# Opaque presentation shell interface

`layouts/shared-shell.html` is runtime infrastructure. Copy it without opening or rewriting it. The shell is the single owner of viewport sizing, 16:9 stage geometry, letterboxing, centering, clipping, scrolling, and four-direction keyboard navigation.

Only the following literal anchors are authoring interfaces. Edit them in the copied deck and leave every other shell byte unchanged.

- Root language: `<html lang="en">`
- Document title: `<title>Presentation template</title>`
- Theme import: `<link rel="stylesheet" href="../styles/template.css" />`
- Deck label: `<div class="deck" aria-label="Presentation">`
- Slide insertion range:

```html
<!-- BEGIN SLIDES -->
<!-- Insert one direct-child .slide wrapper per presentation page. -->
<!-- END SLIDES -->
```

After copying the shell to the output deck, replace the theme-import anchor with exactly one `<style data-template-theme>...</style>` block containing the already-read `styles/template.css`. This keeps the final deck standalone and avoids a path that changes when the shell is copied out of `layouts/`. Do not edit the shell's `<style data-presentation-shell>` block.

Replace the content between the slide markers with one direct-child `.slide` wrapper per page while retaining both marker comments:

```html
<div class="slide">
  <div class="stage" data-layout="cover">
    <div class="fit">...</div>
  </div>
</div>
```

Every generated page supplies exactly one complete `.stage > .fit` inside its direct-child `.slide` wrapper. Generated page markup contains no `doctype`, document elements, `.deck`, shell CSS, or navigation JavaScript.

The theme may set color, type, and other visual tokens used by `.stage`, but it must not set viewport geometry. Do not declare layout-affecting `width`, `height`, `margin`, `padding`, `display`, `position`, `inset`, `overflow`, `flex`, `container-type`, `transform`, or `zoom` rules for `html`, `body`, `.deck`, `.slide`, or `.stage` in theme CSS or generated pages. Use `cqw`, `cqh`, percentages, Flexbox, and Grid for design content inside `.fit`; never scale or move the outer stage.
