/**
 * Load the optional Canvas helper, preparing its isolated install on demand.
 *
 * Pixel commands are normal workflow steps, so callers should not have to know
 * which of them happens to import Canvas internally. Keep the dependency out of
 * the repository while making every Canvas-backed entry point self-contained.
 */
import { execFileSync } from "node:child_process";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const require_ = createRequire(import.meta.url);
const HERE = path.dirname(fileURLToPath(import.meta.url));

function resolveCanvas(libraryDirectory) {
  for (const id of [path.join(libraryDirectory, "node_modules", "@napi-rs/canvas"), "@napi-rs/canvas"]) {
    try {
      return require_.resolve(id);
    } catch {
      // Keep looking. A missing local helper may still exist in the host image.
    }
  }
  return null;
}

export async function loadCanvas() {
  const libraryDirectory = process.env.PRT_NODE_LIBS ?? "/tmp/prt-nodelibs";
  let resolved = resolveCanvas(libraryDirectory);
  if (!resolved) {
    const bootstrap = process.env.PRT_BOOTSTRAP ?? path.join(HERE, "bootstrap.sh");
    process.stderr.write(`pixel helper: @napi-rs/canvas missing; installing into ${libraryDirectory}\n`);
    const output = execFileSync("bash", [bootstrap, "--pixels"], {
      encoding: "utf8",
      env: { ...process.env, PRT_NODE_LIBS: libraryDirectory },
      stdio: ["ignore", "pipe", "inherit"],
    });
    if (output) process.stderr.write(output);
    resolved = resolveCanvas(libraryDirectory);
  }
  if (!resolved) {
    throw new Error(`@napi-rs/canvas is still unavailable after running ${process.env.PRT_BOOTSTRAP ?? path.join(HERE, "bootstrap.sh")} --pixels`);
  }
  return import(resolved);
}
