#!/usr/bin/env node
/**
 * extract-html.mjs — harvest style evidence from an HTML deck.
 *
 * Drives the page with the agent-browser CLI (the house browser driver; never
 * Playwright/Puppeteer) and walks every slide's DOM, recording geometry,
 * computed styles, text runs, decoration candidates, and — so a corporate logo
 * survives the round trip — the identity of every image and inline SVG.
 *
 *   node extract-html.mjs --input <deck.html> --out <evidence.json>
 *                         [--slide-sel .slide] [--stage-sel .stage] [--media <dir>]
 *
 * Writes the shared evidence schema documented in references/evidence-schema.md.
 */
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { writeFileSync, existsSync, mkdirSync, copyFileSync } from "node:fs";
import path from "node:path";
import { pathToFileURL, fileURLToPath } from "node:url";

const execFileAsync = promisify(execFile);
const BROWSER = process.env.AGENT_BROWSER_BIN ?? "agent-browser";
const MAX_BUFFER = 256 * 1024 * 1024;

function parseArgs(argv) {
  const args = { input: "", out: "", slideSel: ".slide", stageSel: ".stage", media: "" };
  for (let i = 2; i < argv.length; i += 1) {
    const a = argv[i], next = argv[i + 1];
    if (a === "--input") { args.input = next; i += 1; }
    else if (a === "--out") { args.out = next; i += 1; }
    else if (a === "--slide-sel") { args.slideSel = next; i += 1; }
    else if (a === "--stage-sel") { args.stageSel = next; i += 1; }
    else if (a === "--media") { args.media = next; i += 1; }
    else if (a === "--help" || a === "-h") { usage(); process.exit(0); }
    else throw new Error(`Unknown argument: ${a}`);
  }
  if (!args.input || !args.out) { usage(); process.exit(1); }
  return args;
}

function usage() {
  console.log(`Usage: node extract-html.mjs --input <deck.html> --out <evidence.json>
                            [--slide-sel <css>] [--stage-sel <css>] [--media <dir>]

Opens the deck in agent-browser and dumps per-slide style and asset evidence.`);
}

async function browser(args) {
  const { stdout } = await execFileAsync(BROWSER, args, { maxBuffer: MAX_BUFFER });
  return stdout;
}

/** agent-browser eval prints the value JSON-encoded; unwrap one layer. */
async function evalJson(expression) {
  const stdout = await browser(["eval", expression]);
  const trimmed = stdout.trim();
  if (!trimmed) return null;
  const last = trimmed.split("\n").pop();
  let value;
  try { value = JSON.parse(last); } catch { throw new Error(`eval did not return JSON: ${last.slice(0, 300)}`); }
  return typeof value === "string" ? JSON.parse(value) : value;
}

/* The page-side collector. Runs inside the deck; must stay self-contained. */
const COLLECTOR = String.raw`(() => {
  const SLIDE_SEL = __SLIDE__, STAGE_SEL = __STAGE__, INDEX = __INDEX__;
  const slides = [...document.querySelectorAll(SLIDE_SEL)];
  const slide = slides[INDEX];
  if (!slide) return JSON.stringify({ error: "no-slide" });
  const stage = slide.querySelector(STAGE_SEL) || slide;
  const sb = stage.getBoundingClientRect();
  const W = sb.width || 1, H = sb.height || 1;
  const pct = (v, base) => Math.round((v / base) * 10000) / 100;

  const toHex = (c) => {
    if (!c) return null;
    const m = c.match(/rgba?\(([^)]+)\)/);
    if (!m) return null;
    const p = m[1].split(",").map((s) => parseFloat(s.trim()));
    if (p.length > 3 && p[3] === 0) return null;
    const h = (n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, "0");
    return { hex: ("#" + h(p[0]) + h(p[1]) + h(p[2])).toUpperCase(), alpha: p.length > 3 ? p[3] : 1 };
  };
  const radii = (cs) => [cs.borderTopLeftRadius, cs.borderTopRightRadius, cs.borderBottomRightRadius, cs.borderBottomLeftRadius];
  const ICON_FONT = /icon|awesome|glyph|symbol|material|ionicons|feather/i;

  const text = [], shapes = [], deco = [], assets = [], colorArea = {}, fontArea = {}, radiusHits = {};
  const bump = (bag, key, amount) => { if (key == null) return; bag[key] = (bag[key] || 0) + amount; };

  const stageBg = toHex(getComputedStyle(stage).backgroundColor);
  if (stageBg) bump(colorArea, stageBg.hex, 1);

  for (const el of [...stage.querySelectorAll("*")]) {
    const tag = el.tagName.toLowerCase();
    if (tag === "script" || tag === "style") continue;
    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) continue;
    const cs = getComputedStyle(el);
    if (cs.display === "none" || cs.visibility === "hidden" || parseFloat(cs.opacity) === 0) continue;
    const area = (r.width * r.height) / (W * H);
    const box = { x: pct(r.left - sb.left, W), y: pct(r.top - sb.top, H), w: pct(r.width, W), h: pct(r.height, H) };

    // direct text only, so a wrapper is not counted as its children's text
    const own = [...el.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent.trim()).join(" ").trim();
    if (own) {
      const fg = toHex(cs.color);
      const sizePx = parseFloat(cs.fontSize);
      const family = (cs.fontFamily || "").split(",")[0].replace(/["']/g, "").trim();
      const isIcon = ICON_FONT.test(family);
      text.push({
        text: own.slice(0, 160), tag,
        cls: typeof el.className === "string" ? el.className : "",
        family,
        sizePx: Math.round(sizePx * 100) / 100,
        sizeCqw: Math.round((sizePx / W) * 10000) / 100,
        weight: cs.fontWeight, lineHeight: cs.lineHeight, letterSpacing: cs.letterSpacing,
        transform: cs.textTransform, color: fg ? fg.hex : null, box,
        iconFont: isIcon, glyph: isIcon ? own.trim() : null,
      });
      bump(fontArea, family, area);
      if (fg) bump(colorArea, fg.hex, area * 0.35);
    }

    const bg = toHex(cs.backgroundColor);
    const bgImage = cs.backgroundImage && cs.backgroundImage !== "none" ? cs.backgroundImage : null;
    const isSvgShape = ["path", "polygon", "circle", "ellipse", "rect", "line"].includes(tag);

    // asset identity: a placed image, a CSS background image, or an inline <svg>
    let assetId = null, assetSrc = null;
    if (tag === "img") { assetSrc = el.currentSrc || el.src; }
    else if (bgImage) { const m = bgImage.match(/url\(["']?([^"')]+)["']?\)/); if (m) assetSrc = m[1]; }
    else if (tag === "svg" && !el.closest("svg:not(:scope)")) { assetSrc = "inline-svg"; }
    if (assetSrc) {
      assetId = assetSrc === "inline-svg"
        ? "svg:" + (el.outerHTML.length + ":" + el.outerHTML.slice(0, 40).replace(/\s+/g, ""))
        : assetSrc.split("/").pop().split("?")[0];
      assets.push({
        id: assetId, src: assetSrc, box,
        inline: assetSrc === "inline-svg" ? el.outerHTML.slice(0, 4000) : null,
        naturalWidth: tag === "img" ? el.naturalWidth : null,
      });
    }

    if (bg || bgImage || isSvgShape || tag === "img") {
      const rad = radii(cs);
      if (!isSvgShape) {
        for (const v of rad) if (parseFloat(v) > 0.5 || v === "50%" || v === "999px") bump(radiusHits, v, 1);
      }
      if (bg && !isSvgShape) bump(colorArea, bg.hex, area);
      let fill = null;
      if (isSvgShape) {
        fill = {
          fillRaw: el.getAttribute("fill") || cs.fill || null,
          strokeRaw: (el.getAttribute("stroke") || cs.stroke) !== "none" ? (el.getAttribute("stroke") || cs.stroke) : null,
          strokeWidth: el.getAttribute("stroke-width") || null,
        };
        const fh = toHex(cs.fill);
        if (fh) bump(colorArea, fh.hex, area * 0.6);
      }
      shapes.push({
        tag, cls: typeof el.className === "string" ? el.className : "",
        role: tag === "img" || bgImage ? "media" : isSvgShape ? "vector" : "block",
        assetId,
        bg: bg ? bg.hex : null, bgAlpha: bg ? bg.alpha : null,
        radius: rad,
        radiusCqw: rad.map((v) => (v.endsWith("px") ? Math.round((parseFloat(v) / W) * 100000) / 1000 : v)),
        d: tag === "path" ? (el.getAttribute("d") || "").slice(0, 1200)
          : tag === "polygon" ? (el.getAttribute("points") || "").slice(0, 1200) : null,
        // Keep enough vector evidence to preserve small icon candidates and to
        // distinguish reusable decoration from plain blocks.
        ...(isSvgShape ? (() => {
          const owner = el.closest("svg");
          const dAttr = el.getAttribute("d") || "";
          return {
            kind: tag === "path" ? "blob" : tag === "circle" || tag === "ellipse" ? "ellipse" : tag,
            color: toHex(cs.fill)?.hex || toHex(cs.stroke)?.hex || null,
            curves: (dAttr.match(/[csqta]/gi) || []).length,
            viewBox: owner?.getAttribute("viewBox") || null,
          };
        })() : {}),
        svg: fill, z: cs.zIndex, position: cs.position, opacity: cs.opacity,
        box, area: Math.round(area * 10000) / 10000,
      });
    }
  }

  for (const el of [...stage.children]) {
    const cs = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) continue;
    const html = el.outerHTML;
    deco.push({
      textless: (el.textContent || "").trim().length === 0,
      position: cs.position, z: cs.zIndex,
      cls: typeof el.className === "string" ? el.className : "",
      dataAttrs: Object.fromEntries([...el.attributes].filter((a) => a.name.startsWith("data-")).map((a) => [a.name, a.value])),
      box: { x: pct(r.left - sb.left, W), y: pct(r.top - sb.top, H), w: pct(r.width, W), h: pct(r.height, H) },
      html: html.length > 4000 ? html.slice(0, 4000) + "…" : html,
      htmlLength: html.length,
    });
  }

  return JSON.stringify({
    index: INDEX + 1,
    stage: { w: Math.round(W), h: Math.round(H) },
    stageBg: stageBg ? stageBg.hex : null,
    stageStyleAttr: stage.getAttribute("style") || "",
    text, shapes, deco, assets, colorArea, fontArea, radiusHits,
  });
})()`;

async function collectSlide(index, slideSel, stageSel) {
  return evalJson(COLLECTOR
    .replace("__SLIDE__", JSON.stringify(slideSel))
    .replace("__STAGE__", JSON.stringify(stageSel))
    .replace("__INDEX__", String(index)));
}

async function collectRoot() {
  return evalJson(String.raw`(() => {
    const root = document.documentElement;
    const cs = getComputedStyle(root);
    const vars = {};
    const fontFaces = [];
    for (const sheet of [...document.styleSheets]) {
      let rules = [];
      try { rules = [...sheet.cssRules]; } catch { continue; }
      for (const rule of rules) {
        if (rule.type === CSSRule.FONT_FACE_RULE) {
          fontFaces.push({
            family: rule.style.getPropertyValue("font-family").replace(/["']/g, "").trim() || null,
            src: rule.style.getPropertyValue("src").trim() || null,
            weight: rule.style.getPropertyValue("font-weight").trim() || null,
            style: rule.style.getPropertyValue("font-style").trim() || null,
          });
        }
        if (!rule.style) continue;
        for (const prop of [...rule.style]) {
          if (prop.startsWith("--")) vars[prop] = rule.style.getPropertyValue(prop).trim();
        }
      }
    }
    // Cross-origin/file stylesheets throw on cssRules, so also probe the canonical
    // v3 token names directly — computed values resolve even when the rule is unreadable.
    const CANON = ["--bg","--surface","--ink","--soft","--ph","--accent","--s1","--s2","--s3",
      "--oa","--o1","--o2","--o3","--ka","--kad","--k1","--k2","--k3",
      "--g0","--g1","--g2","--g3","--t0","--t1","--t2","--t3",
      "--fd","--fb","--fw-display","--fw-label","--fw-body","--cjk-display","--cjk-body",
      "--r-xs","--r-sm","--r-md","--r-lg","--r-xl","--r-pill","--r-round"];
    const resolved = {};
    for (const k of [...new Set([...Object.keys(vars), ...CANON])]) {
      const value = cs.getPropertyValue(k).trim() || vars[k] || "";
      if (value) resolved[k] = value;
    }
    return JSON.stringify({
      lang: root.getAttribute("lang"),
      colorSystemAttr: root.getAttribute("data-color-system"),
      title: document.title,
      cssVars: resolved,
      fontFaces,
      fontLinks: [...document.querySelectorAll('link[rel="stylesheet"]')].map((l) => l.href)
        .filter((h) => /fonts\.googleapis|fonts\.gstatic/.test(h)),
    });
  })()`);
}

/** Roll per-slide sightings into one asset record per file, like the pptx path. */
function foldAssets(slides, mediaDir, deckDir) {
  const byId = new Map();
  for (const slide of slides) {
    for (const a of slide.assets || []) {
      if (!byId.has(a.id)) byId.set(a.id, { id: a.id, src: a.src, inline: a.inline, uses: 0, slides: [], boxes: [] });
      const rec = byId.get(a.id);
      rec.uses += 1;
      if (!rec.slides.includes(slide.index)) rec.slides.push(slide.index);
      rec.boxes.push(a.box);
    }
  }
  const out = [...byId.values()];
  if (mediaDir) {
    mkdirSync(mediaDir, { recursive: true });
    for (const rec of out) {
      if (!rec.src || rec.src === "inline-svg" || rec.src.startsWith("data:")) continue;
      try {
        const abs = rec.src.startsWith("file://") ? fileURLToPath(rec.src) : path.resolve(deckDir, rec.src);
        if (!existsSync(abs)) continue;
        const dst = path.join(mediaDir, path.basename(abs));
        copyFileSync(abs, dst);
        rec.file = dst;
      } catch { /* remote or unreadable asset; the record still names it */ }
    }
  }
  return out.sort((a, b) => b.slides.length - a.slides.length);
}

async function main() {
  const args = parseArgs(process.argv);
  const abs = path.resolve(args.input);
  if (!existsSync(abs)) throw new Error(`Input not found: ${abs}`);

  await browser(["set", "viewport", "1920", "1080"]);
  await browser(["open", pathToFileURL(abs).href]);
  await browser(["wait", "900"]);

  const slideCount = Number(await evalJson(
    `JSON.stringify(document.querySelectorAll(${JSON.stringify(args.slideSel)}).length)`)) || 0;
  if (!slideCount) throw new Error(`No slides matched ${args.slideSel}`);

  const root = await collectRoot();
  const slides = [];
  for (let i = 0; i < slideCount; i += 1) {
    process.stderr.write(`slide ${i + 1}/${slideCount}\r`);
    slides.push(await collectSlide(i, args.slideSel, args.stageSel));
  }
  process.stderr.write("\n");

  const evidence = {
    schema: "presentation-evidence/2",
    source: { kind: "html", path: abs, slideCount, stage: slides[0]?.stage ?? null, rendered: true },
    root,
    assets: foldAssets(slides, args.media, path.dirname(abs)),
    slides,
  };
  writeFileSync(args.out, JSON.stringify(evidence, null, 2));
  console.log(JSON.stringify({ out: args.out, slideCount, assets: evidence.assets.length }));
}

main().catch((error) => {
  console.error(error.stack || error.message);
  process.exit(1);
});
