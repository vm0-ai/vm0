#!/usr/bin/env node
/**
 * extract-pdf.mjs — harvest style evidence from a PDF deck with Poppler.
 *
 * render-pages.mjs installs Poppler on demand before this extractor runs. Its
 * command-line tools provide complementary views of the same document:
 *   - pdftocairo renders each page to PNG for visual inspection;
 *   - pdftohtml exposes positioned text, fonts, colours, and image boxes;
 *   - pdffonts records declared font type and embedding status;
 *   - pdftocairo SVG output preserves reusable vector geometry;
 *   - pdfinfo reports page count and page dimensions.
 *
 *   node extract-pdf.mjs --input <deck.pdf> --out <evidence.json> --pages <dir>
 *                        [--media <dir>] [--scale 2] [--max-pages 40]
 */
import {
  copyFileSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { createHash } from "node:crypto";
import { execFileSync, spawnSync } from "node:child_process";
import os from "node:os";
import path from "node:path";

const MAX_BUFFER = 128 * 1024 * 1024;
const IDENTITY = [1, 0, 0, 1, 0, 0];

function parseArgs(argv) {
  const args = { input: "", out: "", pages: "", media: "", scale: 2, maxPages: 40 };
  for (let i = 2; i < argv.length; i += 1) {
    const a = argv[i], next = argv[i + 1];
    if (a === "--input") { args.input = next; i += 1; }
    else if (a === "--out") { args.out = next; i += 1; }
    else if (a === "--pages") { args.pages = next; i += 1; }
    else if (a === "--media") { args.media = next; i += 1; }
    else if (a === "--scale") { args.scale = Number(next); i += 1; }
    else if (a === "--max-pages") { args.maxPages = Number(next); i += 1; }
    else if (a === "--help" || a === "-h") { usage(); process.exit(0); }
    else throw new Error(`Unknown argument: ${a}`);
  }
  if (!args.input || !args.out || !args.pages) { usage(); process.exit(1); }
  if (!(args.scale > 0) || !(args.maxPages > 0)) throw new Error("--scale and --max-pages must be positive numbers");
  args.maxPages = Math.floor(args.maxPages);
  return args;
}

function usage() {
  console.log(`Usage: node extract-pdf.mjs --input <deck.pdf> --out <evidence.json> --pages <dir>
                           [--media <dir>] [--scale 2] [--max-pages 40]`);
}

function run(bin, argv, options = {}) {
  try {
    return execFileSync(bin, argv, {
      encoding: "utf8",
      maxBuffer: MAX_BUFFER,
      timeout: 120_000,
      stdio: ["ignore", "pipe", "pipe"],
      ...options,
    });
  } catch (error) {
    const stderr = String(error.stderr || "").trim();
    const detail = stderr ? `\n${stderr}` : "";
    throw new Error(`${bin} failed (${argv.join(" ")})${detail}`, { cause: error });
  }
}

function toolVersion(bin) {
  const result = spawnSync(bin, ["-v"], { encoding: "utf8", maxBuffer: 1024 * 1024 });
  if (result.error?.code === "ENOENT") {
    throw new Error(`${bin} is not available. Run render-pages.mjs first so it can install Poppler on demand.`);
  }
  if (result.status !== 0) throw new Error(`${bin} could not be started`);
  return `${result.stdout || ""}\n${result.stderr || ""}`.trim().split("\n")[0];
}

const round = (value, places = 2) => {
  const factor = 10 ** places;
  return Math.round(value * factor) / factor;
};
const pct = (value, base) => round((value / Math.max(base, 0.0001)) * 100, 2);
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));

function parseAttributes(source) {
  const attrs = {};
  for (const match of source.matchAll(/([:\w-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)) {
    attrs[match[1]] = match[2] ?? match[3] ?? "";
  }
  return attrs;
}

function decodeXml(value) {
  return String(value || "")
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&#([0-9]+);/g, (_, n) => String.fromCodePoint(parseInt(n, 10)))
    .replace(/&(amp|lt|gt|quot|apos);/g, (_, name) => ({
      amp: "&", lt: "<", gt: ">", quot: '"', apos: "'",
    }[name]));
}

function normalizeFamily(value) {
  return decodeXml(value).replace(/^[A-Z]{6}\+/, "");
}

function parsePdfFonts(output) {
  const fonts = [];
  for (const line of String(output || "").split(/\r?\n/).slice(2)) {
    const parts = line.trim().split(/\s+/).filter(Boolean);
    if (parts.length < 8) continue;
    const embedded = parts.at(-5), subset = parts.at(-4), unicode = parts.at(-3);
    if (!/^(yes|no)$/i.test(embedded) || !/^(yes|no)$/i.test(subset) || !/^(yes|no)$/i.test(unicode)) continue;
    const rawName = parts[0];
    fonts.push({
      name: normalizeFamily(rawName),
      rawName,
      type: parts.slice(1, -6).join(" ") || null,
      encoding: parts.at(-6) || null,
      embedded: embedded.toLowerCase() === "yes",
      subset: subset.toLowerCase() === "yes",
      unicodeMap: unicode.toLowerCase() === "yes",
      object: `${parts.at(-2)} ${parts.at(-1)}`,
      directlyUsable: false,
      note: "PDF font metadata only; no installable font file was extracted",
    });
  }
  return fonts;
}

function colorOf(value) {
  const source = String(value || "").trim();
  if (!source || /^(none|transparent)$/i.test(source)) return null;
  const short = source.match(/^#([0-9a-f]{3})$/i);
  if (short) return (`#${[...short[1]].map((c) => c + c).join("")}`).toUpperCase();
  const full = source.match(/^#([0-9a-f]{6})$/i);
  if (full) return (`#${full[1]}`).toUpperCase();
  const rgb = source.match(/^rgba?\(([^)]+)\)$/i);
  if (rgb) {
    const parts = rgb[1].split(/[ ,/]+/).filter(Boolean).slice(0, 3).map((part) => {
      return part.endsWith("%") ? (parseFloat(part) / 100) * 255 : parseFloat(part);
    });
    if (parts.length === 3 && parts.every(Number.isFinite)) {
      return `#${parts.map((n) => clamp(Math.round(n), 0, 255).toString(16).padStart(2, "0")).join("")}`.toUpperCase();
    }
  }
  const named = { black: "#000000", white: "#FFFFFF", red: "#FF0000", blue: "#0000FF", green: "#008000" };
  return named[source.toLowerCase()] || null;
}

function parseTextXml(xml) {
  const pages = new Map();
  // Poppler declares a font the first time it appears, then reuses that id on
  // later pages without repeating <fontspec>. Keep the table document-wide.
  const fonts = new Map();
  const iconFont = /icon|awesome|glyph|symbol|material|ionicons|feather|bootstrap-icons/i;
  for (const pageMatch of xml.matchAll(/<page\b([^>]*)>([\s\S]*?)<\/page>/gi)) {
    const pageAttrs = parseAttributes(pageMatch[1]);
    const pageNo = Number(pageAttrs.number);
    const width = Number(pageAttrs.width) || 1;
    const height = Number(pageAttrs.height) || 1;
    const body = pageMatch[2];
    for (const fontMatch of body.matchAll(/<fontspec\b([^>]*)\/?\s*>/gi)) {
      const attrs = parseAttributes(fontMatch[1]);
      fonts.set(attrs.id, {
        family: normalizeFamily(attrs.family || "unknown"),
        size: Number(attrs.size) || 0,
        color: colorOf(attrs.color) || "#000000",
      });
    }

    const text = [];
    for (const textMatch of body.matchAll(/<text\b([^>]*)>([\s\S]*?)<\/text>/gi)) {
      const attrs = parseAttributes(textMatch[1]);
      const markup = textMatch[2];
      const value = decodeXml(markup.replace(/<br\s*\/?\s*>/gi, "\n").replace(/<[^>]+>/g, "")).trim();
      if (!value) continue;
      const font = fonts.get(attrs.font) || { family: "unknown", size: Number(attrs.height) || 0, color: "#000000" };
      const family = font.family;
      const isIcon = iconFont.test(family);
      const size = font.size || Number(attrs.height) || 0;
      const bold = /<(?:b|strong)\b/i.test(markup) || /bold|black|heavy/i.test(family);
      const italic = /<(?:i|em)\b/i.test(markup) || /italic|oblique/i.test(family);
      text.push({
        text: value.slice(0, 160),
        family,
        sizePt: round(size),
        sizeCqw: round((size / width) * 100),
        color: font.color,
        weight: bold ? "bold" : "regular",
        italic,
        box: {
          x: pct(Number(attrs.left) || 0, width),
          y: pct(Number(attrs.top) || 0, height),
          w: pct(Number(attrs.width) || 0, width),
          h: pct(Number(attrs.height) || size, height),
        },
        iconFont: isIcon,
        glyph: isIcon ? value : null,
        method: "poppler-pdftohtml",
      });
    }

    const images = [];
    for (const imageMatch of body.matchAll(/<image\b([^>]*)\/?\s*>/gi)) {
      const attrs = parseAttributes(imageMatch[1]);
      images.push({
        src: decodeXml(attrs.src || ""),
        box: {
          x: pct(Number(attrs.left) || 0, width),
          y: pct(Number(attrs.top) || 0, height),
          w: pct(Number(attrs.width) || 0, width),
          h: pct(Number(attrs.height) || 0, height),
        },
      });
    }
    pages.set(pageNo, { width, height, text, images });
  }
  return pages;
}

const multiply = (a, b) => [
  a[0] * b[0] + a[2] * b[1],
  a[1] * b[0] + a[3] * b[1],
  a[0] * b[2] + a[2] * b[3],
  a[1] * b[2] + a[3] * b[3],
  a[0] * b[4] + a[2] * b[5] + a[4],
  a[1] * b[4] + a[3] * b[5] + a[5],
];
const transformPoint = (matrix, point) => [
  matrix[0] * point[0] + matrix[2] * point[1] + matrix[4],
  matrix[1] * point[0] + matrix[3] * point[1] + matrix[5],
];
const samePoint = (a, b) => Math.abs(a[0] - b[0]) < 0.0001 && Math.abs(a[1] - b[1]) < 0.0001;
const isIdentity = (matrix) => matrix.every((value, i) => Math.abs(value - IDENTITY[i]) < 0.000001);

function transformOf(source) {
  let matrix = IDENTITY;
  for (const match of String(source || "").matchAll(/([a-z]+)\s*\(([^)]*)\)/gi)) {
    const name = match[1].toLowerCase();
    const values = match[2].split(/[ ,]+/).filter(Boolean).map(Number);
    let next = IDENTITY;
    if (name === "matrix" && values.length >= 6) next = values.slice(0, 6);
    else if (name === "translate") next = [1, 0, 0, 1, values[0] || 0, values[1] || 0];
    else if (name === "scale") next = [values[0] ?? 1, 0, 0, values[1] ?? values[0] ?? 1, 0, 0];
    else if (name === "rotate") {
      const angle = ((values[0] || 0) * Math.PI) / 180;
      const rotation = [Math.cos(angle), Math.sin(angle), -Math.sin(angle), Math.cos(angle), 0, 0];
      if (values.length >= 3) {
        next = multiply(multiply([1, 0, 0, 1, values[1], values[2]], rotation), [1, 0, 0, 1, -values[1], -values[2]]);
      } else next = rotation;
    } else if (name === "skewx") next = [1, 0, Math.tan(((values[0] || 0) * Math.PI) / 180), 1, 0, 0];
    else if (name === "skewy") next = [1, Math.tan(((values[0] || 0) * Math.PI) / 180), 0, 1, 0, 0];
    matrix = multiply(matrix, next);
  }
  return matrix;
}

function tokenizePath(d) {
  return String(d || "").match(/[AaCcHhLlMmQqSsTtVvZz]|[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g) || [];
}

function parsePath(d, matrix) {
  const tokens = tokenizePath(d);
  const segments = [];
  const bounds = [];
  let i = 0, command = null, current = [0, 0], start = [0, 0];
  let previousCubic = null, previousQuadratic = null, hasArc = false;
  const isCommand = (value) => /^[A-Za-z]$/.test(value || "");
  const read = (count) => {
    if (i + count > tokens.length || tokens.slice(i, i + count).some(isCommand)) return null;
    const values = tokens.slice(i, i + count).map(Number);
    i += count;
    return values;
  };
  const transformed = (point) => transformPoint(matrix, point);
  const addBounds = (...points) => bounds.push(...points.map(transformed));
  const lineTo = (point) => {
    segments.push({ type: "line", from: transformed(current), to: transformed(point) });
    addBounds(current, point);
    current = point;
  };
  const curveTo = (c1, c2, point) => {
    segments.push({ type: "curve", from: transformed(current), c1: transformed(c1), c2: transformed(c2), to: transformed(point) });
    addBounds(current, c1, c2, point);
    current = point;
  };

  while (i < tokens.length) {
    if (isCommand(tokens[i])) command = tokens[i++];
    if (!command) { i += 1; continue; }
    const upper = command.toUpperCase();
    const relative = command !== upper;
    if (upper === "Z") {
      if (!samePoint(current, start)) lineTo(start);
      previousCubic = null; previousQuadratic = null; command = null;
      continue;
    }
    const count = ({ M: 2, L: 2, H: 1, V: 1, C: 6, S: 4, Q: 4, T: 2, A: 7 })[upper];
    const values = read(count);
    if (!values) { command = null; continue; }
    const point = (x, y) => relative ? [current[0] + x, current[1] + y] : [x, y];

    if (upper === "M") {
      current = point(values[0], values[1]);
      start = current;
      addBounds(current);
      command = relative ? "l" : "L";
      previousCubic = null; previousQuadratic = null;
    } else if (upper === "L") {
      lineTo(point(values[0], values[1]));
      previousCubic = null; previousQuadratic = null;
    } else if (upper === "H") {
      lineTo([relative ? current[0] + values[0] : values[0], current[1]]);
      previousCubic = null; previousQuadratic = null;
    } else if (upper === "V") {
      lineTo([current[0], relative ? current[1] + values[0] : values[0]]);
      previousCubic = null; previousQuadratic = null;
    } else if (upper === "C") {
      const c1 = point(values[0], values[1]);
      const c2 = point(values[2], values[3]);
      const end = point(values[4], values[5]);
      curveTo(c1, c2, end);
      previousCubic = c2; previousQuadratic = null;
    } else if (upper === "S") {
      const c1 = previousCubic ? [2 * current[0] - previousCubic[0], 2 * current[1] - previousCubic[1]] : current;
      const c2 = point(values[0], values[1]);
      const end = point(values[2], values[3]);
      curveTo(c1, c2, end);
      previousCubic = c2; previousQuadratic = null;
    } else if (upper === "Q") {
      const control = point(values[0], values[1]);
      const end = point(values[2], values[3]);
      const c1 = [current[0] + (2 / 3) * (control[0] - current[0]), current[1] + (2 / 3) * (control[1] - current[1])];
      const c2 = [end[0] + (2 / 3) * (control[0] - end[0]), end[1] + (2 / 3) * (control[1] - end[1])];
      curveTo(c1, c2, end);
      previousQuadratic = control; previousCubic = null;
    } else if (upper === "T") {
      const control = previousQuadratic ? [2 * current[0] - previousQuadratic[0], 2 * current[1] - previousQuadratic[1]] : current;
      const end = point(values[0], values[1]);
      const c1 = [current[0] + (2 / 3) * (control[0] - current[0]), current[1] + (2 / 3) * (control[1] - current[1])];
      const c2 = [end[0] + (2 / 3) * (control[0] - end[0]), end[1] + (2 / 3) * (control[1] - end[1])];
      curveTo(c1, c2, end);
      previousQuadratic = control; previousCubic = null;
    } else if (upper === "A") {
      const end = point(values[5], values[6]);
      const rx = Math.abs(values[0]), ry = Math.abs(values[1]);
      const from = current;
      segments.push({ type: "curve", from: transformed(from), c1: transformed(from), c2: transformed(end), to: transformed(end), arc: true });
      addBounds(from, end, [from[0] - rx, from[1] - ry], [from[0] + rx, from[1] + ry], [end[0] - rx, end[1] - ry], [end[0] + rx, end[1] + ry]);
      current = end; hasArc = true; previousCubic = null; previousQuadratic = null;
    }
  }

  if (!bounds.length) return { segments, bbox: null, hasArc };
  const xs = bounds.map((point) => point[0]), ys = bounds.map((point) => point[1]);
  return { segments, bbox: [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)], hasArc };
}

function serializeSegments(segments) {
  const out = [];
  let cursor = null;
  const n = (value) => String(round(value, 4));
  for (const segment of segments) {
    if (!cursor || !samePoint(cursor, segment.from)) out.push(`M${n(segment.from[0])},${n(segment.from[1])}`);
    if (segment.type === "line") out.push(`L${n(segment.to[0])},${n(segment.to[1])}`);
    else out.push(`C${n(segment.c1[0])},${n(segment.c1[1])} ${n(segment.c2[0])},${n(segment.c2[1])} ${n(segment.to[0])},${n(segment.to[1])}`);
    cursor = segment.to;
  }
  return out.join(" ");
}

function analyzePath(segments, bbox) {
  const width = bbox[2] - bbox[0], height = bbox[3] - bbox[1];
  const shortSide = Math.min(width, height), longSide = Math.max(width, height);
  const lines = segments.filter((segment) => segment.type === "line").length;
  const curves = segments.filter((segment) => segment.type === "curve").length;
  if (!curves) return { kind: lines > 5 ? "polygon" : "rect", radii: [], pill: false };

  const runs = [];
  let current = null;
  for (const segment of segments) {
    if (segment.type === "curve") {
      if (!current) { current = { points: [segment.from] }; runs.push(current); }
      current.points.push(segment.c1, segment.c2, segment.to);
    } else current = null;
  }
  const spans = runs.map((run) => {
    const xs = run.points.map((point) => point[0]), ys = run.points.map((point) => point[1]);
    return Math.max(Math.max(...xs) - Math.min(...xs), Math.max(...ys) - Math.min(...ys));
  });
  const sorted = [...spans].sort((a, b) => a - b);
  const median = sorted[Math.floor(sorted.length / 2)] || 0;
  const even = spans.length > 0 && spans.every((span) => Math.abs(span - median) <= Math.max(0.6, median * 0.25));

  if (curves >= 6 && lines <= 1) {
    return { kind: longSide / Math.max(shortSide, 0.001) < 1.08 ? "circle" : "ellipse", radii: [shortSide / 2], pill: false };
  }
  if (runs.length === 4 && even && lines >= 2) {
    const half = shortSide / 2;
    if (median >= half * 0.9) return { kind: "pill", radii: [half], pill: true };
    return { kind: longSide / Math.max(shortSide, 0.001) < 1.08 ? "rounded-square" : "rounded-rect", radii: [median], pill: false };
  }
  if (runs.length >= 2 && runs.length <= 3 && even) return { kind: "part-round", radii: [median], pill: false };
  return { kind: curves >= 2 ? "blob" : "path", radii: [], pill: false };
}

function inlineStyle(attrs) {
  const style = {};
  for (const part of String(attrs.style || "").split(";")) {
    const split = part.indexOf(":");
    if (split < 0) continue;
    style[part.slice(0, split).trim()] = part.slice(split + 1).trim();
  }
  for (const key of ["fill", "stroke", "fill-opacity", "stroke-opacity", "stroke-width", "opacity"]) {
    if (Object.hasOwn(attrs, key)) style[key] = attrs[key];
  }
  return style;
}

function mergedStyle(parent, attrs) {
  const direct = inlineStyle(attrs);
  const inherited = (key, fallback) => Object.hasOwn(direct, key) ? direct[key] : (parent[key] ?? fallback);
  return {
    fill: inherited("fill", "black"),
    stroke: inherited("stroke", "none"),
    fillOpacity: Number(inherited("fill-opacity", 1)),
    strokeOpacity: Number(inherited("stroke-opacity", 1)),
    strokeWidth: Number(inherited("stroke-width", 1)),
    opacity: (parent.opacity ?? 1) * Number(direct.opacity ?? 1),
  };
}

function svgMetrics(svg, fallback) {
  const match = svg.match(/<svg\b([^>]*)>/i);
  const attrs = parseAttributes(match?.[1] || "");
  const viewBox = String(attrs.viewBox || "").split(/[ ,]+/).map(Number);
  if (viewBox.length === 4 && viewBox.every(Number.isFinite)) {
    return { x: viewBox[0], y: viewBox[1], width: viewBox[2], height: viewBox[3] };
  }
  return {
    x: 0, y: 0,
    width: parseFloat(attrs.width) || fallback.width,
    height: parseFloat(attrs.height) || fallback.height,
  };
}

function parseSvgShapes(svg, fallbackStage) {
  const stage = svgMetrics(svg, fallbackStage);
  const withoutDefs = svg.replace(/<defs\b[\s\S]*?<\/defs>/gi, "");
  const shapes = [];
  const stack = [{ name: "root", matrix: IDENTITY, style: { fill: "black", stroke: "none", fillOpacity: 1, strokeOpacity: 1, strokeWidth: 1, opacity: 1 } }];
  for (const match of withoutDefs.matchAll(/<\/?[A-Za-z][^>]*>/g)) {
    const tag = match[0];
    const closing = /^<\//.test(tag);
    const name = tag.match(/^<\/?\s*([:\w-]+)/)?.[1]?.toLowerCase();
    if (!name) continue;
    if (closing) {
      if (["g", "svg", "a", "symbol"].includes(name) && stack.length > 1) stack.pop();
      continue;
    }
    const attrs = parseAttributes(tag);
    const parent = stack[stack.length - 1];
    const matrix = multiply(parent.matrix, transformOf(attrs.transform));
    const style = mergedStyle(parent.style, attrs);
    if (["g", "svg", "a", "symbol"].includes(name)) {
      if (!/\/\s*>$/.test(tag)) stack.push({ name, matrix, style });
      continue;
    }
    if (name !== "path" || !attrs.d) continue;
    const parsed = parsePath(decodeXml(attrs.d), matrix);
    if (!parsed.bbox || parsed.segments.length === 0) continue;
    const bbox = parsed.bbox;
    const width = bbox[2] - bbox[0], height = bbox[3] - bbox[1];
    if (!(width > 0.01) || !(height > 0.01)) continue;
    const fill = colorOf(style.fill), stroke = colorOf(style.stroke);
    const fillOpacity = style.opacity * style.fillOpacity;
    const strokeOpacity = style.opacity * style.strokeOpacity;
    const paint = fill && fillOpacity > 0.01 ? "fill" : (stroke && strokeOpacity > 0.01 ? "stroke" : null);
    const color = paint === "fill" ? fill : stroke;
    if (!paint || !color) continue;
    const area = (width * height) / Math.max(stage.width * stage.height, 0.0001);
    const analysis = analyzePath(parsed.segments, bbox);
    const boxWidth = pct(width, stage.width), boxHeight = pct(height, stage.height);
    const keepPath = boxWidth <= 20 && boxHeight <= 25 && parsed.segments.length <= 1400;
    const reusablePath = isIdentity(matrix) ? decodeXml(attrs.d) : (!parsed.hasArc ? serializeSegments(parsed.segments) : null);
    shapes.push({
      role: "vector",
      kind: analysis.kind,
      paint,
      color,
      stroke: paint === "stroke" ? color : null,
      svgPath: keepPath ? reusablePath : null,
      viewBox: keepPath && reusablePath
        ? `${round(bbox[0], 4)} ${round(bbox[1], 4)} ${round(width, 4)} ${round(height, 4)}`
        : null,
      lineWidth: paint === "stroke" ? round(style.strokeWidth) : null,
      opacity: round(paint === "fill" ? fillOpacity : strokeOpacity, 3),
      box: {
        x: pct(bbox[0] - stage.x, stage.width),
        y: pct(bbox[1] - stage.y, stage.height),
        w: boxWidth,
        h: boxHeight,
      },
      area: round(area, 4),
      segments: parsed.segments.length,
      curves: parsed.segments.filter((segment) => segment.type === "curve").length,
      radiiPt: analysis.radii.map((radius) => round(radius)),
      radiiCqw: analysis.radii.map((radius) => round((radius / stage.width) * 100)),
      pill: analysis.pill,
      method: "poppler-pdftocairo-svg",
    });
  }
  return { stage, shapes };
}

function parsePdfInfo(info) {
  const pages = Number(info.match(/^Pages:\s+(\d+)/m)?.[1]);
  if (!(pages > 0)) throw new Error("pdfinfo did not report a positive page count");
  const sizes = new Map();
  for (const match of info.matchAll(/^Page\s+(\d+)\s+size:\s+([\d.]+)\s+x\s+([\d.]+)\s+pts/mg)) {
    sizes.set(Number(match[1]), { width: Number(match[2]), height: Number(match[3]) });
  }
  const generic = info.match(/^Page size:\s+([\d.]+)\s+x\s+([\d.]+)\s+pts/m);
  if (generic && !sizes.size) sizes.set(1, { width: Number(generic[1]), height: Number(generic[2]) });
  return { pages, sizes };
}

function renderPages(args, tempDir, take) {
  const prefix = path.join(tempDir, "render");
  run("pdftocairo", [
    "-q", "-png", "-r", String(round(72 * args.scale, 3)),
    "-f", "1", "-l", String(take), args.input, prefix,
  ]);
  const rendered = new Map();
  for (const filename of readdirSync(tempDir)) {
    const match = filename.match(/^render-(\d+)\.png$/);
    if (match) rendered.set(Number(match[1]), path.join(tempDir, filename));
  }
  for (let pageNo = 1; pageNo <= take; pageNo += 1) {
    const source = rendered.get(pageNo);
    if (!source) throw new Error(`pdftocairo did not produce a PNG for page ${pageNo}`);
    const destination = path.join(args.pages, `page-${String(pageNo).padStart(2, "0")}.png`);
    copyFileSync(source, destination);
    rendered.set(pageNo, destination);
  }
  return rendered;
}

function assetCollector(mediaDir, xmlDir) {
  const records = new Map();
  return {
    add(pageNo, image) {
      const source = path.isAbsolute(image.src) ? image.src : path.resolve(xmlDir, image.src);
      const readable = source && existsSync(source);
      const digest = readable
        ? createHash("sha1").update(readFileSync(source)).digest("hex")
        : createHash("sha1").update(`${path.basename(image.src || "missing")}|${JSON.stringify(image.box)}`).digest("hex");
      const id = `image-${digest.slice(0, 16)}`;
      if (!records.has(id)) {
        let file = null;
        if (readable && mediaDir) {
          const ext = path.extname(source).toLowerCase() || ".bin";
          file = path.join(mediaDir, `${id}${ext}`);
          copyFileSync(source, file);
        }
        records.set(id, { id, ids: [id], file, uses: 0, slides: new Set(), boxes: [] });
      }
      const record = records.get(id);
      record.uses += 1;
      record.slides.add(pageNo);
      record.boxes.push(image.box);
      return {
        role: "media",
        kind: "image",
        paint: "image",
        color: null,
        assetId: id,
        image: record.file,
        box: image.box,
        area: round(((image.box.w || 0) * (image.box.h || 0)) / 10000, 4),
        method: "poppler-pdftohtml",
      };
    },
    list() {
      return [...records.values()].map((record) => ({
        ...record,
        slides: [...record.slides].sort((a, b) => a - b),
      })).sort((a, b) => b.slides.length - a.slides.length);
    },
  };
}

function pageColors(shapes) {
  const fullStage = shapes.filter((shape) => shape.paint === "fill" && shape.opacity >= 0.99
    && shape.box.w >= 94 && shape.box.h >= 94 && shape.color);
  const stageBg = fullStage.at(-1)?.color || "#FFFFFF";
  const colorArea = { [stageBg]: 1 };
  for (const shape of shapes) {
    if (!shape.color || shape.paint !== "fill") continue;
    if (shape.box.w >= 94 && shape.box.h >= 94) continue;
    colorArea[shape.color] = round((colorArea[shape.color] || 0) + shape.area * (shape.opacity || 1), 4);
  }
  const firstFull = shapes.findIndex((shape) => shape.paint === "fill" && shape.opacity >= 0.99
    && shape.box.w >= 94 && shape.box.h >= 94 && shape.color);
  const lastFull = shapes.findLastIndex((shape) => shape.paint === "fill" && shape.opacity >= 0.99
    && shape.box.w >= 94 && shape.box.h >= 94 && shape.color);
  const filtered = firstFull >= 0 && firstFull !== lastFull
    ? shapes.filter((_, index) => index !== firstFull)
    : shapes;
  return { stageBg, colorArea, shapes: filtered };
}

function main() {
  const args = parseArgs(process.argv);
  if (!existsSync(args.input)) throw new Error(`Input not found: ${args.input}`);
  mkdirSync(args.pages, { recursive: true });
  mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
  if (args.media) mkdirSync(args.media, { recursive: true });

  const versions = {
    pdfinfo: toolVersion("pdfinfo"),
    pdftocairo: toolVersion("pdftocairo"),
    pdftohtml: toolVersion("pdftohtml"),
    pdffonts: toolVersion("pdffonts"),
  };
  const pdfFonts = parsePdfFonts(run("pdffonts", [args.input]));
  const firstInfo = parsePdfInfo(run("pdfinfo", [args.input]));
  const total = firstInfo.pages;
  const take = Math.min(total, args.maxPages);
  const pageInfo = parsePdfInfo(run("pdfinfo", ["-f", "1", "-l", String(take), "-box", args.input]));
  const tempDir = mkdtempSync(path.join(os.tmpdir(), "prt-poppler-"));
  const warnings = [];

  try {
    const xmlPath = path.join(tempDir, "text.xml");
    run("pdftohtml", [
      "-q", "-xml", "-hidden", "-noroundcoord", "-nomerge", "-fontfullname",
      "-enc", "UTF-8", "-zoom", "1", "-nodrm", "-f", "1", "-l", String(take),
      args.input, xmlPath,
    ]);
    const textPages = parseTextXml(readFileSync(xmlPath, "utf8"));
    const rendered = renderPages(args, tempDir, take);
    const assets = assetCollector(args.media, tempDir);
    const slides = [];

    for (let pageNo = 1; pageNo <= take; pageNo += 1) {
      process.stderr.write(`page ${pageNo}/${take}\r`);
      const textPage = textPages.get(pageNo);
      const fallback = textPage || pageInfo.sizes.get(pageNo) || pageInfo.sizes.get(1) || { width: 960, height: 540 };
      let parsed = { stage: { x: 0, y: 0, width: fallback.width, height: fallback.height }, shapes: [] };
      const svgPath = path.join(tempDir, `page-${pageNo}.svg`);
      try {
        run("pdftocairo", ["-q", "-svg", "-f", String(pageNo), "-l", String(pageNo), args.input, svgPath]);
        if (existsSync(svgPath)) parsed = parseSvgShapes(readFileSync(svgPath, "utf8"), fallback);
        else warnings.push(`page ${pageNo}: pdftocairo produced no SVG; vector evidence is unavailable`);
      } catch (error) {
        warnings.push(`page ${pageNo}: vector extraction failed (${error.message.split("\n")[0]})`);
      }
      const mediaShapes = (textPage?.images || []).map((image) => assets.add(pageNo, image));
      const colors = pageColors([...parsed.shapes, ...mediaShapes]);
      slides.push({
        index: pageNo,
        stage: { w: round(parsed.stage.width), h: round(parsed.stage.height) },
        stageBg: colors.stageBg,
        png: rendered.get(pageNo),
        text: textPage?.text || [],
        shapes: colors.shapes,
        colorArea: colors.colorArea,
      });
    }
    process.stderr.write("\n");

    const evidence = {
      schema: "presentation-evidence/2",
      source: {
        kind: "pdf",
        path: path.resolve(args.input),
        slideCount: take,
        pagesInFile: total,
        truncated: take < total,
        stage: slides[0]?.stage || null,
        rendered: true,
        extractor: "poppler",
        tools: versions,
        warnings,
      },
      root: { cssVars: {}, fontLinks: [], pdfFonts },
      assets: assets.list(),
      slides,
    };
    writeFileSync(args.out, JSON.stringify(evidence, null, 2));
    console.log(JSON.stringify({
      out: args.out,
      extractor: "poppler",
      pages: take,
      pagesInFile: total,
      pngDir: args.pages,
      assets: evidence.assets.length,
      fonts: pdfFonts.length,
      warnings: warnings.length,
    }));
  } finally {
    rmSync(tempDir, { recursive: true, force: true });
  }
}

try {
  main();
} catch (error) {
  console.error(error.stack || error.message);
  process.exit(1);
}
