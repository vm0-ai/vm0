#!/usr/bin/env node
/**
 * extract-pixels.mjs — palette evidence from slide images.
 *
 * The fallback path, and for some decks the only path. Plenty of "PPTX" files
 * are one full-bleed picture per slide (every AI slide tool exports that way),
 * and a scanned or flattened PDF is the same story: no text runs, no shapes, no
 * theme — just pixels. This samples them.
 *
 *   node extract-pixels.mjs --images <dir|file> [--images ...] --out <evidence.json>
 *                           [--bins 5] [--top 12] [--max 40]
 *
 * Emits the shared evidence schema with `colorArea` populated and everything
 * else empty, plus an honest `capabilities` block saying what is missing, so the
 * design system that follows does not claim measurements it never had.
 */
import { readdirSync, statSync, writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";
import { loadCanvas } from "./canvas-helper.mjs";

function parseArgs(argv) {
  const args = { images: [], out: "", bins: 5, top: 12, max: 40 };
  for (let i = 2; i < argv.length; i += 1) {
    const a = argv[i], next = argv[i + 1];
    if (a === "--images") { args.images.push(next); i += 1; }
    else if (a === "--out") { args.out = next; i += 1; }
    else if (a === "--bins") { args.bins = Number(next); i += 1; }
    else if (a === "--top") { args.top = Number(next); i += 1; }
    else if (a === "--max") { args.max = Number(next); i += 1; }
    else if (a === "--help" || a === "-h") { usage(); process.exit(0); }
    else throw new Error(`Unknown argument: ${a}`);
  }
  if (!args.images.length || !args.out) { usage(); process.exit(1); }
  return args;
}

function usage() {
  console.log(`Usage: node extract-pixels.mjs --images <dir|file> [--images ...] --out <evidence.json>
                              [--bins 5] [--top 12] [--max 40]`);
}

const IMAGE_EXT = new Set([".png", ".jpg", ".jpeg", ".webp"]);

function expand(inputs) {
  const files = [];
  for (const input of inputs) {
    if (statSync(input).isDirectory()) {
      for (const name of readdirSync(input).sort()) {
        // a contact sheet or reference sheet in the same folder is a picture *of*
        // the slides, not a slide; sampling it double-counts the whole deck
        if (/^(contact-sheet|reference)/i.test(name)) continue;
        if (IMAGE_EXT.has(path.extname(name).toLowerCase())) files.push(path.join(input, name));
      }
    } else if (IMAGE_EXT.has(path.extname(input).toLowerCase())) files.push(input);
  }
  return files;
}

const hex = (r, g, b) =>
  "#" + [r, g, b].map((v) => Math.max(0, Math.min(255, v)).toString(16).padStart(2, "0")).join("").toUpperCase();

/**
 * Quantise to a coarse grid, then merge each bucket back to the mean of the
 * pixels that landed in it. Quantising alone would report #F0F0F0 for a
 * #FFFDF7 paper; the mean recovers the colour the designer actually chose.
 */
function palette(data, width, height, bins, top) {
  const step = Math.max(1, Math.floor(Math.sqrt((width * height) / 240000)));
  const q = 256 / bins;
  const buckets = new Map();
  let counted = 0;
  for (let y = 0; y < height; y += step) {
    for (let x = 0; x < width; x += step) {
      const i = (y * width + x) * 4;
      if (data[i + 3] < 24) continue;
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const key = `${Math.floor(r / q)},${Math.floor(g / q)},${Math.floor(b / q)}`;
      let bucket = buckets.get(key);
      if (!bucket) { bucket = { n: 0, r: 0, g: 0, b: 0 }; buckets.set(key, bucket); }
      bucket.n += 1; bucket.r += r; bucket.g += g; bucket.b += b;
      counted += 1;
    }
  }
  return [...buckets.values()]
    .sort((a, b) => b.n - a.n)
    .slice(0, top)
    .map((b) => ({
      hex: hex(Math.round(b.r / b.n), Math.round(b.g / b.n), Math.round(b.b / b.n)),
      share: Math.round((b.n / Math.max(1, counted)) * 10000) / 10000,
    }));
}

async function main() {
  const args = parseArgs(process.argv);
  const canvasMod = await loadCanvas();
  const { loadImage, createCanvas } = canvasMod.default ?? canvasMod;
  const files = expand(args.images).slice(0, args.max);
  if (!files.length) throw new Error("no images found");

  const slides = [];
  let stage = null;
  for (let i = 0; i < files.length; i += 1) {
    const img = await loadImage(files[i]);
    const w = img.width, h = img.height;
    if (!stage) stage = { w, h };
    const canvas = createCanvas(w, h);
    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0);
    const { data } = ctx.getImageData(0, 0, w, h);
    const colors = palette(data, w, h, args.bins, args.top);
    const colorArea = {};
    for (const c of colors) colorArea[c.hex] = c.share;
    slides.push({
      index: i + 1, stage: { w, h }, stageBg: colors[0]?.hex ?? null, png: files[i],
      text: [], textFrames: [], shapes: [], colorArea, pixelPalette: colors,
    });
    process.stderr.write(`sampled ${i + 1}/${files.length}\r`);
  }
  process.stderr.write("\n");

  const evidence = {
    schema: "presentation-evidence/2",
    source: {
      kind: "images", path: path.resolve(args.images[0]),
      slideCount: slides.length, stage, rendered: true,
      capabilities: {
        palette: "measured from pixels",
        fonts: "not available — identify the typefaces by looking at the slides",
        typeScale: "not available — measure heading vs body proportions by eye",
        radius: "not available — judge corner softness by eye",
        vectorGeometry: "not available — preserve reusable visual treatment in the image layer",
        assets: "not available — a flattened page has no separable logo; crop it by hand if the template needs one",
      },
    },
    root: { cssVars: {}, fontLinks: [] },
    assets: [],
    slides,
  };
  mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
  writeFileSync(args.out, JSON.stringify(evidence, null, 2));
  console.log(JSON.stringify({ out: args.out, images: slides.length, stage,
    topColors: slides[0]?.pixelPalette?.slice(0, 6) ?? [] }, null, 2));
}

main().catch((error) => {
  console.error(error.stack || error.message);
  process.exit(1);
});
