#!/usr/bin/env python3
"""extract-pptx.py — harvest style evidence from a .pptx deck.

This extractor reads authored OOXML rather than pixels. What a .pptx gives,
and a PDF does not, is the authored intent: named theme colours, the font scheme,
`roundRect` adjust values that state a corner radius directly, and — the part
that matters most for a corporate template — the identity of every embedded
image, so the same logo used on twenty slides is recognisably *one asset*
rather than twenty anonymous rectangles.

    python3 extract-pptx.py --input <deck.pptx> --out <evidence.json>
                            [--media <dir>] [--fonts <dir>] [--max-slides 40]

Writes the shared evidence schema documented in references/evidence-schema.md.
"""
from __future__ import annotations

import argparse
import importlib
import json
import os
import re
import subprocess
import sys
import zipfile
from collections import defaultdict

NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}
EMU_PER_PT = 12700

# Families whose glyphs are pictures, not letters. A deck that sets a run in one
# of these is drawing an icon, and the glyph name is the icon's name.
ICON_FONT_RE = re.compile(r"icon|awesome|glyph|symbol|material|ionicons|feather|bootstrap-icons", re.I)


def _lxml():
    extra = os.environ.get("PRT_PY_LIBS", "/tmp/prt-pylibs")
    if extra and extra not in sys.path:
        sys.path.insert(0, extra)
    try:
        from lxml import etree  # noqa: PLC0415
        return etree
    except ImportError:
        bootstrap = os.environ.get(
            "PRT_BOOTSTRAP",
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "bootstrap.sh"),
        )
        print(
            f"pptx helper: lxml missing; installing into {extra}",
            file=sys.stderr,
        )
        env = os.environ.copy()
        env["PRT_PY_LIBS"] = extra
        env["PRT_PYTHON_BIN"] = sys.executable
        subprocess.run(
            ["bash", bootstrap, "--pptx"],
            check=True,
            env=env,
            stdout=sys.stderr,
        )
        importlib.invalidate_caches()
        for name in list(sys.modules):
            if name == "lxml" or name.startswith("lxml."):
                del sys.modules[name]
        from lxml import etree  # noqa: PLC0415
    return etree


def parse_args():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--media", default="", help="directory to export embedded images into")
    ap.add_argument("--fonts", default="", help="directory to preserve embedded OOXML font payloads")
    ap.add_argument("--max-slides", type=int, default=40)
    return ap.parse_args()


def slide_sort_key(name: str) -> int:
    m = re.search(r"slide(\d+)\.xml$", name)
    return int(m.group(1)) if m else 0


def bounded_slides(slide_names, maximum):
    """Return (source slide number, part name), always including both ends."""
    if maximum < 2 and len(slide_names) > 1:
        raise ValueError("--max-slides must be at least 2 so cover and closing slides can both be retained")
    if len(slide_names) <= maximum:
        return list(enumerate(slide_names, start=1))
    indexes = {
        round(offset * (len(slide_names) - 1) / (maximum - 1))
        for offset in range(maximum)
    }
    return [(index + 1, slide_names[index]) for index in sorted(indexes)]


def theme_colors(etree, root):
    out = {}
    scheme = root.find(".//a:themeElements/a:clrScheme", NS)
    if scheme is None:
        return out
    for child in scheme:
        role = etree.QName(child).localname
        srgb = child.find("a:srgbClr", NS)
        sysc = child.find("a:sysClr", NS)
        if srgb is not None:
            out[role] = "#" + srgb.get("val", "").upper()
        elif sysc is not None:
            out[role] = "#" + (sysc.get("lastClr") or "000000").upper()
    return out


def theme_fonts(root):
    out = {}
    for slot in ("majorFont", "minorFont"):
        node = root.find(f".//a:themeElements/a:fontScheme/a:{slot}", NS)
        if node is None:
            continue
        latin = node.find("a:latin", NS)
        ea = node.find("a:ea", NS)
        out[slot] = {
            "latin": latin.get("typeface") if latin is not None else None,
            "ea": ea.get("typeface") if ea is not None and ea.get("typeface") else None,
        }
    return out


def package_application(etree, zf, names):
    """Read the application that last wrote the OOXML package.

    LibreOffice can legitimately render the converted deck while also replacing
    the legacy file's theme defaults. The producer is therefore provenance, not
    a reason to discard the extracted slide-local styling.
    """
    part = "docProps/app.xml"
    if part not in names:
        return None
    try:
        root = etree.fromstring(zf.read(part))
    except (KeyError, ValueError):
        return None
    for node in root.iter():
        if etree.QName(node).localname == "Application" and node.text:
            return node.text.strip()
    return None


def _alpha_of(node):
    """<a:alpha val="0"/> means fully transparent. Decks use a transparent black
    fill as an invisible hit box; treating it as a real fill paints the slide
    with big black rectangles."""
    a = node.find("a:alpha", NS)
    if a is None:
        return 1.0
    try:
        return int(a.get("val", "100000")) / 100000.0
    except (TypeError, ValueError):
        return 1.0


def resolve_color(etree, node, theme):
    """Resolve the first visible colour under `node`, following theme references."""
    if node is None:
        return None
    srgb = node.find(".//a:srgbClr", NS)
    if srgb is not None:
        if _alpha_of(srgb) < 0.06:
            return None
        return "#" + srgb.get("val", "").upper()
    sch = node.find(".//a:schemeClr", NS)
    if sch is not None:
        if _alpha_of(sch) < 0.06:
            return None
        val = sch.get("val")
        alias = {"tx1": "dk1", "tx2": "dk2", "bg1": "lt1", "bg2": "lt2"}.get(val, val)
        return theme.get(alias) or theme.get(val)
    return None


def shape_fill(etree, sp, theme):
    spPr = sp.find(".//p:spPr", NS)
    if spPr is None:
        spPr = sp.find(".//a:spPr", NS)
    if spPr is None:
        return None, None
    if spPr.find("a:noFill", NS) is not None:
        return None, None
    solid = spPr.find("a:solidFill", NS)
    fill = resolve_color(etree, solid, theme) if solid is not None else None
    grad = spPr.find("a:gradFill", NS)
    if fill is None and grad is not None:
        stops = [resolve_color(etree, gs, theme) for gs in grad.findall(".//a:gs", NS)]
        fill = next((s for s in stops if s), None)
    line = spPr.find("a:ln", NS)
    stroke = resolve_color(etree, line, theme) if line is not None else None
    return fill, stroke


def geometry(spPr, w_emu, h_emu):
    """prstGeom / custGeom → (kind, radius_emu | None, adj values, path data)."""
    if spPr is None:
        return "unknown", None, {}, None
    prst = spPr.find("a:prstGeom", NS)
    if prst is not None:
        kind = prst.get("prst")
        adj = {gd.get("name"): gd.get("fmla", "") for gd in prst.findall(".//a:gd", NS)}
        radius = None
        if kind in ("roundRect", "round2SameRect", "round2DiagRect", "round1Rect", "snipRoundRect"):
            raw = adj.get("adj") or adj.get("adj1") or ""
            m = re.search(r"val\s+(-?\d+)", raw)
            frac = (int(m.group(1)) if m else 16667) / 100000.0
            radius = min(w_emu, h_emu) * frac
        elif kind == "ellipse":
            radius = min(w_emu, h_emu) / 2.0
        return kind, radius, adj, None
    cust = spPr.find("a:custGeom", NS)
    if cust is not None:
        # A custGeom is a drawn icon. Keep enough of the path to redraw it.
        pts = []
        for path in cust.findall(".//a:path", NS):
            pw = int(path.get("w") or 0)
            ph = int(path.get("h") or 0)
            cmds = []
            for node in path:
                tag = node.tag.split("}")[-1]
                coords = [(int(p.get("x")), int(p.get("y")))
                          for p in node.findall("a:pt", NS)]
                cmds.append({"op": tag, "pts": coords})
            pts.append({"w": pw, "h": ph, "cmds": cmds[:60]})
        return "custGeom", None, {}, pts[:4]
    return "unknown", None, {}, None


def run_props(etree, r, theme):
    rPr = r.find("a:rPr", NS)
    txt = r.find("a:t", NS)
    text = txt.text if txt is not None and txt.text else ""
    if not text.strip():
        return None
    size_pt = weight = family = color = spacing = caps = None
    if rPr is not None:
        if rPr.get("sz"):
            size_pt = int(rPr.get("sz")) / 100.0
        weight = "bold" if rPr.get("b") == "1" else None
        latin = rPr.find("a:latin", NS)
        if latin is not None:
            family = latin.get("typeface")
        solid = rPr.find("a:solidFill", NS)
        color = resolve_color(etree, solid, theme) if solid is not None else None
        if rPr.get("spc"):
            spacing = int(rPr.get("spc")) / 100.0
        caps = rPr.get("cap")
    return {
        "text": text[:160],
        "family": family,
        "sizePt": size_pt,
        "weight": weight,
        "color": color,
        "letterSpacingPt": spacing,
        "caps": caps,
        # An icon font run is a picture with a name, not a word. Marking it here
        # is what lets the template keep the icon instead of dropping it.
        "iconFont": bool(family and ICON_FONT_RE.search(family)),
        "glyph": text.strip() if family and ICON_FONT_RE.search(family) else None,
    }


def rels_of(etree, zf, names, part):
    """Relationship map for one package part."""
    rel = f"{os.path.dirname(part)}/_rels/{os.path.basename(part)}.rels"
    if rel not in names:
        return {}
    return {r.get("Id"): r.get("Target", "") for r in etree.fromstring(zf.read(rel))}


def resolve_part(base_part, target):
    """Resolve a rels Target (which is relative to the part's folder)."""
    if target.startswith("/"):
        return target.lstrip("/")
    return os.path.normpath(os.path.join(os.path.dirname(base_part), target)).replace("\\", "/")


def safe_name(value: str) -> str:
    clean = re.sub(r"[^A-Za-z0-9._-]+", "-", value or "font").strip("-.")
    return clean or "font"


def embedded_fonts(etree, zf, names, presentation, out_dir):
    """Preserve embedded font payloads without claiming they are installable.

    OOXML stores embedded fonts as obfuscated ``.fntdata`` parts. Keeping those
    bytes is useful provenance, but de-obfuscation and licensing decisions are
    deliberately outside extraction.
    """
    rels = rels_of(etree, zf, names, "ppt/presentation.xml")
    result = []
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    rid_attr = "{%s}id" % NS["r"]
    for font_index, embedded in enumerate(presentation.findall(".//p:embeddedFont", NS), start=1):
        font = embedded.find("p:font", NS)
        family = font.get("typeface") if font is not None else None
        for style in ("regular", "bold", "italic", "boldItalic"):
            style_node = embedded.find(f"p:{style}", NS)
            rid = style_node.get(rid_attr) if style_node is not None else None
            target = rels.get(rid, "") if rid else ""
            part = resolve_part("ppt/presentation.xml", target) if target else None
            if not part or part not in names:
                continue
            exported = None
            if out_dir:
                filename = f"{safe_name(family or 'font')}-{style}-{font_index}.fntdata"
                exported = os.path.abspath(os.path.join(out_dir, filename))
                with open(exported, "wb") as fh:
                    fh.write(zf.read(part))
            result.append({
                "family": family,
                "style": style,
                "part": part,
                "file": exported,
                "format": "ooxml-obfuscated-font",
                "directlyUsable": False,
                "note": "original OOXML payload preserved; installability and licensing are not inferred",
            })
    return result


def paragraph_line_height(ppr, size_pt):
    if ppr is None:
        return None
    spacing = ppr.find("a:lnSpc", NS)
    if spacing is None:
        return None
    percent = spacing.find("a:spcPct", NS)
    if percent is not None and percent.get("val"):
        return round(int(percent.get("val")) / 100000.0, 3)
    points = spacing.find("a:spcPts", NS)
    if points is not None and points.get("val") and size_pt:
        return round((int(points.get("val")) / 100.0) / size_pt, 3)
    return None


def inheritance_chain(etree, zf, names, slide_part):
    """slide -> layout -> master.

    A corporate template puts its logo and its branded background on the master,
    because that is what a master is for. Reading only ppt/slides/*.xml sees a
    blank white deck and reports zero assets — which is exactly the failure this
    function exists to prevent.
    """
    chain = []
    layout = None
    for rid, target in rels_of(etree, zf, names, slide_part).items():
        if "slideLayout" in target:
            layout = resolve_part(slide_part, target)
            break
    if layout and layout in names:
        chain.append(layout)
        for rid, target in rels_of(etree, zf, names, layout).items():
            if "slideMaster" in target:
                master = resolve_part(layout, target)
                if master in names:
                    chain.append(master)
                break
    return chain


def main():
    args = parse_args()
    etree = _lxml()
    zf = zipfile.ZipFile(args.input)
    names = zf.namelist()
    application = package_application(etree, zf, names)
    theme_fallback_allowed = not bool(application and re.search(r"LibreOffice", application, re.I))

    pres = etree.fromstring(zf.read("ppt/presentation.xml"))
    sld_sz = pres.find("p:sldSz", NS)
    w_emu = int(sld_sz.get("cx")) if sld_sz is not None else 12192000
    h_emu = int(sld_sz.get("cy")) if sld_sz is not None else 6858000

    theme_name = next((n for n in names if n.startswith("ppt/theme/theme")), None)
    theme_root = etree.fromstring(zf.read(theme_name)) if theme_name else None
    theme = theme_colors(etree, theme_root) if theme_root is not None else {}
    fonts = theme_fonts(theme_root) if theme_root is not None else {}
    preserved_fonts = embedded_fonts(etree, zf, names, pres, args.fonts)

    slide_names = sorted([n for n in names if re.match(r"ppt/slides/slide\d+\.xml$", n)],
                         key=slide_sort_key)
    selected_slides = bounded_slides(slide_names, args.max_slides)
    slides = []
    pct_w = lambda v: round(v / w_emu * 10000) / 100  # noqa: E731
    pct_h = lambda v: round(v / h_emu * 10000) / 100  # noqa: E731

    if args.media:
        os.makedirs(args.media, exist_ok=True)
    exported = {}          # zip part -> path on disk
    asset_uses = defaultdict(list)   # asset id -> [{slide, box}]

    def export_image(part):
        """Export once, keyed by the *zip part*, so the same logo on twenty
        slides stays one asset with one id."""
        if part in exported:
            return exported[part]
        if not args.media:
            exported[part] = part
            return part
        dst = os.path.join(args.media, os.path.basename(part))
        with open(dst, "wb") as fh:
            fh.write(zf.read(part))
        exported[part] = dst
        return dst

    for idx, name in selected_slides:
        root = etree.fromstring(zf.read(name))
        text, shapes, frames = [], [], []
        color_area = defaultdict(float)

        rel_name = f"ppt/slides/_rels/{os.path.basename(name)}.rels"
        rel_map = {}
        if rel_name in names:
            for rel in etree.fromstring(zf.read(rel_name)):
                rel_map[rel.get("Id")] = rel.get("Target", "")

        # The identity layer is inherited: background fill, background picture,
        # and any non-placeholder shape sitting on the layout or the master.
        chain = inheritance_chain(etree, zf, names, name)
        inherited_roots = []
        for part in chain:
            try:
                inherited_roots.append((part, etree.fromstring(zf.read(part))))
            except KeyError:
                continue

        bg = root.find(".//p:bg", NS)
        bg_owner = name
        for part, croot in inherited_roots:
            if bg is not None:
                break
            found = croot.find(".//p:bg", NS)
            if found is not None:
                bg, bg_owner = found, part
        bg_color = resolve_color(etree, bg, theme) if bg is not None else None
        if bg_color:
            color_area[bg_color] += 1.0

        # a background can also be a picture rather than a fill
        bg_image = None
        if bg is not None:
            blip = bg.find(".//a:blip", NS)
            embed = blip.get("{%s}embed" % NS["r"]) if blip is not None else None
            if embed:
                target = rels_of(etree, zf, names, bg_owner).get(embed, "")
                part = resolve_part(bg_owner, target) if target else None
                if part and part in names:
                    bg_image = export_image(part)
                    asset_uses[os.path.basename(part)].append(
                        {"slide": idx, "box": {"x": 0, "y": 0, "w": 100, "h": 100}})

        # non-placeholder shapes from layout and master, outermost first
        for part, croot in reversed(inherited_roots):
            part_rels = rels_of(etree, zf, names, part)
            for sp in croot.iter():
                tag = etree.QName(sp).localname
                if tag not in ("sp", "pic"):
                    continue
                if sp.find(".//p:ph", NS) is not None:
                    continue          # a placeholder is a content slot, not identity
                asset_id = image_path = None
                if tag == "pic":
                    blip = sp.find(".//a:blip", NS)
                    embed = blip.get("{%s}embed" % NS["r"]) if blip is not None else None
                    target = part_rels.get(embed, "") if embed else ""
                    ipart = resolve_part(part, target) if target else None
                    if ipart and ipart in names:
                        asset_id = os.path.basename(ipart)
                        image_path = export_image(ipart)
                xfrm = sp.find(".//a:xfrm", NS)
                off = xfrm.find("a:off", NS) if xfrm is not None else None
                ext = xfrm.find("a:ext", NS) if xfrm is not None else None
                x = int(off.get("x")) if off is not None else 0
                y = int(off.get("y")) if off is not None else 0
                cx = int(ext.get("cx")) if ext is not None else w_emu
                cy = int(ext.get("cy")) if ext is not None else h_emu
                box = {"x": pct_w(x), "y": pct_h(y), "w": pct_w(cx), "h": pct_h(cy)}
                spPr = sp.find(".//p:spPr", NS)
                kind, radius_emu, adj, path = geometry(spPr, cx, cy)
                fill, stroke = shape_fill(etree, sp, theme)
                if asset_id:
                    asset_uses[asset_id].append({"slide": idx, "box": box})
                shapes.append({
                    "role": "media" if tag == "pic" else "vector",
                    "assetId": asset_id,
                    "image": image_path,
                    "inherited": "master" if "slideMaster" in part else "layout",
                    "kind": kind,
                    "paint": "fill" if fill else ("stroke" if stroke else "none"),
                    "color": fill,
                    "stroke": stroke,
                    "rotation": 0,
                    "box": box,
                    "area": round((cx * cy) / float(w_emu * h_emu), 4) if w_emu and h_emu else 0,
                    "radiiEmu": [radius_emu] if radius_emu else [],
                    "radiiCqw": [round(radius_emu / w_emu * 10000) / 100] if radius_emu else [],
                    "pill": False,
                    "adj": adj,
                    "path": path,
                })

        for sp in root.iter():
            tag = etree.QName(sp).localname
            if tag not in ("sp", "pic", "graphicFrame", "cxnSp"):
                continue

            asset_id = image_path = None
            if tag == "pic":
                blip = sp.find(".//a:blip", NS)
                embed = blip.get("{%s}embed" % NS["r"]) if blip is not None else None
                target = rel_map.get(embed, "") if embed else ""
                if target:
                    part = "ppt/" + target.replace("../", "")
                    if part in names:
                        asset_id = os.path.basename(part)
                        image_path = export_image(part)

            xfrm = sp.find(".//a:xfrm", NS)
            off = xfrm.find("a:off", NS) if xfrm is not None else None
            ext = xfrm.find("a:ext", NS) if xfrm is not None else None
            x = int(off.get("x")) if off is not None else 0
            y = int(off.get("y")) if off is not None else 0
            cx = int(ext.get("cx")) if ext is not None else 0
            cy = int(ext.get("cy")) if ext is not None else 0
            rot = int(xfrm.get("rot") or 0) / 60000.0 if xfrm is not None else 0
            box = {"x": pct_w(x), "y": pct_h(y), "w": pct_w(cx), "h": pct_h(cy)}
            area = (cx * cy) / float(w_emu * h_emu) if w_emu and h_emu else 0

            if asset_id:
                asset_uses[asset_id].append({"slide": idx, "box": box})

            spPr = sp.find(".//p:spPr", NS)
            kind, radius_emu, adj, path = geometry(spPr, cx, cy)
            fill, stroke = shape_fill(etree, sp, theme)
            if fill and area > 0.0002:
                color_area[fill] += area

            shapes.append({
                "role": "media" if tag == "pic" else "vector",
                "assetId": asset_id,
                "image": image_path,
                "kind": kind,
                "paint": "fill" if fill else ("stroke" if stroke else "none"),
                "color": fill,
                "stroke": stroke,
                "rotation": round(rot, 2),
                "box": box,
                "area": round(area, 4),
                "radiiEmu": [radius_emu] if radius_emu else [],
                "radiiCqw": [round(radius_emu / w_emu * 10000) / 100] if radius_emu else [],
                "pill": bool(radius_emu and cy
                             and abs(radius_emu - min(cx, cy) / 2) < min(cx, cy) * 0.06
                             and kind == "roundRect"),
                "adj": adj,
                "path": path,
            })

            body = sp.find(".//p:txBody", NS)
            paragraphs = []
            for para in (body.findall("a:p", NS) if body is not None else []):
                pPr = para.find("a:pPr", NS)
                default = pPr.find("a:defRPr", NS) if pPr is not None else None
                runs = []
                for r in para.findall("a:r", NS):
                    item = run_props(etree, r, theme)
                    if not item:
                        continue
                    if item["sizePt"] is None and default is not None and default.get("sz"):
                        item["sizePt"] = int(default.get("sz")) / 100.0
                    if item["weight"] is None and default is not None and default.get("b") == "1":
                        item["weight"] = "bold"
                    if item["family"] is None and default is not None:
                        default_latin = default.find("a:latin", NS)
                        if default_latin is not None:
                            item["family"] = default_latin.get("typeface")
                    if item["letterSpacingPt"] is None and default is not None and default.get("spc"):
                        item["letterSpacingPt"] = int(default.get("spc")) / 100.0
                    item["lineHeight"] = paragraph_line_height(pPr, item["sizePt"])
                    item["sizeCqw"] = (round(item["sizePt"] * EMU_PER_PT / w_emu * 10000) / 100
                                       if item["sizePt"] else None)
                    runs.append(item)
                    flat = dict(item)
                    flat["box"] = box
                    text.append(flat)
                    if item["color"]:
                        # A text colour is ink, not paint. Weighting it by the area
                        # of its frame lets a body placeholder — which spans the
                        # slide — outrank every real fill, and the generated
                        # image layer becomes a wall of body-text grey.
                        color_area[item["color"]] += 0.004
                if runs:
                    paragraphs.append({
                        "align": (pPr.get("algn") if pPr is not None else None) or "l",
                        "runs": runs,
                    })
            if paragraphs:
                bodyPr = body.find("a:bodyPr", NS) if body is not None else None
                frames.append({
                    "box": box,
                    "anchor": (bodyPr.get("anchor") if bodyPr is not None else None) or "t",
                    "paragraphs": paragraphs,
                })

        slides.append({
            "index": idx,
            "stage": {"w": round(w_emu / EMU_PER_PT), "h": round(h_emu / EMU_PER_PT)},
            "stageBg": bg_color,
            "stageImage": bg_image,
            "text": text,
            "textFrames": frames,
            "shapes": shapes,
            "colorArea": dict(color_area),
        })

    evidence = {
        "schema": "presentation-evidence/2",
        "source": {
            "kind": "pptx",
            "path": os.path.abspath(args.input),
            "slideCount": len(slides),
            "slidesInFile": len(slide_names),
            "truncated": len(slides) < len(slide_names),
            "stage": {"w": round(w_emu / EMU_PER_PT), "h": round(h_emu / EMU_PER_PT)},
            "aspect": round(w_emu / h_emu, 4) if h_emu else None,
            "rendered": False,
            "application": application,
            "renderNote": "this extractor records authored OOXML structure; render separately when pixel evidence is needed",
        },
        "root": {
            "themeColors": theme,
            "themeFonts": fonts,
            "themeProvenance": {
                "application": application,
                "usableAsDesignFallback": theme_fallback_allowed,
                "note": (
                    "LibreOffice-authored OOXML may contain rewritten theme defaults; preserve the declarations as provenance but prefer observed slide-local fonts and colours"
                    if not theme_fallback_allowed
                    else "theme declarations came from the supplied OOXML package"
                ),
            },
            "cssVars": {},
            "fontLinks": [],
            "embeddedFonts": preserved_fonts,
        },
        "assets": [
            {
                "id": asset_id,
                "file": exported.get("ppt/media/" + asset_id, None) or exported.get(asset_id),
                "uses": len(uses),
                "slides": sorted({u["slide"] for u in uses}),
                "boxes": [u["box"] for u in uses],
            }
            for asset_id, uses in sorted(asset_uses.items(), key=lambda kv: -len(kv[1]))
        ],
        "slides": slides,
    }
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(evidence, fh, indent=2, ensure_ascii=False)
    print(json.dumps({"out": args.out, "slides": len(slides),
                      "slidesInFile": len(slide_names), "assets": len(evidence["assets"]),
                      "embeddedFonts": len(preserved_fonts),
                      "themeFallbackAllowed": theme_fallback_allowed}))


if __name__ == "__main__":
    main()
