#!/usr/bin/env node
/**
 * reconstruct.mjs — turn extracted evidence back into pixels.
 *
 * Extracted shape boxes, fills, radii, images, and text runs can be rebuilt as
 * HTML and screenshotted. Two uses:
 *
 *   1. it gives every input format one comparable evidence view;
 *   2. the reconstruction doubles as an extraction self-check — whatever is
 *      missing from the picture is exactly what the extractor failed to read.
 *
 * For an image-only deck (every slide one full-bleed picture, which is what AI
 * slide generators emit) the reconstruction is pixel-faithful.
 *
 *   node reconstruct.mjs --evidence <evidence.json> --out <dir> [--shot] [--sheet]
 *                        [--max 40] [--cols 3] [--exclude-assets assets.json]
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import path from "node:path";
import { pathToFileURL } from "node:url";

const execFileAsync = promisify(execFile);
const BROWSER = process.env.AGENT_BROWSER_BIN ?? "agent-browser";

function parseArgs(argv) {
  const args = { evidence: "", out: "", shot: false, sheet: false, max: 40, cols: 3, noText: false, excludeAssets: "" };
  for (let i = 2; i < argv.length; i += 1) {
    const a = argv[i], next = argv[i + 1];
    if (a === "--evidence") { args.evidence = next; i += 1; }
    else if (a === "--out") { args.out = next; i += 1; }
    else if (a === "--max") { args.max = Number(next); i += 1; }
    else if (a === "--cols") { args.cols = Number(next); i += 1; }
    else if (a === "--exclude-assets") { args.excludeAssets = next; i += 1; }
    else if (a === "--no-text") args.noText = true;
    else if (a === "--shot") args.shot = true;
    else if (a === "--sheet") { args.sheet = true; args.shot = true; }
    else if (a === "--help" || a === "-h") { usage(); process.exit(0); }
    else throw new Error(`Unknown argument: ${a}`);
  }
  if (!args.evidence || !args.out) { usage(); process.exit(1); }
  if (!Number.isFinite(args.max) || args.max < 2) throw new Error("--max must be at least 2 so cover and closing slides can both be retained");
  return args;
}

function usage() {
  console.log(`Usage: node reconstruct.mjs --evidence <evidence.json> --out <dir>
                            [--shot] [--sheet] [--max 40] [--cols 3]
                            [--exclude-assets <assets.json>]

  --shot     screenshot each rebuilt slide to <dir>/slide-NN.png
  --sheet    also build <dir>/contact-sheet.png (implies --shot)
  --no-text  render the shell only — no text at all. What survives is the
             template's image layer: ground, background art, logo, chrome.
  --exclude-assets
             omit image candidates suggested as one-off content. Suggestions
             remain advisory; review the rendered backgrounds before reuse.`);
}

const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
// JSON.stringify would emit double quotes, which terminate the style="..." attribute
const fontStack = (family) => (family ? `'${String(family).replace(/'/g, "")}',` : "");

function excludedAssetKeys(file) {
  if (!file) return new Set();
  const report = JSON.parse(readFileSync(file, "utf8"));
  const keys = new Set();
  for (const asset of report.contentCandidates || []) {
    for (const value of [asset.id, asset.file, asset.staged, ...(asset.ids || [])]) {
      if (!value) continue;
      keys.add(String(value));
      keys.add(path.basename(String(value)));
    }
  }
  return keys;
}

function isExcluded(shape, keys) {
  if (!keys.size) return false;
  return [shape.assetId, shape.image].filter(Boolean).some((value) =>
    keys.has(String(value)) || keys.has(path.basename(String(value))));
}

function shapeHtml(shape, omitMissingMedia = false) {
  const b = shape.box || {};
  if (!(b.w > 0.05) || !(b.h > 0.05)) return "";
  const radius = shape.pill
    ? "999px"
    : (shape.radiiCqw && shape.radiiCqw.length
      ? (shape.kind === "ellipse" || shape.kind === "circle" ? "50%" : `${shape.radiiCqw[0]}cqw`)
      : "0");
  const pos = `position:absolute;left:${b.x}%;top:${b.y}%;width:${b.w}%;height:${b.h}%`;
  const rot = shape.rotation ? `;transform:rotate(${shape.rotation}deg)` : "";
  if (shape.image && existsSync(shape.image)) {
    const url = pathToFileURL(path.resolve(shape.image)).href;
    return `<div style="${pos};background-image:url('${url}');background-size:100% 100%;background-position:center;border-radius:${radius};overflow:hidden${rot}"></div>`;
  }
  if (shape.role === "media") {
    if (omitMissingMedia) return "";
    return `<div style="${pos};background:#DDD;border:1px dashed #999;border-radius:${radius}${rot}"></div>`;
  }
  if (!shape.color && !shape.stroke) return "";
  const fill = shape.color ? `background:${shape.color}` : "background:transparent";
  const border = shape.stroke && !shape.color
    ? `;border:${Math.max(1, Math.round(shape.lineWidth || 1))}px solid ${shape.stroke}` : "";
  return `<div style="${pos};${fill};border-radius:${radius}${border}${rot}"></div>`;
}

function textHtml(item, stageW) {
  const b = item.box || {};
  const size = item.sizeCqw ?? (item.sizePt ? (item.sizePt / stageW) * 100 : null);
  if (!size) return "";
  return `<div style="position:absolute;left:${b.x}%;top:${b.y}%;max-width:${Math.max(b.w || 20, 6)}%;`
    + `font-family:${fontStack(item.family)}system-ui,sans-serif;font-size:${size}cqw;`
    + `font-weight:${item.weight === "bold" ? 700 : 400};color:${item.color || "#111"};`
    + `line-height:1.2;white-space:pre-wrap">${esc(item.text)}</div>`;
}

const ALIGN = { l: "left", ctr: "center", r: "right", just: "justify" };
const ANCHOR = { t: "flex-start", ctr: "center", b: "flex-end" };

/** Keep a bounded but deck-wide sample. Taking only the first N pages silently
 *  drops the closing template variant on every longer deck. */
function selectSlides(slides, max) {
  const limit = Math.floor(max);
  if (slides.length <= limit) return slides;
  const selected = [];
  const indexes = new Set();
  for (let offset = 0; offset < limit; offset += 1) {
    indexes.add(Math.round((offset * (slides.length - 1)) / (limit - 1)));
  }
  for (const index of [...indexes].sort((left, right) => left - right)) selected.push(slides[index]);
  return selected;
}

/** A text frame lays its paragraphs out in flow, the way the source app did. */
function frameHtml(frame, stageW) {
  const b = frame.box || {};
  const paras = (frame.paragraphs || []).map((p) => {
    const runs = p.runs.map((r) => {
      const size = r.sizeCqw ?? (r.sizePt ? (r.sizePt / stageW) * 100 : 1.4);
      const caps = r.caps === "all" ? ";text-transform:uppercase" : "";
      const track = r.letterSpacingPt ? `;letter-spacing:${(r.letterSpacingPt / stageW) * 100}cqw` : "";
      return `<span style="font-family:${fontStack(r.family)}system-ui,sans-serif;font-size:${size}cqw;`
        + `font-weight:${r.weight === "bold" ? 700 : 400};color:${r.color || "#111"}${caps}${track}">${esc(r.text)}</span>`;
    }).join("");
    return `<p style="margin:0;text-align:${ALIGN[p.align] || "left"};line-height:1.25">${runs}</p>`;
  }).join("");
  return `<div style="position:absolute;left:${b.x}%;top:${b.y}%;width:${b.w}%;height:${b.h}%;`
    + `display:flex;flex-direction:column;justify-content:${ANCHOR[frame.anchor] || "flex-start"};`
    + `overflow:hidden">${paras}</div>`;
}

function slideHtml(slide, stageW, bgFallback, noText, excluded) {
  const bg = slide.stageBg || bgFallback || "#FFFFFF";
  const stageImage = slide.stageImage && existsSync(slide.stageImage)
    ? `;background-image:url('${pathToFileURL(path.resolve(slide.stageImage)).href}');background-size:100% 100%;background-position:center`
    : "";
  const shapes = (slide.shapes || [])
    .filter((shape) => !isExcluded(shape, excluded))
    .map((shape) => shapeHtml(shape, noText))
    .join("\n");
  const text = noText ? "" : (slide.textFrames?.length
    ? slide.textFrames.map((f) => frameHtml(f, stageW)).join("\n")
    : (slide.text || []).map((t) => textHtml(t, stageW)).join("\n"));
  return `<section class="slide"><div class="stage" style="background-color:${bg}${stageImage}">\n${shapes}\n${text}\n</div></section>`;
}

async function browser(args) {
  return (await execFileAsync(BROWSER, args, { maxBuffer: 64 * 1024 * 1024 })).stdout;
}

async function main() {
  const args = parseArgs(process.argv);
  const evidence = JSON.parse(readFileSync(args.evidence, "utf8"));
  const excluded = excludedAssetKeys(args.excludeAssets);
  const stageW = evidence.source?.stage?.w || 960;
  const stageH = evidence.source?.stage?.h || Math.round(stageW * 9 / 16);
  const aspect = stageW / stageH;
  // agent-browser resolves paths against its own cwd, so keep everything absolute
  const outDir = path.resolve(args.out);
  mkdirSync(outDir, { recursive: true });

  const slides = selectSlides(evidence.slides, args.max);
  const sourceSlideCount = evidence.source?.slidesInFile || evidence.source?.pagesInFile
    || evidence.source?.slideCount || evidence.slides.length;
  // The ground is whatever was *painted*, not whatever colour appears most in the
  // census: a body text colour sits inside a full-slide placeholder, so weighting
  // it by that box would make a white deck reconstruct as a grey one.
  const bgVotes = {};
  for (const s of slides) if (s.stageBg) bgVotes[s.stageBg] = (bgVotes[s.stageBg] || 0) + 1;
  const fillTotals = {};
  for (const s of slides) {
    for (const sh of s.shapes || []) {
      if (!sh.color || sh.paint === "none") continue;
      const b = sh.box || {};
      fillTotals[sh.color] = (fillTotals[sh.color] || 0) + ((b.w || 0) * (b.h || 0)) / 10000;
    }
  }
  const bgFallback = Object.entries(bgVotes).sort((a, b) => b[1] - a[1])[0]?.[0]
    ?? Object.entries(fillTotals).sort((a, b) => b[1] - a[1])[0]?.[0]
    ?? "#FFFFFF";

  const doc = `<!doctype html><html><head><meta charset="utf-8"><title>reconstruction</title><style>
*{box-sizing:border-box;margin:0}
body{background:#222}
.slide{width:100vw;height:100vh;display:flex}
.stage{position:relative;width:min(100vw,${(aspect * 100).toFixed(4)}vh);height:min(${(100 / aspect).toFixed(4)}vw,100vh);margin:auto;container-type:size;overflow:hidden}
</style></head><body>
${slides.map((s) => slideHtml(s, stageW, bgFallback, args.noText, excluded)).join("\n")}
</body></html>`;
  const htmlPath = path.join(outDir, "reconstruction.html");
  writeFileSync(htmlPath, doc);

  const result = {
    html: htmlPath,
    slides: slides.length,
    sourceSlideCount,
    selectedSlides: slides.map((slide, index) => slide.index || index + 1),
    shots: [],
    sheet: null,
    excludedAssetKeys: excluded.size,
  };

  if (args.shot) {
    // Shoot at the deck's own ratio. A letterboxed shot puts the page background
    // into every frame, and the shell pass would then report the letterbox as
    // the template's ground colour.
    const shotW = 1280;
    const shotH = Math.round(shotW / aspect);
    await browser(["set", "viewport", String(shotW), String(shotH)]);
    await browser(["open", pathToFileURL(htmlPath).href]);
    await browser(["wait", "500"]);
    for (let i = 0; i < slides.length; i += 1) {
      const css = `.slide{display:none!important}.slide:nth-of-type(${i + 1}){display:flex!important}`;
      await browser(["eval", `(()=>{let e=document.getElementById('only');if(!e){e=document.createElement('style');e.id='only';document.head.appendChild(e);}e.textContent=${JSON.stringify(css)};return 'ok'})()`]);
      await browser(["wait", "160"]);
      const slideNumber = slides[i].index || i + 1;
      const shot = path.join(outDir, `slide-${String(slideNumber).padStart(3, "0")}.png`);
      await browser(["screenshot", shot]);
      result.shots.push(shot);
      process.stderr.write(`shot ${i + 1}/${slides.length}\r`);
    }
    process.stderr.write("\n");
  }

  if (args.sheet && result.shots.length) {
    const cards = result.shots.map((p, i) =>
      `<figure><img src="${pathToFileURL(p).href}"><figcaption>${String(result.selectedSlides[i]).padStart(3, "0")}</figcaption></figure>`).join("\n");
    const sheetHtml = `<!doctype html><meta charset="utf-8"><style>
body{margin:0;padding:16px;background:#f4f4f2;font:12px/1.3 system-ui,sans-serif}
.grid{display:grid;grid-template-columns:repeat(${args.cols},1fr);gap:12px}
figure{margin:0;background:#fff;border:1px solid #ddd;padding:6px}
img{display:block;width:100%;aspect-ratio:${stageW}/${stageH};object-fit:cover}
figcaption{margin-top:4px;color:#555}
</style><div class="grid">${cards}</div>`;
    const sheetPath = path.join(outDir, "contact-sheet.html");
    writeFileSync(sheetPath, sheetHtml);
    const rows = Math.ceil(result.shots.length / args.cols);
    await browser(["set", "viewport", "1600", String(Math.min(9000, 120 + rows * 340))]);
    await browser(["open", pathToFileURL(sheetPath).href]);
    await browser(["wait", "700"]);
    const sheetPng = path.join(outDir, "contact-sheet.png");
    await browser(["screenshot", sheetPng, "--full"]);
    result.sheet = sheetPng;
  }

  const manifestPath = path.join(outDir, "background-manifest.json");
  writeFileSync(manifestPath, JSON.stringify({
    schema: "presentation-background-render/1",
    sourceSlideCount,
    selectedSlides: result.shots.map((file, index) => ({
      slide: result.selectedSlides[index],
      file: path.basename(file),
    })),
  }, null, 2));
  result.manifest = manifestPath;

  console.log(JSON.stringify(result));
}

main().catch((error) => {
  console.error(error.stack || error.message);
  process.exit(1);
});
