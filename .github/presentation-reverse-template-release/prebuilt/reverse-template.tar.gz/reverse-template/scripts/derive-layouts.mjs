#!/usr/bin/env node
/**
 * derive-layouts.mjs — cluster source blocks into layout candidates.
 *
 * The output records measured columns, bands, media roles, panels, and source
 * frequency. Clusters are advisory and may be merged, split, renamed, or rejected
 * after visual review.
 *
 *   node derive-layouts.mjs --evidence work/evidence.json --out work/layouts.json
 */
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";

function parseArgs(argv) {
  const args = { evidence: "", out: "", minShare: 0.08 };
  for (let i = 2; i < argv.length; i += 1) {
    const a = argv[i], next = argv[i + 1];
    if (a === "--evidence") { args.evidence = next; i += 1; }
    else if (a === "--out") { args.out = next; i += 1; }
    else if (a === "--min-share") { args.minShare = Number(next); i += 1; }
    else if (a === "--help" || a === "-h") { usage(); process.exit(0); }
    else throw new Error(`Unknown argument: ${a}`);
  }
  if (!args.evidence || !args.out) { usage(); process.exit(1); }
  return args;
}

function usage() {
  console.log(`Usage: node derive-layouts.mjs --evidence <evidence.json> --out <layouts.json> [--min-share 0.08]`);
}

const r1 = (v) => Math.round(v * 10) / 10;
const median = (xs) => {
  if (!xs.length) return 0;
  const s = [...xs].sort((a, b) => a - b);
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};

/**
 * Pictures and colour panels occupy columns too. Projecting text alone reports
 * "one column" for the commonest slide in any deck — a picture on one side and a
 * paragraph on the other — and then generated content spreads across the
 * whole stage and lands it on top of where the picture should be.
 */
function mediaBlocksOf(slide) {
  const out = [];
  for (const sh of slide.shapes || []) {
    const b = sh.box;
    if (!b || !(b.w >= 6) || !(b.h >= 6)) continue;
    if (b.w >= 95 && b.h >= 95) continue;          // a full-bleed ground is not a column
    // A table frame or a header band spans the content width; it is the container
    // the columns sit in, not one of them.
    if (b.w >= 60) continue;
    const isMedia = sh.role === "media";
    const isPanel = sh.role !== "media" && (sh.color || sh.bg) && b.w >= 8 && b.h >= 8;
    if (!isMedia && !isPanel) continue;
    out.push({ box: b, size: 0, chars: 0, text: "", media: true, panel: !isMedia });
  }
  return out;
}

/** Text blocks with a box, whichever way the extractor recorded them. */
function blocksOf(slide) {
  if (slide.textFrames?.length) {
    return slide.textFrames
      .filter((f) => f.box && (f.paragraphs || []).some((p) => (p.runs || []).some((r) => (r.text || "").trim())))
      .map((f) => {
        const runs = (f.paragraphs || []).flatMap((p) => p.runs || []);
        const chars = runs.reduce((n, r) => n + (r.text || "").trim().length, 0);
        return {
          box: f.box,
          size: Math.max(0, ...runs.map((r) => r.sizeCqw || 0)),
          chars,
          text: runs.map((r) => r.text || "").join(" ").trim(),
        };
      });
  }
  // Fall back to loose runs, merged when they share a box.
  const byBox = new Map();
  for (const t of slide.text || []) {
    if (!t.box || !(t.text || "").trim()) continue;
    const k = `${Math.round(t.box.x)}|${Math.round(t.box.y)}|${Math.round(t.box.w)}`;
    if (!byBox.has(k)) byBox.set(k, { box: t.box, size: 0, chars: 0, text: "" });
    const b = byBox.get(k);
    b.size = Math.max(b.size, t.sizeCqw || 0);
    b.chars += t.text.trim().length;
    b.text = `${b.text} ${t.text}`.trim();
  }
  return [...byBox.values()];
}

function isChromeCandidate(block, titleSize) {
  const b = block.box;
  const topFurniture = b.y + b.h <= 12;
  const bottomFurniture = b.y >= 88;
  const furnitureScale = block.size <= Math.max(1.5, titleSize * 0.45) || b.w <= 20;
  return (topFurniture || bottomFurniture) && (bottomFurniture || furnitureScale);
}

function geometryNear(a, b, tolerance = 2) {
  return ["x", "y", "w", "h"].every((key) =>
    Math.abs((a.box[key] || 0) - (b.box[key] || 0)) <= tolerance);
}

/**
 * Find running furniture before classifying slide content.
 *
 * Text is allowed to change (page counters do), so recurrence is based on
 * geometry rather than literal content. The outer-band and scale/measure gates
 * keep ordinary titles that share a template position in the content model.
 */
function repeatedChromePatterns(blocksBySlide, titleSize) {
  if (blocksBySlide.length < 2) return [];
  const patterns = [];
  blocksBySlide.forEach((blocks, slideIndex) => {
    for (const block of blocks) {
      if (!isChromeCandidate(block, titleSize)) continue;
      const hit = patterns.find((pattern) => !pattern.slides.has(slideIndex)
        && geometryNear(pattern.center, block));
      if (hit) {
        hit.samples.push(block);
        hit.slides.add(slideIndex);
        hit.center = {
          box: Object.fromEntries(["x", "y", "w", "h"].map((key) =>
            [key, median(hit.samples.map((sample) => sample.box[key] || 0))])),
        };
      } else {
        patterns.push({ center: block, samples: [block], slides: new Set([slideIndex]) });
      }
    }
  });
  const minimum = Math.max(2, Math.ceil(blocksBySlide.length * 0.6));
  return patterns.filter((pattern) => pattern.slides.size >= minimum);
}

function isDecorativeTextBlock(block) {
  const text = (block.text || "").trim();
  return text && [...text].length <= 2 && !/[\p{L}\p{N}]/u.test(text);
}

/** Split blocks into horizontal bands: a band is a set that overlaps vertically. */
function bandsOf(blocks) {
  const sorted = [...blocks].sort((a, b) => a.box.y - b.box.y);
  const bands = [];
  for (const b of sorted) {
    const top = b.box.y, bottom = b.box.y + b.box.h;
    const hit = bands.find((band) => {
      const bt = Math.min(...band.map((x) => x.box.y));
      const bb = Math.max(...band.map((x) => x.box.y + x.box.h));
      const overlap = Math.min(bottom, bb) - Math.max(top, bt);
      return overlap > Math.min(b.box.h, bb - bt) * 0.45;
    });
    if (hit) hit.push(b); else bands.push([b]);
  }
  return bands;
}

/**
 * Merge blocks that are really one line of prose. A PDF hands back one box per
 * text item, so "Fixed Mindset" can arrive as two boxes a space apart; treating
 * that gap as a column boundary is how you end up reporting five columns on a
 * slide that has two.
 */
function mergeRuns(band) {
  const sorted = [...band].sort((a, b) => a.box.x - b.box.x);
  const out = [];
  for (const b of sorted) {
    const last = out[out.length - 1];
    // a word space at this type size, with a floor for very small text
    const space = Math.max(1.6, (last?.size || b.size || 2) * 1.1);
    if (last && b.box.x - (last.box.x + last.box.w) < space) {
      const right = Math.max(last.box.x + last.box.w, b.box.x + b.box.w);
      last.box = { x: last.box.x, y: Math.min(last.box.y, b.box.y), w: right - last.box.x,
        h: Math.max(last.box.h, b.box.h) };
      last.size = Math.max(last.size, b.size);
      last.chars += b.chars;
      last.text = `${last.text || ""} ${b.text || ""}`.trim();
    } else {
      out.push({ box: { ...b.box }, size: b.size, chars: b.chars, text: b.text || "" });
    }
  }
  return out;
}

/**
 * Columns, by clustering left edges.
 *
 * A whitespace projection was the obvious approach and it does not survive real
 * decks: one decorative bar straddling the corridor welds two columns into one,
 * and table cells that touch have no corridor at all. What actually defines a
 * column is that everything in it starts at the same x — that is how the deck
 * was built, and it holds whether or not there is a gap.
 */
function columnsOfSlide(lines, titleSize) {
  // Display type and wide text frames span the measure above/between columns.
  // They describe hierarchy, not a column boundary. Keep them only as a
  // fallback when the slide has no structural body anchors at all.
  const structural = lines.filter((l) => l.media
    || (l.size < titleSize * 0.92 && l.box.w < 60));
  const fallback = lines.filter((l) => l.box.w < 85);
  const pool = structural.length >= 2 ? structural : fallback;
  if (!pool.length) return [];

  const TOL = 3;   // two things one indent apart are still the same column
  const clusters = [];
  for (const l of [...pool].sort((a, b) => a.box.x - b.box.x)) {
    const hit = clusters.find((c) => Math.abs(c.x - l.box.x) <= TOL);
    if (hit) hit.blocks.push(l);
    else clusters.push({ x: l.box.x, blocks: [l] });
  }

  // A lone block near a well-populated column is that column's heading, sitting
  // one indent out. Left on its own it becomes a 7cqw phantom column.
  for (const c of [...clusters]) {
    if (c.blocks.length > 1) continue;
    const host = clusters.find((o) => o !== c && o.blocks.length >= 3 && Math.abs(o.x - c.x) <= 8);
    if (!host) continue;
    host.x = Math.min(host.x, c.x);
    host.blocks.push(...c.blocks);
    clusters.splice(clusters.indexOf(c), 1);
  }

  // Do not use a cluster's furthest right edge to delete another anchor. A
  // nearly full-width kicker can share the left anchor and make that edge span
  // the whole page even though the card grid beneath it has real columns.
  return clusters
    .sort((a, b) => a.x - b.x)
    .map((c, i, all) => {
      const nextX = all[i + 1]?.x ?? 100;
      const chars = c.blocks.reduce((n, l) => n + l.chars, 0);
      const measuredPanels = c.blocks.filter((l) => l.panel).map((l) => l.box.w);
      const measuredMedia = c.blocks.filter((l) => l.media && !l.panel).map((l) => l.box.w);
      const visualWidth = measuredPanels.length ? median(measuredPanels)
        : (measuredMedia.length ? median(measuredMedia) : null);
      return {
        x: r1(c.x),
        // The column is as wide as the space allotted to it, not as wide as the
        // words that happen to sit in it — a table cell holding "3.1" still
        // occupies its share of the row.
        w: r1(visualWidth ?? (Math.min(100, nextX) - c.x)),
        blocks: c.blocks,
        // Filled panels are structural anchors, but they are not pictures.
        // Keep the distinction so the generated skill does not reserve an
        // image slot for a plain comparison card.
        media: c.blocks.some((l) => l.media && !l.panel),
        hasVisual: c.blocks.some((l) => l.media),
        chars,
      };
    })
    .filter((c) => c.w >= 8 && (c.chars >= 12 || c.hasVisual));
}

/**
 * The filled panel a slide's content sits on.
 *
 * This falls between every other detector and so went unrecorded: it is a plain
 * rectangle, which decorative-vector extraction excludes by design, and it
 * moves between slides, which puts it outside the constant shell. But it is
 * unmistakably part of the template — the tinted card behind the agenda or the
 * band behind a comparison — and generated slides lose that treatment without it.
 */
function panelOf(slide, blocks) {
  const cands = (slide.shapes || []).filter((sh) => {
    const b = sh.box;
    if (!b || sh.role === "media") return false;
    const area = (b.w * b.h) / 10000;
    if (area < 0.06 || area > 0.75) return false;
    if (b.w >= 97 && b.h >= 97) return false;
    // A stroked outline is a table's border, not a panel. Taking its colour
    // paints the whole table solid black.
    if (sh.paint && sh.paint !== "fill") return false;
    return Boolean(sh.color || sh.bg);
  });
  if (!cands.length) return null;
  // it has to be *behind something*, or it is a decoration rather than a ground
  const backing = cands.filter((sh) => blocks.some((bl) =>
    bl.box.x + bl.box.w > sh.box.x && bl.box.x < sh.box.x + sh.box.w
    && bl.box.y + bl.box.h > sh.box.y && bl.box.y < sh.box.y + sh.box.h));
  const pick = (backing.length ? backing : cands)
    .sort((a, b) => (b.box.w * b.box.h) - (a.box.w * a.box.h))[0];
  return {
    x: r1(pick.box.x), y: r1(pick.box.y), w: r1(pick.box.w), h: r1(pick.box.h),
    color: pick.color || pick.bg || null,
    radiusCqw: Array.isArray(pick.radiiCqw) && pick.radiiCqw.length ? pick.radiiCqw[0] : 0,
  };
}

/** Does this slide sit on a picture rather than on the page colour? */
function fullBleedOf(slide) {
  const pic = (slide.shapes || []).find((sh) => sh.role === "media" && sh.box
    && sh.box.w >= 90 && sh.box.h >= 40);
  if (!pic) return null;
  return { x: r1(pic.box.x), y: r1(pic.box.y), w: r1(pic.box.w), h: r1(pic.box.h) };
}

function repeatedPanelPatternOf(slide, blocks) {
  const intersectsContent = (shape) => blocks.some((block) =>
    block.box.x + block.box.w > shape.box.x && block.box.x < shape.box.x + shape.box.w
    && block.box.y + block.box.h > shape.box.y && block.box.y < shape.box.y + shape.box.h);
  const panels = (slide.shapes || []).filter((shape) => {
    const b = shape.box;
    if (!b || shape.role === "media") return false;
    if (b.w < 6 || b.h < 4 || b.w >= 90 || b.h >= 90) return false;
    if (shape.paint && shape.paint !== "fill") return false;
    return Boolean(shape.color || shape.bg) && intersectsContent(shape);
  });
  if (panels.length < 2) return null;

  // Group by item dimensions, not colour: comparison cards often alternate
  // fills while retaining one repeated geometry.
  const groups = [];
  const near = (a, b) => Math.abs(a - b) <= Math.max(1.5, Math.min(a, b) * 0.1);
  for (const panel of panels) {
    const hit = groups.find((group) => near(group.seed.box.w, panel.box.w)
      && near(group.seed.box.h, panel.box.h));
    if (hit) hit.items.push(panel); else groups.push({ seed: panel, items: [panel] });
  }

  const clusterPositions = (values) => {
    const clusters = [];
    for (const value of [...values].sort((a, b) => a - b)) {
      const hit = clusters.find((cluster) => Math.abs(median(cluster) - value) <= 2);
      if (hit) hit.push(value); else clusters.push([value]);
    }
    return clusters.map((cluster) => median(cluster)).sort((a, b) => a - b);
  };
  const candidates = groups.map((group) => {
    const unique = [];
    for (const item of group.items) {
      if (!unique.some((other) => Math.abs(other.box.x - item.box.x) <= 0.5
        && Math.abs(other.box.y - item.box.y) <= 0.5)) unique.push(item);
    }
    const xs = clusterPositions(unique.map((item) => item.box.x));
    const ys = clusterPositions(unique.map((item) => item.box.y));
    return { items: unique, xs, ys };
  }).filter((candidate) => candidate.items.length >= 2
    && (candidate.xs.length >= 2 || candidate.ys.length >= 2));
  if (!candidates.length) return null;

  const best = candidates.sort((a, b) => (b.items.length - a.items.length)
    || (b.xs.length * b.ys.length - a.xs.length * a.ys.length))[0];
  const itemW = median(best.items.map((item) => item.box.w));
  const itemH = median(best.items.map((item) => item.box.h));
  const gaps = (positions, itemSize) => positions.slice(1)
    .map((value, i) => value - positions[i] - itemSize);
  const arrangement = best.xs.length > 1 && best.ys.length > 1 ? "grid"
    : (best.xs.length > 1 ? "row" : "stack");
  return {
    arrangement,
    columns: best.xs.length,
    rows: best.ys.length,
    count: best.items.length,
    itemWidthCqw: r1(itemW),
    itemHeightCqh: r1(itemH),
    gapCqw: best.xs.length > 1 ? r1(median(gaps(best.xs, itemW))) : 0,
    gapCqh: best.ys.length > 1 ? r1(median(gaps(best.ys, itemH))) : 0,
    radiusCqw: r1(median(best.items.flatMap((item) => item.radiiCqw || [0]))),
  };
}

function archetypeOf(slide, blocks, titleSize, context) {
  if (!blocks.length) return { id: "blank", bands: [], cols: [], fullBleed: fullBleedOf(slide) };
  const media = mediaBlocksOf(slide);
  const semanticBlocks = blocks.filter((block) => !isDecorativeTextBlock(block));
  const lines = bandsOf(semanticBlocks).flatMap(mergeRuns);
  // Pictures may only *reveal* a column boundary, never close one. Projecting
  // them together with the text lets one wide panel swallow a real gutter, so
  // both projections are run and the one that finds more structure wins.
  const textCols = columnsOfSlide(lines, titleSize);
  const withMedia = columnsOfSlide([...lines, ...media], titleSize);
  const cols = withMedia.length >= textCols.length ? withMedia : textCols;
  const bands = bandsOf(lines).map((band) => ({ band }));
  const widest = Math.max(1, cols.length);
  const chars = semanticBlocks.reduce((n, b) => n + b.chars, 0);
  const biggest = Math.max(0, ...semanticBlocks.map((b) => b.size));
  const semanticBands = bandsOf(semanticBlocks);

  // Few semantic bands plus display type: a cover or a section break. Running
  // furniture and standalone decorative glyphs were removed before counting.
  if (semanticBands.length <= 3 && chars < 220 && biggest >= titleSize * 0.85) {
    const cx = median(semanticBlocks.map((b) => b.box.x + b.box.w / 2));
    const cy = median(semanticBlocks.map((b) => b.box.y + b.box.h / 2));
    const centred = Math.abs(cx - 50) < 12;
    const position = context.index === 0 ? "cover"
      : (context.index === context.total - 1 ? "closing" : "statement");
    const placement = centred ? "-centred" : (cy > 55 ? "-low" : "");
    return { id: `${position}${placement}`, bands, cols, fullBleed: fullBleedOf(slide), panel: panelOf(slide, semanticBlocks) };
  }
  // Name only what was measured. "media-grid" versus "four-col" was a
  // distinction the evidence could not actually support, and a name that claims
  // more than the measurement is worse than a plain count — the columns array
  // already says which side takes the picture.
  const mediaCols = cols.filter((c) => c.media).length;
  const fullBleed = fullBleedOf(slide);
  const panel = panelOf(slide, blocks);
  const repetition = repeatedPanelPatternOf(slide, blocks);
  const measuredId = widest === 2 ? (mediaCols === 1 ? "split-media" : "split")
    : (widest >= 3 ? `grid-${widest}` : "single-col");
  const id = repetition
    ? `repeated-${repetition.arrangement}-${repetition.columns}x${repetition.rows}`
    : measuredId;
  return { id, bands, cols, fullBleed, panel, repetition };
}

function main() {
  const args = parseArgs(process.argv);
  const evidence = JSON.parse(readFileSync(args.evidence, "utf8"));
  const slides = evidence.slides;
  const total = slides.length;

  const blocksBySlide = slides.map(blocksOf);
  const allSizes = blocksBySlide.flatMap((blocks) => blocks.map((block) => block.size || 0));
  const titleSize = Math.max(0, ...allSizes) * 0.75;
  const chromePatterns = repeatedChromePatterns(blocksBySlide, titleSize);

  const seen = new Map();
  const perSlide = [];

  slides.forEach((slide, i) => {
    const allBlocks = blocksBySlide[i];
    const blocks = allBlocks.filter((block) =>
      !(isChromeCandidate(block, titleSize)
        && chromePatterns.some((pattern) => geometryNear(pattern.center, block))));
    const a = archetypeOf(slide, blocks, titleSize, { index: i, total });
    perSlide.push({
      slide: i + 1,
      archetype: a.id,
      blocks: blocks.length,
      chromeBlocks: allBlocks.length - blocks.length,
    });
    if (!seen.has(a.id)) seen.set(a.id, { id: a.id, slides: [], samples: [] });
    const rec = seen.get(a.id);
    rec.slides.push(i + 1);
    rec.samples.push(a);
  });

  const archetypes = [...seen.values()].map((rec) => {
    // Every slide of this archetype was measured whole; take the shape they agree on.
    const colCount = Math.round(median(rec.samples.map((s) => s.cols.length))) || 1;
    const sameShape = rec.samples.filter((s) => s.cols.length === colCount);

    const columns = [];
    for (let c = 0; c < colCount; c += 1) {
      const xs = sameShape.map((b) => b.cols[c]?.x).filter((v) => v != null);
      const ws = sameShape.map((b) => b.cols[c]?.w).filter((v) => v != null);
      // Which column takes the picture is the single most useful thing here: it
      // is what stops generated prose from covering the photo's half of the stage.
      const med = sameShape.filter((b) => b.cols[c]?.media).length;
      if (xs.length) columns.push({ x: r1(median(xs)), w: r1(median(ws)), media: med > sameShape.length / 2 });
    }
    const gutter = columns.length > 1
      ? r1(median(columns.slice(1).map((c, i) => c.x - (columns[i].x + columns[i].w)))) : 0;

    // Where the first line of each band sits, so generated content has a vertical rhythm
    // to place into rather than a single top margin.
    const bandTops = rec.samples.flatMap((s) => s.bands.map((b) => Math.min(...b.band.map((x) => x.box.y))));
    const titleTop = r1(median(rec.samples.map((s) => {
      const all = s.bands.flatMap((b) => b.band);
      const big = all.reduce((m, b) => (b.size > (m?.size || 0) ? b : m), null);
      return big ? big.box.y : 0;
    })));
    const bodyTop = r1(median(rec.samples.map((s) => {
      const all = s.bands.flatMap((b) => b.band).sort((a, b) => a.box.y - b.box.y);
      const big = all.reduce((m, b) => (b.size > (m?.size || 0) ? b : m), null);
      const after = all.filter((b) => b !== big && b.box.y > (big?.box.y || 0));
      return after.length ? after[0].box.y : (big?.box.y || 0);
    })));

    const centres = rec.samples.flatMap((s) => s.bands.flatMap((b) => b.band.map((x) => x.box.x + x.box.w / 2)));
    const align = median(centres) > 42 && median(centres) < 58
      && median(rec.samples.flatMap((s) => s.bands.flatMap((b) => b.band.map((x) => x.box.x)))) > 15
      ? "center" : "left";

    // Columns come from clustering left edges, and a centred stack has different
    // left edges *by construction* — a centred kicker, a centred title and a
    // centred lead line each start somewhere else. Reading that as a column
    // boundary turns one centred stack into a two-column claim the deck never
    // made. Centred content is one measure, however ragged its left edge.
    const centredStack = align === "center" && columns.length > 1;
    const measure = centredStack
      ? [{
          x: r1(Math.min(...columns.map((col) => col.x))),
          w: r1(Math.max(...columns.map((col) => col.x + col.w)) - Math.min(...columns.map((col) => col.x))),
          media: columns.some((col) => col.media),
        }]
      : columns;

    return {
      id: centredStack ? "centred-stack" : rec.id,
      slides: rec.slides,
      share: Math.round((rec.slides.length / total) * 100) / 100,
      columns: measure,
      gutterCqw: centredStack ? 0 : gutter,
      titleTopCqh: titleTop,
      bodyTopCqh: bodyTop,
      bandTopsCqh: [...new Set(bandTops.map(r1))].sort((a, b) => a - b).slice(0, 6),
      align,
      repetition: (() => {
        const hits = rec.samples.map((sample) => sample.repetition).filter(Boolean);
        if (hits.length <= rec.samples.length / 2) return null;
        return {
          arrangement: hits[0].arrangement,
          columns: Math.round(median(hits.map((hit) => hit.columns))),
          rows: Math.round(median(hits.map((hit) => hit.rows))),
          count: Math.round(median(hits.map((hit) => hit.count))),
          itemWidthCqw: r1(median(hits.map((hit) => hit.itemWidthCqw))),
          itemHeightCqh: r1(median(hits.map((hit) => hit.itemHeightCqh))),
          gapCqw: r1(median(hits.map((hit) => hit.gapCqw))),
          gapCqh: r1(median(hits.map((hit) => hit.gapCqh))),
          radiusCqw: r1(median(hits.map((hit) => hit.radiusCqw))),
        };
      })(),
      // Text over a picture is a different slide from text on the page colour,
      // and it is a major identity cue: a cover generated on white will not
      // resemble a source cover that sits on a full-bleed photograph.
      panel: (() => {
        const hits = rec.samples.map((x) => x.panel).filter(Boolean);
        if (hits.length <= rec.samples.length / 2) return null;
        const colors = new Map();
        for (const h of hits) if (h.color) colors.set(h.color, (colors.get(h.color) || 0) + 1);
        const color = [...colors.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || null;
        return {
          x: r1(median(hits.map((h) => h.x))), y: r1(median(hits.map((h) => h.y))),
          w: r1(median(hits.map((h) => h.w))), h: r1(median(hits.map((h) => h.h))),
          color, radiusCqw: r1(median(hits.map((h) => h.radiusCqw || 0))),
        };
      })(),
      fullBleed: (() => {
        const hits = rec.samples.map((x) => x.fullBleed).filter(Boolean);
        if (hits.length <= rec.samples.length / 2) return null;
        return { y: r1(median(hits.map((h) => h.y))), h: r1(median(hits.map((h) => h.h))) };
      })(),
    };
  }).sort((a, b) => b.slides.length - a.slides.length);

  // No floor. It kept deleting the arrangements a deck cannot do without — the
  // cover appears once by definition, and so does the closing slide. The share
  // is the signal; suppressing the row as well only loses information.
  const kept = archetypes.filter((a) => a.id !== "blank");
  const dropped = [];

  const reviewNotes = [];
  if (!kept.some((a) => a.columns.length > 1)) {
    reviewNotes.push("no multi-column candidate crossed the current clustering settings; inspect tables, panels, and media relationships before concluding that the deck is single-column");
  }
  if (!kept.some((a) => a.id.startsWith("cover"))) {
    reviewNotes.push("no cover candidate separated from body layouts; inspect the first and final slides before choosing a cover treatment");
  }
  for (const a of kept) {
    if (a.share < args.minShare) {
      reviewNotes.push(`candidate "${a.id}" was seen on ${a.slides.length}/${total} slides; review whether it is reusable or content-specific`);
    }
  }

  const out = {
    schema: "presentation-layouts/2",
    interpretation: {
      status: "advisory",
      note: "Layout archetypes are clustering suggestions. Confirm, merge, split, or reject them after visual review.",
    },
    slideCount: total,
    archetypes: kept,
    rare: dropped.filter((a) => a.id !== "blank"),
    perSlide,
    reviewNotes,
  };
  mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
  writeFileSync(args.out, JSON.stringify(out, null, 2));

  console.log(JSON.stringify({
    out: args.out,
    status: "advisory",
    archetypes: kept.map((a) => ({
      id: a.id, slides: a.slides.length, share: a.share,
      columns: a.columns, gutterCqw: a.gutterCqw, align: a.align,
      titleTopCqh: a.titleTopCqh, bodyTopCqh: a.bodyTopCqh,
    })),
    rare: out.rare.map((a) => `${a.id} ×${a.slides.length}`),
    reviewNotes,
  }, null, 2));
}

main();
