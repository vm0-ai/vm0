#!/usr/bin/env node
/**
 * derive-assets.mjs — group image and icon candidates by observed use.
 *
 * Size, repetition, inheritance, and anchor agreement produce suggested roles.
 * They do not establish ownership or user intent. The agent confirms every role
 * against the rendered deck before deciding which files belong in a template.
 *
 *   node derive-assets.mjs --evidence <evidence.json> --out <assets.json>
 *                          [--stage <template/assets>] [--min-share 0.25]
 */
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, existsSync } from "node:fs";
import { createHash } from "node:crypto";
import path from "node:path";

function parseArgs(argv) {
  const args = { evidence: "", out: "", stage: "", minShare: 0.25 };
  for (let i = 2; i < argv.length; i += 1) {
    const a = argv[i], next = argv[i + 1];
    if (a === "--evidence") { args.evidence = next; i += 1; }
    else if (a === "--out") { args.out = next; i += 1; }
    else if (a === "--stage") { args.stage = next; i += 1; }
    else if (a === "--min-share") { args.minShare = Number(next); i += 1; }
    else if (a === "--help" || a === "-h") { usage(); process.exit(0); }
    else throw new Error(`Unknown argument: ${a}`);
  }
  if (!args.evidence || !args.out) { usage(); process.exit(1); }
  if (!(args.minShare >= 0 && args.minShare <= 1)) throw new Error("--min-share must be between 0 and 1");
  return args;
}

function usage() {
  console.log(`Usage: node derive-assets.mjs --evidence <evidence.json> --out <assets.json>
                             [--stage <template/assets>] [--min-share 0.25]`);
}

/** Drop candidate lists that found nothing, so a key means a finding. */
const withoutEmptyLists = (groups) => Object.fromEntries(
  Object.entries(groups).filter(([, list]) => (list?.length ?? 0) > 0),
);

const median = (xs) => {
  if (!xs.length) return 0;
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)];
};

/**
 * The anchor a picture *usually* sits at, and how much of its use agrees.
 *
 * Requiring every placement to agree is too strict for real decks: this deck's
 * lockup sits top-left on three slides and top-right on the fourth, and a
 * min/max spread test threw the logo away over that one exception. Cluster the
 * placements on a 5% grid and take the largest cluster instead.
 */
function modalAnchor(boxes) {
  if (!boxes.length) return { x: 0, y: 0, w: 0, h: 0, agreement: 0 };
  const bucket = new Map();
  for (const b of boxes) {
    const key = `${Math.round(b.x / 5)}|${Math.round(b.y / 5)}`;
    if (!bucket.has(key)) bucket.set(key, []);
    bucket.get(key).push(b);
  }
  const best = [...bucket.values()].sort((a, b) => b.length - a.length)[0];
  return {
    x: Math.round(median(best.map((b) => b.x)) * 10) / 10,
    y: Math.round(median(best.map((b) => b.y)) * 10) / 10,
    w: Math.round(median(best.map((b) => b.w)) * 10) / 10,
    h: Math.round(median(best.map((b) => b.h)) * 10) / 10,
    agreement: Math.round((best.length / boxes.length) * 100) / 100,
  };
}

const near = (a, b, tol = 8) => Math.abs(a - b) <= tol;

/** A picture is a stage background only when it actually reaches every edge.
 *  Width alone is not enough: a full-width hero strip is still content. */
function coversStage(box) {
  if (!box) return false;
  const x = Number(box.x || 0), y = Number(box.y || 0);
  const w = Number(box.w || 0), h = Number(box.h || 0);
  const tolerance = 2.5;
  return x <= tolerance && y <= tolerance
    && x + w >= 100 - tolerance && y + h >= 100 - tolerance
    && w * h >= 8500;
}

const assetKeys = (values) => new Set(values.flatMap((value) => {
  if (!value) return [];
  const text = String(value);
  return [text, path.basename(text)];
}));

/** Recover per-slide placement because the folded asset record intentionally
 *  stores boxes and slide ids separately for compatibility across extractors. */
function placementsOf(evidence, asset) {
  const keys = assetKeys([asset.id, asset.file, asset.src, ...(asset.ids || [])]);
  const placements = [];
  const seen = new Set();
  const add = (slide, box, inherited = false) => {
    const key = `${slide}|${box?.x}|${box?.y}|${box?.w}|${box?.h}|${inherited}`;
    if (seen.has(key)) return;
    seen.add(key);
    placements.push({ slide, box, inherited: Boolean(inherited), fullStage: coversStage(box) });
  };
  const matches = (...values) => [...assetKeys(values)].some((value) => keys.has(value));

  for (const [offset, slide] of (evidence.slides || []).entries()) {
    const slideNumber = slide.index || offset + 1;
    if (matches(slide.stageImage)) add(slideNumber, { x: 0, y: 0, w: 100, h: 100 }, true);
    for (const shape of slide.shapes || []) {
      if (matches(shape.assetId, shape.image, shape.src)) {
        add(slideNumber, shape.box, shape.inherited);
      }
    }
  }

  // Older evidence may not repeat the asset id on slide shapes. Preserve its
  // folded boxes as a fallback rather than silently losing background evidence.
  if (!placements.length) {
    const slides = asset.slides || [];
    for (const [index, box] of (asset.boxes || []).entries()) {
      add(slides[Math.min(index, Math.max(0, slides.length - 1))] || null, box, asset.inherited);
    }
  }
  return placements;
}

function rolesForSlides(slides, sourceSlideCount) {
  const roles = new Set();
  for (const slide of slides) {
    if (slide === 1) roles.add("cover");
    else if (slide === sourceSlideCount) roles.add("closing");
    else roles.add("content");
  }
  return [...roles];
}

function roleLabel(roles) {
  const present = new Set(roles);
  if (present.has("cover") && present.has("content") && present.has("closing")) return "universal";
  return ["cover", "content", "closing"].filter((role) => present.has(role)).join("-") || "content";
}

/**
 * Suggest roles in two passes: find a likely anchored mark first, then compare
 * the remaining assets with that candidate.
 */
function classify(asset, slideCount, brandMark, minShare = 0.25) {
  const anchor = asset.anchor;
  const { w, h, agreement } = anchor;
  const share = asset.slides.length / Math.max(1, slideCount);

  // A local full-stage image in the middle of a deck may be one-off semantic
  // content. The same placement on the cover or closing slide defines that
  // boundary page's visual treatment even when it appears only once.
  if (asset.fullStageSlides.length) {
    const boundary = asset.templateRoles.includes("cover") || asset.templateRoles.includes("closing");
    return asset.inherited || asset.slides.length >= 2 || boundary ? "background" : "illustration";
  }
  // Retain the older broad search for inherited/repeated artwork that nearly
  // spans the stage, but never promote a one-off strip merely for being wide.
  if (w >= 80 || h >= 80) {
    return asset.inherited || asset.slides.length >= 2 ? "background" : "illustration";
  }
  // Chrome is small in both axes. A 45cqh image is a picture wherever it sits.
  const chromeSized = h <= 22;
  if (chromeSized && agreement >= 0.6 && share >= minShare && w <= 10) return "brand-mark";
  if (chromeSized && agreement >= 0.6 && asset.slides.length >= 2 && w <= 30
      && brandMark && near(anchor.x, brandMark.anchor.x) && near(anchor.y, brandMark.anchor.y)) {
    return "brand-lockup";
  }
  if (w <= 8 && h <= 12) return "icon";
  if (w >= 20 || h >= 30) return "illustration";
  return "decoration";
}

const IDENTITY = new Set(["brand-mark", "brand-lockup", "icon", "decoration", "background"]);

const round1 = (value) => Math.round(value * 10) / 10;

function pathFromCustGeom(paths) {
  if (!Array.isArray(paths) || !paths.length) return null;
  const commands = [];
  for (const item of paths) {
    const width = item.w || 100, height = item.h || 100;
    const x = (value) => round1((value / width) * 100);
    const y = (value) => round1((value / height) * 100);
    for (const command of item.cmds || []) {
      const points = command.pts || [];
      if (command.op === "moveTo" && points[0]) commands.push(`M${x(points[0][0])},${y(points[0][1])}`);
      else if (command.op === "lnTo" && points[0]) commands.push(`L${x(points[0][0])},${y(points[0][1])}`);
      else if (command.op === "cubicBezTo" && points.length >= 3) {
        commands.push(`C${x(points[0][0])},${y(points[0][1])} ${x(points[1][0])},${y(points[1][1])} ${x(points[2][0])},${y(points[2][1])}`);
      } else if (command.op === "quadBezTo" && points.length >= 2) {
        commands.push(`Q${x(points[0][0])},${y(points[0][1])} ${x(points[1][0])},${y(points[1][1])}`);
      } else if (command.op === "close") commands.push("Z");
      else return null;
    }
  }
  return commands.length ? commands.join("") : null;
}

const vectorPath = (shape) => shape.svgPath || shape.d || pathFromCustGeom(shape.path) || null;

function vectorIconCandidates(evidence, stageDir) {
  const groups = new Map();
  for (const slide of evidence.slides || []) {
    for (const shape of slide.shapes || []) {
      const box = shape.box || {};
      const d = vectorPath(shape);
      if (!d || shape.role === "media" || shape.kind === "rect") continue;
      if (!(box.w > 0.2) || !(box.h > 0.2) || box.w > 8 || box.h > 12) continue;
      const fill = shape.color || null, stroke = shape.stroke || null;
      const signature = createHash("sha256").update(`${d}|${fill}|${stroke}`).digest("hex").slice(0, 12);
      if (!groups.has(signature)) groups.set(signature, { d, fill, stroke, viewBox: shape.viewBox || "0 0 100 100", uses: [] });
      groups.get(signature).uses.push({ slide: slide.index, box });
    }
  }

  return [...groups.entries()].map(([signature, group], index) => {
    const boxes = group.uses.map((use) => use.box);
    const candidate = {
      id: `vector-icon-${signature}`,
      file: null,
      staged: null,
      slides: [...new Set(group.uses.map((use) => use.slide))],
      uses: group.uses.length,
      boxes,
      box: modalAnchor(boxes),
      fill: group.fill,
      stroke: group.stroke,
      suggestedKind: "vector-icon",
      identityCandidate: true,
      interpretation: "advisory",
    };
    if (stageDir) {
      const file = path.join(stageDir, `vector-icon-${String(index + 1).padStart(2, "0")}.svg`);
      const fill = /^#[0-9A-F]{6}$/i.test(group.fill || "") ? group.fill : (group.stroke ? "none" : "currentColor");
      const stroke = /^#[0-9A-F]{6}$/i.test(group.stroke || "") ? ` stroke="${group.stroke}"` : "";
      writeFileSync(file, `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${group.viewBox}"><path d="${group.d}" fill="${fill}"${stroke}/></svg>\n`);
      candidate.file = file;
      candidate.staged = file;
    }
    return candidate;
  });
}

function main() {
  const args = parseArgs(process.argv);
  const evidence = JSON.parse(readFileSync(args.evidence, "utf8"));
  const slideCount = evidence.source?.slideCount || evidence.slides.length;
  const sourceSlideCount = evidence.source?.slidesInFile || evidence.source?.pagesInFile || slideCount;

  // An image placed by the master or a layout was put there by whoever made the
  // template, not by whoever wrote this slide — that alone makes it template.
  const inheritedIds = new Set();
  for (const slide of evidence.slides) {
    for (const sh of slide.shapes || []) {
      if (sh.inherited && sh.assetId) inheritedIds.add(sh.assetId);
    }
  }

  const staged0 = (evidence.assets || []).map((a) => {
    const inherited = (a.ids || [a.id]).some((id) => inheritedIds.has(id));
    const placements = placementsOf(evidence, { ...a, inherited });
    const inheritedPlacement = inherited || placements.some((placement) => placement.inherited);
    const fullStageSlides = [...new Set(placements.filter((placement) => placement.fullStage)
      .map((placement) => placement.slide).filter(Boolean))].sort((left, right) => left - right);
    const templateRoles = rolesForSlides(fullStageSlides, sourceSlideCount);
    const slides = a.slides || [];
    return {
      id: a.id,
      ids: a.ids,
      file: a.file,
      src: a.src,
      uses: a.uses,
      slides,
      boxes: a.boxes,
      inherited: inheritedPlacement,
      share: Math.round((slides.length / Math.max(1, slideCount)) * 100) / 100,
      anchor: modalAnchor(a.boxes || []),
      fullStageSlides,
      templateRoles,
      templateRole: roleLabel(templateRoles),
    };
  });

  // Pass 1: find an anchored brand-mark candidate.
  const markCandidate = staged0
    .filter((a) => classify(a, slideCount, null, args.minShare) === "brand-mark")
    .sort((a, b) => b.slides.length - a.slides.length)[0] || null;

  // Pass 2: suggest roles relative to the mark candidate.
  const assets = staged0.map((a) => {
    const kind = a === markCandidate ? "brand-mark" : classify(a, slideCount, markCandidate, args.minShare);
    return {
      ...a,
      box: a.anchor,
      suggestedKind: kind,
      identityCandidate: IDENTITY.has(kind),
      interpretation: "advisory",
    };
  });

  // icon fonts: family + the glyph names the deck actually used
  const glyphs = new Map();
  const families = new Map();
  for (const slide of evidence.slides) {
    for (const t of slide.text || []) {
      if (!t.iconFont || !t.glyph) continue;
      families.set(t.family, (families.get(t.family) || 0) + 1);
      const key = `${t.family}|${t.glyph}`;
      glyphs.set(key, (glyphs.get(key) || 0) + 1);
    }
  }
  const iconFonts = [...families.entries()].map(([family, uses]) => ({
    family,
    uses,
    glyphs: [...glyphs.entries()]
      .filter(([k]) => k.startsWith(`${family}|`))
      .map(([k, n]) => ({ name: k.split("|")[1], uses: n })),
  }));

  // vector icons drawn as custom geometry rather than placed as images
  let customGeometry = 0;
  for (const slide of evidence.slides) {
    for (const s of slide.shapes || []) if (s.kind === "custGeom" && s.path) customGeometry += 1;
  }

  const staged = [];
  if (args.stage) {
    mkdirSync(args.stage, { recursive: true });
    for (const a of assets) {
      if (!a.identityCandidate || !a.file || !existsSync(a.file)) continue;
      const dst = path.join(args.stage, path.basename(a.file));
      copyFileSync(a.file, dst);
      a.staged = dst;
      staged.push(dst);
    }
  }
  const vectorIcons = vectorIconCandidates(evidence, args.stage);
  staged.push(...vectorIcons.map((candidate) => candidate.staged).filter(Boolean));

  const backgroundCandidates = assets.filter((a) => a.suggestedKind === "background");
  const brandMarkCandidate = assets.find((a) => a.suggestedKind === "brand-mark") || null;
  const reviewNotes = [];
  if (!brandMarkCandidate) {
    reviewNotes.push(backgroundCandidates.length
      ? `no separable logo candidate was found; inspect whether identity artwork is embedded in ${backgroundCandidates.length} full-bleed image candidate(s)`
      : "no repeated anchored image crossed the current search settings; inspect vector shapes and the rendered deck before concluding that no brand mark exists");
  }
  if (backgroundCandidates.length > 1) {
    reviewNotes.push(`${backgroundCandidates.length} background candidates were found; review whether they are template variants or recurring content`);
  }
  const boundaryBackgrounds = backgroundCandidates.filter((candidate) =>
    candidate.templateRoles.includes("cover") || candidate.templateRoles.includes("closing"));
  if (boundaryBackgrounds.length) {
    reviewNotes.push(`${boundaryBackgrounds.length} full-stage cover or closing background candidate(s) were treated as template variants; repetition is not required for boundary pages`);
  }
  if (customGeometry) {
    reviewNotes.push(`${customGeometry} custom-geometry shape(s) were found; review their captured paths as possible icons or decoration`);
  }
  if (vectorIcons.length) {
    reviewNotes.push(`${vectorIcons.length} small vector path candidate(s) were preserved as SVG icons; confirm their semantic role before reuse`);
  }
  if (iconFonts.length) {
    reviewNotes.push(`icon-font evidence found (${iconFonts.map((f) => f.family).join(", ")}); review family and glyph names as reusable identity candidates`);
  }
  const contentCandidates = assets.filter((a) => a.suggestedKind === "illustration");
  if (contentCandidates.length) {
    reviewNotes.push(`${contentCandidates.length} interior large or one-off image(s) were suggested as content and were not staged; review exceptions before final packaging`);
  }

  const out = {
    schema: "presentation-assets/2",
    interpretation: {
      status: "advisory",
      note: "Asset roles are heuristic suggestions based on observed use; confirm them visually and against user intent.",
    },
    candidateSearch: {
      minRepeatedShare: args.minShare,
      note: "This narrows the review set and is not an inclusion requirement; full-stage cover and closing artwork remains eligible when seen once.",
    },
    source: evidence.source?.path,
    slideCount,
    brandMarkCandidate,
    // Only the lists that found something. Ten empty arrays read as ten
    // considered findings; `assetsFound: 0` is the same information without the
    // ceremony, and it keeps "we looked and found nothing" from looking like
    // "we found ten kinds of nothing".
    ...withoutEmptyLists({
      backgroundCandidates,
      lockupCandidates: assets.filter((a) => a.suggestedKind === "brand-lockup"),
      iconCandidates: assets.filter((a) => a.suggestedKind === "icon"),
      vectorIconCandidates: vectorIcons,
      decorationCandidates: assets.filter((a) => a.suggestedKind === "decoration"),
      contentCandidates,
      iconFonts,
      stagedCandidates: staged,
    }),
    assetsFound: staged.length,
    customGeometry,
    reviewNotes,
  };
  mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
  writeFileSync(args.out, JSON.stringify(out, null, 2));
  console.log(JSON.stringify({
    out: args.out,
    status: "advisory",
    brandMarkCandidate: brandMarkCandidate ? `${brandMarkCandidate.id} on ${brandMarkCandidate.slides.length}/${slideCount} slides at ${brandMarkCandidate.box.x},${brandMarkCandidate.box.y} (${brandMarkCandidate.box.w}cqw)` : null,
    backgroundCandidates: backgroundCandidates.map((b) => `${b.id} on slides ${b.slides.join(",")}`),
    lockupCandidates: out.lockupCandidates?.length ?? 0,
    iconCandidates: out.iconCandidates?.length ?? 0,
    vectorIconCandidates: vectorIcons.length,
    iconFonts: iconFonts.map((f) => `${f.family}: ${f.glyphs.map((g) => g.name).join(", ")}`),
    contentCandidatesNotStaged: contentCandidates.length,
    stagedCandidates: staged.length,
    reviewNotes,
  }, null, 2));
}

main();
