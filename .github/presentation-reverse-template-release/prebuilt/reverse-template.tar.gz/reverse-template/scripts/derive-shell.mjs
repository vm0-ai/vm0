#!/usr/bin/env node
/**
 * derive-shell.mjs — find the part of a deck that never changes.
 *
 * The method, in one line: **take the text away and see what is left.**
 *
 * A deck is two layers wearing one coat. The content layer changes on every
 * slide; the identity layer — ground colour, background artwork, logo, footer,
 * rules — is the same on all of them. Reading shapes cannot reliably separate
 * the two, and it fails completely when the whole brand shell is baked into one
 * background JPEG on the slide master, which is exactly how corporate templates
 * are built. Pixels do not care: render every slide with the text removed, then
 * keep only what agrees across slides.
 *
 *   node reconstruct.mjs --evidence ev.json --out shellrender --no-text --shot
 *   node derive-shell.mjs --images shellrender --out shell.json --png shell.png
 *
 * Emits the invariant ground colour, the regions that hold constant marks (logo,
 * footer, rules) with their measured boxes, and how much of the stage the
 * template's own furniture occupies.
 */
import { existsSync, readFileSync, readdirSync, writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";
import { loadCanvas } from "./canvas-helper.mjs";

function parseArgs(argv) {
  const args = { images: "", out: "", png: "", tolerance: 12, agree: 0.8, max: 40, variantTolerance: 4 };
  for (let i = 2; i < argv.length; i += 1) {
    const a = argv[i], next = argv[i + 1];
    if (a === "--images") { args.images = next; i += 1; }
    else if (a === "--out") { args.out = next; i += 1; }
    else if (a === "--png") { args.png = next; i += 1; }
    else if (a === "--tolerance") { args.tolerance = Number(next); i += 1; }
    else if (a === "--agree") { args.agree = Number(next); i += 1; }
    else if (a === "--max") { args.max = Number(next); i += 1; }
    else if (a === "--variant-tolerance") { args.variantTolerance = Number(next); i += 1; }
    else if (a === "--help" || a === "-h") { usage(); process.exit(0); }
    else throw new Error(`Unknown argument: ${a}`);
  }
  if (!args.images || !args.out) { usage(); process.exit(1); }
  if (!Number.isFinite(args.max) || args.max < 2) throw new Error("--max must be at least 2 so cover and closing slides can both be retained");
  return args;
}

function usage() {
  console.log(`Usage: node derive-shell.mjs --images <text-free render dir> --out <shell.json>
                            [--png <shell.png>] [--tolerance 12] [--agree 0.8]
                            [--variant-tolerance 4]`);
}

const IMAGE_EXT = new Set([".png", ".jpg", ".jpeg", ".webp"]);
const hexOf = (r, g, b) =>
  "#" + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("").toUpperCase();

function listImages(dir) {
  return readdirSync(dir).sort()
    .filter((n) => !/^(contact-sheet|reference|shell)/i.test(n))
    .filter((n) => IMAGE_EXT.has(path.extname(n).toLowerCase()))
    .map((n) => path.join(dir, n));
}

function selectFiles(files, max) {
  const limit = Math.floor(max);
  if (files.length <= limit) return files;
  const indexes = new Set();
  for (let offset = 0; offset < limit; offset += 1) {
    indexes.add(Math.round((offset * (files.length - 1)) / (limit - 1)));
  }
  return [...indexes].sort((left, right) => left - right).map((index) => files[index]);
}

function backgroundManifest(dir) {
  const file = path.join(dir, "background-manifest.json");
  if (!existsSync(file)) return null;
  try {
    return JSON.parse(readFileSync(file, "utf8"));
  } catch {
    return null;
  }
}

function templateRole(slides, sourceSlideCount) {
  const roles = new Set(slides.map((slide) => slide === 1
    ? "cover" : (slide === sourceSlideCount ? "closing" : "content")));
  if (roles.has("cover") && roles.has("content") && roles.has("closing")) return "universal";
  return ["cover", "content", "closing"].filter((role) => roles.has(role)).join("-") || "content";
}

/** Group the constant non-ground pixels into rectangles, so the report names
 *  regions ("a mark top-left, 18% wide") rather than a cloud of coordinates. */
function regions(mask, w, h, minPixels, bridge = 2) {
  const seen = new Uint8Array(w * h);
  const out = [];
  const stack = [];
  for (let i = 0; i < w * h; i += 1) {
    if (!mask[i] || seen[i]) continue;
    stack.length = 0;
    stack.push(i);
    seen[i] = 1;
    let count = 0, minX = w, minY = h, maxX = 0, maxY = 0;
    while (stack.length) {
      const p = stack.pop();
      const x = p % w, y = (p - x) / w;
      count += 1;
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
      // 8-connected, with a small bridging radius so a wordmark's letters join up
      for (let dy = -bridge; dy <= bridge; dy += 1) {
        for (let dx = -bridge; dx <= bridge; dx += 1) {
          const nx = x + dx, ny = y + dy;
          if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
          const q = ny * w + nx;
          if (mask[q] && !seen[q]) { seen[q] = 1; stack.push(q); }
        }
      }
    }
    if (count >= minPixels) {
      out.push({
        x: Math.round((minX / w) * 1000) / 10,
        y: Math.round((minY / h) * 1000) / 10,
        w: Math.round(((maxX - minX + 1) / w) * 1000) / 10,
        h: Math.round(((maxY - minY + 1) / h) * 1000) / 10,
        pixels: count,
      });
    }
  }
  return out.sort((a, b) => b.pixels - a.pixels).slice(0, 12);
}

async function main() {
  const args = parseArgs(process.argv);
  const canvasMod = await loadCanvas();
  const { loadImage, createCanvas } = canvasMod.default ?? canvasMod;
  const files = selectFiles(listImages(args.images), args.max);
  if (!files.length) throw new Error(`no text-free renders found in ${args.images}`);
  const manifest = backgroundManifest(args.images);
  const manifestSlides = new Map((manifest?.selectedSlides || []).map((entry) => [entry.file, entry.slide]));
  const slideNumbers = files.map((file, index) => manifestSlides.get(path.basename(file))
    || Number(path.basename(file).match(/(?:slide|page)-0*(\d+)/i)?.[1]) || index + 1);
  const sourceSlideCount = manifest?.sourceSlideCount || Math.max(...slideNumbers);

  // Work at a reduced size: the question is "does this area agree across slides",
  // not "is this pixel identical".
  const first = await loadImage(files[0]);
  const scale = Math.min(1, 640 / first.width);
  const w = Math.max(1, Math.round(first.width * scale));
  const h = Math.max(1, Math.round(first.height * scale));

  const frames = [];
  for (const file of files) {
    const img = await loadImage(file);
    const canvas = createCanvas(w, h);
    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0, w, h);
    frames.push(ctx.getImageData(0, 0, w, h).data);
    process.stderr.write(`read ${frames.length}/${files.length}\r`);
  }
  process.stderr.write("\n");

  const n = frames.length;
  const need = Math.max(1, Math.ceil(n * args.agree));

  // Each slide's own ground, so a deck that ships several background variants is
  // still measurable. Comparing raw colours across variants finds nothing: the
  // same logo is maroon on grey in one variant and white on olive in another.
  const grounds = frames.map((f) => {
    const buckets = new Map();
    for (let p = 0; p < w * h; p += 1) {
      const i = p * 4;
      const key = `${f[i] >> 3},${f[i + 1] >> 3},${f[i + 2] >> 3}`;
      const b = buckets.get(key) || { n: 0, r: 0, g: 0, b: 0 };
      b.n += 1; b.r += f[i]; b.g += f[i + 1]; b.b += f[i + 2];
      buckets.set(key, b);
    }
    const best = [...buckets.values()].sort((a, b) => b.n - a.n)[0];
    return [best.r / best.n, best.g / best.n, best.b / best.n];
  });

  const constant = new Uint8Array(w * h);     // same colour on most slides
  const furniture = new Uint8Array(w * h);    // occupied on most slides, whatever the colour
  const shell = new Uint8ClampedArray(w * h * 4);
  const groundVotes = new Map();
  let constantPixels = 0, furniturePixels = 0;

  for (let p = 0; p < w * h; p += 1) {
    const i = p * 4;
    const buckets = new Map();
    let occupied = 0;
    for (let k = 0; k < n; k += 1) {
      const f = frames[k], g = grounds[k];
      const key = `${f[i] >> 3},${f[i + 1] >> 3},${f[i + 2] >> 3}`;
      const b = buckets.get(key) || { n: 0, r: 0, g: 0, b: 0 };
      b.n += 1; b.r += f[i]; b.g += f[i + 1]; b.b += f[i + 2];
      buckets.set(key, b);
      const d = Math.abs(f[i] - g[0]) + Math.abs(f[i + 1] - g[1]) + Math.abs(f[i + 2] - g[2]);
      if (d > args.tolerance) occupied += 1;
    }
    const best = [...buckets.values()].sort((a, b) => b.n - a.n)[0];
    const r = best.r / best.n, g = best.g / best.n, bl = best.b / best.n;

    if (occupied >= need) { furniture[p] = 1; furniturePixels += 1; }

    if (best.n >= need) {
      constant[p] = 1; constantPixels += 1;
      shell[i] = r; shell[i + 1] = g; shell[i + 2] = bl; shell[i + 3] = 255;
      groundVotes.set(hexOf(r, g, bl), (groundVotes.get(hexOf(r, g, bl)) || 0) + 1);
    } else if (furniture[p]) {
      // structurally constant but recoloured between variants — mark it so the
      // stencil still shows where the template always puts something
      shell[i] = r; shell[i + 1] = g; shell[i + 2] = bl; shell[i + 3] = 140;
    } else {
      shell[i] = 255; shell[i + 1] = 255; shell[i + 2] = 255; shell[i + 3] = 0;
    }
  }

  const ground = [...groundVotes.entries()].sort((a, b) => b[1] - a[1])[0];
  const groundHex = ground ? ground[0] : hexOf(...grounds[0]);

  // bridge ≈ 1.5% of the width: letters of a wordmark join, separate marks do not
  const rawMarks = regions(furniture, w, h, Math.round(w * h * 0.0004), Math.max(2, Math.round(w * 0.015)));

  // How assertive is each mark? A 5%-opacity watermark and a solid header band
  // are both "constant", but only one of them is a keep-out zone — the source
  // writes body copy straight over the watermark. Measure the distance from the
  // ground so the two can be told apart.
  const groundRgbArr = [parseInt(groundHex.slice(1, 3), 16), parseInt(groundHex.slice(3, 5), 16), parseInt(groundHex.slice(5, 7), 16)];
  const marks = rawMarks.map((m) => {
    const x0 = Math.floor((m.x / 100) * w), x1 = Math.min(w, Math.ceil(((m.x + m.w) / 100) * w));
    const y0 = Math.floor((m.y / 100) * h), y1 = Math.min(h, Math.ceil(((m.y + m.h) / 100) * h));
    let sum = 0, n = 0;
    for (let y = y0; y < y1; y += 1) {
      for (let x = x0; x < x1; x += 1) {
        const p = y * w + x;
        if (!furniture[p]) continue;
        const i = p * 4;
        sum += (Math.abs(shell[i] - groundRgbArr[0]) + Math.abs(shell[i + 1] - groundRgbArr[1]) + Math.abs(shell[i + 2] - groundRgbArr[2])) / 3;
        n += 1;
      }
    }
    const strength = n ? Math.round((sum / n) * 10) / 10 : 0;
    return { ...m, strength, assertive: strength >= 40 };
  })
    // A "constant mark" spanning the whole stage is not a mark, it is the stage.
    // Decks whose every slide is one flat field produce exactly that: a single
    // 0,0,100,100 region carrying no location and therefore no keep-out
    // information, which a reader can only mistake for a full-bleed logo.
    .filter((m) => (m.w * m.h) / 10000 < 0.6);

  // How many distinct background variants does the template ship? Cluster the
  // text-free frames on a coarse signature; "one shell" and "eight shells" are
  // very different briefs for whoever generates the next deck.
  const signature = (f) => {
    const cells = [];
    for (let cy = 0; cy < 6; cy += 1) {
      for (let cx = 0; cx < 8; cx += 1) {
        let r = 0, g = 0, b = 0, count = 0;
        for (let y = Math.floor((cy * h) / 6); y < Math.floor(((cy + 1) * h) / 6); y += 2) {
          for (let x = Math.floor((cx * w) / 8); x < Math.floor(((cx + 1) * w) / 8); x += 2) {
            const i = (y * w + x) * 4;
            r += f[i]; g += f[i + 1]; b += f[i + 2]; count += 1;
          }
        }
        cells.push([r / count, g / count, b / count]);
      }
    }
    return cells;
  };
  const sigs = frames.map(signature);
  const variantOf = new Array(n).fill(-1);
  const variants = [];
  for (let k = 0; k < n; k += 1) {
    if (variantOf[k] >= 0) continue;
    const id = variants.length;
    variantOf[k] = id;
    const members = [k];
    for (let j = k + 1; j < n; j += 1) {
      if (variantOf[j] >= 0) continue;
      let diff = 0;
      for (let c = 0; c < sigs[k].length; c += 1) {
        diff += Math.abs(sigs[k][c][0] - sigs[j][c][0])
          + Math.abs(sigs[k][c][1] - sigs[j][c][1])
          + Math.abs(sigs[k][c][2] - sigs[j][c][2]);
      }
      if (diff / sigs[k].length < args.variantTolerance) { variantOf[j] = id; members.push(j); }
    }
    const sourceSlides = members.map((member) => slideNumbers[member]);
    variants.push({
      id,
      slides: sourceSlides,
      example: path.basename(files[members[0]]),
      templateRole: templateRole(sourceSlides, sourceSlideCount),
    });
  }

  if (args.png) {
    mkdirSync(path.dirname(path.resolve(args.png)), { recursive: true });
    const canvas = createCanvas(w, h);
    const ctx = canvas.getContext("2d");
    const img = ctx.createImageData(w, h);
    img.data.set(shell);
    ctx.putImageData(img, 0, 0);
    writeFileSync(args.png, canvas.toBuffer("image/png"));
  }

  const result = {
    schema: "presentation-shell/2",
    interpretation: {
      status: "advisory",
      note: "Constant regions and variants are pixel-clustering candidates; confirm their semantic role against the rendered deck.",
    },
    slidesCompared: n,
    sourceSlideCount,
    candidateAgreementThreshold: args.agree,
    variantTolerance: args.variantTolerance,
    ground: groundHex,
    constantShare: Math.round((constantPixels / (w * h)) * 1000) / 10,
    furnitureShare: Math.round((furniturePixels / (w * h)) * 1000) / 10,
    variants,
    marks,
    shellPng: args.png || null,
    note: n < 4
      ? "fewer than four slides compared — a mark that happens to sit in the same place twice will look constant"
      : null,
  };
  mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
  writeFileSync(args.out, JSON.stringify(result, null, 2));
  console.log(JSON.stringify(result, null, 2));
}

main().catch((error) => {
  console.error(error.stack || error.message);
  process.exit(1);
});
