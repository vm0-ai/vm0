#!/usr/bin/env node
/**
 * derive-candidates.mjs — collect the independent candidate reports in one run.
 *
 * This is only an orchestration shortcut. Each child script still emits
 * advisory evidence; this script does not accept, reject, or rank design
 * decisions for the agent.
 *
 *   node derive-candidates.mjs --evidence <evidence.json> --work <dir>
 *                              --token <token> --name <name>
 *                              [--render-backgrounds <dir> | --shell-images <dir>]
 *                              [--max 12]
 */
import { execFile } from "node:child_process";
import { mkdirSync } from "node:fs";
import { promisify } from "node:util";
import path from "node:path";
import { fileURLToPath } from "node:url";

const execFileAsync = promisify(execFile);
const HERE = path.dirname(fileURLToPath(import.meta.url));

function parseArgs(argv) {
  const args = {
    evidence: "", work: "", token: "extracted_system", name: "Extracted system",
    shellImages: "", renderBackgrounds: "", max: 12,
  };
  for (let i = 2; i < argv.length; i += 1) {
    const a = argv[i], next = argv[i + 1];
    if (a === "--evidence") { args.evidence = next; i += 1; }
    else if (a === "--work") { args.work = next; i += 1; }
    else if (a === "--token") { args.token = next; i += 1; }
    else if (a === "--name") { args.name = next; i += 1; }
    else if (a === "--shell-images") { args.shellImages = next; i += 1; }
    else if (a === "--render-backgrounds") { args.renderBackgrounds = next; i += 1; }
    else if (a === "--max") { args.max = Number(next); i += 1; }
    else if (a === "--help" || a === "-h") { usage(); process.exit(0); }
    else throw new Error(`Unknown argument: ${a}`);
  }
  if (!args.evidence || !args.work) { usage(); process.exit(1); }
  if (args.shellImages && args.renderBackgrounds) throw new Error("choose either --shell-images or --render-backgrounds");
  if (!(args.max >= 2)) throw new Error("--max must be at least 2 so cover and closing slides can both be retained");
  return args;
}

function usage() {
  console.log(`Usage: node derive-candidates.mjs --evidence <evidence.json> --work <dir>
                                  [--token <token>] [--name <name>]
                                  [--render-backgrounds <output dir>]
                                  [--shell-images <existing text-free render dir>]
                                  [--max 12]`);
}

async function run(script, argv) {
  const started = Date.now();
  try {
    const result = await execFileAsync(process.execPath, [path.join(HERE, script), ...argv], {
      maxBuffer: 64 * 1024 * 1024,
    });
    if (result.stderr) process.stderr.write(result.stderr);
    return { script, elapsedMs: Date.now() - started };
  } catch (error) {
    const detail = String(error.stderr || error.message || error).trim();
    throw new Error(`${script} failed${detail ? `: ${detail}` : ""}`, { cause: error });
  }
}

async function main() {
  const started = Date.now();
  const args = parseArgs(process.argv);
  const work = path.resolve(args.work);
  const backgroundImages = args.renderBackgrounds
    ? path.resolve(args.renderBackgrounds)
    : (args.shellImages ? path.resolve(args.shellImages) : "");
  const files = {
    assets: path.join(work, "assets.json"),
    layouts: path.join(work, "layouts.json"),
    tokens: path.join(work, "tokens.json"),
    css: path.join(work, `${args.token}.css`),
    shell: backgroundImages ? path.join(work, "shell.json") : null,
    shellPng: backgroundImages ? path.join(work, "shell-stencil.png") : null,
    backgroundImages: backgroundImages || null,
    stagedAssets: path.join(work, "candidate-assets"),
  };
  mkdirSync(work, { recursive: true });

  const assets = run("derive-assets.mjs", [
    "--evidence", args.evidence, "--out", files.assets, "--stage", files.stagedAssets,
  ]);
  const layouts = run("derive-layouts.mjs", [
    "--evidence", args.evidence, "--out", files.layouts,
  ]);
  const firstPhase = await Promise.all([assets, layouts]);

  const backgroundTasks = [];
  if (args.renderBackgrounds) {
    mkdirSync(backgroundImages, { recursive: true });
    backgroundTasks.push(await run("reconstruct.mjs", [
      "--evidence", args.evidence,
      "--out", backgroundImages,
      "--no-text",
      "--exclude-assets", files.assets,
      "--shot",
      "--max", String(Math.floor(args.max)),
    ]));
  }
  if (backgroundImages) {
    backgroundTasks.push(await run("derive-shell.mjs", [
      "--images", backgroundImages,
      "--out", files.shell,
      "--png", files.shellPng,
      "--max", String(Math.floor(args.max)),
    ]));
  }

  const tokenArgs = [
    "--evidence", args.evidence, "--out", files.tokens, "--css", files.css,
    "--token", args.token, "--name", args.name,
  ];
  if (files.shell) tokenArgs.push("--shell", files.shell);
  const secondPhase = await Promise.all([run("derive-tokens.mjs", tokenArgs)]);

  console.log(JSON.stringify({
    status: "advisory-identity-evidence",
    note: "Reports and image-backed variants are draft evidence; interpretation and retention remain agent decisions.",
    elapsedMs: Date.now() - started,
    tasks: [...firstPhase, ...backgroundTasks, ...secondPhase].filter((item) => item && item.script),
    files,
  }, null, 2));
}

main().catch((error) => {
  console.error(error.stack || error.message);
  process.exit(1);
});
