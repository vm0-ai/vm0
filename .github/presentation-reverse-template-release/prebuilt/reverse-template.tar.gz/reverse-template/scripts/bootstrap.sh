#!/usr/bin/env bash
# bootstrap.sh — verify sandbox tools and install the small optional helpers.
#
# Poppler and LibreOffice are not assumed to be in the sandbox image.
# render-pages.mjs installs only the missing tools required by each input. This
# script only prepares the optional helpers: Canvas for reading pixels, lxml
# for OOXML.
# extract-pptx.py invokes the lxml branch automatically when its import fails.
#
#   bash scripts/bootstrap.sh [--pixels] [--pptx]
#   # no flags: prepare both optional helper groups
set -euo pipefail

NODE_LIBS="${PRT_NODE_LIBS:-/tmp/prt-nodelibs}"
PY_LIBS="${PRT_PY_LIBS:-/tmp/prt-pylibs}"
PYTHON_BIN="${PRT_PYTHON_BIN:-python3}"
LXML_SPEC="${PRT_LXML_SPEC:-lxml==6.0.1}"

want_pixels=0
want_pptx=0
if [ "$#" -eq 0 ]; then want_pixels=1; want_pptx=1; fi
for arg in "$@"; do
  case "$arg" in
    --pixels) want_pixels=1 ;;
    --pptx) want_pptx=1 ;;
    -h|--help) sed -n '2,11p' "$0"; exit 0 ;;
    *) echo "unknown flag: $arg" >&2; exit 1 ;;
  esac
done

missing=""
for tool in pdfinfo pdftocairo pdftohtml pdffonts soffice; do
  command -v "$tool" >/dev/null || missing="$missing $tool"
done
if [ -n "$missing" ]; then
  echo "system document tools absent:$missing"
  echo "  render-pages installs missing Poppler for PDF"
  echo "  render-pages installs missing LibreOffice 24.2.2.2 and Poppler for PPTX/PPT"
else
  echo "sandbox tools: Poppler and LibreOffice available"
fi

if [ "$want_pixels" = 1 ]; then
  if [ -d "$NODE_LIBS/node_modules/@napi-rs/canvas" ]; then
    echo "pixel helper: already present at $NODE_LIBS"
  else
    echo "pixel helper: installing @napi-rs/canvas into $NODE_LIBS"
    mkdir -p "$NODE_LIBS"
    ( cd "$NODE_LIBS" && npm install --silent --no-audit --no-fund @napi-rs/canvas >/dev/null )
  fi
  echo "pixel helper: ok ($(node -p "require('$NODE_LIBS/node_modules/@napi-rs/canvas/package.json').version"))"
fi

if [ "$want_pptx" = 1 ]; then
  if PYTHONPATH="$PY_LIBS${PYTHONPATH:+:$PYTHONPATH}" "$PYTHON_BIN" -c "import lxml" >/dev/null 2>&1; then
    echo "pptx helper: already present at $PY_LIBS"
  else
    echo "pptx helper: installing $LXML_SPEC into $PY_LIBS"
    mkdir -p "$PY_LIBS"
    "$PYTHON_BIN" -m pip install --quiet --disable-pip-version-check --upgrade \
      --target "$PY_LIBS" "$LXML_SPEC" >/dev/null
  fi
  PYTHONPATH="$PY_LIBS${PYTHONPATH:+:$PYTHONPATH}" "$PYTHON_BIN" \
    -c "import lxml; print('pptx helper: ok', lxml.__version__)"
fi

command -v agent-browser >/dev/null \
  && echo "agent-browser: ok" \
  || echo "agent-browser: MISSING — HTML extraction, reconstruction, and visual comparison will not work"
