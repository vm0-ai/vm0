#!/usr/bin/env node
/**
 * scaffold.mjs — package identity guidance and high-fidelity background images.
 *
 * This is a mechanical packager. Candidate roles stay advisory and the agent
 * remains free to correct or remove anything after reviewing the source.
 *
 *   node scaffold.mjs --tokens work/tokens.json --assets work/assets.json
 *                     --shell work/shell.json --layouts work/layouts.json
 *                     --background-images work/backgrounds
 *                     --color-system work/system.css
 *                     --out output --slug template-name --assemble
 */
import { createHash } from "node:crypto";
import {
  copyFileSync,
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import path from "node:path";

function parseArgs(argv) {
  const args = {
    tokens: "", assets: "", shell: "", layouts: "", backgroundImages: "",
    colorSystem: "", out: "", slug: "", force: false, assemble: false,
  };
  for (let i = 2; i < argv.length; i += 1) {
    const a = argv[i], next = argv[i + 1];
    if (a === "--tokens") { args.tokens = next; i += 1; }
    else if (a === "--assets") { args.assets = next; i += 1; }
    else if (a === "--shell") { args.shell = next; i += 1; }
    else if (a === "--layouts") { args.layouts = next; i += 1; }
    else if (a === "--background-images") { args.backgroundImages = next; i += 1; }
    else if (a === "--color-system") { args.colorSystem = next; i += 1; }
    else if (a === "--out") { args.out = next; i += 1; }
    else if (a === "--slug") { args.slug = next; i += 1; }
    else if (a === "--assemble") args.assemble = true;
    else if (a === "--force") args.force = true;
    else if (a === "--help" || a === "-h") { usage(); process.exit(0); }
    else throw new Error(`Unknown argument: ${a}`);
  }
  if (!args.tokens || !args.out || !args.slug) { usage(); process.exit(1); }
  if (args.assemble) {
    for (const key of ["assets", "shell", "layouts", "backgroundImages"]) {
      if (!args[key]) throw new Error(`--assemble requires --${key.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`)}`);
    }
  }
  return args;
}

function usage() {
  console.log(`Usage: node scaffold.mjs --tokens <tokens.json> --out <dir> --slug <name>
                        [--assets <assets.json>] [--shell <shell.json>]
                        [--layouts <layouts.json>] [--background-images <dir>]
                        [--color-system <token.css>] [--assemble] [--force]`);
}

const readJson = (file, fallback = null) => file && existsSync(file)
  ? JSON.parse(readFileSync(file, "utf8")) : fallback;
const sha = (file) => createHash("sha256").update(readFileSync(file)).digest("hex").slice(0, 16);
const rel = (from, file) => path.relative(from, file).split(path.sep).join("/");
const safe = (value) => String(value || "asset").replace(/[^A-Za-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "") || "asset";
const skillSlug = (value) => String(value || "extracted-presentation").toLowerCase()
  .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 64).replace(/-+$/g, "") || "extracted-presentation";

function writer(force) {
  const written = [], skipped = [];
  const write = (file, content) => {
    mkdirSync(path.dirname(file), { recursive: true });
    if (existsSync(file) && !force) { skipped.push(file); return false; }
    writeFileSync(file, content);
    written.push(file);
    return true;
  };
  const copy = (source, destination) => {
    mkdirSync(path.dirname(destination), { recursive: true });
    if (existsSync(destination) && !force) { skipped.push(destination); return false; }
    copyFileSync(source, destination);
    written.push(destination);
    return true;
  };
  return { write, copy, written, skipped };
}

function candidateGroups(assets) {
  return [
    ["brand-mark", assets?.brandMarkCandidate ? [assets.brandMarkCandidate] : []],
    ["brand-lockup", assets?.lockupCandidates || []],
    ["icon", assets?.iconCandidates || []],
    ["vector-icon", assets?.vectorIconCandidates || []],
  ];
}

function copyIdentityAssets(assets, templateDir, io, assemble) {
  const records = [], missing = [];
  for (const [role, candidates] of candidateGroups(assets)) {
    candidates.forEach((candidate, index) => {
      const source = candidate.staged || candidate.file;
      if (!source || !existsSync(source)) {
        missing.push({ role, id: candidate.id || null, source: source || null });
        return;
      }
      const ext = path.extname(source);
      const name = `${safe(role)}-${String(index + 1).padStart(2, "0")}${ext}`;
      const destination = path.join(templateDir, "assets", "identity", name);
      if (assemble) io.copy(source, destination);
      records.push({
        role: `${role}-candidate`,
        id: candidate.id || null,
        file: assemble ? rel(templateDir, destination) : null,
        sha256: sha(source),
        slides: candidate.slides || [],
        observedBox: candidate.box || candidate.anchor || null,
        status: "advisory",
        suggestedHandling: "preserve-source-bytes",
      });
    });
  }
  return { records, missing };
}

function copyFontPayloads(typography, templateDir, io, assemble) {
  const embedded = typography?.sources?.embeddedFonts || [];
  return embedded.map((font, index) => {
    const { file, ...metadata } = font;
    if (!file || !existsSync(file)) {
      return { ...metadata, sourceFile: file ? path.basename(file) : null, packagedFile: null };
    }
    const ext = path.extname(file) || ".bin";
    const name = `${safe(font.family || "font")}-${safe(font.style || "source")}-${String(index + 1).padStart(2, "0")}${ext}`;
    const destination = path.join(templateDir, "assets", "fonts", name);
    if (assemble) io.copy(file, destination);
    return {
      ...metadata,
      sourceFile: path.basename(file),
      packagedFile: assemble ? rel(templateDir, destination) : null,
      sha256: sha(file),
    };
  });
}

function copyBackgrounds(shell, sourceDir, assets, templateDir, io, assemble) {
  const variants = [], sources = [], missing = [];
  const counters = new Map();
  const numberedName = (role, suffix, ext) => {
    const key = `${role}|${suffix}`;
    const index = (counters.get(key) || 0) + 1;
    counters.set(key, index);
    return `${safe(role)}${suffix ? `-${suffix}` : ""}-${String(index).padStart(2, "0")}${ext}`;
  };
  for (const [index, variant] of (shell?.variants || []).entries()) {
    const source = variant.example ? path.join(sourceDir, variant.example) : "";
    if (!source || !existsSync(source)) {
      missing.push({ kind: "rendered", id: variant.id, example: variant.example || null });
      continue;
    }
    const ext = path.extname(source) || ".png";
    const role = variant.templateRole || "background";
    const name = numberedName(role, "", ext);
    const destination = path.join(templateDir, "assets", "backgrounds", name);
    if (assemble) io.copy(source, destination);
    variants.push({
      id: `${safe(role)}-${String(index + 1).padStart(2, "0")}`,
      file: assemble ? rel(templateDir, destination) : null,
      sha256: sha(source),
      sourceSlides: variant.slides || [],
      templateRole: role,
      sourceKind: "text-free-render",
      status: "advisory",
      suggestedUse: "full-stage image layer",
    });
  }

  for (const candidate of assets?.backgroundCandidates || []) {
    const source = candidate.staged || candidate.file;
    if (!source || !existsSync(source)) {
      missing.push({ kind: "source", id: candidate.id || null, example: source || null });
      continue;
    }
    const ext = path.extname(source) || ".bin";
    const role = candidate.templateRole || "content";
    const name = numberedName(role, "source", ext);
    const destination = path.join(templateDir, "assets", "backgrounds", name);
    if (assemble) io.copy(source, destination);
    sources.push({
      id: candidate.id || null,
      file: assemble ? rel(templateDir, destination) : null,
      sha256: sha(source),
      sourceSlides: candidate.fullStageSlides?.length ? candidate.fullStageSlides : (candidate.slides || []),
      templateRole: role,
      sourceKind: "original-extracted-bytes",
      status: "advisory",
      suggestedUse: "full-stage image layer",
    });
  }
  return { variants, sources, missing };
}

function colorLines(colors) {
  return Object.entries(colors || {})
    .filter(([key, value]) => !key.startsWith("_") && typeof value === "string")
    .map(([key, value]) => `- \`${key}\`: \`${value}\``)
    .join("\n") || "- no colour value was recovered";
}

function slidesText(slides) {
  return slides?.length ? slides.join(", ") : "unresolved source slides";
}

function boxText(box) {
  if (!box) return "";
  return `; observed near x ${box.x}%, y ${box.y}%, width ${box.w}%, height ${box.h}%`;
}

function identityLines(identity) {
  if (!identity.records.length) return "- no separable identity asset was confirmed";
  return identity.records.map((record) =>
    `- \`${record.file}\` — ${record.role}; source slides ${slidesText(record.slides)}${boxText(record.observedBox)}`
  ).join("\n");
}

function backgroundLines(backgrounds) {
  const rows = [...backgrounds.variants, ...backgrounds.sources];
  if (!rows.length) return "- no clean background image was packaged";
  return rows.map((variant) =>
    `- \`${variant.file}\` — ${variant.sourceKind === "original-extracted-bytes" ? "original extracted bytes" : "text-free rendered variant"} for ${variant.templateRole || "unresolved"} slides; source slides ${slidesText(variant.sourceSlides)}`
  ).join("\n");
}

function imageEvidence(assets, backgrounds) {
  return {
    backgroundImages: backgrounds.variants.length + backgrounds.sources.length,
    renderedBackgrounds: backgrounds.variants.length,
    sourceBackgrounds: backgrounds.sources.length,
    contentImages: (assets?.contentCandidates || []).length,
    status: backgrounds.variants.length + backgrounds.sources.length || (assets?.contentCandidates || []).length
      ? "observed"
      : "not-observed",
    authoringConstraint: null,
  };
}

function imageLayerIntro(evidence, occupied) {
  if (evidence.backgroundImages) {
    return `${evidence.renderedBackgrounds} text-free rendered background variant(s) and ${evidence.sourceBackgrounds}
original background asset(s) were packaged. They are optional visual
materials rather than named layouts. ${occupied} occupied-region candidate(s) were observed; inspect the
selected image before placing live content. A variant with source text, data, or one-off semantic imagery
still baked into it should normally be left out.`;
  }

  const sourceObservation = evidence.contentImages
    ? `${evidence.contentImages} one-off source image candidate(s) were observed as content.`
    : "No source image candidate was observed by this extraction.";
  return `No clean background image was packaged. ${sourceObservation} This leaves image treatment unresolved;
it does not restrict a future AI from adding imagery when it helps the new content. Use the observed visual
language to make any new element fit.`;
}

function observationText(rows, fallback = "unresolved") {
  const values = (rows || []).slice(0, 8).map((item) => {
    const unit = item.unit === "ratio" ? "×" : (item.unit || "");
    const count = item.count ? ` (${item.count} observations)` : "";
    return `\`${item.value}${unit}\`${count}`;
  });
  return values.join(", ") || fallback;
}

function scaleText(scale) {
  const values = Object.entries(scale || {}).filter(([, value]) => value != null);
  return values.length
    ? values.map(([role, value]) => `\`${role} ${value}cqw\``).join(", ")
    : "unresolved";
}

function pdfFontText(pdfFonts) {
  const names = [...new Set((pdfFonts || []).map((font) =>
    String(font.name || "").replace(/^[A-Z]{6}\+/, "")).filter(Boolean))];
  if (!names.length) return "none recorded";
  const shown = names.slice(0, 12).map((name) => `\`${name}\``).join(", ");
  return names.length > 12 ? `${shown} and ${names.length - 12} more` : shown;
}

function fontPayloadLines(type, embeddedFonts, assets) {
  const lines = [];
  for (const font of embeddedFonts.slice(0, 12)) {
    const availability = font.packagedFile
      ? `packaged as \`${font.packagedFile}\``
      : "metadata only; no usable file was packaged";
    lines.push(`- ${font.family || "unresolved family"} ${font.style || ""} — ${availability}${font.directlyUsable === false ? "; not directly usable" : ""}`);
  }
  for (const font of (assets?.iconFonts || []).slice(0, 8)) {
    const glyphs = (font.glyphs || []).slice(0, 16).map((glyph) => glyph.name).join(", ") || "unresolved glyphs";
    lines.push(`- icon font \`${font.family}\` — observed glyphs: ${glyphs}`);
  }
  const links = type.sources?.webFontLinks || [];
  if (links.length) lines.push(`- declared web-font sources: ${links.slice(0, 6).map((link) => `\`${link}\``).join(", ")}`);
  lines.push(`- PDF font names observed: ${pdfFontText(type.sources?.pdfFonts)}`);
  return lines.join("\n");
}

function percentage(value) {
  if (!Number.isFinite(value)) return "an unresolved share";
  return `${Math.round((value <= 1 ? value * 100 : value) * 10) / 10}% of source slides`;
}

function layoutLines(layouts) {
  const archetypes = layouts?.archetypes || [];
  if (!archetypes.length) return "- no stable layout tendency was confirmed";
  return archetypes.slice(0, 8).map((layout) => {
    const columns = layout.columns || [];
    const geometry = columns.length
      ? columns.map((column) => `x ${column.x}%, width ${column.w}%${column.media ? " (media)" : ""}`).join("; ")
      : "no reusable column geometry confirmed";
    const vertical = [
      Number.isFinite(layout.titleTopCqh) ? `title near ${layout.titleTopCqh}% height` : null,
      Number.isFinite(layout.bodyTopCqh) ? `body near ${layout.bodyTopCqh}% height` : null,
    ].filter(Boolean).join(", ");
    // A centred stack is one measure, not a column count. Saying "2-column" of
    // slides whose every block is centred describes a layout the deck never had.
    const shape = layout.id === "centred-stack"
      ? "centred stack"
      : `${columns.length || 1}-column tendency`;
    const repeat = layout.repetition;
    const repeated = repeat
      ? `; repeated ${repeat.arrangement} of ${repeat.count} panels (${repeat.columns} across × ${repeat.rows} down, item ${repeat.itemWidthCqw}% × ${repeat.itemHeightCqh}%, gaps ${repeat.gapCqw}% × ${repeat.gapCqh}%)`
      : "";
    return `- ${percentage(layout.share)}: ${shape} (${geometry})${vertical ? `; ${vertical}` : ""}${layout.align ? `; ${layout.align}-aligned` : ""}${repeated}`;
  }).join("\n");
}

function uncertaintyLines(tokens, assets, identity, backgrounds) {
  const notes = [
    ...(tokens.reviewNotes || []),
    ...(assets.reviewNotes || []),
    ...identity.missing.map((item) => `identity candidate ${item.id || item.role} had no readable source file`),
    ...backgrounds.missing.map((item) => `background candidate ${item.id ?? "unknown"} had no readable source file`),
  ];
  return notes.length ? notes.slice(0, 12).map((note) => `- ${note}`).join("\n") : "- no additional extraction warning was recorded";
}

function designSystem(tokens, identity, backgrounds, layouts, embeddedFonts, assets, shell) {
  const type = tokens.typography || {};
  const stage = tokens.stage || {};
  const layout = tokens.layout || {};
  const occupied = (shell?.marks || []).filter((mark) => mark.assertive !== false).length;
  const evidence = imageEvidence(assets, backgrounds);
  return `# ${tokens.name || tokens.token || "Extracted presentation identity"}

This package combines measured identity guidance with any high-fidelity visual assets recovered from the
source. All roles and classifications are advisory and may be corrected after inspecting the source. A
future AI authors the actual slides directly in HTML and CSS; this document and the assets inform its visual
decisions. Extraction counts describe what was observed, not what is allowed. An unobserved element remains
an open design choice unless the user or source explicitly states a constraint.

## Image layer

${imageLayerIntro(evidence, occupied)}

${backgroundLines(backgrounds)}

## Identity assets

${identity.records.length} original logo, lockup, or icon candidate(s) were packaged under
\`assets/identity/\`. Their bytes are preserved. Avoid placing a separate mark when the selected background
already contains it.

${identityLines(identity)}

## Colour guidance

The role names below are inferred from observed use unless the source declared them explicitly. The
corresponding CSS file is copied under \`../color-systems/\`.

${colorLines(tokens.colors)}

## Typography guidance

- display family candidate: \`${type.display || "unresolved"}\`
- body family candidate: \`${type.body || "unresolved"}\`
- CJK display candidate: \`${type.cjkDisplay || "unresolved"}\`
- CJK body candidate: \`${type.cjkBody || "unresolved"}\`
- observed type scale: ${scaleText(type.scale)}
- observed weights: ${observationText(type.weights)}
- observed line heights: ${observationText(type.lineHeights)}
- observed letter spacing: ${observationText(type.letterSpacing)}

Font-source evidence:

${fontPayloadLines(type, embeddedFonts, assets)}

Do not treat preserved obfuscated font payloads as directly installable.

## Layout guidance

- observed stage: ${stage.w || "unresolved"} × ${stage.h || "unresolved"}
- common left margin: ${layout.marginLeftCqw ?? "unresolved"}% of stage width
- common title top: ${layout.titleTopCqh ?? "unresolved"}% of stage height
- common content range: ${layout.contentTopCqh ?? "unresolved"}%–${layout.contentBottomCqh ?? "unresolved"}% of stage height

Observed tendencies:

${layoutLines(layouts)}

These measurements are reference guidance. Choose the HTML structure from the new content; they are not
layout IDs, traced coordinates, or a mandatory page sequence. Prefer CSS Grid or Flexbox for the live
content flow when they fit. Keep absolute positioning mainly for the background layer, fixed chrome,
decoration, and intentional overlays.

## Uncertainty

Keep missing fonts, ambiguous identity ownership, flattened assets, and inferred colour roles explicit. The
package intentionally contains no source-deck replica or similarity result.

${uncertaintyLines(tokens, assets, identity, backgrounds)}
`;
}

function generatedSkill(tokens) {
  const title = tokens.name || tokens.token || "extracted";
  return `---
name: ${skillSlug(tokens.token)}
description: ${JSON.stringify(`Author presentation HTML directly using the source-backed ${title} identity, typography, and image-layer guidance.`)}
---

# Author ${title} slides directly in HTML

Use this folder as visual guidance while writing the final slide HTML and CSS yourself. It describes a
visual language; it does not provide a slide data model, component API, or fixed renderer.

## Authoring guidance

- Read \`design-system.md\` for the concise visual language, then inspect assets relevant to the new deck.
- Create semantic HTML for each slide and style it with CSS. Keep new text, charts, tables, labels, and
  diagrams as live HTML or SVG.
- Prefer CSS Grid or Flexbox for live content layout so columns, rows, and text remain coherent when content
  changes. Use absolute positioning mainly for backgrounds, fixed chrome, decoration, and intentional
  overlays where document flow is not appropriate.
- Treat every extracted layout as a reference layout. If another layout would communicate the new content
  better, use it instead. No matching layout ID, column count, or source-page sequence is required.
- Treat an element not observed in the source as unresolved, not forbidden. You may introduce it when it
  helps the new content, using the observed visual language to make it fit. Treat only a constraint explicitly
  attributed to the user or source as a prohibition.
- A packaged background may be used as a full-stage image when it fits the content. It is optional visual
  material, not a prebuilt slide template; author the live content layer yourself.
- Apply the observed colour and typography guidance where it fits. Keep unavailable fonts and uncertain
  classifications explicit rather than inventing certainty.
- Use packaged identity assets when relevant and avoid duplicating marks already present in a background.
- Review the rendered result for legibility, accidental source-specific content, and visual continuity.

The extraction measurements are already summarized in \`design-system.md\`. There is no slide JSON,
layout API, or JSON-to-HTML step in this package. Author the HTML from the new content instead of recreating
the source page sequence.
`;
}

function main() {
  const args = parseArgs(process.argv);
  const tokens = readJson(args.tokens, {});
  const assets = readJson(args.assets, {});
  const shell = readJson(args.shell, {});
  const layouts = readJson(args.layouts, {
    schema: "presentation-layout-guidance/1",
    interpretation: { status: "unavailable" },
  });
  const templateDir = path.join(path.resolve(args.out), args.slug);
  const io = writer(args.force);
  mkdirSync(templateDir, { recursive: true });

  const identity = copyIdentityAssets(assets, templateDir, io, args.assemble);
  const embeddedFonts = copyFontPayloads(tokens.typography, templateDir, io, args.assemble);
  const backgrounds = copyBackgrounds(shell, path.resolve(args.backgroundImages || "."), assets, templateDir, io, args.assemble);
  const evidence = imageEvidence(assets, backgrounds);

  io.write(path.join(templateDir, "SKILL.md"), generatedSkill(tokens));
  io.write(path.join(templateDir, "design-system.md"),
    designSystem(tokens, identity, backgrounds, layouts, embeddedFonts, assets, shell));

  if (args.colorSystem) {
    if (!existsSync(args.colorSystem)) throw new Error(`Colour system not found: ${args.colorSystem}`);
    io.copy(args.colorSystem, path.join(path.resolve(args.out), "color-systems", `${tokens.token || "extracted_system"}.css`));
  }

  console.log(JSON.stringify({
    status: "advisory-image-backed-draft",
    dir: templateDir,
    identityAssets: identity.records.length,
    backgroundVariants: backgrounds.variants.length,
    originalBackgroundAssets: backgrounds.sources.length,
    embeddedFontPayloads: embeddedFonts.filter((font) => font.packagedFile).length,
    evidenceSemantics: {
      imagery: evidence.status,
      unobserved: "unresolved",
      inferredAuthoringConstraints: evidence.authoringConstraint ? 1 : 0,
    },
    written: io.written,
    skipped: io.skipped,
    review: [
      "confirm identity ownership and candidate roles against the source",
      "remove any background that retains source-specific semantic content",
      "edit the generated guidance when the evidence supports a better interpretation",
    ],
  }, null, 2));
}

main();
