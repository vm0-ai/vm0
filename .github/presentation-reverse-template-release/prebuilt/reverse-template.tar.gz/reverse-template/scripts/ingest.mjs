#!/usr/bin/env node
/**
 * ingest.mjs — take whatever the user uploaded and hand back a work plan.
 *
 * A web-chat attachment arrives as `[Web file]\n  [ID] <uuid>` — no filename and
 * no mimetype. `okou web download-file` writes it to an extension-less path and
 * only then reports the type, so detection has to happen after the download and
 * cannot trust an extension. An archive may also contain other archives, a
 * whole exported HTML site, or a folder of page images.
 *
 *   node ingest.mjs --file-id <uuid> --work <dir>
 *   node ingest.mjs --input <path>   --work <dir>
 *
 * Prints a plan: what was found, which extractor to run for each deck, and what
 * was deliberately skipped. Unpacks safely — no absolute paths, no `..`, and a
 * total-size ceiling, because a 1 GB upload is permitted by the platform.
 */
import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { promisify } from "node:util";
import { mkdirSync, existsSync, statSync, readdirSync, readFileSync } from "node:fs";
import path from "node:path";

import { convertLegacyPpt } from "./libreoffice.mjs";

const execFileAsync = promisify(execFile);

const ARCHIVE_LIMIT_BYTES = 2 * 1024 * 1024 * 1024;
const ARCHIVE_LIMIT_FILES = 20000;
const IMAGE_EXT = new Set([".png", ".jpg", ".jpeg", ".webp", ".avif", ".gif", ".bmp", ".tif", ".tiff"]);

function parseArgs(argv) {
  const args = {
    fileId: "",
    input: "",
    work: "",
    cli: process.env.PRT_OKOU_CLI || process.env.PRT_ZERO_CLI || "",
  };
  for (let i = 2; i < argv.length; i += 1) {
    const a = argv[i], next = argv[i + 1];
    if (a === "--file-id") { args.fileId = next; i += 1; }
    else if (a === "--input") { args.input = next; i += 1; }
    else if (a === "--work") { args.work = next; i += 1; }
    else if (a === "--help" || a === "-h") { usage(); process.exit(0); }
    else throw new Error(`Unknown argument: ${a}`);
  }
  if ((!args.fileId && !args.input) || !args.work) { usage(); process.exit(1); }
  if (args.fileId && !/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/iu.test(args.fileId)) {
    throw new Error(`Invalid web file id: ${args.fileId}`);
  }
  return args;
}

function usage() {
  console.log(`Usage: node ingest.mjs (--file-id <uuid> | --input <path>) --work <dir>

Downloads (when given a file id), sniffs the real type, unpacks archives safely,
and prints a JSON plan naming the extractor for every deck it found.`);
}

async function run(cmd, cmdArgs, opts = {}) {
  return (await execFileAsync(cmd, cmdArgs, { maxBuffer: 64 * 1024 * 1024, ...opts })).stdout;
}

async function sniff(file) {
  let magic = "";
  try { magic = (await run("file", ["-b", file])).trim(); } catch { /* file(1) missing */ }
  const head = readFileSync(file, { encoding: "latin1", flag: "r" }).slice(0, 4096);
  if (head.startsWith("%PDF")) return { kind: "pdf", magic };
  if (head.startsWith("PK")) {
    // .pptx / .key / .odp are all zips; look for their marker entries
    let listing = "";
    try { listing = await run("unzip", ["-Z1", file]); } catch { /* not readable as zip */ }
    if (/^ppt\/presentation\.xml$/m.test(listing)) return { kind: "pptx", magic };
    if (/^content\.xml$/m.test(listing) && /presentation/i.test(listing)) return { kind: "odp", magic };
    if (/\.key\//.test(listing) || /^Index\/Document\.iwa$/m.test(listing)) return { kind: "keynote", magic };
    return { kind: "zip", magic, entries: listing.split("\n").filter(Boolean).length };
  }
  if (/^\s*<(!doctype html|html)/i.test(head)) return { kind: "html", magic };
  if (/gzip compressed/i.test(magic)) return { kind: "tgz", magic };
  if (/POSIX tar/i.test(magic)) return { kind: "tar", magic };
  if (/7-zip/i.test(magic)) return { kind: "7z", magic, unsupported: true };
  if (/RAR archive/i.test(magic)) return { kind: "rar", magic, unsupported: true };
  if (/Composite Document File|CDFV2/i.test(magic)) {
    const legacyPpt = path.extname(file).toLowerCase() === ".ppt" || /PowerPoint/i.test(magic);
    return legacyPpt
      ? { kind: "ppt-binary", magic }
      : { kind: "cdf", magic, unsupported: true };
  }
  if (/PNG image|JPEG image|WebP/i.test(magic)) return { kind: "image", magic };
  return { kind: "unknown", magic };
}

function unsafeEntries(listing) {
  return listing.filter((name) => name.startsWith("/") || name.includes("..") || /^[A-Za-z]:/.test(name));
}

async function unpack(file, kind, dest) {
  mkdirSync(dest, { recursive: true });
  if (kind === "zip") {
    const listing = (await run("unzip", ["-Z1", file])).split("\n").filter(Boolean);
    if (listing.length > ARCHIVE_LIMIT_FILES) throw new Error(`archive has ${listing.length} entries (limit ${ARCHIVE_LIMIT_FILES})`);
    const bad = unsafeEntries(listing);
    if (bad.length) throw new Error(`archive contains unsafe paths: ${bad.slice(0, 3).join(", ")}`);
    await run("unzip", ["-qq", "-o", file, "-d", dest]);
    return;
  }
  if (kind === "tar" || kind === "tgz") {
    const listing = (await run("tar", [kind === "tgz" ? "-tzf" : "-tf", file])).split("\n").filter(Boolean);
    const bad = unsafeEntries(listing);
    if (bad.length) throw new Error(`archive contains unsafe paths: ${bad.slice(0, 3).join(", ")}`);
    await run("tar", [kind === "tgz" ? "-xzf" : "-xf", file, "-C", dest]);
    return;
  }
  throw new Error(`cannot unpack ${kind} in this sandbox`);
}

function walk(dir, depth = 0) {
  const out = [];
  if (depth > 8) return out;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (entry.name.startsWith("__MACOSX") || entry.name === ".DS_Store") continue;
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(p, depth + 1));
    else out.push(p);
  }
  return out;
}

const totalSize = (files) =>
  files.reduce((sum, f) => { try { return sum + statSync(f).size; } catch { return sum; } }, 0);

function planFor(kind, file) {
  const q = JSON.stringify(file);
  switch (kind) {
    case "pdf": return { extractor: "extract-pdf.mjs", command: `node scripts/extract-pdf.mjs --input ${q} --out <evidence.json> --pages <dir> --media <dir>` };
    case "pptx": return { extractor: "extract-pptx.py", command: `python3 scripts/extract-pptx.py --input ${q} --out <evidence.json> --media <dir>` };
    case "html": return { extractor: "extract-html.mjs", command: `node scripts/extract-html.mjs --input ${q} --out <evidence.json>` };
    default: return null;
  }
}

async function classify(file, decks, skipped, notes, work, forcedKind) {
  const ext = path.extname(file).toLowerCase();
  const kind = forcedKind
    || (ext === ".pdf" ? "pdf" : ext === ".pptx" ? "pptx" : (ext === ".html" || ext === ".htm") ? "html"
      : IMAGE_EXT.has(ext) ? "image" : ext === ".ppt" ? "ppt-binary" : ext === ".key" ? "keynote"
      : ext === ".odp" ? "odp" : "other");
  if (kind === "image") { skipped.push({ file, kind, why: "image asset" }); return; }
  if (kind === "ppt-binary") {
    const fingerprint = createHash("sha256").update(path.resolve(file)).digest("hex").slice(0, 10);
    const stem = path.basename(file, ext).replace(/[^A-Za-z0-9._-]+/g, "-") || "legacy-presentation";
    const converted = path.resolve(work, "converted", `${stem}-${fingerprint}.pptx`);
    const conversion = await convertLegacyPpt(file, converted);
    decks.push({
      file: converted,
      kind: "pptx",
      originalFile: file,
      originalKind: "ppt-binary",
      conversion: {
        tool: "LibreOffice",
        version: conversion.libreOfficeVersion,
      },
      ...planFor("pptx", converted),
    });
    notes.push(`${path.basename(file)}: converted legacy PPT with LibreOffice ${conversion.libreOfficeVersion} → ${converted}`);
    return;
  }
  const plan = planFor(kind, file);
  if (plan) { decks.push({ file, kind, ...plan }); return; }
  const why = kind === "keynote" ? "Keynote bundle — no reader in this sandbox; export to .pptx or .pdf"
    : kind === "odp" ? "ODP — no reader in this sandbox; export to .pptx or .pdf"
    : "not a deck";
  skipped.push({ file, kind, why });
}

async function main() {
  const args = parseArgs(process.argv);
  mkdirSync(args.work, { recursive: true });
  const notes = [];
  let source = args.input;
  let sourceKindHint = "";

  if (args.fileId) {
    const dest = path.join(args.work, `upload-${args.fileId}`);
    const cli = args.cli || `npx --yes --package="${process.env.CLI_PKG_URL || ""}" okou`;
    const stdout = await run("bash", ["-lc", `${cli} web download-file ${args.fileId} -o ${JSON.stringify(dest)}`]);
    const line = stdout.trim().split("\n").filter((l) => l.trim().startsWith("{")).pop();
    const meta = line ? JSON.parse(line) : { path: dest };
    source = meta.path;
    if (meta.mimetype === "application/vnd.ms-powerpoint") sourceKindHint = "ppt-binary";
    notes.push(`downloaded ${args.fileId} → ${source}${meta.mimetype ? ` (${meta.mimetype}, ${meta.size} bytes)` : ""}`);
    notes.push("the prompt carried no filename or mimetype; the type below comes from content sniffing");
  }

  if (!existsSync(source)) throw new Error(`Not found: ${source}`);

  const decks = [];
  const skipped = [];

  if (statSync(source).isDirectory()) {
    for (const f of walk(source)) await classify(f, decks, skipped, notes, args.work);
  } else {
    const info = await sniff(source);
    const detectedKind = info.kind === "cdf" && sourceKindHint ? sourceKindHint : info.kind;
    notes.push(`${path.basename(source)}: ${detectedKind}${detectedKind !== info.kind ? " (from upload MIME)" : ""}${info.magic ? ` (${info.magic})` : ""}`);
    if (info.unsupported && detectedKind === info.kind) {
      skipped.push({
        file: source, kind: info.kind,
        why: info.kind === "7z" || info.kind === "rar"
          ? "the platform accepts this upload type but the sandbox has no 7z/unrar; ask the user to re-send as .zip"
          : "legacy OLE file is not identifiable as a PowerPoint presentation",
      });
    } else if (info.kind === "zip" || info.kind === "tar" || info.kind === "tgz") {
      const dest = path.join(args.work, "unpacked");
      await unpack(source, info.kind, dest);
      const files = walk(dest);
      const bytes = totalSize(files);
      notes.push(`unpacked ${files.length} files, ${(bytes / 1048576).toFixed(1)} MB`);
      if (bytes > ARCHIVE_LIMIT_BYTES) throw new Error(`unpacked size ${bytes} exceeds limit`);
      for (const f of files) await classify(f, decks, skipped, notes, args.work);
    } else {
      await classify(source, decks, skipped, notes, args.work, detectedKind);
    }
  }

  // A folder of page images is a deck too — the only route for a picture-only export.
  const images = skipped.filter((s) => s.kind === "image");
  if (!decks.length && images.length >= 3) {
    decks.push({
      file: path.dirname(images[0].file), kind: "images", count: images.length,
      extractor: "extract-pixels.mjs",
      command: `node scripts/extract-pixels.mjs --images ${JSON.stringify(path.dirname(images[0].file))} --out <evidence.json>`,
    });
    notes.push(`${images.length} images and no deck file — treating the folder as a page-image deck`);
  }

  console.log(JSON.stringify({ source, work: args.work, decks, skipped, notes }, null, 2));
}

main().catch((error) => {
  console.error(error.stack || error.message);
  process.exit(1);
});
