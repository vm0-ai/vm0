#!/usr/bin/env node
/**
 * derive-tokens.mjs — evidence.json → design tokens.
 *
 * Turns the raw census (colour areas, text sizes, corner radii, shape kinds)
 * into the things a v3 `design-system.md` actually needs: nine role colours,
 * the full derived token set, a type scale, observed corner radii, layout margins,
 * chrome candidates, and an element census.
 *
 *   node derive-tokens.mjs --evidence <evidence.json> [--evidence <more.json>]
 *                          --out <tokens.json> [--css <color-systems/<token>.css>]
 *                          [--token <snake_case>] [--name "Display Name"]
 *
 * The colour work is the delicate part. A source deck names no roles, so roles
 * are inferred from how a colour is used, and the derived tokens (`--k*`, `--g*`,
 * `--t*`, `--o*`) are then *computed for contrast* rather than copied — a brand
 * hue that reads fine as a 2cqw block is often unreadable as body text.
 */
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";

function parseArgs(argv) {
  const args = { evidence: [], out: "", css: "", token: "", name: "", shell: "" };
  for (let i = 2; i < argv.length; i += 1) {
    const a = argv[i], next = argv[i + 1];
    if (a === "--evidence") { args.evidence.push(next); i += 1; }
    else if (a === "--out") { args.out = next; i += 1; }
    else if (a === "--css") { args.css = next; i += 1; }
    else if (a === "--token") { args.token = next; i += 1; }
    else if (a === "--name") { args.name = next; i += 1; }
    else if (a === "--shell") { args.shell = next; i += 1; }
    else if (a === "--help" || a === "-h") { usage(); process.exit(0); }
    else throw new Error(`Unknown argument: ${a}`);
  }
  if (!args.evidence.length || !args.out) { usage(); process.exit(1); }
  if (!args.token) args.token = "extracted_system";
  return args;
}

function usage() {
  console.log(`Usage: node derive-tokens.mjs --evidence <evidence.json> [--evidence <more>]
                             --out <tokens.json> [--css <out.css>]
                             [--token <snake_case>] [--name "Display Name"]`);
}

/* ------------------------------ colour maths ------------------------------ */

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const toRgb = (hex) => {
  const h = String(hex || "").replace("#", "");
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
  return [parseInt(full.slice(0, 2), 16), parseInt(full.slice(2, 4), 16), parseInt(full.slice(4, 6), 16)];
};
const toHex = (rgb) => "#" + rgb.map((v) => clamp(Math.round(v), 0, 255).toString(16).padStart(2, "0")).join("").toUpperCase();

function luminance(hex) {
  const srgb = toRgb(hex).map((v) => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * srgb[0] + 0.7152 * srgb[1] + 0.0722 * srgb[2];
}
function contrast(a, b) {
  const l1 = luminance(a), l2 = luminance(b);
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}
function toHsl(hex) {
  const [r, g, b] = toRgb(hex).map((v) => v / 255);
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  const l = (max + min) / 2;
  if (max === min) return [0, 0, l];
  const d = max - min;
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
  let h;
  if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
  else if (max === g) h = ((b - r) / d + 2) / 6;
  else h = ((r - g) / d + 4) / 6;
  return [h * 360, s, l];
}
function fromHsl(h, s, l) {
  h = ((h % 360) + 360) % 360 / 360;
  if (s === 0) { const v = Math.round(l * 255); return toHex([v, v, v]); }
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  const hue = (t) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };
  return toHex([hue(h + 1 / 3) * 255, hue(h) * 255, hue(h - 1 / 3) * 255]);
}
const lightness = (hex) => toHsl(hex)[2];
/**
 * Chroma, not HSL saturation. A pale peach card (#FFF1E8) has HSL saturation
 * 1.0 and would outrank the actual brand orange; its RGB chroma is 0.09, which
 * is the truth. Every "is this a hue or a neutral?" test uses this.
 */
const chroma = (hex) => {
  const [r, g, b] = toRgb(hex);
  return (Math.max(r, g, b) - Math.min(r, g, b)) / 255;
};

/** Darken (or lighten) a hue until it reads at `target` contrast against `on`. */
function forceContrast(hex, on, target = 4.5) {
  if (contrast(hex, on) >= target) return hex;
  const [h, s] = toHsl(hex);
  const onLight = luminance(on) > 0.5;
  let best = hex, bestRatio = contrast(hex, on);
  for (let step = 1; step <= 100; step += 1) {
    const l = onLight ? 0.5 - step * 0.005 : 0.5 + step * 0.005;
    if (l <= 0 || l >= 1) break;
    const candidate = fromHsl(h, Math.min(0.95, s), l);
    const ratio = contrast(candidate, on);
    if (ratio > bestRatio) { best = candidate; bestRatio = ratio; }
    if (ratio >= target) return candidate;
  }
  return best;
}

/** Pick whichever of the deck's own ink / paper reads best on `hex`. */
const onColor = (hex, ink, paper) => (contrast(hex, paper) >= contrast(hex, ink) ? paper : ink);

const nearlyEqual = (a, b, tol = 14) => {
  const [r1, g1, b1] = toRgb(a), [r2, g2, b2] = toRgb(b);
  return Math.abs(r1 - r2) + Math.abs(g1 - g2) + Math.abs(b1 - b2) <= tol * 3;
};
const hueDistance = (a, b) => {
  const d = Math.abs(toHsl(a)[0] - toHsl(b)[0]);
  return Math.min(d, 360 - d);
};

/* ------------------------------- clustering ------------------------------- */

/** 1-D clustering with a relative gap: values within `tol` of the running mean merge. */
function cluster(values, tol = 0.12) {
  const sorted = [...values].sort((a, b) => a.value - b.value);
  const out = [];
  for (const item of sorted) {
    const last = out[out.length - 1];
    if (last && Math.abs(item.value - last.center) <= Math.max(0.06, last.center * tol)) {
      last.weight += item.weight;
      last.members.push(item.value);
      last.center = last.members.reduce((s, v) => s + v, 0) / last.members.length;
    } else {
      out.push({ center: item.value, weight: item.weight, members: [item.value] });
    }
  }
  return out.map((c) => ({ value: Math.round(c.center * 100) / 100, weight: c.weight, count: c.members.length }));
}

/* --------------------------------- census --------------------------------- */

function observedWeight(value) {
  if (value == null || value === "") return null;
  const raw = String(value).trim().toLowerCase();
  if (raw === "bold" || raw === "bolder") return 700;
  if (raw === "regular" || raw === "normal") return 400;
  const numeric = Number(raw);
  return Number.isFinite(numeric) && numeric >= 1 && numeric <= 1000 ? numeric : null;
}

function observedLineHeight(text) {
  if (text.lineHeight == null || text.lineHeight === "") return null;
  const raw = String(text.lineHeight).trim().toLowerCase();
  if (raw === "normal") return { value: "normal", unit: "keyword" };
  const px = raw.match(/^(-?\d+(?:\.\d+)?)px$/);
  if (px && text.sizePx > 0) {
    return { value: Math.round((Number(px[1]) / text.sizePx) * 100) / 100, unit: "ratio" };
  }
  const numeric = Number(raw);
  if (Number.isFinite(numeric)) return { value: numeric, unit: "ratio" };
  return { value: raw, unit: "source" };
}

function observedLetterSpacing(text) {
  if (Number.isFinite(text.letterSpacingPt)) {
    return { value: Math.round(text.letterSpacingPt * 100) / 100, unit: "pt" };
  }
  if (text.letterSpacing == null || text.letterSpacing === "") return null;
  const raw = String(text.letterSpacing).trim().toLowerCase();
  if (raw === "normal") return { value: "normal", unit: "keyword" };
  const value = raw.match(/^(-?\d+(?:\.\d+)?)(px|em|rem|pt|%)$/);
  return value ? { value: Number(value[1]), unit: value[2] } : { value: raw, unit: "source" };
}

const observationKey = (item) => JSON.stringify(item);
const observationRows = (map) => [...map.entries()]
  .sort((a, b) => b[1] - a[1])
  .map(([key, count]) => ({ ...JSON.parse(key), count }));

/**
 * A run made only of pictographs — an emoji used as an icon, a hero graphic, or
 * oversized wallpaper. Variation selectors, ZWJ, skin-tone modifiers and
 * whitespace are part of the glyph, not evidence of surrounding prose.
 */
function isPictographic(text) {
  const raw = String(text ?? "").replace(/[\s‍︎️\u{1F3FB}-\u{1F3FF}]/gu, "");
  if (!raw) return false;
  return /^\p{Extended_Pictographic}+$/u.test(raw);
}

const validHex = (value) => /^#[0-9A-F]{6}$/i.test(String(value || ""));
const boxArea = (box) => Math.max(0, box?.w || 0) * Math.max(0, box?.h || 0);

function overlapShare(foreground, background) {
  const area = boxArea(foreground);
  if (!area || !background) return 0;
  const left = Math.max(foreground.x || 0, background.x || 0);
  const top = Math.max(foreground.y || 0, background.y || 0);
  const right = Math.min((foreground.x || 0) + (foreground.w || 0), (background.x || 0) + (background.w || 0));
  const bottom = Math.min((foreground.y || 0) + (foreground.h || 0), (background.y || 0) + (background.h || 0));
  return Math.max(0, right - left) * Math.max(0, bottom - top) / area;
}

/**
 * Resolve the visual immediately behind a text run.
 *
 * A slide-level ground is only correct when no nearer painted object contains
 * the text. Text inside a dark callout on a white slide belongs to the callout,
 * while text over a photograph has no single measurable colour and must remain
 * unresolved instead of being reported as white-on-white.
 */
function groundBehindText(slide, text) {
  const box = text.box;
  const backdrops = [];
  if (box && boxArea(box)) {
    for (const [index, shape] of (slide.shapes || []).entries()) {
      const shapeBox = shape.box;
      if (!shapeBox || overlapShare(box, shapeBox) < 0.55) continue;
      const fillPaint = shape.paint == null || shape.paint === "fill";
      const alpha = Number(shape.bgAlpha ?? shape.opacity ?? 1);
      const rawColor = shape.color || shape.bg;
      const color = validHex(rawColor) && fillPaint && alpha >= 0.98
        ? String(shape.color || shape.bg).toUpperCase()
        : null;
      const visual = (validHex(rawColor) && fillPaint)
        || shape.role === "media" || shape.image || shape.assetId;
      if (!visual) continue;
      backdrops.push({
        color,
        area: boxArea(shapeBox),
        fullStage: shapeBox.w >= 92 && shapeBox.h >= 92,
        index,
      });
    }
  }

  // The smallest containing visual is the most local one. Later source order
  // wins equal-area ties, matching normal slide z-order.
  const local = backdrops
    .filter((item) => !item.fullStage)
    .sort((a, b) => (a.area - b.area) || (b.index - a.index))[0];
  if (local) return local.color;

  // A full-stage image or translucent field is itself the ground. Its pixels
  // may vary underneath the run, so a declared stage colour is not an honest
  // substitute. An explicit opaque full-stage shape, however, can be measured.
  const field = backdrops
    .filter((item) => item.fullStage)
    .sort((a, b) => b.index - a.index)[0];
  if (field) return field.color;
  if (slide.stageImage) return null;
  return validHex(slide.stageBg) ? slide.stageBg.toUpperCase() : null;
}

function sizePtOf(text, source) {
  if (Number.isFinite(text.sizePt)) return text.sizePt;
  if (Number.isFinite(text.sizePx)) return text.sizePx * 0.75;
  const width = source?.stage?.w;
  if (!Number.isFinite(text.sizeCqw) || !Number.isFinite(width)) return null;
  const sourceSize = (text.sizeCqw / 100) * width;
  return source?.kind === "html" ? sourceSize * 0.75 : sourceSize;
}

function isLargeText(text, source) {
  const sizePt = sizePtOf(text, source);
  if (!Number.isFinite(sizePt)) return false;
  return sizePt >= (observedWeight(text.weight) >= 700 ? 14 : 18);
}

function recordPair(map, key, text, source) {
  if (!key) return;
  const row = map.get(key) || { runs: 0, largeRuns: 0, smallRuns: 0 };
  row.runs += 1;
  if (isLargeText(text, source)) row.largeRuns += 1;
  else row.smallRuns += 1;
  map.set(key, row);
}

function collect(evidences) {
  const colorArea = new Map(), stageBgVotes = new Map();
  const textColorWeight = new Map(), fillColorWeight = new Map();
  const fontCount = new Map(), fontBySize = [], fontWeights = new Map();
  const lineHeights = new Map(), letterSpacings = new Map();
  const sizes = [], pictureSizes = [], radii = [], kinds = new Map(), chrome = new Map();
  const onFieldText = new Map();
  const contentTop = [], contentBottom = [], contentLeft = [], titleTop = [];
  let pillCount = 0, slideCount = 0, mediaCount = 0, fullFieldCount = 0, unresolvedContrastRuns = 0;
  const fieldColors = new Map();
  const stage = evidences[0]?.source?.stage ?? { w: 960, h: 540 };
  const declaredThemeFonts = evidences[0]?.root?.themeFonts ?? null;
  const cssVars = evidences[0]?.root?.cssVars ?? {};
  const declaredThemeColors = evidences[0]?.root?.themeColors ?? null;
  const themeProvenance = evidences[0]?.root?.themeProvenance ?? null;
  const themeFallbackAllowed = themeProvenance?.usableAsDesignFallback !== false;
  const themeFonts = themeFallbackAllowed ? declaredThemeFonts : null;
  const themeColors = themeFallbackAllowed ? declaredThemeColors : null;

  const bump = (map, key, v) => { if (key) map.set(key, (map.get(key) || 0) + v); };

  for (const ev of evidences) {
    for (const slide of ev.slides) {
      slideCount += 1;
      if (slide.stageBg && /^#[0-9A-F]{6}$/i.test(slide.stageBg)) bump(stageBgVotes, slide.stageBg.toUpperCase(), 1);
      for (const [hex, area] of Object.entries(slide.colorArea || {})) {
        if (!/^#[0-9A-F]{6}$/i.test(hex)) continue;
        bump(colorArea, hex.toUpperCase(), area);
      }
      for (const t of slide.text || []) {
        if (t.color && /^#[0-9A-F]{6}$/i.test(t.color)) bump(textColorWeight, t.color.toUpperCase(), 1);
        const size = t.sizeCqw ?? null;
        // A pictographic run is a picture, same as an icon-font run. Counting it
        // as type is not a rounding error: an emoji used as decoration is set an
        // order of magnitude larger than any heading, so it takes the top step
        // of the scale and pushes real headings down into the body steps.
        const picture = t.iconFont || isPictographic(t.text);
        if (size && size > 0.2 && size < 40 && !picture) {
          sizes.push({ value: size, weight: 1 });
          if (t.family) fontBySize.push({ size, family: t.family });
        }
        if (picture && size) pictureSizes.push({ value: size, weight: 1 });
        // an icon-font run is a picture, not type; it must not pollute the type census
        if (!picture) {
          if (t.family) bump(fontCount, t.family, 1);
          const weight = observedWeight(t.weight);
          if (weight) bump(fontWeights, observationKey({ value: weight }), 1);
          const lineHeight = observedLineHeight(t);
          if (lineHeight) bump(lineHeights, observationKey(lineHeight), 1);
          const letterSpacing = observedLetterSpacing(t);
          if (letterSpacing) bump(letterSpacings, observationKey(letterSpacing), 1);
        }
      }

      // Record the colour each run is actually placed on. A single slide can
      // contain several grounds (cards, callouts, bands); treating every run as
      // if it sat directly on the stage invents failures such as white-on-white.
      for (const t of slide.text || []) {
        if (!validHex(t.color)) continue;
        const ground = groundBehindText(slide, t);
        if (!ground) { unresolvedContrastRuns += 1; continue; }
        recordPair(onFieldText, `${ground}>${t.color.toUpperCase()}`, t, ev.source);
      }

      // Where the biggest text on the slide starts — the anchor a generator needs.
      const biggest = (slide.text || []).filter((t) => t.sizeCqw).sort((a, b) => b.sizeCqw - a.sizeCqw)[0];
      if (biggest?.box?.y != null) titleTop.push(biggest.box.y);
      for (const t of slide.text || []) {
        const b = t.box || {};
        if (b.h == null || b.y == null || (b.w || 0) < 3) continue;
        contentTop.push(b.y); contentBottom.push(b.y + (b.h || 0)); contentLeft.push(b.x || 0);
      }

      for (const s of slide.shapes || []) {
        bump(kinds, s.kind || s.role, 1);
        if (s.pill) pillCount += 1;
        if (s.role === "media") mediaCount += 1;
        if (s.color && /^#[0-9A-F]{6}$/i.test(s.color)) bump(fillColorWeight, s.color.toUpperCase(), s.area || 0);
        const box = s.box || {};
        if ((box.w || 0) > 92 && (box.h || 0) > 92 && s.color) {
          fullFieldCount += 1;
          // A colour the deck paints edge to edge is a ground it chose, whatever
          // its chroma. The generic hue test rejects pastels, which on a deck
          // built from pale full-bleed fields throws away the palette itself.
          if (/^#[0-9A-F]{6}$/i.test(s.color)) bump(fieldColors, s.color.toUpperCase(), 1);
        }
        for (const r of s.radiiCqw || []) if (r > 0.05 && r < 25) radii.push({ value: r, weight: 1 });
        if (box.w && box.w < 40 && box.h && box.h < 22) {
          // 5% grid: a logo nudged a pixel between slides must not split into two
          // buckets and land under the repeat threshold.
          bump(chrome, `${s.role || "vector"}|${s.kind}|${Math.round(box.x / 5)}|${Math.round(box.y / 5)}|${s.color || "-"}`, 1);
        }
      }
      for (const f of slide.textFrames || []) {
        const box = f.box || {};
        if (box.h && box.h < 14 && box.w && box.w < 60) {
          bump(chrome, `text|text|${Math.round(box.x / 5)}|${Math.round(box.y / 5)}|-`, 1);
        }
      }
    }
  }

  return {
    stage, themeFonts, themeColors, declaredThemeFonts, declaredThemeColors, themeProvenance,
    themeFallbackAllowed, cssVars, slideCount, pillCount, mediaCount, fullFieldCount, fieldColors, stageBgVotes,
    colorArea, textColorWeight, fillColorWeight, fontCount, fontBySize,
    fontWeights, lineHeights, letterSpacings,
    sizes, radii, kinds, chrome, onFieldText, unresolvedContrastRuns,
    contentTop, contentBottom, contentLeft, titleTop,
  };
}

/* ------------------------------ role assignment ---------------------------- */

function deriveRoles(c) {
  const byArea = [...c.colorArea.entries()].sort((a, b) => b[1] - a[1]);
  const fills = [...c.fillColorWeight.entries()].sort((a, b) => b[1] - a[1]);
  const texts = [...c.textColorWeight.entries()].sort((a, b) => b[1] - a[1]);

  const neutralish = (hex) => chroma(hex) < 0.14;
  const light = (hex) => lightness(hex) > 0.86;

  const fieldRanked = [...(c.fieldColors ?? new Map()).entries()].sort((a, b) => b[1] - a[1]);
  // The declared stage background is the paper only while the audience can see
  // it. A deck that paints a full-bleed field on every slide has covered it: the
  // PPTX still reports #FFFFFF underneath, and taking that vote hands the paper
  // role to a colour that appears in the deck exactly zero times. When every
  // slide is covered, the most-used field is the paper.
  const everySlideCovered = c.fullFieldCount >= c.slideCount && c.slideCount > 0;
  const explicitBg = (everySlideCovered && fieldRanked.length)
    ? fieldRanked.find(([h]) => neutralish(h) && light(h))?.[0] ?? fieldRanked[0][0]
    : (c.stageBgVotes.size
      ? [...c.stageBgVotes.entries()].sort((a, b) => b[1] - a[1])[0][0] : null);
  // A text-only deck paints nothing at all. Falling through to "the colour with
  // the largest area" then hands the ground role to the body text grey and the
  // whole palette collapses to 1:1. The theme's light-1 is the paper.
  const themeLight = c.themeColors?.lt1 || c.themeColors?.bg1 || null;
  const bg = explicitBg
    || (fills.find(([h]) => light(h) && neutralish(h)) || [])[0]
    || (themeLight && light(themeLight) ? themeLight : null)
    || (byArea.find(([h]) => light(h) && neutralish(h)) || [])[0]
    || "#FFFFFF";

  // ink: the darkest of the *commonly used* text colours. Sorting all text
  // colours by lightness alone hands the role to a stray pure black.
  const textTop = texts.slice(0, 6).filter(([h]) => contrast(h, bg) >= 4.5 && neutralish(h));
  const ink = (textTop.sort((a, b) => (b[1] - a[1]) || (lightness(a[0]) - lightness(b[0])))[0]
    || texts.filter(([h]) => contrast(h, bg) >= 4.5).sort((a, b) => lightness(a[0]) - lightness(b[0]))[0]
    || byArea.filter(([h]) => lightness(h) < 0.3)[0] || ["#111111"])[0];

  const soft = (texts.find(([h]) => !nearlyEqual(h, ink) && neutralish(h)
      && lightness(h) > lightness(ink) + 0.08 && contrast(h, bg) >= 3)
    || [fromHsl(toHsl(ink)[0], Math.min(0.2, toHsl(ink)[1]), clamp(lightness(ink) + 0.22, 0, 1))])[0];

  const surface = (fills.find(([h]) => neutralish(h) && light(h) && !nearlyEqual(h, bg, 6))
    || [fromHsl(toHsl(bg)[0], 0.06, clamp(lightness(bg) - 0.035, 0, 1))])[0];

  const ph = (fills.find(([h]) => neutralish(h) && !nearlyEqual(h, bg, 6) && !nearlyEqual(h, surface, 6) && lightness(h) > 0.78)
    || [fromHsl(toHsl(surface)[0], 0.05, clamp(lightness(surface) - 0.04, 0, 1))])[0];

  // hues: real chroma, used as fills or as coloured type, ordered by how much of
  // the deck they colour. Tints of the ground (pale cards) are not hues.
  const hueList = [];
  const consider = (hex, weight, isField = false) => {
    // A full-bleed field is exempt from the chroma floor. It is not a tint that
    // happened to be pale — it is a colour the deck put on the whole stage, and
    // a deck whose palette is blush and peach has a palette of blush and peach.
    if (!isField && chroma(hex) < 0.22) return;
    if (lightness(hex) > 0.9 && !isField) return;
    if (lightness(hex) < 0.06) return;
    if (nearlyEqual(hex, bg, 10) || nearlyEqual(hex, ink, 10)) return;
    if (hueList.some((h) => nearlyEqual(h.hex, hex, 18) || hueDistance(h.hex, hex) < 12)) return;
    hueList.push({ hex, weight, field: isField });
  };
  for (const [hex, weight] of fieldRanked) { if (hueList.length >= 6) break; consider(hex, weight, true); }
  for (const [hex, weight] of fills) { if (hueList.length >= 6) break; consider(hex, weight); }
  for (const [hex, weight] of byArea) { if (hueList.length >= 6) break; consider(hex, weight); }
  for (const [hex, weight] of texts) { if (hueList.length >= 4) break; consider(hex, weight / 100); }

  // A deck with no chroma at all is monochrome, and inventing a hue for it is the
  // worst thing this script can do — a sepia engraving must not leave here wearing
  // a green accent. Step down the deck's own neutrals instead.
  const achromatic = hueList.length === 0;
  const neutralSteps = byArea.map(([h]) => h).filter((h) => chroma(h) < 0.16)
    .sort((a, b) => lightness(a) - lightness(b));
  const darkNeutral = neutralSteps.find((h) => contrast(h, bg) >= 4.5) || ink;
  const accent = hueList[0]?.hex ?? darkNeutral;

  const neutralAt = (p) => (neutralSteps.length
    ? neutralSteps[Math.min(neutralSteps.length - 1, Math.floor((neutralSteps.length - 1) * p))]
    : fromHsl(0, 0, clamp(1 - p, 0.1, 0.92)));
  /**
   * The slot must be filled — the colour-system contract is a fixed set of
   * variables — but it is filled by *repeating* a colour the deck owns, never by
   * spinning the accent's hue to manufacture a new one. A deck of yellow, teal
   * and orange that leaves here wearing a synthesised lime has been given a
   * colour it does not contain, in a file whose entire job is to be trusted, and
   * no downstream reader can tell the fabrication from the measurement.
   */
  const fallbackHue = (index, achromaticStep) => {
    if (achromatic) return neutralAt(achromaticStep);
    return hueList[index % hueList.length].hex;
  };
  const s1 = hueList[1]?.hex ?? fallbackHue(1, 0.15);
  const s2 = hueList[2]?.hex ?? fallbackHue(2, 0.55);
  const s3 = hueList[3]?.hex ?? fallbackHue(3, 0.8);

  const sources = [accent, s1, s2, s3];
  const on = sources.map((h) => onColor(h, ink, bg));
  const safeText = sources.map((h) => forceContrast(h, bg, 4.5));

  const observedOn = (groundHex) => {
    const prefix = `${groundHex.toUpperCase()}>`;
    const hits = [...c.onFieldText.entries()]
      .filter(([k]) => k.startsWith(prefix))
      .map(([k, stats]) => [k.slice(prefix.length), stats.runs])
      .sort((a, b) => b[1] - a[1]);
    return hits[0]?.[0] ?? null;
  };
  const grounds = sources.map((h) => {
    const t = onColor(h, ink, bg);
    return contrast(h, t) >= 4.5 ? h : forceContrast(h, t, 4.5);
  });
  // Prefer the colour the source itself used on this ground, as long as it clears
  // 3:1 (the large-text threshold — these grounds only carry display type).
  // Falling back to max-contrast silently repaints a white-on-orange deck in black.
  const groundText = grounds.map((g, i) => {
    const seen = observedOn(sources[i]) || observedOn(g);
    if (seen && contrast(seen, g) >= 3) return seen;
    return onColor(g, ink, bg);
  });

  return {
    bg, surface, ink, soft, ph, accent, s1, s2, s3,
    oa: on[0], o1: on[1], o2: on[2], o3: on[3],
    ka: safeText[0], kad: contrast(accent, ink) >= 4.5 ? accent : forceContrast(accent, ink, 4.5),
    k1: safeText[1], k2: safeText[2], k3: safeText[3],
    g0: grounds[0], g1: grounds[1], g2: grounds[2], g3: grounds[3],
    t0: groundText[0], t1: groundText[1], t2: groundText[2], t3: groundText[3],
    _hueCount: hueList.length,
    _achromatic: achromatic,
    _observed: byArea.slice(0, 16).map(([hex, area]) => ({ hex, area: Math.round(area * 100) / 100 })),
  };
}

/* ------------------------------- type + radius ----------------------------- */

function deriveTypeScale(c) {
  // Every cluster is reported, including sizes seen once: a cover title appears
  // exactly once by definition, and a repeat threshold deletes it. The *scale*
  // still picks from repeated sizes only, so one stray size cannot become a step.
  const all = cluster(c.sizes, 0.1).sort((a, b) => b.value - a.value);
  const clusters = all.filter((x) => x.weight >= 2);
  const big = clusters.filter((x) => x.value >= 3);
  const mid = clusters.filter((x) => x.value >= 1.6 && x.value < 3);
  const small = clusters.filter((x) => x.value < 1.6);
  const pick = (arr, i) => (arr[i] ? arr[i].value : null);

  // Only claim a step the deck actually has — the same rule already applied to
  // h3 and lead below. Multiplying display by 0.66 to conjure an h1 produced a
  // heading size that appears on no slide, and nothing marks it as invented.
  const scale = {};
  scale.display = pick(big, 0);
  scale.h1 = pick(big, 1);
  scale.h2 = pick(big, 2);
  scale.stat = scale.h1;
  // Body copy is whatever the deck uses most, not whatever happens to be third
  // largest. Getting this backwards puts body text on a heading step, and
  // generated slides then render every paragraph at the heading's weight.
  const byWeight = [...mid].sort((a, b) => b.weight - a.weight);
  scale.body = (byWeight[0]?.value) ?? pick(small, 0);
  // Only claim a step the deck actually has. Filling h3 and lead with the body
  // size invents two headings that do not exist, and generated slides then set
  // prose at a heading's weight.
  const aboveBody = mid.filter((m) => m.value > (scale.body ?? 0));
  scale.h3 = aboveBody.length ? aboveBody[aboveBody.length - 1].value : null;
  scale.lead = aboveBody.length > 1 ? aboveBody[0].value : null;
  scale.cap = pick(small, 0);
  scale.kicker = pick(small, small.length - 1) ?? scale.cap;
  return { scale, clusters: all };
}

/**
 * Corner radii, as observed. There is deliberately no interpolated xs/sm/md/lg/xl
 * scale here: a deck with two radii has two radii, and stretching them over five
 * steps invented three values while rounding the real ones away — measured on a
 * deck whose card radius (1.14, used 13 times) came out of the scale as 1.22.
 * Nothing downstream consumed the steps, so they were three fabrications and a
 * wrong answer in exchange for nothing.
 */
function deriveRadii(c) {
  const clusters = cluster(c.radii, 0.18).filter((x) => x.weight >= 2).sort((a, b) => a.value - b.value);
  const sharp = clusters.length === 0 || clusters.every((x) => x.value < 0.12);
  return { sharp, clusters, pillCount: c.pillCount };
}

/** The Office 2013+ factory theme, verbatim. Matching it means nobody chose it. */
const STOCK_OFFICE = {
  fonts: ["calibri light", "calibri"],
  colors: { accent1: "#4472C4", accent2: "#ED7D31", accent3: "#A5A5A5", accent4: "#FFC000", dk2: "#44546A" },
};

function isStockOfficeTheme(themeFonts, themeColors) {
  if (!themeFonts && !themeColors) return false;
  const major = String(themeFonts?.majorFont?.latin ?? "").toLowerCase();
  const minor = String(themeFonts?.minorFont?.latin ?? "").toLowerCase();
  const fontsAreStock = major === STOCK_OFFICE.fonts[0] && minor === STOCK_OFFICE.fonts[1];
  const colorsAreStock = Object.entries(STOCK_OFFICE.colors)
    .every(([role, hex]) => String(themeColors?.[role] ?? "").toUpperCase() === hex);
  return fontsAreStock && colorsAreStock;
}

function deriveFonts(c) {
  const ranked = [...c.fontCount.entries()].sort((a, b) => b[1] - a[1]);
  const clean = (f) => String(f || "").replace(/\s*(Light|Regular|Medium|SemiBold|Bold|ExtraBold|Black|Italic)$/i, "").trim();
  const bySize = [...c.fontBySize].sort((a, b) => b.size - a.size);
  const displayRaw = bySize.length ? bySize[0].family : ranked[0]?.[0];
  const totalRuns = ranked.reduce((sum, [, n]) => sum + n, 0) || 1;
  const bodyRaw = ranked.find(([f, n]) => clean(f) !== clean(displayRaw) && n / totalRuns >= 0.15)?.[0] ?? ranked[0]?.[0];
  // No font evidence means no font. Defaulting to Inter would put a confident
  // wrong answer into a document whose whole job is to be trusted.
  const display = clean(displayRaw) || c.themeFonts?.majorFont?.latin || null;
  const body = clean(bodyRaw) || c.themeFonts?.minorFont?.latin || display;
  // A CJK deck declares a separate east-asian face; reading only `latin` drops
  // the font that actually sets most of the text.
  const cjkDisplay = c.themeFonts?.majorFont?.ea || null;
  const cjkBody = c.themeFonts?.minorFont?.ea || cjkDisplay;
  return {
    display, body,
    cjkDisplay, cjkBody,
    unknown: !display,
    singleFamily: Boolean(display) && clean(display) === clean(body),
    observed: ranked.slice(0, 8).map(([family, count]) => ({ family, count })),
    themeFonts: c.declaredThemeFonts,
    themeProvenance: c.themeProvenance,
    themeFallbackAllowed: c.themeFallbackAllowed,
    // A deck built in PowerPoint and never re-themed still declares the stock
    // Office theme, and every shape then overrides it locally. Emitting Calibri
    // and #4472C4 as "the deck's theme" hands a reader a font and a blue that
    // appear nowhere on any slide. Say that it is the factory default instead.
    themeIsStockDefault: c.themeFallbackAllowed && isStockOfficeTheme(c.themeFonts, c.themeColors),
  };
}

function deriveFontSources(evidences) {
  const unique = (items, keyOf) => {
    const seen = new Set();
    return items.filter((item) => {
      const key = keyOf(item);
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  };
  const roots = evidences.map((evidence) => evidence.root || {});
  return {
    webFontLinks: unique(roots.flatMap((root) => root.fontLinks || []), String),
    fontFaces: unique(roots.flatMap((root) => root.fontFaces || []), (item) => JSON.stringify(item)),
    embeddedFonts: unique(roots.flatMap((root) => root.embeddedFonts || []),
      (item) => `${item.family || ""}|${item.style || ""}|${item.part || item.file || ""}`),
    pdfFonts: unique(roots.flatMap((root) => root.pdfFonts || []),
      (item) => `${item.name || ""}|${item.type || ""}|${item.object || ""}`),
  };
}

/** Where content sits on the stage — the margins are part of the identity. */
function deriveLayout(c) {
  const pct = (arr, p) => {
    if (!arr.length) return null;
    const sorted = [...arr].sort((a, b) => a - b);
    return Math.round(sorted[Math.floor((sorted.length - 1) * p)] * 10) / 10;
  };
  const top = pct(c.contentTop, 0.05);
  const bottom = pct(c.contentBottom, 0.95);
  return {
    marginLeftCqw: pct(c.contentLeft, 0.1),
    titleTopCqh: pct(c.titleTop, 0.5),
    contentTopCqh: top,
    contentBottomCqh: bottom,
    verticalFill: top != null && bottom != null ? Math.round((bottom - top) * 10) / 10 : null,
  };
}

function deriveElementCensus(c) {
  const kinds = [...c.kinds.entries()].sort((a, b) => b[1] - a[1])
    .map(([kind, count]) => ({ kind, count, perSlide: Math.round((count / Math.max(1, c.slideCount)) * 100) / 100 }));
  const chrome = [...c.chrome.entries()]
    .filter(([, count]) => count >= Math.max(3, c.slideCount * 0.4))
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([key, count]) => {
      const [role, kind, x, y, color] = key.split("|");
      return {
        role, kind,
        // Bucketed to a 5% grid so a logo nudged a pixel between slides stays one
        // candidate. Stated as a range because that is the resolution actually
        // measured: reporting `x: 90` invites a reader to place something at 90%.
        xRangeCqw: [Number(x) * 5 - 2.5, Number(x) * 5 + 2.5],
        yRangeCqh: [Number(y) * 5 - 2.5, Number(y) * 5 + 2.5],
        ...(color === "-" ? {} : { color }),
        slides: count,
        share: Math.round((count / Math.max(1, c.slideCount)) * 100) / 100,
      };
    });
  return {
    kinds, chrome,
    pillPerDeck: c.pillCount, mediaPerDeck: c.mediaCount,
    fullFieldSlides: c.fullFieldCount, slideCount: c.slideCount,
  };
}

/* ---------------------------------- output --------------------------------- */

function cssFor(token, roles, provenance) {
  const line = (keys) => keys.map((k) => `--${k}: ${roles[k]};`).join(" ");
  return `/* token: ${token} | category: ${roles._hueCount >= 3 ? "V" : "M"} | ${provenance} */
:root[data-color-system="${token}"] {
  ${line(["bg", "surface", "ink", "soft", "ph"])}
  ${line(["accent", "s1", "s2", "s3"])}
  ${line(["oa", "o1", "o2", "o3"])}
  ${line(["ka", "kad", "k1", "k2", "k3"])}
  --g0: ${roles.g0}; --t0: ${roles.t0}; --g1: ${roles.g1}; --t1: ${roles.t1}; --g2: ${roles.g2}; --t2: ${roles.t2}; --g3: ${roles.g3}; --t3: ${roles.t3};
}
`;
}

function buildWarnings({ c, roles, type, radius, fonts, contrastReport }) {
  const w = [];
  if (c.slideCount < 6) w.push(`only ${c.slideCount} slides of evidence — the census is thin, treat counts as indicative`);
  if (roles._hueCount < 4 && !roles._achromatic) {
    w.push(`only ${roles._hueCount} distinct source hue(s) found; the remaining accent slots repeat an observed hue rather than introduce a new one`);
  }
  if (!type.scale.display) w.push("no display-size text found — the type scale has no top step");
  if (fonts.unknown) w.push("no font evidence in the source; inspect the rendered slides and keep the family unresolved if it cannot be confirmed");
  if (roles._achromatic) w.push("no chroma was observed; accent and s1..s3 step down the source's own neutrals, so review any added hue against the user's goal");
  if (fonts.singleFamily) w.push(`display and body resolved to the same family (${fonts.display}) — the deck may use weight, not family, for hierarchy`);
  if (fonts.cjkDisplay) w.push(`the source declares an east-asian face (${fonts.cjkDisplay}); review it as the primary CJK typography candidate`);
  if (fonts.themeIsStockDefault) w.push("the file carries the stock Office theme (Calibri / #4472C4) and overrides it on every shape; the theme block is a factory default, not a design decision");
  if (!fonts.themeFallbackAllowed) {
    const application = fonts.themeProvenance?.application || "a conversion tool";
    w.push(`the OOXML package reports ${application}; its theme declarations are preserved only as provenance and were not used as font or colour fallbacks`);
  }
  if (radius.sharp) w.push("no non-zero corner radius was observed; review a sharp-corner interpretation against the render");
  if (contrastReport.inkOnBg < 4.5) w.push(`ink on bg is only ${contrastReport.inkOnBg}:1 — below WCAG AA for body text`);
  if (c.sizes.length < 12) w.push("fewer than 12 sized text runs; treat the suggested type scale as low-confidence");
  if (c.shellFurnitureShare >= 20) {
    w.push(`constant furniture covers ${c.shellFurnitureShare}% of each slide after text removal; review whether identity is carried primarily by background art`);
  }
  for (let i = 0; i < 4; i += 1) {
    const g = roles[`g${i}`], t = roles[`t${i}`];
    if (g && t && contrast(t, g) < 4.5) {
      w.push(`--t${i} on --g${i} is ${Math.round(contrast(t, g) * 100) / 100}:1; review intended text size and legibility before reuse`);
    }
  }
  // The source's own choices, which the derived roles cannot reveal: a deck may
  // ship a kicker that fails AA on every ground it sits on, and that is a fact
  // about the deck the package has to carry rather than quietly repair.
  const worst = contrastReport.observedBelowAA ?? [];
  if (worst.length) {
    const shown = worst.slice(0, 3)
      .map((pair) => `${pair.text} on ${pair.ground} at ${pair.ratio}:1 (needs ${pair.requiredRatio}:1)`)
      .join(", ");
    w.push(`the source itself pairs text below the size-dependent WCAG AA threshold in ${worst.length} observed combination(s) — ${shown}${worst.length > 3 ? ", …" : ""}; keep the look only with a darker step, and never copy the worst pairing onto a new ground`);
  }
  return w;
}

function main() {
  const args = parseArgs(process.argv);
  const evidences = args.evidence.map((p) => JSON.parse(readFileSync(p, "utf8")));
  const c = collect(evidences);
  // The shell pass measures the ground from pixels. It wins over a declared
  // background fill, because a full-bleed background image covers that fill and
  // the deck the audience sees is the image.
  if (args.shell) {
    const shell = JSON.parse(readFileSync(args.shell, "utf8"));
    if (shell.ground) {
      c.stageBgVotes.clear();
      c.stageBgVotes.set(shell.ground.toUpperCase(), 999);
      c.shellGround = shell.ground.toUpperCase();
      c.shellFurnitureShare = shell.furnitureShare;
    }
  }
  const roles = deriveRoles(c);
  const type = deriveTypeScale(c);
  const radius = deriveRadii(c);
  const fonts = deriveFonts(c);
  const fontSources = deriveFontSources(evidences);
  const elements = deriveElementCensus(c);
  const layout = deriveLayout(c);

  const round2 = (v) => Math.round(v * 100) / 100;
  /**
   * Only local pairings the source actually used. Reporting `contrast(ka, bg)` is
   * circular — `ka` is whatever `forceContrast` just pushed to 4.5, so it always
   * passes, and the one number that mattered on the deck this was measured on
   * was never computed at all. A ratio the tool guaranteed is not evidence; a
   * ratio the deck chose is.
   */
  const observedPairs = [...c.onFieldText.entries()]
    .map(([key, stats]) => {
      const [ground, text] = key.split(">");
      const ratio = round2(contrast(text, ground));
      const requiredRatio = stats.smallRuns > 0 ? 4.5 : 3;
      return {
        text,
        ground,
        ratio,
        runs: stats.runs,
        largeRuns: stats.largeRuns,
        smallRuns: stats.smallRuns,
        requiredRatio,
        passes: ratio >= requiredRatio,
      };
    })
    .sort((a, b) => (a.ratio - b.ratio) || (b.runs - a.runs));
  const contrastReport = {
    note: "measured on resolved local solid backgrounds; large text requires 3:1 and small text 4.5:1",
    inkOnBg: round2(contrast(roles.ink, roles.bg)),
    observedPairs,
    observedBelowAA: observedPairs.filter((pair) => !pair.passes),
    unresolvedRuns: c.unresolvedContrastRuns,
  };

  const tokens = {
    schema: "presentation-tokens/2",
    interpretation: {
      status: "advisory",
      note: "Token roles and derived contrast colours are a source-backed draft; confirm semantic roles against the rendered deck.",
    },
    token: args.token,
    name: args.name || args.token,
    sources: evidences.map((e) => ({
      kind: e.source.kind, path: e.source.path, slides: e.source.slideCount,
      rendered: e.source.rendered !== false,
    })),
    stage: c.stage,
    slideCount: c.slideCount,
    colors: roles,
    contrast: contrastReport,
    typography: {
      ...fonts,
      scale: type.scale,
      clusters: type.clusters,
      weights: observationRows(c.fontWeights),
      lineHeights: observationRows(c.lineHeights),
      letterSpacing: observationRows(c.letterSpacings),
      sources: fontSources,
    },
    radius,
    elements,
    layout,
    reviewNotes: buildWarnings({ c, roles, type, radius, fonts, contrastReport }),
  };

  mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
  writeFileSync(args.out, JSON.stringify(tokens, null, 2));

  if (args.css) {
    mkdirSync(path.dirname(path.resolve(args.css)), { recursive: true });
    writeFileSync(args.css, cssFor(args.token, roles,
      `extracted from ${evidences.map((e) => path.basename(e.source.path)).join(" + ")}`));
  }

  console.log(JSON.stringify({
    out: args.out, css: args.css || null, token: args.token, status: "advisory",
    colors: { bg: roles.bg, ink: roles.ink, accent: roles.accent, s1: roles.s1, s2: roles.s2, s3: roles.s3 },
    fonts: {
      display: fonts.display,
      body: fonts.body,
      cjkDisplay: fonts.cjkDisplay,
      cjkBody: fonts.cjkBody,
      weights: observationRows(c.fontWeights),
      lineHeights: observationRows(c.lineHeights),
      letterSpacing: observationRows(c.letterSpacings),
      sources: fontSources,
    },
    radius: radius.clusters, sharp: radius.sharp,
    typeScale: type.scale, layout,
    reviewNotes: tokens.reviewNotes,
  }, null, 2));
}

main();
