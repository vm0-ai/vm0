---
name: presentation-reverse-template
description: Turn a PPT, PPTX, PDF, image deck, or ordered page screenshots into a compact reusable HTML presentation template that preserves the source deck's visual language.
---

# Reverse a presentation into a reusable template

## Outcome

Publish an editable template that is fast to reverse and fast for later AI to use while preserving the source deck's visual language. Remove duplicate and page-specific work; do not omit distinct reusable patterns or fidelity evidence.

## Workflow

### 1. Render and inspect

Preserve the source. For PPT, PPTX, and PDF, use the platform renderer:

```bash
npx --yes --package="${CLI_PKG_URL}" okou presentation screenshot \
  --input <deck.ppt|deck.pptx|deck.pdf> \
  --out <source-pages-dir> --width 1600 --height 900 --json
```

Reuse this source render for analysis and publication; rerun it only after a concrete failure. Inspect all ordered pages together and enlarge only ambiguous ones. Extract the ratio, page roles, typography, functional colors, spacing, structures, components, motifs, chrome, image treatment, and reusable assets. Assign every page to a structural family; content-only changes share a family.

### 2. Build a coverage-complete package

```bash
mkdir -p <template-slug>/layouts/fragments <template-slug>/styles <template-slug>/reference
cp assets/template/layouts/shared-shell.html <template-slug>/layouts/shared-shell.html
cp assets/template/layouts/shell-contract.md <template-slug>/layouts/shell-contract.md
```

```text
<template-slug>/
  SKILL.md
  design-system.md
  layouts/
    shared-shell.html
    shell-contract.md
    fragments/<semantic-layout>.html
  styles/template.css
  reference/       # optional: selected source-page evidence
  assets/          # optional: reusable logos, fonts, textures, or images
```

`design-system.md` is the single authority. Record exact typography, color and spacing roles, safe areas, image treatment, components, motifs, chrome, and fixed versus adaptable rules. Add a compact coverage table: structural family, source pages, exact fragment path or adaptation rule, editable regions, supported variations, and assets.

Keep `styles/template.css` to reusable fonts, variables, base styles, and components; it must not own viewport geometry. Later runs receive only this package, so add selected source-page evidence when rules and fragments cannot preserve important visual detail. References never become slide backgrounds or replacement layouts.

Create an editable fragment for every materially different reusable composition. Consolidate only when its difference from a named fragment can be stated unambiguously as an adaptation rule. There is no fixed fragment or reference-page count; do not rebuild covered source pages. Each fragment contains exactly one `.stage > .fit` and no document shell, `.deck`, `.slide`, shared CSS, or navigation script. Text, shapes, cards, tables, diagrams, and ordinary charts remain editable HTML/CSS/SVG.

Keep the supplied shell byte-identical. It owns centered 16:9 geometry, scrolling, and four-arrow navigation. Follow `layouts/shell-contract.md`; size content inside `.fit` with container units, percentages, Flexbox, or Grid, and never move or scale `.stage`.

The generated `SKILL.md` gives one fast path: read `design-system.md`, `layouts/shell-contract.md`, and `styles/template.css`; choose page roles from the coverage table once; open relevant fragments and assets in one batch; start from the nearest fragment; copy the shell; inline the CSS at its theme anchor; and add one editable `.slide > .stage > .fit` per page. Preserve the source typography, color, spacing, components, motifs, chrome, and image treatment. New layouts compose this system instead of falling back to generic styling; fragments are not a whitelist.

### 3. Validate against the source

Check required files, shell byte identity, fragment structure, asset paths, and coverage. Assemble all fragments through the shell and render them as one batch with `okou presentation screenshot`. Compare every family with its source evidence for composition, typography, colors, components, centering, clipping, fonts, and assets. A visual pass is required. Fix failures and re-render only affected evidence until it passes; do not repeat passing QA or build a gallery.

### 4. Publish

```bash
npx --yes --package="${CLI_PKG_URL}" okou presentation-template publish \
  --title "<user-visible template name>" \
  --source <deck.ppt|deck.pptx|deck.pdf> \
  --pages <source-pages-dir> \
  --package <template-slug>
```

`--source` accepts PPT, PPTX, or PDF; do not convert legacy PPT. For an image deck, create an ordered PDF and retain provenance. `<source-pages-dir>` contains only ordered source pages.

Stop when publication succeeds. Report the printed template name and ID. Do not spend reverse time hosting a separate preview or resolving a URL unless the user requested one.

## Completion

- Every source page is inspected, covered, and published with the original source.
- The package preserves the observed visual language without a fixed layout quota or full-page image substitutes.
- Later authors have an indexed path to relevant rules and editable examples.
- The unchanged shell, fragment structure, assets, and source-based visual validation pass.
- Publication succeeds without unrelated preview work.
