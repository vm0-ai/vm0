---
name: presentation-reverse-template
description: Quickly extract reusable presentation identity guidance and high-fidelity visual assets from an uploaded PDF, PPT, PPTX, HTML deck, image deck, or archive. Use when a future AI should author new slide HTML itself while retaining the source deck's brand, icons, colours, typography, background treatments, or spatial character.
---

# Extract a presentation identity package

Turn a source deck into concise guidance plus reusable original or rendered assets. Aim to finish a normal
request within five minutes by extracting the identity layer and preserving complex visual treatments as
images. Do not reproduce the source deck as HTML and do not rebuild it for comparison. The resulting skill
guides a future AI that writes the final HTML and CSS directly.

## Operating principle

Separate the source into two practical layers:

- **Identity guidance:** logo and lockup files, icons and icon-font glyph names, colour roles, typography,
  layout tendencies, and overlap-risk regions.
- **High-fidelity image layer:** text-free background variants that retain complex decoration, texture,
  geometry, and chrome without asking a generating agent to redraw them.

Source text, data, and one-off semantic imagery are content, not template assets. When an element cannot be
separated from flattened source pixels, record that limitation instead of presenting it as a clean reusable
background.

Scripts measure evidence and prepare a draft. Their classifications, thresholds, and generated prose are
advisory. The agent reviews the source and may accept, change, reject, or leave any candidate unresolved.
Extraction reports may use JSON internally while the scripts run. Summarize their useful conclusions in
`design-system.md`; do not copy the reports into the final package.

Keep observed patterns, unobserved elements, and explicit constraints separate. An element that was not
observed is unresolved guidance, not a negative design rule. A zero candidate count or missing asset folder
does not mean that a future deck must omit that kind of element. Phrase something as forbidden only when the
user or source explicitly declares the constraint; otherwise the future AI remains free to introduce it when
it helps the new content and can use the observed visual language to make it fit.

## Output

```text
<out>/
  color-systems/<token>.css
  <slug>/
    SKILL.md
    design-system.md
    assets/identity/      # only when identity files were retained
    assets/backgrounds/   # only when background files were retained
    assets/fonts/         # only when font payloads were retained
```

Do not pre-create optional asset directories or add placeholder files. Omit every directory that would be
empty from the final package and archive.

The generated `SKILL.md` should tell a future agent to author semantic slide HTML, CSS, and SVG itself,
using `design-system.md` and the packaged assets as visual reference. Summarize observed layouts there as
reference guidance, not as layout IDs or a schema. State explicitly that extracted layouts are reference
layouts and that another layout may be used whenever it communicates the new content better. The skill must
not ask the agent to create a slide JSON file, feed JSON through an HTML generator, or use a fixed renderer.
Background images are optional visual materials, not predeclared slide templates. Text, charts, tables, and
labels in the new deck remain live HTML or SVG. Recommend CSS Grid or Flexbox for live content flow when they
fit; reserve absolute positioning mainly for backgrounds, fixed chrome, decoration, and intentional
overlays. This is layout guidance rather than a compulsory implementation rule.

## Input

The deck arrives as an attachment on the message that started this thread, so it is already on local disk;
there is nothing to download. Accept `.ppt`, `.pptx`, and `.pdf`.

## 1. Ingest and extract

Resolve the real content type and read the complete ingest plan:

```bash
node scripts/ingest.mjs --input <path> --work <work-dir>
```

When ingest detects a legacy binary `.ppt` by content or extension, it installs the missing document tools
described below, converts the source to a work-directory `.pptx`, and returns that converted path in the
plan. Preserve the original `.ppt` as provenance, use the converted `.pptx` for rendering and OOXML
extraction, and state that LibreOffice conversion may not retain every legacy effect exactly. The extractor
marks a LibreOffice-authored theme as provenance-only: prefer slide-local font and colour observations,
because conversion may rewrite the legacy deck's theme defaults.

Render the pages first. `extract-pptx.py` records structure only, so without this step a PPTX yields no
appearance evidence at all. Do not assume the sandbox image already has Poppler or LibreOffice.

```bash
node scripts/render-pages.mjs --input <deck.ppt|deck.pptx|deck.pdf> --out <pages-dir>
```

The renderer checks system tools first and installs only what is missing: PDF needs `poppler-utils`; PPTX
needs `libreoffice-impress` plus `poppler-utils`; legacy PPT uses that same pair for conversion and render.
LibreOffice must report exactly `24.2.2.2`; a different installed version or apt candidate is rejected.
Automatic installation requires Linux plus root or passwordless `sudo`, and works on x86-64 and ARM64 when
the distro repository provides that pinned build. apt downloads, package lists, LibreOffice profiles, and
conversion temporary files use the writable filesystem with the most free space and are removed after use;
installed system packages remain available for later inputs. Every page lands on a fixed 1600x900 surface,
ordered `page-001.png` onward.

When the machine lacks a declared font, LibreOffice or Poppler may substitute it. **The page images therefore
show the deck's shapes and spacing, not necessarily its letterforms.** Read the declared family out of the
evidence, record it as the typography candidate, and say in `design-system.md` when it could not be verified
against the render.

Then run the selected extractor. `extract-pptx.py` installs its pinned `lxml` helper into an isolated
temporary Python library directory automatically when the import is missing. Canvas-backed commands do the
same for their pinned pixel helper, so `derive-candidates.mjs` and `extract-pixels.mjs` do not require a
separate bootstrap step.

```bash
node scripts/extract-pdf.mjs --input <deck.pdf> --out <evidence.json> --pages <pages-dir> --media <media-dir>
python3 scripts/extract-pptx.py --input <deck.pptx|converted-ppt.pptx> --out <evidence.json> --media <media-dir> --fonts <font-dir>
node scripts/extract-html.mjs --input <deck.html> --out <evidence.json> --media <media-dir>
node scripts/extract-pixels.mjs --images <pages-dir> --out <evidence.json>   # the pages rendered above
```

Preserve provenance and original bytes. For PPTX, include slide, layout, and master inheritance. For PDF,
combine Poppler's rendered, positioned-text, font, image, and vector evidence. For HTML, retain computed
typography and declared font sources. For flattened inputs, state which type and asset properties are not
recoverable.

## 2. Derive the reusable layers

Collect identity, typography, layout, colour, and background-variant evidence in one bounded pass:

```bash
node scripts/derive-candidates.mjs --evidence <evidence.json> --work <candidate-work> \
  --token <token> --name <name> --render-backgrounds <background-work> --max 12
```

The background pass removes text and interior image assets suggested as one-off content, then preserves the
remaining visual layer as rendered images. A full-stage image on the cover or closing slide is a template
variant even when it appears once; a bounded sample must therefore include both ends of the deck. Preserve
its original extracted bytes as well as the text-free render, and give packaged variants semantic
`cover`, `content`, or `closing` names. It does not attempt to convert complex decoration into editable HTML
or SVG. A source overview and a few representative slides are enough to check candidate identity, font
evidence, and whether any old semantic content remains baked into a background.

Review these internal reports as a group:

- `assets.json`: original logo, lockup, icon, full-stage background, and icon-font candidates, including
  one-off cover and closing backgrounds;
- `tokens.json`: observed and derived colour roles, typography, spacing, radius, and stage evidence;
- `layouts.json`: observed spatial tendencies to preserve as reference, not an authoring schema;
- `shell.json`: rendered background variants and overlap-risk regions.

Do not promote an item only because it crossed a threshold. Keep extracted values distinct from inferred
values, and keep uncertain identity or font evidence labelled as uncertain.

For contrast evidence, resolve each text run against the nearest opaque solid visual behind its own box.
Do not substitute the stage colour for text over an image, gradient, or translucent layer; report that run
as unresolved. Apply the 3:1 large-text and 4.5:1 small-text thresholds to the observed local pairing.

For layout evidence, remove running chrome only when outer-band geometry recurs across slides; changing
page-counter text must not defeat that match. Treat wide title and eyebrow frames as spanning hierarchy,
not as column widths. Preserve repeated panel rows, grids, and stacks with their measured item sizes and
gaps instead of collapsing them into a generic single-column tendency.

## 3. Assemble concise guidance

Create the draft package mechanically:

```bash
node scripts/scaffold.mjs --tokens <candidate-work>/tokens.json --assets <candidate-work>/assets.json \
  --shell <candidate-work>/shell.json --layouts <candidate-work>/layouts.json \
  --background-images <background-work> --color-system <candidate-work>/<token>.css \
  --out <out> --slug <slug> --assemble
```

The scaffold copies source identity candidates and representative text-free background variants, then
writes a concise design-system document and a guidance-only skill. It converts useful evidence into prose
and asset references without copying the intermediate JSON reports. Review its classifications against the
source and make focused corrections where needed. Do not add a source-deck replica, proof rebuild,
similarity score, mandatory validation gate, slide-data format, or JSON-to-HTML build path.

Let copied files create their own asset directories. Before delivery, confirm that the package contains no
empty directory and no placeholder added only to preserve a directory name.

## Typography extraction

Record typography as evidence, not merely a guessed family name:

- display, body, and CJK families;
- observed family frequency, weights, and size hierarchy;
- observed line-height and letter-spacing values;
- icon-font family and glyph names;
- theme declarations, web-font sources, and embedded-font metadata.

Preserve extractable font files exactly. Mark protected, obfuscated, missing, or otherwise unusable font
data explicitly, and provide source-declared fallbacks without claiming the fallback is visually identical.

## Completion

Report the package location, source coverage, retained identity and background assets, typography sources,
uncertain classifications, and flattened-source limitations. The package is complete when it gives a future
agent enough evidence to write new HTML directly while reusing the identity and image layer; reproducing the
original deck is outside this workflow.

## 4. Deliver the template

A package sitting on disk is not a template. Publish it, which uploads the deck, the ordered page images,
and the package, then commits them together as one ready row:

```bash
okou presentation-template publish \
  --title "<name the user will see>" \
  --source <deck.pptx|converted-ppt.pptx|deck.pdf> \
  --pages <pages-dir> \
  --package <out>/<slug>
```

Page order is the order the PNGs sort in, which is the order `render-pages.mjs` wrote them.

Nothing is created before this succeeds, so a failed extraction leaves no half-built template behind. If the
deck cannot yield a template, say so in the thread and explain why rather than publishing a thin package.

## Guardrails

- Preserve source files and extracted asset bytes.
- Keep archive traversal, size, count, and decompression limits enforced.
- State page or slide caps whenever they truncate evidence.
- Never invent a font, colour, asset identity, source path, or confidence level.
- Never turn a heuristic result into a compulsory action for a future agent.
- Never infer an authoring ban from an unobserved element, zero candidate count, or missing asset directory.
- Never include extracted JSON reports in the final package or make them an input format for future slide
  authoring.
- Never retain an empty optional directory in the delivered package.
