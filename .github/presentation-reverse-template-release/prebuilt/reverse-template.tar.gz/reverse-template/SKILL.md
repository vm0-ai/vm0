---
name: presentation-reverse-template
description: Turn a PPT, PPTX, PDF, image deck, or ordered page screenshots into a compact reusable HTML presentation template that preserves the source deck's visual language.
---

# Reverse a presentation into a reusable template

## Outcome

Publish the smallest package that gives a later presentation run enough design rules, editable reference layouts, and reusable assets to produce new high-fidelity slides. Do not rebuild the source deck page by page.

## Workflow

### 1. Render and inspect

Preserve the source. For PPT, PPTX, and PDF, use the platform renderer:

```bash
npx --yes --package="${CLI_PKG_URL}" okou presentation screenshot \
  --input <deck.ppt|deck.pptx|deck.pdf> \
  --out <source-pages-dir> --width 1600 --height 900 --json
```

Inspect every ordered page in one deck-level pass; enlarge only ambiguous pages. Identify the ratio and page roles, typography, functional colors, spacing, recurring structures, components, motifs, chrome, image treatment, and reusable assets.

### 2. Build the minimum sufficient package

```bash
mkdir -p <template-slug>/layouts/fragments <template-slug>/styles <template-slug>/reference
cp assets/template/layouts/shared-shell.html <template-slug>/layouts/shared-shell.html
cp assets/template/layouts/shell-contract.md <template-slug>/layouts/shell-contract.md
```

```text
<template-slug>/
  SKILL.md
  design-system.md
  layouts/
    shared-shell.html
    shell-contract.md
    fragments/<semantic-layout>.html
  styles/template.css
  reference/       # optional: one to three source pages
  assets/          # optional: reusable logos, fonts, textures, or images
```

`design-system.md` is authoritative. Record exact typography and fallbacks; color and spacing roles; margins and safe areas; image treatment; components, motifs, chrome, and page families; fixed versus adaptable rules; the fragment index and content regions; and the selected reference page numbers.

Keep `styles/template.css` to reusable fonts, variables, base styles, and components. It must not own viewport geometry. Copy only reusable assets. Reference pages are visual evidence only and must never become slide backgrounds or replacement layouts.

Create the smallest set of editable semantic fragments that teaches the source's layout grammar, normally three to five. Cover structurally different high-value roles such as cover, primary content, data or diagram when observed, and closing; consolidate variants instead of creating one fragment per source page. Each fragment contains exactly one `.stage` with one direct child `.fit`, with no document shell, `.deck`, `.slide`, shared CSS, or navigation script.

Keep the supplied shell byte-identical. It owns centered 16:9 geometry, scrolling, and four-arrow navigation. Follow `layouts/shell-contract.md`; size content inside `.fit` with container units, percentages, Flexbox, or Grid, and never move or scale `.stage`.

The generated `SKILL.md` must give later authors one short path: read `design-system.md`, the shell contract, shared CSS, and only relevant fragments or assets; copy the shell; inline the CSS at its theme anchor; insert one editable `.slide > .stage > .fit` per page; and edit only documented shell anchors. Fragments guide composition but never limit new content to the packaged layouts.

### 3. Validate once

Run structural checks for required files, shell byte identity, one `.stage > .fit` per fragment, and resolvable asset paths. Assemble the fragments temporarily through the supplied shell and render them together once with `okou presentation screenshot`; inspect one contact sheet for centering, clipping, font and asset loading, and fidelity to the selected source references. Correct observed defects, but do not create a gallery, rebuild additional source pages, or repeat visual QA without a concrete failure.

### 4. Publish

```bash
npx --yes --package="${CLI_PKG_URL}" okou presentation-template publish \
  --title "<user-visible template name>" \
  --source <deck.ppt|deck.pptx|deck.pdf> \
  --pages <source-pages-dir> \
  --package <template-slug>
```

`--source` accepts PPT, PPTX, or PDF; do not convert legacy PPT. For an image deck, create an ordered PDF and retain provenance. `<source-pages-dir>` contains only ordered source pages.

Stop when publication succeeds. Report the printed template name and ID. Do not spend reverse time hosting a separate preview or resolving a URL unless the user requested one.

## Completion

- Every source page was inspected and published with the original source.
- The authoritative design system, shared CSS, references, assets, and minimum fragment set preserve the observed visual language for later editable authoring.
- The shell is unchanged, fragments satisfy `.stage > .fit`, asset paths resolve, and one targeted render passes.
- No full-page image substitutes for editable slide content.
- Publication succeeded without unrelated preview work.
