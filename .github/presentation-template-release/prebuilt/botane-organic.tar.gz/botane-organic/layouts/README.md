# botane-organic — naked layouts

37 layouts, with structure separated from optional decoration and measured reference
geometry. The set covers opening, prose, imagery, data, planning, diagrams, decisions,
cases, people, and closing pages without using duplicate pages to inflate the count.
Pair one of these with `../decoration/PLACEMENT.md` to build a slide.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 37: zero `width` / `max-width` / `min-width` / `height` / `left` /
`top` / `right` / `bottom` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex-basis`. A numbering gutter written `flex:0 0 4cqw` freezes exactly the
way a `width` does.

Four exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline rule.
- **`em`** on a gutter or an ornament that holds no prose — `flex:0 0 2.6em` on a row
  numeral, `width:.9em` on a timeline dot. `em` scales with the type around it, so it
  cannot freeze a text box the way `cqw` can.
- **`%`** in `chart-bar` and `gantt` only, where the number *is* the datum. A bar at
  61% is reporting 61, not making a layout choice.

Everything else stretches. Columns are `flex:1`. The safe area is set once, by the padding
on `.fit` — `12cqh 6cqw 9cqh`, measured off the reference: content starts at 11.18cqh, the
most common left edge is 6% (24 of 115 text runs), and the footer chrome sits at 3.4cqh
from the bottom.

Any flex child holding an SVG or a percentage-height bar needs `min-height:0`, or the
SVG's intrinsic ratio pushes the box past the stage edge.

the original reference deck was produced by measuring a rendered deck and writing the numbers back, so
its widths are observations of one string at one font size — `width:36cqw`,
`margin-left:83.24%`. Copying them reproduces that one string. These carry none.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions —
including the four signature-element helpers (`.photo` `.panel` `.dot` `.chrome-foot`).
Not a slide. If those helpers are missing, `.panel` renders as an unstyled div and every
dot collapses to zero width, while the colour system still loads and every probe still
reads 0. `_base.css` mirrors the shared naked-layout primitives for the expanded
planning and diagram examples; it is also not a slide.

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `statement` `long-form` `two-column` `three-column` `color-cards`
`bullets` `numbered-list` `big-quote`

**Numbers** · `kpi-grid` `kpi-cards` `stat-highlight` `stat-donut` `data-table`
`chart-bar` `chart-line`

**Time and sequence** · `process-steps` `timeline` `roadmap` `gantt`

**Structures and relationships** · `architecture` `mindmap`

**Decisions and comparisons** · `comparison` `versus` `pros-cons`

**Cases, people, pricing, testimony** · `case-study` `team` `pricing` `quote-cards`
`icon-cells`

**Imagery** · `image-portrait` `image-right` `image-grid` `image-hero` — all four
delete cleanly. When
the source has no imagery, drop the `data-photocell` frame and use a prose layout
instead; do not leave an empty box.

## Coverage audit and where the 37 came from

Inventory first, supplement second — not an import of another template's list.

- **13 are what the original reference deck already demonstrated**, one per distinct page
  role: cover, toc, section-divider, image-portrait, numbered-list, team, icon-cells,
  process-steps, image-grid, stat-donut, quote-cards, pricing, close.
- **3 come from `../composition-recipes.html`**, which holds treatments the example does
  not: `big-quote`, `comparison`, `data-table`.
- **12 were genuinely missing** for decks this template has to serve: `two-column`,
  `three-column`, `color-cards`, `bullets`, `kpi-grid`, `kpi-cards`, `stat-highlight`,
  `versus`, `timeline`, `chart-bar`, `chart-line`, `image-hero`.
- **9 were added after the full communication-job audit**: `statement` for a
  non-quoted thesis, `long-form` for sustained prose, `image-right` for the missing
  text-led image orientation, `roadmap` for future horizons, `gantt` for scheduled
  work, `architecture` for layers and dependencies, `mindmap` for branching
  relationships, `pros-cons` for a decision with explicit trade-offs, and
  `case-study` for challenge → intervention → outcome plus proof.

The audit also confirmed that four requested jobs should stay mapped to existing
layouts rather than create look-alike files:

| requested job | existing layout | why it is the same job |
|---|---|---|
| checklist / key points | `bullets` or `numbered-list` | unordered or ordered action rows |
| image left | `image-portrait` | the photograph leads and prose follows |
| flow diagram | `process-steps` | connected ordered stages |
| large image / gallery | `image-hero` / `image-grid` | one dominant image or several peers |

## Ruled or filled — every peer-row content type has both

The catalogue deliberately carries both ruled and filled treatments. The communication
job decides which register is used; neither is more on-template than the other:

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `color-cards` |
| a row of numbers | `kpi-grid` | `kpi-cards` |
| two things compared | `comparison` | `versus` |
| a set of categories | `icon-cells` | `color-cards` |

The filled versions cycle `--g0 --g2 --g1 --g3` with the matching `--t?`, so neighbours
never share a colour. Pick the filled version when the items are short and parallel, when
the ruled version reads thin, or simply when the previous slide was ruled.

Note that botane's own reference is the opposite of skewed: only 2 of its 15 pages carry
a hairline at all. The skew is in *this layout set*, which is what an agent samples from.

## A filled box is sized by its content, never by the stage

```
height  row     flex:none        — from the tallest child, not the stage
        child   flex:1           — every sibling matches that tallest child
        group   wrapped in flex:1;min-height:0;…;justify-content:center

width   box     align-self:flex-start; max-width:100%
```

`.fit` is a column flex with `align-items:stretch`, so **every child is full-width by
default**. That default is why boxes come out too wide.

The exception is a **row of peers** — cards, columns, steps. Those stay equal width and
divide the safe area. One box hugs, a row of boxes divides.

`flex:1` on the **row** is not the same instruction as `flex:1` on the **child**: on the
row it fills the stage and the cards inherit the stage's height, giving a slab of colour
that is half empty. Reserve a filling `flex:1` for an image frame or a chart plot area.

Stress-tested the 37-layout set by injecting an extra sentence into the first item of
every stretch-aligned peer row: 24 peer rows found, 0 unequal.

## Peer columns agree on their first line

The reference reads 0 on this and so do all 37 layouts, so it gates. Two traps cost me a
round each here:

- **A vertically-centred half.** `stat-donut` and `stat-highlight` both put a figure group
  beside a prose column and centred it, which drops its first line 40px below the
  kicker's. Both now top-align.
- **Proportional figures.** Fraunces sets `01` `02` `03` at different widths, so a
  `flex:none` numeral gutter starts each row's text at a different x. The lead-in columns
  in `bullets`, `numbered-list` and `toc` carry `flex:0 0 2.6em` and
  `font-variant-numeric:tabular-nums`. This is invisible to the alignment probe — it
  measures tops, not lefts — and obvious on screen.

## Colour: what is safe as text here

Measured against `--bg` across all six tokens `../design-system.md` prefers
(`mauve_dusk`, `forest_editorial`, `warm_sand`, `terracotta_clay`, `gold_luxe`,
`nordic_frost`), worst case:

| token | worst contrast | use as |
|---|---|---|
| `--ink` 12.5 · `--k1` 12.5 · `--k2` 12.5 · `--k3` 6.6 · `--soft` 5.3 · `--ka` 4.7 | pass | text or fill |
| `--g0` 3.97 · `--g1` 3.83 | pass | text or fill |
| `--accent` 2.18 · `--s1` 1.90 · `--s2` 1.23 · `--s3` 1.26 · `--g2` 1.23 · `--g3` 1.26 | **fail** | fill only |
| `--surface` 1.02 · `--ph` 1.14 | fail | fill only |

`--s3` is the trap: it is identical to `--ink` in `mauve_dusk` and nearly invisible in
`terracotta_clay`. Testing the default token alone would pass it. Same for `--g3`, and
`--accent` passes in `mauve_dusk` and fails in `warm_sand`.

On `--bg`, small coloured labels use the k-series. On a `--g?` ground use the matching
`--t?`. Checked on all 37: zero text below 3.0:1.

`--surface` is white on a near-white page. Unlike bloom, botane's reference does use it —
4 cards on the icon-cell page — so it is not forbidden here. It is still an invisible box,
and none of these 37 uses it.

## Which ornament attaches to which layout

The layouts are naked on purpose, but several describe a **set of peer items**, and on
those pages every item carries an ornament — all of them or none. See
[../decoration/item-sets.html](../decoration/item-sets.html) for copyable markup.

| layout | attach |
|---|---|
| `icon-cells` `three-column` `color-cards` | one `tile` per item, ground cycling `--g0..--g3` |
| `process-steps` `timeline` `roadmap` | one `node` per stage + one `connector`, when the marks clarify sequence |
| `numbered-list` `toc` | one `badge` per row, or leave the numeral as plain text |
| `stat-donut` `stat-highlight` | one `donut` for the rate being isolated |
| `cover` `section-divider` `close` | the wide colour panel, flush to the opposite edge |
| `bullets` `two-column` `comparison` `data-table` `architecture` `mindmap` `pros-cons` `case-study` | nothing — their rules or colour fields are content structure, not optional decoration |

**Never reserve flow space for an ornament.** Every panel, dot and circle-photo is
`position:absolute` at z 0–3, so it costs the text layer nothing. An empty `flex:1` half
column "kept free for the panel" is measurable dead space: on `cover` it was 47.7% of the
safe width, and it squeezed the title into three lines with half the stage empty beside
it. Text uses the whole safe area; if an ornament lands on it, move the ornament
(`../decoration/PLACEMENT.md`). A half-width text column is legitimate only when a real
peer column — image, chart, second text block — sits in the other half.

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` ·
structure `stage fit deck slide band card tile badge` ·
marks `dot tick soft dim pagenum` ·
signature `photo panel chrome-foot`.

Sizes live in those classes. If something needs to be bigger, use the next class up — do
not write a `font-size`. Size a `tile` or `badge` with `--sz`, never `width`/`height`, and
wrap its numeral in a `<span>` so the figure scales with the box.
