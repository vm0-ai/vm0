# botane-organic — decoration placement

Everything here is measured from the original reference deck (15 pages, rendered 1600×900).
Numbers, not taste. Where a number contradicts `../design-system.md`, the number wins and
the contradiction is named.

Open `decoration.html` to see each item rendered with no text on the page.

**Do not carry bloom's decoration rules across.** They were measured on a different deck
and three of them are false here:

| bloom's rule | bloom | **botane** |
|---|---|---|
| ornaments hang off the stage edge | 94% | **0%** — botane's panels are flush, never bleeding |
| 15 of 17 pages carry a *pair* of big ornaments | 88% | **0 pages** — botane has no pairing device |
| roughly one page in four is a full-bleed colour field | 29% | **0 of 15** — botane's colour field is a half-panel |

## The layer model

| z-index | layer | where it comes from |
|---|---|---|
| 0–3 | decoration | this folder |
| 40 | `.fit` — all text | `../layouts/*.html` |
| 45 | pagenum | the shell |

Decoration sits **below** text and is never inside `.fit`. If a layout and an ornament
collide, move the ornament — never the copy.

## A · The colour-block panel — the template's one big move

**7 panels on 7 of 15 pages (47%).** Measured, all 7 agree on all three properties:

- `border-radius: 0` — 7/7. Square-cornered, always.
- full stage height — 7/7 at 99.78cqh.
- flush to exactly one stage edge — 7/7, four left, three right. **Never inset, never
  bleeding past the edge.** This is botane's answer to bloom's bleed rule, and it is the
  opposite instruction: 0 of 7 cross the stage bounds.

Two widths, and nothing between them:

| variant | measured | used on |
|---|---|---|
| wide field | 38 / 46 / 46 / 48 / 48 / 48 cqw | cover, section divider ×3, one content page, close |
| narrow spine | 8cqw | the agenda page only |

Grounds observed: `--g0` ×4, `--g1` ×1, `--g2` ×2. Cycle them so consecutive panels
differ; pair the text with the matching `--t0`/`--t1`/`--t2`.

**Which pages get one.** The 7 panel pages are cover, agenda, three section dividers, one
statement page, and the closing page. The 8 pages with no panel are every dense content
page — team, icon cells, process, gallery, statistics, quotes, pricing. That split is
exact in the reference and it is the rule: *a wide panel marks a change of page role; it
is not a background for body copy.*

```html
<div class="panel" style="right:0;width:46cqw;background:var(--g0);color:var(--t0)"></div>
<div class="panel" style="left:0;width:8cqw;background:var(--g0);color:var(--t0)"></div>
```

`.panel` already carries `position:absolute; top:0; height:100cqh; border-radius:0`.

## B · The accent dot — botane's quiet punctuation

**24 dots across 15 pages, 1.6 per page.** Sizes 0.7 / 1.0 / 1.2 / 1.4 cqw.
Fills: `--accent` ×16, `--s2` ×5, `--s1` ×3.

Corner distribution — **top-right 14, bottom-left 6, top-left 4, bottom-right 0**.

> **Never place a dot in the bottom-right corner.** 0 of 24 in the reference, because the
> page number lives there. Exact-equality criterion, reference reads 0, so this one gates.

`../design-system.md` says "every slide carries at least two accent-dots". **The reference
does not**: 9 of 15 pages carry two, 6 carry one. Two is the dominant pattern, not a
floor — do not add a second dot to a page that reads better with one, and do not read the
1.6 average as a quota.

```html
<div class="dot" style="right:6cqw;top:6cqh"></div>
<div class="dot" style="left:7cqw;bottom:18cqh;width:1cqw;height:1cqw;background:var(--s2)"></div>
```

## C · The circle photograph — and when it is not a circle

**17 photocells, 9 circular.** The split is not arbitrary and it is not what
`../design-system.md` says ("every photograph that is present is a circle"):

| the photograph is | treatment | count |
|---|---|---|
| standalone — a hero on or beside the colour panel | **circle**, `--r-round`, 14–28cqw | 7 |
| a small avatar beside a quotation | **circle**, `--r-round`, 4cqw | 2 |
| a member of a repeating set — team, gallery | **rounded rectangle**, `--r-md` | 7 |
| the one full-height edge portrait | rounded on the **inner** side only | 1 |

So: *a photograph that stands alone is a circle; a photograph that is one of a set is a
rounded rectangle.* Both are on-template. A grid of circles is not.

Never invent a photograph the source material does not support. When there is no image,
delete the frame — do not leave an empty `--ph` box.

## D · Vocabulary — 8 items, nothing else

| name | marker | what it is | reference count |
|---|---|---|---|
| panel | `.panel` / `data-bigcircle` | square-cornered full-height colour field | 7 |
| dot | `.dot` | solid circle, 0.7–1.4cqw | 24 |
| circle-photo | `data-photocell` | round image frame on `--ph` | 9 |
| rect-photo | `data-photocell` | rounded-rect image frame, `--r-md` | 8 |
| tile | `data-tile` | rounded square, icon at 55% | 4 (one page) |
| badge | `data-badge` | rounded square holding a numeral | 3 (one page) |
| node + connector | `data-node` / `data-connector` | circle on a hairline | 4 + 1 (one page) |
| donut | `data-bbadge` | open proportion ring, arc in `--accent` on `--ph` | 1 |

Do not invent arches, blobs, triangles, starbursts or quarter-circles. Botane's geometry
is the rectangle and the true circle, and nothing else.

## D2 · Small ornaments are a page device, not a sprinkle

Same finding as bloom, measured independently here. `tile`, `badge`, `node` and `donut`
are each concentrated on **exactly one page** of the 15:

- 4 tiles on the icon-cell page — every one of the 4 items has one
- 3 badges on the numbered-list page — every one of the 3 items has one
- 4 nodes + 1 connector on the process page — every one of the 4 steps has one
- 1 donut on the statistics page

The rule is *all or none*: if a page uses the device, every peer item on it gets one. A
set of four where two carry a tile is the failure mode. See
[item-sets.html](item-sets.html) for copyable markup.

Within one set the grounds cycle `--g0 --g1 --g2 --g3` with the matching `--t?` for the
icon or numeral, so neighbours never share a colour.

The shared leaf is an SVG, never a font glyph. Put it in the geometric `.tile` grid,
size every instance at 52%, and apply the same optical correction:
`transform:translate(15%,-4%)`. Its drawn outline is left-heavy and low inside the
24×24 viewBox, so raw mathematical centring is visibly wrong. For a node set, keep the
connector at `top:50%` with `translateY(-50%)` and `z-index:0`; every circular node
sits at `z-index:1`, so the hairline shares the centre axis and stays behind the fill.

## E · Colour — measured across all six preferred tokens

`../design-system.md` names six preferred tokens. A rule that only holds in `mauve_dusk`
is not a rule. Contrast of each token against its own `--bg`, worst case across
`mauve_dusk`, `forest_editorial`, `warm_sand`, `terracotta_clay`, `gold_luxe`,
`nordic_frost`:

| token | worst contrast on `--bg` | use as |
|---|---|---|
| `--ink` 12.5 · `--k1` 12.5 · `--k2` 12.5 · `--k3` 6.6 · `--ka` 4.7 · `--soft` 5.3 | pass | **text or fill** |
| `--g0` 3.97 · `--g1` 3.83 | pass | text or fill |
| `--accent` 2.18 · `--s1` 1.90 · `--s2` 1.23 · `--s3` 1.26 · `--g2` 1.23 · `--g3` 1.26 | **fail** | **fill only** |
| `--surface` 1.02 · `--ph` 1.14 | fail | fill only, and see below |

Two traps this table catches that a single-token check would not:

- **`--s3` is `--ink` in `mauve_dusk` and light in `terracotta_clay`.** It looks like a
  safe text colour if you only test the default token. It is not. Same for `--g3`.
- **`--accent` passes in `mauve_dusk` (3.33) and fails in `warm_sand` (2.18).**

For a coloured label on `--bg`, use the k-series — `--ka`, `--k1`, `--k2`, `--k3` are the
colour system's own contrast-safe text versions of the four source hues, and they are the
mechanism `../design-system.md` already specifies. On a `--g?` ground use the matching
`--t?`.

**This is a change to the reference.** The agenda page set its four row numerals in
`--accent` / `--s1` / `--s2` / `--s3`, reading 3.33 / 2.49 / 1.69 / 13.96 against the
page. Two of them tripped the probe's 3.0:1 floor and all four break under at least one
preferred token. They are now `--ka` / `--k1` / `--k2` / `--k3`, and the reference reads
`lowContrast 0`.

**`--surface` is near-white on a near-white page** — 1.02–1.11 across the six tokens. The
reference paints 4 `--surface` cards on the icon-cell page. That is 4 more than bloom's
reference, so unlike bloom **this cannot be a gate here** — but it is still an invisible
box. Prefer the reference's other panel treatments: no fill plus a hairline rule for
prose, `--g0..--g3` for a filled card, `--ph` for an image frame.

## F · What is measured but does not gate

Report these; do not block on them. The reference itself fails each one.

| criterion | reference reading | why it cannot gate |
|---|---|---|
| `boxesUnderfilledH` | **3** | all 3 are `data-bigcircle` panels carrying a chapter word — a colour field is meant to be wider than its text |
| decoration overlapping text | **2** | a dot at `left:7cqw;bottom:18cqh` lands on the team page's first caption |
| two dots per page | **9 of 15** | `design-system.md` claims every slide; the reference says 60% |
| every photo is a circle | **9 of 17** | `design-system.md` claims all; the true rule is standalone-vs-set (§C) |
| three rotated side labels | **2 of 15** | `design-system.md` says "at least three slides carry" one |

## G · The rotated side label

2 in the reference, both `rotate(-90deg)` against a vertical edge, `--soft`, 1.05cqw,
`letter-spacing:.24em`, uppercase, `z-index:3`. It is the detail that makes the template
read as editorial. It is decoration, not content — it lives outside `.fit`, which is why
it may sit in the top 11% where flowing text may not.

```html
<div style="position:absolute;left:46cqw;top:18cqh;transform-origin:0 0;
            transform:rotate(-90deg) translate(-50%,0);font-family:var(--fd),var(--cjk-display);
            font-weight:500;font-size:1.05cqw;letter-spacing:.24em;text-transform:uppercase;
            color:var(--soft);white-space:nowrap;z-index:3">About — 2026</div>
```

## H · Reference audit contract

The reference deck produces this diagnostic row:

```
overflow                 reference 0     must be 0
outsideSafeArea          reference 0     must be 0   (safe area is 6% — the mode of 115 runs)
aboveChromeBand          reference 0     must be 0
lowContrast              reference 0     must be 0   (after the agenda fix in §E)
boxesUnderfilledV        reference 0     must be 0
navigableSlides          reference 15    must equal the page count
orphanSlides             reference 0     must be 0
indirectSlides           reference 0     must be 0
decks                    reference 1     must be 1

boxesUnderfilledH        reference 3     report only — see §F
panels per deck          reference 7 on 15 pages (47%)
dots per page            reference 1.6, 0 of 24 in the bottom-right corner
```

A valid deck keeps every slide directly reachable and advances its live state on
arrow-key input.
