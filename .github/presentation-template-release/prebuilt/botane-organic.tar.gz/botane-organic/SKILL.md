---
name: botane-organic
description: Create a standalone 16:9 HTML presentation deck with the Botane Organic visual identity and direct-HTML workflow. Use when the user selects the Botane Organic presentation template or explicitly names botane-organic as the deck style. Best suited to warm editorial stories about sustainability, wellness, health, food, and organic lifestyles.
---

# Botane Organic presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one standalone HTML file with one live `.deck`. Keep every `.slide` as a direct child, give it one 16:9 `.stage`, and include the deck CSS and keyboard-navigation script once.
- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Create one direct-child `.slide` per planned page and one 16:9 `.stage` inside each slide.

### Sizing — the rule that decides whether a slide survives its own text

**Never write a `cqw`, `cqh`, `px`, `vw` or `vh` width or height on anything that holds
text.** That includes `flex-basis`: `flex:0 0 4cqw` freezes exactly the way `width` does.
Start from a layout in `layouts/`, which already obeys this, and add text to it.

| want                            | write                                                               |
| ------------------------------- | ------------------------------------------------------------------- |
| the safe area                   | padding on `.fit`, once — `12cqh 6cqw 9cqh`                         |
| peer columns                    | `flex:1` on each                                                    |
| a box that hugs its content     | `align-self:flex-start; max-width:100%`                             |
| a numbering gutter              | `flex:0 0 2.6em` plus `font-variant-numeric:tabular-nums`           |
| an ornament holding no prose    | `em`, or `--sz` on a `tile`/`badge`                                 |
| a bar whose length is the datum | `%`, in charts only                                                 |
| a hairline                      | `height:1px`                                                        |
| an out-of-flow badge            | `position:absolute` + `left/top/right/bottom` — placement, not size |

Everything else is flex. A filled box takes its height from its tallest child, not from
the stage: `flex:none` on the row, `flex:1` on each child. Putting `flex:1` on the _row_
makes the cards inherit the stage height and you get a slab of colour that is half empty.

- Use a `data-layout` container with Flexbox for the primary spatial relationship. Keep content groups in normal flow, and use absolute positioning only when an element's meaning or visual role depends on layering — the decoration layer, the page number, a rotated side label. Adapt proportions and nesting to each slide's communication job.
- Preserve the template's original visual character from `design-system.md` and the examples. Compose content and signature elements together according to their visual and semantic roles, whether they belong inside the main layout or on a separate layer.
- Review all regions and layers as one composition. Aim for readable balance, allowing intentional overlap and out-of-flow placement when they strengthen hierarchy, meaning, or the template's signature style.
- Treat every slide as a projected presentation canvas. Write concise visible copy for the audience and keep one clear hierarchy of title, supporting content, and evidence on each page.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

### Composing the identity layer

- Build every slide in three layers: a **ground** layer (stage background, colour
  fields, panels, grid), a **decoration** layer (the signature elements from
  `design-system.md`, positioned absolutely and free to be cropped by the stage
  edge or to overlap content), and a **content** layer (`.fit` and the text).
  Give the decoration layer a `z-index` below the content layer unless the
  element is meant to sit on top.
- Place the decoration first, then the content, so both layers are composed together.
- Copy the `Deck shell` CSS from `design-system.md` verbatim into the single
  `<style>` block and build slides out of its class names. Do not invent a
  parallel set of utility classes.
- Vary the composition slide to slide, but keep the chrome, the radius scale, and
  the signature elements constant. Variety belongs in the layout, never in the
  identity.
- Use the helper classes that the `Deck shell` CSS defines — `.photo`, `.panel`,
  `.dot`, `.chrome-foot`, `.tile`, `.badge`, `.card` — instead of repeating the same
  long inline style on every slide. They exist so the signature treatment is one class
  name, not a paragraph of CSS to remember, and a forgotten class is the usual reason a
  treatment goes missing. **Copy the whole `Deck shell` block including those four
  signature helpers.** Omitting them is silent: `.panel` becomes an unstyled div and
  every dot collapses to zero width, while the colour system still loads and every
  automated check still reads 0.
- Whitespace is part of the composition. A deliberately quiet half-slide can be
  finished when the hierarchy is balanced. Add a signature element or colour field only
  when its documented page role supports that composition.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

- The photo treatments in `design-system.md` describe **how** a photograph looks
  in this template when there is one. They are not an instruction to produce
  that many photographs.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

This template is split into two layers, and they are read in this order:

| read                                                                            | for                                                                                           |
| ------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| [layouts/README.md](layouts/README.md) + [layouts/](layouts/)                   | **structure** — purpose-specific, content-responsive layouts                                  |
| [decoration/PLACEMENT.md](decoration/PLACEMENT.md) + [decoration/](decoration/) | **identity** — the allowed roles and placement of panels, dots, photos and item-set ornaments |
| [design-system.md](design-system.md)                                            | tokens, type scale, deck shell, prohibitions                                                  |
| [layouts/](layouts/)                                                            | the two together, at full scale                                                               |

**Build a slide by picking a layout and adding decoration to it.** Read
`layouts/` for rhythm and scale, but take responsive structure from
`layouts/` and placement from `decoration/PLACEMENT.md`.

#### Slide type → layout

| the slide is                                       | use                                              |
| -------------------------------------------------- | ------------------------------------------------ |
| the opening                                        | `cover`                                          |
| an agenda or contents                              | `toc`                                            |
| a chapter break                                    | `section-divider`                                |
| the closing or contact page                        | `close`                                          |
| a concept beside its example                       | `two-column`                                     |
| three peer ideas                                   | `three-column` (ruled) or `color-cards` (filled) |
| one non-quoted thesis                              | `statement`                                      |
| a sustained article with context                   | `long-form`                                      |
| a list of points                                   | `bullets` (no disc bullets, ever)                |
| an ordered set of claims                           | `numbered-list`                                  |
| one sourced quotation                              | `big-quote`                                      |
| a row of figures                                   | `kpi-grid` (ruled) or `kpi-cards` (filled)       |
| one hero figure                                    | `stat-highlight`                                 |
| a rate, share or percentage                        | `stat-donut`                                     |
| rows of records or metrics                         | `data-table`                                     |
| a series over time                                 | `chart-bar` or `chart-line`                      |
| stages of a process                                | `process-steps`                                  |
| dated milestones                                   | `timeline`                                       |
| future horizons and exit signals                   | `roadmap`                                        |
| scheduled work across periods                      | `gantt`                                          |
| system layers and dependencies                     | `architecture`                                   |
| branches around a central idea                     | `mindmap`                                        |
| two things compared                                | `comparison` (quiet) or `versus` (loud)          |
| explicit benefits, trade-offs, and a decision rule | `pros-cons`                                      |
| challenge, intervention, outcome, and proof        | `case-study`                                     |
| people                                             | `team`                                           |
| plans or tiers                                     | `pricing`                                        |
| testimony                                          | `quote-cards`                                    |
| a set of categories                                | `icon-cells`                                     |
| a photograph leading on the left                   | `image-portrait`                                 |
| prose leading with a photograph on the right       | `image-right`                                    |
| one dominant standalone photograph                 | `image-hero`                                     |
| a set of photographs                               | `image-grid`                                     |

Pick the ruled or the filled register deliberately. Choose from the communication job
and the surrounding slide rhythm rather than sampling the catalogue at random.

- The `Signature elements` section gives exact markup for this template's
  decorations, motifs, badges, panels, and photo treatments. **Copy those snippets.
  Do not paraphrase them, redraw them,
  simplify them, or substitute a shape you find easier to write.** Change only
  size, position, colour token, and text content.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — signature elements, background
     treatment, chrome;
  4. every ornament follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is
  accurate but visually anonymous also fails. Omit optional ornament when it competes
  with content.

- Optional: [example/reference.jpg](example/reference.jpg) for the visual identity
  and [layouts/](layouts/) for full-slide scale, rhythm,
  and composition. When the reference image and this document appear to disagree,
  follow `design-system.md`.
- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. Its packets carry this template's column, spacing, and chrome behaviour; adapt one rather than inventing table markup, which is where these decks lose content. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use the prompt's `color-system` when supplied, otherwise a preferred token from
  `design-system.md`. Inline that one `color-systems/<token>.css` in the final HTML.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Reported fields

The single report includes these recommended targets:

```
overflow 0 · outsideSafeArea 0 · aboveChromeBand 0
lowContrast 0 · boxesUnderfilledV 0
decks 1 · orphanSlides 0 · indirectSlides 0 · navigableSlides == page count
```

Treat two readings as **report-only** and inspect their context:

- `boxesUnderfilledH` — a section-divider colour field may intentionally be wider than
  its chapter word.
- uses of `--surface` — prefer a hairline rule, a `--g?` ground, or `--ph` when the
  surface does not separate visibly from the page.
- Complete creation and revision tasks with the verified final HTML; complete review tasks with a concise, prioritized findings report.

#### Signature-element checks while authoring

While authoring, walk the `Self-check before delivery` list in
`design-system.md` as an identity audit:

- Confirm the content survived and every slide carries the required chrome.
- Verify every optional ornament is a named signature element and follows
  `decoration/PLACEMENT.md`.
- Confirm each remaining element is appropriate to that slide's page role. A reported
  geometric crossing remains an optional-review candidate under `Automated QA` below.
- Search the finished HTML for each pattern named in `Never do this` and remove
  every hit.

A clear, balanced content slide may correctly use no optional ornament.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
