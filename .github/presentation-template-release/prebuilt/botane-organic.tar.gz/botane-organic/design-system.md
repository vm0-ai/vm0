# Botane Organic

## Visual identity

Warm editorial sensibility combined with organic geometry: colour-block panels, circular numbering, circular icons, and occasional rotated side titles. Soft, spacious, and steady.

## Color system tokens

Before generating, read `color-system` from the prompt. If the prompt provides one of the valid tokens below, use it exactly. If it does not, select a token according to the content, audience, mood, information density, and readability. Use only one token throughout a deck.

The presentation category documented for this template is **M (single primary)** and its example token is `mauve_dusk`; determine the generation token using the rule above.

Valid tokens are limited to the following snake_case values:

- Single-primary M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`mauve_dusk`, `forest_editorial`, `warm_sand`, `terracotta_clay`, `gold_luxe`, `nordic_frost`

The default color system used in `example/reference.jpg` is `mauve_dusk`.
The identity is warm, calm and editorial. High-energy multicolour tokens (`carnival`, `pop_art`, `prism`) break it and must not be chosen by default.


After selecting a token, read `color-systems/<token>.css`, inline its only CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="mauve_dusk">
```

- Use `--bg`, `--surface`, `--ink`, `--soft`, and `--ph` for the page, surfaces, body copy, secondary text, and image placeholders.
- `--accent`, `--s1`, `--s2`, and `--s3` are source hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected by v1 for those source hues; use them for large icons or decorative symbols. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text. On an `--ink` colour field, use `--kad` for accent text. When a source hue needs stronger text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour blocks containing text, use `--g0` through `--g3` and pair the text with the corresponding `--t0` through `--t3`.
- HTML/CSS components must reference colours only through `var(--...)`; derive transparency, strokes, shadows, and gradients from defined tokens as well.

Use `--bg` as the primary page ground and rotate `--g0` through `--g2` across soft colour-block panels. Use `--k3` / `--ink` for titles and `--s3` for non-text structure.

```css
.slide { background: var(--bg); color: var(--ink); }
.surface { background: var(--surface); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Fraunces` as the display typeface and `Work Sans` as the body typeface.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500;600&family=Work+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Fraunces";
  --fb: "Work Sans";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "Songti SC", "STSong", "Noto Serif CJK SC", "Noto Serif SC", serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600; available body weights are 300 / 400 / 500 / 600. Use `--fd` for titles, hero numbers, and section numbers. Use `--fb` for body copy, labels, chart annotations, and tables. For CJK text, preserve the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the template's own base stylesheet. Copy it verbatim into the single
`<style>` block, immediately after the inlined colour-system CSS, before writing
any slide. It defines the 16:9 stage, the type scale, and the chrome and
decoration classes (`.kicker`, `.pagenum`, `.dot`, `.badge`, `.tile`, `.card`)
that the rest of this document refers to. A deck that invents its own class
names instead of using these will not look like this template.

The radius scale is part of the template's character, not a generic default —
do not replace it, and do not add a `border-radius` that is not one of these
tokens.

```css
:root{
  /* Botane Organic: sharp colour-block panels, softly rounded photos, true circles. */
  --r-xs: 0; --r-sm: 0; --r-md: 1.6cqw; --r-lg: 2.6cqw; --r-xl: 3.4cqw;
  --r-pill: 999px; --r-round: 50%;
  --fd: "Fraunces";
  --fb: "Work Sans";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "Songti SC", "STSong", "Noto Serif CJK SC", "Noto Serif SC", serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);border:1px solid color-mix(in srgb, var(--ink) 12%, transparent);}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}
  

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:6;}

.tile{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:grid;place-items:center;border-radius:var(--r-md);line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.tile>span{font-size:40cqw;line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.tile .leaf-glyph{width:52%!important;height:52%!important;display:block;transform:translate(15%,-4%);transform-origin:center;}
.badge{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.badge>span{font-size:40cqw;line-height:1;}
.tick{position:absolute;}
.card{background:var(--surface);border-radius:var(--r-md);}
.dot{border-radius:50%;}.qcircle{border-radius:50% 0 0 0;}.semi{border-radius:999px 999px 0 0;}.tri{width:0;height:0;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}
/* signature-element helpers — use these instead of repeating inline styles */
.photo{background:var(--ph);overflow:hidden;background-size:cover;background-position:center;background-repeat:no-repeat;border-radius:var(--r-round);}
.panel{position:absolute;top:0;height:100cqh;background:var(--g0);color:var(--t0);border-radius:0;}
.dot{border-radius:50%;position:absolute;width:1.4cqw;height:1.4cqw;background:var(--accent);}
.chrome-foot{position:absolute;left:7cqw;bottom:3.4cqh;opacity:.75;}
```
The number inside a `badge` and any text inside a `tile` must be wrapped in a
`<span>`. The wrapper is what makes the text scale with the box: it is measured
against the badge's own width, so the figure stays in proportion at any size.
Text placed directly in the box only follows `--sz`, and a deck that sizes the
box with `width`/`height` instead will render a small number in a large frame.
Size these with `--sz`, not `width`/`height`.


## Signature elements

These are not optional decoration. They **are** the template. A deck that drops
them is a generic deck wearing this template's colours, and it fails review.

Each element below is given as exact markup. Copy the snippet, keep its geometry
and its `var(--...)` colours, and change only size, position, and text content.
The listed counts describe reference usage; they are not minimums or delivery
quotas. Use only the elements supported by the closest reference page role.

## Element reference patterns

These counts describe how a 13–15 slide reference deck uses the named elements.
They help reveal the template's rhythm, but are neither floors nor a request to
fill every page. More ornament is not more fidelity: past a point it costs
legibility, which costs more than the ornament was worth.

| Element | Reference count per 13–15 slide deck | Note |
| --- | --- | --- |
| `colour-block-panel` | 2–4 wide fields; optional narrow spines | wide fields only on covers, section dividers, comparisons, or closings; never on dense content pages |
| `accent-dot` | 18–26 | two per slide, different corners and sizes |
| `donut` | 1–2 | one per rate or share worth isolating |
| `rotated-side-label` | 2–3 | against a panel edge only |
| `circle-photo` | only what the material supports, 0–4 | when there is one it is a circle on the panel; never generate one to hit a number |

Do not scale these counts mechanically for a longer or shorter deck. Rows that
say *only what the material supports* are content, not decoration: see the
photograph rule in `SKILL.md`. Use the table to check identity and page-role
rhythm, not to decide how many elements to add.

### 1. `colour-block-panel` — the full-height colour field

A square-cornered panel of `--g0` running the full height of the stage, taking
roughly 40–50% of the width, or a narrow `8cqw` spine at one edge. The wide
version is a high-level composition for a cover, section divider, comparison,
or closing slide. It is not a default content-page background.

**Reference use:** reserve the wide panel for those high-level page roles and
use it only when the text is composed wholly within the opposite field. Never
overlay the wide panel on body copy or use it to fill unused space. A dense
content slide stays on `--bg` or may use the narrow spine outside its text area.

```html
<div style="position:absolute;right:0;top:0;width:46cqw;height:100cqh;
            background:var(--g0);color:var(--t0);border-radius:0"></div>
```

Narrow spine variant:

```html
<div style="position:absolute;left:0;top:0;width:8cqw;height:100cqh;
            background:var(--g0);color:var(--t0);border-radius:0"></div>
```

### 2. `accent-dot` — the small solid circle

Small filled circles, `1.4cqw` across, in `--accent` or a paler supporting hue,
scattered near the top and bottom edges. They are the template's quiet
punctuation and the first thing that gets dropped.

**Reference use: every slide carries at least two accent-dots, in different corners and
at least one of them in a paler hue.**

```html
<div class="dot" style="position:absolute;left:7cqw;top:8cqh;width:1.4cqw;height:1.4cqw;
                        background:var(--accent);border-radius:var(--r-round)"></div>
<div class="dot" style="position:absolute;left:11cqw;top:8cqh;width:1cqw;height:1cqw;
                        background:var(--s3);border-radius:var(--r-round)"></div>
```

### 3. `circle-badge` / `icon-in-circle` — the round step marker

Numbered steps and process icons live inside solid circles on a connecting
hairline, never in squares.

**Reference use: on 1 of the reference deck's 15 slides.** This is the deck's single
process slide, not a treatment for every numbered list. Prose that happens to
enumerate — three reasons, four lessons — stays prose here; reach for circle
badges when the slide is genuinely a sequence of steps, and use them once.
Circles `5cqw`, alternating fills across `--g0`, `--g1`, `--g2`, `--g3`.

```html
<div style="width:5cqw;height:5cqw;border-radius:var(--r-round);background:var(--g0);color:var(--t0);
            display:flex;align-items:center;justify-content:center;font-family:var(--fd),var(--cjk-display);font-weight:600">01</div>
```

With an icon instead of a numeral:

```html
<div class="tile" style="--sz:5cqw;border-radius:var(--r-round);background:var(--g1);color:var(--t1)">
  <svg class="leaf-glyph" viewBox="0 0 24 24" style="stroke:currentColor;fill:none;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round">
    <path d="M11 20A7 7 0 0 1 4 13c0-5 5-9 11-9 0 6-4 11-9 11"/><path d="M2 22c2-2 5-5 9-7"/>
  </svg>
</div>
```

### 4. `donut` — the open proportion ring

An open ring showing one proportion, value arc in `--accent` on the `--ph`
track, figure centred inside.

**Reference use: at least one donut in any deck containing a rate, share, or
percentage.** `stroke-dasharray` is `value/100 × 238.76`, then `238.76`.

```html
<div style="position:relative;width:22cqw;height:22cqw">
  <svg viewBox="0 0 100 100" style="width:100%;height:100%">
    <circle cx="50" cy="50" r="38" fill="none" stroke="var(--ph)" stroke-width="9"/>
    <circle cx="50" cy="50" r="38" fill="none" stroke="var(--accent)" stroke-width="9"
            stroke-dasharray="171.9 238.76" stroke-linecap="round" transform="rotate(-90 50 50)"/>
  </svg>
  <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
    <div style="font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:4cqw;line-height:1">72%</div>
    <div class="cap soft">Repeat buyers</div>
  </div>
</div>
```

### 5. `rotated-side-label` — the vertical spine caption

A small uppercase label rotated 90° and set against a panel edge. It is the
detail that makes this template read as editorial.

**Reference use: at least three slides carry a rotated-side-label.**

```html
<div style="position:absolute;left:46cqw;top:18cqh;transform-origin:0 0;transform:rotate(-90deg) translate(-50%,0);
            font-family:var(--fd),var(--cjk-display);font-weight:500;font-size:1.05cqw;letter-spacing:.24em;
            text-transform:uppercase;color:var(--soft);white-space:nowrap;z-index:3">About — 2026</div>
```

### 6. `circle-photo` — the round photograph on a colour field

The house photo form is a circle sitting on the colour-block panel. An inset
rectangular photo rounded at `--r-lg` is the alternative.

**Reference use: none.** Use a photograph only where the supplied material describes a subject worth
showing, and then at most four across the deck. If it describes no such subject,
carry no photograph and let the colour-block panel and the donut do the work.
Every photograph that is present is a circle sitting on the colour panel.

```html
<div style="position:absolute;right:14cqw;top:50cqh;transform:translateY(-50%);width:28cqw;height:28cqw;
            background:var(--ph);border-radius:var(--r-round);overflow:hidden;
            background-size:cover;background-position:center;background-repeat:no-repeat;
            background-image:url('<image>')"></div>
```

## Decoration reference profile (diagnostic only)

Observed from this template's own reference deck, per slide, rendered at
1600×900. These averages combine unlike page roles: covers, section dividers,
dense content pages, comparisons, and closings.

**These figures are diagnostics, never quotas or per-slide instructions.**
First choose the closest page role in [layouts/](layouts/),
then use only the named signature elements and motifs demonstrated in that
composition. A utility class, empty colour field, outlined box, circle, pill,
arc, quarter-circle, or other shell geometry is not a motif by itself.

| per slide | decoration | size |
| --- | --- | --- |
| **0.3** | solid colour field | 20cqw and wider |
| **0.3** | solid colour field | 2.5–7.5cqw |
| **0.3** | circle or pill | 2.5–7.5cqw |
| **0.3** | drawn shape | 2.5–7.5cqw |
| **1.4** | circle or pill | 0.8–2.5cqw |
| **0.3** | drawn shape | 0.8–2.5cqw |
| **0.2** | circle or pill | under 0.8cqw |


Read the figures only as a whole-deck drift signal. Around half the reference
rate can be appropriate when the material or page-role mix differs. Judge
fidelity by motif identity, placement, and composition rather than item count.
Sparse slides are intentionally sparse.

The reference deck also fills **1.1 image placeholders per slide**. That is not a target: this template forbids inventing a photograph the source material does not support, so a deck built from a text-only source is right to draw fewer — and image placeholders are excluded from the counts above for the same reason.

The table counts only decoration with no text inside it. This template also paints **0.3 labelled boxes per slide** — nav cells, numbered badges, buttons, tags: a painted or bordered box with a word or two in it. They are counted separately, and this template barely uses them: 0.3 per slide is the whole budget. A deck that turns every label into a bordered chip is not this template — that is a different, busier design, and it is the most common way these decks drift away from their reference.

**A kicker is not a chip.** In this template's reference deck the `kicker`, the
page number, the running head and the standfirst are plain text — no background,
no border, no shadow, no rounded pill around them. Every one of the 23 reference
decks agrees on this, and giving them a box is the single most common way a
generated deck drifts: a kicker appears on every slide, so boxing it adds one
false chip per slide and doubles this template's labelled-box count on its own.

Only the elements the motif library actually draws as chips — `badge`, `tag`,
`pill`, and whatever else this file shows with a fill — carry a background.
Everything else that is text stays text.

**Before delivering, audit identity.** On three
representative slides, verify that every ornament maps to a named signature
element or to a specific composition in the reference. Use the table above only to notice gross whole-deck drift.

Content still comes first. Never push text off the stage, cover it, or drop a point. Never add a photograph
the source material does not support. A slide carrying six bullets may correctly
carry no optional ornament at all.


## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** A label positioned with `left:88cqw` will
overflow the moment its text is longer than the author guessed, and CJK copy is
routinely wider than the Latin draft it was written against. Anchor anything in
the right third with `right:` instead of `left:`, and anything in the bottom
third with `bottom:` instead of `top:`. A block anchored to the edge it is near
grows inward, where there is room, instead of outward into nothing. Give any
absolutely-positioned text an explicit `max-width` so it wraps rather than
extends.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a grid or a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

A finished slide keeps repeated items on one structural alignment and keeps
content clear of every unintended stage edge.

## Required chrome

Every slide carries all three, or the deck is incomplete:

1. **Footer label**, bottom-left — an uppercase `.kicker` such as
   `Botane &nbsp;·&nbsp; 04`, using a stable deck word drawn from the subject:
   `<div class="kicker" style="position:absolute;left:7cqw;bottom:3.4cqh;opacity:.75">Botane &nbsp;·&nbsp; 04</div>`
2. **Page number**, bottom-right: `<div class="pagenum">04</div>` — two digits, zero-padded.
3. **Two accent-dots.**

## Background rhythm

Most slides sit on the pale `--bg` with a serif display face and generous space.
The occasional colour-block panel marks a deliberate change of page role:

- panel right, text left (cover);
- panel left, text right (section divider, comparison, or closing);
- narrow spine at one edge;
- one full-stage `--g0` field for a section divider or big quote;
- one plain `--bg` slide with only a donut and figures.

**Reference use:** a 13–15 slide deck normally needs only 2–4 wide-panel or
full-stage pages in total. Do not place them on consecutive dense content pages.

## Decoration safe area

Decoration is placed before content, but it never fights the content.

- Every slide has a **text safe area**: the region actually occupied by the
  title, body copy, figures, and labels. No decoration may sit on top of it.
- Decoration belongs in one of three places: outside the safe area entirely
  (edges, corners, the empty half of the stage); behind it at `z-index:0`–`1`
  **and** at a contrast low enough that the text stays fully legible; or
  deliberately overlapping a photograph or colour field where the reference
  shows exactly that.
- A large ornament — a wire globe, a big circle, a blob, an oversized sprig —
  must be cropped by the stage edge rather than floated in the middle of the
  composition, unless it carries content itself.
- Never place body copy or a caption directly on top of a photograph unless the
  photograph is a full-bleed field with a text-safe treatment behind the copy.
- Decorations never land on text or reduce title legibility. When the two
  conflict, move the decoration, not the text.

## Never do this

- Never round the corners of a colour-block panel. Panels are square-cornered;
  only photos and badges are round.
- Never use disc/dot list bullets. Use circle badges, numbered rows, or a
  hairline rule between rows.
- Never render a process or timeline with square step markers.
- Never use drop shadows.
- Never let the whole deck sit on plain `--bg` with no colour-block panel.
- Never set body copy in the display serif; `--fd` is for titles and figures only.
- Never let a slide go out without its footer label and page number.

## Self-check before delivery

Review identity and page-role fidelity. Fix the deck before
delivery if any line fails.

0. Every optional ornament maps to a named signature element or a specific
   composition in `layouts/`.
1. Signature elements appear only on the page roles where the reference uses
   them, with clear space and no text collision.
2. Every slide carries the items listed under `Required chrome`.
3. Every photograph follows the documented template treatment and illustrates
   a subject the material describes. Zero photographs is valid.
4. Every prohibition under `Never do this` was checked against the final HTML.
5. Exactly one `data-color-system` token is present and it is preferred.
6. The decoration profile was read only as a gross drift signal.

Visual reference: [example/reference.jpg](example/reference.jpg) —
the rendered proof of every rule above. [layouts/](layouts/)
is the same deck in code; open it when a snippet here needs more context.
