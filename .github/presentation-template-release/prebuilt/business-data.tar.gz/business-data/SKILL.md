---
name: business-data
description: Create, revise, or review standalone 16:9 HTML presentation decks with the Business Data visual identity and direct-HTML workflow. Use when the user selects the Business Data presentation template or explicitly names business-data as the deck style. Best suited to bright, data-first operating reviews, market analyses, KPI reports, and business metrics.
---

# Business Data presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## Choose the task mode

- Create: use Sections 1–5 and complete Section 2 before writing any slide HTML.
- Revise: inspect the existing HTML, reconstruct or update the outline for the affected sequence, and complete Section 2 before editing slide HTML; then use Sections 3–5 as relevant while preserving valid shell, token, identity, and runtime implementation.
- Review: use Sections 1–3 for context and Section 5 as the checklist; infer the deck's throughline and slide-level content contract, skip Section 4, and do not edit. Report slide-specific findings in P1 / P2 / P3 order (blocking / material / polish), include evidence and a fix direction, or state explicitly that there are no actionable findings.

## 1. Define the communication job

- Read the prompt and all supplied source material before composing slides.
- Identify the audience, purpose, desired audience outcome, core takeaway, and required evidence.
- Express the communication job in one sentence: by the end, the audience should reach the desired outcome because of the core takeaway.
- Ground every factual claim and number in supplied or verified sources; label forecasts, targets, and assumptions explicitly.

## 2. Complete the slide outline before HTML

- Before creating or changing slide HTML, write a lightweight plain-text or Markdown outline. State the one-sentence throughline, then list the slides in order.
- For each slide, record its working takeaway title, the point it must establish, and the evidence or data that supports it with its supplied or verified source. Mark forecasts, targets, assumptions, and slides that need no evidence.
- Review the complete outline for narrative flow, duplicated claims, missing evidence, and a deliberate opening and ending. Choose the slide count from the content.
- Treat the completed outline as the content contract for implementation, not as a layout schema. Keep layouts and identity treatments out of it, keep it out of audience-facing HTML unless requested, and update it first when a slide's title, communication job, or evidence changes materially.

## 3. Load the local identity

- Read [design-system.md](design-system.md) **completely, to the last line**, before
  writing any HTML. It is the authoritative definition of this template. Its
  `Deck shell`, `Identity vocabulary`, `Persistent chrome`, `Background rhythm`,
  `Never do this`, and `Self-check before delivery` sections are requirements,
  not suggestions.
- The `Identity vocabulary` section gives exact markup for this template's persistent
  chrome, data components, badges, panels, and photo treatments. **Copy those snippets.
  Do not paraphrase them, redraw them,
  simplify them, or substitute a shape you find easier to write.** Change only
  size, position, colour token, and text content.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — flex composition, typography, colour rhythm,
     content components and persistent chrome;
  4. no optional ornament is invented or inferred from layout geometry.

  Identity treatments never win against 1 or 2. They must not displace content, shrink
  copy or drop a point. A deck that is accurate but visually anonymous also fails, so use
  the documented layouts and chrome rather than filling space with shapes.

- Inspect [example/reference.jpg](example/reference.jpg) for the visual identity
  and [layouts/](layouts/) for full-slide scale, rhythm,
  and composition. When the reference image and this document appear to disagree,
  follow `design-system.md`.
- Read [composition-recipes.html](composition-recipes.html) to identify the page role and
  evidence packet for a table, record list, or repeated row, then start from the matching
  flex construction in `layouts/table.html`, `layouts/big-quote.html`, or
  `layouts/comparison.html`. Do not copy content-specific fixed grid widths.
  An identifier, code, or number column takes only the width its content needs and never
  wraps; only the prose column absorbs the slack.
- Use a valid prompt `color-system` when supplied. Otherwise select one of the
  **preferred tokens** named in `design-system.md` — not an arbitrary token from
  the full list. Load exactly one `color-systems/<token>.css` file and inline
  its CSS in the final HTML.
- Use this folder as the template guidance; the selected atomic colour-system
  file is the only shared template resource.

## 3b. Pick a layout, then apply the identity

Use `layouts/` for scale and rhythm, not as a source of reusable geometry.
Build from these instead:

- **[layouts/](layouts/)** — 42 flex layouts, one file each, plus
  [layouts/README.md](layouts/README.md). They include the content-bearing components they
  need and carry no optional decoration or frozen text sizes. Start here.
- **[decoration/](decoration/)** — the classification and placement rules
  ([PLACEMENT.md](decoration/PLACEMENT.md)) plus the rendered vocabulary showing that this template has
  **no optional decoration** ([decoration.html](decoration/decoration.html)). Its plus-mark,
  footer and page-number anchor are persistent chrome and are counted separately. There is
  no `item-sets.html`: tiles, badges, nodes and connectors are layout components, not motifs.

Pick the layout whose **job** matches the slide, retain its content components, then add the
documented persistent chrome. Do not start from a blank stage and do not invent ornament to
fill an empty region.

| the slide is                                | layout                                           |
| ------------------------------------------- | ------------------------------------------------ |
| the opening                                 | `cover`                                          |
| a contents page                             | `toc`                                            |
| a chapter break                             | `section-divider`                                |
| the closing / contact page                  | `close`                                          |
| one authored conclusion with no attribution | `statement`                                      |
| sustained narrative with one evidence rail  | `longform`                                       |
| two threads of one argument                 | `two-column`                                     |
| three parallel ideas                        | `three-column` (ruled) · `color-cards` (filled)  |
| a list of points                            | `ruled-list`                                     |
| ranked or numbered commitments              | `numbered-list`                                  |
| capabilities or service lines               | `icon-cells`                                     |
| customer quotes                             | `quote-cards` · one decisive quote → `big-quote` |
| plans, tiers, packages                      | `pricing`                                        |
| a row of headline figures                   | `kpi-grid`                                       |
| one figure taken to hero scale              | `stat-hero`                                      |
| rates, shares, percentages                  | `rates`                                          |
| proportions of one whole                    | `bar-rows`                                       |
| a quantity across categories                | `chart-bar`                                      |
| one series over time                        | `chart-line`                                     |
| tabular evidence                            | `table`                                          |
| an executive decision brief                 | `executive-summary`                              |
| one operating snapshot                      | `dashboard`                                      |
| stage-by-stage conversion                   | `funnel`                                         |
| a bridge from opening to closing value      | `waterfall`                                      |
| two-dimensional intensity                   | `heatmap`                                        |
| stages of a process                         | `process`                                        |
| system layers and dependencies              | `architecture`                                   |
| one central idea and its branches           | `mind-map`                                       |
| dated events in order                       | `timeline`                                       |
| what comes next, by quarter                 | `roadmap`                                        |
| who is on what, and when                    | `gantt`                                          |
| gains against costs                         | `pros-cons`                                      |
| before against after                        | `comparison`                                     |
| two alternatives with no implied winner     | `versus`                                         |
| context, intervention and measured result   | `case-study`                                     |
| one photograph beside copy                  | `image-left` · `image-right`                     |
| one photograph carrying the page            | `image-hero`                                     |
| several photographs                         | `image-grid`                                     |
| named people                                | `team`                                           |

Never a pie or doughnut chart: proportions are `bar-rows`, single rates are `rates`.
There is no filled counterpart to `kpi-grid` — figures never go inside a card.

### Two rules from those files that decide whether a deck looks like this template

- **Source hues are fills; `--ka` `--k1` `--k2` `--k3` are text.** On a `--gN` ground
  use the matching `--tN`. On a full-bleed page, let kickers inherit a documented readable
  foreground.
- **Use plus-marks only as documented persistent chrome.** Follow
  `decoration/PLACEMENT.md` for page roles, position, and foreground; do not turn a
  deck-level count or pair rate into a generation rule.

### Images are content choices, not decoration

Use a photograph or other image whenever it communicates the slide more clearly,
credibly, or memorably than text alone. The supplied material does not have to
explicitly request an image; make that editorial choice from the content.

- Choose sources in this order: user-supplied images and visual materials first,
  including media embedded in or linked from the supplied material; then relevant
  imagery from the supplied references and related information; then an AI-generated
  image grounded in the slide's actual subject when it would work better or no suitable
  sourced image exists.
- Never add or generate an image merely to fill an empty region. When no image improves
  the slide, use the template's
  non-photographic treatments instead: a supported colour-field role, a data graphic,
  a large source-backed figure, or generous space.
- Every caption, alt text, and label beside an image must come from the
  material. Never invent a caption to justify a picture.
- A generated image that illustrates nothing in the material makes that slide
  unfaithful to its source, which costs far more than the missing picture would
  have.
- The photo treatments in `design-system.md` describe **how** a photograph looks
  in this template when there is one. They are not an instruction to produce
  that many photographs.

## 4. Build the deck

- Produce one standalone HTML file with one live `.deck`. Keep every `.slide` as a direct child, give it one 16:9 `.stage`, and include the deck CSS and keyboard-navigation script once.
- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Create one direct-child `.slide` per planned page and one 16:9 `.stage` inside each slide.

### Layout approach

- Start from the matching file in `layouts/` and keep all audience-facing content in
  normal-flow flex rows and columns. Do not use CSS Grid, floats, or absolute positioning
  to lay out text.
- The safe area is set once by `.fit` padding. On anything that holds text, do not write
  `width`, `max-width`, `min-width`, `height`, `left`, `top`, `right`, `bottom`, `flex`,
  or `flex-basis` in `cqw`, `cqh`, `px`, `vw`, or `vh`. Peer columns are `flex:1`; a lone
  filled box hugs its content; a row of peers divides the safe area.
- Absolute positioning is reserved for persistent chrome, the fixed `.fit`, a connector,
  an out-of-flow badge, or a textless background field. Percent widths are reserved for
  values in charts and gantt bars.
- Preserve the template's visual character from `design-system.md`, but take structure
  from `layouts/` and placement from `decoration/PLACEMENT.md`.
- Treat every slide as a projected presentation canvas. Write concise visible copy for the audience and keep one clear hierarchy of title, supporting content, and evidence on each page.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep persistent chrome, typography, colour rhythm and content-component treatments consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

### Composing the identity layer

- Build every slide in three layers: a **ground** layer (stage background and colour
  fields), a **content** layer (`.fit`, text, media, data plots and their components), and
  a **persistent-chrome** layer (plus-mark, footer and page-number anchor) placed exactly
  as `decoration/PLACEMENT.md` specifies. This template has no optional-decoration layer.
- Treat whitespace as whitespace. Do not turn an empty region into a decorative square,
  circle, blob, arch, card or colour block.
- Start from `layouts/_shell.html`, inline the selected colour-system CSS, and build
  slides out of its class names. Do not invent a parallel set of utility classes.
- Vary the composition slide to slide, but keep the chrome, radius scale, typography and
  component treatments constant. Variety belongs in the page role, never in the identity.
- Use the helper classes that the `Deck shell` CSS actually defines — `.photo`,
  `.track`, `.chrome-foot`, `.tile`, `.badge`, `.card`, `.dot`, `.kicker`,
  `.pagenum`, `.soft`, `.dim` — instead of repeating the same long inline style on
  every slide. They exist so the signature treatment is one class name, not a
  paragraph of CSS to remember, and a forgotten class is the usual reason a
  treatment goes missing.
- **Size `tile`, `badge` and `node` with an `em` value in `--sz`, never a container-unit
  `width`/`height`,** and wrap a
  badge's digits in a `<span>`. That is what makes the text scale with the box; text
  placed directly in the box renders small inside a large frame.
- **Do not write a `width`, `max-width`, `min-width`, `height`, `left`, `top`, `right`,
  `bottom`, `flex`, or `flex-basis` in `cqw`/`cqh`/`px`/`vw`/`vh` on anything holding
  text.** Columns are `flex:1`; a box that should hug its content takes
  `align-self:flex-start;max-width:100%`; the safe area is the padding on `.fit`
  (`11.6cqh 6cqw 8cqh`) and is set once, not per slide.
- Whitespace is part of the composition. A deliberately quiet half-slide can be finished
  when the hierarchy is balanced. Use a colour field only when its documented page role
  and the source content support that composition.

## Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Getting the container right

A percentage bar height resolves against its parent's **definite** height. Break
that chain and the bar computes to exactly `0` — it vanishes while the labels,
values and legend still render, so the page reads as merely empty. Measured on
generated decks: 52 of 558 percentage bars rendered at zero, and one deck spent
455s of gate repair on this alone.

`layouts/chart-*.html` already carries a structure that works. Copy it rather
than inventing lanes. Three rules make the chain definite:

1. **A bar is a direct child of the plot box.** Any level between them needs its
   own definite height, and one that lacks it zeroes everything below.
2. **All columns share one grid, so the label row is shared.** A label that wraps
   to two lines must cost every column the same height, or the bar above it is
   measured against a shorter ruler than its neighbours. Make the plot
   `display:grid; grid-auto-flow:column; grid-auto-columns:1fr` with
   `grid-template-rows:1fr auto …` (one row per item in a column, exactly — a
   spare row pulls the next column's first item into the previous column), and
   give each column wrapper `display:contents`. The markup grouping stays "one
   div per column"; only the rows become shared.

   Measured on the template's own `chart-bar.html`, changing nothing but one
   label to a wrapping name: baseline offset 0 → 19px, and the fourth bar 342 →
   324px — the value never changed, the bar just lost 5%. With the shared grid
   the same label costs all four bars the same 8%, and the ratios stay exact.

3. **Every level is either `flex:none` or `flex:1`** — sized by its content, or
   taking the remainder. There is no third kind.

4. **A value label never shares the lane with the bar it labels.** If it does,
   flex has to fit label + gap + bar into the lane, so it shrinks the bar — and
   only the bars tall enough to run out of room. The scale stops being linear at
   the top: measured on `bloom/chart-bar.html`, lane 336px, label 19px, gap 6px,
   every value above 92.5% rendered at the same 310px, so **96 and 100 drew
   identically**. Under the template's own "percentages of the tallest value"
   convention the tallest bar is always 100%, so this fires on every chart.
   Reserve the label row on the lane (`padding-top`, measured once per template)
   and set both children `flex:none`; the bar then resolves against the lane
   minus that reserve, the same reserve for every column.

Grouping two bars per category still obeys this, but the group wrapper needs
`align-self:stretch`, or it is sized by content and the lane inside it collapses.

Do not "fix" a flat chart by enlarging the numbers or switching to a table. The
values are right; the container chain is not.

## How full a page should be

Measured across all 902 layouts in the 23 shared templates, so this is what the
system already does — not a target invented for the occasion:

|                                                                                  | p25 |  median | p75 |
| -------------------------------------------------------------------------------- | --: | ------: | --: |
| vertical coverage (share of the stage height that carries ink or a filled block) | 33% | **43%** | 61% |
| ink area (share of the stage area)                                               |  9% | **12%** | 16% |
| lowest ink (how far down the page the content reaches)                           | 68% | **75%** | 90% |

**Aim for the middle column.** A content page that stops at 40% of the height and
leaves the rest blank reads as unfinished; one that runs past 25% ink area reads as
a wall. Both are allowed when the material calls for it — a statement page is one
huge line at 6% coverage, a table or a longform page is legitimately dense — but
neither is the default.

Two things that are **not** the same:

- **A void at the bottom.** Content stops early and nothing follows. This is the
  one to avoid; measured on the naked layouts, 73 of 902 pages do it.
- **Air between blocks.** A title, then a band of columns centred in the space
  below it. That is composition, not a defect — do not fill it just to fill it.

If the material genuinely does not fill the page, cut a column or merge the page
into its neighbour rather than padding sentences.

## 5. Verify before delivery

- Render and inspect every slide at full presentation size, then review the complete sequence for narrative flow and visual rhythm.
- Compare the rendered deck with the completed outline; confirm every title, communication job, evidence item, and source status remains aligned and no planning notes appear in audience-facing copy.
- Check title wrapping, body readability, data labels, contrast, clipping, overflow, unintended overlap, unresolved placeholders, and identity consistency.
- Run `tools/run.sh <deck>` at 1600×900 after fonts settle. Require `titleBodyOverlaps`, `bodyCtaOverlaps`, and `textBigcircleOverlaps` all equal 0; any non-zero result is blocking. These semantic intersections have no bypass.
- Inspect every `textVisualOverlapCandidates` sample in the rendered slide. This field is advisory: repair or move the motif when it obscures any glyph or reduces the text to doubtful readability; keep an intentional crossing only when every word remains immediately legible. Do not auto-fail a clear, harmless overlap.
- Review the slide as a complete composition. Confirm that text, media, data, content components and chrome remain legible, and that every layer or overlap supports an intentional visual relationship.
- Confirm the prompt-selected colour-system is used exactly, or record the valid token chosen when the prompt omitted it.
- Confirm the delivered HTML contains one live `.deck`, one navigation runtime, and only the markup and CSS used by its rendered slides.
- **Confirm every `.slide` is a direct child of the `.deck`.** The navigation runtime
  collects pages with `[...deck.children].filter(n => n.classList.contains('slide'))`, so a
  slide nested one level deeper, or written after the deck's closing `</div>`, renders
  perfectly and cannot be reached by the arrow keys. Nothing else catches this — the page
  looks right, scrolling still works, and a screenshot shows no defect. One line:

  ```js
  document.querySelectorAll(".slide").length ===
    [...document.querySelector(".deck").children].filter((n) =>
      n.classList.contains("slide"),
    ).length;
  ```

- Test `← / ↑ / → / ↓`, `Home`, and `End` **by actually pressing them**, and confirm you
  reach the last slide; confirm focused editable controls retain their normal key behaviour.
- Complete creation and revision tasks with the verified final HTML; complete review tasks with a concise, prioritized findings report.

### Identity audit

Before delivering, walk the `Self-check before delivery` list in
`design-system.md` as an identity audit:

- Confirm the content survived and every page carries the documented footer,
  `.pagenum` anchor, and page-role-appropriate plus-mark treatment.
- Confirm the strict optional-decoration count remains zero. A tile, badge, node,
  connector, progress ring, bar, colour field, media frame, card or grid cell is content
  or layout structure and must never be counted as decoration.
- Confirm each remaining element is appropriate to that slide's page role and
  does not sit on top of text.
- Search the finished HTML for each pattern named in `Never do this` and remove
  every hit.

This template has no optional decorations. Preserve its identity through layout,
typography, colour rhythm, and persistent chrome; never manufacture ornament.

## Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding. Run `tools/run.sh <deck>` and require `safeAreaShells`, `outsideSafeArea`, and `emptyPhotocells` all to equal `0`; any non-zero result blocks delivery.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
