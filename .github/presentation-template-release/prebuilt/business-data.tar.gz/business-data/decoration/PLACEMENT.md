# business-data — identity placement

Everything here is measured from the original reference deck (15 pages, rendered at
1600×900). These are this template's readings, not bloom's.

## Classification result: zero optional decorations

Classify before counting. Optional decoration must be template-specific, textless,
data-free, outside `.fit`, and perform no content or layout function. The business-data
reference contains **zero** elements that meet that definition.

- `plus-mark`, the footer label and `.pagenum` are persistent chrome, counted below.
- tiles, badges, nodes and connectors are content-bearing or layout structure.
- progress rings, tracks, bars and stat figures encode data.
- photocells are media content.
- cards, colour fields, panels, rectangular backgrounds and grid cells are layout.

Therefore this template has no `data-decoration`, `data-deco`,
`data-decoration-size="small"` or `data-deco-small` elements, and no
`item-sets.html`. Do not invent a circle, square, arch, blob, pill, empty colour block or
other geometry to satisfy a decoration quota. See `decoration.html` for the rendered
“No optional decorations” proof.

## Layer model

| z-index | layer | contents |
|---|---|---|
| 0–2 | ground/layout | stage colour, textless background field, data plot |
| 40 | content | `.fit`, text, media and content components |
| 45 | persistent chrome | page-number anchor; plus-marks remain below content at z 2 |

There is no optional-decoration layer.

## A · Persistent chrome — calibrated separately

The reference separates three checks:

- **footer label**, bottom-left — present on **15/15** pages: `.kicker`,
  `left:6cqw;bottom:3.4cqh;opacity:.7`
- **page-number anchor**, bottom-right — `.pagenum` exists on **15/15** pages; **10/15**
  carry a visible, zero-padded number, while five divider/emphasis/closing pages leave the
  anchor empty
- **plus-mark** — at least one on **15/15** pages; the deck has 29 total

### Plus-mark placement

| reading | reference |
|---|---|
| marks per page | **1.93** (29 / 15) |
| pages with two or more | **73%** (11 / 15) |
| marks outside the stage | **0%** (0 / 29) |
| size | **1.0–1.6cqw** |

The mark is persistent chrome, not optional decoration. A page with zero is a defect; the
73% pair rate and 1.93/page are reported deck-level readings, not per-page gates.

Marks sit fully inside the stage, about `6cqw` / `6cqh` from the nearby edge. A pair
uses opposite corners. Bottom marks normally use `bottom:11cqh` to clear the footer.

```html
<svg style="position:absolute;right:6cqw;top:6cqh;width:1.4cqw;height:1.4cqw;z-index:2"
     viewBox="0 0 24 24" aria-hidden="true">
  <path d="M12 4 V20 M4 12 H20" stroke="var(--accent)"
        stroke-width="2.6" stroke-linecap="round"/>
</svg>
```

Colour is ground-dependent:

| stage ground | stroke | measured reason |
|---|---|---|
| `--bg` | `var(--accent)` | 4.19:1 in berry_pop |
| `--g3` / `--ink` | `var(--accent)` | 3.73:1 |
| saturated `--g0` | `var(--bg)` | accent on g0 is 1.07:1 |

## B · Layout and content vocabulary — never count as decoration

These markers make the components auditable. They remain inside their matching layout.

| component | marker | role |
|---|---|---|
| photocell | `data-photocell` | media frame; inset uses `--r-md`, edge-bleed uses 0 |
| tile | `data-tile` | icon-bearing item component, `--sz:4.6em` |
| node | `data-node` | process stage component, `--sz:6em` |
| badge | `data-badge` | numbered content label, `--sz:5em`, digits in `<span>` |
| connector | `data-connector` | process relationship, 1px hairline |
| progress ring | `data-bbadge` | one data value and its track |
| track | `.track` | proportional data bar |
| background field | `data-background-field` | textless layout ground, never an ornament |

Tiles, nodes and badges use an `em` value in `--sz`; never hide cqw/cqh/px/vw/vh
sizing in the custom property. The icon or number is part of the content component.

## C · Colour: source hues are fills, `--k*` is text

Measured across all six preferred colour systems:

| token | berry_pop | ocean_deep | mint_tech | bauhaus | slate_corp | midnight |
|---|---:|---:|---:|---:|---:|---:|
| `--accent` | 4.19 | 7.15 | **2.51** | 3.82 | 5.95 | 15.75 |
| `--s1` | 4.46 | 4.42 | **2.72** | 5.21 | 3.47 | 3.84 |
| `--s2` | **1.61** | **1.55** | **1.43** | **1.61** | **2.14** | **1.71** |
| `--ka` `--k1` `--k2` `--k3` | 15.6 | 7.2–13.6 | 9.3–14.8 | 5.2–15.4 | 6.0–15.6 | 15.8–16.6 |

- text → `--ka`, `--k1`, `--k2`, `--k3`, `--ink`, `--soft`
- fills and non-text graphics → `--accent`, `--s1`, `--s2`, `--s3`,
  `--g0`–`--g3`
- text on a `--gN` ground → matching `--tN`

`--s2` fails as text in every preferred system; `--accent` and `--s1` fail in
mint_tech. On dark `--ink` / `--g3`, `--soft` reads 2.39:1 and `--ka` 1.0:1;
use `color:inherit` plus opacity for a kicker on a colour field.

## D · Ground rhythm

The reference uses full-stage colour on **5/15 pages (33%)**: three dark chapter/voice
pages, one stat hero and the close. Full-bleed pages carry no cards or panels. One further
page uses a textless half-stage `data-background-field`; it is layout, not decoration.
Treat both readings as deck diagnostics, not quotas.

## E · Photographs are content

The reference carries 16 photocells across 15 pages (**1.07/page**). This is not a target:
when the source has no supported image, delete the frame. Never leave an empty placeholder,
manufacture a rectangle to fill space, desaturate a photograph or crop one as a circle.

## Verification

```bash
cd ../tools
SAFE=.061 ./run.sh ../../layouts/*.html
```

Reference exact gates:

```
overflow 0             outsideSafeArea 0
lowContrast 0          columnsMisaligned 0
aboveChromeBand 0      boxesUnderfilledV/H 0
orphanSlides 0         indirectSlides 0
optional decoration 0  small optional decoration 0
```

Also require `navigableSlides == pages`, and actually press an arrow key. Report the
chrome distribution separately: 1.93 plus-marks/page, 73% paired pages, 0% bleeding.
