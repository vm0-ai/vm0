# Business Data

## Visual identity

Data-first, bright, and professional. Large figures, bars, rings, and restrained imagery form the information hierarchy; a primary accent and structural colours give data slides a distinct identity.

## Color system tokens

Before generating, read `color-system` from the prompt. If the prompt provides one of the valid tokens below, use it exactly. If it does not, select a token according to the content, audience, mood, information density, and readability. Use only one token throughout a deck.

The presentation category documented for this template is **M (single primary)** and its example token is `berry_pop`; determine the generation token using the rule above.

Valid tokens are limited to the following snake_case values:

- Single-primary M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`berry_pop`, `ocean_deep`, `mint_tech`, `bauhaus_primary`, `slate_corporate`, `midnight_mono`

The default color system used in `example/reference.jpg` is `berry_pop`.
The identity is bright and professional: one confident accent carrying data emphasis against a clean ground.


After selecting a token, read `color-systems/<token>.css`, inline its only CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="berry_pop">
```

- Use `--bg`, `--surface`, `--ink`, `--soft`, and `--ph` for the page, surfaces, body copy, secondary text, and image placeholders.
- `--accent`, `--s1`, `--s2`, and `--s3` are source hues for fills and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the foreground colours selected by v1 for those source hues; use them for icons and graphic symbols. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text. On an `--ink` colour field, use `--kad` for accent text. When a source hue needs stronger text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour blocks containing text, use `--g0` through `--g3` and pair the text with the corresponding `--t0` through `--t3`.
- HTML/CSS components must reference colours only through `var(--...)`; derive transparency, strokes, shadows, and gradients from defined tokens as well.

Alternate `--bg` content slides, `--g0` emphasis slides, and `--g3` key slides. Use `--s1` / `--s2` for supporting chart series, and let only one colour field carry the core data on each slide.

```css
.slide { background: var(--bg); color: var(--ink); }
.surface { background: var(--surface); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Space Grotesk` as the display typeface and `Lexend` as the body typeface.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600&family=Lexend:wght@300;400;500;600&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Space Grotesk";
  --fb: "Lexend";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600; available body weights are 300 / 400 / 500 / 600. Use `--fd` for titles, hero numbers, and section numbers. Use `--fb` for body copy, labels, chart annotations, and tables. For CJK text, preserve the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

The canonical, copyable base stylesheet is `layouts/_shell.html`. Start from that file,
inline the chosen colour-system CSS, and keep its class names. The block below mirrors
the shell for reference; if the two ever differ, `_shell.html` wins.

The radius scale is part of the template's character, not a generic default —
do not replace it, and do not add a `border-radius` that is not one of these
tokens.

```css
:root{
  /* Business Data: sharp panels and colour fields, gently rounded photos, fully round bars. */
  --r-xs: 0; --r-sm: 0; --r-md: 1.2cqw; --r-lg: 1.6cqw; --r-xl: 2cqw;
  --r-pill: 999px; --r-round: 50%;
  --fd: "Space Grotesk";
  --fb: "Lexend";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);overflow-wrap:break-word;word-break:normal;}
.stage *{overflow-wrap:break-word !important;word-break:normal !important;}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;font-size:1cqw;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}
  

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:45;}

.tile{width:var(--sz,5em);height:var(--sz,5em);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;}
.tile>span{font-size:40cqw;line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{width:var(--sz,5em);height:var(--sz,5em);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;}
.badge>span{font-size:40cqw;line-height:1;}
.tick{position:absolute;}
.card{background:var(--surface);border-radius:var(--r-md);}
.dot{border-radius:50%;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}
/* signature-element helpers — use these instead of repeating inline styles */
.photo{background:var(--ph);overflow:hidden;background-size:cover;background-position:center;background-repeat:no-repeat;border-radius:0;}
.track{height:1.1cqh;background:var(--ph);border-radius:var(--r-pill);}
.track>span{display:block;height:100%;background:var(--accent);border-radius:var(--r-pill);}
.chrome-foot{position:absolute;left:6cqw;bottom:3.4cqh;opacity:.7;}
```
The number inside a `badge` and any text inside a `tile` must be wrapped in a
`<span>`. The wrapper is measured against the badge's own width. Size these with
an `em` value in `--sz`, never a cqw/cqh/px/vw/vh `width` or `height`; `.fit` supplies
the container-relative base font size so the component still scales with the stage.


## Identity vocabulary

The business-data identity comes from its flex compositions, typography, colour rhythm,
content components and persistent chrome. It has **zero optional decorations** under the
strict definition in `decoration/PLACEMENT.md`.

Classify each element before using it:

| element | class | measured reference use |
|---|---|---|
| `plus-mark` | persistent chrome | 29 / 15 pages; at least one on every page |
| footer label | persistent chrome | 15 / 15 pages |
| `.pagenum` anchor | persistent chrome | 15 / 15; visible on 10 / 15 |
| `stat-block` | content | only where the material supplies a figure |
| `progress-ring` | data graphic | rates and shares |
| `bar-row` | data graphic | multi-way proportions |
| `photocell` | media content | 16 cells in the reference; source-supported only |
| tile / badge / node / connector | layout component | inside their matching layouts |
| full-stage / half-stage colour field | ground/layout | 5 full-stage pages; one half-stage field |
| optional decoration | decoration | **0** |

The snippets below are exact component and chrome patterns. Their observed usage is a
page-role diagnostic, never a quota. Do not reinterpret a square, ring, panel, card,
background or grid cell as decoration.

### 1. `plus-mark` — persistent chrome, not decoration

A thin `+` in `--accent`, `1.4cqw` across, in the slide corners. It is the
template's constant tick and the cheapest thing to forget.

**Reference use: 29 across 15 pages.** Every page has at least one, and 11/15 carry two
or more. A pair sits in opposite corners. Gate only a page with zero; report pair rate
against the 73% reference rather than requiring two on every page.

```html
<svg style="position:absolute;left:6cqw;top:6cqh;width:1.4cqw;height:1.4cqw;z-index:2" viewBox="0 0 24 24">
  <path d="M12 4 V20 M4 12 H20" stroke="var(--accent)" stroke-width="2.6" stroke-linecap="round"/>
</svg>
```

On a slide whose stage is a saturated colour field, draw the plus in
`currentColor` instead so it stays legible.

### 2. `stat-block` — content

Figures in this template are never in boxes. They are set large in `--fd`, with
a small uppercase label directly beneath, and separated from their neighbours by
whitespace alone.

**Reference observation:** the cover carries a row of three stat-blocks and two further
pages use bare figures. Use them only for figures the source actually supplies.

```html
<div style="display:flex;gap:3.4cqw;align-items:flex-end">
  <div>
    <div class="stat" style="font-size:3.4cqw">$48M</div>
    <div class="cap soft" style="margin-top:.6cqh">Revenue</div>
  </div>
  <div>
    <div class="stat" style="font-size:3.4cqw">+34%</div>
    <div class="cap soft" style="margin-top:.6cqh">YoY</div>
  </div>
  <div>
    <div class="stat" style="font-size:3.4cqw">12 mkts</div>
    <div class="cap soft" style="margin-top:.6cqh">Live</div>
  </div>
</div>
```

When the source has one decisive figure, `stat-hero.html` takes it to hero scale against a
colour field. Do not manufacture a metric to obtain that page role.

### 3. `progress-ring` — data graphic

An open circular ring showing one proportion, with the percentage centred
inside. The track is `--ph`. The value arc is `--accent` on the standard ground, as in
the snippet; switch it to `--bg` only when the ring sits on a saturated colour
field, where `--accent` would disappear.

Use `rates.html` when the material contains isolated rates or shares. `stroke-dasharray`
is `value/100 × 238.76`, then `238.76`; the ring encodes data and is never decoration.

```html
<div style="flex:1;display:flex;flex-direction:column;align-items:center">
  <div style="position:relative;width:100%;display:flex;align-items:center;justify-content:center">
    <svg viewBox="0 0 100 100" data-bbadge="1" style="width:60%;height:auto;display:block">
      <circle cx="50" cy="50" r="38" fill="none" stroke="var(--ph)" stroke-width="9"/>
      <circle cx="50" cy="50" r="38" fill="none" stroke="var(--accent)" stroke-width="9"
              stroke-dasharray="195.8 238.76" stroke-linecap="round" transform="rotate(-90 50 50)"/>
    </svg>
    <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
      <div class="stat" style="font-size:2.6cqw;color:var(--ka)">82%</div>
    </div>
  </div>
  <div class="kicker" style="margin-top:1.4cqh;color:var(--ka)">Retention</div>
</div>
```

### 4. `bar-row` — data graphic

A labelled track with a filled capsule bar and the value on the right. This is
how proportions are compared; never a pie chart.

Use `bar-rows.html` when the material compares three or more proportions. The track and
fill encode data and are never decoration.

```html
<div style="display:flex;align-items:center;gap:1.4cqw;margin-bottom:1.2cqh">
  <div class="cap" style="flex:1">Engineering</div>
  <div class="track" style="flex:4"><span style="width:65%"></span></div>
  <div class="cap" style="flex:none;text-align:right">65%</div>
</div>
```

### 5. `photocell` — media content

Photographs are people at work, cropped as a large rectangle — full-bleed to the
stage edge on the cover, gently rounded at `--r-md` when inset. Never
desaturated, never circular.

**Reference observation: 16 photocells across the 15-page deck (1.07/page).** This is a
reported reference reading, not a target. Use a photograph only where the supplied
material describes a subject worth showing. If the material describes no such subject,
carry no photograph at all and use a colour field or a large figure instead.

```html
<div style="position:absolute;right:0;top:0;width:46cqw;height:100cqh;background:var(--ph);
            border-radius:0;overflow:hidden;
            background-size:cover;background-position:center;background-repeat:no-repeat;
            background-image:url('<image>')"></div>
```

## Optional-decoration profile

**Reference reading: 0.** There is no optional decoration in this template. The audit must
report zero declared large and small decorations. Do not infer decoration from geometry:

- a card, square tile, colour block, rectangular background, content container, grid cell,
  media frame, node or connector is content-bearing or layout structure;
- a ring, bar or figure carries data;
- plus-marks, footer labels and page-number anchors are persistent chrome.

Do not add `data-decoration`, `data-deco`, `data-ornament`,
`data-decoration-size="small"` or `data-deco-small` markers. A sparse page remains sparse.
Identity comes from the measured layouts, colour rhythm, type and chrome—not a quota of
shapes. `decoration/decoration.html` renders this zero result explicitly, and there is no
`item-sets.html` because this template has no optional motif attached to repeated items.

The reference still carries **16 image cells across 15 pages (1.07/page)**, but those are
media content and source-dependent. A kicker is plain chrome text, never a chip. Badges
exist only inside the numbered-list layout; do not turn ordinary labels into boxes.


## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** Keep audience-facing copy in normal-flow flex
containers inside the one `.fit` safe area. Do not position prose with `left`, `right`,
`top`, or `bottom`, and do not freeze a text box with a container- or viewport-unit
width. CJK copy is routinely wider than the Latin draft; flex lets it wrap inward.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a flex row so the alignment is structural,
not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

A finished slide keeps repeated items on one structural alignment and keeps
content clear of every unintended stage edge.

## Persistent chrome

The three chrome readings are different; only criteria the reference satisfies exactly
may gate:

1. **Footer label**, bottom-left — present on 15/15 reference pages: an uppercase
   `.kicker` such as `Business Data &nbsp;·&nbsp; 04`, using a stable deck word drawn from
   the subject: `<div class="kicker" style="position:absolute;left:6cqw;bottom:3.4cqh;opacity:.7">Business Data &nbsp;·&nbsp; agenda</div>`
2. **Page-number anchor**, bottom-right — `.pagenum` exists on 15/15 pages. Ten carry a
   visible two-digit number; five divider, emphasis, and closing pages leave it empty.
3. **Plus-mark** — at least one on 15/15 pages. The reference averages 1.93/page and
   11/15 pages carry a diagonal pair; pair rate is reported, not a per-page gate.

## Background rhythm

Most slides sit on `--bg` with a wide, calm information grid. The template's
punch comes from full-stage accent fields:

```html
<div class="slide"><div class="stage" style="background:var(--g0);color:var(--t0)"> … </div></div>
```

**Reference observation: 5/15 pages (33%) use a full-stage colour field**—three dark
chapter/voice pages, the stat hero and the closing page. On a colour field, stat labels,
ring tracks and bar tracks switch to the matching `--tN` / `--bg` values.

One further page uses a half-stage, textless `data-background-field`. It is a ground/layout
device, not decoration. Treat both readings as deck-level diagnostics, not quotas; select
the page role only when the content supports it.

## No optional-decoration layer

Keep all content inside the `.fit` safe area. Persistent plus-marks sit in their measured
corners and never overlap copy. Background fields stay behind content; media frames and
data components remain inside their layouts. Do not add a wire globe, large circle, blob,
sprig, arch, empty square or any other optional shape: none exists in the reference.

Never place body copy or a caption directly on a photograph unless a reference page role
provides a text-safe field. If chrome or a ground treatment collides with content, move or
remove the non-content treatment, never the copy.

## Never do this

- Never use a pie chart or a doughnut with more than one segment. Proportions are
  bar-rows; single rates are progress-rings.
- Never put a figure inside a bordered or shadowed card. Figures stand in
  whitespace.
- Never use disc/dot list bullets. Use numbered rows, bar-rows, or a hairline
  rule between rows.
- Never desaturate a photograph, and never make one circular.
- Never use drop shadows.
- Never leave the whole deck on `--bg` with no colour-field slide.
- Never let a slide go out without its footer label, `.pagenum` anchor, or at least one
  plus-mark. A visible page number and a second mark follow the measured profile above;
  they are not required on every page.

## Self-check before delivery

Review identity and page-role fidelity. Fix the deck before
delivery if any line fails.

0. Optional-decoration count is zero; no content or layout component was relabelled as
   decoration and no generic geometry was invented.
1. Content components appear only on the page roles where the reference/layout set uses
   them, with clear space and no text collision.
2. Every slide satisfies the exact gates under `Persistent chrome`; visible-page-number
   and plus-pair coverage are reported against their reference rates.
3. Every photograph follows the documented template treatment and illustrates
   a subject the material describes. Zero photographs is valid.
4. Every prohibition under `Never do this` was checked against the final HTML.
5. Exactly one `data-color-system` token is present and it is preferred.
6. Persistent chrome, content components and ground fields were reported separately from
   the zero optional-decoration profile.

Visual reference: [example/reference.jpg](example/reference.jpg) —
the rendered proof of every rule above. [layouts/](layouts/)
is the same deck in code; open it when a snippet here needs more context.
