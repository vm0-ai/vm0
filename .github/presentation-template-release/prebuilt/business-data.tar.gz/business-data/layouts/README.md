# business-data — naked layouts

42 layouts, text only. No decoration, no measured geometry. Pair one of these with
[../decoration/PLACEMENT.md](../decoration/PLACEMENT.md) to build a slide.

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions. Not a slide.

## The one rule

**No sizing in container or viewport units on anything that holds text.** Verified across
all 42: zero `width` / `max-width` / `min-width` / `height` / `left` / `top` / `right` /
`bottom` / `flex-basis` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

`flex:0 0 4cqw` counts — a flex-basis freezes a text box exactly the way a `width` does.

Exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline rule.
- **`%`** where the number *is* the datum — `chart-bar`, `bar-rows`, `gantt`, and the
  ring's `stroke-dasharray`. A bar that is 65 % long is reporting 65.
- **`%` on a textless background field** where it defines a page split, never a text box.
- **`--sz` in `em` only** on `tile` / `badge` / `node`. `.fit` supplies a container-relative
  base font size, so an em-sized component scales with the stage; the `<span>` inside scales
  its text against the box. A cqw value hidden in `--sz` would still freeze the text box.
- **`aspect-ratio`** on an image frame — a crop, not a measurement.

Everything else stretches. Columns are `flex:1`. The safe area is set **once**, by the
padding on `.fit`: `11.6cqh 6cqw 8cqh`.

Why this matters: the original reference deck was produced by measuring a rendered deck and writing the
numbers back, so `width:36cqw` is an observation of one string at one font size, not a
design decision. Copying it reproduces that string. These carry none.

Any flex child holding an SVG or a percentage-height bar needs `min-height:0`, or the
SVG's intrinsic ratio pushes the box past the stage edge.

## The safe area is a template constant

Measured on the reference: the most common text left edge is **6.1 %** of stage width and
the minimum inset on either side is **6.1 %**. Content starts at **11.09 %** from the top —
below the plus-marks at `6cqh` — and the footer label and page number occupy the bottom
`~6cqh`. Hence `11.6cqh 6cqw 8cqh`, set on `.fit` and nowhere else.

Do not re-set padding per page. The safe area is a constant of the template, not a
per-slide decision.

## Files

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `statement` `longform` `two-column` `three-column` `ruled-list`
`numbered-list` `color-cards` `icon-cells` `quote-cards` `big-quote` `pricing`

**Numbers** · `kpi-grid` `stat-hero` `rates` `bar-rows` `chart-bar` `chart-line` `funnel`
`waterfall` `heatmap` `table` `dashboard`

**Time, sequence and systems** · `process` `architecture` `mind-map` `timeline` `roadmap`
`gantt`

**Decisions and proof** · `executive-summary` `pros-cons` `comparison` `versus` `case-study`

**Imagery** · `image-left` `image-right` `image-hero` `image-grid` `team` — all five delete
cleanly. When the source has no imagery, drop the frame and use a prose or numbers layout
instead; do not leave an empty box.

## Where this set came from

The first sixteen are the compositions the reference deck itself demonstrates, page by
page: `cover` `toc` `section-divider` `image-left`(p4) `numbered-list` `team` `icon-cells`
`process` `image-grid` `stat-hero` `quote-cards` `pricing` `close`, plus `big-quote`,
`comparison` and `table` from `../composition-recipes.html`.

The rest fill page roles an annual report and operating review need and this template had no page for:
`two-column` `three-column` `ruled-list` `kpi-grid` `rates` `bar-rows` `chart-bar`
`chart-line` `timeline` `roadmap` `gantt` `pros-cons` `image-right` `image-hero`
`color-cards` `statement` `longform` `architecture` `mind-map` `versus` `case-study`
`executive-summary` `funnel` `waterfall` `heatmap` `dashboard`. Each is expressed in
this template's own vocabulary — the capsule track, the `--gN` ground, the hairline rule,
the bare figure and normal-flow flex relationships.

Deliberately **not** here, because they are another design language's furniture:
pie and doughnut charts (the skill forbids them — proportions are `bar-rows`, single rates
are `rates`), radar charts, terminal and code panels, pill-button call-to-action rows.
`architecture` and `mind-map` are present because they have distinct communication jobs;
both use the same colour fields, type, hairlines and flex system as the rest of this family.

Also not here: a **filled** counterpart to `kpi-grid`. This template says *"Never put a
figure inside a bordered or shadowed card. Figures stand in whitespace."* A `kpi-cards`
would contradict the skill, so the row of numbers has one treatment, not two.

## Ruled or filled

Measured on the reference: **0.47 hairline rules per page** (7 across 15 pages) — four
table-of-contents rows and three price-card dividers. That is a thin menu, not a skewed
one, so this template does not have the "every slide gets the same horizontal line"
problem. Both treatments are still provided where the content type supports both:

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `color-cards` |
| two things compared | `pros-cons` | `comparison` |
| a set of quotes | — | `quote-cards` |
| a row of numbers | `kpi-grid` | *(none — figures never go in cards)* |

The filled versions cycle the grounds `--g0 --g2 --g1` so neighbours never share a colour.

## A filled box is sized by its content, never by the stage

```
height   row     flex:none      height comes from the tallest child, not the stage
         child   flex:1         siblings equalise to that tallest child
width    box     align-self:flex-start; max-width:100%
```

`.fit` is a column flex with `align-items:stretch`, so every child is full-width by
default; `align-self:flex-start` opts one box out. The exception is a **row of peers** —
cards, columns, quarters — which stays equal-width and divides the safe area. One box
hugs, a row of boxes divides.

Reserve a filling `flex:1` for an image frame or a chart plot area.

All stretch-aligned content peer rows in this set were stress-tested by injecting an
extra sentence into the first item: every row stays equal-height (spread 0px). `process` has a separate
stress check: longer step copy leaves all four node centres on one line (spread 0px).

## Two geometry readings, taken at 1600×900

Both are measured on the rendered layout, not judged by eye. Safe area = the stage minus
6 % each side, the template constant.

| reading | rule | these 42 | the original reference deck, 15 pages |
|---|---|---|---|
| empty wide column | no textless, unpainted, image-free **flow** box occupies ≥ 8 % of the safe-area width | 0 | 0 |
| narrow wrap | no text wraps to 2+ lines inside a box under 72 % of the safe area while the band from its right edge to the safe-area edge is empty | 0 | **6** |

Only the first one is a gate: the reference reads 0, so a non-zero reading is a defect.
The reference reads **6** on narrow wrap — including the very construction that was
removed from `process` here, on its own page 9 — so this one is a standard these layouts
hold themselves to, not a criterion that can be pointed at a generated deck. Report the
number, do not block on it.

Whitespace is never reserved with an empty element. If a column has nothing in it, delete
it and let the text run the full width; half width is for when a photo, a chart or a real
second column occupies the other half. A short right-hand panel next to longer prose is
the same defect wearing a hat — `longform` puts its side panel on `align-items:stretch`
so the second column is present for every paragraph, not just the first two.

## Two constructions that look right and are not

**`process`** — the four nodes live in their own flex row with the connector behind them;
all four pieces of copy live in one more flex row underneath, column *n* of the copy row
sitting under node *n*. Longer copy expands the copy row and cannot move a node off the
connector. Do not put a node and its copy in the same flex item, and do not absolutely
position the prose.

The earlier version alternated the copy above and below the connector, which needed an
empty `flex:1` spacer opposite every step. Measured at 1600×900 that left four empty
columns at 24.3 % of the safe area each, and each step's copy wrapped to two lines in a
24.3 % box with 25 % of empty safe area to its right. One copy row per node row: no
spacers, and every column has a neighbour to its right.

**`chart-bar`** — the value labels sit *below* a fixed-height plot area, not on top of the
bars. Labels riding on the bars is the obvious construction and it misaligns by design,
because the bars are different heights. Also: a vertical column takes
`--r-md --r-md 0 0`, not `--r-pill`. A full pill radius on a wide column renders as a
lozenge — this template's "fully round bars" means the thin horizontal `track`.

## Colour

Source hues are fills. `--ka` `--k1` `--k2` `--k3` are text. Measured across all six
preferred colour systems, `--s2` fails as text in every one (1.43–2.14:1) and `--accent`
and `--s1` fail in `mint_tech` (2.51 / 2.72). The `--k*` tokens pass everywhere because
they are defined to fall back to a readable colour when the source hue cannot carry text.

Checked on all 42: zero text below 3.0:1.

On a `--gN` ground use the matching `--tN`. On a full-bleed page a kicker uses
`color:inherit` with `opacity` — never `--ka`, which is `--ink` and vanishes on a dark
field, and never `.soft`, which measures 2.39:1 there.

`section-divider` and `big-quote` are full-bleed `--g3`; `close` and `stat-hero` are
full-bleed `--g0`. 33 % of reference pages are a colour field. Nothing sits on top of one —
no cards, no panels.

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` · structure
`stage fit deck slide band card tile badge` · marks `dot tick soft dim pagenum` ·
helpers `photo track chrome-foot`.

Sizes live in those classes. If something needs to be bigger, use the next class up.
