#!/usr/bin/env python3
"""Concatenate every layout into one labelled scrolling deck for review."""
import re, glob, os, sys
HERE=os.path.dirname(os.path.abspath(__file__))
only=sys.argv[1:] if len(sys.argv)>1 else None
files=sorted(f for f in glob.glob(os.path.join(HERE,'layouts','*.html')) if not f.endswith('_shell.html'))
if only: files=[f for f in files if os.path.basename(f)[:-5] in only]
head=open(os.path.join(HERE,'layouts','_shell.html')).read()
# contact.html sits one level ABOVE layouts/, so its local colour path drops
# the layout directory's leading "../".
head=head.replace('href="../color-systems/prism.css"','href="color-systems/prism.css"')
head=head.replace('<title>sticker-scrapbook — shell</title>','<title>sticker-scrapbook — contact sheet</title>')
head=head.replace('.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}','.deck{}')
head=head.replace('.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}',
                  '.slide{width:1600px;height:900px;display:flex;background:var(--ink);margin:0 0 18px 0;position:relative;}')
head=head.replace('.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);',
                  '.stage{position:relative;width:1600px;height:900px;')
head+='<style>.lbl{position:absolute;left:0;top:0;z-index:99;background:#111;color:#fff;font:600 22px/1.2 monospace;padding:8px 16px;letter-spacing:.04em}</style>\n'
out=[head,'<div class="deck">\n']
for f in files:
    name=os.path.basename(f)[:-5]
    m=re.search(r'<div class="slide">(.*)</div></div></div>\s*</body>',open(f).read(),re.S)
    out.append('<div class="slide"><div class="lbl">%s</div>%s</div></div>\n'%(name,m.group(1)))  # lbl is outside .stage
out.append('''</div>
<script>
const deck = document.querySelector('.deck');
const slides = [...deck.children].filter(n => n.classList.contains('slide'));
let current = 0;
addEventListener('keydown', e => {
  if (['ArrowDown','ArrowRight','PageDown'].includes(e.key)) current = Math.min(slides.length - 1, current + 1);
  else if (['ArrowUp','ArrowLeft','PageUp'].includes(e.key)) current = Math.max(0, current - 1);
  else if (e.key === 'Home') current = 0;
  else if (e.key === 'End') current = slides.length - 1;
  else return;
  e.preventDefault();
  slides[current].scrollIntoView({block:'start'});
});
</script>
</body></html>
''')
open(os.path.join(HERE,'contact.html'),'w').write(''.join(out))
print('contact.html:',len(files),'layouts')
