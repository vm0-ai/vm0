// Run on contact.html after fonts load. Text-bearing peer rows receive one extra
// sentence in their first item; image-only peer rows are measured structurally.
// Returns JSON. The authored set has 33 marked rows: 31 text, 2 image-only.
(async () => {
  const ownText = e => [...e.childNodes]
    .filter(n => n.nodeType === 3).map(n => n.textContent.trim()).join('').trim();
  const rows = [...document.querySelectorAll('[data-peer-row]')];
  const injected = [];

  for (const row of rows) {
    const imageOnly = row.dataset.peerRow === 'image';
    const peers = [...row.children].filter(k => {
      if (getComputedStyle(k).flexGrow === '0') return false;
      return imageOnly || [k, ...k.querySelectorAll('*')].some(e => ownText(e).length >= 2);
    });
    if (peers.length < 2) continue;
    if (!imageOnly) {
      const candidates = [...peers[0].querySelectorAll('.body,p,.cap,.h3,.kicker')]
        .filter(e => ownText(e).length >= 2);
      const target = candidates[candidates.length - 1] || peers[0];
      target.appendChild(document.createTextNode(' An additional sentence deliberately makes this first item longer than its peers.'));
      injected.push(target);
    }
  }

  await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
  const results = [];
  for (const row of rows) {
    const imageOnly = row.dataset.peerRow === 'image';
    const st = row.closest('.stage'), sr = st.getBoundingClientRect();
    const peers = [...row.children].filter(k => {
      if (getComputedStyle(k).flexGrow === '0') return false;
      return imageOnly || [k, ...k.querySelectorAll('*')].some(e => ownText(e).length >= 2);
    });
    const hs = peers.map(k => Math.round(k.getBoundingClientRect().height * 10) / 10);
    const spread = hs.length ? Math.max(...hs) - Math.min(...hs) : 0;
    const overflow = peers.some(k => {
      const r = k.getBoundingClientRect();
      return r.left < sr.left - 2 || r.right > sr.right + 2 || r.top < sr.top - 2 || r.bottom > sr.bottom + 2;
    });
    results.push({layout: st.dataset.slot, kind: imageOnly ? 'image' : 'text', peers: peers.length, heights: hs, spread: +spread.toFixed(1), overflow});
  }
  injected.forEach(e => e.lastChild && e.lastChild.remove());
  return JSON.stringify({
    rows: results.length,
    textRows: results.filter(x => x.kind === 'text').length,
    imageRows: results.filter(x => x.kind === 'image').length,
    failedRows: results.filter(x => x.spread > 2 || x.overflow).length,
    maxSpreadPx: Math.max(0, ...results.map(x => x.spread)),
    failures: results.filter(x => x.spread > 2 || x.overflow)
  }, null, 1);
})()
