# sticker-scrapbook — naked layouts

45 layouts, text only. No decoration, no measured geometry. Pair one of these with
`../decoration/PLACEMENT.md` to build a slide.

Regenerate with `python3 ../build_layouts.py`. Edit the generator, not these files —
the shell, the safe area and the ground rotation are shared and must not drift.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 45: zero `width` / `max-width` / `min-width` / `height` /
`left` / `top` / `right` / `bottom` / `flex-basis` values in `cqw`, `cqh`, `px`,
`vw` or `vh`.

`flex-basis` counts. `flex:0 0 4cqw` freezes a column exactly the way `width` does.

Four exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something
  that is `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline rule and for a connector.
- **`em`** on an ornament that contains no prose — a legend dot, a timeline dot, the
  avatar frame in `quote-cards`. `em` scales with the type around it, so it cannot
  freeze a text box.
- **`%`** in charts, `roadmap`, `gantt`, and `fundraising-progress`, where the
  number *is* the datum. A bar at 61% is reporting 61.

`--sz` on a `.tile` or `.badge` is not a width. The shell computes the box **and**
the glyph inside it from `--sz` through a container query; writing `width`/`height`
instead sizes the box but not the glyph, and you get a small figure in a large frame.

Everything else stretches. Columns are `flex:1`. The safe area is set once, by the
padding on `.fit` (`13cqh 6cqw 9cqh`). The 6% side padding is the template constant,
measured from the original reference deck: 37 of its text runs start at exactly 6.0% of
stage width. The 13cqh top clears the reference's own minimum content top of 13.1%,
and the 9cqh bottom clears the page number at `bottom:3.2cqh`.

This matters because the original reference deck was produced by measuring a rendered deck and
writing the numbers back — `min-height:48.13cqh`, `margin-top:16.27cqh`,
`width:13.799999999999999cqw`. Those are observations of one string at one font
size, not design decisions. Copying them reproduces that string. These carry none.

## Nothing empty holds a column, and nothing folds in a box it did not need

Two geometric readings, both taken at 1600x900 on every layout and on
`../layouts/`. The reference reads **0** on both, which is what makes them
gates rather than opinions.

- **No empty wide column.** A flow box that holds no text, paints no background or
  border and draws no vector, but still occupies **8% or more of the safe width**, is
  blank paper. It cannot be defended as breathing room: decoration is an absolute layer
  that sits *over* the page, so a reserved flow column decorates nothing. Reference: 0.
  Layouts: 0 of 45. This is what a gap in a track really is — the roadmap and gantt bars
  state their start as their own `margin-left` and their duration as their own `width`,
  and a waterfall bar states its base as `bottom`; a term or week with no bar costs no
  box. The zigzag `process-steps` was the other source: half its strip was empty cells.
- **No narrow fold.** A run of text that wraps onto two or more lines inside a box
  **narrower than 90% of the safe width, with nothing between that box and the safe-area
  edge**, is a title folded in the middle of an empty page. Half width is legitimate
  only when something real — an image, a chart, a second column — is beside it.
  Reference: 0 of 114 text runs. Layouts: 0 of 45.

Two writings cause the fold, and both look harmless in the generator:

- a hard `<br>` inside a hugged heading. `align-self:flex-start` shrink-wraps to
  **max-content**, and `<br>` makes max-content the longest hand-written line, so the
  box stops at 45% of the measure and the break is frozen at whatever the author typed.
  Without the `<br>` the same heading stretches and breaks at the safe area.
- prose carrying `align-self:flex-start` or a written `max-width` while alone on its
  line. The reference's own closing page did this with `max-width:46cqw` and folded a
  52.3%-wide paragraph in two; it now spans the measure.

Use `align-self:flex-start` for a box that must hug — a chip, a pill, a badge — not for
prose or a title that owns its line.

## Titles never shrink

`.fit` is a column flex, so a heading defaults to `flex:0 1 auto` and **will shrink**
to make room for a `flex:1` sibling. In `chart-pie` that let the donut draw straight
over the title while every probe read 0. Every heading block therefore carries
`flex:none`; only the content group gets `flex:1`.

Any flex child holding an SVG needs `min-height:0`, and an SVG that should fit a box
needs `width:100%;height:100%` with the default `preserveAspectRatio` — not
`height:100%;width:auto`, which resolves to `auto` against an auto-height parent and
overflows the row by its own aspect ratio.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions. Not
a slide.

**Opening and closing** · `cover` `agenda` `section-divider` `close`

**Prose** · `statement` `long-form` `bullet-list` `two-column` `three-column`
`icon-cells` `numbered-list` `note-pad` `checklist`

**Quotes** · `big-quote` `quote-cards`

**Numbers** · `kpi-grid` `stat-stickers` `stat-highlight` `table` `chart-bar`
`chart-line` `chart-pie` `chart-area` `chart-waterfall` `chart-funnel`

**Time and sequence** · `process-steps` `timeline` `roadmap` `gantt`

**Two things compared** · `comparison` `versus` `pros-cons`

**People and imagery** · `team` `image-left` `image-right` `image-grid`
`image-hero` `photo-story`

**Structure** · `flow-diagram` `architecture` `mind-map`

**Cases** · `case-study`

**Community programmes** · `event-schedule` `fundraising-progress`

**Offers** · `price-tiers`

## Where this set came from

13 of them are compositions the original reference deck already demonstrated, named
after the `data-device` it uses: `cover` `agenda` `section-divider` `close`
`note-pad`(pad) `numbered-list` `team` `icon-cells`(icon-cell) `process-steps`(process)
`image-grid` `stat-stickers`(statcard) `quote-cards`(quote) `price-tiers`(price).
Those are non-negotiable — they are the compositions this template actually knows.

3 more come from `../composition-recipes.html`: `big-quote` `comparison` `table`.

The remaining 15 of the original set are things a real deck needs and this template
had no answer for:
the three charts, `timeline`, `roadmap`, `two-column`, `three-column`, `kpi-grid`,
`stat-highlight`, `versus`, `pros-cons`, `checklist`, `image-left`, `image-hero`,
`flow-diagram`.

A coverage review then added 14 non-isomorphic communication jobs that the original
31 did not answer:

- `statement`, `long-form`, and `bullet-list` separate a thesis, continuous prose,
  and unordered points rather than disguising each as a numbered list;
- `image-right` changes reading order, while `photo-story` ties captions to a
  sequence of supplied photographs;
- `chart-area`, `chart-waterfall`, and `chart-funnel` answer cumulative magnitude,
  contribution-to-change, and stage-conversion questions;
- `gantt` adds task ownership, overlapping work, and week-level duration rather
  than repeating the milestone-oriented `roadmap`;
- `architecture` shows system boundaries, and `mind-map` shows non-linear ideas
  around a shared question; neither is a renamed linear `flow-diagram`;
- `case-study` binds challenge, intervention, and evidence in one case record;
- `event-schedule` and `fundraising-progress` cover the community/event scenarios
  this visual identity is designed for.

**Deliberately not added**, though bloom and open-design have them: `chart-radar`
(a corporate instrument this template has no use for), `terminal`/`code`
(another design language's skeuomorphism — and a large dark rounded rectangle reads
as a photo placeholder), `cta` (a slide cannot be clicked).

## Content devices belong to the layout, not the decoration layer

Several layouts describe a **set of peer items**. Their tile, node, badge, dot or
connector carries content or performs layout work, so none is optional decoration and
none enters the decoration count. The copyable markup is already in the named layout:

| layout | content device |
|---|---|
| `icon-cells` `checklist` `pros-cons` | one `tile` per item |
| `process-steps` | one `node` per stage + one continuous `connector` |
| `numbered-list` | one `badge` per row, figure wrapped in a `<span>` |
| `timeline` | one `dot` per date + one `connector` |
| `gantt` `chart-area` `chart-waterfall` `chart-funnel` `fundraising-progress` | bars, areas and spans encode the supplied values |
| `architecture` `mind-map` `flow-diagram` | content nodes and connectors express relationships |
| `two-column` `three-column` `comparison` `table` `kpi-grid` | nothing — these hold prose, use the hairline rules already in them |
| `agenda` `stat-stickers` `versus` `price-tiers` | nothing — the card *is* the colour |

Every completed slide additionally carries exactly one `seal` shape from the true
decoration layer. See `../decoration/PLACEMENT.md` §B.

## Ruled or filled — every peer row has both

The menu deliberately supplies both ruled and filled treatments so an agent does not
put the same horizontal line on every slide. Each of these content types has two
treatments, and neither is more on-template:

| content | ruled | filled |
|---|---|---|
| three or more peer columns | `three-column` | `icon-cells` |
| a row of numbers | `kpi-grid` | `stat-stickers` |
| two things compared | `comparison` | `versus` |
| a list of points | `numbered-list` | `agenda` |
| a set of tasks | `checklist` | `icon-cells` |

The filled versions cycle the ground tokens so neighbours never share a colour —
**and never reuse the stage's own ground**, which would make that item invisible.
`grounds()` in the generator does this; if you write one by hand, do it yourself.

## Colour on a card

A card is `--surface`, and `--surface` is legible **only on a colour field** —
1.00–1.10:1 against `--bg` in all five preferred colour systems, 3.65–4.66:1 against
a `--g?` field. The reference puts 8 cards on fields and 0 on `--bg`.

The stage sets `color:var(--t1)`, and a card inherits it — white text on a near-white
card. `.card` in the shell now carries `color:var(--ink)` so this cannot happen by
default. A hand-written card must restate it.

`[data-device="price"]` and `[data-device="icon-cell"] .tile` are pinned by the shell
with `!important` — `--surface`/`--ink` and `--ink`/`--bg` respectively. Do not write
an inline ground for them; it is silently discarded. Emphasis on a price tier has to
come from the label, not from the card.

Type on `--bg` uses `--ka` `--k1..--k3` `--soft` `--ink` (4.94–17.58:1). Type on a
`--g?` field uses the matching `--t?` (4.60–16.15:1 across all five systems). The raw
hues `--accent` `--s1` `--s2` `--s3` read 1.44–4.97:1 on `--bg` and are **fills
only**. `--ink` on a colour field reads as low as **1.00:1** — never.

## Ground rhythm

12 of 15 reference pages are full-bleed colour fields — **80%**. Rotate `--g0`,
`--g3`, `--g1` and drop one `--bg` page every three to four slides. `--g2` is never a
page ground in the reference; it is a card and ornament colour.

This is the opposite of bloom, which is cream with roughly one colour field in four.
Do not carry bloom's ratio, its ban on `--surface`, or its rule against boxes on a
full-bleed page over here. This reference has 22 boxes on full-bleed pages and they
are correct.

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` · structure
`stage fit deck slide band card tile badge seal` · marks `dot tick soft dim pagenum`.

Sizes live in those classes. If something needs to be bigger, use the next class up —
do not write a `font-size`.

## Verified

All 45, at 1600×900, with the colour system loaded:

```
overflow 0 · outsideSafeArea 0 · lowContrast 0 · columnsMisaligned 0
aboveChromeBand 0 · boxesUnderfilledV 0 · boxesUnderfilledH 0
darkPanels 0 · offVocabularyShapes 0 · orphanSlides 0 · indirectSlides 0
decks 1 · navigableSlides == pages
```

Plus the §3 static sizing audit at zero, the placeholder-copy audit at zero, and the
equal-height stress test on every peer row: 33 rows (31 text, 2 image-only), 0 failures.
