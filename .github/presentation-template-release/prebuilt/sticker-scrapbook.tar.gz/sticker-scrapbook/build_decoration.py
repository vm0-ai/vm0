#!/usr/bin/env python3
"""Rebuild decoration/decoration.html from its committed motif vocabulary.

The decoration catalogue is now the canonical source for ornaments; the
template package intentionally has no full-deck HTML example. Run from the
template folder.
"""
import os, re

HERE = os.path.dirname(os.path.abspath(__file__))
DEC = os.path.join(HERE, 'decoration')
EX = open(os.path.join(HERE, 'decoration', 'decoration.html')).read()


def lift(pattern, what):
    m = re.search(pattern, EX, re.S)
    if not m:
        raise SystemExit('could not lift %s from decoration/decoration.html' % what)
    return m.group(0)


SUNBURST = lift(r'<svg data-decoration="sunburst" viewBox="0 0 100 100" style="width:100%;height:100%;overflow:visible">(?:<line[^>]*/>)+</svg>', 'sunburst')
CHEVRON  = lift(r'<svg data-decoration="chevrons" viewBox="0 0 100 100" style="width:33\.33%;height:100%"><polygon points="20,12[^>]*/></svg>', 'chevron')
SPARKLE  = lift(r'<svg data-decoration="sparkle" viewBox="0 0 100 100" style="width:100%;height:100%"><path d="M50 3[^>]*/></svg>', 'sparkle')
SEAL     = lift(r'<svg data-decoration="seal" viewBox="0 0 100 100" style="position:absolute;inset:0;width:100%;height:100%"><polygon points="50\.00,1\.00[^>]*/></svg>', 'seal')

# Shared probes count only explicit, textless decoration. Mark the SVG shape of a
# labelled seal (not its text-bearing wrapper), and one glyph as the declaration
# for each three-glyph chevron unit.
_chevron_marked = CHEVRON
_chevron_plain = _chevron_marked.replace(' data-decoration="chevrons"', '', 1)
CHEVRON_ROW = _chevron_marked + _chevron_plain + _chevron_plain

SHELL = open(os.path.join(HERE, 'layouts', '_shell.html')).read()
SHELL = re.sub(r' data-safe-area="[^"]+"', '', SHELL, count=1)
FIT = 'display:flex;flex-direction:column;align-items:stretch;padding:13cqh 6cqw 9cqh'


def page(title, body, extra_css=''):
    h = SHELL.replace('<title>sticker-scrapbook — @@NAME@@</title>',
                      '<title>sticker-scrapbook — %s</title>' % title)
    h = h.replace('href="../color-systems/prism.css"', 'href="../color-systems/prism.css"')
    h = h.replace('.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}', '.deck{}')
    h = h.replace('.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}',
                  '.slide{width:1600px;height:900px;display:flex;background:var(--ink);margin:0 0 18px 0;position:relative;}')
    h = h.replace('.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);',
                  '.stage{position:relative;width:1600px;height:900px;')
    h += ('<style>.lbl{position:absolute;left:0;top:0;z-index:99;background:#111;color:#fff;'
          'font:600 20px/1.2 monospace;padding:7px 14px;letter-spacing:.04em}'
          '.note{position:absolute;left:0;bottom:0;z-index:99;background:#111;color:#fff;'
          'font:400 15px/1.4 monospace;padding:7px 14px;max-width:70%%}%s</style>\n' % extra_css)
    return h + body + '</body></html>\n'


def slide(label, stage_style, inner, note=''):
    # the label and the note sit OUTSIDE .stage. Inside, they read as dark panels
    # glued to the stage edge and trip outsideSafeArea/darkPanels on a file whose
    # whole job is to be looked at.
    n = '<div class="note">%s</div>' % note if note else ''
    # a real slide always has a .fit; without one the audit cannot separate the
    # persistent chrome from content and counts the page number as copy outside
    # the safe area.
    fit = '' if '<div class="fit"' in inner else '<div class="fit" style="%s"></div>' % FIT
    return ('<div class="slide"><div class="lbl">%s</div>%s'
            '<div class="stage" style="%s">%s%s<div class="pagenum">page 01</div></div></div>\n'
            % (label, n, stage_style, inner, fit))


# ---------------------------------------------------------------- decoration.html
def seal(left_top, size, rot, fill, label_tok, text, fs):
    # the lifted polygon already carries whichever ground token that reference page
    # used, so swap on the fill attribute itself rather than on one literal token.
    svg = re.sub(r'fill="var\(--\w+\)"', 'fill="var(--%s)"' % fill, SEAL)
    assert 'var(--%s)' % fill in svg, fill
    return ('<div class="seal" data-doodle="1" style="position:absolute;%s;width:%s;height:%s;'
            'transform:rotate(%sdeg);z-index:6">%s'
            '<div class="seal-label" style="font-size:%s;color:var(--%s)">%s</div></div>'
            % (left_top, size, size, rot, svg, fs, label_tok, text))


def sunburst(pos, size, stroke='--s2'):
    return ('<div data-doodle="1" style="position:absolute;%s;width:%s;height:%s;opacity:.5;z-index:1">%s</div>'
            % (pos, size, size, SUNBURST.replace('var(--s2)', 'var(%s)' % stroke)))


def chevrons(pos, w, h, fill='--s2'):
    return ('<div data-doodle="1" style="position:absolute;%s;width:%s;height:%s;z-index:5;'
            'display:flex;gap:.4cqw">%s</div>' % (pos, w, h, CHEVRON_ROW.replace('var(--s2)', 'var(%s)' % fill)))


def sparkle(pos, size, fill='--bg'):
    return ('<div data-doodle="1" style="position:absolute;%s;width:%s;height:%s;z-index:5">%s</div>'
            % (pos, size, size, SPARKLE.replace('var(--bg)', 'var(%s)' % fill)))


body = ['<div class="deck">\n']

body.append(slide('vocabulary — all four, no text', 'background:var(--g0);color:var(--t0)',
    sunburst('left:8cqw;top:14cqh', '24cqw') +
    seal('left:38cqw;top:30cqh', '13cqw', -10, 'g1', 't1', '', '2.4cqw') +
    chevrons('left:58cqw;top:38cqh', '15cqw', '5cqw') +
    sparkle('left:82cqw;top:40cqh', '4.5cqw'),
    'left to right: sunburst 22-24cqw z1 · seal 6.8-15.1cqw z6 · chevrons 12-15cqw z5 · sparkle 3.4-4.5cqw z5'))

body.append(slide('page role A — cover / divider / close (4 ornaments)', 'background:var(--g1);color:var(--t1)',
    sunburst('left:-5cqw;top:-4cqh', '24cqw') +
    seal('right:7cqw;top:16cqh', '13cqw', -10, 'g2', 't2', '', '2.4cqw') +
    chevrons('right:8cqw;bottom:32cqh', '13.8cqw', '4.6cqw') +
    sparkle('right:12cqw;bottom:16cqh', '4cqw'),
    'all four families. 5 of 15 reference pages, and they are exactly the 5 structural pages.'))

body.append(slide('page role B — content, chevrons variant (2 ornaments)', 'background:var(--g3);color:var(--t3)',
    seal('right:5cqw;bottom:6cqh', '6cqw', -8, 'g0', 't0', '', '2cqw') +
    chevrons('right:9cqw;top:29cqh', '12cqw', '4cqw'),
    'seal + chevrons. no sunburst on a content page.'))

body.append(slide('page role C — content, sparkle variant (2 ornaments)', 'background:var(--g0);color:var(--t0)',
    seal('left:8cqw;bottom:9cqh', '9cqw', -12, 'bg', 'ink', '', '2.4cqw') +
    sparkle('right:9cqw;top:13cqh', '3.4cqw'),
    'seal + sparkle. the --bg/--ink seal: legible here because the stage is a field. 4 of 15 reference seals are this pairing, all 4 on fields.'))

body.append(slide('the seal, at the four sizes the reference uses', 'background:var(--bg);color:var(--ink)',
    seal('left:6cqw;top:30cqh', '6.8cqw', -8, 'g0', 't0', '', '1.9cqw') +
    seal('left:20cqw;top:28cqh', '9.3cqw', -10, 'g1', 't1', '', '2.4cqw') +
    seal('left:38cqw;top:26cqh', '13cqw', -12, 'g3', 't3', '', '3cqw') +
    seal('left:58cqw;top:24cqh', '15.1cqw', -8, 'g2', 't2', '', '3cqw'),
    'min 6.8 · median 9.3 · max 15.1 cqw. rotation -8 / -10 / -12deg. this page is --bg, so no --bg seal.'))

body.append(slide('the middle band belongs to the copy', 'background:var(--g3);color:var(--t3)',
    '<div style="position:absolute;left:0;right:0;top:34%;height:33%;background:var(--t3);opacity:.14;z-index:0"></div>' +
    sunburst('left:-4cqw;top:-4cqh', '24cqw') +
    seal('right:7cqw;top:14cqh', '10cqw', -10, 'g1', 't1', '', '2.4cqw') +
    chevrons('left:7cqw;bottom:12cqh', '15cqw', '5cqw') +
    sparkle('right:12cqw;bottom:18cqh', '4.5cqw'),
    'shaded band = middle third. 2 of 42 reference ornaments are centred in it. 21 sit above, 19 below.'))

body.append('</div>\n')
open(os.path.join(DEC, 'decoration.html'), 'w').write(page('decoration', ''.join(body)))
print('wrote decoration.html')
