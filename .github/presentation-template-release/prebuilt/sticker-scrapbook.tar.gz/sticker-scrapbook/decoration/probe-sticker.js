// Template-specific fidelity probe for sticker-scrapbook.
// Run after the template-local ../tools/audit.js. Every gate below is calibrated
// against ../layouts/; diagnostics whose reference is non-zero remain
// report-only. Returns one JSON string for agent-browser eval -b.
(() => {
  const ownText = e => [...e.childNodes]
    .filter(n => n.nodeType === 3).map(n => n.textContent.trim()).join('').trim();
  const rgba = c => {
    const hex = String(c || '').trim().match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
    if (hex) {
      let h = hex[1]; if (h.length === 3) h = [...h].map(x => x + x).join('');
      return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16), 1];
    }
    const m = String(c || '').match(/[\d.]+/g);
    return m && m.length >= 3 ? m.slice(0, 4).map(Number) : null;
  };
  const same = (a, b) => {
    const x = rgba(a), y = rgba(b);
    return x && y && x.slice(0, 3).every((v, i) => Math.abs(v - y[i]) < 1);
  };
  const lum = c => {
    const m = rgba(c) || [0, 0, 0];
    const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); };
    return .2126 * f(m[0]) + .7152 * f(m[1]) + .0722 * f(m[2]);
  };
  const contrast = (a, b) => (Math.max(lum(a), lum(b)) + .05) / (Math.min(lum(a), lum(b)) + .05);
  const visibleBg = e => {
    const c = getComputedStyle(e).backgroundColor;
    return c && !/rgba?\(0, 0, 0, 0\)|transparent/.test(c) ? c : null;
  };
  const classify = e => {
    if (e.classList.contains('seal')) return 'seal';
    const lines = e.querySelectorAll('line').length;
    const polys = e.querySelectorAll('polygon').length;
    const paths = e.querySelectorAll('path').length;
    const svgs = e.querySelectorAll('svg').length;
    if (lines === 12 && svgs === 1) return 'sunburst';
    if (polys === 3 && svgs === 3) return 'chevrons';
    if (paths === 1 && svgs === 1) return 'sparkle';
    return 'unknown';
  };

  const root = getComputedStyle(document.documentElement);
  const rootBg = root.getPropertyValue('--bg').trim();
  const surface = root.getPropertyValue('--surface').trim();
  const R = {
    pages: 0,
    ornaments: 0,
    ornamentsPerPage: 0,
    seals: 0,
    pagesWithoutExactlyOneSeal: 0,
    sunbursts: 0,
    structuralPagesWithoutExactlyOneSunburst: 0,
    sunburstsOnContentPages: 0,
    chevrons: 0,
    sparkles: 0,
    offVocabularyOrnaments: 0,
    ornamentBleeds: 0,
    ornamentBleedPct: 0,
    middleBandOrnaments: 0,
    layoutDevices: 0,
    layoutDevicesPerPage: 0,
    fullBleedPages: 0,
    fullBleedPct: 0,
    surfaceUses: (document.documentElement.outerHTML.match(/var\(--surface\)/g) || []).length,
    surfaceCardsOnBg: 0,
    paintMatchesStageGround: 0,
    lowContrastSealLabels: 0,
    chromeTextChips: 0,
    textInBottomChromeBand: 0,
    labelledBoxes: 0,
    labelledBoxesPerPage: 0,
    samples: []
  };

  const stages = [...document.querySelectorAll('.slide .stage, .stage')];
  for (const [pi, st] of stages.entries()) {
    R.pages++;
    const sr = st.getBoundingClientRect();
    const stageBg = getComputedStyle(st).backgroundColor;
    const structural = ['cover', 'divider', 'close', 'section-divider'].includes(st.dataset.slot);
    if (!same(stageBg, rootBg)) R.fullBleedPages++;

    const ornaments = [...st.querySelectorAll('[data-doodle]')];
    R.ornaments += ornaments.length;
    const types = ornaments.map(classify);
    const seals = types.filter(x => x === 'seal').length;
    const suns = types.filter(x => x === 'sunburst').length;
    if (seals !== 1) R.pagesWithoutExactlyOneSeal++;
    if (structural && suns !== 1) R.structuralPagesWithoutExactlyOneSunburst++;
    if (!structural && suns) R.sunburstsOnContentPages += suns;

    ornaments.forEach((e, i) => {
      const type = types[i];
      if (type === 'unknown') {
        R.offVocabularyOrnaments++;
        if (R.samples.length < 10) R.samples.push(`p${pi + 1} unknown ornament`);
      } else R[{seal: 'seals', sunburst: 'sunbursts', chevrons: 'chevrons', sparkle: 'sparkles'}[type]]++;
      const r = e.getBoundingClientRect();
      if (r.left < sr.left - 1 || r.right > sr.right + 1 || r.top < sr.top - 1 || r.bottom > sr.bottom + 1)
        R.ornamentBleeds++;
      const cy = (r.top + r.bottom) / 2;
      if (cy >= sr.top + sr.height / 3 && cy <= sr.top + sr.height * 2 / 3) R.middleBandOrnaments++;

      let marks = [];
      if (type === 'seal' || type === 'chevrons') marks = [...e.querySelectorAll('polygon')];
      else if (type === 'sparkle') marks = [...e.querySelectorAll('path')];
      else if (type === 'sunburst') marks = [...e.querySelectorAll('line')];
      if (marks.some(m => same(getComputedStyle(m).fill, stageBg) || same(getComputedStyle(m).stroke, stageBg))) {
        R.paintMatchesStageGround++;
        if (R.samples.length < 10) R.samples.push(`p${pi + 1} ${type} matches stage`);
      }

      if (type === 'seal') {
        const poly = e.querySelector('polygon'), lab = e.querySelector('.seal-label');
        if (poly && lab && contrast(getComputedStyle(poly).fill, getComputedStyle(lab).color) < 3) {
          R.lowContrastSealLabels++;
          if (R.samples.length < 10) R.samples.push(`p${pi + 1} seal contrast`);
        }
      }
    });

    R.layoutDevices += st.querySelectorAll('[data-tile],[data-node],[data-badge],[data-connector]').length;

    const candidates = [...st.querySelectorAll('.card,[data-device],[data-tile],[data-node],[data-badge]')];
    const seen = new Set();
    for (const e of candidates) {
      if (seen.has(e) || e.closest('[data-doodle]')) continue;
      seen.add(e);
      const bg = visibleBg(e);
      if (!bg) continue;
      if (same(bg, stageBg)) R.paintMatchesStageGround++;
      if (same(stageBg, rootBg) && same(bg, surface)) R.surfaceCardsOnBg++;
    }

    st.querySelectorAll('.kicker,.pagenum,[data-running-head]').forEach(e => {
      const cs = getComputedStyle(e);
      if (visibleBg(e) || (parseFloat(cs.borderTopWidth) > 0 && cs.borderTopStyle !== 'none') || cs.boxShadow !== 'none')
        R.chromeTextChips++;
    });

    const fit = st.querySelector('.fit');
    if (fit) fit.querySelectorAll('*').forEach(e => {
      if (e.closest('[data-doodle]')) return;
      const t = ownText(e);
      if (t.length < 2) return;
      for (let n = e; n && n !== fit; n = n.parentElement)
        if (getComputedStyle(n).position === 'absolute') return;
      const rg = document.createRange(); rg.selectNodeContents(e);
      const runs = [...rg.getClientRects()].filter(x => x.width > 2);
      if (runs.some(x => x.bottom > sr.bottom - sr.height * .09 + 2)) {
        R.textInBottomChromeBand++;
        if (R.samples.length < 10) R.samples.push(`p${pi + 1} bottom-band "${t.slice(0, 18)}"`);
      }
    });

    const boxes = new Set(st.querySelectorAll('[data-badge]'));
    st.querySelectorAll('*').forEach(e => {
      if (e.closest('[data-doodle]') || e.matches('[data-badge]') || !ownText(e)) return;
      const r = e.getBoundingClientRect(), bg = visibleBg(e), br = parseFloat(getComputedStyle(e).borderRadius);
      if (bg && r.width < sr.width * .24 && r.height < sr.height * .12 && br >= r.height * .25) boxes.add(e);
    });
    R.labelledBoxes += boxes.size;
  }

  R.ornamentsPerPage = +(R.ornaments / (R.pages || 1)).toFixed(3);
  R.ornamentBleedPct = +(R.ornamentBleeds / (R.ornaments || 1)).toFixed(3);
  R.layoutDevicesPerPage = +(R.layoutDevices / (R.pages || 1)).toFixed(3);
  R.fullBleedPct = +(R.fullBleedPages / (R.pages || 1)).toFixed(3);
  R.labelledBoxesPerPage = +(R.labelledBoxes / (R.pages || 1)).toFixed(3);
  return JSON.stringify(R, null, 1);
})()
