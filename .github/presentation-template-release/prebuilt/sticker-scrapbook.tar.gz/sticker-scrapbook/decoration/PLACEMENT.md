# sticker-scrapbook — decoration placement

Everything here is measured from the original reference deck (15 pages, 42 decoration
elements, rendered at 1600×900). Numbers, not taste.

Open `decoration.html` to see each ornament rendered with no text on the page.

**Do not carry bloom's decoration rules over.** Three of them are inverted here, and
the measurement is in §G. This template bleeds almost nothing off the stage, puts
boxes on colour fields constantly, and uses `--surface` freely. bloom does the
opposite of all three.

## The layer model

| z-index | layer | where it comes from |
|---|---|---|
| 1 | `sunburst` — the large background ornament | this folder |
| 5 | `chevrons`, `sparkle` | this folder |
| 6 | `seal` | this folder |
| 40 | `.fit` — all text | `../layouts/*.html` |
| 45 | pagenum | the shell |

Decoration is never inside `.fit`. If a layout and an ornament collide, move the
ornament — never the copy.

## A · Vocabulary — 4 ornaments, nothing else

Every ornament in the reference deck, with its marker and count:

| name | marker | what it is | count | size (cqw) |
|---|---|---|---|---|
| `seal` | `[data-decoration="seal"]` | textless 32-point shape; its wrapper carries a separate label | 15 | 6.8–15.1, median 9.3 |
| `sunburst` | `[data-decoration="sunburst"]` | 12 `<line>` radiating from centre, `opacity:.5` | 5 | 22–24 |
| `chevrons` | `[data-decoration="chevrons"]` | a flex unit of 3 identical double-chevron `<polygon>`, `gap:.4cqw` | 12 | 12–15 |
| `sparkle` | `[data-decoration="sparkle"]` | one 4-point star `<path>` | 10 | 3.4–4.5 |

`data-decoration` is placed on the textless SVG shape, never on the seal's
text-bearing wrapper. The wrapper keeps `data-doodle` so the template-specific probe
can count one chevron unit rather than its three glyphs.

Do not invent plain circles, squares, arches, triangles or colour blocks. The
`design-system.md` line about "generic substitute circles" is measurable here: the
reference contains none.

## B · One seal per page — the strongest rule in this template

**15 of 15 reference pages carry exactly one `seal`. Never zero, never two.**

It is the template's namesake and the single most recognisable thing on the page.
Standard deviation across 15 pages is 0. This is an exact-equality criterion.

- `8–10cqw` on a content page, up to `15cqw` on a cover
- `transform:rotate(-8deg)` to `rotate(-12deg)` — the reference uses −8 (9×), −10 (5×), −12 (1×)
- `z-index:6`, above the other ornaments and below `.fit`
- one or two words, or a two-digit number, or a short date
- **three layers, all required**: wrapper → `<svg>` polygon → `.seal-label` at
  `position:absolute;inset:0` *of the seal wrapper*. A label written at `inset:0` of a
  content block instead fills that block and buries the copy under it.

### The seal's fill and its label must be a matched pair

This is the one place the reference was wrong, and it is fixed in the original reference deck as
of this commit.

The reference paired a **raw hue** fill (`--s1`, `--s2`, `--s3`) with a **ground**
text token (`--t1`, `--t2`, `--t3`). Those are different colours. Measured across the
five preferred colour systems:

| pairing | prism | carnival | pop_art | citrus_fresh | berry_pop |
|---|---|---|---|---|---|
| `--s1` / `--t1` | **2.82** | 3.97 | 3.29 | 12.73 | 4.61 |
| `--s3` / `--t3` | **2.56** | **2.53** | **2.61** | **2.96** | 16.15 |
| `--s2` / `--t2` | 12.43 | 10.27 | 15.59 | **2.42** | 11.08 |

In `prism` — the default token, and the one `reference.jpg` was rendered with — **8
of the 15 seal labels sat below 3.0:1**. The deck audit cannot see this: the fill is
an SVG `fill` attribute, not a CSS background, so `bgOf()` walks straight past it to
the stage colour and reports a comfortable pass.

**Use a ground token and its own text token.** `--g0/--t0` … `--g3/--t3`, or
`--bg/--ink`. Worst case across all five systems after the fix: **4.60:1**.

```
fill var(--g1) → label var(--t1)      fill var(--bg) → label var(--ink)
```

## C · How many ornaments, by page role — measured, not chosen

The count is not uniform, and it is not random. It is decided by the page role:

| page role | ornaments | which |
|---|---|---|
| cover, section divider, closing | **4** | `sunburst` + `seal` + `chevrons` + `sparkle` |
| agenda, content | **2** | `seal` + *one* of `chevrons` / `sparkle` |

Reference: 5 pages of the first kind (p1, p3, p7, p11, p15), 10 of the second. Two
content pages carry a third ornament (p2, p4). Deck average **2.8 per page**.

`sunburst` appears **only** on the 5 opening/divider/closing pages — 5 uses, 5 pages,
exact. It is what marks a page as structural rather than content. Do not put one on a
content page, and do not leave one off a divider.

On content pages `chevrons` and `sparkle` alternate; the reference never doubles up
on the same one two content pages running.

## D · Ornaments stay inside the stage

**41 of 42 reference ornaments sit fully within the stage bounds. Bleed rate 2.4%.**

The single exception is one `sunburst` on the cover, anchored `left:-5cqw;top:-4cqh`.

`design-system.md` says "a large ornament must be cropped by the stage edge rather
than floated in the middle". Measured, the reference does that **once in five**
large ornaments. Treat it as permission for the cover, not as a rule — and do not
import bloom's version of it, which is the opposite (bloom bleeds 94%).

Anchor to the near edge — `right:` in the right third, `bottom:` in the bottom third
— so a longer label grows inward where there is room.

## E · The middle band is for text

Ornament centres by vertical third: **top 21, middle 2, bottom 19**.

Only 2 of 42 ornaments (4.8%) are centred in the middle third of the stage, and both
are small `sparkle`s beside a title. The band from 34% to 67% of stage height belongs
to the copy.

This is a distribution, not an equality — a middle-band ornament is not automatically
wrong. It is reported, not gated.

## F · Layout devices are not decoration

The reference also contains 4 tiles, 4 nodes, 3 badges and 1 connector. They carry
content or perform layout work, so they are **not ornaments**, do not receive a
`data-decoration` marker, and do not enter the decoration count. Their markup stays
with `icon-cells`, `process-steps` and `numbered-list` in `../layouts/`.

This template therefore has no optional item-set decoration and deliberately has no
`item-sets.html`. Do not manufacture a square, card or coloured block to fill that
slot. Size genuine layout devices with `--sz`, never `width`/`height`; the shell uses
the variable to scale both the box and its glyph.

## G · Colour — measured on this template's own systems

Run these against your chosen token; the names are shared across templates, the
values are not.

**`--surface` is legible only on a colour field.** Measured against `--bg`:

| token | prism | carnival | pop_art | citrus_fresh | berry_pop |
|---|---|---|---|---|---|
| `--surface` on `--bg` | 1.07 | 1.02 | 1.10 | 1.00 | 1.03 |
| `--surface` on a `--g?` field | 4.65 | 4.60 | 3.65 | 4.66 | 4.61 |

The reference puts **8 `--surface` cards on colour fields and 0 on `--bg`**. That is
an exact-equality criterion. A `--surface` card on a `--bg` page is an invisible
rectangle.

This is where bloom's rule is inverted: bloom bans `--surface` outright because its
page is cream and its surface is white. Here the page is *usually* a colour field, so
`--surface` is the correct card colour — the reference uses it 14 times.

**A card on a colour field must restate its text colour.** The stage sets
`color:var(--t1)` and the card inherits it — white text on a near-white card. The
shell's `.card` now carries `color:var(--ink)` for this reason. Any hand-written card
must do the same.

**Nothing may be painted in the stage's own ground colour.** Cycling `--g0..--g3` on a
`--g3` stage makes the fourth item vanish. It cost two layouts and two ornaments here,
and no probe can see it: identical colours produce no contrast pair to measure, so
`lowContrast` stays at 0 while the item is completely invisible.

This applies to **seal fills too**. Measured on the reference: **0 of 15 seals share
their page's ground** — an exact-equality criterion. The four `--bg`-filled seals are
all on colour-field pages (p3, p7, p11, p15); a `--bg` seal on a `--bg` page is a
white shape on white.

| stage | seal fills available |
|---|---|
| `--g0` | `--g1` `--g2` `--g3` `--bg` |
| `--g1` | `--g0` `--g2` `--g3` `--bg` |
| `--g3` | `--g0` `--g1` `--g2` `--bg` |
| `--bg` | `--g0` `--g1` `--g2` `--g3` |

Same for the `chevrons` and `sunburst` fill, which default to `--s2`. `--s2` and
`--g2` are the *same hex value* in `prism`, so an `--s2` ornament on a `--g2` page is
invisible. The deck rhythm rotates `--g0`/`--g3`/`--g1` and never uses `--g2` as a
page ground, which is why the reference never hits this — keep it that way.

**Raw hues are fills, never text.** On `--bg`:

| as text on `--bg` | prism | carnival | citrus_fresh |
|---|---|---|---|
| `--s1` `--s2` `--s3` `--accent` | 1.48–4.97 | 1.76–3.90 | 1.44–2.95 |
| `--ka` `--k1` `--k2` `--k3` | 4.97–17.58 | 16.59 | 15.81 |
| `--soft` | 6.81 | 7.10 | 6.77 |

Use `--ka`/`--k1..k3`/`--soft`/`--ink` for type on `--bg`, and `--t?` for type on
`--g?`. Never `--ink` on a colour field: it reads **1.00:1** on `berry_pop`'s `--g3`
and 1.06 on `pop_art`'s `--g2`.

**Colour fields are the norm, not the exception.** 12 of 15 reference pages are
full-bleed `--g?` fields — **80%**. `design-system.md`'s rhythm rule is measured and
correct: rotate `--g0`, `--g3`, `--g1` with one `--bg` page every three to four
slides. bloom's "roughly one page in four" is a bloom number; here it is four in five.

**Boxes on a full-bleed page are normal here.** The reference has 22. bloom forbids
them. Do not carry that rule over.

## H · Where the reference reads non-zero — report, never gate

| criterion | reference | verdict |
|---|---|---|
| ornaments bleeding off the stage | 2.4% | template-specific, not a defect either way |
| ornaments centred in the middle third | 2 of 42 | report only |
| labelled boxes per page | 0.27 | matches `design-system.md`'s stated 0.3 |
| `--surface` uses | 14 | correct for this template |
| boxes on a full-bleed page | 22 | correct for this template |
| full-bleed pages | 80% | correct for this template |

And where it reads zero, so it can gate:

| criterion | reference |
|---|---|
| kicker, page number or running head given a chip | **0** |
| `--surface` card on a `--bg` page | **0** |
| text running into the bottom chrome band | **0** |
| seal label under 3.0:1 against its own fill | **0** *(after the fix in §B)* |
| pages without exactly one seal | **0** |

## I · Deliberate deviation from the reference

One, and it is §B: the seal fills were changed from `--s1/--s2/--s3` to
`--g1/--g2/--g3` so the labels clear 3:1 in every preferred colour system. The seals
are marginally deeper in hue than `reference.jpg`. Everything else follows the
reference as measured.

## J · When to place nothing

A page whose copy already fills the stage still carries its seal — that rule has no
exceptions in 15 pages — but it may carry nothing else. An ornament crowded against
text is worse than no ornament. Content order of priority is in `SKILL.md` §3:
decoration never wins against accuracy or legibility.
