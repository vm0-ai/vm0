# Sticker Scrapbook design-system entrypoint

The sole authoritative normal-generation specification is
[`authoring-core.md`](authoring-core.md). Read it through the batched contract in
`SKILL.md`.

Files under `reference/` preserve the pre-migration design notes and diagnostics.
They are provenance only, may describe superseded rules, and must not be read during
normal generation.
