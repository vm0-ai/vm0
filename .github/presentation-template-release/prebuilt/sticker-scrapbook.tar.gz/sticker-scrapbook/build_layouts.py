#!/usr/bin/env python3
"""Emit sticker-scrapbook/layouts/*.html.

One shell, one file per layout. Kept as a generator so the shell, the safe area
and the ground rotation cannot drift between the generated files.
Run from the template folder:  python3 build_layouts.py
"""
import os, textwrap

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'layouts')

SHELL_CSS = """:root{
  --r-xs: .5cqw;
  --r-sm: .9cqw;
  --r-md: 1.7cqw;
  --r-lg: 3cqw;
  --r-xl: 5cqw;
--fd: "Poppins";
  --fb: "Figtree";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);overflow-wrap:break-word;word-break:normal;}
.stage *{overflow-wrap:break-word !important;word-break:normal !important;}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;display:flex;flex-direction:column;align-items:stretch;justify-content:center;}
.fit>h1+*{margin-top:4cqh!important;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}
.seal{position:absolute;}.seal>.seal-label{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;text-align:center;font-family:var(--fd),var(--cjk-display);font-weight:700;line-height:1.05;letter-spacing:.01em;padding:14%;}

.display{font-family:var(--fd),var(--cjk-display);font-size:calc((7cqw) * var(--fit, 1));font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:calc((4.6cqw) * var(--fit, 1));font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:calc((3.2cqw) * var(--fit, 1));font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:calc((1.95cqw) * var(--fit, 1));font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:calc((5.2cqw) * var(--fit, 1));font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:calc((1.15cqw) * var(--fit, 1));font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:calc((2cqw) * var(--fit, 1));font-weight:300;line-height:1.5;}
.body{font-size:calc((1.5cqw) * var(--fit, 1));font-weight:400;line-height:1.5;}
.cap{font-size:calc((1.2cqw) * var(--fit, 1));font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:calc((1cqw) * var(--fit, 1));font-weight:500;letter-spacing:.06em;opacity:.65;z-index:45;}

.tile{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;font-size:calc((calc(var(--sz,5cqw)*.4)) * var(--fit, 1));}
.tile>span{font-size:calc((40cqw) * var(--fit, 1));line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;font-size:calc((calc(var(--sz,5cqw)*.4)) * var(--fit, 1));}
.badge>span{font-size:calc((40cqw) * var(--fit, 1));line-height:1;}
.tick{position:absolute;}
.card{background:var(--surface);color:var(--ink);border-radius:var(--r-md);}
.dot{border-radius:50%;}.qcircle{border-radius:50% 0 0 0;}.semi{border-radius:999px 999px 0 0;}.tri{width:0;height:0;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}

:root{--r-xs:1cqw!important;--r-sm:1.6cqw!important;--r-md:2.2cqw!important;--r-lg:3.2cqw!important;--r-xl:5cqw!important;}
[data-device="price"],[data-device="quote"]{border-radius:var(--r-lg)!important;}
[data-device="numbered-list"] .badge{border-radius:999px!important;}
[data-device="process"] [data-node]{border-radius:50%!important;}
[data-device="team"] [data-photocell]{border-radius:var(--r-lg)!important;}
[data-device="icon-cell"] .tile{background:var(--ink)!important;color:var(--bg)!important;border-radius:var(--r-md)!important;}
[data-device="price"]{background:var(--surface)!important;color:var(--ink)!important;}
.display{letter-spacing:-.01em;}
/* Contain-media sizing: fixed-ratio cells may shrink and sit in the middle
   of their lane; natural-ratio cells are marked by the shell after the image loads. */
[data-photocell][style*="aspect-ratio"]{flex-shrink:1!important;min-height:0!important;margin-block:auto;}
[data-photocell][data-contain-fitted]{flex-shrink:1!important;min-width:0!important;min-height:0!important;max-width:100%;max-height:100%;align-self:center;}
[data-photocell][data-contain-column-grow]{flex-grow:0!important;flex-basis:auto!important;}"""

HEAD = """<!DOCTYPE html>
<html data-safe-area="0.06" lang="en" data-color-system="prism">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>sticker-scrapbook — @@NAME@@</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&family=Figtree:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../color-systems/prism.css">
<style>
%s
</style>
</head>
<body>
""" % SHELL_CSS

FIT = 'justify-content:center;padding:13cqh 6cqw 9cqh'
RULE = 'border-top:1.4px solid color-mix(in srgb,currentColor 22%,transparent)'
HUG = 'align-self:flex-start;max-width:100%'
# a group that fills the leftover stage and centres inside it
GROW = 'flex:1;min-height:0;display:flex;flex-direction:column;justify-content:center'

ICON = {
 'book': '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
 'star': '<path d="M12 2l3 6.5 7 1-5 5 1.2 7L12 18l-6.2 3.5L7 14.5l-5-5 7-1z"/>',
 'heart': '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l8.8 8.8 8.8-8.8a5.5 5.5 0 0 0 0-7.8z"/>',
 'flag': '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>',
 'clock': '<circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/>',
 'users': '<path d="M17 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9.5" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9"/>',
 'pin': '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
 'check': '<polyline points="20 6 9 17 4 12"/>',
}

def icon(n, cls=''):
    return ('<svg viewBox="0 0 24 24"%s>%s</svg>' % (cls, ICON[n]))

def head_block(kicker, title, cls='h1', on_field=True, sub=None):
    # flex:none is load-bearing. `.fit` is a column flex, so a heading defaults to
    # flex:0 1 auto and will SHRINK to give room to a flex:1 sibling -- the chart
    # then draws over the title. Titles never shrink; only the content group grows.
    kc = 'opacity:.82' if on_field else 'color:var(--ka)'
    s = '<div class="kicker" style="flex:none;%s">%s</div>\n' % (kc, kicker)
    s += '  <h1 class="%s" style="flex:none;margin-top:1.1cqh">%s</h1>\n' % (cls, title)
    if sub:
        s += '  <p class="lead" style="flex:none;margin-top:1.6cqh;opacity:.88">%s</p>\n' % sub
    return s

def grounds(stage_g, n):
    """n ground indices, never reusing the stage's own field.

    An item painted --g3 on a --g3 stage is invisible. The probe cannot see it
    (same colour = no contrast pair to measure) and it cost two layouts here."""
    pool = [i for i in (0, 1, 2, 3) if i != stage_g]
    return [pool[i % len(pool)] for i in range(n)]

L = {}

# ------------------------------------------------------------------ opening
L['cover'] = ('background:var(--g0);color:var(--t0)', """
  <div style="%(GROW)s">
    <div class="kicker" style="opacity:.86">Riverside Primary presents</div>
    <h1 class="display" style="margin-top:2.4cqh">Community<br>Day 2026</h1>
    <p class="lead" style="margin-top:3cqh;opacity:.9">A day to make, share, and meet the neighbours.</p>
  </div>
  <div style="%(HUG)s">
    <div class="kicker" style="opacity:.86">18 May &nbsp;·&nbsp; school hall and garden</div>
  </div>
""" % globals())

def agenda_card(n, t, b, g):
    return ('<div data-device="agenda" style="flex:1;display:flex;flex-direction:column;gap:.8cqh;'
            'padding:2.6cqh 1.8cqw;background:var(--g%d);color:var(--t%d);border-radius:var(--r-lg)">'
            '<div class="h2">%s</div><h3 class="h3">%s</h3>'
            '<p class="body" style="opacity:.92">%s</p></div>' % (g, g, n, t, b))

L['agenda'] = ('background:var(--g3);color:var(--t3)', """
  %s
  <div style="display:flex;flex-direction:column;gap:1.8cqh;margin-top:3cqh;flex:none">
    <div data-peer-row="1" style="display:flex;gap:1.8cqw;align-items:stretch">%s%s%s</div>
    <div data-peer-row="1" style="display:flex;gap:1.8cqw;align-items:stretch">%s%s%s</div>
  </div>
""" % (head_block("Today's plan", "Event agenda", 'h1'),
       *[agenda_card(n, t, b, g) for (n, t, b), g in zip([
           ('01', 'Welcome', 'Opening remarks from the principal and PTA chair.'),
           ('02', 'The year ahead', 'Goals, calendar and the term ahead at a glance.'),
           ('03', 'Policies', 'Rules, uniform, grading and homework expectations.'),
           ('04', 'Get involved', 'Volunteering, the PTA and how to join in.'),
           ('05', 'Staying in touch', 'Newsletters, the app and who to contact.'),
           ('06', 'Questions', 'Open floor for anything not covered above.')], grounds(3, 6))]))

# A title or a paragraph that is alone on its line owns the whole measure. Neither
# `align-items:flex-start` on the group nor HUG on the text may be used to shrink a
# wrapping text box: a hugged box breaks at the widest hard-coded line instead of at
# the safe area, which reads as a title folded in the middle of an empty page. Half
# width is only legitimate when something real -- an image, a chart, a second column
# -- sits beside it.
L['section-divider'] = ('background:var(--g1);color:var(--t1)', """
  <div style="%(GROW)s">
    <div class="kicker" style="opacity:.86">Section 02</div>
    <h1 class="display" style="margin-top:2cqh">Families in action</h1>
    <p class="lead" style="margin-top:2.4cqh;opacity:.9">How shared ideas become visible community projects.</p>
  </div>
""" % globals())

L['close'] = ('background:var(--g0);color:var(--t0)', """
  <div style="%(GROW)s">
    <h1 class="display">See you Saturday</h1>
    <p class="lead" style="margin-top:2.4cqh;opacity:.9">Bring one idea, one friend, and an appetite for the garden lunch.</p>
    <div class="kicker" style="margin-top:3.4cqh;opacity:.86">community@riverside.edu &nbsp;·&nbsp; riverside.edu/events</div>
  </div>
""" % globals())

# ------------------------------------------------------------------ prose
L['two-column'] = ('', """
  %s
  <div data-peer-row="1" style="display:flex;gap:3.4cqw;margin-top:3.4cqh;flex:none;align-items:stretch;%s;padding-top:2.6cqh">
    <div style="flex:1"><div class="h3">More ways to join</div><p class="body soft" style="margin-top:1cqh">Offer a morning and an evening session, translated invitations, and a remote feedback option.</p></div>
    <div style="flex:1"><div class="h3">Clear follow-through</div><p class="body soft" style="margin-top:1cqh">Publish the decision, name its owner, and tell families when the group will review progress.</p></div>
  </div>
""" % (head_block('Participation plan', 'What families need from us', 'h1', False), RULE))

L['three-column'] = ('', """
  %s
  <div data-peer-row="1" style="display:flex;gap:2.6cqw;margin-top:3.4cqh;flex:none;align-items:stretch;%s;padding-top:2.6cqh">
    <div style="flex:1"><div class="kicker" style="color:var(--ka)">01</div><div class="h3" style="margin-top:.9cqh">Attend</div><p class="body soft" style="margin-top:.9cqh">Join one event and meet the people behind the programme.</p></div>
    <div style="flex:1"><div class="kicker" style="color:var(--ka)">02</div><div class="h3" style="margin-top:.9cqh">Volunteer</div><p class="body soft" style="margin-top:.9cqh">Offer one hour, one skill, or one practical pair of hands.</p></div>
    <div style="flex:1"><div class="kicker" style="color:var(--ka)">03</div><div class="h3" style="margin-top:.9cqh">Lead</div><p class="body soft" style="margin-top:.9cqh">Own a small project and bring a wider group into the work.</p></div>
  </div>
""" % (head_block('Get involved', 'Three paths to participation', 'h1', False), RULE))

def icon_cell(ic, t, b):
    return ('<div class="card" data-device="icon-cell" style="flex:1;display:flex;gap:1.4cqw;align-items:flex-start;padding:2.4cqh 1.8cqw">'
            '<div class="tile" data-tile="1" style="--sz:5cqw;flex:none">%s</div>'
            '<div style="min-width:0"><h3 class="h3">%s</h3><p class="body soft" style="margin-top:.6cqh">%s</p></div></div>'
            % (icon(ic), t, b))

L['icon-cells'] = ('background:var(--g1);color:var(--t1)', """
  %s
  <div style="display:flex;flex-direction:column;gap:2cqh;margin-top:3.4cqh;flex:none">
    <div data-peer-row="1" style="display:flex;gap:2cqw;align-items:stretch">%s%s</div>
    <div data-peer-row="1" style="display:flex;gap:2cqw;align-items:stretch">%s%s</div>
  </div>
""" % (head_block('For families', 'Four things at a glance', 'h1'),
       icon_cell('book', 'Classroom rules', 'Be respectful, ready and kind — the basics that keep learning happy.'),
       icon_cell('star', 'Uniform', 'Simple, comfortable dress guidelines for every school day.'),
       icon_cell('flag', 'Grading', 'How progress is measured and shared with families each term.'),
       icon_cell('clock', 'Homework', 'Reasonable, routine practice that supports class learning.')))

def numbered_row(n, t, b, g, last=False):
    rule = '' if last else ';padding-bottom:1.8cqh;border-bottom:1.4px solid color-mix(in srgb,currentColor 22%,transparent)'
    return ('<div style="display:flex;gap:1.6cqw;align-items:flex-start%s">'
            '<div class="badge" data-badge="1" style="--sz:4.4cqw;flex:none;background:var(--g%d);color:var(--t%d)"><span>%s</span></div>'
            '<div style="min-width:0;flex:1"><div class="h3">%s</div><p class="body" style="margin-top:.5cqh;opacity:.86">%s</p></div></div>'
            % (rule, g, g, n, t, b))

L['numbered-list'] = ('background:var(--g3);color:var(--t3)', """
  <div style="%(GROW)s;flex-direction:row;gap:4cqw;align-items:stretch">
    <div style="flex:1;display:flex;flex-direction:column;justify-content:center">
      <div class="kicker" style="opacity:.82">Our school</div>
      <h1 class="display" style="margin-top:1.1cqh">What we<br>stand for</h1>
      <p class="body" style="margin-top:1.6cqh;opacity:.86">Three commitments that guide every family programme.</p>
    </div>
    <div style="flex:1.25;display:flex;flex-direction:column;gap:1.8cqh;justify-content:center">%(ROWS)s</div>
  </div>
""" % dict(globals(), ROWS=''.join((
       numbered_row('01', 'Every child thrives', 'Learning, safety, and belonging shape every decision.', 0),
       numbered_row('02', 'Families as partners', 'People closest to the child help design the support around them.', 1),
       numbered_row('03', 'Community first', 'Shared spaces and shared responsibility make the whole neighbourhood stronger.', 2, True)))))

L['note-pad'] = ('background:var(--g0);color:var(--t0)', """
  <div style="%(GROW)s;flex-direction:row;gap:4cqw;align-items:center">
    <div style="flex:1;display:flex;flex-direction:column;justify-content:center">
      <div class="kicker" style="opacity:.82">Welcome</div>
      <h1 class="h1" style="margin-top:1.1cqh">A word before<br>we start</h1>
      <p class="body" style="margin-top:1.6cqh;opacity:.86">Why this year begins with listening.</p>
    </div>
    <div style="flex:1.15;display:flex;flex-direction:column;justify-content:center;min-height:0">
      <div class="card" data-device="pad" style="flex:none;display:flex;flex-direction:column;padding:2.2cqh 1.8cqw">
        <div data-photocell="1" style="flex:none;aspect-ratio:16/6;background:var(--ph);border-radius:var(--r-md);overflow:hidden"></div>
        <div class="h3" style="margin-top:1.5cqh">A note from the head teacher</div>
        <p class="body soft" style="margin-top:.8cqh">This term we are opening more ways for families to shape school life, from short listening circles to practical weekend projects.</p>
        <p class="body soft" style="margin-top:.7cqh">Please tell us what would make it easier for you to take part.</p>
        <div class="kicker" style="margin-top:1.4cqh;color:var(--ka)">— Amina Reyes, head teacher</div>
      </div>
    </div>
  </div>
""" % globals())

L['statement'] = ('background:var(--g1);color:var(--t1)', """
  <div style="%(GROW)s;flex-direction:row;gap:4cqw;align-items:stretch">
    <div style="flex:2;display:flex;flex-direction:column;justify-content:center">
      <div class="kicker" style="opacity:.82">The central idea</div>
      <h1 class="display" style="margin-top:1.3cqh">Belonging grows when every family can take part.</h1>
    </div>
    <div style="flex:1;display:flex;flex-direction:column;justify-content:center;gap:2.2cqh">
      <div style="%(RULE)s;padding-top:1.5cqh"><div class="h3">Participation first</div><p class="body" style="margin-top:.7cqh;opacity:.88">Plan around the people who are usually missing, not only the people already in the room.</p></div>
      <div style="%(RULE)s;padding-top:1.5cqh"><div class="h3">One shared measure</div><p class="body" style="margin-top:.7cqh;opacity:.88">Track whether more families can join, contribute, and be heard.</p></div>
    </div>
  </div>
""" % globals())

L['long-form'] = ('', """
  %s
  <p class="lead" style="flex:none;margin-top:2.2cqh">A strong community programme starts by listening closely, naming the shared need, and making the first step easy to understand.</p>
  <div data-peer-row="1" style="display:flex;gap:3.4cqw;margin-top:2.8cqh;flex:none;align-items:stretch;%s;padding-top:2.2cqh">
    <div style="flex:1"><div class="h3">Listen before planning</div><p class="body soft" style="margin-top:.9cqh">Families bring different schedules, languages, and experiences. A useful plan begins with those realities, then turns them into choices the whole group can see.</p><p class="body soft" style="margin-top:1cqh">That makes the invitation specific instead of generic.</p></div>
    <div style="flex:1"><div class="h3">Make progress visible</div><p class="body soft" style="margin-top:.9cqh">Publish the next action, its owner, and the date it will be reviewed. Small, visible commitments build trust faster than a long list of aspirations.</p><p class="cap soft" style="margin-top:1.4cqh">Community planning note · Autumn term</p></div>
  </div>
""" % (head_block('Context', 'Why participation needs deliberate design', 'h1', False), RULE))

def bullet_row(t, b, g, last=False):
    rule = '' if last else ';padding-bottom:1.5cqh;border-bottom:1.4px solid color-mix(in srgb,currentColor 22%,transparent)'
    return ('<div style="display:flex;gap:1.2cqw;align-items:flex-start%s">'
            '<div class="dot" style="flex:none;width:1em;height:1em;margin-top:.32em;background:var(--g%d)"></div>'
            '<div style="flex:1;min-width:0"><div class="h3">%s</div><p class="body" style="margin-top:.45cqh;opacity:.86">%s</p></div></div>'
            % (rule, g, t, b))

L['bullet-list'] = ('background:var(--g3);color:var(--t3)', """
  <div style="%(GROW)s;flex-direction:row;gap:4cqw;align-items:stretch">
    <div style="flex:1;display:flex;flex-direction:column;justify-content:center">
      <div class="kicker" style="opacity:.82">What matters</div>
      <h1 class="display" style="margin-top:1.1cqh">Five principles for the term</h1>
    </div>
    <div style="flex:1.2;display:flex;flex-direction:column;justify-content:center;gap:1.5cqh">%(ROWS)s</div>
  </div>
""" % dict(globals(), ROWS=''.join([
       bullet_row('Make the welcome clear', 'Say who the event is for and what will happen.', 0),
       bullet_row('Offer more than one way in', 'Time, language, and format should not become barriers.', 1),
       bullet_row('Name the owner', 'Every follow-up has one person responsible for the next step.', 2),
       bullet_row('Show the result', 'Close the loop with the people who contributed.', 0),
       bullet_row('Learn in public', 'Share what changed and what the group will try next.', 1, True)])))

# ------------------------------------------------------------------ quotes
L['big-quote'] = ('background:var(--g0);color:var(--t0)', """
  <div style="%(GROW)s;align-items:center;text-align:center">
    <div class="kicker" style="opacity:.8">Shared note</div>
    <blockquote class="h1" style="margin-top:2.4cqh;%(HUG)s;align-self:center">The clearest strategy is the one a team can explain, choose, and act on together.</blockquote>
    <div class="cap" style="margin-top:2.4cqh;opacity:.8"><strong>Maya Chen</strong> · family council chair</div>
  </div>
""" % globals())

def quote_card(q, n, r, g):
    return ('<div data-device="quote" style="flex:1;display:flex;flex-direction:column;padding:2.6cqh 1.8cqw;'
            'background:var(--g%d);color:var(--t%d);border-radius:var(--r-lg)">'
            '<p class="body" style="flex:1">&ldquo;%s&rdquo;</p>'
            '<div style="display:flex;gap:1cqw;align-items:center;margin-top:1.6cqh">'
            '<div data-photocell="1" style="flex:none;width:2.6em;aspect-ratio:1;background:var(--ph);border-radius:50%%;overflow:hidden"></div>'
            '<div style="min-width:0"><div class="cap" style="font-weight:600">%s</div><div class="cap" style="opacity:.78">%s</div></div></div></div>'
            % (g, g, q, n, r))

L['quote-cards'] = ('', """
  %s
  <div data-peer-row="1" style="display:flex;gap:2cqw;margin-top:3.4cqh;flex:none;align-items:stretch">%s%s%s</div>
""" % (head_block('From our families', 'What people say', 'h1', False),
       quote_card('The welcome host knew our names before we found our table.', 'Nadia K.', 'Parent', 0),
       quote_card('I could volunteer for one hour without committing to the whole day.', 'Theo M.', 'Volunteer', 1),
       quote_card('Families left knowing exactly what would happen next.', 'Priya S.', 'Teacher', 2)))

# ------------------------------------------------------------------ numbers
def kpi(v, l, s):
    return ('<div style="flex:1"><div class="stat">%s</div><div class="h3" style="margin-top:.8cqh">%s</div>'
            '<p class="cap soft" style="margin-top:.5cqh">%s</p></div>' % (v, l, s))

L['kpi-grid'] = ('', """
  %s
  <div data-peer-row="1" style="display:flex;gap:2.6cqw;margin-top:3.4cqh;flex:none;align-items:stretch;%s;padding-top:2.6cqh">%s%s%s</div>
""" % (head_block('This year', 'The numbers', 'h1', False), RULE,
       kpi('1,240', 'Families reached', 'Across every year group.'),
       kpi('87%', 'Attendance at events', 'Up from 74% last year.'),
       kpi('36', 'Volunteers', 'Regular, named volunteers.')))

def stat_sticker(v, l, g):
    return ('<div data-device="statcard" style="flex:1;display:flex;flex-direction:column;align-items:flex-start;'
            'padding:3cqh 1.8cqw;background:var(--g%d);color:var(--t%d);border-radius:var(--r-lg)">'
            '<div class="stat">%s</div><div class="h3" style="margin-top:.8cqh">%s</div></div>' % (g, g, v, l))

L['stat-stickers'] = ('background:var(--g3);color:var(--t3)', """
  %s
  <div data-peer-row="1" style="display:flex;gap:2cqw;margin-top:3.4cqh;flex:none;align-items:stretch">%s%s%s</div>
""" % (head_block('Fundraising', 'Together we raised', 'display'),
       stat_sticker('£18k', 'Raised in total', 0),
       stat_sticker('412', 'Donors', 1),
       stat_sticker('9', 'Projects funded', 2)))

L['stat-highlight'] = ('background:var(--g0);color:var(--t0)', """
  <div style="%(GROW)s">
    <div class="kicker" style="opacity:.84">The headline number</div>
    <div class="display" style="margin-top:1.6cqh;font-family:var(--fd),var(--cjk-display)">87%%</div>
    <p class="lead" style="margin-top:2cqh;opacity:.92">of attending families said they would return to another event.</p>
    <div class="cap" style="margin-top:2cqh;opacity:.78">Post-event survey · 126 responses</div>
  </div>
""" % globals())

L['table'] = ('', """
  %s
  <div style="margin-top:3cqh;flex:none;min-width:0">
    <table style="width:100%%;border-collapse:collapse;table-layout:auto;font-size:calc((1.2cqw) * var(--fit, 1));font-variant-numeric:tabular-nums">
      <thead><tr>
        <th style="text-align:left;padding:1.1cqh 1.1cqw;font-family:var(--fd),var(--cjk-display);font-size:calc((1cqw) * var(--fit, 1));letter-spacing:.08em;text-transform:uppercase;opacity:.72;box-shadow:inset 0 -1px 0 currentColor;white-space:nowrap;width:1%%">ID</th>
        <th style="text-align:left;padding:1.1cqh 1.1cqw;font-family:var(--fd),var(--cjk-display);font-size:calc((1cqw) * var(--fit, 1));letter-spacing:.08em;text-transform:uppercase;opacity:.72;box-shadow:inset 0 -1px 0 currentColor">Item</th>
        <th style="text-align:right;padding:1.1cqh 1.1cqw;font-family:var(--fd),var(--cjk-display);font-size:calc((1cqw) * var(--fit, 1));letter-spacing:.08em;text-transform:uppercase;opacity:.72;box-shadow:inset 0 -1px 0 currentColor;white-space:nowrap;width:1%%">Count</th>
        <th style="text-align:right;padding:1.1cqh 1.1cqw;font-family:var(--fd),var(--cjk-display);font-size:calc((1cqw) * var(--fit, 1));letter-spacing:.08em;text-transform:uppercase;opacity:.72;box-shadow:inset 0 -1px 0 currentColor;white-space:nowrap;width:1%%">Share</th>
      </tr></thead>
      <tbody>
        <tr><td style="padding:1.1cqh 1.1cqw;white-space:nowrap;width:1%%;font-family:var(--fd),var(--cjk-display);opacity:.85;box-shadow:inset 0 -1px 0 color-mix(in srgb,currentColor 16%%,transparent)">EV-104</td><td style="padding:1.1cqh 1.1cqw;box-shadow:inset 0 -1px 0 color-mix(in srgb,currentColor 16%%,transparent)">Community day preparation and delivery</td><td style="padding:1.1cqh 1.1cqw;text-align:right;white-space:nowrap;box-shadow:inset 0 -1px 0 color-mix(in srgb,currentColor 16%%,transparent)">164</td><td style="padding:1.1cqh 1.1cqw;text-align:right;white-space:nowrap;box-shadow:inset 0 -1px 0 color-mix(in srgb,currentColor 16%%,transparent)">41%%</td></tr>
        <tr><td style="padding:1.1cqh 1.1cqw;white-space:nowrap;width:1%%;font-family:var(--fd),var(--cjk-display);opacity:.85;box-shadow:inset 0 -1px 0 color-mix(in srgb,currentColor 16%%,transparent)">LB-207</td><td style="padding:1.1cqh 1.1cqw;box-shadow:inset 0 -1px 0 color-mix(in srgb,currentColor 16%%,transparent)">Library sorting, labelling, and reading corners</td><td style="padding:1.1cqh 1.1cqw;text-align:right;white-space:nowrap;box-shadow:inset 0 -1px 0 color-mix(in srgb,currentColor 16%%,transparent)">100</td><td style="padding:1.1cqh 1.1cqw;text-align:right;white-space:nowrap;box-shadow:inset 0 -1px 0 color-mix(in srgb,currentColor 16%%,transparent)">25%%</td></tr>
        <tr><td style="padding:1.1cqh 1.1cqw;white-space:nowrap;width:1%%;font-family:var(--fd),var(--cjk-display);opacity:.85">GD-312</td><td style="padding:1.1cqh 1.1cqw">Garden club and outdoor learning support</td><td style="padding:1.1cqh 1.1cqw;text-align:right;white-space:nowrap">136</td><td style="padding:1.1cqh 1.1cqw;text-align:right;white-space:nowrap">34%%</td></tr>
      </tbody>
    </table>
    <div class="cap soft" style="margin-top:1.4cqh">Community day is the largest single use of volunteer time this term.</div>
  </div>
""" % head_block('Volunteer report', 'Hours contributed by programme', 'h1', False))

def bar(pct, lab, g):
    return ('<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:1cqh;min-height:0">'
            '<div style="flex:1;min-height:0;width:100%%;display:flex;align-items:flex-end">'
            '<div style="width:100%%;height:%s;background:var(--g%d);border-radius:var(--r-sm) var(--r-sm) 0 0"></div></div>'
            '<div class="cap" style="font-weight:600">%s</div><div class="cap soft">%s</div></div>' % (pct, g, pct, lab))

L['chart-bar'] = ('', """
  %s
  <div style="%s;margin-top:3cqh">
    <div data-peer-row="1" style="flex:1;min-height:0;display:flex;gap:2.4cqw;align-items:stretch">%s%s%s%s</div>
  </div>
""" % (head_block('Trend', 'Attendance by term', 'h1', False), GROW,
       bar('46%', 'Autumn', 0), bar('72%', 'Spring', 1), bar('61%', 'Summer', 2), bar('88%', 'Autumn', 3)))

L['chart-line'] = ('', """
  %s
  <div style="%s;margin-top:3cqh">
    <div style="flex:1;min-height:0;display:flex;flex-direction:column">
      <div style="flex:1;min-height:0"><svg viewBox="0 0 100 46" preserveAspectRatio="none" style="width:100%%;height:100%%;overflow:visible">
        <line x1="0" y1="45" x2="100" y2="45" stroke="currentColor" stroke-opacity=".25" stroke-width=".4"/>
        <line x1="0" y1="23" x2="100" y2="23" stroke="currentColor" stroke-opacity=".14" stroke-width=".4"/>
        <polyline points="2,38 22,30 42,33 62,18 82,12 98,6" fill="none" stroke="var(--g0)" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
        <polyline points="2,42 22,40 42,36 62,34 82,28 98,24" fill="none" stroke="var(--g1)" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="3 2"/>
      </svg></div>
      <div style="display:flex;margin-top:1.2cqh;flex:none">
        <div class="cap soft" style="flex:1">2019</div><div class="cap soft" style="flex:1">2020</div><div class="cap soft" style="flex:1">2021</div>
        <div class="cap soft" style="flex:1">2022</div><div class="cap soft" style="flex:1">2023</div><div class="cap soft" style="flex:none">2024</div>
      </div>
      <div style="display:flex;gap:2cqw;margin-top:1.4cqh;flex:none">
        <div style="display:flex;gap:.6cqw;align-items:center"><div class="dot" style="width:.8em;height:.8em;background:var(--g0)"></div><span class="cap">Families</span></div>
        <div style="display:flex;gap:.6cqw;align-items:center"><div class="dot" style="width:.8em;height:.8em;background:var(--g1)"></div><span class="cap">Volunteers</span></div>
      </div>
    </div>
  </div>
""" % (head_block('Trend', 'Six years of growth', 'h1', False), GROW))

L['chart-pie'] = ('', """
  %s
  <div style="%s;margin-top:3cqh">
    <div style="flex:1;min-height:0;display:flex;gap:3.4cqw;align-items:stretch">
      <div style="flex:1;min-height:0;display:flex;align-items:center;justify-content:center"><svg viewBox="0 0 42 42" style="width:100%%;height:100%%">
        <circle cx="21" cy="21" r="15.9" fill="none" stroke="var(--g0)" stroke-width="9" stroke-dasharray="41 59" stroke-dashoffset="0"/>
        <circle cx="21" cy="21" r="15.9" fill="none" stroke="var(--g1)" stroke-width="9" stroke-dasharray="25 75" stroke-dashoffset="-41"/>
        <circle cx="21" cy="21" r="15.9" fill="none" stroke="var(--g2)" stroke-width="9" stroke-dasharray="20 80" stroke-dashoffset="-66"/>
        <circle cx="21" cy="21" r="15.9" fill="none" stroke="var(--g3)" stroke-width="9" stroke-dasharray="14 86" stroke-dashoffset="-86"/>
      </svg></div>
      <div style="flex:1;display:flex;flex-direction:column;justify-content:center;gap:1.4cqh">
        <div style="display:flex;gap:.9cqw;align-items:baseline"><div class="dot" style="flex:none;width:.9em;height:.9em;background:var(--g0)"></div><div style="flex:1"><span class="h3">Trips</span> <span class="cap soft">41%%</span></div></div>
        <div style="display:flex;gap:.9cqw;align-items:baseline"><div class="dot" style="flex:none;width:.9em;height:.9em;background:var(--g1)"></div><div style="flex:1"><span class="h3">Equipment</span> <span class="cap soft">25%%</span></div></div>
        <div style="display:flex;gap:.9cqw;align-items:baseline"><div class="dot" style="flex:none;width:.9em;height:.9em;background:var(--g2)"></div><div style="flex:1"><span class="h3">Books</span> <span class="cap soft">20%%</span></div></div>
        <div style="display:flex;gap:.9cqw;align-items:baseline"><div class="dot" style="flex:none;width:.9em;height:.9em;background:var(--g3)"></div><div style="flex:1"><span class="h3">Events</span> <span class="cap soft">14%%</span></div></div>
      </div>
    </div>
  </div>
""" % (head_block('Where it went', 'How the fund was spent', 'h1', False), GROW))

L['chart-area'] = ('', """
  %s
  <div style="%s;margin-top:3cqh">
    <div style="flex:1;min-height:0;display:flex;flex-direction:column">
      <div style="flex:1;min-height:0"><svg viewBox="0 0 100 46" preserveAspectRatio="none" style="width:100%%;height:100%%;overflow:visible">
        <defs><linearGradient id="area-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--g3)" stop-opacity=".78"/><stop offset="1" stop-color="var(--g3)" stop-opacity=".12"/></linearGradient></defs>
        <line x1="0" y1="45" x2="100" y2="45" stroke="currentColor" stroke-opacity=".25" stroke-width=".4"/>
        <line x1="0" y1="23" x2="100" y2="23" stroke="currentColor" stroke-opacity=".14" stroke-width=".4"/>
        <path d="M2 40 L18 37 L34 31 L50 33 L66 22 L82 16 L98 7 L98 45 L2 45 Z" fill="url(#area-fill)"/>
        <polyline points="2,40 18,37 34,31 50,33 66,22 82,16 98,7" fill="none" stroke="var(--g3)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
      </svg></div>
      <div style="display:flex;margin-top:1.2cqh;flex:none">
        <div class="cap soft" style="flex:1">Sep</div><div class="cap soft" style="flex:1">Oct</div><div class="cap soft" style="flex:1">Nov</div>
        <div class="cap soft" style="flex:1">Dec</div><div class="cap soft" style="flex:1">Jan</div><div class="cap soft" style="flex:none">Feb</div>
      </div>
      <div class="cap soft" style="margin-top:1.4cqh;flex:none">Cumulative family registrations · 84 to 612</div>
    </div>
  </div>
""" % (head_block('Cumulative growth', 'Registrations build across the year', 'h1', False), GROW))

WF_SCALE = 20  # plot height in £k, so a floating bar can be placed as a percentage

def waterfall_col(lab, value, before, amount, after, g):
    # The riser under a floating bar used to be an empty flex box as wide as the bar.
    # It is an offset, not a column: the bar now sits in its own track and states its
    # own base and height. No text lives in the track, so percentages are safe here.
    return ('<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:.9cqh;min-height:0">'
            '<div style="flex:1;min-height:0;width:100%%;position:relative">'
            '<div style="position:absolute;left:0;right:0;bottom:%s%%;height:%s%%;background:var(--g%d);border-radius:var(--r-sm)"></div></div>'
            '<div class="cap" style="font-weight:600">%s</div><div class="cap soft" style="text-align:center">%s</div></div>'
            % (after * 100 // WF_SCALE, amount * 100 // WF_SCALE, g, value, lab))

L['chart-waterfall'] = ('', """
  %s
  <div style="%s;margin-top:3cqh">
    <div data-peer-row="1" style="flex:1;min-height:0;display:flex;gap:2.2cqw;align-items:stretch">
      %s%s%s%s%s
    </div>
    <div class="cap soft" style="margin-top:1.4cqh;flex:none">Opening balance plus income, less costs, equals the current total.</div>
  </div>
""" % (head_block('Change explained', 'How the fund reached £20k', 'h1', False), GROW,
       waterfall_col('Opening fund', '£12k', 8, 12, 0, 3),
       waterfall_col('Family events', '+£6k', 2, 6, 12, 0),
       waterfall_col('Event costs', '−£2k', 2, 2, 16, 1),
       waterfall_col('Local sponsors', '+£4k', 0, 4, 16, 2),
       waterfall_col('Current total', '£20k', 0, 20, 0, 3)))

def funnel_row(lab, value, pct, g):
    return ('<div style="display:flex;align-items:center;gap:1.4cqw">'
            '<div class="h3" style="flex:1;min-width:0">%s</div>'
            '<div style="flex:3;min-width:0;display:flex;justify-content:center"><div style="width:%s;height:1.6em;background:var(--g%d);border-radius:999px"></div></div>'
            '<div class="h3" style="flex:none;font-variant-numeric:tabular-nums">%s</div></div>' % (lab, pct, g, value))

L['chart-funnel'] = ('background:var(--g1);color:var(--t1)', """
  %s
  <div style="display:flex;flex-direction:column;gap:1.9cqh;margin-top:3.4cqh;flex:none">
    %s%s%s%s
  </div>
  <div class="cap" style="margin-top:1.6cqh;opacity:.78">Conversion from invitation to repeat participation.</div>
""" % (head_block('Participation funnel', 'From invitation to regular volunteer', 'h1'),
       funnel_row('Invited', '1,240', '100%', 0),
       funnel_row('Registered', '612', '72%', 2),
       funnel_row('Attended', '328', '51%', 3),
       funnel_row('Returned', '146', '34%', 0)))

# ------------------------------------------------------------------ sequence
def process_copy(n, t, b, align):
    return ('<div style="flex:1;min-width:0;text-align:center;display:flex;flex-direction:column;justify-content:%s">'
            '<div class="kicker" style="color:var(--ka)">Step %s</div>'
            '<div class="h3" style="margin-top:.7cqh">%s</div>'
            '<p class="body soft" style="margin-top:.6cqh">%s</p></div>' % (align, n, t, b))

def process_node(ic):
    # The reference uses four small --ink/--bg discs. This is measured sticker
    # vocabulary, not bloom's later decision to recolour its own nodes.
    return ('<div style="flex:1;display:flex;justify-content:center">'
            '<div class="tile" data-node="1" style="--sz:5cqw;flex:none;background:var(--ink);color:var(--bg)">%s</div></div>'
            % icon(ic))

# Four steps, four columns, nothing else in the row. The earlier zigzag put each
# caption above or below the line and paid for it with an empty cell beside every
# caption: half the strip was blank flow boxes a quarter of the safe area wide, and
# they squeezed the captions into 23.6% boxes that then folded in two. One caption
# per column, all four filled, is the same vocabulary without the blanks.
L['process-steps'] = ('', """
  %s
  <div data-device="process" style="%s;margin-top:3cqh">
    <div data-connector="1" style="display:flex;flex:none;background:linear-gradient(to right,transparent 12.5%%,color-mix(in srgb,currentColor 26%%,transparent) 12.5%%,color-mix(in srgb,currentColor 26%%,transparent) 87.5%%,transparent 87.5%%) center/100%% 1px no-repeat">%s%s%s%s</div>
    <div data-peer-row="1" style="display:flex;gap:1.6cqw;align-items:stretch;flex:none;margin-top:1.8cqh">%s%s%s%s</div>
  </div>
""" % (head_block('A day at school', 'The daily flow', 'h1', False),
       GROW,
       process_node('clock'), process_node('book'), process_node('users'), process_node('heart'),
       process_copy('01', 'Arrival', 'Doors open and registration begins.', 'flex-start'),
       process_copy('02', 'Core blocks', 'Literacy and numeracy in the morning.', 'flex-start'),
       process_copy('03', 'Enrichment', 'Clubs, music and sport after lunch.', 'flex-start'),
       process_copy('04', 'Home time', 'Collection from the main gate.', 'flex-start')))

def tl(date, t, b, g, last=False):
    conn = '' if last else '<div data-connector="1" style="flex:1;height:1px;background:color-mix(in srgb,currentColor 26%,transparent);margin-top:.75em"></div>'
    return ('<div style="flex:1;display:flex;flex-direction:column;gap:1.2cqh">'
            '<div style="display:flex;align-items:flex-start;gap:.6cqw">'
            '<div class="dot" style="flex:none;width:1.5em;height:1.5em;background:var(--g%d)"></div>%s</div>'
            '<div><div class="kicker" style="color:var(--ka)">%s</div>'
            '<div class="h3" style="margin-top:.7cqh">%s</div>'
            '<p class="body soft" style="margin-top:.6cqh">%s</p></div></div>' % (g, conn, date, t, b))

L['timeline'] = ('', """
  %s
  <div data-peer-row="1" style="display:flex;gap:1.6cqw;margin-top:3.4cqh;flex:none;align-items:stretch">%s%s%s%s</div>
""" % (head_block('How we got here', 'A short history', 'h1', False),
       tl('2019', 'Founded', 'Twelve families around one kitchen table.', 0),
       tl('2021', 'First grant', 'Funding for the library refurbishment.', 1),
       tl('2023', 'Hundred members', 'The association reached three figures.', 2),
       tl('2025', 'New wing', 'Ground broken on the science block.', 3, True)))

# A term the strand does not run in is not a column of the layout: it is the bar not
# being there. Drawing it as an empty flex cell put a quarter of the safe area of
# blank flow box on the page three times over. The start is the bar's own margin and
# the duration is its own width, so an idle term costs no box at all.
QUARTERS = 4

def pct(n, of):
    return round(n * 100 / of, 2)

def lane(name, start, span, g):
    # em, not cqw, for the inset between neighbouring terms: it scales with the type
    # and cannot freeze a box, which is what the sizing rule is protecting against.
    bar = ('<div style="margin-left:%s%%;width:calc(%s%% - .5em);background:var(--g%d);border-radius:999px"></div>'
           % (pct(start, QUARTERS), pct(span, QUARTERS), g))
    return ('<div style="display:flex;gap:1.4cqw;align-items:center">'
            '<div class="h3" style="flex:1;min-width:0">%s</div>'
            '<div style="flex:3;display:flex;align-items:stretch;height:1.6em">%s</div></div>' % (name, bar))

L['roadmap'] = ('background:var(--g3);color:var(--t3)', """
  %s
  <div style="display:flex;flex-direction:column;gap:1.8cqh;margin-top:3.4cqh;flex:none">
    <div style="display:flex;gap:1.4cqw"><div class="kicker" style="flex:1;opacity:.8">Strand</div><div data-peer-row="1" style="flex:3;display:flex">
      <div class="kicker" style="flex:1;opacity:.8">Autumn</div><div class="kicker" style="flex:1;opacity:.8">Spring</div>
      <div class="kicker" style="flex:1;opacity:.8">Summer</div><div class="kicker" style="flex:1;opacity:.8">Next year</div></div></div>
    %s%s%s
  </div>
""" % (head_block('The year ahead', 'What happens when', 'display'),
       lane('Library refit', 0, 2, 0),
       lane('Playground', 1, 2, 1),
       lane('Science block', 2, 2, 2)))

WEEKS = 6

def gantt_lane(task, owner, before, active, g, milestone=False):
    # Same rule as the roadmap: the weeks before a task starts are the bar's margin,
    # not a flow box. A spacer div holds no text, paints nothing and draws nothing.
    mark = ('<div class="dot" style="flex:none;width:1.15em;height:1.15em;background:var(--g%d);align-self:center;margin-left:auto"></div>' % g
            if milestone else '')
    return ('<div style="display:flex;gap:1.2cqw;align-items:center;padding:1.25cqh 0;border-top:1.4px solid color-mix(in srgb,currentColor 18%%,transparent)">'
            '<div style="flex:1.1;min-width:0"><div class="h3">%s</div><div class="cap soft" style="margin-top:.25cqh">%s</div></div>'
            '<div style="flex:3;display:flex;align-items:center;min-width:0;height:1.5em">'
            '<div style="margin-left:%s%%;width:calc(%s%% - .5em);height:1.15em;background:var(--g%d);border-radius:999px"></div>'
            '%s</div></div>' % (task, owner, pct(before, WEEKS), pct(active, WEEKS), g, mark))

L['gantt'] = ('', """
  %s
  <div style="margin-top:2.7cqh;flex:none">
    <div style="display:flex;gap:1.2cqw;align-items:flex-end;padding-bottom:.7cqh">
      <div class="kicker" style="flex:1.1;color:var(--ka)">Workstream</div><div data-peer-row="1" style="flex:3;display:flex">
        <div class="kicker" style="flex:1;color:var(--ka)">W1</div><div class="kicker" style="flex:1;color:var(--ka)">W2</div>
        <div class="kicker" style="flex:1;color:var(--ka)">W3</div><div class="kicker" style="flex:1;color:var(--ka)">W4</div>
        <div class="kicker" style="flex:1;color:var(--ka)">W5</div><div class="kicker" style="flex:1;color:var(--ka)">W6</div>
      </div>
    </div>
    %s%s%s%s
  </div>
  <div class="cap soft" style="margin-top:1.4cqh">Bars show scheduled work; the final dot marks the public launch.</div>
""" % (head_block('Delivery plan', 'Six-week event campaign', 'h1', False),
       gantt_lane('Listen &amp; scope', 'Family council', 0, 2, 0),
       gantt_lane('Book partners', 'Events lead', 1, 3, 1),
       gantt_lane('Create materials', 'Comms team', 2, 3, 2),
       gantt_lane('Open the doors', 'Whole team', 5, 1, 3, True)))

# ------------------------------------------------------------------ compared
L['comparison'] = ('', """
  %s
  <div data-peer-row="1" style="display:flex;gap:3.4cqw;margin-top:3.4cqh;flex:none;align-items:stretch;%s;padding-top:2.6cqh">
    <div style="flex:1"><div class="kicker" style="color:var(--ka)">Before</div>
      <div class="h2" style="margin-top:1cqh">Scattered understanding</div>
      <p class="body soft" style="margin-top:1.2cqh">The idea lives across documents, meetings, and individual memory.</p>
      <div style="display:flex;flex-direction:column;gap:.7cqh;margin-top:1.4cqh">
        <p class="body">Different definitions</p><p class="body">Slow decisions</p><p class="body">Repeated explanations</p></div></div>
    <div style="flex:1"><div class="kicker" style="color:var(--ka)">After</div>
      <div class="h2" style="margin-top:1cqh">Shared direction</div>
      <p class="body soft" style="margin-top:1.2cqh">One visual gives everyone the same frame for discussion and action.</p>
      <div style="display:flex;flex-direction:column;gap:.7cqh;margin-top:1.4cqh">
        <p class="body">Common language</p><p class="body">Faster alignment</p><p class="body">Clear next steps</p></div></div>
  </div>
""" % (head_block('Two ways of working', 'Before and after', 'h1', False), RULE))

def versus_side(lab, t, b, pts, g):
    lis = ''.join('<p class="body">%s</p>' % p for p in pts)
    return ('<div style="flex:1;display:flex;flex-direction:column;padding:3cqh 2.2cqw;'
            'background:var(--g%d);color:var(--t%d);border-radius:var(--r-lg)">'
            '<div class="kicker" style="opacity:.82">%s</div>'
            '<div class="h2" style="margin-top:1cqh">%s</div>'
            '<p class="body" style="margin-top:1.2cqh;opacity:.88">%s</p>'
            '<div style="display:flex;flex-direction:column;gap:.7cqh;margin-top:1.4cqh">%s</div></div>' % (g, g, lab, t, b, lis))

L['versus'] = ('', """
  %s
  <div data-peer-row="1" style="display:flex;gap:2cqw;margin-top:3.4cqh;flex:none;align-items:stretch">%s%s</div>
""" % (head_block('Two ways of working', 'Before and after', 'h1', False),
       versus_side('Before', 'Scattered understanding', 'The idea lives across documents and individual memory.',
                   ['Different definitions', 'Slow decisions', 'Repeated explanations'], 1),
       versus_side('After', 'Shared direction', 'One visual gives everyone the same frame for action.',
                   ['Common language', 'Faster alignment', 'Clear next steps'], 0)))

def proscons(lab, items, g, mark):
    rows = ''.join(
        '<div style="display:flex;gap:.9cqw;align-items:flex-start">'
        '<div class="tile" data-tile="1" style="--sz:2.4cqw;flex:none;background:var(--g%d);color:var(--t%d)">%s</div>'
        '<p class="body" style="flex:1;min-width:0">%s</p></div>' % (g, g, mark, i) for i in items)
    return ('<div style="flex:1"><div class="kicker" style="color:var(--ka)">%s</div>'
            '<div style="display:flex;flex-direction:column;gap:1.2cqh;margin-top:1.6cqh">%s</div></div>' % (lab, rows))

L['pros-cons'] = ('', """
  %s
  <div data-peer-row="1" style="display:flex;gap:3.4cqw;margin-top:3.4cqh;flex:none;align-items:stretch;%s;padding-top:2.6cqh">%s%s</div>
""" % (head_block('Weighing it up', 'What we gain, what it costs', 'h1', False), RULE,
       proscons('In favour', ['More families can attend.', 'Local partners share the workload.', 'Children see the community working together.'], 0,
                icon('check')),
       proscons('Against', ['A weekend event needs extra supervision.', 'Weather can disrupt the garden programme.', 'Volunteer capacity must be confirmed early.'], 1,
                '<svg viewBox="0 0 24 24"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>')))

# ------------------------------------------------------------------ people & imagery
def person(n, r):
    return ('<div data-device="team" style="flex:1;display:flex;flex-direction:column;gap:1.2cqh">'
            '<div data-photocell="1" style="width:100%%;aspect-ratio:1;background:var(--ph);border-radius:var(--r-lg);overflow:hidden"></div>'
            '<div><div class="h3">%s</div><div class="cap soft" style="margin-top:.4cqh">%s</div></div></div>' % (n, r))

L['team'] = ('', """
  %s
  <div data-peer-row="1" style="display:flex;gap:2cqw;margin-top:3.4cqh;flex:none;align-items:stretch">%s%s%s%s</div>
""" % (head_block('The people', 'Meet the team', 'h1', False),
       person('Mr. A. Reyes', 'Head teacher'), person('Ms. J. Okafor', 'Deputy head'),
       person('Ms. L. Park', 'Year lead'), person('Mr. D. Cohen', 'PTA chair')))

L['image-left'] = ('background:var(--g0);color:var(--t0)', """
  <div style="%s;flex-direction:row;gap:3.4cqw;align-items:stretch">
    <div data-photocell="1" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-lg);overflow:hidden"></div>
    <div style="flex:1.15;display:flex;flex-direction:column;justify-content:center">
      <div class="kicker" style="opacity:.84">Garden project</div>
      <h1 class="h1" style="margin-top:1.1cqh">A neglected corner becomes an outdoor classroom</h1>
      <p class="body" style="margin-top:1.6cqh;opacity:.9">Families cleared the beds, local growers donated seedlings, and pupils now use the space for weekly science sessions.</p>
    </div>
  </div>
""" % GROW)

L['image-right'] = ('background:var(--g3);color:var(--t3)', """
  <div style="%s;flex-direction:row;gap:3.4cqw;align-items:stretch">
    <div style="flex:1.15;display:flex;flex-direction:column;justify-content:center">
      <div class="kicker" style="opacity:.84">A closer look</div>
      <h1 class="h1" style="margin-top:1.1cqh">The workshop in action</h1>
      <p class="body" style="margin-top:1.6cqh;opacity:.9">Mixed-age tables sketch a safer route to school, compare priorities, and agree on the first corner to improve.</p>
      <div class="cap" style="margin-top:1.4cqh;opacity:.76">Family design workshop · Spring term</div>
    </div>
    <div data-photocell="1" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-lg);overflow:hidden"></div>
  </div>
""" % GROW)

L['image-grid'] = ('background:var(--g0);color:var(--t0)', """
  <div style="%(GROW)s;flex-direction:row;gap:4cqw;align-items:stretch">
    <div style="flex:.9;display:flex;flex-direction:column;justify-content:center">
      <div class="kicker" style="opacity:.82">Around school</div>
      <h1 class="h1" style="margin-top:1.1cqh">Activities &amp;<br>clubs</h1>
      <p class="body" style="margin-top:1.4cqh;opacity:.86">Four weekly clubs led by staff, families, and local partners.</p>
    </div>
    <div style="flex:1.1;min-height:0;display:flex;flex-direction:column;gap:1.6cqh">
      <div data-peer-row="image" style="flex:1;min-height:0;display:flex;gap:1.6cqw">
        <div data-photocell="1" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-md);overflow:hidden"></div>
        <div data-photocell="1" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-md);overflow:hidden"></div>
      </div>
      <div data-peer-row="image" style="flex:1;min-height:0;display:flex;gap:1.6cqw">
        <div data-photocell="1" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-md);overflow:hidden"></div>
        <div data-photocell="1" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-md);overflow:hidden"></div>
      </div>
    </div>
  </div>
""" % globals())

L['photo-story'] = ('background:var(--g0);color:var(--t0)', """
  %s
  <div data-peer-row="1" style="%s;flex-direction:row;gap:2cqw;margin-top:2.8cqh;align-items:stretch">
    <div style="flex:1;min-height:0;display:flex;flex-direction:column"><div data-photocell="1" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-lg);overflow:hidden"></div><div class="h3" style="margin-top:1.1cqh">1 · The doors open</div><p class="cap" style="margin-top:.35cqh;opacity:.8">Families arrive and choose a table.</p></div>
    <div style="flex:1;min-height:0;display:flex;flex-direction:column"><div data-photocell="1" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-lg);overflow:hidden"></div><div class="h3" style="margin-top:1.1cqh">2 · Ideas take shape</div><p class="cap" style="margin-top:.35cqh;opacity:.8">Small groups turn needs into proposals.</p></div>
    <div style="flex:1;min-height:0;display:flex;flex-direction:column"><div data-photocell="1" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-lg);overflow:hidden"></div><div class="h3" style="margin-top:1.1cqh">3 · A shared choice</div><p class="cap" style="margin-top:.35cqh;opacity:.8">The room agrees on one action to test.</p></div>
  </div>
""" % (head_block('Event recap', 'One afternoon, three moments', 'h1'), GROW))

L['image-hero'] = ('background:var(--g1);color:var(--t1)', """
  <div style="%s">
    <div data-photocell="1" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-lg);overflow:hidden"></div>
    <div style="flex:none;margin-top:2.4cqh">
      <h1 class="h1">The whole playground becomes a stage</h1>
      <p class="body" style="margin-top:1cqh;opacity:.9">Student performances close Community Day in front of families and neighbours.</p>
    </div>
  </div>
""" % GROW)

# ------------------------------------------------------------------ structure
def flow_node(t, g, last=False):
    arrow = ('' if last else
             '<div data-connector="1" style="flex:none;display:flex;align-items:center;color:currentColor;opacity:.45">'
             '<svg viewBox="0 0 100 100" style="width:1.6em;height:1.6em"><polygon points="20,12 46,50 20,88 36,88 62,50 36,12" fill="currentColor"/></svg></div>')
    return ('<div style="flex:1;display:flex;flex-direction:column;justify-content:center;padding:2.4cqh 1.4cqw;'
            'background:var(--g%d);color:var(--t%d);border-radius:var(--r-lg);text-align:center">'
            '<div class="h3">%s</div></div>%s' % (g, g, t, arrow))

L['flow-diagram'] = ('', """
  %s
  <div style="%s;margin-top:3cqh">
    <div data-peer-row="1" style="flex:none;display:flex;gap:1.2cqw;align-items:stretch">%s%s%s%s</div>
    <p class="cap soft" style="margin-top:2cqh">Each approved proposal leaves the meeting with a named owner and review date.</p>
  </div>
""" % (head_block('How it works', 'From idea to assembly', 'h1', False), GROW,
       flow_node('Idea', 0), flow_node('Proposal', 1), flow_node('Vote', 2), flow_node('Action', 3, True)))

def arch_module(t, b):
    return ('<div class="card" style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:1.1cqh 1.1cqw;text-align:center">'
            '<div class="h3">%s</div><div class="cap soft" style="margin-top:.35cqh">%s</div></div>' % (t, b))

def arch_layer(lab, modules, g):
    return ('<div data-peer-row="1" style="flex:none;min-height:0;display:flex;gap:1.4cqw;align-items:stretch">'
            '<div class="kicker" style="flex:.55;display:flex;align-items:center;justify-content:center;padding:1.2cqh 1.1cqw;background:var(--g%d);color:var(--t%d);border-radius:var(--r-lg);text-align:center">%s</div>'
            '<div data-peer-row="1" style="flex:3;display:flex;gap:1cqw;align-items:stretch">%s</div></div>'
            % (g, g, lab, ''.join(arch_module(*m) for m in modules)))

L['architecture'] = ('background:var(--g3);color:var(--t3)', """
  %s
  <div style="flex:none;min-height:0;display:flex;flex-direction:column;justify-content:center;gap:.8cqh;margin-top:2cqh">
    %s
    <div class="cap" style="text-align:center;opacity:.68">requests and updates move through shared services</div>
    %s
    <div class="cap" style="text-align:center;opacity:.68">identity and data remain common foundations</div>
    %s
  </div>
""" % (head_block('System view', 'How the community platform is layered', 'h1'),
       arch_layer('Experience', [('Family portal', 'sign-up · updates · consent'), ('Teacher console', 'rosters · messages · support'), ('Event display', 'schedule · rooms · notices')], 0),
       arch_layer('Services', [('Membership', 'profiles and roles'), ('Calendar', 'events and reminders'), ('Messages', 'email and in-app')], 1),
       arch_layer('Foundation', [('Identity &amp; permissions', 'access and consent'), ('Shared programme data', 'members · events · outcomes')], 2)))

def mind_node(t, b, g):
    return ('<div style="align-self:flex-start;max-width:100%%;padding:1.5cqh 1.2cqw;background:var(--g%d);color:var(--t%d);border-radius:var(--r-lg)">'
            '<div class="h3">%s</div><div class="cap" style="margin-top:.35cqh;opacity:.82">%s</div></div>' % (g, g, t, b))

L['mind-map'] = ('', """
  %s
  <div style="%s;flex-direction:row;gap:1.4cqw;margin-top:2.8cqh;align-items:stretch">
    <div style="flex:1;display:flex;flex-direction:column;justify-content:center;gap:1.3cqh">
      %s%s%s
    </div>
    <div data-connector="1" style="flex:.16;background:linear-gradient(to right,transparent 0,color-mix(in srgb,currentColor 24%%,transparent) 45%%,color-mix(in srgb,currentColor 24%%,transparent) 55%%,transparent 100%%) center/100%% 1px no-repeat"></div>
    <div style="flex:.85;display:flex;align-items:center"><div class="card" style="flex:1;padding:3cqh 1.8cqw;text-align:center;box-shadow:0 0 0 1.4px color-mix(in srgb,currentColor 18%%,transparent)"><div class="kicker" style="color:var(--ka)">Shared question</div><div class="h2" style="margin-top:.8cqh">How might every family belong?</div></div></div>
    <div data-connector="1" style="flex:.16;background:linear-gradient(to right,transparent 0,color-mix(in srgb,currentColor 24%%,transparent) 45%%,color-mix(in srgb,currentColor 24%%,transparent) 55%%,transparent 100%%) center/100%% 1px no-repeat"></div>
    <div style="flex:1;display:flex;flex-direction:column;justify-content:center;gap:1.3cqh">
      %s%s%s
    </div>
  </div>
""" % (head_block('Idea map', 'Six branches around one question', 'h1', False), GROW,
       mind_node('Access', 'time · language · transport', 0),
       mind_node('Trust', 'listen · explain · close the loop', 1),
       mind_node('Welcome', 'names · faces · first steps', 2),
       mind_node('Voice', 'surveys · circles · open floor', 3),
       mind_node('Action', 'owners · dates · visible progress', 0),
       mind_node('Learning', 'review · adapt · share back', 1)))

L['case-study'] = ('background:var(--g0);color:var(--t0)', """
  %s
  <div data-peer-row="1" style="display:flex;gap:2cqw;margin-top:3cqh;flex:none;align-items:stretch">
    <div class="card" style="flex:1.2;display:flex;flex-direction:column;padding:2.6cqh 1.8cqw">
      <div class="kicker" style="color:var(--ka)">Challenge</div><div class="h2" style="margin-top:.8cqh">The same small group attended every event.</div>
      <div style="%s;margin-top:1.5cqh;padding-top:1.4cqh"><div class="kicker" style="color:var(--ka)">What changed</div><p class="body soft" style="margin-top:.7cqh">The team added translated invitations, two start times, and a named welcome host at the door.</p></div>
    </div>
    <div class="card" style="flex:1;display:flex;flex-direction:column;padding:2.6cqh 1.8cqw">
      <div class="kicker" style="color:var(--ka)">Outcome after one term</div><div class="stat" style="margin-top:1cqh">+64%%</div><div class="h3" style="margin-top:.6cqh">first-time attendance</div>
    </div>
  </div>
""" % (head_block('Case study', 'A more welcoming family forum', 'h1'), RULE))

# ------------------------------------------------------------------ community programmes
def schedule_row(time, title, detail, last=False):
    rule = '' if last else ';padding-bottom:1.35cqh;border-bottom:1.4px solid color-mix(in srgb,currentColor 22%,transparent)'
    return ('<div style="display:flex;gap:1.5cqw;align-items:baseline%s">'
            '<div class="h3" style="flex:.55;font-variant-numeric:tabular-nums">%s</div>'
            '<div class="h3" style="flex:1.7;min-width:0">%s</div>'
            '<div class="body" style="flex:1.2;min-width:0;opacity:.82">%s</div></div>' % (rule, time, title, detail))

L['event-schedule'] = ('background:var(--g1);color:var(--t1)', """
  %s
  <div style="display:flex;gap:1.5cqw;margin-top:2.4cqh;flex:none;opacity:.72">
    <div class="kicker" style="flex:.55">Time</div><div class="kicker" style="flex:1.7">Activity</div><div class="kicker" style="flex:1.2">Place · lead</div>
  </div>
  <div style="display:flex;flex-direction:column;gap:1.35cqh;margin-top:1.1cqh;flex:none">
    %s%s%s%s%s
  </div>
""" % (head_block('Community day', 'Saturday run of show', 'h1', sub='18 May · school hall and garden'),
       schedule_row('09:30', 'Doors &amp; welcome table', 'Main hall · Amina'),
       schedule_row('10:00', 'Family maker workshop', 'Art room · Jo'),
       schedule_row('11:15', 'Garden lunch', 'Courtyard · PTA'),
       schedule_row('12:30', 'Student performances', 'Main stage · Luis'),
       schedule_row('14:00', 'Closing circle', 'Garden · Priya', True)))

L['fundraising-progress'] = ('background:var(--g3);color:var(--t3)', """
  <div style="%(GROW)s;flex-direction:row;gap:4cqw;align-items:stretch">
    <div style="flex:1.2;display:flex;flex-direction:column;justify-content:center">
      <div class="kicker" style="opacity:.82">Library appeal</div>
      <div class="display" style="margin-top:1.1cqh">£18,240</div>
      <div class="h3" style="margin-top:.7cqh">of £25,000 raised</div>
      <div data-device="fundraising-progress" style="margin-top:2cqh;height:1.25em;background:color-mix(in srgb,currentColor 18%%,transparent);border-radius:999px;overflow:hidden"><div style="width:73%%;height:100%%;background:var(--g2);border-radius:inherit"></div></div>
      <div class="cap" style="margin-top:.8cqh;opacity:.78">73%% complete · 312 family donors</div>
    </div>
    <div style="flex:1;display:flex;flex-direction:column;justify-content:center;gap:1.5cqh">
      <div class="kicker" style="opacity:.82">What the goal unlocks</div>
      <div style="%(RULE)s;padding-top:1.3cqh"><div class="h3">New reading corners</div><div class="cap" style="margin-top:.35cqh;opacity:.78">£11,000 · furniture and lighting</div></div>
      <div style="%(RULE)s;padding-top:1.3cqh"><div class="h3">Classroom book sets</div><div class="cap" style="margin-top:.35cqh;opacity:.78">£9,000 · six year groups</div></div>
      <div style="%(RULE)s;padding-top:1.3cqh"><div class="h3">Author workshops</div><div class="cap" style="margin-top:.35cqh;opacity:.78">£5,000 · four visiting writers</div></div>
    </div>
  </div>
""" % globals())

# ------------------------------------------------------------------ offers
def price(lab, amount, note, items):
    # the deck shell pins [data-device=price] to --surface/--ink with !important;
    # emphasis therefore has to come from the label, not from the card's ground.
    lis = ''.join('<p class="body" style="opacity:.9">%s</p>' % i for i in items)
    return ('<div data-device="price" style="flex:1;display:flex;flex-direction:column;padding:3cqh 1.8cqw;'
            'border-radius:var(--r-lg)">'
            '<div class="kicker" style="color:var(--ka)">%s</div>'
            '<div class="stat" style="margin-top:1cqh">%s</div>'
            '<div class="cap" style="margin-top:.6cqh;opacity:.82">%s</div>'
            '<div style="display:flex;flex-direction:column;gap:.7cqh;margin-top:1.8cqh">%s</div></div>'
            % (lab, amount, note, lis))

L['price-tiers'] = ('background:var(--g1);color:var(--t1)', """
  %s
  <div data-peer-row="1" style="display:flex;gap:2cqw;margin-top:3.4cqh;flex:none;align-items:stretch">%s%s%s</div>
""" % (head_block('Get involved', 'PTA membership', 'display'),
       price('Friend', '£10', 'per year', ['Newsletter', 'Termly events']),
       price('Supporter', '£25', 'per year', ['Everything in Friend', 'Priority tickets']),
       price('Champion', '£50', 'per year', ['Everything in Supporter', 'Named in the report'])))

def check_row(t, b, g, last=False):
    rule = '' if last else ';padding-bottom:1.6cqh;border-bottom:1.4px solid color-mix(in srgb,currentColor 22%,transparent)'
    return ('<div style="display:flex;gap:1.2cqw;align-items:flex-start%s">'
            '<div class="tile" data-tile="1" style="--sz:3cqw;flex:none;background:var(--g%d);color:var(--t%d)">%s</div>'
            '<div style="flex:1;min-width:0"><div class="h3">%s</div>'
            '<p class="body" style="margin-top:.5cqh;opacity:.86">%s</p></div></div>' % (rule, g, g, icon('check'), t, b))

L['checklist'] = ('background:var(--g3);color:var(--t3)', """
  %s
  <div style="display:flex;flex-direction:column;gap:1.6cqh;margin-top:3.4cqh;flex:none">%s%s%s%s</div>
""" % (head_block('Before the first day', 'What to bring', 'display'),
       *[check_row(t, b, g, last) for (t, b, last), g in zip([
           ('Uniform', 'Two sets, labelled with your child’s name.', False),
           ('Water bottle', 'Named, refillable, no glass.', False),
           ('Reading record', 'Sent home in the first week.', False),
           ('Consent forms', 'Returned before the first trip.', True)], grounds(3, 4))]))


def emit(name, stage_style, body):
    st = ' style="%s"' % stage_style if stage_style else ''
    html = HEAD.replace('@@NAME@@',name)
    html += '<div class="deck"><div class="slide"><div class="stage" data-slot="%s"%s>\n' % (name, st)
    html += '<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;%s">\n' % FIT
    html += body.rstrip() + '\n'
    html += '</div>\n<div class="pagenum">page 01</div>\n</div></div></div>\n</body></html>\n'
    open(os.path.join(OUT, name + '.html'), 'w').write(html)


if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    open(os.path.join(OUT, '_shell.html'), 'w').write(HEAD.replace('@@NAME@@','shell'))
    for n, (s, b) in L.items():
        emit(n, s, b)
    print('wrote %d layouts' % len(L))
    print(' '.join(sorted(L)))
