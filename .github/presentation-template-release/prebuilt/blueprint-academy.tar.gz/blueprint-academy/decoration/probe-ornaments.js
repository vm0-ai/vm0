// blueprint-academy ornament + identity probe.
//
// The template-local ../tools/audit.js ornament group does not describe this template:
// its big-ornament selector does not include data-doodle, and its shape test knows
// bloom's four-rect flower and one-path petal, not a wireframe globe. See PLACEMENT.md.
//
// This classifies by geometry actually drawn here:
//   wire-globe      >=5 <line> and >=2 <ellipse>
//   link-circles    exactly 3 <circle>, no <line>
//   four-point-star exactly 1 <path>, nothing else
//   grid-paper      a repeating-linear-gradient background, no svg
//
// Every figure in PLACEMENT.md came from this file, run at 1600x900 on
// ../layouts/.
(() => {
  const classify = (el) => {
    const svg = el.querySelector('svg');
    if (!svg) {
      const bi = getComputedStyle(el).backgroundImage || '';
      if (/repeating-linear-gradient/.test(bi)) return 'grid-paper';
      return null;
    }
    const c = svg.querySelectorAll('circle').length;
    const e = svg.querySelectorAll('ellipse').length;
    const l = svg.querySelectorAll('line').length;
    const p = svg.querySelectorAll('path').length;
    if (l >= 5 && e >= 2) return 'wire-globe';
    if (c === 3 && l === 0) return 'link-circles';
    if (p === 1 && c === 0 && e === 0 && l === 0) return 'four-point-star';
    if (p >= 1 && c === 0) return 'icon';
    return 'UNKNOWN:c' + c + 'e' + e + 'l' + l + 'p' + p;
  };

  const R = { pages: 0, byName: {}, perPage: {}, large: [], bleed: {}, starsPerPage: [],
              mattedPhotos: 0, mattedPairs: 0, badges: 0, nodes: 0, connectors: 0,
              statUnderlines: 0, titleFlourishes: 0, unknown: [], fullBleed: 0,
              radiusUses: [], surfaceUses: 0, g2BoxesOnPage: 0, inkPanels: [] };

  document.querySelectorAll('.slide .stage, .stage').forEach((st, pi) => {
    R.pages++;
    const sr = st.getBoundingClientRect();
    const sbg = getComputedStyle(st).backgroundColor;
    const isField = st.getAttribute('style') && /background:var\(--g/.test(st.getAttribute('style'));
    if (isField) R.fullBleed++;
    let stars = 0;
    const seen = new Set();

    st.querySelectorAll('[data-doodle],[data-deco]').forEach(el => {
      if (seen.has(el)) return; seen.add(el);
      const name = classify(el);
      if (!name) return;
      if (name.startsWith('UNKNOWN')) { R.unknown.push(`p${pi + 1} ${name}`); return; }
      R.byName[name] = (R.byName[name] || 0) + 1;
      (R.perPage[name] = R.perPage[name] || {})[pi + 1] = ((R.perPage[name] || {})[pi + 1] || 0) + 1;
      if (name === 'four-point-star') stars++;
      const r = el.getBoundingClientRect();
      const wPct = r.width / sr.width * 100;
      if (name === 'wire-globe' || name === 'link-circles') {
        const out = r.left < sr.left - 1 || r.right > sr.right + 1 || r.top < sr.top - 1 || r.bottom > sr.bottom + 1;
        let over = 0;
        if (r.bottom > sr.bottom) over = (r.bottom - sr.bottom) / r.height;
        if (r.top < sr.top) over = Math.max(over, (sr.top - r.top) / r.height);
        if (r.left < sr.left) over = Math.max(over, (sr.left - r.left) / r.width);
        if (r.right > sr.right) over = Math.max(over, (r.right - sr.right) / r.width);
        R.large.push({ p: pi + 1, name, wPct: +wPct.toFixed(1), bleeds: out, overFrac: +over.toFixed(2),
                       opacity: +getComputedStyle(el).opacity });
        R.bleed[name] = R.bleed[name] || { yes: 0, no: 0 };
        out ? R.bleed[name].yes++ : R.bleed[name].no++;
      }
    });
    R.starsPerPage.push(stars);

    // matted photos: the double-frame mount (has box-shadow + border, contains a photocell)
    const mats = [...st.querySelectorAll('div')].filter(d => {
      const cs = getComputedStyle(d);
      return cs.boxShadow !== 'none' && d.querySelector('[data-photocell]');
    });
    R.mattedPhotos += mats.length;
    if (mats.length >= 2) R.mattedPairs++;

    R.badges += st.querySelectorAll('[data-badge]').length;
    R.nodes += st.querySelectorAll('[data-node]').length;
    R.connectors += st.querySelectorAll('[data-connector]').length;

    // stat underline: short solid bar, no text
    R.statUnderlines += [...st.querySelectorAll('div')].filter(d => {
      if (d.textContent.trim()) return false;
      const r = d.getBoundingClientRect();
      return r.height > 1 && r.height < 8 && r.width > 20 && r.width < 120;
    }).length;

    // title flourish: a 1px hairline span inline in a heading row
    R.titleFlourishes += [...st.querySelectorAll('span')].filter(s => {
      const r = s.getBoundingClientRect();
      return !s.textContent.trim() && Math.round(r.height) === 1 && r.width > 20;
    }).length;

    // colour traps
    [...st.querySelectorAll('*')].forEach(el => {
      const cs = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      if (r.width < sr.width * 0.08 || r.height < sr.height * 0.06) return;
      if (el === st) return;
      const bg = cs.backgroundColor;
      if (bg === 'rgb(228, 223, 208)' && !isField) R.g2BoxesOnPage++;   // --g2 box on the page
      if (bg === 'rgb(30, 43, 34)') R.inkPanels.push({ p: pi + 1, wPct: +(r.width / sr.width * 100).toFixed(1),
                                                        hPct: +(r.height / sr.height * 100).toFixed(1) });
    });
  });

  const html = document.documentElement.outerHTML;
  R.surfaceUses = (html.match(/var\(--surface\)/g) || []).length;
  // written border-radius in slide markup (not the :root token block)
  const bodyHtml = html.slice(html.indexOf('<body'));
  R.radiusUses = (bodyHtml.match(/border-radius:\s*[^;"']+/g) || []);
  R.starsPerPageAvg = +(R.starsPerPage.reduce((a, b) => a + b, 0) / R.pages).toFixed(2);
  R.pagesWithZeroStars = R.starsPerPage.filter(s => s === 0).length;
  return JSON.stringify(R, null, 1);
})()
