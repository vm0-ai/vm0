# blueprint-academy — decoration placement

Everything here is measured from the original reference deck (15 pages, 71 decoration
elements) at 1600×900. Numbers, not taste.

Open `decoration.html` to see each ornament rendered with no text on the page, and
`item-sets.html` for the ornaments that attach to repeated items.

## The headline number, and it is not bloom's

**This template puts its two large emblems on five pages and on no others.**

| | pages | wire-globe | link-circles |
|---|---|---|---|
| cover, 3 section dividers, closing | 1, 3, 7, 11, 15 | 1 each — 5 of 5 | 1 each — 5 of 5 |
| every content page | 2, 4, 5, 6, 8, 9, 10, 12, 13, 14 | **0 of 10** | **0 of 10** |

If you have read bloom's `PLACEMENT.md`, note that this is the opposite rule. bloom
puts a pair of big ornaments on *every content page* and its gap was that generated
decks only drew one. Here a big ornament on a content page is the defect. A
blueprint-academy content page is carried by the grid, the stars, and — when the
material supports one — a matted photograph.

## The layer model

| z-index | layer | where it comes from |
|---|---|---|
| 0 | `grid-paper` | this folder, first child of every `.stage` |
| 1 | `wire-globe` | this folder, emblem pages only |
| 2 | `matted-photo` | content, when the material supports it |
| 3 | `four-point-star`, `link-circles` | this folder |
| 5 | persistent chrome | fixed, see A below |
| 40 | `.fit` — all text | `../layouts/*.html` |
| 45 | `pagenum` | the shell |

Decoration is never inside `.fit`. If a layout and an ornament collide, move the
ornament — never the copy.

## A · Persistent chrome — identical on every page

Four items. All four, on every slide, or the deck is incomplete. The top two sit in
the band the content is forbidden to enter (see D0).

```html
<div class="kicker" style="position:absolute;left:6cqw;top:5cqh;opacity:.6;z-index:5">Your Academy</div>
<div class="kicker" style="position:absolute;right:6cqw;top:5cqh;opacity:.6;z-index:5">Section Name</div>
<div style="position:absolute;left:6cqw;bottom:4.4cqh;z-index:5;display:inline-flex;align-items:center;gap:.8cqw;
            border:1px solid color-mix(in srgb,currentColor 32%,transparent);border-radius:var(--r-pill);padding:.7cqh 1.3cqw">
  <span data-doodle="1" style="width:1.1cqw;height:1.1cqw;display:inline-block"><svg viewBox="0 0 100 100" style="width:100%;height:100%"><path d="M50 3 Q65 35 97 50 Q65 65 50 97 Q35 65 3 50 Q35 35 50 3 Z" fill="currentColor"/></svg></span>
  <span class="kicker" style="opacity:.85">Academy</span>
  <span data-doodle="1" style="width:1.1cqw;height:1.1cqw;display:inline-block"><svg viewBox="0 0 100 100" style="width:100%;height:100%"><path d="M50 3 Q65 35 97 50 Q65 65 50 97 Q35 65 3 50 Q35 35 50 3 Z" fill="currentColor"/></svg></span>
</div>
<div class="pagenum">page 04</div>
```

Note the ruled label carries two stars, and those two are part of its 3.13-per-page
star count. `design-system.md` calls this label square-cornered; the shipped
`example/reference.jpg` renders it as a rounded pill and the original reference deck writes
`border-radius:999px`. See `../layouts/README.md` — that disagreement is not settled
here, and the token `--r-pill` is what to change if it gets settled.

## B · Vocabulary — 5 ornaments, nothing else

| name | marker | what it is | reference count |
|---|---|---|---|
| `grid-paper` | `data-doodle` | full-stage 5.2cqw × 5.2cqh ruled grid, `opacity:.07` | 15 of 15 pages |
| `wire-globe` | `data-doodle` | outlined sphere: 1 circle, 3 ellipses, 7 chords | 5 |
| `link-circles` | `data-doodle` | 3 overlapping outlined rings, star tucked under | 5 |
| `four-point-star` | `data-doodle` | one `<path>` diamond, filled | 47 |
| `matted-photo` | `data-photocell` | `--bg` mount, hairline, inner hairline, image | 12 |

Do not invent squares, blobs, arcs, quarter-circles or colour blocks. The two
outlined emblems are the only large shapes this template draws.

**Marker convention: everything decorative is `data-doodle`,** which is what the
reference writes and therefore what generated decks write.

One consequence, so nobody reads the ornament numbers wrongly. The template-local
`../tools/audit.js` ornament group — `bigOrnaments`, `bigPerPage`,
`pagesWithPair`, `bleedingPct`, `offVocabularyShapes` — **is not interpretable on this
template**, in either direction:

- `data-doodle` is not in its big-ornament selector, so it falls back to counting every
  wrapper that holds an `<svg>` and no text. On the reference that returns 23 "big
  ornaments" for 15 pages, which is really 5 globes + 5 ring-sets + 13 stars, and
  `bleedingPct` 0.217 because only the globes bleed. The number is a mixture of three
  things of different sizes.
- Re-tagging the emblems `data-deco` fixes those counts and breaks another: its shape
  test recognises bloom's vocabulary — four `<rect>`s, or a single `<path>` — so
  blueprint-academy's globe (1 circle, 3 ellipses, 7 lines) and rings (3 circles,
  1 path) come back as 4 off-vocabulary shapes. Measured both ways: `data-doodle` gives
  offVocabularyShapes 0, `data-deco` gives 4. Neither reading means anything.

Use [probe-ornaments.js](probe-ornaments.js) instead. It classifies by this template's
actual geometry and produced every number on this page. Run it the same way as the
template-local probe:

```
agent-browser eval -b "$(base64 -w0 blueprint-academy/decoration/probe-ornaments.js)"
```

## C · Where the two emblems go — measured, and it is not "hang it off the edge"

| | wire-globe | link-circles |
|---|---|---|
| width | 32–34 cqw | 16 cqw |
| opacity | 0.50–0.55 | 0.60 |
| z-index | 1 | 3 |
| bleeds off the stage | **5 of 5** | **0 of 5** |
| how far past the edge | 0.13–0.18 × its own height | — |

Two separate rules, and they pull in opposite directions:

- **the globe always bleeds, and only just.** 0.13–0.18 of itself, always at the
  bottom: `bottom:-8cqh` to `bottom:-14cqh`. bloom's globes hang out by 0.27–0.83;
  copying that number here buries a third of the sphere and it stops reading as one.
- **link-circles never bleed.** All five sit fully inside, high on the page
  (`top:5cqh`–`10cqh`), acting as a section mark above or beside the title.

Which side: every emblem page, including the cover, puts the globe on the right
(`right:6cqw`). Keep the cover's main copy on the left.

## D · The stars are the rule that will die if I do not state it

`four-point-star`: **47 across 15 pages, 3.13 per page, range 2–4, and not one page
has zero.**

bloom learned this the expensive way — it gave its big ornaments a number and left
the small ones as a vocabulary list, and over the next 18 decks small ornaments fell
from 0.214 per page to 0.022 (p=0.0043). What is not stated as a number does not
survive. So, stated as numbers:

| where the stars actually are | count |
|---|---|
| two inside the bottom-left ruled chrome label | 2 per page, every page |
| a title flourish — a 1px hairline then a star, inline in the heading | 8 across the deck |
| loose in a margin on emblem pages, 2.4–3.4cqw, `opacity:.7–.9` | 2 on each of pages 3, 7, 11 |
| flanking a centred title, star–rule–title–rule–star | pages 6, 8, 13 |

So a content page's two stars are usually *just the chrome label's two*. That is the
floor, and it is why no page reads zero. Adding loose stars to a content page is not
required and past four the page starts to look sprinkled.

## E · Item sets — every item, or none

Three devices, each the signature of exactly one page type. On those pages **every
item in the set carries one**; the reference never gives them to some items and not
others.

| the items are | ornament | reference | size | colour |
|---|---|---|---|---|
| numbered points | `badge` | 3 of 3 on page 5 | `--sz:3.4em` | grounds cycle `--g0 --g1 --g2`, figure in the matching `--t?` |
| ordered stages | `node` + one `connector` | 3 of 3 on page 9 | `--sz:4em` circle | `--ink` ground, `--bg` mark; connector a `.55cqh` hairline at `z-index:0` |
| statistics | `--s1` underline | 4 of 4 on page 12 | `.18em` tall, `3em` long | `--s1` as a **fill** |

See [item-sets.html](item-sets.html) for all three as copyable markup.

`--ink` grounds the three `node` circles and nothing else larger. bloom hit a
generated deck that put seven `--ink` discs in a row and it read as a bar of black
holes — keep a node row to 3–5.

## F · Colour, measured against this page

`--bg` is `#F7F6F1`. Contrast of every token against it:

| token | ratio | use as |
|---|---|---|
| `--ink` `--s3` `--k1` `--g3` 13.63 · `--soft` 6.50 · `--ka` `--accent` `--g0` 4.72 · `--g1` 4.36 | pass | text or fill |
| `--s1` 3.03 | marginal | **fill only** |
| `--s2` 1.23 · `--g2` 1.23 · `--ph` 1.14 · `--surface` 1.08 | fail | **fill only** |

Four consequences, each measured:

- **`--s1` is a fill, never type.** 3.03:1 clears a 3.0 gate by a hundredth, which
  is exactly why a contrast probe will not catch it, and `design-system.md` already
  reserves the source hues for decoration. The reference used it as text on five
  agenda numbers; that is fixed. Its correct job is the statistic underline.
- **`--surface` is unusable.** `#FFFFFF` on `#F7F6F1` is 1.08:1. The reference uses
  it **zero times** in 15 pages. A panel of prose takes no fill and a hairline
  instead.
- **`--g2` needs its border.** At 1.23:1 against the page a `--g2` card has no edge
  at all. Keep the `.rule-card` hairline on it. The reference ships one borderless
  `--g2` card (page 13), so this is a stated preference and not a gate.
- **No large `--ink` or `--g3` panel.** The reference has **zero** filled boxes over
  8%×6% of the stage with luminance under 0.09. A dark slab that size reads as a
  photo placeholder, which is the mistake bloom made twice.

On a full-bleed divider, `--ka` measures **2.89:1** against `--g3`. A kicker there
takes `color:inherit;opacity:.85`, never the accent token.

## G · Full-bleed pages

3 of 15 — pages 3, 7 and 11, every one a section divider, `--g0` or `--g3` on
`.stage` itself. That is the whole of this template's colour-field rhythm; there is
no full-bleed content page and no full-bleed closing page.

**Nothing sits on a full-bleed page.** Measured: 0 filled boxes on all three. The
content goes straight onto the ground.

## H · The lower third is the globe's, on emblem pages only

On pages 1, 3, 7, 11 and 15 the bottom of the stage holds a 32–34cqw sphere. The
`cover` and `close` layouts therefore keep their content in the upper band and do
**not** centre it vertically, and do not use `margin-top:auto` to push a trailing
line down — that drops it straight onto the globe.

Before deciding one of those layouts looks empty, open `decoration.html`, overlay the
pair, and look again. bloom "fixed" two layouts for emptiness and had to revert both.

**The cover globe stays clear of the copy.** The source reference placed it left of
centre and let it pass behind the display title; the live template intentionally
moves it to the bottom-right so it does not cross the title, subtitle, body copy,
caption, or label.

On the ten content pages the lower third is not reserved. It is simply where a
matted photograph goes when the material supports one.

## I · Photographs are content

`matted-photo` is 12 of the reference's 71 decoration elements, and 3 pages carry two
at different sizes overlapping — that is the house arrangement when there are two.
Every one is double-framed and square, and the mount is the only shadow in this
template.

When the source material supports no photograph, **delete the frame**. Do not leave
an empty mount, and do not substitute a grid of grey rectangles. the original reference deck has
a rule for exactly this case:

```css
.stage:not(:has([data-photocell])) .fit > div{width:auto;max-width:86cqw;}
```

The naked layouts in `../layouts/` do not need it — none of them pins a column
width in the first place.

## Verifying your own deck

```
grid-paper per page                reference 1.00   (every page, no exceptions)
four-point-star per page           reference 3.13   range 2-4, zero pages at 0
pages with zero stars              reference 0
wire-globe, emblem pages           reference 5 of 5
wire-globe, content pages          reference 0 of 10
globe bleed, fraction of itself    reference 0.13-0.18
link-circles that bleed            reference 0 of 5
uses of --surface                  reference 0
large --ink / --g3 panels          reference 0
filled boxes on a full-bleed page  reference 0
full-bleed pages                   reference 3 of 15 (20%), all section dividers
```
