# blueprint-academy — naked layouts

36 layouts, text only. No decoration, no chrome, no colour decisions, no measured
geometry. Pair one of these with `../decoration/PLACEMENT.md` to build a slide.

Where the 36 came from: **12 are the compositions `../layouts/` already
demonstrates**, 3 come from `../composition-recipes.html`, and 21 fill gaps a real
deck has and the reference does not cover. That is an outcome, not a target — bloom
ended at 32 with a different mix.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 36: zero `width` / `max-width` / `min-width` / `height` /
`left` / `top` / `right` / `bottom` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex-basis`. `flex:0 0 4cqw` freezes exactly the way a `width` does.

Every title, lead/subtitle and body in a single-column composition is a full
safe-area row: `align-self:stretch; width:100%; max-width:none`. Do not introduce
a narrow wrapper, a narrow `max-width`, or a manual `<br>` to force wrapping.
Text wraps only after it uses the available safe-area width.

**In a split composition the column is the measure — nothing narrower.** In
`image-left`, `image-right`, `comparison` and the reading columns of `long-form`,
prose fills its own flex column and stops there, because the other column holds a
photograph, a filled half, or a second body of text. No layout writes a prose
`max-width` any more, in `em` or anything else. Measured at 1600×900: a text box
that wraps to two or more lines while ending short of the safe edge, with nothing
in the strip to its right, reads **0 across all 36 layouts and all 15 reference
pages**. `big-quote` is centered but still stretches the full row.

Why it matters here specifically: every content page in the original reference deck was produced by
measuring a rendered deck and writing the numbers back. Its text column is
`width:44cqw` with a `max-width:40cqw` on the copy inside it — two pins for one
column, so releasing either alone changes nothing. That column width is the observed
width of one English string at one font size. A CJK source is routinely wider, and the
reference's own comment records what happens: the text keeps 0.40 of the width and the
right third of the slide is simply empty. None of the layouts here pin a column, so
none of them needs the `:has([data-photocell])` escape hatch the example carries.

### Exemptions, all checkable

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that
  is `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline. A hairline is a hairline at any scale.
- **`em`** on ornaments only — never on a prose measure. See below.
- **`%`** in `chart-bar`, `chart-line` and `chart-share` only, where the number *is*
  the datum, and `width:1%` on a `data-table` identifier column, which is the
  shrink-to-fit table idiom meaning "take exactly the width your content needs".
- text that merely *displays* a CSS string. Strip text nodes before matching.

### `em` only works because `.fit` sets a container-relative font-size

`.fit` carries `font-size:1.5cqw`. Without that, `em` resolves against the root's
16px, does not scale with the stage, and is no better than writing `px`. With it:

| written | resolves to | the reference's number |
|---|---|---|
| `.badge` `--sz:3.4em` | 5.1 cqw | `width:5cqw` |
| node `--sz:4em` | 6 cqw | `width:6cqw` |
| `.disc` `--sz:3em` | 4.5 cqw | `width:4.6cqw` |

So an ornament reproduces the reference's size without writing a single observation,
and it cannot freeze a text box the way a `cqw` width would.

`em` used to carry the prose measure too — `max-width:27em` on a split `.body` and
`20em` on a split `.lead`, chosen to land on the reference's `max-width:40cqw`. Both
are gone. They were arithmetically faithful to the reference and still wrong in the
rendered result: in `image-left` they held the copy to 46.5% and 47.1% of the safe
area inside a column that was already 57.6% wide, so the text wrapped early and left
a ~10% empty strip between it and the safe edge. Reproducing a measured number is not
the goal; not leaving empty space is.

## The safe area

Set once, by the padding on `.fit`: `12cqh 7cqw 8cqh`.

**7%, not bloom's 6%.** Measured on `../layouts/`: 90 in-flow text runs,
the most common left inset is 7.0% (37 of 90) and the minimum is also 7.0% — nothing
in the reference starts left of it. The chrome sits further out at 6cqw, which is
correct: chrome is outside the content safe area by design.

If you run `../tools/audit.js` against this template, set `const SAFE = 0.07`.
The committed default is bloom's 0.06, which passes these layouts but is a looser
check than this template deserves.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions.
Not a slide. Every layout file embeds a byte-identical copy of it, generated from one
source, so a wrong relative path cannot appear in some files and not others.

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `statement` `long-form` `two-column` `three-column` `bullets`
`numbered-list` `big-quote`

**Filled counterparts** · `color-cards` `quote-cards`

**Compared, grouped, connected** · `comparison` `versus` `pros-cons` `case-study`
`feature-cards` `flow-diagram` `matrix`

**Numbers** · `kpi-grid` `kpi-cards` `stat-highlight` `data-table` `chart-bar`
`chart-line` `chart-share` `pricing`

**Time and sequence** · `process-steps` `timeline` `roadmap`

**Imagery** · `image-left` `image-right` `image-hero` `image-grid` `team-grid` — all five delete
cleanly. When the source has no imagery, drop the `.mat` frame and use a prose layout;
do not leave an empty mount.

**Contact** · `contact`

## Coverage review

The review is by communication job, not filename count. Closely related jobs share a
layout only when the same structure serves them without an empty region or a renamed
variant.

| common presentation job | coverage |
|---|---|
| opening, agenda, section, closing | `cover` `toc` `section-divider` `close` |
| one claim, extended narrative, bullets | `statement` `long-form` `bullets` `numbered-list` |
| two or three parallel ideas | `two-column` `three-column` `feature-cards` `color-cards` |
| photograph left/right, one large image, gallery | `image-left` `image-right` `image-hero` `image-grid` |
| quotation and testimonials | `big-quote` `quote-cards` |
| KPI, table, charts, share of total | `kpi-grid` `kpi-cards` `stat-highlight` `data-table` `chart-bar` `chart-line` `chart-share` |
| fees, tiers, packages | `pricing` |
| process, dated history, future plan, connected flow | `process-steps` `timeline` `roadmap` `flow-diagram` |
| comparison, strengths/trade-offs, case evidence | `comparison` `versus` `pros-cons` `case-study` |
| prioritisation and grouped features | `matrix` `feature-cards` |
| people and contact details | `team-grid` `contact` |

Any flex child holding an SVG or a percentage-height bar needs `min-height:0`, or the
SVG's intrinsic ratio pushes the box past the stage edge. `chart-bar`, `chart-line`
and `chart-share` all carry it.

## `versus` — the one slanted edge

Every other edge in blueprint-academy is drafted square, and this document used to
list `versus` under "what this template does not get" for exactly that reason. It is
here now because it was asked for: a full-page comparison that is one surface rather
than two cards.

It is deliberately the template's only slant, and it is the page's whole composition —
no heading, no chrome above it. The slant crosses the page centre at mid-height (56%
at the top edge, 44% at the foot). The safe area is untouched: `.fit` still carries
7cqw either side, and each half insets further so no line of type crosses the slant.

`comparison` remains the default. Use `versus` when the two readings are the entire
point of the page; use `comparison` when the comparison sits under a heading with the
rest of the argument.

## What this template does *not* get, and why

Taking "what a layout is for" rather than how another template built it:

- **`pros-cons` is not a renamed `comparison`.** `comparison` puts two subjects side by
  side. `pros-cons` evaluates one decision in two full-width stacked bands, so long
  strengths and trade-offs retain the whole safe-area row.
- **no `chart-pie`** — a wedge would be the first filled circle sector in this
  template. `link-circles` are outlined and empty and `icon-disc` carries an icon, so
  a pie has no vocabulary to sit in. `chart-share` does the same job as a divided bar.
- **no `mindmap` / `arch-diagram`** — one connected-boxes layout is enough, and
  `flow-diagram` is it. bloom's mindmap hub had to be recoloured twice for reading as
  a photo placeholder.
- **no `terminal` / `code` / `cta`** — see PLAYBOOK §5.

## Ruled or filled — both registers exist

The menu includes both ruled and filled treatments, so an agent need not repeat one
separator on every slide. Each peer-row content type has two treatments and neither is
more on-template:

| content | ruled | filled |
|---|---|---|
| three peer blocks | `feature-cards` | `color-cards` |
| three peer prose columns | `three-column` | `color-cards` |
| a row of numbers | `kpi-grid` | `kpi-cards` |
| testimonials | — | `quote-cards` |
| two things compared, in a ruled pair | `comparison` — plain half **and** filled half in one layout | |
| two things compared, as one full-page split | `versus` — full-bleed field, no heading, one slant | |

Filled versions cycle `--g0 --g1 --g2` so neighbours never share a colour, and the
`--g2` card keeps its hairline border because `--g2` is 1.23:1 against the page and
has no edge without one. `--g3` is not in the cycle: it is `#1E2B22`, and a card that
size in it is a large dark panel, which reads as a photo placeholder. The reference has
zero of those.

## A filled box is sized by its content, never by the stage

```
height  row     flex:none        — from the tallest child, not the stage
        child   flex:1           — every sibling matches that tallest child
        group   wrapped in flex:1;min-height:0;…;justify-content:center

width   box     align-self:flex-start; max-width:100%
        row     a row of peers divides the safe area and stays equal-width
```

`flex:1` on the **row** and on the **child** look like one instruction and do opposite
things: on the row it fills the stage and the cards inherit the stage's height, which
is how you get a slab of colour that is half empty.

Stress-tested rather than trusted: an extra sentence injected into the first peer of
every row, then sibling heights compared. **6 filled or bordered peer rows, all 6
equalise to the tallest content (spread 0px).** The 10 bare-text peer rows are not
required to equalise — they only have to agree on their first line.

`flow-diagram`'s cards were top-aligned for that reason. They centred their content
until the stress test showed the three headings drifting 40px apart as the copy grew;
the connector arms are `align-self:center` on their own spacers, so they hold the chain
at mid-height without the cards having to centre anything.

## Colour: what the tokens measure on this page

Against `--bg` `#F7F6F1`:

| token | ratio | use as |
|---|---|---|
| `--ink` `--s3` `--k1` `--g3` 13.63 · `--soft` 6.50 · `--ka` `--accent` `--g0` 4.72 · `--g1` 4.36 | pass | text or fill |
| `--s1` 3.03 | **fill only** | the statistic underline |
| `--s2` 1.23 · `--g2` 1.23 · `--ph` 1.14 · `--surface` 1.08 | **fill only** | grounds, mats, frames |

`--s1` at 3.03:1 clears a 3.0 contrast gate by one hundredth, so no probe will catch
it as text — and `design-system.md` already reserves the source hues for decoration.
The reference used it on five agenda numbers and I reproduced the same mistake in
`toc` before catching it by eye. Text on the pale ground is `--ink`, `--soft` or
`--ka`, and nothing else.

`--surface` is `#FFFFFF` on a `#F7F6F1` page: 1.08:1. The reference uses it **zero**
times. These layouts use it zero times. A panel of prose takes no fill and a hairline.

On a full-bleed divider `--ka` measures 2.89:1 against `--g3`, so a kicker there takes
`color:inherit`, never the accent token.

## Two contradictions in the source documents, left unresolved on purpose

Both are flagged rather than silently decided, because deciding either one changes the
shipped look of 23 decks:

1. **Square or rounded.** `design-system.md` sets every radius token to `0`, says
   "Never use `border-radius` anywhere", and calls the chrome label square-cornered.
   `example/reference.jpg` renders that label as a rounded pill, and the original reference deck
   writes 35 border-radius values including `border-radius:999px` on it. The rendered
   proof and the code agree with each other and disagree with the prose, so these
   layouts follow the render and use the radius **tokens** — change `--r-pill` and
   `--r-md` in one place if it gets settled the other way. A "no border-radius"
   criterion reads **35 on the reference**, so it cannot gate anything.
2. **Saturated grounds.** `design-system.md` says "Never fill the stage with a
   saturated colour", and the original reference deck puts `--g0` / `--g3` on `.stage` for all
   three section dividers. Measured: 3 of 15 pages, 20%. `section-divider` follows the
   example; no other layout is full-bleed.

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` ·
structure `stage fit deck slide card tile badge disc` ·
signature `gridpaper photo mat rule-card rule hair` ·
marks `dot soft dim pagenum`.

Sizes live in those classes. If something needs to be bigger, use the next class up —
do not write a `font-size`.
