# Blueprint Academy

## Visual identity

A quiet academic blueprint language: pale grid paper, wireframe structures, double-layer frames, and restrained starbursts. Information should unfold like a carefully organized worksheet.

## Color system tokens

Before generating, read `color-system` from the prompt. If the prompt provides one of the valid tokens below, use it exactly. If it does not, select a token according to the content, audience, mood, information density, and readability. Use only one token throughout a deck.

The presentation category documented for this template is **M (single primary)** and its example token is `forest_editorial`; determine the generation token using the rule above.

Valid tokens are limited to the following snake_case values:

- Single-primary M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`forest_editorial`, `warm_sand`, `slate_corporate`, `mono_ink`, `nordic_frost`, `gold_luxe`

The default color system used in `example/reference.jpg` is `forest_editorial`.
The identity is a quiet, pale worksheet with one deep ink hue. Bright multicolour tokens (`carnival`, `pop_art`, `prism`) break it and must not be chosen by default.


After selecting a token, read `color-systems/<token>.css`, inline its only CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="forest_editorial">
```

- Use `--bg`, `--surface`, `--ink`, `--soft`, and `--ph` for the page, surfaces, body copy, secondary text, and image placeholders.
- `--accent`, `--s1`, `--s2`, and `--s3` are source hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected by v1 for those source hues; use them for large icons or decorative symbols. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text. On an `--ink` colour field, use `--kad` for accent text. When a source hue needs stronger text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour blocks containing text, use `--g0` through `--g3` and pair the text with the corresponding `--t0` through `--t3`.
- HTML/CSS components must reference colours only through `var(--...)`; derive transparency, strokes, shadows, and gradients from defined tokens as well.

Combine `--bg` with a low-opacity grid to create a paper ground. Use `--g0` or `--g3` fields on section slides, and use `--s1` and `--s2` for starbursts, frame lines, and image mats.

```css
.slide { background: var(--bg); color: var(--ink); }
.surface { background: var(--surface); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Fraunces` as the display typeface and `Work Sans` as the body typeface.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500;600&family=Work+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Fraunces";
  --fb: "Work Sans";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "Songti SC", "STSong", "Noto Serif CJK SC", "Noto Serif SC", serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600; available body weights are 300 / 400 / 500 / 600. Use `--fd` for titles, hero numbers, and section numbers. Use `--fb` for body copy, labels, chart annotations, and tables. For CJK text, preserve the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the template's own base stylesheet. Copy it verbatim into the single
`<style>` block, immediately after the inlined colour-system CSS, before writing
any slide. It defines the 16:9 stage, the type scale, and the chrome and
decoration classes (`.kicker`, `.pagenum`, `.dot`, `.badge`, `.tile`, `.card`)
that the rest of this document refers to. A deck that invents its own class
names instead of using these will not look like this template.

The radius scale is part of the template's character, not a generic default —
do not replace it, and do not add a `border-radius` that is not one of these
tokens.

```css
:root{
  /* Blueprint Academy is drafted on paper. Every edge is square. */
  --r-xs: 0; --r-sm: 0; --r-md: 0; --r-lg: 0; --r-xl: 0;
  --r-pill: 0; --r-round: 50%;
  --fd: "Fraunces";
  --fb: "Work Sans";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "Songti SC", "STSong", "Noto Serif CJK SC", "Noto Serif SC", serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}
  

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:45;}

.tile{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.tile>span{font-size:40cqw;line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.badge>span{font-size:40cqw;line-height:1;}
.tick{position:absolute;}
.card{background:var(--surface);border-radius:var(--r-md);}
.dot{border-radius:50%;}.qcircle{border-radius:50% 0 0 0;}.semi{border-radius:999px 999px 0 0;}.tri{width:0;height:0;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}
/* signature-element helpers — use these instead of repeating inline styles */
.gridpaper{position:absolute;inset:0;z-index:0;opacity:.07;color:currentColor;
  background-image:repeating-linear-gradient(0deg,currentColor 0 1px,transparent 1px 5.2cqh),
                   repeating-linear-gradient(90deg,currentColor 0 1px,transparent 1px 5.2cqw);}
.photo{background:var(--ph);overflow:hidden;background-size:cover;background-position:center;background-repeat:no-repeat;border-radius:0;}
.mat{background:var(--bg);padding:.55cqw;border:1px solid color-mix(in srgb,var(--ink) 30%,transparent);box-shadow:0 .8cqw 2cqw color-mix(in srgb, var(--ink) 10%, transparent);}
.mat>div{padding:.5cqw;border:1px solid color-mix(in srgb,var(--ink) 16%,transparent);}
.rule-card{border:1px solid color-mix(in srgb,var(--ink) 22%,transparent);padding:2.4cqh 1.8cqw;}
.chrome-head{position:absolute;top:5cqh;opacity:.6;z-index:5;}
```
The number inside a `badge` and any text inside a `tile` must be wrapped in a
`<span>`. The wrapper is what makes the text scale with the box: it is measured
against the badge's own width, so the figure stays in proportion at any size.
Text placed directly in the box only follows `--sz`, and a deck that sizes the
box with `width`/`height` instead will render a small number in a large frame.
Size these with `--sz`, not `width`/`height`.


## Signature elements

These are not optional decoration. They **are** the template. A deck that drops
them is a generic deck wearing this template's colours, and it fails review.

Each element below is given as exact markup. Copy the snippet, keep its geometry
and its `var(--...)` colours, and change only size, position, and text content.
The listed counts describe reference usage; they are not minimums or delivery
quotas. Use only the elements supported by the closest reference page role.

## Element reference patterns

These counts describe how a 13–15 slide reference deck uses the named elements.
They help reveal the template's rhythm, but are neither floors nor a request to
fill every page. More ornament is not more fidelity: past a point it costs
legibility, which costs more than the ornament was worth.

| Element | Reference count per 13–15 slide deck | Note |
| --- | --- | --- |
| `grid-paper` | every slide | no exceptions; it costs nothing and defines the template |
| `wire-globe` | 2–4 | cover and closing slide; it is an emblem, not wallpaper |
| `link-circles` | 3–5 | above a title, as a section mark |
| `four-point-star` | 20–30 | one or two per slide including the chrome pill |
| `matted-photo` | only what the material supports, 0–4 | when there is one it is double-framed; never generate one to hit a number |

Do not scale these counts mechanically for a longer or shorter deck. Rows that
say *only what the material supports* are content, not decoration: see the
photograph rule in `SKILL.md`. Use the table to check identity and page-role
rhythm, not to decide how many elements to add.

### 1. `grid-paper` — the faint ruled ground

A pale square grid covering the entire stage at very low opacity. It is the
literal blueprint of the template and the single element that must never be
missing.

**Reference use: every slide, without exception, has the grid-paper layer as its first
child inside `.stage`.**

```html
<div style="position:absolute;inset:0;z-index:0;opacity:.07;color:currentColor;
  background-image:repeating-linear-gradient(0deg,currentColor 0 1px,transparent 1px 5.2cqh),
                   repeating-linear-gradient(90deg,currentColor 0 1px,transparent 1px 5.2cqw)"></div>
```

Because the grid sits at `z-index:0`, put all content on a layer above it —
`.fit` in this template is already `z-index:40`.

### 2. `wire-globe` — the wireframe sphere

An outlined globe built from nested ellipses and horizontal chords, drawn in the
ink hue at low opacity, large and cropped by the stage edge. It is the
template's academic emblem.

**Template use: the cover and the closing slide each carry a bottom-right wire-globe.** Width
`30cqw`–`46cqw`, `opacity:.35`–`.5`, `z-index:1`.

```html
<div style="position:absolute;right:6cqw;bottom:-14cqh;width:36cqw;height:36cqw;opacity:.45;z-index:1">
  <svg viewBox="0 0 100 100" style="width:100%;height:100%;display:block">
    <g fill="none" stroke="currentColor" stroke-width="0.7">
      <circle cx="50" cy="50" r="49"/>
      <ellipse cx="50" cy="50" rx="44.1" ry="49"/><ellipse cx="50" cy="50" rx="30.6" ry="49"/>
      <ellipse cx="50" cy="50" rx="10.9" ry="49"/>
      <line x1="18.5" y1="12.5" x2="81.5" y2="12.5"/><line x1="7.9" y1="25.0" x2="92.1" y2="25.0"/>
      <line x1="2.6" y1="37.5" x2="97.4" y2="37.5"/><line x1="1.0" y1="50.0" x2="99.0" y2="50.0"/>
      <line x1="2.6" y1="62.5" x2="97.4" y2="62.5"/><line x1="7.9" y1="75.0" x2="92.1" y2="75.0"/>
      <line x1="18.5" y1="87.5" x2="81.5" y2="87.5"/>
    </g>
  </svg>
</div>
```

### 3. `link-circles` — three overlapping outlined rings

Three thin outlined circles overlapping in a row, with a small four-point star
tucked beneath them. Used as a section mark above a title.

**Reference use: at least three slides carry link-circles**, including the cover.

```html
<div style="position:absolute;left:38cqw;top:5cqh;width:9cqw;height:5.9cqw;z-index:2;color:currentColor">
  <svg viewBox="0 0 100 66" style="width:100%;height:100%;display:block">
    <g fill="none" stroke="currentColor" stroke-width="1.6">
      <circle cx="30" cy="24" r="19"/><circle cx="50" cy="24" r="19"/><circle cx="70" cy="24" r="19"/>
    </g>
    <path d="M50 38 Q54 46 62 50 Q54 54 50 62 Q46 54 38 50 Q46 46 50 38 Z" fill="currentColor"/>
  </svg>
</div>
```

### 4. `four-point-star` — the small drafting star

A slim four-pointed star used as an inline marker beside titles, between words,
and in empty corners.

**Reference use: at least one four-point-star on every slide.** Size `1.1cqw`–`2.4cqw`.

```html
<span style="width:1.4cqw;height:1.4cqw;color:currentColor;display:inline-block;opacity:.7">
  <svg viewBox="0 0 100 100" style="width:100%;height:100%;display:block;overflow:visible">
    <path d="M50 3 Q65 35 97 50 Q65 65 50 97 Q35 65 3 50 Q35 35 50 3 Z" fill="currentColor"/>
  </svg>
</span>
```

### 5. `matted-photo` — the double-framed photograph

Photographs are matted like archive prints: an outer `--bg` mount with a thin
ink border and a soft shadow, an inner thin border, then the image. Photographs
are square-cornered and are frequently overlapped in pairs at slightly different
angles of offset.

**Reference use: none.** Use a photograph only where the supplied material describes a subject worth
showing, and then at most four across the deck. If it describes no such subject,
carry no photograph and let the wire globe, link-circles and grid do the work.
Every photograph that is present is matted and double-framed; two overlapping at
different sizes is the house arrangement when there are two.

```html
<div style="position:absolute;right:6cqw;top:11cqh;z-index:2;background:var(--bg);padding:.55cqw;
            border:1px solid color-mix(in srgb,var(--ink) 30%,transparent);
            box-shadow:0 .8cqw 2cqw color-mix(in srgb, var(--ink) 10%, transparent)">
  <div style="padding:.5cqw;border:1px solid color-mix(in srgb,var(--ink) 16%,transparent)">
    <div style="width:26cqw;height:40cqh;background:var(--ph);overflow:hidden;
                background-size:cover;background-position:center;background-repeat:no-repeat;
                background-image:url('<image>')"></div>
  </div>
</div>
```

The matted frame is the one place this template uses a shadow. Nothing else does.

### 6. `bordered-card` — the ruled worksheet block

Content blocks are thin-ruled rectangles with square corners, sometimes filled
with `--g0` and its `--t0` text. They read as boxes on a worksheet.

**Reference use: any comparison or grouped-content slide uses bordered-cards.**

```html
<div style="border:1px solid color-mix(in srgb,var(--ink) 22%,transparent);padding:2.4cqh 1.8cqw">
  <div class="kicker" style="opacity:.7">Item 1</div>
  <h3 class="h3" style="margin-top:1cqh">Heading</h3>
  <p class="body soft" style="margin-top:1cqh">Supporting sentence.</p>
</div>
```

### 7. `icon-disc` — the filled circle carrying an icon

A solid `--g` circle with a stroked icon centred in it, used beside a heading or
at the head of a list item. It is the only place this template fills a circle:
`link-circles` are outlined and empty, so the two never substitute for one
another.

**Reference use: on 7 of the reference deck's 15 slides.** Circle `4–5cqw`, icon about
`45%` of it, icon stroke in the matching `--t` token.

```html
<div style="flex:none;width:4.6cqw;height:4.6cqw;border-radius:50%;background:var(--g0);display:flex;align-items:center;justify-content:center"><svg viewBox="0 0 24 24" style="width:2.1cqw;height:2.1cqw;stroke:var(--t0);fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg></div>
```

## Decoration reference profile (diagnostic only)

Observed from this template's own reference deck, per slide, rendered at
1600×900. These averages combine unlike page roles: covers, section dividers,
dense content pages, comparisons, and closings.

**These figures are diagnostics, never quotas or per-slide instructions.**
First choose the closest page role in [layouts/](layouts/),
then use only the named signature elements and motifs demonstrated in that
composition. A utility class, empty colour field, outlined box, circle, pill,
arc, quarter-circle, or other shell geometry is not a motif by itself.

| per slide | decoration | size |
| --- | --- | --- |
| **0.6** | solid colour field | 20cqw and wider |
| **0.5** | outlined box | 20cqw and wider |
| **0.3** | drawn shape | 20cqw and wider |
| **0.3** | drawn shape | 7.5–20cqw |
| **0.3** | outlined box | 7.5–20cqw |
| **0.2** | solid colour field | 7.5–20cqw |
| **0.9** | drawn shape | 2.5–7.5cqw |
| **0.5** | circle or pill | 2.5–7.5cqw |
| **2.5** | drawn shape | 0.8–2.5cqw |


Read the figures only as a whole-deck drift signal. Around half the reference
rate can be appropriate when the material or page-role mix differs. Judge
fidelity by motif identity, placement, and composition rather than item count.
Sparse slides are intentionally sparse.

The reference deck also fills **1.5 image placeholders per slide**. That is not a target: this template forbids inventing a photograph the source material does not support, so a deck built from a text-only source is right to draw fewer — and image placeholders are excluded from the counts above for the same reason.

The table counts only decoration with no text inside it. This template also paints **1.2 labelled boxes per slide** — nav cells, numbered badges, buttons, tags: a painted or bordered box with a word or two in it. They are counted separately, and here they carry a large share of the identity: a deck that draws none of them reads as bare however well it does on the table above. Aim for that rate, not above it.

**A kicker is not a chip.** In this template's reference deck the `kicker`, the
page number, the running head and the standfirst are plain text — no background,
no border, no shadow, no rounded pill around them. Every one of the 23 reference
decks agrees on this, and giving them a box is the single most common way a
generated deck drifts: a kicker appears on every slide, so boxing it adds one
false chip per slide and doubles this template's labelled-box count on its own.

Only the elements the motif library actually draws as chips — `badge`, `tag`,
`pill`, and whatever else this file shows with a fill — carry a background.
Everything else that is text stays text.

**Before delivering, audit identity.** On three
representative slides, verify that every ornament maps to a named signature
element or to a specific composition in the reference. Use the table above only to notice gross whole-deck drift.

Content still comes first. Never push text off the stage, cover it, or drop a point. Never add a photograph
the source material does not support. A slide carrying six bullets may correctly
carry no optional ornament at all.


## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** A label positioned with `left:88cqw` will
overflow the moment its text is longer than the author guessed, and CJK copy is
routinely wider than the Latin draft it was written against. Anchor anything in
the right third with `right:` instead of `left:`, and anything in the bottom
third with `bottom:` instead of `top:`. A block anchored to the edge it is near
grows inward, where there is room, instead of outward into nothing. Give any
absolutely-positioned text an explicit `max-width` so it wraps rather than
extends.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a grid or a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

Both faults hide from a quick glance at the whole deck and are obvious on the
slide itself. Before delivering, look at every slide that carries a set of
things and check that the set is aligned and that nothing touches an edge it was
not meant to touch.

## Required chrome

This template's chrome sits at the **top** of the stage, not only the bottom.
Every slide carries all four, or the deck is incomplete:

1. **Top-left running head** — an uppercase `.kicker` naming the deck, constant across the deck:
   `<div class="kicker" style="position:absolute;left:6cqw;top:5cqh;opacity:.6;z-index:5">Your Academy</div>`
2. **Top-right section label** — an uppercase `.kicker` naming this slide's section:
   `<div class="kicker" style="position:absolute;right:6cqw;top:5cqh;opacity:.6;z-index:5">Education</div>`
3. **Bottom-left ruled pill** — a square-cornered outlined label flanked by two four-point stars:
   ```html
   <div style="position:absolute;left:6cqw;bottom:5cqh;z-index:5;display:inline-flex;align-items:center;gap:.8cqw;
               border:1px solid color-mix(in srgb,var(--ink) 30%,transparent);padding:.6cqh 1.2cqw">
     <span style="width:1.1cqw;height:1.1cqw;display:inline-block"><svg viewBox="0 0 100 100" style="width:100%;height:100%"><path d="M50 3 Q65 35 97 50 Q65 65 50 97 Q35 65 3 50 Q35 35 50 3 Z" fill="currentColor"/></svg></span>
     <span class="kicker">Academy</span>
     <span style="width:1.1cqw;height:1.1cqw;display:inline-block"><svg viewBox="0 0 100 100" style="width:100%;height:100%"><path d="M50 3 Q65 35 97 50 Q65 65 50 97 Q35 65 3 50 Q35 35 50 3 Z" fill="currentColor"/></svg></span>
   </div>
   ```
4. **Page number**, bottom-right, written as `page 04`: `<div class="pagenum">page 04</div>`

## Background rhythm

The ground is always the pale `--bg` with the grid-paper layer on top of it. This
template does not use full-stage saturated colour fields; its variety comes from
structure, not from colour:

- large serif display titles against wide empty grid;
- overlapping matted photographs;
- a cropped wire-globe;
- a ruled comparison pair, one plain and one filled with `--g0`;
- a worksheet-style timeline of filled circles on a hairline.

**Reference use: at least one slide is close to empty — a large title, a globe or
link-circles, and nothing else.**

## Decoration safe area

Decoration is placed before content, but it never fights the content.

- Every slide has a **text safe area**: the region actually occupied by the
  title, body copy, figures, and labels. No decoration may sit on top of it.
- Decoration belongs in one of three places: outside the safe area entirely
  (edges, corners, the empty half of the stage); behind it at `z-index:0`–`1`
  **and** at a contrast low enough that the text stays fully legible; or
  deliberately overlapping a photograph or colour field where the reference
  shows exactly that.
- A large ornament — a wire globe, a big circle, a blob, an oversized sprig —
  must be cropped by the stage edge rather than floated in the middle of the
  composition, unless it carries content itself.
- Never place body copy or a caption directly on top of a photograph unless the
  photograph is a full-bleed field with a text-safe treatment behind the copy.
- After rendering, look at every slide for a decoration that lands on text or
  makes a title hard to read. Move the decoration, not the text.

## Never do this

- Never omit the grid-paper layer. It is on every slide.
- Never use `border-radius` anywhere. Every edge in this template is square,
  including photographs, cards, and labels.
- Never fill the stage with a saturated colour. The ground stays pale.
- Never use disc/dot list bullets. Use bordered-cards, `STEP 01` labels, or a
  hairline rule between rows.
- Never use a shadow on anything except the matted-photo mount.
- Never set body copy in the display serif; `--fd` is for titles and figures only.
- Never let a slide go out without its top-left running head, top-right section
  label, bottom-left ruled pill, and `page NN` number.

## Self-check before delivery

Review identity and page-role fidelity. Fix the deck before
delivery if any line fails.

0. Every optional ornament maps to a named signature element or a specific
   composition in `layouts/`.
1. Signature elements appear only on the page roles where the reference uses
   them, with clear space and no text collision.
2. Every slide carries the items listed under `Required chrome`.
3. Every photograph follows the documented template treatment and illustrates
   a subject the material describes. Zero photographs is valid.
4. Every prohibition under `Never do this` was checked against the final HTML.
5. Exactly one `data-color-system` token is present and it is preferred.
6. The decoration profile was read only as a gross drift signal.

Visual reference: [example/reference.jpg](example/reference.jpg) —
the rendered proof of every rule above. [layouts/](layouts/)
is the same deck in code; open it when a snippet here needs more context.
