---
name: blueprint-academy
description: Create a standalone 16:9 HTML presentation deck with the Blueprint Academy visual identity and direct-HTML workflow. Use when the user selects the Blueprint Academy presentation template or explicitly names blueprint-academy as the deck style. Best suited to calm academic teaching, research explanations, courseware, and technical instruction.
---

# Blueprint Academy presentation

Create one coherent, audience-facing presentation from the supplied material. The
default deliverable is one directly openable HTML deck; use another presentation
format only when the user explicitly requests it.

`authoring-core.md` is the only authoritative Blueprint Academy authoring specification.
Files under `reference/` preserve provenance and diagnostics; do not read them during
normal generation.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.
All normal-generation paths are named below. Do not discover the template tree, count
files, search the repository, probe executable availability, or request tool help.

## 1. Decide the story and layouts

- Read the prompt and supplied material once. Identify the audience, intended outcome,
  throughline, and one evidence-backed takeaway per slide internally. Do not create a
  separate planning artifact or pause for approval.
- Ground every claim in the supplied material. Label forecasts, targets, and assumptions.
- Choose slide roles and fragment names from the index in `authoring-core.md`; let the
  content determine the count.
- Choose one colour-system token from the prompt or the supplied list in
  `authoring-core.md`.

## 2. Batch-read the build set

In one batch, read only:

1. `tools/qa-config.json`;
2. `authoring-core.md`;
3. `layouts/shell-contract.md`;
4. the selected `layouts/fragments/<name>.html` files;
5. the selected `color-systems/<token>.css`;
6. `resources/chrome.html` when it exists;
7. `resources/decoration.html` only when a chosen slide needs a named signature motif.

Do not read unselected fragments, recurse through the template folder, or open files
under `reference/`. Do not open `layouts/shared-shell.html`, `tools/run.sh`,
`tools/audit.js`, or any runtime implementation. The shared shell already contains all
common CSS and runtime code and is copied through its short interface contract.

## 3. Assemble and author once

- Copy the opaque shell exactly once with
  `cp layouts/shared-shell.html <deck>.html`. Without opening it, edit only the literal
  anchors documented in `layouts/shell-contract.md`: inline the one selected
  colour-system CSS, remove its local stylesheet link, and set the actual `lang`,
  `title`, `data-color-system`, and deck `aria-label`.
- Replace the shell's slide marker with one direct-child `.slide` wrapper per page.
  Put one selected `.stage` fragment in each wrapper, then adapt its placeholder copy
  and structure to the source. Keep the shared CSS and JavaScript exactly once.
- Read `tools/qa-config.json` before writing chrome. On every applicable `.stage`, put
  each required item on one visible wrapper with the exact `data-chrome="<role>"` name,
  preserving its `min`, `max`, and `when` contract. Copy only missing roles from
  `resources/chrome.html` when present; never duplicate chrome already in a fragment.
- Apply all identity, layout, colour, media, chart, and decoration rules from
  `authoring-core.md` while writing. Do not run a second manual audit of the same rules.
- Make non-destructive content and layout decisions autonomously. Split dense material
  rather than shrinking it into illegibility, and never invent content to fill a slot.

### Authoring checklist and final QA

Authoring is complete when the deck follows `authoring-core.md`, uses only supported
source material, and contains one assembled shell with direct-child slides. Mechanical
verification belongs to Automated QA; do not add a separate grep, browser inspection,
or item-by-item preflight phase.

#### Final delivery contracts

- Preserve the shell's 16:9 stage, `data-safe-area`, `.fit` padding, navigation runtime,
  and media-fit runtime.
- Every `[data-photocell]` must contain a successfully loaded image or CSS `url(...)`.
  Remove an unsupported media cell and choose a non-media layout instead of leaving a
  placeholder.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` extracts requested
  source figures in one pass. With no arguments it prints its contract.

#### Automated QA

- After fonts and images settle, run `bash tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary. An absent counter reads zero. `hardGateFailures` must be
  `0` and `status` must be `READY_TO_PUBLISH`.
- A blocked report carries `blocking`. Fix every named finding together, then rerun the
  same command once. If the HTML did not change, do not rerun QA.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` points to optional review pages.
- If an optional review leads to an HTML change, rerun the same QA command.
  If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. Do not open them to
  reverse-engineer a finding; use the page and rendered-DOM details already returned in
  the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
