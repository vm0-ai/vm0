---
name: blueprint-academy
description: Create a standalone 16:9 HTML presentation deck with the Blueprint Academy visual identity and direct-HTML workflow. Use when the user selects the Blueprint Academy presentation template or explicitly names blueprint-academy as the deck style. Best suited to calm academic teaching, research explanations, courseware, and technical instruction.
---

# Blueprint Academy presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one standalone HTML file with one live `.deck`. Keep every `.slide` as a direct child, give it one 16:9 `.stage`, and include the deck CSS and keyboard-navigation script once.
- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Create one direct-child `.slide` per planned page and one 16:9 `.stage` inside each slide.

### Which layout for which slide

Start from this table, then adapt. Every name is a file in [layouts/](layouts/).

In a single-column layout, every title, lead/subtitle and body is a full safe-area
row. Do not add a narrow wrapper, a narrow `max-width`, or a manual `<br>`; let the
browser wrap only after the full row is used. In a split composition the flex column
is the measure — prose fills its column and nothing narrower, and only because the
other column holds a photograph, a filled half, or a second body of text. A text box
that wraps early with an empty strip between it and the safe edge is a defect in
either case.

| the slide's job                          | layout                      | pair with                                                 |
| ---------------------------------------- | --------------------------- | --------------------------------------------------------- |
| open the deck                            | `cover`                     | globe bottom-right + link-circles, content upper-left     |
| agenda / contents                        | `toc`                       | hairline rows, tabular figures                            |
| start a section                          | `section-divider`           | full-bleed `--g0`/`--g3`, globe bottom-right              |
| one claim in prose                       | `statement`                 | full-width text rows; no empty second column              |
| extended narrative or policy context     | `long-form`                 | full-width opening + balanced reading columns             |
| two or three parallel ideas              | `two-column` `three-column` | or filled: `color-cards`                                  |
| a list of points                         | `bullets`                   | hairline rows, never disc bullets                         |
| ordered points with figures              | `numbered-list`             | one `badge` per item, grounds cycling                     |
| one decisive quotation                   | `big-quote`                 | link-circles high on the page                             |
| testimonials                             | `quote-cards`               | filled, grounds cycling                                   |
| two things compared                      | `comparison`                | one plain half, one `--g0` half                           |
| two things compared, as the whole page   | `versus`                    | full-bleed `--g0` field split by one slant, no heading    |
| strengths and trade-offs of one decision | `pros-cons`                 | two stacked full-width bands                              |
| challenge, response and measured outcome | `case-study`                | horizontal evidence sequence                              |
| prioritise by two dimensions             | `matrix`                    | compact 2 × 2 ruled field                                 |
| grouped features or goals                | `feature-cards`             | or filled: `color-cards`                                  |
| a chain of stages                        | `flow-diagram`              | outlined boxes, hairline arms                             |
| a numbered process                       | `process-steps`             | one `node` per stage + one `connector`                    |
| dated milestones                         | `timeline`                  | rail + one dot per milestone                              |
| workstreams across planning horizons     | `roadmap`                   | rows by workstream, columns by horizon                    |
| a row of metrics                         | `kpi-grid`                  | one `--s1` underline per cell                             |
| metrics as cards                         | `kpi-cards`                 | filled, grounds cycling                                   |
| one dominant figure                      | `stat-highlight`            | `--s1` rule under the figure                              |
| tabular evidence                         | `data-table`                | identifier columns never wrap                             |
| a trend or comparison of series          | `chart-bar` `chart-line`    |                                                           |
| a share of a total                       | `chart-share`               | a divided bar, not a pie                                  |
| fees, tiers or packages                  | `pricing`                   | three ruled tiers, the recommended one filled with `--g0` |
| a photograph and copy                    | `image-left` `image-right`  | double-framed `.mat`                                      |
| one large photograph                     | `image-hero`                | large double-framed `.mat` + concrete caption             |
| several photographs                      | `image-grid` `team-grid`    |                                                           |
| how to reach us                          | `contact`                   |                                                           |
| close the deck                           | `close`                     | globe + link-circles, content in the upper band           |

### Every slide must be a direct child of the deck

The navigation runtime collects slides with
`[...deck.children].filter(n => n.classList.contains('slide'))`. A `.slide` nested one
level deeper is not reachable with the arrow keys.

Check it before delivering, and then press the keys yourself:

```js
document.querySelectorAll(".slide").length ===
  [...document.querySelector(".deck").children].filter((n) =>
    n.classList.contains("slide"),
  ).length;
```

### Recommended layout approach

- Recommended starting point: use a clear top-to-bottom or left-to-right Grid/Flex relationship. Aim to balance the visual weight of its regions and place each primary content group near the optical center of its own region. A left-to-right composition can vertically center the groups on each side; a top-to-bottom composition can center groups within balanced bands. Adapt alignment and asymmetry to the content and the template's visual character.
- Use a `data-layout` container with CSS Grid or Flexbox for the primary spatial relationship when it helps the composition remain stable. Keep content groups in normal flow where appropriate, and use absolute positioning when an element's meaning or visual role depends on layering. Adapt proportions, nesting, and positioning to each slide's communication job.
- Preserve the template's original visual character from `design-system.md` and the examples. Compose content and signature elements together according to their visual and semantic roles, whether they belong inside the main layout or on a separate layer.
- Review all regions and layers as one composition. Aim for readable balance, allowing intentional overlap and out-of-flow placement when they strengthen hierarchy, meaning, or the template's signature style.
- Treat every slide as a projected presentation canvas. Write concise visible copy for the audience and keep one clear hierarchy of title, supporting content, and evidence on each page.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

### Composing the identity layer

- Build every slide in three layers: a **ground** layer (stage background, colour
  fields, panels, grid), a **decoration** layer (the signature elements from
  `design-system.md`, positioned absolutely and free to be cropped by the stage
  edge or to overlap content), and a **content** layer (`.fit` and the text).
  Give the decoration layer a `z-index` below the content layer unless the
  element is meant to sit on top.
- Place the decoration first, then the content, so both layers are composed together.
- Copy the `Deck shell` CSS from `design-system.md` verbatim into the single
  `<style>` block and build slides out of its class names. Do not invent a
  parallel set of utility classes.
- Vary the composition slide to slide, but keep the chrome, the radius scale, and
  the signature elements constant. Variety belongs in the layout, never in the
  identity.
- Use the helper classes that the `Deck shell` CSS defines (`.photo`, `.mono`,
  `.pill`, `.panel`, `.gridpaper`, `.mat`, `.track`, `.chrome-foot`, …) instead of
  repeating the same long inline style on every slide. They exist so the
  signature treatment is one class name, not a paragraph of CSS to remember, and
  a forgotten class is the usual reason a treatment goes missing.
- Whitespace is part of the composition. A deliberately quiet half-slide can be
  finished when the hierarchy is balanced. Add a signature element or colour field only
  when its documented page role supports that composition.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

- The photo treatments in `design-system.md` describe **how** a photograph looks
  in this template when there is one. They are not an instruction to produce
  that many photographs.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

- The `Signature elements` section gives exact markup for this template's
  decorations, motifs, badges, panels, and photo treatments. **Copy those snippets.
  Do not paraphrase them, redraw them,
  simplify them, or substitute a shape you find easier to write.** Change only
  size, position, colour token, and text content.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — signature elements, background
     treatment, chrome;
  4. every ornament follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is
  accurate but visually anonymous also fails. Omit optional ornament when it competes
  with content.

- **Take structure from [layouts/](layouts/) and ornament from
  [decoration/](decoration/), not from `layouts/`.** Use the reference image only
  for visual rhythm; its content-specific geometry is not reusable structure.
  - [layouts/README.md](layouts/README.md) — the 36 layouts, the sizing rule, the
    safe area, and which ruled layout pairs with which filled one.
  - [decoration/PLACEMENT.md](decoration/PLACEMENT.md) — the allowed roles and placement
    for each ornament.
  - [decoration/item-sets.html](decoration/item-sets.html) — the ornaments that
    attach to repeated items, as copyable markup.
- Optional: [example/reference.jpg](example/reference.jpg) for the visual identity and
  [layouts/](layouts/) for scale and rhythm. Where the three
  disagree: `layouts/` wins on structure and sizing, `reference.jpg` wins on what the
  template looks like, `design-system.md` wins on tokens and prohibitions.
- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. Its packets carry this template's column, spacing, and chrome behaviour; adapt one rather than inventing table markup, which is where these decks lose content. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use the prompt's `color-system` when supplied, otherwise a preferred token from
  `design-system.md`. Inline that one `color-systems/<token>.css` in the final HTML.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Signature-element checks while authoring

While authoring, walk the `Self-check before delivery` list in
`design-system.md` as an identity audit:

- Confirm the content survived and every slide carries the required chrome.
- Verify every optional ornament is a named signature element and follows
  `decoration/PLACEMENT.md`.
- Confirm each remaining element is appropriate to that slide's page role. A reported
  geometric crossing remains an optional-review candidate under `Automated QA` below.
- Search the finished HTML for each pattern named in `Never do this` and remove
  every hit.

A clear, balanced content slide may correctly use no optional ornament.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
