# vantage — decoration placement

Everything here is measured from the original reference deck (15 pages, 16 decoration
elements, rendered at 1600×900). Numbers, not taste.

Open `decoration.html` to see each ornament rendered with no text on the page.

**These numbers are vantage's. They are not bloom's, and several are its opposite** —
most importantly the bleed rule. Do not carry a number across from another template.

## The layer model

A vantage slide is four independent layers. Build them in this order and they cannot
fight each other:

| z-index | layer | where it comes from |
|---|---|---|
| 1 | split colour field | this folder, section E |
| 3–4 | decoration | this folder |
| 6 | persistent chrome | fixed, see A |
| 40 | `.fit` — all text | `../layouts/*.html` |

Decoration sits **below** text and is never inside `.fit`. If a layout and an ornament
collide, move the ornament — never the copy.

## A · Persistent chrome — identical on every page

Four items, on 15 of 15 reference pages. Copy them verbatim onto every slide. All four
sit **outside** `.fit`.

- `left:6cqw; top:4.5cqh` — `chrome-idx`: the giant page index, `4.4cqw`, `--fd` 600,
  over a `#yourcompany` kicker at `.65` opacity
- `right:6cqw; top:6cqh` — the running head, a `kicker`, two words with the second in `<b>`
- `left:6cqw; bottom:5cqh` — `brand`: a `2.2cqw` square plus the wordmark at `1.3cqw`
- `right:3cqw; bottom:3.2cqh` — `pagenum`

**The chrome occupies the top 14.9 % of the stage.** `.fit` therefore starts its content
at `15cqh`, and the lowest any reference content starts is 14.8 %. See D0.

On a colour field every one of these takes the matching `--t?`, never `--accent`: see D3.

## B · One ornament per page, not a pair

**This is where vantage differs most from the other v3 templates.** Measured:

| | reference |
|---|---|
| ornaments per page | **1.07** (16 over 15 pages) |
| pages carrying exactly 1 | 10 of 15 |
| pages carrying 2 | 3 of 15 — and all three are section dividers |
| pages carrying 0 | 2 of 15 — the image page and the pricing page |

The two empty pages are the two whose content already fills the stage. A page whose copy
fills the safe area correctly carries none.

The three 2-ornament pages are the section dividers, and the second ornament is always
the same one: a lone `sqm` square in the lower right. That is the divider's signature,
not a general licence to double up.

## C · Nothing bleeds — 0 of 16

**Zero reference ornaments cross the stage edge.** Not one. `squares` sits at centre
x=88–90 %, so its right edge lands at about 92 %, inside the 94 % safe edge.

This directly contradicts the sentence in `../design-system.md` that reads "A large
ornament must be cropped by the stage edge rather than floated in the middle of the
composition." **That sentence is wrong for this template** — it describes a different
design language. It is left in place only because rewriting the generated
`design-system.md` is out of scope for this split; follow this file instead.

Anchor with a positive offset from the edge it is near (`right:8cqw`, `top:16cqh`), never
a negative one.

## D · Where it goes — the right half, above or below the copy

15 of 16 ornaments sit in the **right half** of the stage. The single exception is the
donut, which is a chart and carries content.

| | count | centre x | centre y |
|---|---|---|---|
| right / upper | 9 | 88–90 % | 20–36 % |
| right / lower | 6 | 78–90 % | 69–80 % |
| left / lower | 1 | 22 % | 61 % — the donut, a chart |

Vertically it is always **20–36 %** or **69–80 %**, never the middle band where the
title sits.

Which of the two:

- copy is left-weighted and stops around half the stage → ornament goes **upper right**
- copy runs the full width of the safe area → ornament goes **lower right**
- section divider → `squares` upper right **plus** one `sqm` lower right

This is why `../layouts/` gives the left-weighted layouts a `data-decochannel` column:
it is the empty right column the ornament occupies. Its ratio is `1.1 : 1`, which is the
0.523 of the safe area the reference's left-weighted pages actually use.

## E · The split colour field

Three reference pages (cover, close, and the market page) are built on a full-height
colour field down one side, and it is one of vantage's strongest signatures.

- it is a **flex peer**, not a positioned box: `position:absolute;inset:0;display:flex`
  with a `flex:1.5` spacer and a `flex:1` panel. The reference wrote `width:40cqw`, which
  is a measured width written back; it has been unfrozen.
- the panel runs edge to edge — top, bottom, and its own side
- the copy on the other side keeps a real gutter (`padding-right:5cqw`). Without it the
  last word of every line sits flush against the field.

## F · Vocabulary — 4 ornaments, nothing else

| name | marker | what it is | count |
|---|---|---|---|
| square pair | `data-device="squares"` | two `4.4cqw` squares offset by `2.728cqw`; the rear one carries a 24×24 stroke glyph at 48 % | 11 |
| lone square | `data-device="sqm"` | one `5cqw` square, section dividers only | 3 |
| donut | `data-device="donut"` | `conic-gradient` ring, `inset:30%` hole | 1 |
| milestone line | `data-device="milestone"` | `polyline` + dots + date labels, `viewBox 0 0 100 100` | 1 |

**Do not invent circles, arches, quarter-circles, blobs or gradients.** The shell defines
`.qcircle`, `.semi` and `.tri`; the reference uses none of them. vantage is square.

The offset is exactly `2.728cqw` on a `4.4cqw` square — a 62 % overlap. Keep it.

## G · The pair must not collide with its own ground

`--ink` and `--g3` are the same colour (`#16243B`), and `--accent` and `--g0` are the same
colour (`#2F5BD0`). A square painted in the token that matches the page ground is
invisible, and half the pair disappears.

Measured on the reference before this was fixed: on all **5** colour-field pages one of
the two squares had contrast 1.00 against its ground.

| page ground | front square | glyph | rear square |
|---|---|---|---|
| `--bg` | `--ink` | `--bg` | `--accent` |
| `--g0` | `--ink` | `--bg` | `--t0` |
| `--g3` | `--accent` | `--t0` | `--t3` |

## H · Colour traps, measured against this colour system

`slate_corporate`, contrast ratios against each ground:

| token | on `--bg` | on `--g0` | on `--g3` |
|---|---|---|---|
| `--ink` / `--s3` | 15.56 | 2.61 | **1.00** |
| `--accent` / `--ka` | 5.95 | **1.00** | 2.61 |
| `--soft` | 5.82 | 1.02 | 2.67 |
| `--s1` | 3.47 | 1.71 | 4.48 |
| `--s2` | **2.14** | 2.78 | 7.26 |
| `--kad` / `--t?` | 1.00 | 5.95 | 15.56 |

Three consequences:

- **`--s2` is fill-only on the page.** 2.14:1 as text on `--bg`. It grounds a card; it
  never types.
- **On a colour field, text is `--t0`/`--t3`/`--kad` and nothing else.** The reference
  broke this three times — the divider page index was `--accent` on `--g3` at 2.61:1 —
  and those three are now `--kad`. That is what took `lowContrast` from 3 to 0.
- **Never use `--surface`.** It is `#F6F8FB` on a `#FFFFFF` page: **1.06:1**. The shell
  defines `.card{background:var(--surface)}` and the reference **never uses it** —
  `var(--surface)` appears exactly once in 15 pages, in that class definition itself.
  A `--surface` card is an invisible rectangle. The donut's third slice used it and read
  as a missing third; it is now `--s1`.

Card grounds cycle **`--g0 --g2 --g1`**, which is what the reference's quote row and
pricing row do. `--g3` is a page ground, not a card ground.

## I · Colour fields — one page in three

5 of 15 reference pages carry a ground colour on `.stage`: `--g0` ×2, `--g3` ×3 — the
cover, the three section dividers, and the closing page. That is 33 %.

On a full-bleed page the content sits **directly on the ground**. No cards, no panels.

## J · Item sets — every item, or none

The reference's repeated-item devices, as counted:

| the items are | device | treatment |
|---|---|---|
| ordered commitments | `badge` | one square badge per item, grounds cycling `--g0 --g2 --g1` |
| an unordered list | square marker | `1.6em` square, alternating `--ink` / `--accent` |
| people, quotes | `photocell` | `--ph`, `aspect-ratio:1` — or `border-radius:50%` for an avatar |

Within one set **every item carries the device**, or none does. The reference never puts
a badge on two of three rows.

Copyable markup: [item-sets.html](item-sets.html).

Labelled boxes — a painted box with a word or two in it — measure **0.27 per page** (4 in
15). That is the whole budget. **A kicker is not a chip**: the running head, the page
number and every `kicker` in the reference are plain text with no background, no border
and no pill. Boxing the kicker adds one false chip per slide and is the fastest way to
stop looking like vantage.

## K · Images

`photocell` measures **0.6 per page** (9 in 15). It is the image frame itself, `--ph`.
When the source has no imagery, **delete the frame** — do not leave an empty box and do
not substitute a grid of grey rectangles. `image-hero`, `image-left`, `image-right`,
`image-pair`, `image-gallery` and `team-grid` all delete cleanly.

Note `--ph` is `#E9EDF3` and reads 1.17:1 against `--bg`: a photo frame with no photo in
it is nearly invisible on the page, which is another reason to delete rather than keep it.

## D0 · The top 15 % belongs to the chrome

The chrome occupies down to **14.9 %** of stage height. `.fit` starts its content at
`15cqh`, and the lowest any reference content starts is **14.8 %**.

Measured: the reference has **zero** content text above the band. Exact-equality
criterion — it can gate.

Note the probe's band is 11 %, which is bloom's geometry and is looser than vantage's.
Passing it is necessary, not sufficient; vantage's own line is 15 %.

## D4 · Peer columns agree on their first line

Measured: the reference has **zero** rows where two peer columns start their text at
different heights, and so do all 44 layouts.

The trap is a filled card beside plain copy, and a second one specific to vantage: a
row of cards whose quotes are different lengths leaves the attributions at three
different heights. Pin them with `margin-top:auto` inside the card.

## D0b · Everything stays inside the safe area

The safe area is **6cqw** on each side — a template constant, set once by the padding on
`.fit` (`15cqh 6cqw 9cqh`). A page that sets less padding has not widened its safe area,
it has broken it.

Measured: the reference has zero text runs starting left of 6 % or ending right of 94 %.

## Verifying your own deck

```
                              reference        what to expect
ornaments per page            1.07             ~1, not 2
pages with >= 2 ornaments     3/15  (dividers only)
bleeding ornaments            0 of 16          0
ornaments in the right half   15 of 16
uses of --surface             0                0
full-bleed pages             33 %
labelled boxes per page       0.27             not one per kicker
photocells per page           0.6
text below 3.0:1              0                0
content above 15 % of height  0                0
```
