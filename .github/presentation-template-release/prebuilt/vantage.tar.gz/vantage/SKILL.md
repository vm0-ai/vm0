---
name: vantage
description: Create a standalone 16:9 HTML presentation deck with the Vantage visual identity and direct-HTML workflow. Use when the user selects the Vantage presentation template or explicitly names vantage as the deck style. Best suited to angular, confident business proposals, executive briefings, and sales pitches.
---

# Vantage presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one standalone HTML file with one live `.deck`. **Every `.slide` must be a
  direct child of that `.deck`** — the navigation runtime collects them with
  `[...deck.children].filter(n => n.classList.contains('slide'))`, so a slide nested one
  level deeper renders perfectly, scrolls perfectly, screenshots perfectly, and is
  unreachable by keyboard. Give each slide one 16:9 `.stage`, and include the deck CSS and
  keyboard-navigation script once.
- Before delivering, count them: `document.querySelectorAll('.slide').length` must equal
  `[...document.querySelector('.deck').children].filter(n => n.classList.contains('slide')).length`.
  The final QA dispatches the keys and verifies the live state; do not repeat the walk.
- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Create one direct-child `.slide` per planned page and one 16:9 `.stage` inside each slide.

### Layout — start from a canonical layout

For each slide, pick the layout in [layouts/](layouts/) whose name matches what the slide
has to do, and adapt it. Read [layouts/README.md](layouts/README.md) for the index and the
sizing rule. The 45 files are text only, so what you copy is the structure and nothing else.

| the slide is                                      | use                                                                                                                   |
| ------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------- |
| a title, agenda, chapter break, or closing        | `cover` `toc` `section-divider` `close`                                                                               |
| prose                                             | `statement` `longform` `lead-aside` `two-column` `three-column` `color-cards` `bullets` `numbered-list` `big-quote`   |
| numbers                                           | `kpi-grid` `kpi-cards` `stat-highlight` `stat-split` `table` `chart-bar` `chart-donut` `chart-line` `chart-waterfall` |
| a sequence in time                                | `milestone-line` `process-steps` `timeline` `roadmap` `gantt`                                                         |
| two things compared                               | `comparison` quiet · `versus` angled and loud · `pros-cons`                                                           |
| a structure                                       | `flow-diagram` `arch-diagram` `mindmap`                                                                               |
| people, or imagery the material actually supports | `team-grid` `quote-cards` `price-cards` `image-left` `image-right` `image-hero` `image-pair` `image-gallery`          |
| a decision-ready proposal                         | `case-study` `proposal-summary` `risk-matrix`                                                                         |

Rules that carry over from those files into anything you write:

- **Do not write a `width`, `max-width`, `height`, `left`, `top`, `right` or `bottom` in
  `cqw`, `cqh`, `px`, `vw` or `vh` on anything that holds text.** `flex-basis` counts.
  The safe area is set once, by the `.fit` padding — **`15cqh 6cqw 9cqh`**. Peer columns
  are `flex:1`. A width written by hand is a measurement of the placeholder string, and it
  will clip or wrap your real text.
- Two allowed exceptions: `em` for ornaments containing no prose, and `%` where the number
  _is_ the datum — a bar height, a polyline point, a conic stop.
- Any flex child holding an SVG or a percentage-height bar needs `min-height:0`.
- **A box with a visible fill is sized by its content, never by the stage — both
  dimensions.** Height: `flex:none` on the row, `flex:1` on each sibling so they equalise
  to the tallest one. Width: `align-self:flex-start;max-width:100%` on a lone box, because
  `.fit` stretches every child to full width by default; a **row of peers** stays
  equal-width and divides the safe area. One box hugs, a row of boxes divides. Reserve a
  filling `flex:1` for an image frame or a chart plot area.
- Do not put `align-items:flex-start` on a peer row — the short columns stay short the
  moment one of them grows.
- The full-height split colour field on `cover`, `close` and `stat-split` is a **flex
  peer** (`position:absolute;inset:0;display:flex` with a spacer and the panel), not a
  panel with a written width.
- Use the classes, not new font sizes. If something needs to be bigger, move up a class.
- Cycle filled cards `--g0 --g2 --g1` so neighbours never share a colour. `--g3` is a page
  ground, never a card ground. **Never use `--surface`** — it is 1.06:1 against `--bg` and
  renders as an invisible rectangle.
- On a colour field, text is `--t0` / `--t3` / `--kad`. `--accent` on `--g3` is 2.61:1 and
  `--ink` on `--g3` is 1.00:1 — the same colour.
- Treat every slide as a projected presentation canvas. Write concise visible copy for the audience and keep one clear hierarchy of title, supporting content, and evidence on each page.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

- Read [design-system.md](design-system.md) for the deck shell, motif library, and
  required chrome.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — motifs, background treatment, chrome;
  4. every optional motif follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is accurate but visually anonymous also fails.

- Build each slide from a **naked layout** in [layouts/](layouts/) plus the documented
  placement rules in [decoration/PLACEMENT.md](decoration/PLACEMENT.md). See Section 4a.
  Inspect [example/reference.jpg](example/reference.jpg) and
  [layouts/](layouts/) for scale, rhythm and composition — but
  copy structure from `layouts/`, not content-specific geometry from the reference image.
- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. Its packets carry this template's column, spacing, and chrome behaviour; adapt one rather than inventing table markup, which is where these decks lose content. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use the prompt's `color-system` when supplied, otherwise a preferred token from
  `design-system.md`. Inline that one `color-systems/<token>.css` in the final HTML.

#### Decoration

Decoration is not bound by the safe area: an ornament may cross it and bleed off the
stage where `PLACEMENT.md` says so. The safe area binds type and content.

- Decoration goes outside the region the content occupies — the empty half of
  the stage, the margins, the corners — or behind it at a contrast low enough
  that the text stays fully legible. A title crossing a background shape is the
  most common way these decks lose a layout mark.
- **Ornaments do not bleed off the stage in this template.** Keep them inside the right
  half at the page-role anchors in `PLACEMENT.md`; use a positive offset from the near
  edge, never a negative one. This is the opposite of several other
  v3 templates — see [decoration/PLACEMENT.md](decoration/PLACEMENT.md) section C.
- Never place body copy on top of a photograph unless the photograph is a
  full-bleed field and the copy sits on a text-safe treatment.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Identity checks while authoring

First confirm the content survived: every point is still on its slide and no
image or caption appears that the material does not support. Then audit
identity:

- every slide carries all four chrome items from
  [decoration/PLACEMENT.md](decoration/PLACEMENT.md) section A;
- every ornament is one of the **four** named in `PLACEMENT.md` section F — `squares`,
  `sqm`, `donut`, `milestone` — in its own geometry, with no substitute circles, arches,
  quarter-circles, blobs or gradients. vantage is square;
- every ornament follows the page-role composition in `PLACEMENT.md`;
- **no ornament bleeds off the stage edge**;
- on a colour field, neither square of the pair uses the token that matches the ground:
  `--ink` _is_ `--g3` and `--accent` _is_ `--g0`, so that square would be invisible;
- **no kicker, running head, page number or standfirst has a background, border or pill;**
- every page presenting a set of peer items carries the device on **every** item, or on
  none — see [decoration/item-sets.html](decoration/item-sets.html);
- `surfaceUses` reports no live `--surface` element; the unused `.card` definition is
  intentionally ignored;
- exactly one `data-color-system` token, and it is one of the preferred tokens;
- keep authored ornaments clear of type; any reported geometric crossing remains an
  optional-review candidate under `Automated QA` below.

The Automated QA report below supplies these diagnostics; do not run a second probe:
`overflow`, `outsideSafeArea`, `aboveChromeBand`, `lowContrast`,
`boxesUnderfilledV`, `boxesUnderfilledH`, `offVocabularyShapes`, `orphanSlides`,
`indirectSlides` — and `navigableSlides` equals the slide count.

Resolve any failure before running Automated QA.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
