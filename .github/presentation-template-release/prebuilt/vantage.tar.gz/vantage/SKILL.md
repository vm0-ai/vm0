---
name: vantage
description: Create, revise, or review standalone 16:9 HTML presentation decks with the Vantage visual identity and direct-HTML workflow. Use when the user selects the Vantage presentation template or explicitly names vantage as the deck style. Best suited to angular, confident business proposals, executive briefings, and sales pitches.
---

# Vantage presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## Choose the task mode

- Create: use Sections 1–5 and complete Section 2 before writing any slide HTML.
- Revise: inspect the existing HTML, reconstruct or update the outline for the affected sequence, and complete Section 2 before editing slide HTML; then use Sections 3–5 as relevant while preserving valid shell, token, motif, and runtime implementation.
- Review: use Sections 1–3 for context and Section 5 as the checklist; infer the deck's throughline and slide-level content contract, skip Section 4, and do not edit. Report slide-specific findings in P1 / P2 / P3 order (blocking / material / polish), include evidence and a fix direction, or state explicitly that there are no actionable findings.

## 1. Define the communication job

- Read the prompt and all supplied source material before composing slides.
- Identify the audience, purpose, desired audience outcome, core takeaway, and required evidence.
- Express the communication job in one sentence: by the end, the audience should reach the desired outcome because of the core takeaway.
- Ground every factual claim and number in supplied or verified sources; label forecasts, targets, and assumptions explicitly.

## 2. Complete the slide outline before HTML

- Before creating or changing slide HTML, write a lightweight plain-text or Markdown outline. State the one-sentence throughline, then list the slides in order.
- For each slide, record its working takeaway title, the point it must establish, and the evidence or data that supports it with its supplied or verified source. Mark forecasts, targets, assumptions, and slides that need no evidence.
- Review the complete outline for narrative flow, duplicated claims, missing evidence, and a deliberate opening and ending. Choose the slide count from the content.
- Treat the completed outline as the content contract for implementation, not as a layout schema. Keep layouts and motifs out of it, keep it out of audience-facing HTML unless requested, and update it first when a slide's title, communication job, or evidence changes materially.

## 3. Load the local identity

- Read [design-system.md](design-system.md) completely for colour roles, typography, signature elements, and visual identity.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — motifs, background treatment, chrome;
  4. every optional motif follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is accurate but visually anonymous also fails.

- Read [design-system.md](design-system.md) **completely, to the last line**,
  before writing any HTML. Its `Deck shell`, `Motif library` and
  `Required chrome` sections are requirements, not suggestions.
- Use one of the **preferred tokens** named in `design-system.md` when the
  prompt does not supply a `color-system` — not an arbitrary token from the full
  list.

- Build each slide from a **naked layout** in [layouts/](layouts/) plus the documented
  placement rules in [decoration/PLACEMENT.md](decoration/PLACEMENT.md). See Section 4a.
  Inspect [example/reference.jpg](example/reference.jpg) and
  [layouts/](layouts/) for scale, rhythm and composition — but
  copy structure from `layouts/`, not content-specific geometry from the reference image.
- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. Its packets carry this template's column, spacing, and chrome behaviour; adapt one rather than inventing table markup, which is where these decks lose content. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use a valid prompt `color-system` when supplied. Otherwise select a valid token from `design-system.md`. Load exactly one `color-systems/<token>.css` file and inline its CSS in the final HTML.
- Use this folder as the template guidance; the selected atomic colour-system file is the only shared template resource.

### Images are content choices, not decoration

Use a photograph or other image whenever it communicates the slide more clearly,
credibly, or memorably than text alone. The supplied material does not have to
explicitly request an image; make that editorial choice from the content.

- Choose sources in this order: user-supplied images and visual materials first,
  including media embedded in or linked from the supplied material; then relevant
  imagery from the supplied references and related information; then an AI-generated
  image grounded in the slide's actual subject when it would work better or no suitable
  sourced image exists.
- Never add or generate an image merely to fill an empty region or make a slide look
  finished. When no image improves the slide, use the template's
  non-photographic treatments instead: a colour field, a panel, a large figure,
  a motif, or generous space.
- Every caption, alt text, and label beside an image must come from the
  material. Never invent a caption to justify a picture.
- A generated image that illustrates nothing in the material makes that slide
  unfaithful to its source, which costs far more than the missing picture would.

### Decoration safe area

- Decoration goes outside the region the content occupies — the empty half of
  the stage, the margins, the corners — or behind it at a contrast low enough
  that the text stays fully legible. A title crossing a background shape is the
  most common way these decks lose a layout mark.
- **Ornaments do not bleed off the stage in this template.** Keep them inside the right
  half at the page-role anchors in `PLACEMENT.md`; use a positive offset from the near
  edge, never a negative one. This is the opposite of several other
  v3 templates — see [decoration/PLACEMENT.md](decoration/PLACEMENT.md) section C.
- Never place body copy on top of a photograph unless the photograph is a
  full-bleed field and the copy sits on a text-safe treatment.

## 4. Build the deck

- Produce one standalone HTML file with one live `.deck`. **Every `.slide` must be a
  direct child of that `.deck`** — the navigation runtime collects them with
  `[...deck.children].filter(n => n.classList.contains('slide'))`, so a slide nested one
  level deeper renders perfectly, scrolls perfectly, screenshots perfectly, and is
  unreachable by keyboard. Give each slide one 16:9 `.stage`, and include the deck CSS and
  keyboard-navigation script once.
- Before delivering, count them: `document.querySelectorAll('.slide').length` must equal
  `[...document.querySelector('.deck').children].filter(n => n.classList.contains('slide')).length`.
  Then press the arrow keys and walk to the last slide.
- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Create one direct-child `.slide` per planned page and one 16:9 `.stage` inside each slide.

### 4a. Layout — start from a canonical layout

For each slide, pick the layout in [layouts/](layouts/) whose name matches what the slide
has to do, and adapt it. Read [layouts/README.md](layouts/README.md) for the index and the
sizing rule. The 45 files are text only, so what you copy is the structure and nothing else.

| the slide is                                      | use                                                                                                                   |
| ------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------- |
| a title, agenda, chapter break, or closing        | `cover` `toc` `section-divider` `close`                                                                               |
| prose                                             | `statement` `longform` `lead-aside` `two-column` `three-column` `color-cards` `bullets` `numbered-list` `big-quote`   |
| numbers                                           | `kpi-grid` `kpi-cards` `stat-highlight` `stat-split` `table` `chart-bar` `chart-donut` `chart-line` `chart-waterfall` |
| a sequence in time                                | `milestone-line` `process-steps` `timeline` `roadmap` `gantt`                                                         |
| two things compared                               | `comparison` quiet · `versus` angled and loud · `pros-cons`                                                           |
| a structure                                       | `flow-diagram` `arch-diagram` `mindmap`                                                                               |
| people, or imagery the material actually supports | `team-grid` `quote-cards` `price-cards` `image-left` `image-right` `image-hero` `image-pair` `image-gallery`          |
| a decision-ready proposal                         | `case-study` `proposal-summary` `risk-matrix`                                                                         |

Rules that carry over from those files into anything you write:

- **Do not write a `width`, `max-width`, `height`, `left`, `top`, `right` or `bottom` in
  `cqw`, `cqh`, `px`, `vw` or `vh` on anything that holds text.** `flex-basis` counts.
  The safe area is set once, by the `.fit` padding — **`15cqh 6cqw 9cqh`**. Peer columns
  are `flex:1`. A width written by hand is a measurement of the placeholder string, and it
  will clip or wrap your real text.
- Two allowed exceptions: `em` for ornaments containing no prose, and `%` where the number
  _is_ the datum — a bar height, a polyline point, a conic stop.
- Any flex child holding an SVG or a percentage-height bar needs `min-height:0`.
- **A box with a visible fill is sized by its content, never by the stage — both
  dimensions.** Height: `flex:none` on the row, `flex:1` on each sibling so they equalise
  to the tallest one. Width: `align-self:flex-start;max-width:100%` on a lone box, because
  `.fit` stretches every child to full width by default; a **row of peers** stays
  equal-width and divides the safe area. One box hugs, a row of boxes divides. Reserve a
  filling `flex:1` for an image frame or a chart plot area.
- Do not put `align-items:flex-start` on a peer row — the short columns stay short the
  moment one of them grows.
- The full-height split colour field on `cover`, `close` and `stat-split` is a **flex
  peer** (`position:absolute;inset:0;display:flex` with a spacer and the panel), not a
  panel with a written width.
- Use the classes, not new font sizes. If something needs to be bigger, move up a class.
- Cycle filled cards `--g0 --g2 --g1` so neighbours never share a colour. `--g3` is a page
  ground, never a card ground. **Never use `--surface`** — it is 1.06:1 against `--bg` and
  renders as an invisible rectangle.
- On a colour field, text is `--t0` / `--t3` / `--kad`. `--accent` on `--g3` is 2.61:1 and
  `--ink` on `--g3` is 1.00:1 — the same colour.
- Treat every slide as a projected presentation canvas. Write concise visible copy for the audience and keep one clear hierarchy of title, supporting content, and evidence on each page.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

## Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Getting the container right

A percentage bar height resolves against its parent's **definite** height. Break
that chain and the bar computes to exactly `0` — it vanishes while the labels,
values and legend still render, so the page reads as merely empty. Measured on
generated decks: 52 of 558 percentage bars rendered at zero, and one deck spent
455s of gate repair on this alone.

`layouts/chart-*.html` already carries a structure that works. Copy it rather
than inventing lanes. Three rules make the chain definite:

1. **A bar is a direct child of the plot box.** Any level between them needs its
   own definite height, and one that lacks it zeroes everything below.
2. **All columns share one grid, so the label row is shared.** A label that wraps
   to two lines must cost every column the same height, or the bar above it is
   measured against a shorter ruler than its neighbours. Make the plot
   `display:grid; grid-auto-flow:column; grid-auto-columns:1fr` with
   `grid-template-rows:1fr auto …` (one row per item in a column, exactly — a
   spare row pulls the next column's first item into the previous column), and
   give each column wrapper `display:contents`. The markup grouping stays "one
   div per column"; only the rows become shared.

   Measured on the template's own `chart-bar.html`, changing nothing but one
   label to a wrapping name: baseline offset 0 → 19px, and the fourth bar 342 →
   324px — the value never changed, the bar just lost 5%. With the shared grid
   the same label costs all four bars the same 8%, and the ratios stay exact.

3. **Every level is either `flex:none` or `flex:1`** — sized by its content, or
   taking the remainder. There is no third kind.

4. **A value label never shares the lane with the bar it labels.** If it does,
   flex has to fit label + gap + bar into the lane, so it shrinks the bar — and
   only the bars tall enough to run out of room. The scale stops being linear at
   the top: measured on `bloom/chart-bar.html`, lane 336px, label 19px, gap 6px,
   every value above 92.5% rendered at the same 310px, so **96 and 100 drew
   identically**. Under the template's own "percentages of the tallest value"
   convention the tallest bar is always 100%, so this fires on every chart.
   Reserve the label row on the lane (`padding-top`, measured once per template)
   and set both children `flex:none`; the bar then resolves against the lane
   minus that reserve, the same reserve for every column.

Grouping two bars per category still obeys this, but the group wrapper needs
`align-self:stretch`, or it is sized by content and the lane inside it collapses.

Do not "fix" a flat chart by enlarging the numbers or switching to a table. The
values are right; the container chain is not.

## How full a page should be

Measured across all 902 layouts in the 23 shared templates, so this is what the
system already does — not a target invented for the occasion:

|                                                                                  | p25 |  median | p75 |
| -------------------------------------------------------------------------------- | --: | ------: | --: |
| vertical coverage (share of the stage height that carries ink or a filled block) | 33% | **43%** | 61% |
| ink area (share of the stage area)                                               |  9% | **12%** | 16% |
| lowest ink (how far down the page the content reaches)                           | 68% | **75%** | 90% |

**Aim for the middle column.** A content page that stops at 40% of the height and
leaves the rest blank reads as unfinished; one that runs past 25% ink area reads as
a wall. Both are allowed when the material calls for it — a statement page is one
huge line at 6% coverage, a table or a longform page is legitimately dense — but
neither is the default.

Two things that are **not** the same:

- **A void at the bottom.** Content stops early and nothing follows. This is the
  one to avoid; measured on the naked layouts, 73 of 902 pages do it.
- **Air between blocks.** A title, then a band of columns centred in the space
  below it. That is composition, not a defect — do not fill it just to fill it.

If the material genuinely does not fill the page, cut a column or merge the page
into its neighbour rather than padding sentences.

## 5. Verify before delivery

### Automated advisory check

- After fonts and images settle, run `tools/run.sh` once at 1600×900; rerun only when
  the HTML changes.
- The report is the visual review, so there is no need to take screenshots, create
  contact sheets, run image recognition, or visually review slides unless the user
  explicitly asks. It measures overflow, safe area, chrome band, column alignment,
  contrast, underfill, ornament vocabulary, empty photocells, text collisions, and deck
  navigation.
- Every reported item is a recommendation, never a blocker: fix the ones worth fixing
  from the slide, element, and DOM values it names; a zero report is not required.

### Identity audit before delivery

First confirm the content survived: every point is still on its slide and no
image or caption appears that the material does not support. Then audit
identity:

- every slide carries all four chrome items from
  [decoration/PLACEMENT.md](decoration/PLACEMENT.md) section A;
- every ornament is one of the **four** named in `PLACEMENT.md` section F — `squares`,
  `sqm`, `donut`, `milestone` — in its own geometry, with no substitute circles, arches,
  quarter-circles, blobs or gradients. vantage is square;
- every ornament follows the page-role composition in `PLACEMENT.md`;
- **no ornament bleeds off the stage edge**;
- on a colour field, neither square of the pair uses the token that matches the ground:
  `--ink` _is_ `--g3` and `--accent` _is_ `--g0`, so that square would be invisible;
- **no kicker, running head, page number or standfirst has a background, border or pill;**
- every page presenting a set of peer items carries the device on **every** item, or on
  none — see [decoration/item-sets.html](decoration/item-sets.html);
- `var(--surface)` appears zero times outside the `.card` class definition;
- exactly one `data-color-system` token, and it is one of the preferred tokens;
- no ornament sits on top of type.

Then run the probe and confirm these read zero:
`overflow`, `outsideSafeArea`, `aboveChromeBand`, `columnsMisaligned`, `lowContrast`,
`boxesUnderfilledV`, `boxesUnderfilledH`, `offVocabularyShapes`, `orphanSlides`,
`indirectSlides` — and `navigableSlides` equals the slide count.

Fix the deck and re-render before delivering if any line fails.

## Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
