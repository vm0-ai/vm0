// Run after opening a layout (or the labelled contact deck) at 1600×900.
// It adds one wrapping sentence to the first real peer, then checks that
// content-bearing siblings still share one rendered height.
(() => {
  const results = [];
  const excludedSlots = new Set([
    'chart-bar', 'chart-line', 'chart-waterfall', 'gantt', 'mindmap',
    'milestone-line', 'risk-matrix', 'statement'
  ]);

  for (const stage of document.querySelectorAll('.stage')) {
    const slot = stage.dataset.slot || 'content';
    if (excludedSlots.has(slot)) continue;
    const stageRect = stage.getBoundingClientRect();

    for (const row of stage.querySelectorAll('*')) {
      const style = getComputedStyle(row);
      const rowRect = row.getBoundingClientRect();
      if (style.display !== 'flex' || style.flexDirection !== 'row' ||
          rowRect.width < stageRect.width * .45) continue;

      const peers = [...row.children].filter(child =>
        getComputedStyle(child).flexGrow !== '0' &&
        child.getBoundingClientRect().width > 4 &&
        child.textContent.trim().length > 0
      );
      if (peers.length < 2 || peers.length > 4) continue;

      const structured = peers.filter(child =>
        child.querySelector('p,.body,.cap,.h3,.stat,.kicker,blockquote') ||
        child.matches('p,.body,.cap,.h3,.stat,.kicker,blockquote')
      );
      if (structured.length < 2) continue;

      const target = peers[0].querySelector('p,.body,.cap') ||
                     peers[0].querySelector('.h3,.stat,.kicker') || peers[0];
      const addition = document.createElement('span');
      addition.className = 'cap';
      addition.style.cssText = 'display:block;margin-top:.5cqh';
      addition.textContent =
        'Additional stress sentence forces this peer to wrap and become materially taller.';
      target.appendChild(addition);
      void row.offsetHeight;

      const heights = peers.map(peer =>
        Math.round(peer.getBoundingClientRect().height * 10) / 10
      );
      addition.remove();
      const spread = Math.max(...heights) - Math.min(...heights);
      results.push({slot, peers: peers.length, spread: +spread.toFixed(1), heights});
    }
  }

  return {
    tested: results.length,
    failures: results.filter(result => result.spread > 1),
    worstSpreadPx: results.length ? Math.max(...results.map(result => result.spread)) : 0,
    results,
  };
})()
