# vantage — naked layouts

45 layouts, text only. No chrome, no decoration, no colour decisions, no measured
geometry. Pair one of these with [`../decoration/PLACEMENT.md`](../decoration/PLACEMENT.md)
to build a slide.

## The one rule

**No sizing in container or viewport units on anything that holds text.** Verified across
all 45: zero `width` / `max-width` / `min-width` / `height` / `left` / `top` / `right` /
`bottom` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex-basis` too — `flex:0 0 4cqw` freezes exactly the way a `width` does.

Four exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline rule.
- **`em`** on ornaments that hold no prose — a square list marker, a timeline dot. `em`
  scales with the type around it, so it cannot freeze a text box the way `cqw` can. The
  marker is `1.6em` inside a `1.5cqw` row, which renders at exactly the `2.4cqw` the
  reference draws — the same mark, expressed as a ratio instead of a measurement.
- **`%`** where the number *is* the datum — bar heights in `chart-bar`, the polyline in
  `milestone-line`, the conic stops in `chart-donut`.

Everything else stretches. Columns are `flex:1`. The safe area is set once, by the padding
on `.fit`: **`15cqh 6cqw 9cqh`**.

Those three numbers are measured, not chosen. The persistent chrome occupies the top
**14.9 %** of the stage and the lowest any reference content starts is **14.8 %**, so
`15cqh` is the first row that clears it. `6cqw` is the reference's left margin on all 15
pages.

Any flex child holding an SVG or a percentage-height bar needs `min-height:0`, or the
SVG's intrinsic aspect ratio pushes the box past the stage edge.

## Why the numbers in the original reference deck are not design decisions

Every removed v3 full-deck example was produced by measuring a rendered deck and writing the numbers
back. `width:40cqw` on the cover panel is the observed width of one panel at one font
size; `max-width:44cqw` on a paragraph is where one particular English sentence happened
to wrap. Copying them reproduces that sentence, not the design. These layouts carry none
of them — including the three side panels, which are now flex peers.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions. Not a slide.

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `statement` `longform` `lead-aside` `two-column` `three-column`
`color-cards` `bullets` `numbered-list` `big-quote`

**Numbers and charts** · `kpi-grid` `kpi-cards` `stat-highlight` `stat-split` `table`
`chart-bar` `chart-donut` `chart-line` `chart-waterfall`

**Time and sequence** · `milestone-line` `process-steps` `timeline` `roadmap` `gantt`

**Two things compared** · `comparison` `versus` `pros-cons`

**Structure** · `flow-diagram` `arch-diagram` `mindmap`

**People and imagery** · `team-grid` `quote-cards` `price-cards` `image-left`
`image-right` `image-hero` `image-pair` `image-gallery` `image-grid`

**Decision-ready proposals** · `case-study` `proposal-summary` `risk-matrix`

## Where the set came from

Not from bloom's list, and not from open-design's. The method was: name what each of the
15 reference pages *is*, add what `composition-recipes.html` holds, then add only what a
real deck needs and vantage genuinely lacks.

**13 come straight off the reference** — `cover` `toc` `section-divider` `close`
`lead-aside` `numbered-list` `team-grid` `bullets` `milestone-line` `image-pair`
`stat-split` `quote-cards` `price-cards`.

**3 come from `composition-recipes.html`** — `big-quote` (the 28 % index column),
`versus` (the angled `clip-path` field), `table`.

**29 are additions**, each in vantage's own vocabulary — square markers, square badges,
two-tone headings, ground cycling, hairline rules. Twelve were added after the coverage
review, each for a communication job the first set did not perform:

- `statement` lands one authorial position; unlike `big-quote`, it has no speaker or
  attribution.
- `longform` carries a sustained narrative with an annotation rail; unlike `two-column`,
  it is one argument rather than two peers.
- `image-right` pairs visual evidence with quantified annotations; it is not a reversed
  copy of `image-left`.
- `image-gallery` presents context, interaction and outcome as a three-frame evidence
  sequence; `image-pair` is for two views of one subject; `image-grid` is an even six-up
  set where no frame outranks another — a range, an estate, a set of environments.
- `chart-line` shows continuous change, while `chart-waterfall` explains contributions
  from a baseline to a target.
- `roadmap` groups outcomes by horizon; `gantt` shows overlapping workstreams against a
  common calendar; `timeline` remains the dated event narrative.
- `mindmap` maps related themes around one square proposition; `arch-diagram` remains a
  layered system stack and `flow-diagram` remains a directional process.
- `case-study` tells challenge → action → outcome with proof, `proposal-summary` frames
  the executive decision, and `risk-matrix` prioritises likelihood × impact.

Deliberately **not** added, and why:

- **`todo-checklist`** — in vantage's vocabulary it is `bullets` with a different marker.
- **`cta`** — a slide cannot be clicked.
- **`code` / `terminal`** — a large dark framed rectangle reads as an unsupported image
  placeholder in this template; code belongs in a content-led layout when the source
  requires it.
- **`diff`** — the communication job is already covered by `comparison`; changing the
  sample words would not make a new composition.

## Ruled or filled — every peer row has both

The original set leaned on hairline rules. Left alone that is a skewed
menu: an agent sampling it puts the same horizontal line on every slide. Each of these
content types therefore has two treatments, and neither is more on-template:

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `color-cards` |
| a row of numbers | `kpi-grid` | `kpi-cards` |
| two things compared | `comparison` | `versus` |
| a list of items | `bullets` | `numbered-list` |

The filled versions cycle `--g0 --g2 --g1` so neighbours never share a colour. `--g3` is
a page ground, never a card ground; `--surface` is invisible on `--bg` and is never used.

## Which ornament attaches to which layout

The layouts are naked on purpose. Several describe a **set of peer items**, and in those
every item carries the device — see [`../decoration/item-sets.html`](../decoration/item-sets.html).

| layout | attach |
|---|---|
| `numbered-list` `process-steps` `flow-diagram` | one square `badge` per item, grounds cycling `--g0 --g2 --g1` |
| `bullets` `timeline` `pros-cons` `price-cards` | one `1.6em` square marker per item |
| `team-grid` `quote-cards` `image-*` | one `photocell` per item |
| `two-column` `three-column` `comparison` `table` `toc` | nothing — these hold prose, the hairline rules already in them do the work |
| `color-cards` `kpi-cards` `versus` | nothing — the fill *is* the ornament |
| `mindmap` `risk-matrix` `proposal-summary` | nothing — nodes, cells and numbered decision fields are content structure |

Plus, on the slide as a whole, **one** `squares` pair — upper right when the copy is
left-weighted, lower right when it runs full width. One per page, not two.

## No reserved empty column

`bullets`, `numbered-list` and `stat-highlight` used to wrap their body in a two-column
row — copy at `flex:1.1`, an empty `data-decochannel` column at `flex:1` — reproducing
the 0.523 copy-to-safe-area ratio measured on the reference's left-weighted pages.

That was the wrong instrument. The ratio is a property of *pages that carry a device on
the right*, not of the naked layout. Measured on the naked page it read as a defect, and
it is one: on `numbered-list` the title spanned the full 1408px safe area while the list
it titled was squeezed into 738px by a column holding nothing. A layout may only be split
when both sides carry content.

All three now run the full safe area. The list layouts organise each row as a full-width
grid — marker or badge, heading, description — so the width is used by content rather
than by a reservation. A device still attaches per
[`../decoration/item-sets.html`](../decoration/item-sets.html); it rides the row, it does
not get a column of its own.

Give those rows the default `align-items:stretch` and put `align-self:flex-start` on the
marker. `align-items:flex-start` on the row breaks the equal-height stress test — heading
and description columns stop sharing a height, which is the same defect that left eight
bloom layouts with short columns.

### Two geometric gates, run on all 45

Both are measured at 1600×900 against the 1408px safe area, not judged by eye:

1. **empty width-consuming box** — a flow box with no text, no paint anywhere in its
   subtree and no vector, taking ≥ 8 % of the safe width. Reference: **0**.
2. **narrow wrap** — text wrapping to two or more lines in a box clearly narrower than
   the safe area with nothing in flow to its right. Reference: **0**.

What they caught beyond the three list layouts, and how each was fixed:

| layout | reading | fix |
|---|---|---|
| `big-quote` | empty box 26.8 % × 41.8 % | the index field moved out of the background layer into the row as a real filled column carrying `01` and the kicker |
| `stat-split` | empty box 39.3 %, subtitle wrapping at 55.0 % | same — `$67M` is now a flow peer, so the left column has real content beside it |
| `cover` `close` | tagline wrapping at 29.4 % / 36.5 % | the hard `<br>` is gone; the line runs once at its natural width |
| `gantt` | empty header cell 26.4 % | it is the workstream column's header — it now says so |

A box whose *flex ratio is the datum* — a waterfall offset, a gantt start month — is
marked `data-offset`. It is empty on purpose: the number is the size. Nothing else in the
set is allowed to be.

The painted background layers on `cover` and `close` still carry a `flex` spacer. Those
are out of flow, they sit behind the content, and the field beside them holds real copy;
neither gate reads them and neither should. `big-quote` and `stat-split` no longer have a
background layer at all.

## A filled box is sized by its content, never by the stage

```
height   row     flex:none      height comes from the tallest child, not the stage
         child   flex:1         siblings equalise to that tallest child

width    box     align-self:flex-start; max-width:100%
         row     a row of peers divides the safe area — one box hugs, a row divides
```

`.fit` is a column flex with `align-items:stretch`, so every child is full-width by
default. Reserve a filling `flex:1` for an image frame or a chart plot area.

**Stress-tested, not assumed.** [`probe-equal-height.js`](probe-equal-height.js) injects
an extra sentence into the first item of every growable peer row and compares sibling
heights. Chart marks, schedule bars, matrix cells and the mind-map hub are excluded
because they are data structures rather than interchangeable prose peers.

## Two things compared

`comparison` and `versus` are the same job in two registers. `comparison` is two ruled
columns, quiet. `versus` splits the stage with the recipe's angled `clip-path` field and
puts one side on `--g0`, the other on `--g3` — the loud version for a claim you want to
land. The slant is a percentage of the field, not of the stage, so it follows wherever
flex puts the split.

## Charts

`chart-bar` puts both labels **below** the bar. A value label riding the top of a bar
cannot align with its neighbours — the bars are different heights, which is the point of
a bar chart — and a value label *inside* the bar makes the bar read as an underfilled
box. Both were tried; both read as defects.

`chart-donut` never uses `--surface` for a slice. At 1.06:1 against `--bg` the slice
disappears and the donut reads as having a missing third. The reference did this; it is
now `--s1`.

`chart-line` uses square points, not circular dots, and leaves every label outside the
SVG so text keeps the template type scale. `chart-waterfall` reserves the filled bars
for data only; labels remain below the plot and the bar offsets are the data.

## Two known constraints, stated rather than papered over

- `toc` sizes its index column with `flex:none` + `white-space:nowrap`, so the column is
  as wide as its own label. With uniform labels — a two-digit index — the rows agree, and
  they do in every render here. A label of very different length in one row will push that
  row's heading out of line. The honest fix is a `<table>`, which shares column widths
  across rows; it was not worth the weight here.
- `timeline` spaces its milestones evenly, not proportionally to the dates. The rail is a
  sequence, not a scale: four `flex:1` columns, so 15 Jan → 02 Mar occupies the same run
  as 20 Apr → 30 Aug. `gantt` is the layout that puts duration on a common calendar.
- `process-steps` carries no connector hairline. Centred on a tall text column it floats
  beside the headings instead of the badges, and vantage has no connector device — the
  reference conveys order with the numbered badge alone.

## Verified

```
static sizing audit (Sec 3)                    0 violations across 45
overflow / outsideSafeArea / aboveChromeBand   0 on all 45
lowContrast                                    0 on all 45
boxesUnderfilledV / boxesUnderfilledH          0 on all 45
offVocabularyShapes                            0 on all 45
navigation: decks / orphanSlides / indirect    1 / 0 / 0 on all 45
empty width-consuming boxes (>=8 % safe)       0 on all 45
text wrapping in a narrow box, empty right     0 on all 45
equal-height stress test                       0 of 36 growable peer rows failed
every layout rendered and looked at            yes, with the colour system confirmed loaded
```
