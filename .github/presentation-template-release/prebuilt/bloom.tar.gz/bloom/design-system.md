# Bloom

## Visual identity

Bold, rounded, and optimistic. Oversized titles carry the primary visual weight; organic colour fields, eight-petal flowers, and soft contours create rhythm.

## Color system tokens

Before generating, read `color-system` from the prompt. If the prompt provides one of the valid tokens below, use it exactly. If it does not, select a token according to the content, audience, mood, information density, and readability. Use only one token throughout a deck.

The presentation category documented for this template is **V (multicolour)** and its example token is `carnival`; determine the generation token using the rule above.

Valid tokens are limited to the following snake_case values:

- Single-primary M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`carnival`, `pop_art`, `prism`, `citrus_fresh`, `berry_pop`

The default color system used in `example/reference.jpg` is `carnival`.
Picking a token outside this list is how a deck ends up looking like a different
template: a finance source, for instance, pulls every template toward the same
muted corporate grey unless the list stops it.


After selecting a token, read `color-systems/<token>.css`, inline its only CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="carnival">
```

- Use `--bg`, `--surface`, `--ink`, `--soft`, and `--ph` for the page, surfaces, body copy, secondary text, and image placeholders.
- `--accent`, `--s1`, `--s2`, and `--s3` are source hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected by v1 for those source hues; use them for large icons or decorative symbols. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text. On an `--ink` colour field, use `--kad` for accent text. When a source hue needs stronger text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour blocks containing text, use `--g0` through `--g3` and pair the text with the corresponding `--t0` through `--t3`.
- HTML/CSS components must reference colours only through `var(--...)`; derive transparency, strokes, shadows, and gradients from defined tokens as well.

Use `--accent` as the main anchor across slides. Base information slides on `--bg` / `--surface`; rotate full-bleed `--g0` through `--g3` fields across section and key slides, with one field dominating each slide.

```css
.slide { background: var(--bg); color: var(--ink); }
.surface { background: var(--surface); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Fredoka` as the display typeface and `Quicksand` as the body typeface.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;500;600&family=Quicksand:wght@400;500;600;700&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Fredoka";
  --fb: "Quicksand";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600; available body weights are 400 / 500 / 600 / 700. Use `--fd` for titles, hero numbers, and section numbers. Use `--fb` for body copy, labels, chart annotations, and tables. For CJK text, preserve the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the template's own base stylesheet, used by `layouts/`.
Copy it verbatim into the single `<style>` block, immediately after the inlined
colour-system CSS, before writing any slide. It defines the 16:9 stage, the type
scale, and the chrome and decoration classes the rest of this document refers
to. A deck that invents its own class names instead of using these will not look
like this template.

```css
:root{
  --r-xs: .5cqw;
  --r-sm: .9cqw;
  --r-md: 1.7cqw;
  --r-lg: 3cqw;
  --r-xl: 5cqw;
--fd: "Fredoka";
  --fb: "Quicksand";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}
  

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:45;}

.tile{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.tile>span{font-size:40cqw;line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.badge>span{font-size:40cqw;line-height:1;}
.tick{position:absolute;}
.card{background:var(--surface);border-radius:var(--r-md);}
.dot{border-radius:50%;}.qcircle{border-radius:50% 0 0 0;}.semi{border-radius:999px 999px 0 0;}.tri{width:0;height:0;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}
```
The number inside a `badge` and any text inside a `tile` must be wrapped in a
`<span>`. The wrapper is what makes the text scale with the box: it is measured
against the badge's own width, so the figure stays in proportion at any size.
Text placed directly in the box only follows `--sz`, and a deck that sizes the
box with `width`/`height` instead will render a small number in a large frame.
Size these with `--sz`, not `width`/`height`.


## Signature elements

Available signature elements: `oversized-display-title`, `full-colour-ground-rotation`, `organic-blob`, `asterisk-burst`, `persistent-chrome`.


For templates with branded chrome, retain the dimensions, margins, and repeated position shown in the example, then replace placeholder names with actual brand assets.

Visual reference: [example/reference.jpg](example/reference.jpg)

## Motif library

Every motif below is copied out of this template's own reference deck. This is
the geometry that makes the template recognisable, and it is the part that goes
missing when a deck is authored from the prose alone — the shapes exist nowhere
else; it is reproduced here so generation never needs a full-deck HTML example.

**Copy these snippets. Do not paraphrase them, redraw them, or substitute a
shape that is easier to write.** Change only size, position, colour token, and
text content. The count beside each motif is how many times the reference deck
uses it across fifteen slides. It records prevalence; it is not a floor, quota,
or target to scale mechanically. Use a motif only where the closest reference
page role uses it and the composition benefits.


### `bbadge` — used 3× in the reference deck

```html
<div data-bbadge="1" style="position:relative;width:7cqw;height:7cqw;display:inline-flex;align-items:center;justify-content:center">
    <svg viewBox="0 0 100 100" style="position:absolute;inset:0;width:100%;height:100%;display:block"><polygon points="50.00,1.00 59.58,14.26 74.50,7.56 76.16,23.84 92.44,25.50 85.74,40.42 99.00,50.00 85.74,59.58 92.44,74.50 76.16,76.16 74.50,92.44 59.58,85.74 50.00,99.00 40.42,85.74 25.50,92.44 23.84,76.16 7.56,74.50 14.26,59.58 1.00,50.00 14.26,40.42 7.56,25.50 23.84,23.84 25.50,7.56 40.42,14.26" fill="var(--accent)"/></svg>
    <div style="position:relative;text-align:center;line-height:1;font-family:var(--fd);font-weight:600;font-size:1.9600000000000002cqw;letter-spacing:-.01em;color:var(--oa)">01</div>
  </div>
```

### `bigcircle` — used 31× in the reference deck

```html
<div data-bigcircle="1" style="position:absolute;right:-7cqw;bottom:-9cqh;width:22cqw;height:22cqw;opacity:0.92;z-index:0"><svg viewBox="0 0 100 100" style="width:100%;height:100%;display:block;overflow:visible"><g transform="rotate(8 50 50)"><rect x="3" y="41.5" width="94" height="17" rx="8.5" transform="rotate(0 50 50)" fill="var(--s1)"/><rect x="3" y="41.5" width="94" height="17" rx="8.5" transform="rotate(45 50 50)" fill="var(--s1)"/><rect x="3" y="41.5" width="94" height="17" rx="8.5" transform="rotate(90 50 50)" fill="var(--s1)"/><rect x="3" y="41.5" width="94" height="17" rx="8.5" transform="rotate(135 50 50)" fill="var(--s1)"/></g></svg></div>
```

### `slot` — used 15× in the reference deck

This motif is too long to inline without cutting it mid-tag, so it is not
reproduced here. Find it in [layouts/](layouts/) by
searching for the opening tag below, and copy the whole element from there.

```html
<div class="stage" data-slot="cover" style="">
```

### `tile` — used 4× in the reference deck

```html
<div class="tile" data-tile="1" style="width:4.6cqw;height:4.6cqw;background:var(--g0);color:var(--t0)"><svg viewBox="0 0 24 24" style="width:52%;height:52%;stroke:currentColor;fill:none;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/></svg></div>
```


### CSS signatures

These declarations are part of the template's look. The counts are from the reference deck.

| property | values it actually uses | why it matters |
| --- | --- | --- |
| `border-radius` | `999px` ×16<br>`50% 0 0 0` ×1<br>`999px 999px 0 0` ×1<br>`0 var(--r-lg) var(--r-lg) 0` ×1 | arches, capsules and part-round corners |


### Not captured above

These named signature elements have no extractable snippet in this library: `oversized-display-title`, `full-colour-ground-rotation`, `organic-blob`, `asterisk-burst`, `persistent-chrome`. Read [layouts/](layouts/) for them and copy the markup from the slide that uses them; do not improvise a substitute.

## Decoration reference profile (diagnostic only)

Observed from this template's own reference deck, per slide, rendered at
1600×900. These averages combine unlike page roles: covers, section dividers,
dense content pages, comparisons, and closings.

**These figures are diagnostics, never quotas or per-slide instructions.**
First choose the closest page role in [layouts/](layouts/),
then use only the named signature elements and motifs demonstrated in that
composition. A utility class, empty colour field, outlined box, circle, pill,
arc, quarter-circle, or other shell geometry is not a motif by itself.

| per slide | decoration | size |
| --- | --- | --- |
| **1.5** | drawn shape | 20cqw and wider |
| **0.5** | drawn shape | 7.5–20cqw |
| **0.5** | drawn shape | 2.5–7.5cqw |
| **0.3** | solid colour field | 2.5–7.5cqw |
| **0.3** | circle or pill | 2.5–7.5cqw |
| **0.3** | drawn shape | 0.8–2.5cqw |


Read the figures only as a whole-deck drift signal. Around half the reference
rate can be appropriate when the material or page-role mix differs. Judge
fidelity by motif identity, placement, and composition rather than item count.
Sparse slides are intentionally sparse.

The reference deck also fills **0.7 image placeholders per slide**. That is not a target: this template forbids inventing a photograph the source material does not support, so a deck built from a text-only source is right to draw fewer — and image placeholders are excluded from the counts above for the same reason.

The table counts only decoration with no text inside it. This template also paints **0.1 labelled boxes per slide** — nav cells, numbered badges, buttons, tags: a painted or bordered box with a word or two in it. They are counted separately, and this template barely uses them: 0.1 per slide is the whole budget. A deck that turns every label into a bordered chip is not this template — that is a different, busier design, and it is the most common way these decks drift away from their reference.

**A kicker is not a chip.** In this template's reference deck the `kicker`, the
page number, the running head and the standfirst are plain text — no background,
no border, no shadow, no rounded pill around them. Every one of the 23 reference
decks agrees on this, and giving them a box is the single most common way a
generated deck drifts: a kicker appears on every slide, so boxing it adds one
false chip per slide and doubles this template's labelled-box count on its own.

Only the elements the motif library actually draws as chips — `badge`, `tag`,
`pill`, and whatever else this file shows with a fill — carry a background.
Everything else that is text stays text.

**Before delivering, audit identity.** On three
representative slides, verify that every ornament maps to a named signature
element or to a specific composition in the reference. Use the table above only to notice gross whole-deck drift.

Content still comes first. Never push text off the stage, cover it, or drop a point. Never add a photograph
the source material does not support. A slide carrying six bullets may correctly
carry no optional ornament at all.


## Decoration safe area

Decoration is placed before content, but it never fights the content.

- Every slide has a **text safe area**: the region actually occupied by the
  title, body copy, figures, and labels. No decoration may sit on top of it.
- Decoration belongs in one of three places: outside the safe area entirely
  (edges, corners, the empty half of the stage); behind it at `z-index:0`–`1`
  **and** at a contrast low enough that the text stays fully legible; or
  deliberately overlapping a photograph or colour field where the reference
  shows exactly that.
- A large ornament must be cropped by the stage edge rather than floated in the
  middle of the composition, unless it carries content itself.

## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** A label positioned with `left:88cqw` will
overflow the moment its text is longer than the author guessed, and CJK copy is
routinely wider than the Latin draft it was written against. Anchor anything in
the right third with `right:` instead of `left:`, and anything in the bottom
third with `bottom:` instead of `top:`. A block anchored to the edge it is near
grows inward, where there is room, instead of outward into nothing. Give any
absolutely-positioned text an explicit `max-width` so it wraps rather than
extends.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a grid or a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

Both faults hide from a quick glance at the whole deck and are obvious on the
slide itself. Before delivering, look at every slide that carries a set of
things and check that the set is aligned and that nothing touches an edge it was
not meant to touch.

## Never do this

- **Never use a disc-bulleted list.** Not one of the twenty-three V3 reference
  decks contains a single `<ul>` with default bullets, and a bulleted list is the
  fastest way to make a designed template look like a plain document. Structure a
  list as numbered rows with a hairline rule between them, as key–value rows, as
  a row of cards, or with the template's own motifs — whatever the reference deck
  does for the same job.
- Never invent a colour outside the inlined colour-system tokens; every colour
  goes through `var(--...)`.
- Never leave a slide without the chrome named in `Required chrome`.
- Never let an ornament sit on top of a title or a paragraph.
- Never generate a photograph the supplied material does not call for.

## Required chrome

Chrome is the cheapest part of a template's identity and the most frequently
dropped: across the benchmark's baseline decks, four of six templates carried a
footer on 0-2 slides out of 17. This template's reference deck carries the
following, and the count is measured from that deck, not assumed.


### Repeats on every slide

The reference deck also repeats these edge-pinned elements on nearly every slide. Their opening tags are given as locators — find each one in [layouts/](layouts/) and carry it through your deck the same way.

```html
<div class="kicker" style="position:absolute;left:50%;top:5cqh;transform:translateX(-50%);font-size:1.0cqw;letter-spacing:.2em;color:var(--ink);opacity:.82">
```
<sub>on 15 of 15 reference slides</sub>

```html
<div class="kicker" style="position:absolute;left:4cqw;top:4.6cqh;font-family:var(--fd);font-weight:600;font-size:1.55cqw;letter-spacing:.01em;text-transform:none;color:var(--ink)">
```
<sub>on 15 of 15 reference slides</sub>
**Persistent `chrome` element** — on 15 of the reference deck's 15 slides, unchanged from slide to slide.

```html
<div data-device="chrome" style="position:absolute;right:4cqw;top:3.9cqh"><div class="kicker" style="border:1.6px solid var(--ink);border-radius:999px;padding:.95cqh 1.5cqw;font-size:.92cqw;letter-spacing:.13em;color:var(--ink)">LEAD THROUGH INNOVATION</div></div>
```


**Edge-pinned label** — on 15 of the reference deck's 15 slides. A wide-tracked uppercase `.kicker` carrying a stable word drawn from the deck's own subject:

```html
<div class="kicker" style="position:absolute;left:50%;top:5cqh;transform:translateX(-50%);font-size:1.0cqw;letter-spacing:.2em;color:var(--ink);opacity:.82">PRESENTATION 2045</div>
```

**Page number** — on 15 of 15 slides:

```html
<div class="pagenum">01</div>
```

Carry footer label and page number on **every** slide, including the cover and the closing slide.
