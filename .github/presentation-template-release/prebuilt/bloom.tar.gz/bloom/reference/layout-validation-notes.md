# Bloom historical layout-validation notes

> Provenance only. This file may describe the former full-document layout inventory.
> The current assembly and count contract is in `../authoring-core.md`; do not read this
> file during normal generation.

32 layouts, text only. No decoration, no colour decisions, no measured geometry.
Pair one of these with `../decoration/PLACEMENT.md` to build a slide.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 32: zero `width` / `max-width` / `height` / `left` / `top` /
`right` / `bottom` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex-basis` too. A number gutter written `flex:0 0 4cqw` freezes exactly
the way a `width` does, and the first version of this audit missed it in `bullets`,
`toc` and `table` — 15 sites — because the regex only looked at `width`/`height`.

Three exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`, like the persistent chrome or a corner badge. That is where it
  goes, not how big it is.
- **`height:1px`** for a hairline rule. A hairline is a hairline at any scale, and the
  reference writes it the same way.
- text that merely *displays* a CSS string. Strip text nodes before
  matching or the placeholder content trips its own rule.

Two more exceptions, both deliberate:

- **`em`** on ornaments that contain no prose — a legend dot, a timeline dot, a
  checklist badge. `em` scales with the type around it, so it cannot freeze a text
  box the way `cqw` can.
- **`%`** in `chart-bar` and `gantt` only, where the number *is* the datum. A bar
  whose height is 61% is reporting 61, not making a layout choice.

Everything else stretches. Columns are `flex:1`. The safe area is set once, by the
padding on `.fit` (`12cqh 6cqw 8cqh`). Measured on all 32: 0.88 stage width, zero
overflow.

This matters because the original reference deck was produced by measuring a rendered deck and
writing the numbers back, so its widths are observations of one string at one font
size, not design decisions. Copying them reproduces that one string. These carry none.

Any flex child that holds an SVG or a percentage-height bar needs `min-height:0`.
Without it the SVG's intrinsic aspect ratio pushes the box past the stage edge —
that cost three of the four chart layouts a failed render on the first pass.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions.
Not a slide.

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `two-column` `three-column` `color-cards` `bullets` `big-quote`
`todo-checklist`

**Numbers** · `kpi-grid` `kpi-cards` `stat-highlight` `table` `chart-bar` `chart-line`
`chart-pie` `chart-radar`

**Time and sequence** · `process-steps` `timeline` `roadmap` `gantt`

**Structure** · `arch-diagram` `flow-diagram` `mindmap`

**Two things compared** · `comparison` `versus` `pros-cons`

**Imagery** · `image-left` `image-right` `image-hero` `image-grid` — all four delete
cleanly. `image-left` and `image-right` are a split row: the frame is `flex:1`, the copy
is `flex:1.15`, so the picture takes a little under half. When the source has no imagery,
drop the `data-photocell` frame and use a prose layout instead; do not leave an empty box.

## Which ornament attaches to which layout

The layouts are naked on purpose, but several of them describe a **set of peer items**,
and in bloom every item in such a set carries an ornament. See
[../decoration/item-sets.html](../decoration/item-sets.html) for copyable markup.

| layout | attach |
|---|---|
| `three-column` `arch-diagram` `image-grid` | one `tile` per item, ground cycling `--g0..--g3` |
| `process-steps` `flow-diagram` `timeline` | one `node` per stage + one `connector` |
| `kpi-grid` `stat-highlight` `pros-cons` | one `bbadge` per highlighted claim or number |
| `bullets` `two-column` `comparison` `table` | nothing — these hold prose, use the hairline rules already in them |
| `color-cards` | nothing — the card *is* the colour, adding an ornament on top of it is noise |

## Two things compared

`comparison` and `versus` are the same job in two registers. `comparison` is two ruled
columns, quiet; `versus` splits the row with a diagonal and puts one side on a `--g?`
ground, which is the loud version for a claim you want to land.

`versus` is now the whole page: no heading, no chrome above it, the field bleeding to
all four stage edges, and the slant as the page's single style line. It crosses the
centre at mid-height — 56% at the top edge, 44% at the foot — so the two readings meet
on one surface rather than sitting in a panel under a title.

Nothing about it is pinned. The slant is a `clip-path` in percentages of the stage, the
halves are `flex:1` peers, and the 16cqw gutter is what keeps both column boxes clear of
the slant at every height: the left column ends at 42% and the slant's foot is at 44%;
the right column starts at 58% and the slant's top is at 56%.

**Each half repeats the colour it is already sitting on.** That looks redundant and is
not: `tools/run.sh` reads a text element's ground by walking its *ancestors*, and the
slanted field is a sibling. Without the repeat the left half is scored as light-on-light.
It passes here only because the gutter keeps each flat rectangle entirely on its own
colour, so it paints nothing you can see.

An earlier version ran a title across the whole stage in `--t1`; its tail crossed the
diagonal onto cream and vanished. The heading is gone now, so that trap is gone with it.

`diff` used to sit here and was removed: it was `comparison` with different placeholder
text. `cta` went too — its two pill buttons were an `<a class="btn">` pair carried over
from open-design, and a slide cannot be clicked. Same borrowing that cost `terminal` its
traffic lights.

## Ruled or filled — every peer row has both

14 of the 32 layouts separate their items with a hairline rule, 48 sites in all. That is
a skewed menu: an agent sampling it defaults to hairlines and every slide ends up with
the same horizontal line across it. Each of these content types therefore has two
treatments, and neither is more on-template than the other:

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `color-cards` |
| a row of numbers | `kpi-grid` | `kpi-cards` |
| two things compared | `comparison` | `versus` |

The filled versions cycle `--g0 --g2 --g1 --g3` so neighbours never share a colour, and
`color-cards` scales to 2–4. Put a "most relevant" badge at `position:absolute` in a
card's top-right so it does not push that card's title out of line with the others.

Pick the filled version when the items are short and parallel, when the ruled version
reads thin, or simply when the previous slide was ruled. Cycle the grounds
`--g0 --g2 --g1 --g3` so neighbours never share a colour.

## Nothing sits on a full-bleed page

When the ground colour is on `.stage`, the content sits **directly on it** — no cards, no
panels. The reference's one full-bleed content page (p12) puts three statistics straight
onto `--g0` with no box around any of them.

A generated deck put four cards on a `--g2` page and made two of them white and one
black. On a colour field a white card is a hole and a black card is a blot; both also
break the `--surface` and large-`--ink` rules at the same time.

## `margin-top:auto` pushes text into the decoration zone

Five layouts used it to pin a trailing line — a source note, a contact line — to the
bottom of the stage. That leaves a void between the content and that line, and drops the
line straight into the lower third where the ornaments bleed in. A generated deck showed
exactly this: a closing sentence alone at 85 % height with an orange flower behind it.
Use a normal margin; let the trailing line follow its content.


## A coloured block is sized by its content, never by the stage

Both dimensions. A box with a visible fill takes the size of what is inside it; the stage
is not an argument.

```
height  row     flex:none        — from the tallest child, not the stage
        child   flex:1           — every sibling matches that tallest child
        group   wrapped in flex:1 … justify-content:center

width   box     align-self:flex-start; max-width:100%
```

`.fit` is a column flex with `align-items:stretch`, so **every child is full-width by
default**. A monospace panel that shipped here measured 1408px of fill around 551px of
text — 44 % filled — purely from that default. `align-self:flex-start` opts one box out
and it shrink-wraps; `max-width:100%` keeps a long line inside the safe area. No width is
ever written.

The exception is a **row of peers** — cards, columns, flow nodes. Those stay equal width
and share the safe area, because hugging each one individually leaves a ragged row. So:
one box hugs, a row of boxes divides.

`flex:1` on the **row** looks like the same thing and is not: it makes the row fill the
stage, so the children inherit the stage's height and you get a 60 %-empty slab of colour.
`color-cards` shipped that way — its content reached 51 % of the cards. It now hugs.
Under the uneven-content stress test the three cards read 451/451/451: equal to each
other, and equal to the tallest card's content rather than to the slide.

Reserve `flex:1` on the box itself for things that genuinely should fill: an image frame,
a chart plot area.

On a sparse KPI or quote page, the heading and its single content group are one vertical
composition. `kpi-grid`, `kpi-cards`, and `big-quote` mark that wrapper with
`data-vertical-group="center"`; centre the complete wrapper in the safe-height band. Do
not pin the heading at the top and centre only the row beneath it.

## Colour: two rules the reference enforces and I broke once each

**`--ink` is not a panel colour.** In the reference it grounds exactly two things: the
6cqw circular `node`, and a small pill badge. Nothing larger. A big dark rounded
rectangle is not in bloom's vocabulary and reads as a photo placeholder — the `mindmap`
hub used one until it was pointed out that it looked like an image. It now takes `--g1`.
Two monospace layouts that leaned on the same dark slab were removed outright rather than
recoloured.

**Three tokens are fill-only.** Measured against the `#FFFDF7` page:

| token | contrast on cream | use as |
|---|---|---|
| `--ink` 16.6 · `--soft` 7.1 · `--g3` 4.8 · `--g0` 4.5 · `--s1` 3.9 | pass | text or fill |
| `--s2` 1.8 · `--accent` 2.6 · `--s3` 2.5 | fail | **fill only** |

`--s3` passes as a *ground* (`--g3` is its dark sibling) but fails as *text*. The
reference uses `--s2` and `--s3` as a text colour once each in 17 pages, against 64 uses
of `--ink` and 23 of `--ka`. For a small coloured label on cream, cycle
`--s1 --g0 --g3`. On a `--g?` ground use the matching `--t?`, never a scheme colour.

Checked on all 32: zero text below 3.0:1.

## Panels: never `--surface`

`--surface` is `#FFFFFF` on a `#FFFDF7` page — a white rectangle on cream. The reference
deck uses it zero times; earlier versions of these layouts used it 21 times and it is the
main thing that made them look cheap. Panels here are now:

- **no fill + a hairline rule** for anything holding prose (the reference's default)
- `--ink` ground with `--bg` text for a small hub or pill, never a large panel
- `--g0..--g3` ground with matching `--t0..--t3` for icon tiles
- `--ph` for an image frame

`section-divider`, `close` and `stat-highlight` are **full-bleed**: the ground colour is
on `.stage`, not on a box inside it. 5 of 17 reference pages are full-bleed, so roughly
one page in four should be a colour field rather than cream. On a full-bleed page a
kicker uses `color:inherit;opacity:.72`, never `--ka` (which is `--ink` and vanishes).

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` ·
structure `stage fit deck slide band card tile badge` ·
marks `dot tick soft dim pagenum`.

Sizes live in those classes. If something needs to be bigger, use the next class up —
do not write a `font-size`.
