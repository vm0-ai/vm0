# Bloom historical decoration-placement notes

> Provenance only. This file preserves measurement history and may describe superseded
> behaviour. `../authoring-core.md` is authoritative and this file is not part of the
> normal generation read path.

Everything here is measured from the original reference deck (17 pages, 33 decoration
elements). Numbers, not taste.

Open `decoration.html` to see each rule rendered with no text on the page.

## The layer model

A bloom slide is three independent layers. Build them in this order and they cannot
fight each other:

| z-index | layer | where it comes from |
|---|---|---|
| 0 | decoration | this folder |
| 40 | `.fit` — all text | `../layouts/*.html` |
| 45 | pagenum | the shell |
| 60 | persistent chrome | fixed, see A below |

Decoration sits **below** text and is never inside `.fit`. If a layout and an ornament
collide, move the ornament — never the copy.

## A · Persistent chrome — identical on every page

Three items, fixed position and size. Copy them verbatim onto every slide:

- `left:4cqw; top:4.6cqh` — wordmark, `1.55cqw`, the trailing `.` is `var(--s1)`
- `left:50%; top:5cqh` — centred label, `1cqw`, `letter-spacing:.2em`, `opacity:.82`
- `right:4cqw; top:3.9cqh` — outlined pill, `1.6px solid var(--ink)`, `border-radius:999px`

## B · The pair — the rule that is most often missed

**15 of 17 reference pages carry exactly two big ornaments, one flower + one petal.**

Measured across 10 generated decks (330 ornaments): the average is **1.1 per page**, and
1 is the single most common count on every deck. The vocabulary is copied correctly; the
*pairing* is not. Put two on a normal content page.

Within a pair:

- **different shapes** — one `flower`, one `petal`
- **different fills** — 14/14 reference pairs use two different variables out of
  `--s1 --s2 --s3 --accent`
- **different sizes** — big 20–26cqw, small 12–18cqw (median 22cqw, full range 12–30cqw)
- **opacity 0.7–0.92**, never 1
- **`z-index:0`**

## C · Bleed — already being done correctly, keep doing it

31 of 33 reference ornaments hang off the stage edge, by **0.27–0.83× their own width**.
Generated decks measure 96% — this one is learned; do not regress it.

Anchor with a negative offset (`left:-14cqw`, `bottom:-15cqh`). Only one reference
ornament sits fully inside the stage, and it is a 12cqw flower tucked beside a photo.

Which edge:

- content pages → both at `bottom`, one left one right
- section dividers and the closing page → symmetric, same size, mirrored at `bottom`
- when the copy occupies the lower half → move the pair to `top` (bleed shrinks to 0.27–0.5)

## D · Vocabulary — 7 items, nothing else

| name | marker | what it is |
|---|---|---|
| flower | `data-bigcircle` | 4 rounded `<rect>` rotated 0/45/90/135 inside a `<g rotate>` |
| petal | `data-bigcircle` | one organic `<path>` blob |
| tile | `data-tile` | rounded square, `var(--g0)` ground, 24×24 stroke icon at 52% |
| node | `data-node` | circle, `--g0..--g3` ground cycling, icon in the matching `--t?` |
| bbadge | `data-bbadge` | 24-point starburst polygon, `var(--accent)` |
| photocell | `data-photocell` | image frame, `var(--ph)`, `border-radius:var(--r-lg)` |
| connector | `data-connector` | `.55cqh` hairline, `color-mix(--ink 24%)`, `z-index:0` |

Do not invent plain circles, rectangles or triangles. One generated deck out of ten did,
and it is the deck that reads least like bloom.

## D2 · Small ornaments belong to item sets — measured, and regressed once

The first version of this file gave the big ornaments a number and a position and
left `tile` / `node` / `bbadge` / `connector` as a bare vocabulary list. The next 18
generated decks obeyed the number and dropped the rest: small ornaments fell from
0.214 per page to **0.022**, and the starburst from 0.137 to **0.011** (p=0.0043).
The reference is 0.706 and 0.18. What is not stated as a rule does not survive.

The rule, measured from the original reference deck: small ornaments are **not
sprinkled**. They are the visual device of one page type — a set of 3–4 peer items —
and on those pages **every item gets one**. Three of 17 reference pages are item-set
pages; each carries 3 or 4 ornaments, never 1 or 2.

Open [item-sets.html](item-sets.html) for the three treatments as copyable markup.

| the items are | ornament | size | colour |
|---|---|---|---|
| capabilities, features, categories | `tile` | 4.6cqw square | ground cycles `--g0..--g3`, icon `--t0..--t3` |
| ordered stages | `node` + one `connector` | 6cqw circle | ground cycles `--g0..--g3`, icon in the matching `--t?`; connector `.55cqh` hairline at `z-index:0` |
| claims or numbers to emphasise | `bbadge` | 7cqw starburst | `--accent` / `--s1` / `--s3`, index in `--bg` |

Within one set the colours differ, exactly as with the big pair. When the peer items
are themselves paragraphs of prose, use a hairline rule instead — an ornament next to
a three-line paragraph competes with it. That is why only 3 of 17 pages carry these.

## D3 · Never use `--surface`

`--surface` is `#FFFFFF` and the page is `#FFFDF7`. A `--surface` panel is a white
rectangle on cream: no contrast, no meaning, and it is the single ugliest thing these
decks do. The reference uses it **zero times** in 17 pages. Generated decks average
25–38 uses each.

The reference's actual panel palette:

| purpose | value |
|---|---|
| full-bleed page ground | `--g0..--g3` with matching `--t0..--t3` on `.stage` |
| icon tile | `--g?` ground, `--t?` icon |
| image frame | `--ph` |
| a pill badge | `--ink` ground, `--bg` text — the only thing `--ink` grounds |
| a panel of body text | **no fill** — separate it with a hairline rule |

5 of 17 reference pages are full-bleed: every section divider, the closing page, and
one content page. Roughly one page in four should be a colour field, not cream.

`--ink` is not on that list, and as of this revision it does not ground the `node`
either. **This one deviates from the reference deliberately.** The reference's p9 puts
four 6cqw `--ink` discs on a line and it reads fine at four; a generated deck put seven
across a slide and the row read as a bar of black holes. Nodes now cycle `--g0..--g3`
with the matching `--t?`, which keeps them inside the palette and distinguishes the
stages from each other. `--ink` is left for pill badges only.

A large dark rounded rectangle also reads as a photo placeholder, not as a bloom panel.

And three tokens are fill-only, measured against the `#FFFDF7` page: `--s2` 1.8:1,
`--s3` 2.5:1, `--accent` 2.6:1. They colour ornaments, never type on cream. Legible
label colours are `--s1` 3.9, `--g0` 4.5, `--g3` 4.8, `--soft` 7.1, `--ink` 16.6.

## D0 · The top 11% belongs to the chrome

The three persistent items sit between 3.9cqh and about 8cqh. `.fit` therefore starts its
content at `12cqh` and **nothing may begin above 11% of the stage height**.

Measured: the reference has **zero** text above that line. One generated deck had five,
and on one page the section kicker landed directly on top of the wordmark. Another deck
from the same batch had zero, so this is a per-page slip, not a deck-wide habit — which
is exactly the kind of thing a check catches and a paragraph does not.

Exact-equality criterion, reference reads 0.

## D0b · Everything stays inside the safe area

The safe area is `6cqw` on each side — a template constant, set once by the padding on
`.fit`. It is not a per-page choice, and a page that sets less padding has not widened
its safe area, it has broken it.

Measured: the reference has **zero** text runs starting left of 6 % or ending right of
94 % of the stage, out of 149. One generated deck had two paragraphs flush against the
stage's left edge at 0.0 %; two other decks from the same batch had none.

This is a different defect from overflow. Overflow means text crossed the stage edge;
this means text stayed inside the stage and left the safe area. A deck can read 0 on
overflow and still have a paragraph glued to the bezel.

Exact-equality criterion, reference reads 0.

## D4 · Peer columns align on their first line

Measured: the reference has **zero** rows where two peer columns start their text at
different heights. One generated deck had **six**, the worst off by 369px.

The trap is a filled panel beside plain copy. The panel's own padding pushes its first
line down, so the two headings no longer line up even though the boxes do. Either give
both columns the same treatment, or match the plain column's top padding to the panel's.

This is an exact-equality criterion — the reference reads 0 — so it is checkable, not a
matter of taste.

## E · Ornaments that depend on photography

`photocell` is the image frame itself. When the source has no imagery, **delete the frame
entirely** — do not leave an empty box and do not substitute a grid of rounded rectangles
for it. A missing photo legitimately means a missing frame.

## F · When to place nothing

3 of 17 reference pages carry a single ornament. A page whose copy already fills the
stage may carry none at all — that is still on-template as long as the colour system is
bloom's. An ornament crowded against text is worse than no ornament.

## Verifying your own deck

```
per-page big-ornament count      reference 1.94   before 1.23   after 1.84
pages with a pair (>=2)          reference 82%    before 24%    after 81%
bleeding ornaments               reference 94%    before 96%    after 99%
small ornaments per page         reference 0.71   before 0.21   after 0.02  <-- regressed
starburst per page               reference 0.18   before 0.14   after 0.01  <-- regressed
off-vocabulary shapes            reference 0      before 2      after 0
uses of --surface                reference 0      before 38/deck after 25/deck
full-bleed pages                 reference 29%
```

The two regressed rows are why D2 exists. Check them, not just the pair.
