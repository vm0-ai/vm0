# Bloom authoring core

This file is the sole authority for normal Bloom authoring. If a historical note,
example, or placeholder disagrees with it, this file wins.

## Read and assembly contract

Read `tools/qa-config.json`, this file, `layouts/shell-contract.md`, the chosen layout
fragments, and one colour-system CSS in a single batch. Read an optional copyable
resource only when a chosen slide needs it. Never read `reference/`, the full-page
showcases, `layouts/shared-shell.html`, unselected layout fragments, or QA implementation
files during normal generation.

The package contains exactly one shared shell and 32 selectable stage fragments. A
fragment is one complete `.stage`; it intentionally contains no document shell, shared
CSS, `.deck`, `.slide`, or runtime.

To assemble the deck through the shell contract:

1. Run `cp layouts/shared-shell.html <deck>.html` without opening the shell; keep its CSS
   and scripts once and edit only the anchors named by `layouts/shell-contract.md`.
2. Inline the chosen `color-systems/<token>.css` and remove the local stylesheet link.
3. Between `BEGIN SLIDES` and `END SLIDES`, create one direct-child
   `<div class="slide">...</div>` per page and place one adapted stage fragment inside.
4. Set the root language, title, colour token, deck label, and per-slide chrome from the
   actual presentation.

## Layout index

- Opening and navigation: `cover`, `toc`, `section-divider`, `close`.
- Prose and lists: `two-column`, `three-column`, `color-cards`, `bullets`, `big-quote`,
  `todo-checklist`.
- Comparison: `comparison` for quiet peers, `versus` for a loud diagonal contrast,
  `pros-cons` for trade-offs.
- Numbers: `kpi-grid`, `kpi-cards`, `stat-highlight`, `table`, `chart-bar`, `chart-line`,
  `chart-pie`, `chart-radar`.
- Time and sequence: `process-steps`, `timeline`, `roadmap`, `gantt`.
- Structure: `arch-diagram`, `flow-diagram`, `mindmap`.
- Source-supported imagery: `image-left`, `image-right`, `image-hero`, `image-grid`.

Select the fragment by what the slide must communicate, not by filling a catalogue.
Reuse is allowed, but vary composition with the story.

## Geometry and typography

- The stage is 16:9. Narrative content lives inside one `.fit` with `6cqw` horizontal
  safe-area padding and begins below the 11% chrome band. Persistent chrome is outside
  `.fit`.
- Center the complete narrative group inside the safe area. In a side-by-side layout,
  center each peer within its column. In a stacked layout, center the whole stack.
- Keep `4cqh` between the primary title and the next narrative block.
- Peer rows are content-sized with `align-items:stretch`; equal-width peers use
  `flex:1;min-width:0`. The tallest peer sets row height. Never reserve an empty column.
- Narrative text stays flexible. Do not assign `width`, `max-width`, `height`,
  `flex-basis`, `left`, `top`, `right`, or `bottom` in `cqw`, `cqh`, `px`, `vw`, or
  `vh` to prose-bearing flow elements. Absolute pill labels may use fixed placement.
  Plot and media lanes may use deliberate fixed geometry only when their root carries
  `data-fixed-geometry-ok`.
- Use the shell's typography classes (`display`, `h1`, `h2`, `h3`, `stat`, `kicker`,
  `lead`, `body`, `cap`) instead of inventing new sizes. Split dense content.
- A visible prose panel is sized by content. Use a hairline rule or a palette ground;
  do not stretch an isolated box across unused space.
- Keep media whole with `object-fit:contain`. A fixed-ratio media cell may shrink and
  center; full-bleed imagery keeps its authored role.

## Colour authority

Use exactly one supplied `color-system` token, or choose one preferred token:
`carnival`, `berry_pop`, `citrus_fresh`, `coral_studio`, `mint_tech`, `pop_art`,
`prism`, `sunset_maroon`, or `terracotta_clay`.

- Never use `--surface` as a live background. `.card` is transparent unless it receives
  an explicit permitted ground.
- Information pages use `--bg`. A body-text panel has no fill and uses a hairline rule.
- Full-bleed section, closing, or occasional key pages may put `--g0..--g3` on `.stage`
  with the matching `--t0..--t3` text. Do not place another filled panel on that field.
- Tiles and nodes cycle `--g0..--g3` with matching `--t0..--t3`.
- `--ink` may ground only a small pill badge, with `--bg` text. It never grounds a node,
  prose card, or large rounded rectangle.
- `--ph` is reserved for a real image frame. `--s2`, `--s3`, and `--accent` are
  ornament fills, not body text on cream. Do not introduce black, white, or off-palette
  colours.

## Required chrome

Every stage carries the roles declared by `tools/qa-config.json`. Use these positions;
replace placeholder copy with stable deck-specific copy and use `currentColor` so the
same chrome remains legible on cream and full-bleed stages:

```html
<div data-chrome="wordmark" class="kicker" style="position:absolute;left:4cqw;top:4.6cqh;z-index:60;font-size:calc((1.55cqw)*var(--fit,1));letter-spacing:.01em;text-transform:none;color:currentColor">COMPANY<span style="color:var(--s1)">.</span></div>
<div data-chrome="running-head" class="kicker" style="position:absolute;left:50%;top:5cqh;z-index:60;transform:translateX(-50%);font-size:calc((1cqw)*var(--fit,1));letter-spacing:.2em;color:currentColor;opacity:.82">PRESENTATION</div>
<div data-chrome="action" data-device="chrome" style="position:absolute;right:4cqw;top:3.9cqh;z-index:60"><div class="kicker" style="border:1.6px solid currentColor;border-radius:999px;padding:.95cqh 1.5cqw;font-size:calc((.92cqw)*var(--fit,1));letter-spacing:.13em;color:currentColor">KEY MESSAGE</div></div>
<div data-chrome="page-number" class="pagenum">01</div>
```

## Decoration vocabulary

Decoration is optional, textless, outside `.fit`, below narrative content at
`z-index:0`, and subordinate to legibility. When exact motif markup is needed, batch-read
only `resources/decoration-motifs.html`; for a peer item set, batch-read only
`resources/item-sets.html`. The full-page files under `decoration/` are provenance
showcases, not generation resources.

- Large motifs are `flower` (four rotated rounded rectangles) and `petal` (one organic
  path), marked `data-bigcircle`. A roomy content page normally pairs one of each with
  different palette fills and sizes, opacity `.7–.92`, bleeding from opposite edges.
  Section dividers and closing pages use a mirrored pair. Omit them when content is full.
- Small peer-item motifs are `tile` for capabilities, `node` plus one `connector` for
  ordered stages, or `bbadge` for an emphasized claim. Give every item in that set the
  chosen motif; do not sprinkle a single one among plain peers.
- The complete vocabulary is `flower`, `petal`, `tile`, `node`, `bbadge`, `photocell`,
  and `connector`. Do not invent substitute circles, squares, arches, or colour blocks.
- If decoration approaches text, move or remove decoration. Never move, shrink, or drop
  content to accommodate it.

## Source, images, tables, and charts

- Use supplied content and evidence. An image is content, not filler: use supplied media
  first and remove an unsupported image frame completely.
- For a table or repeated records, batch-read `resources/data-table.html` and adapt its
  one packet. Identifier and numeric columns stay content-sized; prose absorbs remaining
  width. `composition-recipes.html` is a full provenance showcase, not a generation
  resource.
- Use a stat for one number, KPI peers for a handful, a table when many classes all
  matter, bars for magnitude, lines for time, and a stacked form for part-to-whole.
- Use one shared baseline, no dual axes, selective direct labels, and a legend only for
  multiple series. Colour identifies an entity or emphasis; it is not a rainbow scale.

## Verification ownership

Author against these rules once. Rendered structure, navigation, safe area, overflow,
media, live `--surface`, and fixed narrative geometry are enforced by the existing final
QA. Do not repeat those mechanical checks manually before or after it.
