# playful-launch — optional decoration placement

Every number below was measured from the original reference deck at 1600×900 across
15 pages. Optional decoration is classified before it is counted: it is
template-specific, textless, carries no data, and performs no layout function.

## Optional vocabulary — two types only

| optional decoration | reference count | per page | role                                       |
| ------------------- | --------------: | -------: | ------------------------------------------ |
| `burst-star`        |              26 |     1.73 | textless edge or corner accent             |
| `big-circle`        |               1 |     0.07 | one cropped counter-shape on a climax page |

The reference contains 34 burst shapes in total. Eight carry text or data —
`2026` twice, three list numbers and three KPI figures — so those eight are
content devices, not optional decoration. Only the 26 textless instances enter
the decoration count.

## What is explicitly not decoration

| element                              | reference count | classification                                  |
| ------------------------------------ | --------------: | ----------------------------------------------- |
| plus-mark                            |              29 | fixed chrome; excluded from optional statistics |
| pill-tag                             |              14 | labelled content badge                          |
| photo cell                           |              10 | source-dependent media content                  |
| circular feature tile                |               4 | content-bearing feature icon                    |
| process node + connector             |           4 + 1 | sequence structure                              |
| numbered / metric burst              |               8 | text or data carrier                            |
| diagonal field                       |               2 | layout background                               |
| card, colour block, panel, grid cell |             n/a | content container or layout structure           |

Do not relabel a square, tile, card, rectangle, background field, content
container, grid cell, node or connector as decoration. Do not invent arches,
waves, dots, blobs or outlined boxes to increase a count. There is no
`item-sets.html` because this reference has no optional textless motif attached
to every member of a repeated set.

## `burst-star` placement

The 26 optional burst-stars have a clean, non-bleeding distribution:

- **0 of 26** cross a stage edge.
- **25 of 26** have a centre in the outer horizontal band: x below 25% or above 75%.
- **19 of 26** sit in a corner quadrant.
- **13 of 26** sit in the lower half.
- Sizes are **3–8cqw, median 5cqw**.
- Every page has at least one textless burst; **8 of 15** pages have at least two.

Place a burst in the free corner or edge left by the content. It may overlap a
photo or colour field only where the closest reference page role does so. It
never covers copy and never hangs off the stage.

The reference fill distribution across all burst shapes is `--accent` 22,
`--bg` 7, `--ink` 2, `--s2` 2 and `--s1` 1. Textless stars may use any source
fill. A burst carrying a number is no longer decoration and must use a
contrast-safe pair such as `--gN` / `--tN` or `--bg` / `--ink`.

## `big-circle` placement

The reference has exactly one: `77.9cqw`, cropped by the right stage edge on
p12, below content at `z-index:1`. Use it once for a data or narrative climax,
not as a repeated texture.

## Background rhythm and chrome

Six of 15 reference pages (40%) use a full-stage colour field. The cover and
closing page are both fields in different hues. Nothing sits in a filled box on
those six pages.

Chrome is required but counted separately from optional decoration:

1. constant hashtag footer, bottom-left;
2. two-digit page number, bottom-right;
3. normally two plus-marks in opposite corners (14 of 15 pages; the diagonal
   page has one).

The chrome occupies the bands outside `.fit`; optional decoration must not be
used to replace it.
