# playful-launch — naked layouts

38 layouts, content and structure only. No optional decoration, no measured geometry.
Pair one of these with `../decoration/PLACEMENT.md` to build a slide.

The removed full-deck HTML example was produced by measuring a rendered deck and writing the numbers
back, so its `width:48cqw` and `min-height:38.35cqh` are observations of one string at one
font size, not design decisions. Copying them reproduces that string. These files carry
none of them.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 38: zero `width` / `max-width` / `min-width` / `height` / `left` /
`top` / `right` / `bottom` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex-basis`. `flex:0 0 4cqw` freezes exactly the way a `width` does.

Three exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline rule.
- text that merely _displays_ a CSS string. Strip text nodes before matching.

Two more, both deliberate:

- **`font-size`** on a non-prose visual device, which then sizes itself
  `width:1em;height:1em`. The metric star, icon tile and circular photo cell all work
  this way. A figure inside
  a star is `.3em` **of the star**, so it is measured against the star and never against
  the stage — which is also why a star can be any size without the number falling out of
  proportion.
- **`%`** in `chart-bar` and `gantt` only, where the number _is_ the datum. A bar at
  76% is reporting 76, and a Gantt offset reports its place on the schedule; neither is
  a text-box sizing choice.

**Example copy is audience-facing copy.** Every string in these files is a line from
the fictional Tomorrow Lab deck. A sentence that explains the layout to whoever is
reading the file — why a column is half the row, why a marker is a star, what a bar
offset encodes — belongs in this README or in `SKILL.md`, never in a slide. It renders
into the deck, into the contact sheet, and into anything generated from the file.

Everything else stretches. Columns are `flex:1`. The safe area is set **once**, by the
padding on `.fit` (`11cqh 6cqw 9cqh`), and no text-bearing layout group writes a
stage-measured margin or width.

Measured on the reference: content sits between 6.1% and 93.9% of stage width. 6% is this
template's safe-area constant — the same number `audit.js` checks against.

Equal height is stress-tested, not assumed. An extra wrapping sentence was injected into
the first peer of every wide flex row, then all sibling heights were measured. The 31
peer rows across this set finish with a maximum spread of 0px. The agenda's two halves
initially differed by 58.1px because its row used `align-items:flex-start`; it now
stretches the halves structurally.

## The three structural rules

**A filled box is sized by its content, never by the stage.** The peer row is `flex:none`
so its height comes from the tallest card; each card is `flex:1` so the siblings equalise
to it. `flex:1` on the _row_ would make the cards inherit the stage's height and you get a
slab of colour that is half empty.

**A content group centres in the height left over.** `.stack` (`flex:1;min-height:0;
justify-content:center`) wraps the row under a title. The row still hugs its own content;
the page just is not top-heavy. 25 of 38 layouts use it. Layouts that already centre their
whole column (`cover`, `section`, `statement`, `big-quote`, `close`) and layouts whose
content region genuinely fills (`chart-*`, `stat-hero`, `image-left/right`) do not.

**One box hugs, a row of boxes divides.** `.fit` is `align-items:stretch`, so every child
is full width by default. `.hug` (`align-self:flex-start;max-width:100%`) opts one out.

## Colour, measured across all six preferred colour systems

`--accent`, `--s1`, `--s2`, `--s3` are **fills, never text**. As text on `--bg` they read
1.44–2.56:1 depending on the system. Only two hue tokens clear 3.0:1 everywhere:

| as text on `--bg`                 | worst case across the six systems |
| --------------------------------- | --------------------------------- |
| `--g0`                            | 4.01                              |
| `--g3`                            | 4.11                              |
| `--ka` / `--k1` / `--k2` / `--k3` | 4.94                              |
| `--s1`                            | **1.44**                          |
| `--g1`                            | **1.44**                          |
| `--g2`                            | **1.48**                          |
| `--surface`                       | **1.00**                          |

`--surface` is `#FFFFFF` on a `#FFFDF7` page — an invisible box. It is used zero times
here, and once in the reference (as an unused class definition).

**A chip that carries text uses `--gN` with its matching `--tN`, or `--ink`/`--bg`.**
Every `--tN`/`--gN` pair is ≥4.60:1 in every system. `--accent` with `--oa` is **2.36**
worst case — it is for icons and symbols, not for words, and that includes the figure
inside a burst-star.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions. Not a
slide. Every layout inlines the same block.

|                     | ruled          | filled        |
| ------------------- | -------------- | ------------- |
| three peer columns  | `three-column` | `color-cards` |
| two things compared | `comparison`   | `versus`      |

`kpi-row` and `kpi-field` are **not** a ruled/filled pair. They are two different
counts on two different structures: `kpi-row` is three metric-carrying bursts in one
row, `kpi-field` is six ruled figures in two rows on a full-bleed ground. A layout
that differs from another only by colour token is a variant of it, not a second
layout — record the variant here instead of adding a file.

- **openers** `cover` `toc` `section`
- **prose** `statement` `longform` `bullets` `numbered-list` `two-column`
  `three-column` `color-cards`
- **with pictures** `image-left` `image-right` `image-hero` `image-grid` `team`
- **structure** `feature-grid` `process-steps` `timeline` `roadmap` `gantt`
  `architecture` `mind-map` `table`
- **figures** `kpi-row` `kpi-field` `stat-hero` `chart-bar` `chart-line` `chart-donut`
- **argument** `comparison` `versus` `pros-cons` `pricing`
- **evidence** `case-study`
- **voice** `quotes` `big-quote`
- **launch-specific** `launch-readiness`
- **closer** `close`

### Purpose inventory

| Layout             | Communication job                                             |
| ------------------ | ------------------------------------------------------------- |
| `cover`            | Open with the presentation promise and identity.              |
| `toc`              | Preview the sequence or agenda.                               |
| `section`          | Mark a chapter transition.                                    |
| `statement`        | Let one declarative sentence carry the slide.                 |
| `longform`         | Support sustained editorial reading with one contextual note. |
| `bullets`          | Present a compact unordered set of points.                    |
| `numbered-list`    | Present an ordered set of actions or priorities.              |
| `two-column`       | Develop two parallel prose threads.                           |
| `three-column`     | Present three ruled peer ideas.                               |
| `color-cards`      | Present three filled peer ideas.                              |
| `image-left`       | Put visual evidence left of its explanation.                  |
| `image-right`      | Put visual evidence right of its explanation.                 |
| `image-hero`       | Let one large image carry the slide.                          |
| `image-grid`       | Show a multi-image gallery.                                   |
| `team`             | Introduce people with role and portrait cells.                |
| `feature-grid`     | Group capabilities or services.                               |
| `process-steps`    | Explain a directional sequence.                               |
| `timeline`         | Place milestones on dated intervals.                          |
| `roadmap`          | Show phases that each end in a proof point.                   |
| `gantt`            | Show overlapping workstreams against time.                    |
| `architecture`     | Explain system layers and their components.                   |
| `mind-map`         | Branch one central idea into related themes.                  |
| `table`            | Compare aligned records and values.                           |
| `kpi-row`          | Give three figures the weight of the page, one burst each.    |
| `kpi-field`        | Lay six supporting figures out as a read-across field.        |
| `stat-hero`        | Make one headline metric the evidence.                        |
| `chart-bar`        | Compare categorical quantities.                               |
| `chart-line`       | Show change over time.                                        |
| `chart-donut`      | Show parts of a whole.                                        |
| `comparison`       | Weigh two options with ruled structure.                       |
| `versus`           | Stage a more emphatic filled head-to-head.                    |
| `pros-cons`        | Separate benefits from trade-offs.                            |
| `pricing`          | Compare plans or tiers.                                       |
| `case-study`       | Connect a challenge and intervention to a result.             |
| `quotes`           | Present several voices as peer evidence.                      |
| `big-quote`        | Let one attributed line carry the slide.                      |
| `launch-readiness` | Review launch signals and go/no-go status.                    |
| `close`            | End with the final thought and contact line.                  |

There is no generic `flow-diagram` alias: `process-steps` carries a sequence,
`architecture` carries dependency layers, and `mind-map` carries non-linear branches.
Those three communication jobs remain visually and structurally distinct.

## Content devices stay in the layout layer

Classification is explicit: feature tiles, process nodes and their connector,
number-carrying bursts, metric-carrying bursts, photo cells, cards and chart marks all
communicate content or perform layout work. They therefore remain in these files and are
excluded from optional decoration statistics.

Only the textless `burst-star` and the one `big-circle` are optional decoration. Add them
afterwards from `../decoration/decoration.html` using the measured placement rules in
`../decoration/PLACEMENT.md`. Fixed plus-marks, footer and page number are chrome, also
counted separately.
