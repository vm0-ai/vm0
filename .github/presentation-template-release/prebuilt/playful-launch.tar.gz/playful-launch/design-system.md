# Playful Launch

## Visual identity

High-saturation colour fields coexist with editorial restraint. Radial burst badges, pill labels, large circles, and stacked titles create a joyful, clear launch character.

## Color system tokens

Read the prompt's `color-system` before generating. If it provides one of the valid tokens below, use that token exactly. If it does not, the Agent selects a token based on the content, audience, mood, information density, and readability. Use only one token per deck.

The demonstration category documented for this template is **V (multicolour)** and its example token is `carnival`; select the generation token using the rule above.

Use only these exact snake_case token values:

- Single dominant colour M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`carnival`, `pop_art`, `prism`, `citrus_fresh`, `berry_pop`, `bauhaus_primary`

The default color system used in `example/reference.jpg` is `carnival`.
The identity is high-saturation and joyful. Muted, corporate, or dark tokens (`slate_corporate`, `mono_ink`, `midnight_mono`, `sunset_maroon`, `nordic_frost`) drain the template of its character and must not be chosen by default.

After choosing a token, read `color-systems/<token>.css`, inline its single CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="carnival"></html>
```

- Use `--bg`, `--surface`, `--ink`, `--soft`, and `--ph` for the page, surfaces, body text, secondary text, and image placeholders.
- `--accent`, `--s1`, `--s2`, and `--s3` are the source hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected by v1 for those source hues; use them for large icons or decorative symbols. Use the contrast-safe text tokens below for normal text.
- For text on the standard `--bg`, use the contrast-safe `--ka`, `--k1`, `--k2`, and `--k3`. Use `--kad` for accent text on an `--ink` field. When a source hue needs stronger text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour fields containing text, use `--g0` through `--g3` and pair each with the matching `--t0` through `--t3`.
- HTML/CSS components reference only `var(--...)`; derive translucent layers, outlines, shadows, and gradients from defined tokens as well.

Use `--bg` for standard content, `--g2` for hero colour fields, `--g3` for chapters and closing slides, and `--g1` for data climaxes. Use `--accent` and `--s3` for textless stars and non-text graphics. A pill that carries text uses `--gN` / `--tN` or `--ink` / `--bg`.

```css
.slide {
  background: var(--bg);
  color: var(--ink);
}
.surface {
  background: var(--surface);
}
.muted {
  color: var(--soft);
}
.safe-emphasis {
  color: var(--ka);
}
.accent-shape {
  background: var(--accent);
  color: var(--oa);
}
.accent-field {
  background: var(--g0);
  color: var(--t0);
}
```

## Typography tokens

Use `Archivo` for display type and `Manrope` for body type.

```html
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link
  href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600&family=Manrope:wght@300;400;500;600&display=swap"
  rel="stylesheet"
/>
```

```css
:root {
  --fd: "Archivo";
  --fb: "Manrope";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display:
    "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC",
    sans-serif;
  --cjk-body:
    "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC",
    sans-serif;
}

h1,
h2,
h3,
.display,
.kpi {
  font-family: var(--fd), var(--cjk-display);
  font-weight: var(--fw-display);
}
.kicker,
.label {
  font-family: var(--fd), var(--cjk-display);
  font-weight: var(--fw-label);
}
body,
p,
li,
table {
  font-family: var(--fb), var(--cjk-body);
  font-weight: var(--fw-body);
}
```

Available display weights are 400 / 500 / 600; available body weights are 300 / 400 / 500 / 600. Use `--fd` for titles, hero numbers, and chapter numbers; use `--fb` for body text, labels, chart annotations, and tables. CJK text preserves the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the template's own base stylesheet. Copy it verbatim into the single
`<style>` block, immediately after the inlined colour-system CSS, before writing
any slide. It defines the 16:9 stage, the type scale, and the shared chrome,
decoration, and content-device helpers (`.kicker`, `.pagenum`, `.star`, `.tile`, `.photocirc`)
that the rest of this document refers to. A deck that invents its own class
names instead of using these will not look like this template.

The radius scale is part of the template's character, not a generic default —
do not replace it, and do not add a `border-radius` that is not one of these
tokens.

```css
:root {
  /* Playful Launch: hard-edged colour fields, but pills and full circles are signature. */
  --r-xs: 0;
  --r-sm: 0;
  --r-md: 0;
  --r-lg: 0;
  --r-xl: 0;
  --r-pill: 999px;
  --r-round: 50%;
  --fd: "Archivo";
  --fb: "Manrope";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display:
    "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC",
    sans-serif;
  --cjk-body:
    "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC",
    sans-serif;
}
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
html,
body {
  background: var(--ink);
  color: var(--ink);
  font-family: var(--fb), var(--cjk-body), sans-serif;
}
.deck {
  scroll-snap-type: y mandatory;
  height: 100vh;
  overflow-y: scroll;
}
.slide {
  width: 100vw;
  height: 100vh;
  scroll-snap-align: start;
  display: flex;
  background: var(--ink);
}
.stage {
  position: relative;
  width: min(100vw, 177.7778vh);
  height: min(56.25vw, 100vh);
  margin: auto;
  overflow: hidden;
  container-type: size;
  background: var(--bg);
  color: var(--ink);
  overflow-wrap: break-word;
  word-break: normal;
}
.stage * {
  overflow-wrap: break-word !important;
  word-break: normal !important;
}
.fit {
  position: absolute;
  inset: 0;
  transform-origin: top center;
  z-index: 40;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  padding: 11cqh 6cqw 9cqh;
}
img {
  max-width: 100%;
  object-fit: contain !important;
}
.photo,
[data-photocell] img {
  width: 100%;
  height: 100%;
  display: block;
}

.display {
  font-family: var(--fd), var(--cjk-display);
  font-size: 7cqw;
  font-weight: 600;
  line-height: 1;
  letter-spacing: -0.02em;
}
.h1 {
  font-family: var(--fd), var(--cjk-display);
  font-size: 4.6cqw;
  font-weight: 500;
  line-height: 1.04;
  letter-spacing: -0.01em;
}
.h2 {
  font-family: var(--fd), var(--cjk-display);
  font-size: 3.2cqw;
  font-weight: 500;
  line-height: 1.08;
  letter-spacing: -0.01em;
}
.h3 {
  font-family: var(--fd), var(--cjk-display);
  font-size: 1.95cqw;
  font-weight: 500;
  line-height: 1.18;
}
.stat {
  font-family: var(--fd), var(--cjk-display);
  font-size: 5.2cqw;
  font-weight: 600;
  line-height: 1;
  letter-spacing: -0.01em;
}
.kicker {
  font-family: var(--fd), var(--cjk-display);
  font-size: 1.15cqw;
  font-weight: 500;
  letter-spacing: 0.2em;
  text-transform: uppercase;
}
.lead {
  font-size: 2cqw;
  font-weight: 300;
  line-height: 1.5;
}
.body {
  font-size: 1.5cqw;
  font-weight: 400;
  line-height: 1.5;
}
.cap {
  font-size: 1.2cqw;
  font-weight: 400;
  line-height: 1.4;
  letter-spacing: 0.02em;
}
.pagenum {
  position: absolute;
  right: 3cqw;
  bottom: 3.2cqh;
  font-family: var(--fd), var(--cjk-display);
  font-size: 1cqw;
  font-weight: 500;
  letter-spacing: 0.06em;
  opacity: 0.65;
  z-index: 45;
}
.soft {
  color: var(--soft);
}
.dim {
  opacity: 0.84;
}
.hug {
  align-self: flex-start;
  max-width: 100%;
}
.grow {
  flex: 1;
  min-height: 0;
}
.stack {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.rule {
  height: 1px;
  background: currentColor;
  opacity: 0.18;
  flex: none;
}
.vrule {
  width: 1px;
  background: currentColor;
  opacity: 0.18;
  flex: none;
  align-self: stretch;
}
.star {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 1em;
  height: 1em;
  flex: none;
  line-height: 1;
}
.star > svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  display: block;
}
.star > span {
  position: relative;
  max-width: 74%;
  text-align: center;
  line-height: 1;
  font-family: var(--fd), var(--cjk-display);
  font-weight: 600;
  font-size: 0.3em;
  letter-spacing: -0.01em;
}
.photo {
  background: var(--ph);
  overflow: hidden;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  border-radius: var(--r-round);
}
.pill {
  display: inline-block;
  background: var(--ink);
  color: var(--bg);
  padding: 1cqh 1.6cqw;
  border-radius: var(--r-pill);
  font-family: var(--fd), var(--cjk-display);
  font-weight: 600;
  font-size: 1.3cqw;
  letter-spacing: 0.06em;
  text-transform: uppercase;
}
.tile {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  width: 1em;
  height: 1em;
  border-radius: var(--r-round);
  line-height: 1;
}
.tile > svg {
  width: 46%;
  height: 46%;
  stroke: currentColor;
  fill: none;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.photocirc {
  background: var(--ph);
  border-radius: var(--r-round);
  overflow: hidden;
  flex: none;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  width: 1em;
  height: 1em;
}
.bigcircle {
  position: absolute;
  border-radius: var(--r-round);
  z-index: 1;
}
.chrome-foot {
  position: absolute;
  left: 6cqw;
  bottom: 3.4cqh;
}
```

Text inside a `.star` must be wrapped in a `<span>`. The wrapper is `.3em` of
the ornament, so the figure stays in proportion at any size. Size ornaments
with `font-size`, never with `width`/`height`.

## Signature elements

These are the template's signature treatments, but they are not all decoration.
Classify first: only a textless `burst-star` and `big-circle` are optional
decoration. The plus-mark is fixed chrome; pills and photos are content; tiles,
nodes, connectors and number-carrying stars are content devices; fields are
layout ground.

Each element below is given as exact markup. Copy the snippet, keep its geometry
and its `var(--...)` colours, and change only size, position, and text content.
The listed counts describe reference usage; they are not minimums or delivery
quotas. Use only the elements supported by the closest reference page role.

## Element reference patterns

These counts are the exact inventory of the 15-slide rendered reference.
They help reveal the template's rhythm, but are neither floors nor a request to
fill every page. More ornament is not more fidelity: past a point it costs
legibility, which costs more than the ornament was worth.

| Element                        | Reference count     | Classification                           |
| ------------------------------ | ------------------- | ---------------------------------------- |
| textless `burst-star`          | 26                  | optional decoration                      |
| numbered / metric `burst-star` | 8                   | content device, excluded from decoration |
| `big-circle`                   | 1                   | optional decoration                      |
| `plus-mark`                    | 29                  | fixed chrome, excluded from decoration   |
| `pill-tag`                     | 14                  | labelled content badge                   |
| `circle-photo`                 | 10 cells on 4 pages | source-dependent media content           |
| circular icon tile             | 4                   | feature content device                   |
| process node + connector       | 4 + 1               | sequence structure                       |
| diagonal field                 | 2                   | layout ground                            |
| full-stage colour field        | 6                   | layout ground                            |

Do not scale these counts mechanically for a longer or shorter deck. Rows that
say _only what the material supports_ are content, not decoration: see the
photograph rule in `SKILL.md`. Use the table to check identity and page-role
rhythm, not to decide how many elements to add.

### 1. `burst-star` — the 20-point starburst badge

A spiky star polygon. This is
the loudest and most recognisable mark of the template. Keep the polygon points
exactly as written; they are what makes the star read as a burst rather than a
blob.

**Measured reference use: 26 textless optional stars and 8 stars carrying text
or data.** Every page has at least one textless star; 8 of 15 have at least two.
Vary the
fill between `var(--ink)`, `var(--accent)`, `var(--s1)`, `var(--s2)` and
`var(--bg)` across the deck. Optional stars are `3cqw`–`8cqw`, sit inside the
stage near corners and edges, and 0 of 26 bleed. Numbered and metric stars are
content devices in `layouts/`, not optional decoration. See
`decoration/PLACEMENT.md` for the measured placement distribution.

```html
<div
  class="star"
  data-decoration="burst-star"
  style="position:relative;font-size:7cqw;display:inline-flex;align-items:center;justify-content:center;width:1em;height:1em"
>
  <svg
    viewBox="0 0 100 100"
    style="position:absolute;inset:0;width:100%;height:100%;display:block"
  >
    <path
      d="M50 1 L58.01 14.9 L71.26 5.85 L72.45 21.85 L88.31 19.45 L82.43 34.38 L97.77 39.1 L86 50 L97.77 60.9 L82.43 65.62 L88.31 80.55 L72.45 78.15 L71.26 94.15 L58.01 85.1 L50 99 L41.99 85.1 L28.74 94.15 L27.55 78.15 L11.69 80.55 L17.57 65.62 L2.23 60.9 L14 50 L2.23 39.1 L17.57 34.38 L11.69 19.45 L27.55 21.85 L28.74 5.85 L41.99 14.9 Z"
      fill="var(--ink)"
    />
  </svg>
</div>
```

A numbered or metric star uses the same path but carries content and therefore
belongs in `numbered-list`, `kpi-row`, `kpi-field` or `stat-hero`. Use a
contrast-safe `--gN` / `--tN` pair.

### 2. `big-circle` — the oversized colour circle

A single huge circle in a supporting hue, pushed off the stage so it is cropped
by the edge. It gives the slide its curved counter-shape.

**Measured reference use: exactly one.** It is `77.9cqw`, partly outside the
right edge and `z-index:1` behind the text layer. Use it for one climax page,
not as texture.

```html
<div
  data-decoration="big-circle"
  style="position:absolute;right:-39cqw;top:50%;transform:translateY(-50%);
            width:78cqw;height:78cqw;background:var(--s2);border-radius:var(--r-round);z-index:1"
></div>
```

### 3. `plus-mark` — fixed chrome, not decoration

A thin `+` drawn in the current text colour, `1.8cqw` across, sitting in a
corner. It is the template's quiet punctuation.

**Measured reference use: exactly two on 14 of 15 pages**, in opposite corners
(for example top-right and bottom-left); the diagonal page has one.

```html
<svg
  style="position:absolute;right:5cqw;top:5cqh;width:1.8cqw;height:1.8cqw;z-index:2"
  viewBox="0 0 24 24"
>
  <path
    d="M12 3 V21 M3 12 H21"
    stroke="currentColor"
    stroke-width="2.4"
    stroke-linecap="round"
  />
</svg>
```

### 4. `pill-tag` — labelled content, not decoration

A fully rounded capsule holding one short uppercase phrase. Used for the brand
mark, chapter labels, and category tags.

**Measured reference use: 14 total.** The cover and closing slide each carry
one; all are short labels, never backgrounds on recurring chrome.

```html
<span
  style="display:inline-block;background:var(--ink);color:var(--bg);padding:1cqh 1.6cqw;
             border-radius:var(--r-pill);font-family:var(--fd),var(--cjk-display);font-weight:600;
             font-size:1.3cqw;letter-spacing:.06em;text-transform:uppercase;"
  >Tomorrow Lab</span
>
```

### 5. `circle-photo` — media content, not decoration

The normalized template treatment is a circular photograph.

**Measured reference use: 10 cells across 4 pages.** Two legacy cells are
rounded rectangles; the split layout library consistently uses circles. Use a
photograph only where the supplied material describes a subject worth showing.
If it describes no such subject, carry no photograph. Zero is valid.

```html
<div
  style="position:absolute;right:6cqw;top:14cqh;width:22cqw;height:22cqw;background:var(--ph);
            border-radius:var(--r-round);z-index:1;overflow:hidden;
            background-size:cover;background-position:center;background-repeat:no-repeat;
            background-image:url('<image>')"
></div>
```

### 6. `diagonal-split-panel` — layout ground, not decoration

For comparisons, split the stage with a diagonal rather than a straight line.

**Measured reference use: two diagonal fields.** Use one only when the page role
needs the template's angled comparison or field transition.

```html
<div
  style="position:absolute;inset:0 auto 0 0;width:56%;background:var(--ink);color:var(--bg);
            clip-path:polygon(0 0,100% 0,88% 100%,0 100%);z-index:1"
></div>
```

## Decoration reference profile (diagnostic only)

Observed from this template's own reference deck, per slide, rendered at
1600×900. These averages combine unlike page roles: covers, section dividers,
dense content pages, comparisons, and closings.

**These figures are diagnostics, never quotas or per-slide instructions.**
First choose the closest page role in [layouts/](layouts/),
then use only the named signature elements and motifs demonstrated in that
composition. A utility class, empty colour field, outlined box, circle, pill,
arc, quarter-circle, or other shell geometry is not a motif by itself.

| measured optional-decoration signal     | reference reading         | n           |
| --------------------------------------- | ------------------------- | ----------- |
| declared optional elements              | 27 total / 1.80 per page  | 15 pages    |
| textless burst-stars                    | 26 total / 1.73 per page  | 15 pages    |
| big-circles                             | 1 total / 0.07 per page   | 15 pages    |
| pages with at least two textless stars  | 8                         | 15 pages    |
| optional elements crossing a stage edge | 1 / 3.7% (the big-circle) | 27 elements |
| off-vocabulary optional SVG shapes      | 0                         | 27 elements |

Read the figures only as a whole-deck drift signal. Around half the reference
rate can be appropriate when the material or page-role mix differs. Judge
fidelity by motif identity, placement, and composition rather than item count.
Sparse slides are intentionally sparse.

Separately, the reference uses **6 full-stage fields across 15 pages (40%)**.
Those fields are ground, not decoration. It also fills **10 image cells across
4 pages (0.67 per page)**. That
is not a target: this template forbids inventing a photograph the source material
does not support, so a text-only source is right to draw none.

The reference also uses **14 pill-tags across 15 pages (0.93 per page)**. They
are role-bound labels, not permission to box recurring text.

**A kicker is not a chip.** In this template's reference deck the `kicker`, the
page number, the running head and the standfirst are plain text — no background,
no border, no shadow, no rounded pill around them. All recurring instances in
the 15-page reference agree on this, and giving them a box is the single most common way a
generated deck drifts: a kicker appears on every slide, so boxing it adds one
false chip per slide and doubles this template's labelled-box count on its own.

Only the pill-tag and number-carrying burst-star treatments demonstrated here
put text inside a filled mark.
Everything else that is text stays text.

**Before delivering, audit identity.** On three
representative slides, verify that every ornament maps to a named signature
element or to a specific composition in the reference. Use the table above only to notice gross whole-deck drift.

Content still comes first. Never push text off the stage, cover it, or drop a point. Never add a photograph
the source material does not support. A slide carrying six bullets may correctly
carry no optional ornament at all.

## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** Keep audience-facing text in normal flow
inside `.fit`; use Flexbox relationships rather than `left`, `top`, `right`, or
`bottom` coordinates. Fixed chrome is the only text-positioning exception. Give
a text block `max-width:100%` so it wraps rather than extends. CJK copy is
routinely wider than the Latin draft, so render the actual language before
delivery.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

Both faults hide from a quick glance at the whole deck and are obvious on the
slide itself. Before delivering, look at every slide that carries a set of
things and check that the set is aligned and that nothing touches an edge it was
not meant to touch.

## Required chrome

Every slide carries all three, or the deck is incomplete:

1. **Hashtag footer**, bottom-left — one uppercase hashtag derived from the deck's
   subject, constant across the whole deck:
   `<div class="kicker" style="position:absolute;left:6cqw;bottom:3.4cqh">#PlayfulMinds</div>`
2. **Page number**, bottom-right: `<div class="pagenum">04</div>` — two digits, zero-padded.
3. **Plus-marks** in opposite corners — normally two; the diagonal split may
   use the reference's one-mark exception.

## Background rhythm

This template is loud. A deck where every stage is the same pale `--bg` has
failed, no matter how correct its text is.

Use full-stage saturated colour fields by setting the stage background directly:

```html
<div class="slide">
  <div class="stage" style="background:var(--g0);color:var(--t0)">…</div>
</div>
```

**Measured reference use: 6 of 15 slides use a full-stage `--g0` / `--g1` /
`--g2` / `--g3` colour field rather than `--bg`.** The cover and the closing
slide must both be colour fields, and they must not be the same hue. Always pair
`--gN` with its matching `--tN` text colour.

## Decoration safe area

Decoration is placed before content, but it never fights the content.

- Every slide has a **text safe area**: the region actually occupied by the
  title, body copy, figures, and labels. No decoration may sit on top of it.
- Decoration belongs in one of three places: outside the safe area entirely
  (edges, corners, the empty half of the stage); behind it at `z-index:0`–`1`
  **and** at a contrast low enough that the text stays fully legible; or
  deliberately overlapping a photograph or colour field where the reference
  shows exactly that.
- The optional `big-circle` is cropped by the right stage edge, exactly as in
  the reference. A `burst-star` stays fully inside the stage. Do not substitute
  another oversized shape or invent a third decoration type.
- Never place body copy or a caption directly on top of a photograph unless the
  photograph is a full-bleed field with a text-safe treatment behind the copy.
- After rendering, look at every slide for a decoration that lands on text or
  makes a title hard to read. Move the decoration, not the text.

## Never do this

- Never render a KPI or statistic as a plain rectangle or a bordered card.
  Use the number-carrying star treatment in `kpi-row`, `kpi-field`, or
  `stat-hero`. Because it carries data, it stays in the content/layout layer and
  never enters optional-decoration statistics.
- Never use disc/dot list bullets. Use pill-tags, ruled rows, or numbered
  content stars.
- Do not copy the two legacy rounded-rectangle photo exceptions. New photo
  treatments use the normalized circular cell.
- Never use `border-radius` on a panel or colour field — only `--r-pill` on
  pill-tags and `--r-round` on circles and photos.
- Never let the whole deck sit on `--bg`.
- Never use drop shadows.
- Never let a slide go out without its hashtag footer and page number.

## Self-check before delivery

Review identity and page-role fidelity. Fix the deck before
delivery if any line fails.

0. Every optional ornament maps to a named signature element or a specific
   composition in `layouts/`.
1. Signature elements appear only on the page roles where the reference uses
   them, with clear space and no text collision.
2. Every slide carries the items listed under `Required chrome`.
3. Every photograph follows the documented template treatment and illustrates
   a subject the material describes. Zero photographs is valid.
4. Every prohibition under `Never do this` was checked against the final HTML.
5. Exactly one `data-color-system` token is present and it is preferred.
6. The decoration profile was read only as a gross drift signal.

Visual reference: [example/reference.jpg](example/reference.jpg) —
the rendered proof of every rule above. [layouts/](layouts/)
is the same deck in code; open it when a snippet here needs more context.
