---
name: playful-launch
description: Create a standalone 16:9 HTML presentation deck with the Playful Launch visual identity and direct-HTML workflow. Use when the user selects the Playful Launch presentation template or explicitly names playful-launch as the deck style. Best suited to cheerful, saturated consumer-product launches, community launches, and events.
---

# Playful Launch presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one standalone HTML file with one live `.deck`. Keep every `.slide` as a direct child, give it one 16:9 `.stage`, and include the deck CSS and keyboard-navigation script once.
- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Create one direct-child `.slide` per planned page and one 16:9 `.stage` inside each slide.

### Recommended layout approach

- Start with a clear top-to-bottom or left-to-right Flexbox relationship. Balance the visual weight of its regions and place each primary content group near the optical center of its own region. A left-to-right composition can vertically center the groups on each side; a top-to-bottom composition can center groups within balanced bands. Adapt alignment and asymmetry to the content and the template's visual character.
- Use a `data-layout` Flexbox container for the primary spatial relationship and keep audience-facing content in normal flow. This template does not use CSS Grid for layout. Reserve absolute positioning for textless decoration, fixed chrome, media frames, or ground fields whose role depends on layering; never use separate absolute coordinates to lay out text groups.
- Preserve the template's original visual character from `design-system.md` and the examples. Compose content and signature elements together according to their visual and semantic roles, whether they belong inside the main layout or on a separate layer.
- Review all regions and layers as one composition. Aim for readable balance, allowing intentional overlap and out-of-flow placement when they strengthen hierarchy, meaning, or the template's signature style.
- Treat every slide as a projected presentation canvas. Write concise visible copy for the audience and keep one clear hierarchy of title, supporting content, and evidence on each page.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

### Composing the identity layer

- Build every slide in three layers: a **ground** layer (stage background, colour
  fields, panels, grid), an optional **decoration** layer (only the textless
  burst-star and big-circle from `decoration/decoration.html`), and a **content**
  layer (`.fit`, text, photos, tiles, nodes, connectors, cards and charts).
  Give the decoration layer a `z-index` below the content layer unless the
  element is meant to sit on top.
- Compose decoration and content together so their placement remains intentional.
- Copy the `Deck shell` CSS from `design-system.md` verbatim into the single
  `<style>` block and build slides out of its class names. Do not invent a
  parallel set of utility classes.
- Vary the composition slide to slide, but keep the chrome, the radius scale, and
  the signature elements constant. Variety belongs in the layout, never in the
  identity.
- Use the helper classes that the `Deck shell` CSS defines (`.photo`, `.photocirc`,
  `.pill`, `.star`, `.tile`, `.bigcircle`, `.stack`, `.rule`) instead of
  repeating the same long inline style on every slide. They exist so the
  signature treatment is one class name, not a paragraph of CSS to remember, and
  a forgotten class is the usual reason a treatment goes missing.
- Whitespace is part of the composition. A deliberately quiet half-slide can be
  finished when the hierarchy is balanced. Add a signature element or colour field only when the
  documented page role supports that composition.

### Sizing

- **Nothing that holds text gets a size in `cqw`, `cqh`, `px`, `vw` or `vh`** — not
  `width`, `max-width`, `height`, and not `flex:0 0 4cqw`, which freezes exactly the
  way a width does. Columns are `flex:1`. A box that hugs its content is
  `align-self:flex-start;max-width:100%`. All 38 layouts read zero on this.
- **The safe area is set once**, by the padding on `.fit` (`11cqh 6cqw 9cqh`). A page
  that sets its own smaller padding has not widened the safe area, it has broken it. This is not the same
  as overflow: a deck can read zero overflow and still have copy glued to the bezel.
- **A peer row is `flex:none` and its cards are `flex:1`.** `flex:1` on the _row_
  makes the cards inherit the stage's height, and you get a slab of colour that is
  half empty. To stop a page being top-heavy, wrap the row in
  `flex:1;min-height:0;justify-content:center` — centre the group, do not stretch
  the cards.
- **A single-column title takes the whole safe area and wraps naturally.** Do not add
  `<br>` or a narrow `max-width` unless a real peer column occupies the remaining width.
- **A chart is sized by its row, and the row is not the whole page.** The donut is
  `width:100%;height:100%;max-height:86%` inside a stretched column: the ring reads
  502px against a 584px row, leaving the title and legend their air, and it shrinks
  to 436px on its own when the title wraps to two lines. A chart with `height:100%`
  and no cap resolves against its own width and renders 664px — larger than the row
  that holds it, so it crosses the safe area.
- **Ornaments are sized with `font-size`**, then `width:1em;height:1em`. The figure
  inside a burst-star is `.3em` of the star, so it stays in proportion at any size.
  A star sized with `width`/`height` renders a small number in a large frame.
- The top `11cqh` belongs to the chrome. `.fit` starts there; the top plus-mark
  occupies 5–8.2cqh. Flow content begins at or below 11% of stage height.

### Colour roles

- **`--accent`, `--s1`, `--s2`, `--s3` are fills, never text.** As text on `--bg`
  they read 1.44–2.56:1 depending on the colour system. For a coloured label on the
  page use `--g0` or `--g3` (4.01 and 4.11 worst case) or the `--k*` family; every
  other hue collapses to ~1.5:1 in at least one preferred system.
- **A chip that carries text uses `--gN` with its matching `--tN`, or `--ink`/`--bg`.**
  All four `--tN`/`--gN` pairs are ≥4.60:1 everywhere. **`--accent` with `--oa` is
  2.36:1 at worst** — it is for icons and symbols, not words, and that includes the
  figure inside a burst-star. Use `--gN`/`--tN` or `--bg`/`--ink` for those.
- **Never use `--surface`.** It is `#FFFFFF` on a `#FFFDF7` page: 1.00–1.13:1 in
  every preferred system. A white card on cream is an invisible box.
- **Nothing sits in a filled box on a full-bleed page.** On a full-bleed page a kicker takes `color:inherit`, never the accent
  token, which is usually the ink colour and vanishes.
- Use colour fields only for the page roles documented in `design-system.md`; vary their
  hues across the opening and closing sequence.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

- The photo treatments in `design-system.md` describe **how** a photograph looks
  in this template when there is one. They are not an instruction to produce
  that many photographs.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

- The `Signature elements` section gives exact markup for this template's
  optional decoration and content-device treatments. **Copy those snippets. Do not paraphrase them, redraw them,
  simplify them, or substitute a shape you find easier to write.** Change only
  size, position, colour token, and text content as the documented role permits.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — signature elements, background
     treatment, chrome;
  4. every ornament follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is accurate but visually anonymous also fails. When a slide genuinely
  has no room for optional ornament, omit it.

- Optional: [example/reference.jpg](example/reference.jpg) for the visual identity
  and [layouts/](layouts/) for full-slide scale, rhythm,
  and composition. `design-system.md` and `decoration/PLACEMENT.md` are authoritative
  for classification and placement.
- A playful-launch slide is three independent layers, and this folder keeps them
  in three separate places. Build them in this order and they cannot fight:

  | z-index | layer                                                          | source                                                                                                       |
  | ------- | -------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
  | 0–1     | stage ground and layout fields, including the `versus` split   | [layouts/](layouts/)                                                                                         |
  | 1–3     | optional textless burst-stars and big-circle                   | [decoration/PLACEMENT.md](decoration/PLACEMENT.md), [decoration/decoration.html](decoration/decoration.html) |
  | 2 / 6   | plus-marks / hashtag footer — fixed chrome, not decoration     | `layouts/_shell.html`, `PLACEMENT.md`                                                                        |
  | 40      | all audience-facing content and content devices, inside `.fit` | [layouts/](layouts/) — 38 naked layouts                                                                      |
  | 45      | page number                                                    | `layouts/_shell.html`                                                                                        |

  **Take structure from `layouts/` and ornament placement from `PLACEMENT.md`.**
  Classification is literal: a burst carrying a number is a content device; a
  textless burst is optional decoration. Tiles, nodes, connectors, photographs,
  cards, backgrounds and fixed chrome never enter decoration statistics.
  Use the reference image to judge rhythm and scale, never as reusable geometry.

  | the slide is                             | use                                                        |
  | ---------------------------------------- | ---------------------------------------------------------- |
  | the opening                              | `cover`                                                    |
  | an agenda                                | `toc`                                                      |
  | a chapter divider                        | `section`                                                  |
  | one sentence that carries the slide      | `statement`                                                |
  | sustained editorial prose                | `longform`                                                 |
  | a list of points                         | `bullets`, or `numbered-list` for 3–4                      |
  | prose beside prose                       | `two-column`                                               |
  | three peer ideas                         | `three-column` (ruled) or `color-cards` (filled)           |
  | a person, place or product               | `image-left` / `image-right`                               |
  | one image that carries the slide         | `image-hero`                                               |
  | several pictures                         | `image-grid`, `team`                                       |
  | capabilities or services                 | `feature-grid`                                             |
  | a sequence                               | `process-steps`                                            |
  | dated milestones                         | `timeline`                                                 |
  | phased outcomes                          | `roadmap`                                                  |
  | overlapping work over time               | `gantt`                                                    |
  | system layers and components             | `architecture`                                             |
  | one idea branching into themes           | `mind-map`                                                 |
  | rows of data                             | `table`                                                    |
  | three figures with the page's weight     | `kpi-row`                                                  |
  | five or six supporting figures           | `kpi-field`                                                |
  | one figure that carries the slide        | `stat-hero`                                                |
  | quantities over time or parts of a whole | `chart-bar`, `chart-line`, `chart-donut`                   |
  | two options weighed                      | `comparison` (ruled) or `versus` (filled)                  |
  | upsides and downsides                    | `pros-cons`                                                |
  | plans or tiers                           | `pricing`                                                  |
  | challenge, intervention and result       | `case-study`                                               |
  | a launch go/no-go review                 | `launch-readiness`                                         |
  | what people said                         | `quotes`, or `big-quote` for one line that fills the stage |
  | the ending                               | `close`                                                    |

  Cycle the ruled and filled variants. Putting the same horizontal rule on every
  slide is what a skewed menu produces. Two slides that share a structure and
  differ only in colour are one layout used twice, not two — vary the count, the
  rows, or the device before reaching for a second ground colour.

- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. Its packets carry this template's column, spacing, and chrome behaviour; adapt one rather than inventing table markup, which is where these decks lose content. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use the prompt's `color-system` when supplied, otherwise a preferred token from
  `design-system.md`. Inline that one `color-systems/<token>.css` in the final HTML.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Signature-element checks while authoring

While authoring, walk the `Self-check before delivery` list in
`design-system.md` as an identity audit:

- Confirm the content survived and every slide carries the required chrome.
- Verify every optional ornament follows a named signature element and page role in
  `decoration/PLACEMENT.md`.
- Confirm each remaining element is appropriate to that slide's page role. A reported
  geometric crossing remains an optional-review candidate under `Automated QA` below.
- Search the finished HTML for each pattern named in `Never do this` and remove
  every hit.

A clear, balanced content slide may correctly use no optional ornament.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
