---
name: playful-launch
description: Create, revise, or review standalone 16:9 HTML presentation decks with the Playful Launch visual identity and direct-HTML workflow. Use when the user selects the Playful Launch presentation template or explicitly names playful-launch as the deck style. Best suited to cheerful, saturated consumer-product launches, community launches, and events.
---

# Playful Launch presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## Choose the task mode

- Create: use Sections 1–5 and complete Section 2 before writing any slide HTML.
- Revise: inspect the existing HTML, reconstruct or update the outline for the affected sequence, and complete Section 2 before editing slide HTML; then use Sections 3–5 as relevant while preserving valid shell, token, motif, and runtime implementation.
- Review: use Sections 1–3 for context and Section 5 as the checklist; infer the deck's throughline and slide-level content contract, skip Section 4, and do not edit. Report slide-specific findings in P1 / P2 / P3 order (blocking / material / polish), include evidence and a fix direction, or state explicitly that there are no actionable findings.

## 1. Define the communication job

- Read the prompt and all supplied source material before composing slides.
- Identify the audience, purpose, desired audience outcome, core takeaway, and required evidence.
- Express the communication job in one sentence: by the end, the audience should reach the desired outcome because of the core takeaway.
- Ground every factual claim and number in supplied or verified sources; label forecasts, targets, and assumptions explicitly.

## 2. Complete the slide outline before HTML

- Before creating or changing slide HTML, write a lightweight plain-text or Markdown outline. State the one-sentence throughline, then list the slides in order.
- For each slide, record its working takeaway title, the point it must establish, and the evidence or data that supports it with its supplied or verified source. Mark forecasts, targets, assumptions, and slides that need no evidence.
- Review the complete outline for narrative flow, duplicated claims, missing evidence, and a deliberate opening and ending. Choose the slide count from the content.
- Treat the completed outline as the content contract for implementation, not as a layout schema. Keep layouts and motifs out of it, keep it out of audience-facing HTML unless requested, and update it first when a slide's title, communication job, or evidence changes materially.

## 3. Load the local identity

- Read [design-system.md](design-system.md) **completely, to the last line**, before
  writing any HTML. It defines this template's tokens, shell, typography and identity.
  [layouts/README.md](layouts/README.md) defines structure and
  [decoration/PLACEMENT.md](decoration/PLACEMENT.md) defines ornament roles and
  placement. Its
  `Deck shell`, `Signature elements`, `Required chrome`, `Background rhythm`,
  `Never do this`, and `Self-check before delivery` sections are requirements,
  not suggestions.
- The `Signature elements` section gives exact markup for this template's
  optional decoration and content-device treatments. **Copy those snippets. Do not paraphrase them, redraw them,
  simplify them, or substitute a shape you find easier to write.** Change only
  size, position, colour token, and text content as the documented role permits.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — signature elements, background
     treatment, chrome;
  4. every ornament follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is accurate but visually anonymous also fails. When a slide genuinely
  has no room for optional ornament, omit it.

- Inspect [example/reference.jpg](example/reference.jpg) for the visual identity
  and [layouts/](layouts/) for full-slide scale, rhythm,
  and composition. `design-system.md` and `decoration/PLACEMENT.md` are authoritative
  for classification and placement.
- A playful-launch slide is three independent layers, and this folder keeps them
  in three separate places. Build them in this order and they cannot fight:

  | z-index | layer                                                          | source                                                                                                       |
  | ------- | -------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
  | 0–1     | stage ground and layout fields, including the `versus` split   | [layouts/](layouts/)                                                                                         |
  | 1–3     | optional textless burst-stars and big-circle                   | [decoration/PLACEMENT.md](decoration/PLACEMENT.md), [decoration/decoration.html](decoration/decoration.html) |
  | 2 / 6   | plus-marks / hashtag footer — fixed chrome, not decoration     | `layouts/_shell.html`, `PLACEMENT.md`                                                                        |
  | 40      | all audience-facing content and content devices, inside `.fit` | [layouts/](layouts/) — 38 naked layouts                                                                      |
  | 45      | page number                                                    | `layouts/_shell.html`                                                                                        |

  **Take structure from `layouts/` and ornament placement from `PLACEMENT.md`.**
  Classification is literal: a burst carrying a number is a content device; a
  textless burst is optional decoration. Tiles, nodes, connectors, photographs,
  cards, backgrounds and fixed chrome never enter decoration statistics.
  Use the reference image to judge rhythm and scale, never as reusable geometry.

  | the slide is                             | use                                                        |
  | ---------------------------------------- | ---------------------------------------------------------- |
  | the opening                              | `cover`                                                    |
  | an agenda                                | `toc`                                                      |
  | a chapter divider                        | `section`                                                  |
  | one sentence that carries the slide      | `statement`                                                |
  | sustained editorial prose                | `longform`                                                 |
  | a list of points                         | `bullets`, or `numbered-list` for 3–4                      |
  | prose beside prose                       | `two-column`                                               |
  | three peer ideas                         | `three-column` (ruled) or `color-cards` (filled)           |
  | a person, place or product               | `image-left` / `image-right`                               |
  | one image that carries the slide         | `image-hero`                                               |
  | several pictures                         | `image-grid`, `team`                                       |
  | capabilities or services                 | `feature-grid`                                             |
  | a sequence                               | `process-steps`                                            |
  | dated milestones                         | `timeline`                                                 |
  | phased outcomes                          | `roadmap`                                                  |
  | overlapping work over time               | `gantt`                                                    |
  | system layers and components             | `architecture`                                             |
  | one idea branching into themes           | `mind-map`                                                 |
  | rows of data                             | `table`                                                    |
  | three figures with the page's weight     | `kpi-row`                                                  |
  | five or six supporting figures           | `kpi-field`                                                |
  | one figure that carries the slide        | `stat-hero`                                                |
  | quantities over time or parts of a whole | `chart-bar`, `chart-line`, `chart-donut`                   |
  | two options weighed                      | `comparison` (ruled) or `versus` (filled)                  |
  | upsides and downsides                    | `pros-cons`                                                |
  | plans or tiers                           | `pricing`                                                  |
  | challenge, intervention and result       | `case-study`                                               |
  | a launch go/no-go review                 | `launch-readiness`                                         |
  | what people said                         | `quotes`, or `big-quote` for one line that fills the stage |
  | the ending                               | `close`                                                    |

  Cycle the ruled and filled variants. Putting the same horizontal rule on every
  slide is what a skewed menu produces. Two slides that share a structure and
  differ only in colour are one layout used twice, not two — vary the count, the
  rows, or the device before reaching for a second ground colour.

- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. Its packets carry this template's column, spacing, and chrome behaviour; adapt one rather than inventing table markup, which is where these decks lose content. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use a valid prompt `color-system` when supplied. Otherwise select one of the
  **preferred tokens** named in `design-system.md` — not an arbitrary token from
  the full list. Load exactly one `color-systems/<token>.css` file and inline
  its CSS in the final HTML.
- Use this folder as the template guidance; the selected atomic colour-system
  file is the only shared template resource.

### Images are content choices, not decoration

Use a photograph or other image whenever it communicates the slide more clearly,
credibly, or memorably than text alone. The supplied material does not have to
explicitly request an image; make that editorial choice from the content.

- Choose sources in this order: user-supplied images and visual materials first,
  including media embedded in or linked from the supplied material; then relevant
  imagery from the supplied references and related information; then an AI-generated
  image grounded in the slide's actual subject when it would work better or no suitable
  sourced image exists.
- Never add or generate an image merely to fill an empty region. When no image improves
  the slide, use the template's
  non-photographic treatments instead: a colour field, a panel, a large figure,
  an ornament, or generous space.
- Every caption, alt text, and label beside an image must come from the
  material. Never invent a caption to justify a picture.
- A generated image that illustrates nothing in the material makes that slide
  unfaithful to its source, which costs far more than the missing picture would
  have.
- The photo treatments in `design-system.md` describe **how** a photograph looks
  in this template when there is one. They are not an instruction to produce
  that many photographs.

## 4. Build the deck

- Produce one standalone HTML file with one live `.deck`. Keep every `.slide` as a direct child, give it one 16:9 `.stage`, and include the deck CSS and keyboard-navigation script once.
- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Create one direct-child `.slide` per planned page and one 16:9 `.stage` inside each slide.

### Recommended layout approach

- Start with a clear top-to-bottom or left-to-right Flexbox relationship. Balance the visual weight of its regions and place each primary content group near the optical center of its own region. A left-to-right composition can vertically center the groups on each side; a top-to-bottom composition can center groups within balanced bands. Adapt alignment and asymmetry to the content and the template's visual character.
- Use a `data-layout` Flexbox container for the primary spatial relationship and keep audience-facing content in normal flow. This template does not use CSS Grid for layout. Reserve absolute positioning for textless decoration, fixed chrome, media frames, or ground fields whose role depends on layering; never use separate absolute coordinates to lay out text groups.
- Preserve the template's original visual character from `design-system.md` and the examples. Compose content and signature elements together according to their visual and semantic roles, whether they belong inside the main layout or on a separate layer.
- Review all regions and layers as one composition. Aim for readable balance, allowing intentional overlap and out-of-flow placement when they strengthen hierarchy, meaning, or the template's signature style.
- Treat every slide as a projected presentation canvas. Write concise visible copy for the audience and keep one clear hierarchy of title, supporting content, and evidence on each page.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

### Composing the identity layer

- Build every slide in three layers: a **ground** layer (stage background, colour
  fields, panels, grid), an optional **decoration** layer (only the textless
  burst-star and big-circle from `decoration/decoration.html`), and a **content**
  layer (`.fit`, text, photos, tiles, nodes, connectors, cards and charts).
  Give the decoration layer a `z-index` below the content layer unless the
  element is meant to sit on top.
- Compose decoration and content together so their placement remains intentional.
- Copy the `Deck shell` CSS from `design-system.md` verbatim into the single
  `<style>` block and build slides out of its class names. Do not invent a
  parallel set of utility classes.
- Vary the composition slide to slide, but keep the chrome, the radius scale, and
  the signature elements constant. Variety belongs in the layout, never in the
  identity.
- Use the helper classes that the `Deck shell` CSS defines (`.photo`, `.photocirc`,
  `.pill`, `.star`, `.tile`, `.bigcircle`, `.stack`, `.rule`) instead of
  repeating the same long inline style on every slide. They exist so the
  signature treatment is one class name, not a paragraph of CSS to remember, and
  a forgotten class is the usual reason a treatment goes missing.
- Whitespace is part of the composition. A deliberately quiet half-slide can be
  finished when the hierarchy is balanced. Add a signature element or colour field only when the
  documented page role supports that composition.

### Sizing

- **Nothing that holds text gets a size in `cqw`, `cqh`, `px`, `vw` or `vh`** — not
  `width`, `max-width`, `height`, and not `flex:0 0 4cqw`, which freezes exactly the
  way a width does. Columns are `flex:1`. A box that hugs its content is
  `align-self:flex-start;max-width:100%`. All 38 layouts read zero on this.
- **The safe area is set once**, by the padding on `.fit` (`11cqh 6cqw 9cqh`). A page
  that sets its own smaller padding has not widened the safe area, it has broken it. This is not the same
  as overflow: a deck can read zero overflow and still have copy glued to the bezel.
- **A peer row is `flex:none` and its cards are `flex:1`.** `flex:1` on the _row_
  makes the cards inherit the stage's height, and you get a slab of colour that is
  half empty. To stop a page being top-heavy, wrap the row in
  `flex:1;min-height:0;justify-content:center` — centre the group, do not stretch
  the cards.
- **A single-column title takes the whole safe area and wraps naturally.** Do not add
  `<br>` or a narrow `max-width` unless a real peer column occupies the remaining width.
- **A chart is sized by its row, and the row is not the whole page.** The donut is
  `width:100%;height:100%;max-height:86%` inside a stretched column: the ring reads
  502px against a 584px row, leaving the title and legend their air, and it shrinks
  to 436px on its own when the title wraps to two lines. A chart with `height:100%`
  and no cap resolves against its own width and renders 664px — larger than the row
  that holds it, so it crosses the safe area.
- **Ornaments are sized with `font-size`**, then `width:1em;height:1em`. The figure
  inside a burst-star is `.3em` of the star, so it stays in proportion at any size.
  A star sized with `width`/`height` renders a small number in a large frame.
- The top `11cqh` belongs to the chrome. `.fit` starts there; the top plus-mark
  occupies 5–8.2cqh. Flow content begins at or below 11% of stage height.

### Colour roles

- **`--accent`, `--s1`, `--s2`, `--s3` are fills, never text.** As text on `--bg`
  they read 1.44–2.56:1 depending on the colour system. For a coloured label on the
  page use `--g0` or `--g3` (4.01 and 4.11 worst case) or the `--k*` family; every
  other hue collapses to ~1.5:1 in at least one preferred system.
- **A chip that carries text uses `--gN` with its matching `--tN`, or `--ink`/`--bg`.**
  All four `--tN`/`--gN` pairs are ≥4.60:1 everywhere. **`--accent` with `--oa` is
  2.36:1 at worst** — it is for icons and symbols, not words, and that includes the
  figure inside a burst-star. Use `--gN`/`--tN` or `--bg`/`--ink` for those.
- **Never use `--surface`.** It is `#FFFFFF` on a `#FFFDF7` page: 1.00–1.13:1 in
  every preferred system. A white card on cream is an invisible box.
- **Nothing sits in a filled box on a full-bleed page.** On a full-bleed page a kicker takes `color:inherit`, never the accent
  token, which is usually the ink colour and vanishes.
- Use colour fields only for the page roles documented in `design-system.md`; vary their
  hues across the opening and closing sequence.

## Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Getting the container right

A percentage bar height resolves against its parent's **definite** height. Break
that chain and the bar computes to exactly `0` — it vanishes while the labels,
values and legend still render, so the page reads as merely empty. Measured on
generated decks: 52 of 558 percentage bars rendered at zero, and one deck spent
455s of gate repair on this alone.

`layouts/chart-*.html` already carries a structure that works. Copy it rather
than inventing lanes. Three rules make the chain definite:

1. **A bar is a direct child of the plot box.** Any level between them needs its
   own definite height, and one that lacks it zeroes everything below.
2. **All columns share one grid, so the label row is shared.** A label that wraps
   to two lines must cost every column the same height, or the bar above it is
   measured against a shorter ruler than its neighbours. Make the plot
   `display:grid; grid-auto-flow:column; grid-auto-columns:1fr` with
   `grid-template-rows:1fr auto …` (one row per item in a column, exactly — a
   spare row pulls the next column's first item into the previous column), and
   give each column wrapper `display:contents`. The markup grouping stays "one
   div per column"; only the rows become shared.

   Measured on the template's own `chart-bar.html`, changing nothing but one
   label to a wrapping name: baseline offset 0 → 19px, and the fourth bar 342 →
   324px — the value never changed, the bar just lost 5%. With the shared grid
   the same label costs all four bars the same 8%, and the ratios stay exact.

3. **Every level is either `flex:none` or `flex:1`** — sized by its content, or
   taking the remainder. There is no third kind.

4. **A value label never shares the lane with the bar it labels.** If it does,
   flex has to fit label + gap + bar into the lane, so it shrinks the bar — and
   only the bars tall enough to run out of room. The scale stops being linear at
   the top: measured on `bloom/chart-bar.html`, lane 336px, label 19px, gap 6px,
   every value above 92.5% rendered at the same 310px, so **96 and 100 drew
   identically**. Under the template's own "percentages of the tallest value"
   convention the tallest bar is always 100%, so this fires on every chart.
   Reserve the label row on the lane (`padding-top`, measured once per template)
   and set both children `flex:none`; the bar then resolves against the lane
   minus that reserve, the same reserve for every column.

Grouping two bars per category still obeys this, but the group wrapper needs
`align-self:stretch`, or it is sized by content and the lane inside it collapses.

Do not "fix" a flat chart by enlarging the numbers or switching to a table. The
values are right; the container chain is not.

## How full a page should be

Measured across all 902 layouts in the 23 shared templates, so this is what the
system already does — not a target invented for the occasion:

|                                                                                  | p25 |  median | p75 |
| -------------------------------------------------------------------------------- | --: | ------: | --: |
| vertical coverage (share of the stage height that carries ink or a filled block) | 33% | **43%** | 61% |
| ink area (share of the stage area)                                               |  9% | **12%** | 16% |
| lowest ink (how far down the page the content reaches)                           | 68% | **75%** | 90% |

**Aim for the middle column.** A content page that stops at 40% of the height and
leaves the rest blank reads as unfinished; one that runs past 25% ink area reads as
a wall. Both are allowed when the material calls for it — a statement page is one
huge line at 6% coverage, a table or a longform page is legitimately dense — but
neither is the default.

Two things that are **not** the same:

- **A void at the bottom.** Content stops early and nothing follows. This is the
  one to avoid; measured on the naked layouts, 73 of 902 pages do it.
- **Air between blocks.** A title, then a band of columns centred in the space
  below it. That is composition, not a defect — do not fill it just to fill it.

If the material genuinely does not fill the page, cut a column or merge the page
into its neighbour rather than padding sentences.

## 5. Verify before delivery

- Render and inspect every slide at full presentation size, then review the complete sequence for narrative flow and visual rhythm.
- Compare the rendered deck with the completed outline; confirm every title, communication job, evidence item, and source status remains aligned and no planning notes appear in audience-facing copy.
- Check title wrapping, body readability, data labels, contrast, clipping, overflow, unintended overlap, unresolved placeholders, and motif consistency.
- Run `tools/run.sh <deck>` at 1600×900 after fonts settle. Require `titleBodyOverlaps`, `bodyCtaOverlaps`, and `textBigcircleOverlaps` all equal 0; any non-zero result is blocking. These semantic intersections have no bypass.
- Inspect every `textVisualOverlapCandidates` sample in the rendered slide. This field is advisory: repair or move the motif when it obscures any glyph or reduces the text to doubtful readability; keep an intentional crossing only when every word remains immediately legible. Do not auto-fail a clear, harmless overlap.
- Review the slide as a complete composition. Confirm that text, media, data, signature elements, ornaments, and chrome remain legible, and that every layer or overlap supports an intentional visual relationship.
- Confirm the prompt-selected colour-system is used exactly, or record the valid token chosen when the prompt omitted it.
- Confirm the delivered HTML contains one live `.deck`, one navigation runtime, and only the markup and CSS used by its rendered slides.
- Test `← / ↑ / → / ↓`, `Home`, and `End`; confirm focused editable controls retain their normal key behaviour.
- **Confirm every slide is reachable, by pressing the key.** The navigation runtime
  collects pages with `[...deck.children].filter(n => n.classList.contains('slide'))`,
  so a `.slide` nested one level deeper, or written after the deck's closing `</div>`,
  renders perfectly and scrolls by drag but cannot be reached with an arrow key. One
  deck of 27 pages stopped at page 2 and looked flawless in every screenshot. One line:

  ```js
  document.querySelectorAll(".slide").length ===
    [...document.querySelector(".deck").children].filter((n) =>
      n.classList.contains("slide"),
    ).length;
  ```

- Complete creation and revision tasks with the verified final HTML; complete review tasks with a concise, prioritized findings report.

### Signature-element audit

Before delivering, walk the `Self-check before delivery` list in
`design-system.md` as an identity audit:

- Confirm the content survived and every slide carries the required chrome.
- Verify every optional ornament follows a named signature element and page role in
  `decoration/PLACEMENT.md`.
- Confirm each remaining element is appropriate to that slide's page role and
  does not sit on top of text.
- Search the finished HTML for each pattern named in `Never do this` and remove
  every hit.

A clear, balanced content slide may correctly use no optional ornament.

## Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding. Run `tools/run.sh <deck>` and require `safeAreaShells`, `outsideSafeArea`, and `emptyPhotocells` all to equal `0`; any non-zero result blocks delivery.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
