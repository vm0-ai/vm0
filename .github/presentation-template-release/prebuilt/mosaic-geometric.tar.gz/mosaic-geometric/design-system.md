# Mosaic Geometric

## Visual identity

A modular Bauhaus mosaic: saturated geometric tiles grow in from the page edges, sharp angles coexist with circular arcs, and the composition feels flat, direct, and rhythmic.

## Color system tokens

Read the prompt's `color-system` before generating. If it supplies one of the valid tokens below, use that token exactly. If it does not, choose from the tokens below according to the content, audience, mood, information density, and readability. Use only one token throughout a deck.

The presentation category documented for this template is **V (multicolour)**, with `carnival` as its example token. Determine the generated deck's token using the rule above.

Use only the following snake_case values as valid tokens:

- Single-primary M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`carnival`, `prism`, `pop_art`, `bauhaus_primary`, `citrus_fresh`

The default color system used in `example/reference.jpg` is `carnival`.
Picking a token outside this list is how a deck ends up looking like a different
template: a finance source, for instance, pulls every template toward the same
muted corporate grey unless the list stops it.


After selecting a token, read `color-systems/<token>.css`, inline that file's single CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="carnival" data-safe-area="0.07">
```

- Use `--bg`, `--ink`, `--soft`, and `--ph` for the page, body copy, secondary text, and image placeholders. `--surface` is reserved for the inner square of the rotated-square glyph; it is not a panel colour (see `Decoration safe area`).
- `--accent`, `--s1`, `--s2`, and `--s3` are raw hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected for those raw hues in v1; use them for large icons or decorative symbols. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use the contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text. Use `--kad` for accent text on an `--ink` field. When a raw hue needs higher text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour fields containing text, use `--g0` through `--g3` and pair each with the matching `--t0` through `--t3`.
- HTML/CSS components must reference colours only through `var(--...)`; derive transparency, strokes, shadows, and gradients from defined tokens as well.

Use `--bg` as the page base, with `--accent` and `--s1` through `--s3` forming the edge mosaics. Establish each slide's visual centre of gravity with one dominant colour cluster.

```css
.slide { background: var(--bg); color: var(--ink); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Space Grotesk` as the display typeface and `Lexend` as the body typeface.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600&family=Lexend:wght@300;400;500;600&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Space Grotesk";
  --fb: "Lexend";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600; available body weights are 300 / 400 / 500 / 600. Use `--fd` for titles, hero numbers, and section numbers; use `--fb` for body copy, labels, chart annotations, and tables. For CJK content, preserve the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the template's own base stylesheet, used by `layouts/`.
Copy it verbatim into the single `<style>` block, immediately after the inlined
colour-system CSS, before writing any slide. It defines the 16:9 stage, the type
scale, and the chrome and decoration classes the rest of this document refers
to. A deck that invents its own class names instead of using these will not look
like this template.

```css
:root{
  --r-xs: .5cqw;
  --r-sm: .9cqw;
  --r-md: 1.7cqw;
  --r-lg: 3cqw;
  --r-xl: 5cqw;
--fd: "Space Grotesk";
  --fb: "Lexend";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);overflow-wrap:break-word;word-break:normal;}
.stage *{overflow-wrap:break-word !important;word-break:normal !important;}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}
  

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:6;}

.tile{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.tile>span{font-size:40cqw;line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.badge>span{font-size:40cqw;line-height:1;}
.tick{position:absolute;}
.card{border-radius:var(--r-md);}
.dot{border-radius:50%;}.qcircle{border-radius:50% 0 0 0;}.semi{border-radius:999px 999px 0 0;}.tri{width:0;height:0;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}
```
The number inside a `badge` and any text inside a `tile` must be wrapped in a
`<span>`. The wrapper is what makes the text scale with the box: it is measured
against the badge's own width, so the figure stays in proportion at any size.
Text placed directly in the box only follows `--sz`, and a deck that sizes the
box with `width`/`height` instead will render a small number in a large frame.
Size these with `--sz`, not `width`/`height`.


## Signature elements

Available signature elements: `mosaic-tile-cluster`, `burst-stat`, `framed-icon-tile`.


Visual reference: [example/reference.jpg](example/reference.jpg)

## Motif library

Every motif below is copied out of this template's own reference deck. This is
the geometry that makes the template recognisable, and it is the part that goes
missing when a deck is authored from the prose alone — the shapes exist nowhere
else; it is reproduced here so generation never needs a full-deck HTML example.

This library is broader than optional decoration. Mosaic cells and their glyphs are
background treatment; badges, metric discs, pills and photo frames carry content. Only
the textless ring, arch and quarter-circle declared in `decoration/PLACEMENT.md` are
optional decoration and may receive `data-decoration`.

**Copy these snippets. Do not paraphrase them, redraw them, or substitute a
shape that is easier to write.** Change only size, position, colour token, and
text content. The count beside each motif is how many times the reference deck
uses it across fifteen slides. It records prevalence; it is not a floor, quota,
or target to scale mechanically. Use a motif only where the closest reference
page role uses it and the composition benefits.


### `badge` — used 3× in the reference deck

```html
<div class="badge" data-badge="1" style="--sz:5rem;background:var(--g0);color:var(--t0)"><span>01</span></div>
```

### `bbadge` — used 4× in the reference deck (one segmented metric disc, three burst-stat discs)

```html
<svg data-bbadge="1" viewBox="0 0 100 100" style="position:absolute;right:10cqw;top:27cqh;width:18cqw;height:18cqw;z-index:1">
     <path d="M50 50 L50 4 A46 46 0 0 1 96 50 Z" fill="var(--accent)"/>
     <path d="M50 50 L96 50 A46 46 0 0 1 50 96 Z" fill="var(--s1)"/>
     <path d="M50 50 L50 96 A46 46 0 0 1 4 50 Z" fill="var(--s2)"/>
     <path d="M50 50 L4 50 A46 46 0 0 1 50 4 Z" fill="var(--s3)"/>
     <circle cx="50" cy="50" r="17" fill="var(--bg)"/>
   </svg>
```

The other three `bbadge` devices are the labelled burst-stat form used by
`layouts/kpi-burst.html`; they carry figures and therefore remain content devices.

### `cols` — used 15× in the reference deck

This motif is too long to inline without cutting it mid-tag, so it is not
reproduced here. Find it in [layouts/](layouts/) by
searching for the opening tag below, and copy the whole element from there.

```html
<div class="mosaic" data-mosaic="1" data-cols="3" data-tile="8" style="display:grid;grid-template-columns:repeat(3,8cqw);gap:0.7cqw;">
```

### `mosaic` — used 15× in the reference deck

This motif is too long to inline without cutting it mid-tag, so it is not
reproduced here. Find it in [layouts/](layouts/) by
searching for the opening tag below, and copy the whole element from there.

```html
<div class="mosaic" data-mosaic="1" data-cols="3" data-tile="8" style="display:grid;grid-template-columns:repeat(3,8cqw);gap:0.7cqw;">
```

### `mtile` — used 91× in the reference deck

```html
<div class="mtile" data-mtile="1" style="display:flex;align-items:center;justify-content:center;width:8cqw;height:8cqw;background:var(--accent)"><svg viewBox="0 0 100 100" style="width:62%;height:62%"><path d="M50 3 Q65 35 97 50 Q65 65 50 97 Q35 65 3 50 Q35 35 50 3 Z" fill="var(--oa)"/></svg></div>
```

### `pill` — used 1× in the reference deck

```html
<div data-pill="1" style="display:inline-flex;align-items:center;margin-top:5cqh;padding:1.2cqh 2cqw;background:var(--g0);color:var(--t0);border-radius:999px;font-family:var(--fd);font-weight:600;font-size:1.2cqw;letter-spacing:.08em">PRESENTATION · 2026</div>
```

### `tile` — used 19× in the reference deck

This motif is too long to inline without cutting it mid-tag, so it is not
reproduced here. Find it in [layouts/](layouts/) by
searching for the opening tag below, and copy the whole element from there.

```html
<div class="mosaic" data-mosaic="1" data-cols="3" data-tile="8" style="display:grid;grid-template-columns:repeat(3,8cqw);gap:0.7cqw;">
```


### CSS signatures

These declarations are part of the template's look. The counts are from the reference deck.

| property | values it actually uses | why it matters |
| --- | --- | --- |
| `border-radius` | `999px` ×2<br>`50% 0 0 0` ×1<br>`999px 999px 0 0` ×1 | arches, capsules and part-round corners |


### Not captured above

These named signature elements have no extractable snippet in this library: `burst-stat`. Read [layouts/](layouts/) for them and copy the markup from the slide that uses them; do not improvise a substitute.

## Strict decoration reference profile

Classify before counting. A card, square tile, colour block, rectangular background,
content container, grid cell, media frame, node or connector performs a content or layout
function and is not decoration. Chrome is counted separately.

The reference has three optional decoration types, explicitly declared and textless:

| type | marker | reference |
|---|---|---:|
| ring | `data-decoration="ring"` | 9 |
| arch | `data-decoration="arch"` | 6 |
| quarter-circle | `data-decoration="quarter-circle"` | 5 |

That is 20 declared elements across 15 slides (`bigPerPage` 1.33). The ten content
slides carry one each; cover, three section dividers and close carry two, so
`pagesWithPair` is 5 / 15. Only 1 of 20 bleeds beyond the stage. There is no small
optional item-set motif (`smallOrnaments` 0).

Keep these categories separate:

- 15 edge mosaic clusters / 91 cells are required background treatment;
- the eight glyph designs live inside those structural cells and are background
  vocabulary, not an optional quota;
- 3 numbered badges and 4 metric-disc / burst-stat devices carry labels or figures;
- photo frames carry media;
- wordmark and page number are persistent chrome.

None receives `data-decoration`, `data-deco` or `data-ornament`. Use the exact declarations
only on the three strict optional types. See `decoration/PLACEMENT.md` for the measured
page-role rules and the browser audit.

Content still comes first. Never push text off the stage, cover it, or drop a point. Never
add a photograph the source material does not support.


## Decoration safe area

Background treatment and optional decoration are placed before content, but they never
fight the content.

- Every slide has a **text safe area**: the region actually occupied by the
  title, body copy, figures, and labels. No decoration may sit on top of it.
- Optional decoration belongs in one of three places: outside the safe area entirely
  (edges, corners, the empty half of the stage); behind it at `z-index:0`–`1`
  **and** at a contrast low enough that the text stays fully legible; or
  deliberately overlapping a photograph or colour field where the reference
  shows exactly that.
- The required mosaic background cluster is cropped by the stage edge. Optional
  decoration follows its measured reference placement; only 1 of 20 bleeds.

## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** A label positioned with `left:88cqw` will
overflow the moment its text is longer than the author guessed, and CJK copy is
routinely wider than the Latin draft it was written against. Anchor anything in
the right third with `right:` instead of `left:`, and anything in the bottom
third with `bottom:` instead of `top:`. A block anchored to the edge it is near
grows inward, where there is room, instead of outward into nothing. Give any
absolutely-positioned text an explicit `max-width` so it wraps rather than
extends.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

Both faults hide from a quick glance at the whole deck and are obvious on the
slide itself. Before delivering, look at every slide that carries a set of
things and check that the set is aligned and that nothing touches an edge it was
not meant to touch.

## Never do this

- **Never use a disc-bulleted list.** Not one of the twenty-three V3 reference
  decks contains a single `<ul>` with default bullets, and a bulleted list is the
  fastest way to make a designed template look like a plain document. Structure a
  list as numbered rows with a hairline rule between them, as key–value rows, as
  a row of cards, or with the template's own motifs — whatever the reference deck
  does for the same job.
- Never invent a colour outside the inlined colour-system tokens; every colour
  goes through `var(--...)`.
- Never mark a card, tile, grid cell, metric disc, badge, node, connector, media frame,
  background field or chrome as `data-decoration`, `data-deco` or `data-ornament`.
- Never leave a slide without the chrome named in `Required chrome`.
- Never let an ornament sit on top of a title or a paragraph.
- Never generate a photograph the supplied material does not call for.

## Required chrome

Chrome is the cheapest part of a template's identity and the most frequently
dropped: across the benchmark's baseline decks, four of six templates carried a
footer on 0-2 slides out of 17. This template's reference deck carries the
following, and the count is measured from that deck, not assumed.


### Repeats on every slide

The reference deck also repeats these edge-pinned elements on nearly every slide. Their opening tags are given as locators — find each one in [layouts/](layouts/) and carry it through your deck the same way.

```html
<div style="position:absolute;left:5cqw;top:5cqh;display:flex;align-items:center;gap:.7cqw;z-index:6">
```
<sub>on 15 of 15 reference slides</sub>

**Page number** — on 15 of 15 slides:

```html
<div class="pagenum">01</div>
```

Carry page number on **every** slide, including the cover and the closing slide.
