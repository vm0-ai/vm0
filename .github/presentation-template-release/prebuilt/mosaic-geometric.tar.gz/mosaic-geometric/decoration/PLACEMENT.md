# mosaic-geometric — background grammar and strict decoration

Everything here is measured from the original reference deck at 1600×900. It uses the
playbook's strict classification: decoration is template-specific, carries no text or
data, and performs no layout or content-container function.

The distinction matters in this template. Its edge mosaic is a required **background
treatment** made from grid cells; numbered badges and metric-disc / burst-stat devices carry
content. None of those may inflate the optional-decoration count.

## Reference ledger

| role | reference | classification |
|---|---:|---|
| mosaic clusters | 15, one per slide | background treatment |
| mosaic cells | 91 | grid cells, not decoration |
| mosaic glyph designs | 8 | background vocabulary inside the cells |
| ring / arch / quarter-circle | 20 total | optional decoration |
| badge / metric-disc or burst-stat device | 3 / 4 | content devices |
| wordmark / page number | 15 / 15 | persistent chrome |

With only the strict optional elements declared, the template-local probe reads:

| diagnostic | reference |
|---|---:|
| `bigOrnaments` | 20 |
| `bigPerPage` | 1.33 across 15 slides |
| `pagesWithPair` | 5 / 15 |
| `bleedingPct` | 0.05 (1 / 20) |
| `smallOrnaments` | 0 |

## Layer model

| z-index | role | source |
|---|---|---|
| 1 | required mosaic background treatment | section B |
| 1 | optional ring / arch / quarter-circle | section C |
| 6 | persistent chrome | section A |
| 40 | `.fit` content flow | `../layouts/*.html` |

Background and optional decoration sit below text and outside `.fit`. If either collides
with content, move the visual element; never move or shrink the copy to preserve it.

Open `decoration.html` for the rendered classification ledger. Its first four sheets and
its glyph sheet demonstrate background vocabulary and are explicitly excluded from the
optional count. The secondary-ornament sheet shows the three declared decorations.

## A · Persistent chrome — not decoration

Two items occur on all 15 reference slides:

- `left:5cqw; top:5cqh` — the wordmark row, `z-index:6`;
- `.pagenum` — `right:3cqw; bottom:3.2cqh`, including cover and close.

Chrome is repeated interface identity, so it is never marked `data-decoration` and never
enters ornament coverage or pairing statistics.

## B · Mosaic clusters — required background treatment, not decoration

All 15 reference slides carry exactly one `data-mosaic` cluster. Its grid cells establish
the template's edge treatment; the playbook explicitly excludes tiles, colour blocks and
grid cells from decoration statistics.

| page role | cells | grid | anchor | reference |
|---|---:|---|---|---:|
| cover, close | 12 | 3×4 | `right:0`, vertically centred or `top:16cqh` | 2 / 15 |
| section divider | 9 | 3×3 | `right:0; top:50cqh; transform:translateY(-50%)` | 3 / 15 |
| content page | 4 | 2×2 | one corner, flush at `0` | 10 / 15 |

Every cluster sits flush against the stage edge and is shown whole — nothing is cropped.
The content-page corners are top-right ×6, bottom-left ×2 and bottom-right ×2; top-left is
reserved for the wordmark. Cluster width is 25.4% of the stage for 9- and 12-cell
treatments (cell 8cqw) and 10.7% for 4-cell treatments (cell 5cqw).

(Earlier revisions bled the clusters past the edge by 2–3cqw and sized the 4-cell cell at
8cqw = 16.7% of the stage. Measured on generated decks, that cell covered body text on 13
of 19 pages, worst case 75px deep; 5cqw and a flush anchor bring the worst case to 8px.)

The cluster's cells cycle `--accent → --s1 → --s2 → --s3`. Each cell holds one of eight
glyph designs: four-point star, four discs, checkerboard, paired arcs, asterisk, rotated
square, four quarter-circles and stacked chevrons. Those designs are background
vocabulary inside the grid; the square cell and its colour fill are not optional
ornaments. Do not invent a ninth glyph.

Use `data-mosaic` and `data-mtile` for this background treatment. Do **not** add
`data-decoration`, `data-deco` or `data-ornament` to the cluster, its cells or its glyphs.

## C · Optional decoration — three declared types

Only three element types pass the strict test. They are independent of content, textless,
carry no data and perform no layout function:

| name | marker | reference | geometry |
|---|---|---:|---|
| ring | `data-decoration="ring"` | 9 | outlined circle, 4–5cqw, `--s3` stroke |
| arch | `data-decoration="arch"` | 6 | `.semi`, 6–12cqw wide |
| quarter-circle | `data-decoration="quarter-circle"` | 5 | `.qcircle`, 4–5cqw |

Their frequency follows page role exactly:

- each of the 10 content pages carries one;
- cover, the three dividers and close carry two;
- measured per slide: `[2,1,2,1,1,1,2,1,1,1,2,1,1,1,2]`.

On 8 of 10 content pages the optional ornament sits diagonally opposite the mosaic
cluster. One of the 20 bleeds beyond the stage; the other 19 sit wholly inside it. The
reference therefore gates the **count by page role**, not a blanket “all ornaments must
bleed” rule.

Do not invent a generic substitute. Copy the exact ring, `.semi` or `.qcircle` geometry
from `decoration.html`, preserve its `data-decoration` marker, and change only placement,
size and a demonstrated fill token.

## D · Elements explicitly excluded from optional decoration

| element | measured role | reference |
|---|---|---:|
| `data-mosaic`, `data-mtile` and their glyphs | background grid treatment | 15 clusters / 91 cells |
| `data-badge` | numbered row label | 3 |
| `data-bbadge` | metric disc carrying a figure | 4 |
| `data-pill` | cover metadata label | 1 |
| `data-photocell` | media content frame | 12 |
| `.card`, panel, colour field, rectangular fill | content container / layout | varies |
| wordmark and `.pagenum` | persistent chrome | 15 / 15 |

These devices remain valid where the corresponding layout calls for them, but they must
never receive a decoration marker or satisfy an ornament quota. There is no genuine
optional item-set motif in the reference, so this template intentionally has no
`item-sets.html`; `numbered-list.html` and `kpi-burst.html` already carry their content
devices.

## E · Colour and surface traps

`--surface` is `#FFFFFF` on the `#FFFDF7` page: contrast 1.02. Across the five preferred
tokens it ranges only 1.00–1.13. The corrected reference uses it five times, solely as
the inner square of the rotated-square background glyph. The old `.card` shell rule
painted four service cards white on cream; it was removed and those items now use
hairline rules.

Raw hues are fills, not text. Against the reference page:

| token | contrast | type? |
|---|---:|---|
| `--s2` | 1.76 | no |
| `--s3` | 2.49 | no |
| `--accent` | 2.56 | no |
| `--s1` | 3.90 | carnival only |
| `--g0` | 4.52 | yes |
| `--g3` | 4.77 | yes |
| `--soft` | 7.10 | yes |
| `--ka` | 16.59 | yes |

Across every preferred token, only `--g0`, `--g3`, `--soft` and `--ka` pass everywhere.
The reference contents page previously used `--accent`, `--s2` and `--s3` as type; that
self-contradiction was corrected, and the reference now has 0 low-contrast text runs.

## F · Stage, safe area and lower strip

- Full-bleed page backgrounds: **0 / 15**. Mosaic colour arrives at the edge of a cream
  stage; flooding the whole stage is a different template.
- The text safe area is **7% each side**, set once by `.fit` padding. Across 152 reference
  text runs, the modal and minimum left edge are both 7.0%; the furthest right edge is
  92.7%.
- The layouts use `padding:12cqh 7cqw 10cqh`; content begins below the wordmark band.
- Optional ornaments appear in the lower strip on 11 of 20 placements. Copy ending below
  72cqh moves the ornament to the top instead; reference pages 4, 5, 8 and 12 demonstrate
  that choice.

## Audit contract

The template constant is root `data-safe-area="0.07"`; it is not derived from each
page's padding.
The reference contract is:

```text
decks / navigable / orphan / indirect     1 / 15 / 0 / 0
overflow / outsideSafeArea                0 / 0
aboveChromeBand                           0
lowContrast                               0
boxesUnderfilledV / H                     0 / 0
fullBleedPages                            0 / 15
declared optional decoration              20 (1 or 2 by page role)
pagesWithPair                             5 / 15
smallOrnaments                            0
```

The declaration itself is auditable:

```js
const declared = [...document.querySelectorAll(
  '[data-decoration],[data-deco],[data-ornament]'
)];
({
  declared: declared.length,
  carriesText: declared.filter(e => e.textContent.trim()).length,
  structural: declared.filter(e => e.matches(
    '[data-photocell],[data-tile],[data-badge],[data-bbadge],' +
    '[data-node],[data-connector],[data-background-field],[data-metric-disc]'
  ) || e.closest('.fit,[data-device]')).length
});
```

Reference: `{declared:20, carriesText:0, structural:0}`.

Every `.slide` is a direct child of `.deck`, and arrow-key navigation reaches every page.
