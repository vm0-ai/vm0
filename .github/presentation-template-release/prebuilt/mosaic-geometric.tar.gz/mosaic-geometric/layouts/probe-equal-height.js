(() => {
  const results = [];

  for (const stage of document.querySelectorAll('.stage')) {
    const label = stage.closest('.slide')?.previousElementSibling?.textContent || '?';
    const stageRect = stage.getBoundingClientRect();

    for (const row of stage.querySelectorAll('*')) {
      const style = getComputedStyle(row);
      const rowRect = row.getBoundingClientRect();
      if (style.display !== 'flex' || style.flexDirection !== 'row' ||
          style.alignItems !== 'stretch' || rowRect.width < stageRect.width * 0.45) continue;

      const children = [...row.children].filter(child =>
        child.getBoundingClientRect().width > 4 && child.textContent.trim().length > 0);
      if (children.length < 2 || children.length > 4) continue;
      // The mind-map row is two branch stacks around one hub, not three peers.
      if (label === 'mindmap') continue;

      const structured = children.filter(child =>
        child.querySelector('.body,.cap,p,.h3,.stat,.kicker') ||
        child.matches('.body,.cap,p,.h3,.stat,.kicker'));
      if (structured.length < 2) continue;

      const target = children[0].querySelector('.body,.cap,p') ||
                     children[0].querySelector('.h3,.stat,.kicker') || children[0];
      let node = [...target.childNodes].find(candidate =>
        candidate.nodeType === Node.TEXT_NODE && candidate.textContent.trim());
      if (!node) node = target.appendChild(document.createTextNode(''));
      const original = node.textContent;
      node.textContent = original +
        ' Additional sentence added to make the first peer materially taller than its neighbours and force another wrapping line.';
      void row.offsetHeight;

      const heights = children.map(child => +child.getBoundingClientRect().height.toFixed(1));
      node.textContent = original;
      const spread = Math.max(...heights) - Math.min(...heights);
      results.push({
        layout: label,
        peers: children.length,
        spread: +spread.toFixed(1),
        heights,
        sample: children.map(child => child.textContent.trim().replace(/\s+/g, ' ').slice(0, 18)),
      });
    }
  }

  return {
    tested: results.length,
    failed: results.filter(result => result.spread > 1),
    results,
  };
})()
