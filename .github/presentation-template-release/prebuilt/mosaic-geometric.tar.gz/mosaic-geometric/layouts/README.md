# mosaic-geometric — naked layouts

36 layouts, text only. No mosaic background treatment, optional decoration, colour
decision, or measured string geometry.
Pair one of these with [`../decoration/PLACEMENT.md`](../decoration/PLACEMENT.md) to build
a slide.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 36: zero `width` / `max-width` / `min-width` / `height` / `left` /
`top` / `right` / `bottom` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex-basis`. `flex:0 0 4cqw` freezes exactly the way a `width` does.

Four exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`. That is where it goes, not how big it is. Used once, for the
  "most picked" tag in `pricing`, so it cannot push that card's title out of line with
  its neighbours.
- **`height:1px`** for a hairline rule.
- **`em`** on textless geometry — the legend dots in `chart-line` and `chart-donut`, the
  connector stubs in `flow-diagram` and `mindmap`, and `--sz` on a content-bearing
  `badge`. `em` scales with the type around it and cannot freeze a text box. These are
  layout/content devices, not optional decoration.
- **`%`** in `chart-bar`, `chart-donut` and `gantt`, where the number *is* the datum. A
  bar whose height is 83% is reporting 83, not making a layout choice.

Everything else stretches. Columns are `flex:1`. The safe area is set once, by the padding
on `.fit`: `12cqh 7cqw 10cqh`. The 7% is measured — see PLACEMENT.md F.
The shell also records it as `data-safe-area="0.07"` on `<html>` for the template-local audit.

This matters because the original reference deck was produced by measuring a rendered deck and writing
the numbers back. Its `width:50cqw`, `margin-top:30.0cqh` and `min-height:57.05cqh` are
observations of one string at one font size, not design decisions. Copying them reproduces
that string. These carry none.

Any flex child holding an SVG or a percentage-height bar needs `min-height:0`. Without it
the SVG's intrinsic ratio pushes the box past the stage edge.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions.
Not a slide.

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `two-column` `three-column` `color-cards` `key-points` `numbered-list`
`big-quote` `todo-checklist` `cards-grid`

**Numbers** · `kpi-grid` `kpi-cards` `kpi-burst` `stat-highlight` `table` `chart-bar`
`chart-line` `chart-donut`

**Time and sequence** · `process-steps` `timeline` `roadmap` `gantt`

**Structure** · `flow-diagram` `arch-diagram` `mindmap`

**Options and comparison** · `comparison` `versus` `pros-cons` `pricing`

**Imagery** · `image-left` `image-right` `image-hero` `image-grid` `team-grid` — all five
delete cleanly. `image-left` / `image-right` are a split row: the frame is `flex:1`, the
copy `flex:1.15`. When the source has no imagery, drop the `data-photocell` frame and use
a prose layout; do not leave an empty box.

## Where this list came from

Thirteen of these are compositions the reference deck already demonstrates, and those were
not negotiable: `cover` (p1), `toc` (p2), `section-divider` (p3/7/11), `image-right` (p4),
`numbered-list` (p5), `team-grid` (p6), `cards-grid` (p8), `process-steps` (p9),
`image-grid` (p10), `kpi-burst` (p12), `color-cards` (p13 — the testimonial page *is*
three filled cards), `pricing` (p14), `close` (p15).

Three more come from `../composition-recipes.html`, which holds treatments the example
does not: `big-quote`, `comparison` and `table`. They are re-expressed here in flex — the
recipes use `grid`, `clip-path` and written `cqw` widths.

The rest are the layouts a real deck needs and this template had no answer for. They are
built out of this template's own vocabulary, not borrowed wholesale from another list.

`chart-donut` rather than a pie: the segmented metric disc is already this template's own figure,
so a ring divided into four is the chart it was always going to draw.

Nothing was imported for symmetry with another template. There is no `terminal`, no
`code`, no `cta` — a large dark rounded rectangle reads as a photo placeholder here just
as it does in bloom, and a slide cannot be clicked.

## Which content device belongs to which layout

These devices carry, label or frame content. They are part of the naked layout itself and
must never receive `data-decoration`, `data-deco` or `data-ornament`.

| layout | content device |
|---|---|
| `numbered-list` | one `badge` per item, ground cycling `--g0 --g2 --g1 --g3` |
| `kpi-burst` | one `bbadge` burst-stat disc per figure |
| `team-grid` `image-grid` `image-left` `image-right` `image-hero` | one `photocell` per picture |
| `cards-grid` | one `tile` content icon per capability |
| `three-column` `process-steps` | nothing extra — these hold prose, using their own rules or nodes |
| `color-cards` `kpi-cards` `roadmap` `pricing` `versus` | the filled card is the content container, never decoration |

Every slide additionally carries one required mosaic **background treatment** and one or
two strict optional decorations (ring, arch or quarter-circle), placed per PLACEMENT.md B
and C. Those are page-role rules, not layout children.

## Ruled or filled — every peer row has both

15 of the 36 layouts separate their items with a hairline rule. That is a skewed menu: an
agent sampling it defaults to hairlines and every slide ends up with the same horizontal
line across it. Each of these content types therefore has two treatments, and neither is
more on-template than the other:

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `color-cards` |
| a row of numbers | `kpi-grid` | `kpi-cards` |
| two things compared | `comparison` | `versus` |
| a set of stages | `process-steps` | `roadmap` |

The filled versions cycle `--g0 --g2 --g1 --g3` so neighbours never share a colour.

Pick the filled version when the items are short and parallel, when the ruled version reads
thin, or simply when the previous slide was ruled.

## A filled box is sized by its content, never by the stage

Both dimensions.

```
height  row     flex:none        — from the tallest child, not the stage
        child   flex:1           — every sibling matches that tallest child
        group   wrapped in .centre (flex:1; min-height:0; justify-content:center)

width   box     align-self:flex-start; max-width:100%   (.hug)
```

`.fit` is a column flex with `align-items:stretch`, so **every child is full-width by
default**. `.hug` opts one box out.

The exception is a **row of peers** — cards, columns, flow nodes. Those stay equal width
and divide the safe area. One box hugs, a row of boxes divides.

`flex:1` on the **row** is not the same instruction: it makes the row fill the stage, so
the children inherit the stage's height and you get a slab of colour that is half empty.
Reserve a filling `flex:1` for an image frame or a chart plot area.

**Stress-tested, not assumed.** `probe-equal-height.js` injects an extra sentence into
the first item of every detected text-bearing peer row and compares sibling heights:
26 peer rows exercised, 0 unequal. The mind-map's two branch stacks around one hub are
not peers and are deliberately excluded. Four layouts failed this the first time —
`toc` and `numbered-list` carried
`align-items:flex-start`, which is the exact bug the playbook warns about, and `gantt` and
`table` would have exposed unequal cells the moment anyone gave them a ground.

`arch-diagram`'s bottom two layers are full-width bands. They carry a label *and* what sits
in that layer, set to opposite ends of the band, because a full-width slab holding one
centred word measured 13% filled and read as a colour block rather than a layer.

Reproduce the review and stress test from the repository root:

```bash
python3 Template-Presentation-v3/mosaic-geometric/layouts/sheet.py
agent-browser open file://$PWD/Template-Presentation-v3/mosaic-geometric/layouts/_sheet.html
agent-browser eval -b "$(base64 -w0 Template-Presentation-v3/mosaic-geometric/layouts/probe-equal-height.js)"
```

`_sheet.html` is generated review output and is intentionally not committed.

## Colour

Text is `--ka`, `--soft`, or on a `--g?` ground the matching `--t?`. Never a raw hue: on
the cream page `--s2` is 1.76:1, `--s3` 2.49 and `--accent` 2.56. Checked on all 36: zero
text below 3.0:1.

`--surface` appears in none of them. It is `#FFFFFF` on a `#FFFDF7` page. See PLACEMENT.md
E.

No layout puts the ground colour on `.stage`. This template has no full-bleed pages —
0 of 15 in the reference. See PLACEMENT.md F.

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` ·
structure `stage fit deck slide band card tile badge mosaic mtile` ·
marks `dot tick semi qcircle soft dim pagenum` ·
layout helpers `rule rule-on-field hug centre`

Sizes live in those classes. If something needs to be bigger, use the next class up.

## Every slide must be a direct child of `.deck`

A `.slide` nested one level deeper still renders, still scrolls, and still screenshots
correctly — and the arrow keys cannot reach it, because navigation collects pages with
`[...deck.children].filter(n => n.classList.contains('slide'))`.

One line, run it on anything you ship:

```js
document.querySelectorAll('.slide').length ===
  [...document.querySelector('.deck').children].filter(n => n.classList.contains('slide')).length
```
