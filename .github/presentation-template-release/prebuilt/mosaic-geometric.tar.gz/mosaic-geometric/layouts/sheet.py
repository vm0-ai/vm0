#!/usr/bin/env python3
"""Build a labelled, scrolling review deck from every mosaic layout."""

from pathlib import Path
import re


HERE = Path(__file__).parent
SHELL = (HERE / "_shell.html").read_text()
HEAD = SHELL[: SHELL.index("</style>")]

GROUPS = [
    ("Opening and closing", ["cover", "toc", "section-divider", "close"]),
    ("Prose", ["two-column", "three-column", "color-cards", "key-points", "numbered-list", "big-quote", "todo-checklist", "cards-grid"]),
    ("Numbers", ["kpi-grid", "kpi-cards", "kpi-burst", "stat-highlight", "table", "chart-bar", "chart-line", "chart-donut"]),
    ("Time and sequence", ["process-steps", "timeline", "roadmap", "gantt"]),
    ("Structure", ["flow-diagram", "arch-diagram", "mindmap"]),
    ("Options and comparison", ["comparison", "versus", "pros-cons", "pricing"]),
    ("Imagery", ["image-left", "image-right", "image-hero", "image-grid", "team-grid"]),
]

SHEET_CSS = """
.deck{scroll-snap-type:none;height:auto;overflow:visible;background:#111}
.slide{width:auto;height:auto;display:block;background:transparent}
.stage{width:1600px;height:900px;margin:0}
.sheet-label{font:600 28px/1.4 ui-monospace,monospace;color:#fff;background:#111;padding:10px 18px;letter-spacing:.04em}
.sheet-group{font:700 30px/1.4 ui-monospace,monospace;color:#111;background:#f6bb32;padding:14px 18px;letter-spacing:.08em}
</style>
"""

parts = []
count = 0
for group, names in GROUPS:
    parts.append(f'<div class="sheet-group">{group}</div>')
    for name in names:
        source = (HERE / f"{name}.html").read_text()
        match = re.search(r'(<div class="stage".*</div>)\s*</div>\s*</div>\s*</body>', source, re.S)
        if not match:
            raise RuntimeError(f"could not extract stage from {name}.html")
        parts.append(f'<div class="sheet-label">{name}</div><div class="slide">{match.group(1)}</div>')
        count += 1

output = HEAD + SHEET_CSS + "\n</head><body><div class=\"deck\">" + "\n".join(parts) + "</div></body></html>\n"
(HERE / "_sheet.html").write_text(output)
print(f"wrote {count} layouts to {HERE / '_sheet.html'}")
