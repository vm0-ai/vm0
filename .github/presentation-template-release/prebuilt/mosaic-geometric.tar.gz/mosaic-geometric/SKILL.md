---
name: mosaic-geometric
description: Create a standalone 16:9 HTML presentation deck with the Mosaic Geometric visual identity and direct-HTML workflow. Use when the user selects the Mosaic Geometric presentation template or explicitly names mosaic-geometric as the deck style. Best suited to saturated geometric creative-business stories, exhibitions, festivals, and cultural events.
---

# Mosaic Geometric presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one standalone HTML file with one live `.deck`. Keep every `.slide` as a direct child, give it one 16:9 `.stage`, and include the deck CSS and keyboard-navigation script once.
- Keep `data-safe-area="0.07"` on the root `<html>` element so the template-local audit uses
  mosaic-geometric's template constant.
- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Create one direct-child `.slide` per planned page and one 16:9 `.stage` inside each slide.

### Layout — start from a canonical layout

For each slide, adapt the closest file in [layouts/](layouts/). Those files carry the
reusable structure.

- Use flex for all content layout. No CSS grid, float, or absolute positioning for prose
  layout. Absolute positioning is for the stage shell, persistent chrome, mosaic
  background treatment, optional decoration, and an out-of-flow badge such as
  `pricing`'s "Most picked" tag.
- **Do not write `width`, `max-width`, `min-width`, `height`, `left`, `top`, `right`,
  `bottom`, `flex`, or `flex-basis` in `cqw`, `cqh`, `px`, `vw`, or `vh` on anything
  that holds text.** A frozen flex basis is a frozen width. The safe area is the sole
  exception: `padding:12cqh 7cqw 10cqh` on `.fit`, exactly once.
- Ornament-only geometry may use `em`; a one-pixel hairline may use `height:1px`; a
  chart or gantt bar may use `%` when the percentage is the datum. Nothing else is an
  exception.
- Peer columns are `flex:1`. One filled box that should hug its content uses
  `align-self:flex-start;max-width:100%`. A row of peer boxes remains equal-width and
  divides the safe area.
- A filled row takes its height from the tallest child: `flex:none` on the row, `flex:1`
  on each peer, with the whole row inside a centring wrapper. Do not put `flex:1` on the
  row itself; that stretches every box to the stage and leaves an empty slab.
- Any flex child that holds an SVG or percentage-height plot needs `min-height:0`.
- Use the supplied type classes instead of inventing font sizes. If copy needs a smaller
  class to fit, first shorten or split the content; do not squeeze the design around an
  overfull slide.
- Preserve the selected colour tokens, repeated chrome and mosaic geometry while varying
  page composition with the story. Keep all content inside the stage and the 7% safe
  area, and set `<html lang>`, `<title>`, `data-color-system`, `data-safe-area`, and the
  live deck's `aria-label` from the presentation.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

- Read [design-system.md](design-system.md) for the deck shell, motif library, and
  required chrome.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — motifs, background treatment, chrome;
  4. background treatments and optional motifs follow their documented roles and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is accurate but visually anonymous also fails.

- Optional: [example/reference.jpg](example/reference.jpg) for the visual identity and [layouts/](layouts/) for full-slide scale, rhythm, and composition.
- A mosaic-geometric slide has four independent roles, and this folder keeps them
  separate. Build them in this order and they cannot fight each other:

  | z-index | layer                                     | source                                                       |
  | ------- | ----------------------------------------- | ------------------------------------------------------------ |
  | 1       | required mosaic background treatment      | [decoration/PLACEMENT.md](decoration/PLACEMENT.md) section B |
  | 1       | optional ring / arch / quarter-circle     | `PLACEMENT.md` section C                                     |
  | 6       | persistent chrome — wordmark, page number | `PLACEMENT.md` section A                                     |
  | 40      | all text, inside `.fit`                   | [layouts/](layouts/) — 36 naked layouts                      |

  `layouts/` shows all three fused together at full scale. Use it to judge
  rhythm; take structure from `layouts/` and visual placement from `PLACEMENT.md`.

#### Which layout for which slide

Start from [layouts/README.md](layouts/README.md); it groups all 36 and names the pairs.

| the slide is                               | layout                                                                     |
| ------------------------------------------ | -------------------------------------------------------------------------- |
| the opening                                | `cover`                                                                    |
| an agenda or contents                      | `toc`                                                                      |
| a section break                            | `section-divider`                                                          |
| two or three parallel ideas                | `two-column` `three-column`, or filled: `color-cards`                      |
| a list of points                           | `key-points` (ruled) or `numbered-list` (badged) — **never a disc bullet** |
| four capability cards                      | `cards-grid`                                                               |
| one sentence that must land                | `big-quote`                                                                |
| status of a set of tasks                   | `todo-checklist`                                                           |
| a row of figures                           | `kpi-grid` (ruled), `kpi-cards` (filled), `kpi-burst` (burst-stat discs)   |
| one dominant number                        | `stat-highlight`                                                           |
| rows of records                            | `table`                                                                    |
| a series, a trend, a split                 | `chart-bar` `chart-line` `chart-donut`                                     |
| a method, dated events, phases, a schedule | `process-steps` `timeline` `roadmap` `gantt`                               |
| how parts connect or stack                 | `flow-diagram` `arch-diagram` `mindmap`                                    |
| two options weighed                        | `comparison` (quiet) or `versus` (loud)                                    |
| arguments for and against                  | `pros-cons`                                                                |
| tiers or packages                          | `pricing`                                                                  |
| a picture and copy                         | `image-left` `image-right`                                                 |
| pictures alone, or people                  | `image-hero` `image-grid` `team-grid`                                      |
| the closing                                | `close`                                                                    |

- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. Use it to identify the semantic columns, spacing rhythm, and chrome, then start from the corresponding safe file in `layouts/`. Do not copy the recipes' CSS grid, clipped shapes, or written `cqw` widths. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use the prompt's `color-system` when supplied, otherwise a preferred token from
  `design-system.md`. Inline that one `color-systems/<token>.css` in the final HTML.

#### Decoration

Decoration is not bound by the safe area: an ornament may cross it and bleed off the
stage where `PLACEMENT.md` says so. The safe area binds type and content.

Read [decoration/PLACEMENT.md](decoration/PLACEMENT.md) and open the labelled ledger in
[decoration/decoration.html](decoration/decoration.html). Apply these role rules:

- **The mosaic cluster is required background treatment, not decoration.** Its variants
  follow cover-close, divider, and content page roles, and every cluster bleeds beyond
  the stage. Tiles, colour blocks, grid cells and
  their fills never satisfy an ornament count and never receive `data-decoration`.
- **Only ring, arch and quarter-circle are declared optional decoration.** Use their
  exact `data-decoration` values and the page-role placements in `PLACEMENT.md`. Keep
  ordinary optional motifs inside the stage.
- **Badges, metric discs / burst-stat discs and photo frames carry content.** `data-badge`,
  `data-bbadge` and `data-photocell` remain valid layout devices, but are never optional
  ornaments and never receive a decoration marker. This template has no optional
  item-set motif, so it intentionally has no `decoration/item-sets.html`.
- **Use only the background glyph designs documented in `decoration.html`.** They live
  inside structural grid cells and are not optional decorations. Do not invent new glyphs.
- **`--surface` is not a panel colour.** Use it only where `design-system.md` assigns it
  inside a saturated glyph. Panels take a
  `--g?` ground with the matching `--t?` text, or no fill and a
  hairline rule.
- **`--s2`, `--s3` and `--accent` are fill-only.** Use documented foreground tokens for
  text and verify contrast with the selected colour system.
- **This template has no full-bleed pages.** Its identity is saturated geometry
  arriving at the edges of a cream page; a stage flooded with colour is a different
  template. Do not carry over bloom's "one page in four should be a colour field".
- **The safe area is 7cqw each side**, set once by the padding on `.fit`. A page that
  reduces that padding has broken the safe area even when it has no overflow.
- **Peer columns align on their first line.** The trap is a filled panel beside plain
  copy — the panel's padding pushes its first line down. Give both columns the same
  treatment, or match the plain column's top padding.
- **Alternate ruled and filled treatments.** Each peer row has a filled sibling —
  `three-column`/`color-cards`,
  `kpi-grid`/`kpi-cards`, `comparison`/`versus`, `process-steps`/`roadmap`.
- Optional decoration goes outside the region the content occupies — the empty half of
  the stage, the margins, the corners — or behind it at a contrast low enough
  that the text stays fully legible. A title crossing a background shape is the
  most common way these decks lose a layout mark.
- The mosaic background cluster must be cropped by the stage edge. Optional decoration
  follows the placements in `PLACEMENT.md`.
- Never place body copy on top of a photograph unless the photograph is a
  full-bleed field and the copy sits on a text-safe treatment.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Identity checks while authoring

First confirm the content survived: every point is still on its slide and no
image or caption appears that the material does not support. Then audit
identity:

- every slide carries the chrome from `Required chrome`;
- every declared optional decoration is a textless ring, arch or quarter-circle and
  carries its exact `data-decoration` value;
- the mosaic cluster stays a background grid treatment and cards, tiles, badges, metric
  discs, nodes, connectors and media frames are never marked as decoration;
- background and optional motifs appear on their documented page roles, without invented
  substitute circles, squares, arches or colour blocks;
- exactly one `data-color-system` token, and it is one of the preferred tokens;
- keep authored ornaments clear of type; any reported geometric crossing remains an
  optional-review candidate under `Automated QA` below.

Resolve any failure before running Automated QA.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
