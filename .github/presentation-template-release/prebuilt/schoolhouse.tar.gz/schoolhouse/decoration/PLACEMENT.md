# schoolhouse — decoration placement

Everything here is measured from the original reference deck (15 pages, 40 page-level
textless marks plus three attached corner halftones, rendered at 1600×900). Numbers, not
taste.

The fused example preserves its historical measured stamp anchors. They are evidence,
not production placement: generated decks use only the fixed top-right rule in section C.

Open `decoration.html` to see the vocabulary rendered without presentation copy, and
`item-sets.html` for the one genuine ornament that attaches to repeated items.

A counted decoration is explicit: it carries `data-decoration`, contains no text or
data, and performs no layout function. The attached halftones also carry
`data-decoration-size="small"`. Cards, square tiles, badges, colour blocks, rectangular
backgrounds, content containers, grid cells, media frames, nodes and connectors are
content or structure, never decoration. The page number is chrome and is counted
separately. On the stamp device, only the textless rings are decoration; the label is
bound text and is not counted.

The preview vocabulary therefore has **13 named decoration types**: `halftone`,
`stamp-rings`, `chevron-mark`, plus the ten closed line-icon names in section G. The
contained/card halftone is a placement variant of `halftone`, not a fourteenth type.

**These numbers are schoolhouse's. They are not bloom's, and several of them point the
opposite way** — bloom's ornaments hang off the stage edge 94 % of the time; schoolhouse's
do so 12 % of the time, and only one shape ever does it. Do not carry a rule across.

## The layer model

| z-index | layer | where it comes from |
|---|---|---|
| 1 | halftone field | this folder |
| 5–6 | line icons, chevron marks and stamp rings | this folder |
| 40 | `.fit` — all text | `../layouts/*.html` |
| 45 | pagenum | the shell |

Page-level decoration sits **below** text and outside `.fit`. The one exception is the
small corner halftone clipped inside each `stat-cards` card; it still sits behind the
card's content. Never move copy to make room for an ornament. A rubber stamp has one
fixed anchor; if that anchor is occupied, omit the stamp.

## A · Persistent chrome — one item, on every page

The page number, bottom right, on 15 of 15 reference pages including the cover and the
closing page:

```html
<div class="pagenum">page 01</div>
```

Measured: `right:3cqw`, `bottom:3.2cqh`, height 1.89cqh — so it occupies the band from
**93.9cqh to 96.8cqh** on the right edge. Content never enters it: the lowest any
reference content reaches is 92cqh.

Unlike bloom, schoolhouse has **no top chrome band**. Content may start at 11cqh, and
the reference does exactly that on its densest page.

## B · At most two page-level ornaments per page

**A generated page carries at most two page-level ornaments. Never three.** Two is the
ceiling, not a quota: one is equally correct, and zero is right when nothing fits. The
usual pair is a halftone field plus a rubber stamp, as `decoration.html` page 1 shows.

The attached corner halftones of the `stat-cards` item set (section H) are outside this
count: they are bound to their cards, carry `data-decoration-size="small"`, and are not
page-level marks. A `stat-cards` page may still carry its own page-level ornaments.

The historical reference deck ran past that ceiling — mean **2.87** page-level marks per
page, min **2**, max **5**, with a rubber stamp on 14 of its 15 pages. **The max of 5 is
superseded by the rule above.** Those readings are kept only because sections D–G quote
measurements taken from the same 43 ornaments; do not read them as a target. Never add or
reposition an ornament to reach any count.

## C · The stamp uses one fixed top-right anchor

When a page uses a rubber stamp, use this single anchor:

- `right:6cqw; top:12cqh`
- never top left or bottom left;
- never iterate through candidate anchors;
- if the fixed top-right slot would cover content, omit the stamp rather than moving
  content or trying another position.

This is a deterministic placement rule, not a search procedure. Other line-art ornaments
keep their documented positions; only the rubber stamp is constrained to this slot.

## D · The stamp itself — the word sizes the ring

```html
<div class="stamp" data-decoration-device="rubber-stamp" style="position:absolute;right:6cqw;top:12cqh;font-size:2cqw;color:var(--ink);transform:rotate(-8deg);z-index:6">
  <i data-decoration="stamp-rings"></i>
  <span class="stamp-label">JOIN</span>
</div>
```

The rings are a CSS border on the empty `<i>`; `aspect-ratio:1` on a `max-content` box
keeps them a true circle at whatever width the word needs. **Nothing here is a fixed
size and no script measures anything** — set `font-size` and write the word.

Measured diameters at `font-size:2cqw`, and the share of the ring's inner diameter the
ink takes:

| word | letters | diameter | ink / inner ring |
|---|---:|---:|---:|
| END | 3 | 9.4cqw | 0.52 |
| JOIN | 4 | 10.1cqw | 0.55 |
| KEYS | 4 | 10.8cqw | 0.57 |
| AGENT | 5 | 12.8cqw | 0.62 |
| BENCH | 5 | 12.9cqw | 0.62 |
| AGENDA | 6 | 14.7cqw | 0.65 |

Three to six letters all land inside the measured **7–15cqw** band, so `2cqw` is the one
constant worth stating. A longer word would leave the band; that is the signal to
shorten the word, not to shrink the type.

- rotation **−7° to −10°** (the reference uses −7, −8, −9, −10 and nothing else)
- `data-decoration` belongs on the textless rings element, not the wrapper that also
  carries the label; this keeps the label out of decoration statistics.
- on a colour field, both rings and the label switch to `var(--bg)`
- one short word or a two-digit number. Never a sentence.

**The earlier revision pinned the stamp at a fixed `width:11cqw` and the label at a
fixed `2.4cqw`, which only fit the reference word.** Measured ink at that size, against
an inner ring of 77px: END 65 · JOIN 73 · KEYS 81 · HARD 87 · TASKS 98 · AGENT 105 ·
BENCH 106 · AGENDA 128. Every five-letter word crossed the outer ring, and since the
letters and the ring share a colour it read as if the circle had been sliced off.

## E · Bleed — one shape only, and it is not the icons

**5 of 43 reference ornaments hang off the stage edge. All five are the halftone field.
The other 38 sit entirely inside the stage.** The separation is total:

| | bleeds | inside |
|---|---|---|
| halftone ≥20cqw | 5 | 0 |
| halftone 12cqw (in a card) | 0 | 3 |
| line icons and stamps | 0 | 35 |

So: **the halftone is cropped by the stage corner; nothing else is.** A line icon or a
stamp that runs off the edge is wrong for this template — which is the opposite of the
rule bloom arrived at.

## F · The halftone — its dots must contrast with what it sits on

Eight instances, two variants, no exceptions:

| where | size | dots | opacity | anchor |
|---|---|---|---|---|
| on a colour-field stage (`--g0`/`--g1`/`--g3`) | 30–34cqw | `var(--bg)` | .16–.18 | bleeding a corner |
| inside a white `--surface` card | 12cqw | `var(--ink)` | .16 | card's bottom-right, clipped by its `overflow:hidden` |

**Never put a `--bg`-dotted halftone on the `--ph` paper ground.** Both are near-white;
the mark disappears. This is the schoolhouse equivalent of bloom's white-on-cream trap,
and it is the one mistake this document exists to prevent.

## G · Line icons — the vocabulary is closed

Ten glyphs, all in `decoration.html`: `pencil` `paperclip` `star` `star-alt` `pin`
`ruler` `scissors` `book` `uniform` `clock`. All drawn at `stroke-width:1.9`, `fill:none`,
round caps and joins, 6–17cqw.

**Copy one. Do not redraw one, and do not substitute a circle, square, arch or colour
block for one.** Schoolhouse's identity is stationery line art; a generic geometric shape
reads as a different template.

Rotation on line icons ranges −22° to +14°. The chevron mark is never rotated.
Three chevrons used as a free-standing mark are decoration. A single chevron between
process nodes is a connector with a layout function and is not decoration.

## H · The one optional item-set decoration — every member, or none

See `item-sets.html`. The only repeated-item motif that passes the strict definition is
the textless corner halftone on `stat-cards`: **every card gets one, never some**.

| set | ornament | reference |
|---|---|---|
| `stat-cards` | corner halftone | 3 cards, 3 halftones |

Numbered badges carry numbers, icon tiles identify content, and leading chips carry time
or index data. They are content devices, not optional decoration, and are intentionally
absent from `item-sets.html`. The same applies to roadmap phase chips and the one "Most
popular" tier distinguisher: useful layout language, excluded from ornament counts.

## I · Colour — measured against this template's own tokens

Computed for `bauhaus_primary` against the `--ph` paper ground and the white `--surface`:

- **`--g2` (#F2B705) is never text.** 1.8:1 on white, 1.35:1 on paper. The reference uses
  it as a fill 6 times and as a text colour **0 times**. The same goes for `--accent`,
  `--s1`, `--s2`, `--s3` and the `--o*` set — they are fills and strokes only.
- As a numeral on a white card, only **`--g0` (4.6:1), `--g1` (5.9:1) and `--g3` (17.4:1)**
  are legible. The reference's three stat figures use exactly those three.
- **A `--surface` white box always carries the ink outline.** White on `--ph` paper is
  1.35:1 — the edge carries the contrast, not the fill. 18 of 18 reference uses have it.
  (Note this is the reverse of bloom, where `--surface` was forbidden outright.)
- **Nothing large is `--ink`-grounded.** No filled box wider than 8 % and taller than 6 %
  of the stage has luminance below .09 anywhere in the reference — a big dark rectangle
  reads as a photo placeholder. The `--ink` ground is for the small `tile` only.
- **6 of 15 pages are colour fields** (`--g0`, `--g1`, `--g3`); the other 9 are `--ph`
  paper. Every section divider, the cover, the closing page, and one data page.
- On a colour field a kicker uses `color:inherit`, never `--soft`, which reads 2.0:1 on
  `--g3`.

## J · What the probe reports, and what it means here

Calibration on the canonical `../layouts/` produced:

```
overflow 0   outsideSafeArea 0   aboveChromeBand 0
lowContrast 0   darkPanels 0   orphanSlides 0   indirectSlides 0
boxesUnderfilledV 0   boxesUnderfilledH 0
```

All ten read zero on the current reference, so all ten gate. The timetable rows were the
only former exception; each now has a real trailing location field and a content-hugging
asymmetric inset rather than an empty padded tail. All 43 extracted layouts also read zero
on both measures. See `../layouts/README.md`.

With only strict, textless decoration declared, the current template-local probe additionally
reads `bigOrnaments 40`, `bigPerPage 2.67`, `pagesWithPair 15`, `bleedingPct .125`, and
`smallOrnaments 3`. `offVocabularyShapes` is diagnostic only: its generic recogniser was
written for rect/path motifs and reports 20 on this closed circle-and-line vocabulary,
so it does not gate schoolhouse.

The declaration itself must read exactly:

```js
const declared = [...document.querySelectorAll(
  '[data-decoration],[data-deco],[data-ornament]'
)];
({
  declared: declared.length,
  carriesText: declared.filter(e => e.textContent.trim()).length,
  structural: declared.filter(e => e.matches(
    '[data-photocell],[data-tile],[data-badge],[data-bbadge],' +
    '[data-node],[data-connector],[data-background-field],[data-metric-disc]'
  ) || (e.closest('.fit,[data-device]') &&
        !e.matches('[data-decoration-size="small"]'))).length
});
```

Reference: `{declared:43, carriesText:0, structural:0}` — 40 page-level marks and three
explicitly allowed small corner halftones inside `stat-cards`.
