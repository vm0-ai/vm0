# Schoolhouse authoring core

This file is the sole authority for normal Schoolhouse authoring. Create a standalone 16:9 HTML presentation deck with the Schoolhouse visual identity and direct-HTML workflow. Use when the user selects the Schoolhouse presentation template or explicitly names schoolhouse as the deck style. Best suited to retro-print education brands, campus stories, workshops, and courseware.
Historical notes, full-page catalogues, and diagnostic files are provenance only. If
they disagree with this file, this file wins.

## Read and assembly contract

Read `tools/qa-config.json`, this file, `layouts/shell-contract.md`, the chosen
layout fragments, `resources/decoration.html` when a slide needs a signature motif, and one colour-system CSS in a single batch. Never read
`layouts/shared-shell.html`, `reference/`, full-page catalogues, unselected
fragments, or QA implementation files during normal generation.

The package contains one opaque shared shell and exactly 43
selectable stage fragments. Every fragment is one complete `.stage` and intentionally
contains no document shell, shared CSS, `.deck`, `.slide`, or runtime.

To assemble the deck:

1. Copy `layouts/shared-shell.html` once without reading it.
2. Inline one selected colour-system CSS and remove the local stylesheet link.
3. Between `BEGIN SLIDES` and `END SLIDES`, create one direct-child
   `<div class="slide">...</div>` per page and place one adapted stage fragment inside.
4. Set the root language, title, colour token, deck label, and required chrome from the
   actual presentation.

## Selectable fragments

`architecture`, `big-quote`, `case-study`, `chart-bar`, `chart-line`, `chart-pie`, `close`, `color-cards`, `comparison`, `concept-board`, `cover`, `flow-diagram`, `gallery`, `gantt`, `icon-cells`, `image-hero`, `image-left`, `image-right`, `key-value`, `kpi-grid`, `lesson-plan`, `longform`, `mind-map`, `note`, `numbered-list`, `price-tiers`, `process-steps`, `pros-cons`, `quotes`, `roadmap`, `ruled-rows`, `section-divider`, `stat-cards`, `stat-highlight`, `statement`, `table`, `team`, `three-column`, `timeline`, `toc`, `todo-checklist`, `two-column`, `versus`.

Choose by the job of the slide, not by filling a catalogue. Reuse is allowed, but vary
composition with the story.

## Identity lock

- The selected fragment is the visual grammar. Preserve its typography classes, spatial
  rhythm, motif construction, edge treatment, and chrome placement while replacing its
  placeholder content. Do not import a second design language or generic component set.
- Keep the shell's font tokens, radius system, 16:9 stage, and safe-area contract. Use
  only the template's existing CSS classes and palette variables unless source content
  requires a semantic chart distinction.
- Use exactly one supplied colour system. Preferred tokens are `bauhaus_primary`, `warm_sand`, `citrus_fresh`, `forest_editorial`, `coral_studio`; the shell default is `bauhaus_primary`. Inline that token's CSS once.
- Do not use literal black, white, or an off-palette colour as a substitute. Use
  `--surface` only when the selected fragment demonstrates a visible panel treatment;
  otherwise use a transparent panel or a matching palette pair. A full-bleed ground and
  its foreground must use a documented matching palette pair.
- Decoration is optional and textless. Reuse a motif already present in the selected fragment or copy one exact named motif from `resources/decoration.html` when the page role and available space call for it. Keep it outside narrative flow and below content; move or remove it when it competes with legibility. Never open a full-page decoration catalogue or invent another motif.

## Geometry and typography

- Narrative content stays inside the fragment's `.fit` safe area. Center the complete
  narrative group; in side-by-side compositions, center each peer within its own column.
- Keep peer rows content-sized with `align-items:stretch`; equal-width peers use
  `flex:1;min-width:0`. Never reserve an empty column.
- Do not assign fixed `width`, `max-width`, `height`, `flex-basis`, `left`,
  `top`, `right`, or `bottom` in canvas units to prose-bearing flow elements. Plot,
  ornament, and media geometry is allowed only on a textless root marked
  `data-fixed-geometry-ok`.
- Use the shell's existing display, heading, body, label, caption, and data classes.
  Split dense content rather than inventing a smaller type scale. Keep media whole with
  `object-fit:contain` unless the selected fragment is explicitly full bleed.

## Required chrome

Read `tools/qa-config.json` before writing chrome. The declared roles are `page-number`.
On every applicable stage, put each required item on one visible wrapper with the exact
`data-chrome="<role>"` name and preserve its `min`, `max`, and `when` contract.
Adapt stable labels and page numbers to the actual deck; do not remove identity chrome
to make room for content.

## Source, images, tables, and charts

- Use the supplied material as the source of truth. Label forecasts, targets, and
  assumptions, and never invent a claim or image to fill a slot.
- Choose a non-media fragment when no supported image exists. Every retained image cell
  must load successfully and carry useful alt text.
- Use a stat for one number, KPI peers for a handful, a table when many classes all
  matter, bars for magnitude, lines for time, and a stacked form for part-to-whole. Use
  one shared baseline, no dual axes, selective direct labels, and colour for entity or
  emphasis rather than decoration.

## Verification ownership

Author against these rules once. Rendered structure, navigation, safe area, overflow,
media, live `--surface`, fixed narrative geometry, colour-system integrity, and exact
chrome counts belong to the existing final QA. Do not repeat those mechanical checks
manually before or after it.
