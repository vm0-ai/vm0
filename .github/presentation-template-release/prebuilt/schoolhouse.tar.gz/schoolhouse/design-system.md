# Schoolhouse

## Visual identity

Retro campus posters with warm paper, sharp corners, heavy ink outlines, hard offset
shadows, rubber-stamp rings, stationery line art and halftone dots. The tone is practical,
cheerful and handmade; it is not a generic card dashboard.

## Authoritative files

Schoolhouse has separate content-layout and optional-decoration layers. Do not rebuild
either from this prose.

| purpose | authoritative source |
|---|---|
| stage, typography and content-device CSS | [`layouts/_shell.html`](layouts/_shell.html) |
| 43 content layouts | [`layouts/`](layouts/) and [`layouts/README.md`](layouts/README.md) |
| strict optional-decoration vocabulary | [`decoration/decoration.html`](decoration/decoration.html) |
| placement, frequency and classification | [`decoration/PLACEMENT.md`](decoration/PLACEMENT.md) |
| optional repeated-item decoration | [`decoration/item-sets.html`](decoration/item-sets.html) |
| visual reference rhythm | [`example/reference.jpg`](example/reference.jpg) |

Copy layout structure from `layouts/`, then add only the explicitly declared textless
marks from `decoration/`. The reference image is for visual rhythm and identity, not reusable geometry.

## Colour-system tokens

Read `color-system` from the prompt. If the prompt supplies a valid token, use it exactly.
Otherwise choose from the preferred list below based on audience, mood and readability.
Use one token for the whole deck.

Valid values:

- M, single-primary: `warm_sand`, `bauhaus_primary`, `nordic_frost`,
  `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`,
  `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`,
  `midnight_mono`, `ocean_deep`, `gold_luxe`.
- V, multicolour: `prism`, `carnival`, `pop_art`.

Preferred tokens, in order:

`bauhaus_primary`, `warm_sand`, `citrus_fresh`, `forest_editorial`, `coral_studio`

The reference uses `bauhaus_primary`. After selecting a token, read
`color-systems/<token>.css`, inline its only CSS block in the final standalone HTML,
and put the same token on the root:

```html
<html lang="en" data-color-system="bauhaus_primary">
```

Colour roles:

- `--ph` is the warm paper ground for most pages.
- `--g0`, `--g1` and `--g3`, paired with `--t0`, `--t1` and `--t3`, are the demonstrated
  large colour fields.
- `--surface` is a white index card only when its ink outline and hard shadow are present.
- `--g2`, `--accent`, `--s1`–`--s3` and `--o*` are fill/stroke-only tokens. Never use
  them as text.
- On a white card, a coloured figure may use `--g0`, `--g1` or `--g3`; those are the
  three reference-backed readable choices.
- On a colour field, use `color:inherit` for kicker text; `--soft` is too faint on `--g3`.

## Typography

Use Archivo for display and Manrope for body copy, with the CJK fallbacks already defined
in `layouts/_shell.html`.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600&family=Manrope:wght@300;400;500;600&display=swap" rel="stylesheet">
```

Available Archivo weights are 400 / 500 / 600 and Manrope weights are
300 / 400 / 500 / 600. Use Archivo for headings, hero numerals, kickers and section
indices; use Manrope for prose, captions, tables and chart annotations.

## Deck shell and layout contract

Start with `layouts/_shell.html`. Preserve one live `.deck`, one keyboard-navigation
runtime, one direct-child `.slide` per page and one 16:9 `.stage` inside each slide.

The safe area exists once, on `.fit`:

```css
.fit {
  position: absolute;
  inset: 0;
  z-index: 40;
  padding: 12cqh 6cqw 10cqh;
  display: flex;
  flex-direction: column;
  align-items: stretch;
}
```

Keep that padding on the shared `.fit` rule. Layout markup may repeat it inline, but the
shared class is the fallback and must remain sufficient when an inline style is replaced.

Everything that lays out content is flex. No grid, float or independent absolute
coordinates for content layout. Absolute positioning is reserved for `.fit`, the page
number, optional decoration, a clipped background field and a bound corner badge.

The universal sizing rule applies to every element that contains text: never give it a
`width`, `max-width`, `min-width`, `height`, `min-height`, `max-height`, `flex-basis`, or
flex shorthand basis in `cqw`, `cqh`, `px`, `vw` or `vh`.

- peer columns use `flex:1; min-width:0`;
- one box that hugs its copy uses `align-self:flex-start; max-width:100%`;
- a peer row is `flex:none` and its children stretch to the tallest peer;
- a hairline may use `height:1px`;
- a textless motif may use `em` sizing;
- percentage length is reserved for chart or gantt data;
- placement offsets are allowed on a genuinely out-of-flow element.

The rubber-stamp device contains a bound label, so its measured size is expressed without
a frozen width:

```html
<div class="stamp" data-decoration-device="rubber-stamp"
     style="position:absolute;right:6cqw;top:12cqh;font-size:2cqw;color:var(--ink);transform:rotate(-8deg);z-index:6">
  <i data-decoration="stamp-rings"></i>
  <span class="stamp-label">JOIN</span>
</div>
```

The rings are a CSS border on the empty `<i>`, and `aspect-ratio:1` on a `max-content`
box makes the circle follow the word: three to six letters all land inside the measured
7–15cqw band (END 9.4 · JOIN 10.1 · AGENT 12.8 · AGENDA 14.7). Set `font-size` and write
the word; there is nothing else to size.

Only the textless rings SVG carries `data-decoration`; the label is required bound text
and is excluded from ornament statistics.

## Content devices are not optional decoration

These devices carry content or perform layout work. Keep their schoolhouse styling, but
never mark or count them as decoration:

| device | role |
|---|---|
| ink-outlined card + hard shadow | index card / content container |
| numbered badge | item identity |
| icon tile | content-cell identity |
| leading chip | time, index or phase data |
| colour block / rectangular field | page or panel ground |
| grid cell / media frame | content structure |
| process node / connector | flow structure |
| page number | persistent chrome |

A kicker is plain text, not a chip. A large near-black rectangle is not part of the
reference vocabulary and reads as a missing photograph.

## Strict optional-decoration vocabulary

Decoration must be template-specific, textless, carry no data and perform no layout
function. Every counted mark carries `data-decoration`; the three attached card
halftones also carry `data-decoration-size="small"`.

There are 13 named optional-decoration types:

- `halftone` — one type with a large colour-field variant and a contained card variant;
- `stamp-rings` — the rings only, never the label wrapper;
- `chevron-mark` — three free-standing chevrons; one process connector is structure;
- ten closed line-icon names: `pencil`, `paperclip`, `star`, `star-alt`, `pin`, `ruler`,
  `scissors`, `book`, `uniform`, `clock`.

Use the exact rendered SVGs from `decoration/decoration.html`. Do not redraw them and do
not substitute a circle, square, arch, colour block or generic icon.

Reference ledger at 1600×900:

| measure | reference |
|---|---:|
| pages | 15 |
| page-level declared marks | 40 |
| attached small halftones | 3 |
| page-level marks per page | mean 2.67, min 2, max 4 |
| pages with at least two page-level marks | 15 / 15 |
| bleeding page-level marks | 5 / 40 (.125), all large halftones |
| stamp devices | 14 / 15 reference pages; production stamps are optional |

Placement and copyable markup live in `decoration/PLACEMENT.md`. The only optional
item-set decoration is the contained halftone: on `stat-cards`, every card gets one. The
badge, tile and chip examples belong to layout content and are intentionally absent from
`decoration/item-sets.html`.

## Photographs are content

Add a photograph only when the supplied material describes a specific person, object,
place, product or scene worth showing. Never invent a decorative photograph. Use a layout
with a media frame when the source supports it; zero photographs is valid for a text-only
source.

## Required chrome

The reference carries one bottom-right page number on 15 of 15 slides, including cover
and close:

```html
<div class="pagenum">page 01</div>
```

Chrome is not optional decoration and does not enter ornament counts.

## Delivery audit

Before delivery:

1. Run the sizing audit with `tools/run.sh` and require zero violations.
2. Run `tools/run.sh` on every layout and on the fused reference. Gate only
   readings calibrated to zero on the reference.
3. Require `overflow`, `outsideSafeArea`, `aboveChromeBand`, `columnsMisaligned`,
   `lowContrast`, `darkPanels`, `boxesUnderfilledV`, `boxesUnderfilledH`, `orphanSlides`
   and `indirectSlides` all to be zero.
4. Inject a longer sentence into the first peer and verify every text-bearing filled or
   outlined peer row equalises.
5. Render and look at every slide with the selected colour CSS and fonts loaded.
6. Confirm every declared decoration has no text, carries no data and is not a card,
   tile, badge, block, container, grid cell, media frame, node, connector or chrome.
7. Confirm every `.fit` computes to at least `12cqh 6cqw 10cqh` padding, and every stamp
   that is present uses the fixed top-right anchor from `decoration/PLACEMENT.md`.
8. Confirm total slides equals direct-child navigable slides, then physically press an
   arrow key.

Never let a motif cover copy, invent unsupported content, add a colour outside the
selected token file, or change layout code after the final preview screenshots.
