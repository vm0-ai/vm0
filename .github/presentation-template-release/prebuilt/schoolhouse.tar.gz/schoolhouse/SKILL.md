---
name: schoolhouse
description: Create a standalone 16:9 HTML presentation deck with the Schoolhouse visual identity and direct-HTML workflow. Use when the user selects the Schoolhouse presentation template or explicitly names schoolhouse as the deck style. Best suited to retro-print education brands, campus stories, workshops, and courseware.
---

# Schoolhouse presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one standalone HTML file with one live `.deck`. Keep every `.slide` as a direct child, give it one 16:9 `.stage`, and include the deck CSS and keyboard-navigation script once.
- **Every `.slide` must be a direct child of `.deck`.** The navigation runtime collects
  pages with `[...deck.children].filter(n => n.classList.contains('slide'))`, so a slide
  nested one level deeper, or written after the deck's closing `</div>`, is unreachable by
  the arrow keys. The page still renders, still scrolls by drag, and still screenshots
  correctly — nothing but a key press reveals it.
- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Create one direct-child `.slide` per planned page and one 16:9 `.stage` inside each slide.

### Recommended layout approach

- Start from a layout in [layouts/](layouts/) rather than composing from scratch; the
  table in Section 3 maps slide jobs to layouts.
- Everything is flex. No grid, no float, and no absolute positioning for layout — absolute
  positioning is for the decoration layer, the pagenum, and the two places `layouts/` uses
  it (a clipped colour field, a corner badge).
- A filled box is sized by its content, never by the stage, in both directions. On a peer
  row: the row is `flex:none`, each child is `flex:1`, and the group is wrapped in
  `flex:1;min-height:0;display:flex;flex-direction:column;justify-content:center`. `flex:1`
  on the row instead makes the cards inherit the stage's height and sit 40–60 % empty.
- Peer columns must agree on their first line. The trap is a filled panel beside plain
  copy: the panel's padding pushes its first line down, so the headings miss even though
  the boxes line up. Give the plain column a matching label, or match the panel's top
  padding.
- Preserve the template's original visual character from `design-system.md` and the examples. Compose content and signature elements together according to their visual and semantic roles, whether they belong inside the main layout or on a separate layer.
- Treat every slide as a projected presentation canvas. Write concise visible copy for the audience and keep one clear hierarchy of title, supporting content, and evidence on each page.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

- Read [design-system.md](design-system.md) for the deck shell, motif library, and
  required chrome.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — motifs, background treatment, chrome;
  4. every optional motif follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is accurate but visually anonymous also fails.

- Optional: [example/reference.jpg](example/reference.jpg) for the visual identity and [layouts/](layouts/) for full-slide scale, rhythm, and composition.
- A schoolhouse slide is three independent layers, and this folder keeps them in three
  separate places. Build them in this order and they cannot fight each other:

  | z-index | layer                                                                                          | source                                                                                                       |
  | ------- | ---------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
  | 1–6     | textless decoration; a stamp's bound label stays in its device but is not marked as decoration | [decoration/PLACEMENT.md](decoration/PLACEMENT.md), [decoration/decoration.html](decoration/decoration.html) |
  | 40      | presentation content, inside `.fit`                                                            | [layouts/](layouts/) — 43 naked layouts                                                                      |
  | 45      | pagenum                                                                                        | `layouts/_shell.html`                                                                                        |

  `layouts/` shows all three fused together at full scale. Use it to judge
  rhythm; take structure from `layouts/` and ornament placement from `PLACEMENT.md`.
  Production stamps follow the fixed top-right rule in `PLACEMENT.md`.

- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. Its packets carry this template's column, spacing, and chrome behaviour; adapt one rather than inventing table markup, which is where these decks lose content. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use the prompt's `color-system` when supplied, otherwise a preferred token from
  `design-system.md`. Inline that one `color-systems/<token>.css` in the final HTML.

#### Pick the layout first, then fill it

Start from [layouts/](layouts/) and [layouts/README.md](layouts/README.md).

| the slide's job                                 | layout                                          |
| ----------------------------------------------- | ----------------------------------------------- |
| open the deck                                   | `cover`                                         |
| list what is coming                             | `toc`                                           |
| start a section                                 | `section-divider`                               |
| close                                           | `close`                                         |
| one idea beside another                         | `two-column`                                    |
| three facets of one idea                        | `three-column` (ruled) · `color-cards` (filled) |
| one decisive statement                          | `big-quote`                                     |
| one authored thesis or position                 | `statement`                                     |
| a developed prose argument                      | `longform`                                      |
| a welcome or an aside, with a picture           | `note`                                          |
| what is done and what is open                   | `todo-checklist`                                |
| ordered principles or reasons                   | `numbered-list`                                 |
| a schedule or a list of records                 | `ruled-rows` (filled) · `key-value` (ruled)     |
| tabular evidence                                | `table`                                         |
| a row of measures                               | `kpi-grid` (ruled) · `stat-cards` (filled)      |
| one number that matters                         | `stat-highlight`                                |
| quantities compared                             | `chart-bar`                                     |
| a trend over time                               | `chart-line`                                    |
| how a whole divides                             | `chart-pie`                                     |
| a linear process                                | `process-steps`                                 |
| milestones across a period                      | `timeline`                                      |
| phases with items under them                    | `roadmap`                                       |
| who does what, and when                         | `gantt`                                         |
| before and after                                | `comparison` (framed) · `versus` (two grounds)  |
| advantages and trade-offs of one decision       | `pros-cons`                                     |
| challenge, action and measured result           | `case-study`                                    |
| the people                                      | `team`                                          |
| several pictures                                | `gallery`                                       |
| one picture and its explanation                 | `image-left` · `image-right`                    |
| one dominant source image                       | `image-hero`                                    |
| four things at a glance                         | `icon-cells`                                    |
| tiers or options to join                        | `price-tiers`                                   |
| what people said                                | `quotes`                                        |
| a branching flow                                | `flow-diagram`                                  |
| layered system responsibilities                 | `architecture`                                  |
| lenses branching around one theme               | `mind-map`                                      |
| objectives, lesson sequence and exit check      | `lesson-plan`                                   |
| definition, example, misconception and transfer | `concept-board`                                 |

Copy the layout's markup, replace the placeholder text, then add decoration from
`PLACEMENT.md`. Do not copy geometry out of `layouts/`.

**Sizing, the one rule that carries across every layout:** nothing that holds text gets a
`width`, `height` or `flex-basis` in `cqw` / `cqh` / `px` / `vw` / `vh`. Columns are
`flex:1`. A box that hugs its content is `align-self:flex-start; max-width:100%`. The safe
area is set once, by the padding on `.fit`: `12cqh 6cqw 10cqh`. Ornaments that hold no
prose may use `em`; when they do, give them a `font-size` or the `em` resolves against
the 16px root and the ornament renders as a speck. Pure textless fields may instead use
container units; the ban applies to elements that contain text.

The shared `.fit` class itself must carry `padding:12cqh 6cqw 10cqh`; an individual
layout may repeat that value inline, but inline markup must never be the only safe-area
enforcement. This keeps the safe area intact when generated content replaces a layout's
inline declarations.

#### Decoration

Decoration is not bound by the safe area: an ornament may cross it and bleed off the
stage where `PLACEMENT.md` says so. The safe area binds type and content.

Read [decoration/PLACEMENT.md](decoration/PLACEMENT.md) and open
[decoration/decoration.html](decoration/decoration.html), which shows every ornament
rendered without presentation copy.

Decoration is explicit and narrow: a counted mark carries `data-decoration`, contains
no text or data, and performs no layout function. The three attached halftones also carry
`data-decoration-size="small"`. Cards, square tiles, badges, colour blocks, rectangular
backgrounds, content containers, grid cells, media frames, nodes and connectors are
content or structure, never decoration. The page number is chrome and is counted
separately. On a rubber stamp only the rings are decoration; its required label is bound
text and is not counted.

- Use only Schoolhouse's documented motif vocabulary and placement rules.
- **At most two page-level ornaments per page. Never three.** Two is a ceiling, not a
  quota — one is equally correct and zero is right when nothing fits. The usual pair is a
  halftone plus a stamp. The `stat-cards` corner halftones are attached to their cards,
  not page-level marks, and do not count against this.
- A stamp is optional.
- **A rubber stamp has one allowed anchor: top right.** Use
  `right:6cqw;top:12cqh`. Never move it to the top left or bottom left, and never search
  through alternative anchors. If that one slot would cover content, omit the stamp.
- **Only the halftone bleeds off the stage.** Keep every other ornament inside. A line
  icon or a stamp running off the edge is wrong here.
- **The halftone's dots must contrast with what it sits on.** On a colour field they are
  `var(--bg)` at 30–34cqw; inside a white card they are `var(--ink)` at 12cqw. A
  `--bg`-dotted halftone on the `--ph` paper ground is invisible — both are near-white.
- **The line-icon vocabulary is closed**: `pencil` `paperclip` `star` `star-alt` `pin`
  `ruler` `scissors` `book` `uniform` `clock`. Copy one from `decoration.html`. Never
  redraw one, and never substitute a plain circle, square, arch or colour block — that
  substitution is what makes a deck stop looking like this template.
- **The only optional item-set decoration is the corner halftone.** A `stat-cards` page
  puts one textless halftone on every card, never some. Numbered badges, icon tiles and
  leading chips carry text, data or layout meaning; they remain content devices and are
  excluded from decoration. Copyable halftone markup:
  [decoration/item-sets.html](decoration/item-sets.html).
- **The lower-left quarter is the line-icon zone.** Do not bottom-anchor content into
  that zone when the selected page role uses a line icon.

#### Colour roles

- **`--g2` is never text.** Nor are `--accent`, `--s1`, `--s2`, `--s3` or the `--o*`
  set. They are fills and strokes.
- **As a numeral on a white card, use `--g0`, `--g1` or `--g3`.**
- **A `--surface` white box always carries the ink outline.** A white card here is an
  index card, not a hole, because it is outlined.
- **Nothing large is `--ink`-grounded.** A big dark rectangle reads as a photo
  placeholder. `--ink` grounds the small icon `tile` and nothing else.
- Use colour fields only for the page roles documented in `design-system.md`; ordinary
  content pages use the `--ph` paper ground.
- On a colour field a kicker uses `color:inherit`, never `--soft`, which reads 2.0:1 on
  `--g3`.
- **A kicker is not a chip.** The kicker, the page number and the standfirst are plain
  text — no background, no border, no pill. Only `badge`, `tile` and `chip` carry a fill.

#### Alternate ruled and filled

Several layouts separate items with a hairline, so a deck built by sampling them can put
the same horizontal line on every slide. Every peer content type has both treatments —
`three-column`/`color-cards`, `kpi-grid`/`stat-cards`, `comparison`/`versus`,
`key-value`/`ruled-rows`. Use the filled one when the items are short, when the ruled
version reads thin, or simply when the previous slide was ruled.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Identity checks while authoring

First confirm the content survived: every point is still on its slide and no
image or caption appears that the material does not support. Then audit
identity:

- every slide carries the page number from `Required chrome`;
- decoration remains recognisably Schoolhouse and follows `PLACEMENT.md`;
- every stamp that is present uses the fixed top-right anchor from
  `decoration/PLACEMENT.md`; a stamp is optional and is omitted when that slot is busy;
- every ornament maps to a named item and page role in `Motif library`,
  `decoration/decoration.html`, or `decoration/PLACEMENT.md`;
- no line icon or stamp crosses the stage edge, and no halftone sits on the paper ground;
- every card in the `stat-cards` item set carries its corner halftone; badges, tiles and
  chips remain unmarked content devices;
- no fill-only token (`--g2`, `--accent`, `--s1`–`--s3`, `--o*`) is used as text;
- exactly one `data-color-system` token, and it is one of the preferred tokens;
- keep authored ornaments clear of type; any reported geometric crossing remains an
  optional-review candidate under `Automated QA` below.

Resolve any failure before running Automated QA.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
