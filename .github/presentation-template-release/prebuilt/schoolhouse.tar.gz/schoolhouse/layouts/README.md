# schoolhouse — naked layouts

43 layouts containing only content and layout structure. No optional decoration and no
measured geometry. Pair one of these with `../decoration/PLACEMENT.md` to build a slide.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 43: zero `width` / `max-width` / `min-width` / `height` / `left` /
`top` / `right` / `bottom` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex-basis` too — a label gutter written `flex:0 0 8cqw` freezes exactly the
way a `width` does.

Exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`. Two sites only: the clipped colour field in `comparison` and the
  corner badge in `note`. That is where a thing goes, not how big it is.
- **`height:1px`** for a hairline rule.
- **`em`** on textless content devices — the checklist box, the timeline dot, the
  numbered badge, the icon tile, the legend swatch. `em` scales with the type around it,
  so it cannot freeze a text box the way `cqw` can. Give the element a `font-size` or the
  `em` resolves against the 16px root and the ornament renders as a speck — that bug was
  in the first cut of `todo-checklist` and `timeline`.
- **`%`** in `chart-bar`, `chart-line` and `gantt` only, where the number *is* the datum.
  A bar whose height is 61 % is reporting 61, not making a layout choice.

Everything else stretches. Columns are `flex:1`. The safe area is set once, by the padding
on `.fit`: **`12cqh 6cqw 10cqh`**.

That padding is part of the shared `.fit` CSS in every layout, including `_shell.html`.
Inline layout markup repeats it for readability, but is not the sole enforcement layer.

That 6cqw is not a guess — the reference's content sits at exactly 6.00cqw from the left
edge on all 15 of its pages, and 6.07cqw from the right. The probe's safe-area check uses
the same constant.

Any flex child holding an SVG or a percentage-height bar needs `min-height:0`, or the
SVG's intrinsic aspect ratio pushes the box past the stage edge.

This matters because the original reference deck was produced by measuring a rendered deck and writing
the numbers back — `width:40cqw`, `min-height:33.84cqh`, `margin-top:16.0cqh`. Those are
observations of one string at one font size, not design decisions. Copying them reproduces
that one string. These layouts carry none of them.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions. Not a
slide.

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Statements and prose** · `statement` `longform` `two-column` `three-column`
`color-cards` `big-quote` `note` `todo-checklist`

**Lists and records** · `numbered-list` `ruled-rows` `key-value` `table`

**Numbers** · `kpi-grid` `stat-cards` `stat-highlight` `chart-bar` `chart-line`
`chart-pie`

**Time and sequence** · `process-steps` `timeline` `roadmap` `gantt`

**Comparison and decisions** · `comparison` `versus` `pros-cons`

**People and pictures** · `team` `gallery` `image-left` `image-right` `image-hero`

**Systems and cases** · `flow-diagram` `architecture` `mind-map` `case-study`

**Schoolhouse teaching** · `lesson-plan` `concept-board`

**Other devices** · `icon-cells` `price-tiers` `quotes`

## Where the set came from

Thirteen are the compositions the original reference deck already demonstrates, one per page role:
`cover` `toc` `section-divider` `note` `numbered-list` `team` `icon-cells` `ruled-rows`
`gallery` `stat-cards` `quotes` `price-tiers` `close`.

Three come from `composition-recipes.html`: `big-quote`, `comparison`, `table`.

Eighteen are things a real deck needs that the reference did not yet
demonstrate, each written in schoolhouse's own vocabulary — heavy outline, hard offset
shadow, sharp corner, chip, chevron. `flow-diagram` and `process-steps` use the
`[data-device="process"] [data-node]` rule that was already in the shell but that no
reference page used.

Nine more close distinct communication gaps found in the catalogue audit:

- `statement` is an authored position, not an attributed quote;
- `longform` carries a developed argument without turning it into peer facets;
- `image-hero` gives one source visual the full evidence field;
- `architecture` groups responsibilities by system layer, while `mind-map` maps lenses
  around one theme;
- `pros-cons` weighs one decision, rather than comparing before/after states;
- `case-study` connects challenge, action and measured result;
- `lesson-plan` and `concept-board` serve the template's courseware and workshop use cases.

Deliberately **not** added, to avoid importing another design language: a terminal or code
frame (a large dark rounded rectangle reads as a photo placeholder here as much as it did
in bloom), a CTA button row (a slide cannot be clicked), and a radar chart.

## Ruled or filled — both, for every peer content type

The catalogue alternates hairline-separated and filled treatments so the menu is not
skewed. Each recurring peer content type has a purposeful counterpart:

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `color-cards` |
| a row of numbers | `kpi-grid` | `stat-cards` |
| two things compared | `comparison` | `versus` |
| a list of records | `key-value` | `ruled-rows` |
| one decision weighed | `pros-cons` | `comparison` / `versus` for state-to-state jobs |

The filled versions cycle `--g0 --g1 --g2 --g3` so neighbours never share a colour.

## How decoration attaches to the naked layouts

Only `stat-cards` has a reference-backed optional item-set decoration: add one clipped,
textless corner halftone to every card using `../decoration/item-sets.html`.

The numbered badge in `numbered-list`, ink-ground icon tile in `icon-cells`, leading chips
in `toc` and `ruled-rows`, roadmap phase chips, and the one "Most popular" tier
distinguisher all carry text, data or layout meaning. They are content devices, not
decoration; do not mark them `data-decoration` or include them in ornament statistics.
Other layouts take page-level decoration from `PLACEMENT.md`.

## What the probe reads on these

`../tools/run.sh` over all 43, totals:

| gate | reference | these 43 |
|---|---|---|
| `overflow` | 0 | **0** |
| `outsideSafeArea` | 0 | **0** |
| `aboveChromeBand` | 0 | **0** |
| `columnsMisaligned` | 0 | **0** |
| `lowContrast` | 0 | **0** |
| `darkPanels` | 0 | **0** |
| `orphanSlides` | 0 | **0** |
| `indirectSlides` | 0 | **0** |
| `boxesUnderfilledV` | 0 | **0** |
| `boxesUnderfilledH` | 0 | **0** |

Plus the equal-height stress test: an extra sentence injected into the first text-bearing
panel of every filled or outlined peer row. All covered rows equalise. The two peer rows
in `gallery` are the playbook's explicit media-frame exception: they reserve the available
image area with `flex:1` and carry no prose to stress. Plain title-beside-content columns
also carry no panel and are not part of this test.

The reference timetable and `ruled-rows` both use an asymmetric content-hugging inset and
a real trailing field; `roadmap` uses hairline-separated phase items; `todo-checklist`
carries a trailing state. All four devices now meet the same zero gate, and none gives a
record row stage-derived height.
