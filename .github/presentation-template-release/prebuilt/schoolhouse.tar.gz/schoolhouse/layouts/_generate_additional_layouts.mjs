#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const shell = fs.readFileSync(path.join(here, "_shell.html"), "utf8");
const head = shell.split("<body>")[0];

const layouts = {
  "statement": String.raw`
<div class="deck"><div class="slide"><div class="stage" data-slot="statement" style="background:var(--ph);color:var(--ink)">
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;padding:12cqh 6cqw 10cqh">
  <div class="kicker" style="color:var(--soft)">Point of view</div>
  <div class="centre" style="align-items:flex-start">
    <div class="hug">
      <h1 class="display" style="font-size:calc((6.5cqw) * var(--fit, 1));line-height:.98;color:var(--ink)">The clearest idea deserves the whole room.</h1>
      <p class="lead" style="margin-top:3cqh;opacity:.82">Use this page for a position, thesis or decision that should land before any supporting detail appears.</p>
    </div>
    <div class="rule" style="align-self:stretch;margin-top:4cqh;background:var(--ink);opacity:1;flex:none"></div>
    <p class="cap" style="margin-top:1.5cqh;opacity:.72">One assertion · one supporting line · no competing panel</p>
  </div>
</div>
<div class="pagenum">page 35</div>
</div></div></div>`,

  "longform": String.raw`
<div class="deck"><div class="slide"><div class="stage" data-slot="longform" style="background:var(--ph);color:var(--ink)">
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;padding:12cqh 6cqw 10cqh">
  <div class="kicker" style="color:var(--soft)">Field note</div>
  <h1 class="display" style="margin-top:.5cqh;font-size:calc((4.7cqw) * var(--fit, 1));line-height:1.0;color:var(--ink)">A longer argument, without shrinking the type</h1>
  <div class="centre" style="gap:2cqh;margin-top:2cqh">
    <p class="lead">A standfirst carries the premise in one readable breath. It tells the audience why the next paragraphs matter.</p>
    <div class="rule" style="background:var(--ink);opacity:1;flex:none"></div>
    <p class="body">The first paragraph establishes context and evidence. It stays full-width so the sequence reads as one essay rather than two unrelated columns. Sentences remain concise enough for projection while allowing a genuinely developed argument.</p>
    <p class="body">The second paragraph advances the implication, names the tension and closes on the action the audience should take. A final marginal line can hold a source, date or editorial note without becoming another content panel.</p>
    <div style="display:flex;align-items:flex-start;gap:1.2cqw;padding-top:1.4cqh;border-top:.4cqw solid var(--ink)"><div class="chip" style="background:var(--g2);color:var(--ink);flex:none">Edit</div><p class="cap" style="padding-top:.5cqh"><strong>Preserve paragraph order.</strong> Split to another slide before reducing body scale.</p></div>
  </div>
</div>
<div class="pagenum">page 36</div>
</div></div></div>`,

  "image-hero": String.raw`
<div class="deck"><div class="slide"><div class="stage" data-slot="image-hero" style="background:var(--ph);color:var(--ink)">
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;padding:12cqh 6cqw 10cqh">
  <div class="kicker" style="color:var(--soft)">Visual evidence</div>
  <h1 class="display" style="margin-top:.5cqh;font-size:calc((4.7cqw) * var(--fit, 1));line-height:1.0;color:var(--ink)">Let one source image carry the scene</h1>
  <div class="centre" style="margin-top:2.5cqh">
    <div data-photocell="1" data-photo-kw="wide scene explicitly described by the source" aria-label="Wide source image" style="flex:1;min-height:0;overflow:hidden;border:.45cqw solid var(--ink);box-shadow:.65cqw .65cqw 0 var(--ink);background:linear-gradient(135deg,var(--g1) 0 38%,var(--g2) 38% 67%,var(--g0) 67% 100%)"></div>
    <div style="display:flex;align-items:flex-start;gap:2cqw;margin-top:2cqh;flex:none">
      <p class="body" style="flex:1;min-width:0">The caption explains what the audience should notice in the image.</p>
      <p class="cap" style="flex:1;min-width:0;opacity:.7">Credit, location or source note sits beside it when supplied.</p>
    </div>
  </div>
</div>
<div class="pagenum">page 37</div>
</div></div></div>`,

  "architecture": String.raw`
<div class="deck"><div class="slide"><div class="stage" data-slot="architecture" style="background:var(--ph);color:var(--ink)">
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;padding:12cqh 6cqw 10cqh">
  <div class="kicker" style="color:var(--soft)">System view</div>
  <h1 class="display" style="margin-top:.5cqh;font-size:calc((4.8cqw) * var(--fit, 1));line-height:1.0;color:var(--ink)">Architecture by responsibility</h1>
  <div class="centre">
    <div data-device="process" style="display:flex;align-items:stretch;gap:1.3cqw;margin-top:3cqh;flex:none">
      <div data-device="index" class="stack" style="flex:1;min-width:0;gap:1.4cqh;background:var(--surface);padding:2.2cqh 1.5cqw">
        <div class="chip" style="background:var(--g2);color:var(--ink)">Sources</div>
        <div><h3 class="h3">People and tools</h3><p class="cap" style="margin-top:.5cqh;opacity:.78">Requests, authored files and live events enter through governed interfaces.</p></div>
        <div class="rule"></div>
        <div><h3 class="h3">Operational data</h3><p class="cap" style="margin-top:.5cqh;opacity:.78">Signals from the work are normalized before they move downstream.</p></div>
      </div>
      <div aria-hidden="true" style="display:flex;align-items:center;flex:none"><svg viewBox="0 0 100 100" style="width:2.3em;height:2.3em"><polyline points="30,14 62,50 30,86" fill="none" stroke="var(--ink)" stroke-width="13" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
      <div data-device="index" class="stack" style="flex:1;min-width:0;gap:1.4cqh;background:var(--g1);color:var(--t1);padding:2.2cqh 1.5cqw">
        <div class="chip" style="background:var(--surface);color:var(--ink)">Core</div>
        <div><h3 class="h3">Orchestration</h3><p class="cap" style="margin-top:.5cqh;opacity:.9">Rules coordinate routing, state transitions and recovery across the system.</p></div>
        <div class="rule"></div>
        <div><h3 class="h3">Shared services</h3><p class="cap" style="margin-top:.5cqh;opacity:.9">Identity, storage and policy provide one reusable operating layer.</p></div>
      </div>
      <div aria-hidden="true" style="display:flex;align-items:center;flex:none"><svg viewBox="0 0 100 100" style="width:2.3em;height:2.3em"><polyline points="30,14 62,50 30,86" fill="none" stroke="var(--ink)" stroke-width="13" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
      <div data-device="index" class="stack" style="flex:1;min-width:0;gap:1.4cqh;background:var(--surface);padding:2.2cqh 1.5cqw">
        <div class="chip" style="background:var(--g0);color:var(--t0)">Destinations</div>
        <div><h3 class="h3">Audience output</h3><p class="cap" style="margin-top:.5cqh;opacity:.78">Decisions and deliverables reach the people responsible for action.</p></div>
        <div class="rule"></div>
        <div><h3 class="h3">System feedback</h3><p class="cap" style="margin-top:.5cqh;opacity:.78">Outcome metrics return to the core and improve the next cycle.</p></div>
      </div>
    </div>
  </div>
</div>
<div class="pagenum">page 38</div>
</div></div></div>`,

  "mind-map": String.raw`
<div class="deck"><div class="slide"><div class="stage" data-slot="mind-map" style="background:var(--ph);color:var(--ink)">
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;padding:12cqh 6cqw 10cqh">
  <div class="kicker" style="color:var(--soft)">Idea map</div>
  <h1 class="display" style="margin-top:.5cqh;font-size:calc((4.8cqw) * var(--fit, 1));line-height:1.0;color:var(--ink)">One theme, four connected lenses</h1>
  <div class="centre">
    <div data-device="process" style="display:flex;align-items:center;gap:1.3cqw;margin-top:3cqh;flex:none">
      <div class="stack" style="flex:1;min-width:0;gap:1.4cqh">
        <div style="padding:1.4cqh 0;border-top:.4cqw solid var(--ink)"><div class="kicker" style="color:var(--soft)">01 · Context</div><h3 class="h3" style="margin-top:.6cqh">What shaped the theme and why it matters now.</h3></div>
        <div style="padding:1.4cqh 0;border-top:.4cqw solid var(--ink)"><div class="kicker" style="color:var(--soft)">02 · Evidence</div><h3 class="h3" style="margin-top:.6cqh">What makes the central claim credible.</h3></div>
      </div>
      <div aria-hidden="true" style="flex:none"><svg viewBox="0 0 100 100" style="width:2.3em;height:2.3em"><polyline points="70,14 38,50 70,86" fill="none" stroke="var(--ink)" stroke-width="13" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
      <div data-node="1" style="flex:1;min-width:0;background:var(--g1);color:var(--t1);padding:4cqh 1.8cqw;text-align:center;align-self:stretch;display:flex;flex-direction:column;justify-content:center;gap:.8cqh"><div class="kicker" style="color:inherit;opacity:.86">Central theme</div><h2 class="h2">The idea that holds the story together</h2></div>
      <div aria-hidden="true" style="flex:none"><svg viewBox="0 0 100 100" style="width:2.3em;height:2.3em"><polyline points="30,14 62,50 30,86" fill="none" stroke="var(--ink)" stroke-width="13" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
      <div class="stack" style="flex:1;min-width:0;gap:1.4cqh">
        <div style="padding:1.4cqh 0;border-top:.4cqw solid var(--ink)"><div class="kicker" style="color:var(--soft)">03 · Implication</div><h3 class="h3" style="margin-top:.6cqh">What changes because the theme is true.</h3></div>
        <div style="padding:1.4cqh 0;border-top:.4cqw solid var(--ink)"><div class="kicker" style="color:var(--soft)">04 · Action</div><h3 class="h3" style="margin-top:.6cqh">What the audience should do next.</h3></div>
      </div>
    </div>
  </div>
</div>
<div class="pagenum">page 39</div>
</div></div></div>`,

  "pros-cons": String.raw`
<div class="deck"><div class="slide"><div class="stage" data-slot="pros-cons" style="background:var(--ph);color:var(--ink)">
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;padding:12cqh 6cqw 10cqh">
  <div class="kicker" style="color:var(--soft)">Decision frame</div>
  <h1 class="display" style="margin-top:.5cqh;font-size:calc((4.8cqw) * var(--fit, 1));line-height:1.0;color:var(--ink)">What we gain, what we accept</h1>
  <div class="centre">
    <div class="peers" style="gap:2.2cqw;margin-top:3cqh">
      <div data-device="index" class="stack" style="padding:2.2cqh 1.6cqw;gap:1.2cqh">
        <div class="chip" style="background:var(--g1);color:var(--t1)">Advantages</div>
        <div><h3 class="h3">Faster alignment</h3><p class="cap" style="margin-top:.4cqh;opacity:.78">One shared frame shortens the decision.</p></div>
        <div class="rule"></div>
        <div><h3 class="h3">Clear ownership</h3><p class="cap" style="margin-top:.4cqh;opacity:.78">Roles and next steps become explicit.</p></div>
        <div class="rule"></div>
        <div><h3 class="h3">Reusable learning</h3><p class="cap" style="margin-top:.4cqh;opacity:.78">The pattern can travel to the next case.</p></div>
      </div>
      <div data-device="index" class="stack" style="padding:2.2cqh 1.6cqw;gap:1.2cqh">
        <div class="chip" style="background:var(--g0);color:var(--t0)">Trade-offs</div>
        <div><h3 class="h3">Up-front effort</h3><p class="cap" style="margin-top:.4cqh;opacity:.78">The team must agree on a common model.</p></div>
        <div class="rule"></div>
        <div><h3 class="h3">Less local freedom</h3><p class="cap" style="margin-top:.4cqh;opacity:.78">Exceptions need an explicit rationale.</p></div>
        <div class="rule"></div>
        <div><h3 class="h3">Ongoing stewardship</h3><p class="cap" style="margin-top:.4cqh;opacity:.78">Someone keeps the frame current.</p></div>
      </div>
    </div>
    <p class="cap" style="margin-top:2cqh;opacity:.72">Use for one decision with asymmetric benefits and costs—not for before/after states.</p>
  </div>
</div>
<div class="pagenum">page 40</div>
</div></div></div>`,

  "case-study": String.raw`
<div class="deck"><div class="slide"><div class="stage" data-slot="case-study" style="background:var(--ph);color:var(--ink)">
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;padding:12cqh 6cqw 10cqh">
  <div class="kicker" style="color:var(--soft)">Case study</div>
  <h1 class="display" style="margin-top:.5cqh;font-size:calc((4.8cqw) * var(--fit, 1));line-height:1.0;color:var(--ink)">From a stuck moment to a measurable result</h1>
  <div class="centre">
    <div class="peers" style="gap:2.2cqw;margin-top:3cqh">
      <div class="stack" style="gap:1.4cqh">
        <div data-device="index" style="padding:2cqh 1.5cqw"><div class="kicker" style="color:var(--soft)">Challenge</div><h3 class="h3" style="margin-top:.5cqh">The audience could see the symptoms, not the cause.</h3><p class="cap" style="margin-top:.7cqh;opacity:.78">Evidence was scattered and no owner held the full picture.</p></div>
        <div data-device="index" style="padding:2cqh 1.5cqw"><div class="kicker" style="color:var(--soft)">Action</div><h3 class="h3" style="margin-top:.5cqh">The team reframed the work around one shared sequence.</h3><p class="cap" style="margin-top:.7cqh;opacity:.78">They combined the signals, named the decision and assigned the next move.</p></div>
      </div>
      <div data-device="statcard" style="padding:2.6cqh 1.8cqw;display:flex;flex-direction:column;justify-content:center;gap:1.4cqh">
        <div class="kicker" style="color:var(--soft)">Result</div>
        <div class="stat" style="color:var(--g0)">3×</div>
        <h2 class="h2">Faster path from signal to action</h2>
        <div class="rule" style="background:var(--ink);opacity:1"></div>
        <p class="body">State the measured outcome, the comparison period and the source behind it.</p>
      </div>
    </div>
  </div>
</div>
<div class="pagenum">page 41</div>
</div></div></div>`,

  "lesson-plan": String.raw`
<div class="deck"><div class="slide"><div class="stage" data-slot="lesson-plan" style="background:var(--ph);color:var(--ink)">
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;padding:12cqh 6cqw 10cqh">
  <div class="kicker" style="color:var(--soft)">Lesson plan · 50 minutes</div>
  <h1 class="display" style="margin-top:.5cqh;font-size:calc((4.8cqw) * var(--fit, 1));line-height:1.0;color:var(--ink)">Teach, practise, check understanding</h1>
  <div class="centre" style="gap:2cqh;margin-top:2cqh">
    <div class="peers" style="gap:1.5cqw">
      <div data-device="statcard" style="padding:1.8cqh 1.3cqw"><div class="kicker" style="color:var(--soft)">Objective 01</div><h3 class="h3" style="margin-top:.5cqh">Explain the core idea</h3></div>
      <div data-device="statcard" style="padding:1.8cqh 1.3cqw"><div class="kicker" style="color:var(--soft)">Objective 02</div><h3 class="h3" style="margin-top:.5cqh">Apply it to an example</h3></div>
      <div data-device="statcard" style="padding:1.8cqh 1.3cqw"><div class="kicker" style="color:var(--soft)">Objective 03</div><h3 class="h3" style="margin-top:.5cqh">Defend one choice</h3></div>
    </div>
    <div data-device="ruled" class="stack" style="padding:1.2cqh 1.5cqw">
      <div style="display:flex;align-items:center;gap:1.3cqw;padding:1.2cqh 0"><div class="chip" style="font-size:calc((1cqw) * var(--fit, 1))">08 min</div><div style="flex:1;min-width:0"><h3 class="h3">Hook and prior knowledge</h3><p class="cap" style="opacity:.75">A prompt reveals what learners already believe.</p></div></div>
      <div class="rule"></div>
      <div style="display:flex;align-items:center;gap:1.3cqw;padding:1.2cqh 0"><div class="chip" style="font-size:calc((1cqw) * var(--fit, 1))">15 min</div><div style="flex:1;min-width:0"><h3 class="h3">Mini lesson and model</h3><p class="cap" style="opacity:.75">Teach the move, then show it in context.</p></div></div>
      <div class="rule"></div>
      <div style="display:flex;align-items:center;gap:1.3cqw;padding:1.2cqh 0"><div class="chip" style="font-size:calc((1cqw) * var(--fit, 1))">20 min</div><div style="flex:1;min-width:0"><h3 class="h3">Guided then independent practice</h3><p class="cap" style="opacity:.75">Release responsibility while feedback is immediate.</p></div></div>
      <div class="rule"></div>
      <div style="display:flex;align-items:center;gap:1.3cqw;padding:1.2cqh 0"><div class="chip" style="font-size:calc((1cqw) * var(--fit, 1));background:var(--g2)">07 min</div><div style="flex:1;min-width:0"><h3 class="h3">Exit ticket</h3><p class="cap" style="opacity:.75">One response proves what to reteach next.</p></div></div>
    </div>
  </div>
</div>
<div class="pagenum">page 42</div>
</div></div></div>`,

  "concept-board": String.raw`
<div class="deck"><div class="slide"><div class="stage" data-slot="concept-board" style="background:var(--ph);color:var(--ink)">
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;padding:12cqh 6cqw 10cqh">
  <div class="kicker" style="color:var(--soft)">Concept board</div>
  <h1 class="display" style="margin-top:.5cqh;font-size:calc((4.8cqw) * var(--fit, 1));line-height:1.0;color:var(--ink)">Definition, example, misconception, transfer</h1>
  <div class="centre">
    <div class="peers" style="gap:1.6cqw;margin-top:3cqh">
      <div data-device="index" class="stack" style="padding:2cqh 1.4cqw;gap:1cqh"><div class="chip" style="background:var(--g1);color:var(--t1)">Define</div><h3 class="h3">Name the idea precisely</h3><p class="cap" style="opacity:.78">A concise definition and the boundary around it.</p></div>
      <div data-device="index" class="stack" style="padding:2cqh 1.4cqw;gap:1cqh"><div class="chip" style="background:var(--g2);color:var(--ink)">Model</div><h3 class="h3">Show one worked example</h3><p class="cap" style="opacity:.78">Make the reasoning visible, not only the answer.</p></div>
      <div data-device="index" class="stack" style="padding:2cqh 1.4cqw;gap:1cqh"><div class="chip" style="background:var(--g0);color:var(--t0)">Correct</div><h3 class="h3">Surface the likely error</h3><p class="cap" style="opacity:.78">Contrast it with the rule that resolves it.</p></div>
      <div data-device="index" class="stack" style="padding:2cqh 1.4cqw;gap:1cqh"><div class="chip" style="background:var(--g3);color:var(--t3)">Transfer</div><h3 class="h3">Try a new situation</h3><p class="cap" style="opacity:.78">Prompt learners to explain why the move still works.</p></div>
    </div>
  </div>
</div>
<div class="pagenum">page 43</div>
</div></div></div>`,
};

for (const [name, body] of Object.entries(layouts)) {
  const output = `${head}<body>\n${body.trim()}\n</body></html>\n`;
  fs.writeFileSync(path.join(here, `${name}.html`), output);
}

console.log(`generated ${Object.keys(layouts).length} additional schoolhouse layouts`);
