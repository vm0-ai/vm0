#!/usr/bin/env python3
"""Build labelled, browser-renderable contact sheets for every schoolhouse layout."""

import pathlib
import re

HERE = pathlib.Path(__file__).parent
SHELL = (HERE / "_shell.html").read_text()
COLOR = (HERE / "../color-systems/bauhaus_primary.css").resolve().read_text()
HEAD = SHELL.split("<body>")[0].replace("schoolhouse — naked layout", "schoolhouse — layout contact sheet")
HEAD = HEAD.replace('<link rel="stylesheet" href="../color-systems/bauhaus_primary.css">', f"<style>{COLOR}</style>")
HEAD = HEAD.replace(
    "</head>",
    """<style>
      html,body{height:auto;overflow:visible}
      .deck{height:auto;overflow:visible;scroll-snap-type:none}
      .layout-label{position:absolute;left:1.2cqw;top:1.2cqh;z-index:90;
        background:var(--ink);color:var(--bg);border:.2cqw solid var(--bg);
        box-shadow:.35cqw .35cqw 0 var(--g0);padding:.7cqh 1.1cqw;
        font:700 1cqw/1 var(--fd),sans-serif;letter-spacing:.08em;text-transform:uppercase}
    </style></head>""",
)

ORDER = [
    "cover", "toc", "section-divider", "close",
    "statement", "longform", "big-quote", "note", "numbered-list", "todo-checklist",
    "two-column", "three-column", "color-cards",
    "image-left", "image-right", "image-hero", "gallery", "quotes",
    "kpi-grid", "stat-cards", "stat-highlight", "chart-bar", "chart-line", "chart-pie", "table",
    "timeline", "roadmap", "gantt", "process-steps", "flow-diagram", "architecture", "mind-map",
    "comparison", "versus", "pros-cons", "case-study",
    "team", "icon-cells", "key-value", "ruled-rows", "price-tiers",
    "lesson-plan", "concept-board",
]

names = sorted(p.stem for p in HERE.glob("*.html") if not p.stem.startswith("_"))
assert set(names) == set(ORDER), f"ORDER mismatch: missing={set(names)-set(ORDER)} extra={set(ORDER)-set(names)}"


def extract_stage(html: str, name: str) -> str:
    start = html.index('<div class="stage"')
    depth = 0
    for match in re.finditer(r"<(/?)div\b[^>]*>", html[start:]):
        depth += -1 if match.group(1) else 1
        if depth == 0:
            return html[start : start + match.end()]
    raise AssertionError(f"unbalanced stage in {name}")


slides = []
for name in ORDER:
    stage = extract_stage((HERE / f"{name}.html").read_text(), name)
    label = f'<div class="layout-label">{name}.html</div>'
    stage = stage.replace(">", ">" + label, 1)
    slides.append(f'<div class="slide">{stage}</div>\n')

chunk_size = 11
for index in range(0, len(slides), chunk_size):
    number = index // chunk_size + 1
    chunk = slides[index : index + chunk_size]
    output = HEAD + "<body>\n<div class=\"deck\" aria-label=\"Schoolhouse layout contact sheet\">\n"
    output += "".join(chunk)
    output += "</div>\n</body></html>\n"
    target = HERE / f"_contact-sheet-{number}.html"
    target.write_text(output)
    print(f"{len(chunk)} slides -> {target.name}")
