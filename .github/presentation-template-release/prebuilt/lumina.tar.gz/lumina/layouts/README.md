# lumina — naked layouts

37 layouts, text only. No decoration, no reference-string dimensions, no colour decisions
beyond the tokens. Pair one of these with
[../decoration/PLACEMENT.md](../decoration/PLACEMENT.md) to build a slide.

The removed full-deck HTML example was a *rendered* deck: its widths are observations of one string at
one font size. Copying them reproduces that string. These carry none.

## The one rule

**No sizing in container or viewport units on anything that holds text.** Verified across
all 37: zero non-exempt `width` / `max-width` / `min-width` / `height` / `left` / `top` /
`right` / `bottom` / `flex-basis` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

`flex-basis` counts. `flex:0 0 4cqw` freezes a column exactly the way a `width` does.

Exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something
  `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline.
- **`em`** on an ornament with no prose in it — a badge, a node, a legend dot. But an `em`
  only scales with the stage if its font-size does: these anchor it with
  `font-size:1.95cqw` (the `.h3` step), so `--sz:2.6em` lands on the reference's 5cqw badge
  at any render width. Sized against the default 16px instead, the badge came out at 42px
  and read as a dot.
- **`%`** in `chart-bar`, `roadmap` and `gantt` only, where the number *is* the datum. A bar whose
  height is 93% is reporting 93.
- **`flex:1`** to fill, on exactly two things: an image frame and a chart plot area.

Everything else stretches. Columns are `flex:1`. The safe area is set once, by the padding
on `.fit` — `12cqh 6cqw 8cqh`.

**6cqw is lumina's constant, measured not assumed.** Across 78 in-flow text runs in the
reference the most common left margin is exactly 6.0%, and the minimum on either side is
6.0%. At a 7% threshold the same deck reads 26 violations, so the constant is 6, not "about
6".

A flex child holding an SVG or a percentage-height bar needs `min-height:0`. Without it the
SVG's intrinsic aspect ratio pushes the box past the stage edge.

**A percentage height needs a parent with a definite height.** `chart-bar` first shipped
with its plot row set to `align-items:flex-end`, which makes each column hug its content —
so `height:46%` resolved against nothing and every bar rendered at 0px. Every probe still
read 0. The row is now `align-items:stretch` and the bar sits in its own
`flex:1;min-height:0` track.

## Files

`_shell.html` is the deck skeleton — head, fonts, colour-system link, class definitions,
the chrome snippet and the navigation runtime. Not a slide.

**Opening and closing** · `cover` `agenda` `section-divider` `close`

**Prose and points** · `statement` `longform` `numbered-points` `two-column` `three-column`
`colour-cards` `big-quote` `quote-cards`

**Numbers** · `stat-row` `kpi-cards` `stat-highlight` `table` `chart-bar` `chart-line`
`chart-donut`

**Time and sequence** · `process-steps` `timeline` `roadmap` `gantt`

**Structure** · `arch-diagram` `flow-diagram` `mindmap`

**Two things compared** · `comparison` `versus` `pros-cons` `tier-cards`

**Proof and people** · `case-study` `team-grid`

**Creative-studio work** · `creative-brief` — objective, audience, proposition and
deliverables in the order a campaign team needs them.

**Imagery** · `image-left` `image-right` `image-hero` `image-grid` `team-grid` — all five
delete cleanly. `image-left` / `image-right` are a split row: the frame is `flex:1`, the
copy `flex:1.15`, so the picture takes a little under half. When the source has no imagery,
drop the `data-photocell` frame and use a prose layout — never leave an empty box.

## Coverage audit

| communication need | layouts that cover it |
|---|---|
| cover / contents / section / ending | `cover` · `agenda` · `section-divider` · `close` |
| statement / long-form / points | `statement` · `longform` · `numbered-points` |
| two / three peer columns | `two-column` · `three-column` · `colour-cards` |
| image left / right / hero / gallery | `image-left` · `image-right` · `image-hero` · `image-grid` |
| quotation / testimonials | `big-quote` · `quote-cards` |
| KPI / charts / table | `stat-row` · `kpi-cards` · `stat-highlight` · `chart-bar` · `chart-line` · `chart-donut` · `table` |
| timeline / roadmap / Gantt | `timeline` · `roadmap` · `gantt` |
| process / architecture / mind map | `process-steps` · `flow-diagram` · `arch-diagram` · `mindmap` |
| comparison / versus / pros-cons | `comparison` · `versus` · `pros-cons` · `tier-cards` |
| case evidence / team | `case-study` · `team-grid` |
| Lumina campaign work | `creative-brief` |

## Where this list came from

The first 16 are what the template already demonstrates: 13 page roles in
`layouts/` (its own markup names them — `data-device="toc"`, `factrow`,
`numbered-list`, `team`, `services`, `process`, `gallery`, `statband`, `quote`, `price`,
plus cover, divider and close) and 3 packets in `composition-recipes.html` (`big-quote`,
`comparison`, `data-table`).

The next 15 are what the nine benchmark sources actually need and the template did not
have: an earnings deck needs `chart-bar` / `chart-line` / `chart-donut` / `table`, two
lecture sources need `arch-diagram` and `flow-diagram`, a talk needs `stat-highlight` and
`big-quote`, and §10 of the playbook wants a filled counterpart for every ruled peer row.

The final six close communication jobs found in the cross-template review, without
duplicating an existing composition:

- `statement` is an authored thesis with a supporting implication; `big-quote` remains an
  attributed voice.
- `longform` is one narrative with a subordinate reading rail; `two-column` remains two
  peer arguments.
- `gantt` exposes concurrent calendar lanes and hand-offs; `roadmap` remains strategic
  phases and `timeline` remains dated history.
- `mindmap` uses Lumina colour fields and hairline connectors to branch from one central
  proposition; it is not a borrowed node-diagram skin.
- `case-study` binds visual evidence to challenge, intervention and result.
- `creative-brief` is the template's campaign-specific objective / audience / proposition /
  deliverables page.

Nothing was imported wholesale from another template's list. `chart-radar` was considered
and dropped because it has no Lumina expression or benchmark need distinct from the
existing quantitative charts.

## Ruled or filled — every peer row has both

15 of the 37 layouts separate items with a hairline. That is a skewed menu: an agent
sampling it puts the same horizontal line on every slide. So each peer-row content type has
two treatments, and neither is more on-template:

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `colour-cards` |
| a row of numbers | `stat-row` | `kpi-cards` |
| two things compared | `comparison` | `versus` |
| a list of options | `pros-cons` | `tier-cards` |

The filled versions cycle `--g0 --g2 --g1 --g3` so neighbours never share a colour. Put a
"most relevant" badge at `position:absolute` in a card's top-right so it does not push that
card's title out of line with the others.

Pick the filled version when the items are short and parallel, when the ruled version reads
thin, or simply when the previous slide was ruled.

## A filled box is sized by its content, never by the stage

```
height  row     flex:none      — from the tallest child, not the stage
        child   flex:1         — every sibling matches that tallest child
        group   wrapped in flex:1;min-height:0; … justify-content:center

width   box     align-self:flex-start; max-width:100%
```

`.fit` is a column flex with `align-items:stretch`, so **every child is full-width by
default**. That default is why boxes come out too wide. `align-self:flex-start` opts one
box out.

The exception is a **row of peers** — cards, columns, flow nodes. Those stay equal width
and divide the safe area. One box hugs; a row of boxes divides.

`flex:1` on the **row** looks like the same instruction and does the opposite: the row
fills the stage and the cards inherit the stage's height, giving a slab of colour that is
half empty.

All 37 pass the equal-height stress test described in the playbook, which injects an
extra sentence into the first item of every peer row and compares sibling heights.
`align-items:stretch` on its own is not evidence — it equalises siblings *to each other*,
which is a different thing from equalising them to the tallest content.

## Colour: what the tokens can and cannot do here

Measured against prism's `#FFFFFF` page:

| token | contrast | use as |
|---|---|---|
| `--ink` 15.9 · `--soft` 6.6 · `--ka` 5.2 | pass | text or fill |
| `--s1` 2.82 · `--s3` 2.56 · `--s2` 1.48 | fail | **fill only** |

The reference deck broke this itself: its agenda numerals were set in `--s1` / `--s2` /
`--s3` at 1.7cqw, reading 2.82 / 1.48 / 2.56 against white — against the rule
`design-system.md` states two sections earlier. Those five numerals now use `--ka` / `--k1`
/ `--k2` / `--k3`, the contrast-safe siblings, and the reference reads `lowContrast 0`.

On a `--g?` ground use the matching `--t?`, never a scheme colour. On a full-bleed page a
kicker uses `color:inherit`, never `--ka`.

**Never `--surface`.** It is `#F7F7FA` on a `#FFFFFF` page — a near-white rectangle on
white. The reference and all 37 layouts paint it zero times. Panels here are: no fill plus
a hairline for prose, `--g0..--g3` with matching `--t?` for a filled card, `--ph` for an
image frame.

`section-divider`, `close` and `stat-highlight` are **full-bleed** — the ground is on
`.stage`, not on a box inside it. The reference has 4 full-bleed pages out of 15; that is a
reported profile, not a quota, because the generated deck's page-role mix may differ.

## Chrome and navigation are not in these files

The naked layouts carry no chrome and no page number, so that the probe measures
composition rather than furniture. Both are in `_shell.html`, and both are required on
every slide of a real deck — the reference carries them on 15 of 15.

**Every `.slide` must be a direct child of `.deck`.** The navigation runtime collects pages
with `[...deck.children].filter(n => n.classList.contains('slide'))`. A slide nested one
level deeper renders, scrolls and screenshots perfectly and is unreachable by the arrow
keys. Self-check:

```js
document.querySelectorAll('.slide').length ===
  [...document.querySelector('.deck').children].filter(n => n.classList.contains('slide')).length
```

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` · structure
`stage fit deck slide band card tile badge` · marks `dot tick soft dim rule pagenum bz ttl`.

Sizes live in those classes. If something needs to be bigger, use the next class up — do
not write a `font-size` on a text element.

`.bz` is the handwritten letter substituted into a title. It must land on **a letter**: a
`.bz` span wrapped around a space renders nothing, the slide silently loses the template's
signature move, and no probe reading changes. Five of these layouts shipped that way before
`build_layouts.py` grew an assert for it.

A `.bz` glyph overflows its line box by about 4cqh above and 3cqh below, and flex stacks by
line box, so anything directly above a `.display` carrying one needs 4cqh of clearance.
