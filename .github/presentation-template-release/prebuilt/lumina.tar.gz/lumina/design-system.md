# Lumina

## Visual identity

A bold creative-agency language: oversized grotesque titles, hand-brushed letter substitutions, tape-like sticker labels, eight-point asterisks, and sharp-cornered colour blocks.

## Color system tokens

Read the prompt's `color-system` before generating. If it supplies one of the valid tokens below, use that token exactly. If it does not, choose from the tokens below according to the content, audience, mood, information density, and readability. Use only one token throughout a deck.

The presentation category documented for this template is **V (multicolour)**, with `prism` as its example token. Determine the generated deck's token using the rule above.

Use only the following snake_case values as valid tokens:

- Single-primary M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`prism`, `carnival`, `pop_art`, `citrus_fresh`, `berry_pop`

The default color system used in `example/reference.jpg` is `prism`.
Picking a token outside this list is how a deck ends up looking like a different
template: a finance source, for instance, pulls every template toward the same
muted corporate grey unless the list stops it.


After selecting a token, read `color-systems/<token>.css`, inline that file's single CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="prism">
```

- Use `--bg`, `--ink`, `--soft`, and `--ph` for the page, body copy, secondary text, and image placeholders. `--surface` exists in the shared token set but is not painted anywhere in this reference: under `prism` it is `#F7F7FA` on a `#FFFFFF` page, so do not use it as a panel.
- `--accent`, `--s1`, `--s2`, and `--s3` are raw hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected for those raw hues in v1; use them for large icons or decorative symbols. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use the contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text. Use `--kad` for accent text on an `--ink` field. When a raw hue needs higher text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour fields containing text, use `--g0` through `--g3` and pair each with the matching `--t0` through `--t3`.
- HTML/CSS components must reference colours only through `var(--...)`; derive transparency, strokes, shadows, and gradients from defined tokens as well.

Let `--bg` support four equally weighted hues. Choose one dominant hue per slide for a sticker, colour cell, or section field, and use the remaining hues as small rhythmic accents.

```css
.slide { background: var(--bg); color: var(--ink); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Poppins` as the display typeface, `Figtree` as the body typeface, and `Caveat` for handwritten letters.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&family=Figtree:wght@300;400;500;600&family=Caveat:wght@600;700&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Poppins";
  --fb: "Figtree";
  --brush: "Caveat";
  --fw-brush: 700;
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
.brush-letter { font-family: var(--brush), var(--fd), var(--cjk-display); font-weight: var(--fw-brush); }
```

Available display weights are 400 / 500 / 600; available body weights are 300 / 400 / 500 / 600; available handwritten weights are 600 / 700. Use `--fd` for titles, hero numbers, and section numbers; use `--fb` for body copy, labels, chart annotations, and tables. For CJK content, preserve the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the template's normalized base stylesheet; it matches
`layouts/_shell.html`. Copy that shell into the single `<style>` block, immediately
after the inlined colour-system CSS, before writing any slide. It defines the 16:9
stage, the type scale, and the chrome and decoration classes the rest of this
document refers to. A deck that invents its own class names instead of using these
will not look like this template.

```css
:root{
  --r-xs: .5cqw;
  --r-sm: .9cqw;
  --r-md: 1.7cqw;
  --r-lg: 3cqw;
  --r-xl: 5cqw;
  --fd: "Poppins";
  --fb: "Figtree";
  --brush: "Caveat";
  --fw-brush: 700;
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);overflow-wrap:break-word;word-break:normal;}
.stage *{overflow-wrap:break-word !important;word-break:normal !important;}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}
  

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:45;}

.tile{width:var(--sz,2.4em);height:var(--sz,2.4em);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;}
.tile>span{font-size:40cqw;line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{width:var(--sz,2.4em);height:var(--sz,2.4em);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;}
.badge>span{font-size:40cqw;line-height:1;}
.tick{position:absolute;}
.card{border-radius:var(--r-md);}
.dot{border-radius:50%;}.qcircle{border-radius:50% 0 0 0;}.semi{border-radius:999px 999px 0 0;}.tri{width:0;height:0;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}
.bz{font-family:var(--brush),var(--fd),var(--cjk-display);font-weight:700;font-size:1.18em;line-height:.8;padding:0 .03em;letter-spacing:normal;}
.ttl{display:inline-block;}
```
The number inside a `badge` and any text inside a `tile` must be wrapped in a
`<span>`. The wrapper is what makes the text scale with the box: it is measured
against the badge's own width, so the figure stays in proportion at any size.
Give the badge or tile a stage-scaled font anchor such as `font-size:1.95cqw`,
then size `--sz` in `em` (`--sz:2.6em`). Text placed directly in the box will not
scale against the box. Never size a text-bearing badge with `cqw`/`cqh`
`width`/`height`.


## Signature elements

Identity is classified by role: `asterisk8` and the divider `bigcircle` are optional
decoration; `sticker-tag` is a text-bearing signature label; `brush-letter` is typography;
`colour-cell` is layout/background treatment.


Visual reference: [example/reference.jpg](example/reference.jpg)

## Motif library

Every motif below is copied out of this template's own reference deck. This is
the geometry that makes the template recognisable, and it is the part that goes
missing when a deck is authored from the prose alone — the shapes exist nowhere
else; it is reproduced here so generation never needs a full-deck HTML example.

**Copy these snippets. Do not paraphrase them, redraw them, or substitute a
shape that is easier to write.** Change only size, position, colour token, and
text content. The count beside each motif is how many times the reference deck
uses it across fifteen slides. It records prevalence; it is not a floor, quota,
or target to scale mechanically. Use a motif only where the closest reference
page role uses it and the composition benefits.


### `badge` — structural item marker, used 2× (not optional decoration)

```html
<div class="badge" data-badge="1" style="font-size:1.95cqw;--sz:2.6em;background:var(--g0);color:var(--t0)"><span>01</span></div>
```

### `bigcircle` — optional decoration, used 3× in the reference deck

```html
<div data-decoration="bigcircle" data-bigcircle="1" style="position:absolute;right:-23cqw;bottom:-12.88cqh;width:46cqw;height:46cqw;background:var(--s1);border-radius:50%;opacity:1;z-index:1"></div>
```

### `doodle` / `asterisk8` — optional decoration, used 14×

```html
<div data-decoration="asterisk" data-doodle="1" style="position:absolute;right:34cqw;top:16cqh;width:6cqw;height:6cqw;z-index:4"><svg viewBox="0 0 100 100" style="width:100%;height:100%;display:block"><rect x="4" y="42.5" width="92" height="15" rx="7.5" transform="rotate(0 50 50)" fill="var(--ink)"/><rect x="4" y="42.5" width="92" height="15" rx="7.5" transform="rotate(45 50 50)" fill="var(--ink)"/><rect x="4" y="42.5" width="92" height="15" rx="7.5" transform="rotate(90 50 50)" fill="var(--ink)"/><rect x="4" y="42.5" width="92" height="15" rx="7.5" transform="rotate(135 50 50)" fill="var(--ink)"/></svg></div>
```

### Page-role locator — `data-slot`, used 15× (not a motif)

`data-slot` classifies the page role; it is shell metadata, not decoration. Find the stage
in [layouts/](layouts/) by searching for the opening tag below.

```html
<div class="stage" data-slot="cover">
```


### CSS signatures

These declarations are part of the template's look. The counts are from the reference deck.

| property | values it actually uses | why it matters |
| --- | --- | --- |
| `box-shadow` | `0 2px 8px color-mix(in srgb, var(--ink) 12%, transparent)` ×21 | offset shadows are a signature, not a default |
| `border-radius` | `.5cqw` ×23<br>`.6cqw` ×4<br>`.4cqw` ×4<br>`50% 0 0 0` ×1 | arches, capsules and part-round corners |
| `transform` | `rotate(-5deg)` ×8<br>`rotate(-6deg)` ×1<br>`rotate(5deg)` ×5<br>`rotate(4deg)` ×4<br>`rotate(-4deg)` ×3 | deliberate tilt |


### Not captured above

These named identity treatments have no extractable snippet in this library:
`sticker-tag`, `brush-letter`, `asterisk8`, `colour-cell`. Read
[layouts/](layouts/) for them and copy the markup from the slide
that uses them; do not improvise a substitute. `brush-letter` is typography and
`colour-cell` is layout/background treatment; neither belongs in optional-decoration
counts.


**A `.bz` letter overflows its line box.** It is set at `1.18em` with
`line-height:.8`, so the glyph reaches about `4cqh` above its line and `3cqh`
below it — measured on both the reference deck and generated ones, the figure is
the same. The line box does not grow to fit it, and flex layout stacks by line
box, so whatever sits directly above a `.display` carrying a `.bz` needs at
least `4cqh` of clearance or the brush letter lands on it. In the reference the
section number and its kicker sit a full line clear of the title; generated
decks that tuck them right underneath end up with the kicker under the glyph.

## Extracted visual-treatment profile (not decoration counts)

Observed from this template's own reference deck, per slide, rendered at
1600×900. These averages combine unlike page roles: covers, section dividers,
dense content pages, comparisons, and closings.

**These figures are diagnostics, never quotas, per-slide instructions, or optional
decoration counts.**
First choose the closest page role in [layouts/](layouts/),
then use only the named signature elements and motifs demonstrated in that
composition. A utility class, empty colour field, outlined box, circle, pill,
arc, quarter-circle, or other shell geometry is not a motif by itself.

| per slide | extractor category | size |
| --- | --- | --- |
| **0.2** | solid colour field | 20cqw and wider |
| **0.3** | drawn shape | 7.5–20cqw |
| **0.7** | drawn shape | 2.5–7.5cqw |
| **0.3** | circle or pill | 2.5–7.5cqw |


Read the figures only as a whole-deck drift signal. Around half the reference
rate can be appropriate when the material or page-role mix differs. Judge
fidelity by motif identity, placement, and composition rather than item count.
Sparse slides are intentionally sparse.

The reference deck contains **15 image cells across 15 slides (1.0 per slide)**. That is
not a target: this template forbids inventing a photograph the source material does not
support, so a deck built from a text-only source is right to draw fewer — and image cells
are excluded from the counts above for the same reason.

The extractor table groups non-content treatments by geometry, so its solid fields,
circles and pills must not be reported as optional decoration. The separate **1.4 labelled
boxes per slide** is exactly the measured 21 stickers across 15 pages; because they carry
text, those are signature labels rather than decoration. Follow the explicit classification
and page-role counts in `decoration/PLACEMENT.md`, not a geometry bucket or per-slide quota.

**A kicker is not a chip.** In this template's reference deck the `kicker`, the
page number, the running head and the standfirst are plain text — no background,
no border, no shadow, no rounded pill around them. Every one of the 23 reference
decks agrees on this, and giving them a box is the single most common way a
generated deck drifts: a kicker appears on every slide, so boxing it adds one
false chip per slide and doubles this template's labelled-box count on its own.

Only the measured tilted sticker and a structural numbered badge carry a small labelled
fill. A generic card, square, rectangle, colour field, content container or grid cell is
layout/background treatment and does not become decoration because it has a fill.
Everything else that is text stays text.

**Before delivering, audit identity.** On three
representative slides, verify that every ornament maps to a named signature
element or to a specific composition in the reference. Use the table above only to notice gross whole-deck drift.

Content still comes first. Never push text off the stage, cover it, or drop a point. Never
add a photograph the source material does not support. A dense slide may omit the optional
asterisk, as reference page 14 does, but it still carries the required sticker and chrome.


## Decoration safe area

Decoration is placed before content, but it never fights the content.

- Every slide has a **text safe area**: the region actually occupied by the
  title, body copy, figures, and labels. No decoration may sit on top of it.
- Decoration belongs in one of three places: outside the safe area entirely
  (edges, corners, the empty half of the stage); behind it at `z-index:0`–`1`
  **and** at a contrast low enough that the text stays fully legible; or
  deliberately overlapping a photograph or colour field where the reference
  shows exactly that.
- A large ornament must be cropped by the stage edge rather than floated in the
  middle of the composition. In lumina this rule applies to the divider `bigcircle`; the
  reference puts it on all three dividers and on zero content pages.

## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** Keep audience-facing copy in `.fit` and in
flex flow; the safe-area padding supplies the only stage-relative text boundary.
Do not position paragraphs or headings with `left`/`top`, and do not freeze their
width. The only out-of-flow text is a short, nowrap sticker or badge, anchored to
the edge it is near so it grows inward.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

Both faults hide from a quick glance at the whole deck and are obvious on the
slide itself. Before delivering, look at every slide that carries a set of
things and check that the set is aligned and that nothing touches an edge it was
not meant to touch.

## Never do this

- **Never use a disc-bulleted list.** Not one of the twenty-three V3 reference
  decks contains a single `<ul>` with default bullets, and a bulleted list is the
  fastest way to make a designed template look like a plain document. Structure a
  list as numbered rows with a hairline rule between them, as key–value rows, as
  a row of cards, or with the template's own motifs — whatever the reference deck
  does for the same job.
- Never invent a colour outside the inlined colour-system tokens; every colour
  goes through `var(--...)`.
- Never leave a slide without the chrome named in `Required chrome`.
- Never let an ornament sit on top of a title or a paragraph.
- Never generate a photograph the supplied material does not call for.

## Required chrome

Chrome is the cheapest part of a template's identity and the most frequently
dropped: across the benchmark's baseline decks, four of six templates carried a
footer on 0-2 slides out of 17. This template's reference deck carries the
following, and the count is measured from that deck, not assumed.


### Repeats on every slide

The reference deck also repeats these edge-pinned elements on nearly every slide. Their opening tags are given as locators — find each one in [layouts/](layouts/) and carry it through your deck the same way.

```html
<div style="position:absolute;left:6cqw;right:6cqw;top:5cqh;display:flex;justify-content:space-between;align-items:center">
```
<sub>on 15 of 15 reference slides</sub>

**Page number** — on 15 of 15 slides:

```html
<div class="pagenum">01</div>
```

Carry page number on **every** slide, including the cover and the closing slide.
