---
name: lumina
description: Create a standalone 16:9 HTML presentation deck with the Lumina visual identity and direct-HTML workflow. Use when the user selects the Lumina presentation template or explicitly names lumina as the deck style. Best suited to poster-led, sticker-rich creative studios, events, campaigns, and trend brands.
---

# Lumina presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one standalone HTML file with one live `.deck`. Copy the shell from
  [layouts/\_shell.html](layouts/_shell.html): it carries the head, the fonts, the class
  definitions, the chrome and the navigation runtime.
- **Every `.slide` must be a direct child of `.deck`.** The navigation runtime collects
  pages with `[...deck.children].filter(n => n.classList.contains('slide'))`. A slide
  nested one level deeper renders, scrolls, and screenshots perfectly — and the arrow keys
  cannot reach it. Keep this invariant; the final QA checks it together with the live
  keyboard state, so do not repeat it in the console:

  ```js
  document.querySelectorAll(".slide").length ===
    [...document.querySelector(".deck").children].filter((n) =>
      n.classList.contains("slide"),
    ).length;
  ```

- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Give each slide one 16:9 `.stage`, one `.fit` for all its text, and the chrome.

### Sizing — the rule that keeps a layout alive

**Write no `width`, `max-width`, `min-width`, `height` or `flex-basis` in `cqw`, `cqh`,
`px`, `vw` or `vh` on anything that holds text.** The safe area is set once, by the padding
on `.fit`: `12cqh 6cqw 8cqh`. Everything else is flex.

- peer columns → `flex:1`
- a box that hugs its content → `align-self:flex-start; max-width:100%`
- a textless optional decoration → its documented `cqw` / `cqh` geometry from
  `decoration/PLACEMENT.md`
- a structural item marker with no prose → `em`, anchored to the type scale with a `cqw`
  `font-size` so it still scales with the stage
- a bar whose length is the datum → `%` (charts and `roadmap` only)
- a hairline → `height:1px`
- an out-of-flow badge → `position:absolute` + `left/top/right/bottom`

`flex:0 0 4cqw` freezes a column exactly the way a `width` does. Reserve a filling `flex:1`
for an image frame or a chart plot area, and give any flex child holding an SVG or a
percentage-height bar `min-height:0`.

**A percentage height needs a parent whose height is definite.** A plot row set to
`align-items:flex-end` makes its columns hug their content, so `height:46%` resolves
against nothing and every bar renders at zero — while every automated check still passes.

### A filled box is sized by its content, never by the stage

`.fit` is a column flex with `align-items:stretch`, so every child is full-width by
default; that default is why boxes come out too wide. One box hugs
(`align-self:flex-start`), a row of peers divides the safe area. `flex:1` on the **row**
makes the row fill the stage and the cards inherit the stage's height — a slab of colour
that is half empty. Put `flex:1` on the **child** instead, and wrap the group in
`flex:1;min-height:0; … justify-content:center`.

Do not trust `align-items:stretch` — it equalises siblings to each other, which is not the
same as equalising them to the tallest content. Stress it: add a sentence to the first item
of a peer row and check the siblings still match.

### Decoration and signature labels — classify by role

Use [decoration/PLACEMENT.md](decoration/PLACEMENT.md) as the authority for page roles and
geometry. Stickers carry text, item-set marks perform layout, photo cells carry content,
and chrome repeats as interface; none of those is optional decoration.
[decoration/decoration.html](decoration/decoration.html) renders and names the qualifying
decoration types without chrome.

- A sticker is a text-bearing signature label, not decoration. Use it only in the page
  roles documented in `PLACEMENT.md`, rotate it, and retain its offset shadow so it does
  not read as a button.
- Use an asterisk only where `PLACEMENT.md` calls for one. Keep it whole and omit it when
  it competes with content.
- The big circle belongs to section dividers and nowhere else. Use its documented
  right-edge crop and colour treatment.

Structural item sets are all-or-nothing: `numbered-points` gives every row a `badge`, and
`process-steps` / `flow-diagram` / `timeline` give every step a `node` plus one
connector treatment. Three items with a structural mark and a fourth without reads as a
bug. These marks remain in the named layout files; they do not qualify for an optional
decoration `item-sets.html`.

### Colour roles

- **`--s1`, `--s2`, `--s3` and `--accent` are never text colours.** On the standard `--bg`
  use `--ka`, `--k1`, `--k2`, `--k3`; on a `--g?` ground use the matching `--t?`.
- **Never paint `--surface`.** Use the documented ground and field tokens instead.
- On a full-bleed page, put the ground colour on `.stage` and content directly on it.
  A kicker inherits the page foreground instead of forcing `--ka`.
- The persistent chrome carries **no colour token** — it inherits from `.stage` so it flips
  automatically on a full-bleed page. Do not pin it to `.soft`.

### Never do this

- **Never use a disc-bulleted list.** Structure a list as numbered rows
  (`numbered-points`), as ruled rows, as a row of cards, or with the template's own motifs.
- Never invent a colour outside the inlined colour-system tokens.
- Never leave a slide without the chrome named in `Required chrome`.
- Never let an ornament sit on top of a title or a paragraph.
- Never invent substitute circles, squares, arches or colour blocks. Optional decoration is
  closed to asterisk and divider big circle. The sticker is a required text-bearing
  signature label, not decoration. Numbered badges and nodes/connectors are structural
  item-set marks; brush letters are typography; image cells are content; cards, squares,
  rectangles, colour fields, content containers and grid cells are layout, not decoration.
- Never write a `.bz` handwritten letter onto a space. It renders nothing, and the slide
  silently loses the template's signature move.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

- Read [design-system.md](design-system.md) for the deck shell, motif library, and
  required chrome.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — motifs, background treatment, chrome;
  4. every optional motif follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is accurate but visually anonymous also fails.

- A lumina slide has two authored layers — decoration and layout — wrapped by one shared
  shell. Build them in z-order and they cannot fight each other:

  | z-index | layer                                                  | source                                                                                                       |
  | ------- | ------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------ |
  | 1, 4    | optional decoration                                    | [decoration/PLACEMENT.md](decoration/PLACEMENT.md), [decoration/decoration.html](decoration/decoration.html) |
  | 5       | sticker signature label (text-bearing, not decoration) | [decoration/PLACEMENT.md](decoration/PLACEMENT.md) section B                                                 |
  | 6       | persistent chrome                                      | [decoration/PLACEMENT.md](decoration/PLACEMENT.md) section A                                                 |
  | 40      | all text, inside `.fit`                                | [layouts/](layouts/) — 37 naked layouts                                                                      |
  | 45      | pagenum                                                | `layouts/_shell.html`                                                                                        |

  Every optional decoration and sticker sits below `.fit`, which is why "nothing on top of
  type" holds structurally rather than by vigilance. If a layout and a device collide,
  move the device — never the copy.

- Take **structure** from [layouts/](layouts/) and **ornament placement** from
  [decoration/PLACEMENT.md](decoration/PLACEMENT.md). Both are stated as rules.
  [layouts/](layouts/) shows all three layers fused at full scale —
  use it to judge rhythm and motif geometry, but take reusable structure and placement
  rules from `layouts/` and `decoration/PLACEMENT.md`.
- Optional: [example/reference.jpg](example/reference.jpg) for the visual identity.
- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. Its packets carry this template's information treatment; then implement that treatment through the matching normalized file in `layouts/`. Do not copy content-specific fixed geometry. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use the prompt's `color-system` when supplied, otherwise a preferred token from
  `design-system.md`. Inline that one `color-systems/<token>.css` in the final HTML.

#### Pick a layout, do not invent one

[layouts/README.md](layouts/README.md) is the index. Match the slide's job to a file:

| the slide's job                                             | layout                                                                 |
| ----------------------------------------------------------- | ---------------------------------------------------------------------- |
| open / close the deck                                       | `cover` `close`                                                        |
| list what is coming                                         | `agenda`                                                               |
| start a section                                             | `section-divider`                                                      |
| state the deck's thesis · explain it at length              | `statement` · `longform`                                               |
| a set of claims, numbered                                   | `numbered-points`                                                      |
| two or three peer blocks of prose                           | `two-column` `three-column` (ruled) · `colour-cards` (filled)          |
| one sentence that carries the deck                          | `big-quote` · `stat-highlight`                                         |
| what people said                                            | `quote-cards`                                                          |
| a row of figures                                            | `stat-row` (ruled) · `kpi-cards` (filled)                              |
| rows of records, codes, counts                              | `table`                                                                |
| a quantity over categories / time / share                   | `chart-bar` `chart-line` `chart-donut`                                 |
| ordered stages                                              | `process-steps` `flow-diagram`                                         |
| dated milestones · a phased plan · concurrent calendar work | `timeline` · `roadmap` · `gantt`                                       |
| layers of a system · associative branches                   | `arch-diagram` · `mindmap`                                             |
| two things compared                                         | `comparison` (quiet) · `versus` (loud) · `pros-cons`                   |
| options at different levels                                 | `tier-cards`                                                           |
| bind challenge, intervention and result                     | `case-study`                                                           |
| objective, audience, proposition and deliverables           | `creative-brief`                                                       |
| a picture and copy · one picture · a set · a team           | `image-left` `image-right` · `image-hero` · `image-grid` · `team-grid` |

**Alternate ruled and filled treatments.** Each peer-row content type has both treatments;
vary them with the narrative instead of repeating one treatment throughout the deck.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Identity checks while authoring

First confirm the content survived: every point is still on its slide and no
image or caption appears that the material does not support. Then audit
identity:

- every slide carries the chrome and the page number;
- stickers and asterisks follow the page roles in `decoration/PLACEMENT.md`;
- the big circle appears on section dividers and nowhere else;
- every ornament maps to a named item and page role in `Motif library` or
  `decoration/PLACEMENT.md`;
- no text is set in `--s1`, `--s2`, `--s3` or `--accent`, and nothing is painted
  `--surface`;
- no text begins above 11% of stage height, and none sits outside the 6% safe area;
- exactly one `data-color-system` token, and it is one of the preferred tokens;
- keep authored ornaments clear of type; any reported geometric crossing remains an
  optional-review candidate under `Automated QA` below.

Resolve any failure before running Automated QA.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
