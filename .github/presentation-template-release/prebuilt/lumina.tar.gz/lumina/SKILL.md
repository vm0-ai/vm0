---
name: lumina
description: Create, revise, or review standalone 16:9 HTML presentation decks with the Lumina visual identity and direct-HTML workflow. Use when the user selects the Lumina presentation template or explicitly names lumina as the deck style. Best suited to poster-led, sticker-rich creative studios, events, campaigns, and trend brands.
---

# Lumina presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## Choose the task mode

- Create: use Sections 1–5 and complete Section 2 before writing any slide HTML.
- Revise: inspect the existing HTML, reconstruct or update the outline for the affected sequence, and complete Section 2 before editing slide HTML; then use Sections 3–5 as relevant while preserving valid shell, token, motif, and runtime implementation.
- Review: use Sections 1–3 for context and Section 5 as the checklist; infer the deck's throughline and slide-level content contract, skip Section 4, and do not edit. Report slide-specific findings in P1 / P2 / P3 order (blocking / material / polish), include evidence and a fix direction, or state explicitly that there are no actionable findings.

## 1. Define the communication job

- Read the prompt and all supplied source material before composing slides.
- Identify the audience, purpose, desired audience outcome, core takeaway, and required evidence.
- Express the communication job in one sentence: by the end, the audience should reach the desired outcome because of the core takeaway.
- Ground every factual claim and number in supplied or verified sources; label forecasts, targets, and assumptions explicitly.

## 2. Complete the slide outline before HTML

- Before creating or changing slide HTML, write a lightweight plain-text or Markdown outline. State the one-sentence throughline, then list the slides in order.
- For each slide, record its working takeaway title, the point it must establish, and the evidence or data that supports it with its supplied or verified source. Mark forecasts, targets, assumptions, and slides that need no evidence.
- Review the complete outline for narrative flow, duplicated claims, missing evidence, and a deliberate opening and ending. Choose the slide count from the content.
- Treat the completed outline as the content contract for implementation, not as a layout schema. Keep layouts and motifs out of it, keep it out of audience-facing HTML unless requested, and update it first when a slide's title, communication job, or evidence changes materially.

## 3. Load the local identity

- Read [design-system.md](design-system.md) completely for colour roles, typography, signature elements, and visual identity.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — motifs, background treatment, chrome;
  4. every optional motif follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is accurate but visually anonymous also fails.

- Read [design-system.md](design-system.md) **completely, to the last line**,
  before writing any HTML. Its `Deck shell`, `Motif library` and
  `Required chrome` sections are requirements, not suggestions.
- Use one of the **preferred tokens** named in `design-system.md` when the
  prompt does not supply a `color-system` — not an arbitrary token from the full
  list.

- A lumina slide has two authored layers — decoration and layout — wrapped by one shared
  shell. Build them in z-order and they cannot fight each other:

  | z-index | layer                                                  | source                                                                                                       |
  | ------- | ------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------ |
  | 1, 4    | optional decoration                                    | [decoration/PLACEMENT.md](decoration/PLACEMENT.md), [decoration/decoration.html](decoration/decoration.html) |
  | 5       | sticker signature label (text-bearing, not decoration) | [decoration/PLACEMENT.md](decoration/PLACEMENT.md) section B                                                 |
  | 6       | persistent chrome                                      | [decoration/PLACEMENT.md](decoration/PLACEMENT.md) section A                                                 |
  | 40      | all text, inside `.fit`                                | [layouts/](layouts/) — 37 naked layouts                                                                      |
  | 45      | pagenum                                                | `layouts/_shell.html`                                                                                        |

  Every optional decoration and sticker sits below `.fit`, which is why "nothing on top of
  type" holds structurally rather than by vigilance. If a layout and a device collide,
  move the device — never the copy.

- Take **structure** from [layouts/](layouts/) and **ornament placement** from
  [decoration/PLACEMENT.md](decoration/PLACEMENT.md). Both are stated as rules.
  [layouts/](layouts/) shows all three layers fused at full scale —
  use it to judge rhythm and motif geometry, but take reusable structure and placement
  rules from `layouts/` and `decoration/PLACEMENT.md`.
- Inspect [example/reference.jpg](example/reference.jpg) for the visual identity.
- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. Its packets carry this template's information treatment; then implement that treatment through the matching normalized file in `layouts/`. Do not copy content-specific fixed geometry. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use a valid prompt `color-system` when supplied. Otherwise select a valid token from `design-system.md`. Load exactly one `color-systems/<token>.css` file and inline its CSS in the final HTML.
- Use this folder as the template guidance; the selected atomic colour-system file is the only shared template resource.

### Pick a layout, do not invent one

[layouts/README.md](layouts/README.md) is the index. Match the slide's job to a file:

| the slide's job                                             | layout                                                                 |
| ----------------------------------------------------------- | ---------------------------------------------------------------------- |
| open / close the deck                                       | `cover` `close`                                                        |
| list what is coming                                         | `agenda`                                                               |
| start a section                                             | `section-divider`                                                      |
| state the deck's thesis · explain it at length              | `statement` · `longform`                                               |
| a set of claims, numbered                                   | `numbered-points`                                                      |
| two or three peer blocks of prose                           | `two-column` `three-column` (ruled) · `colour-cards` (filled)          |
| one sentence that carries the deck                          | `big-quote` · `stat-highlight`                                         |
| what people said                                            | `quote-cards`                                                          |
| a row of figures                                            | `stat-row` (ruled) · `kpi-cards` (filled)                              |
| rows of records, codes, counts                              | `table`                                                                |
| a quantity over categories / time / share                   | `chart-bar` `chart-line` `chart-donut`                                 |
| ordered stages                                              | `process-steps` `flow-diagram`                                         |
| dated milestones · a phased plan · concurrent calendar work | `timeline` · `roadmap` · `gantt`                                       |
| layers of a system · associative branches                   | `arch-diagram` · `mindmap`                                             |
| two things compared                                         | `comparison` (quiet) · `versus` (loud) · `pros-cons`                   |
| options at different levels                                 | `tier-cards`                                                           |
| bind challenge, intervention and result                     | `case-study`                                                           |
| objective, audience, proposition and deliverables           | `creative-brief`                                                       |
| a picture and copy · one picture · a set · a team           | `image-left` `image-right` · `image-hero` · `image-grid` · `team-grid` |

**Alternate ruled and filled treatments.** Each peer-row content type has both treatments;
vary them with the narrative instead of repeating one treatment throughout the deck.

## 4. Build the deck

- Produce one standalone HTML file with one live `.deck`. Copy the shell from
  [layouts/\_shell.html](layouts/_shell.html): it carries the head, the fonts, the class
  definitions, the chrome and the navigation runtime.
- **Every `.slide` must be a direct child of `.deck`.** The navigation runtime collects
  pages with `[...deck.children].filter(n => n.classList.contains('slide'))`. A slide
  nested one level deeper renders, scrolls, and screenshots perfectly — and the arrow keys
  cannot reach it. Before delivering, run this in the console and confirm it is `true`:

  ```js
  document.querySelectorAll(".slide").length ===
    [...document.querySelector(".deck").children].filter((n) =>
      n.classList.contains("slide"),
    ).length;
  ```

- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Give each slide one 16:9 `.stage`, one `.fit` for all its text, and the chrome.

### Sizing — the rule that keeps a layout alive

**Write no `width`, `max-width`, `min-width`, `height` or `flex-basis` in `cqw`, `cqh`,
`px`, `vw` or `vh` on anything that holds text.** The safe area is set once, by the padding
on `.fit`: `12cqh 6cqw 8cqh`. Everything else is flex.

- peer columns → `flex:1`
- a box that hugs its content → `align-self:flex-start; max-width:100%`
- a textless optional decoration → its documented `cqw` / `cqh` geometry from
  `decoration/PLACEMENT.md`
- a structural item marker with no prose → `em`, anchored to the type scale with a `cqw`
  `font-size` so it still scales with the stage
- a bar whose length is the datum → `%` (charts and `roadmap` only)
- a hairline → `height:1px`
- an out-of-flow badge → `position:absolute` + `left/top/right/bottom`

`flex:0 0 4cqw` freezes a column exactly the way a `width` does. Reserve a filling `flex:1`
for an image frame or a chart plot area, and give any flex child holding an SVG or a
percentage-height bar `min-height:0`.

**A percentage height needs a parent whose height is definite.** A plot row set to
`align-items:flex-end` makes its columns hug their content, so `height:46%` resolves
against nothing and every bar renders at zero — while every automated check still passes.

### A filled box is sized by its content, never by the stage

`.fit` is a column flex with `align-items:stretch`, so every child is full-width by
default; that default is why boxes come out too wide. One box hugs
(`align-self:flex-start`), a row of peers divides the safe area. `flex:1` on the **row**
makes the row fill the stage and the cards inherit the stage's height — a slab of colour
that is half empty. Put `flex:1` on the **child** instead, and wrap the group in
`flex:1;min-height:0; … justify-content:center`.

Do not trust `align-items:stretch` — it equalises siblings to each other, which is not the
same as equalising them to the tallest content. Stress it: add a sentence to the first item
of a peer row and check the siblings still match.

### Decoration and signature labels — classify by role

Use [decoration/PLACEMENT.md](decoration/PLACEMENT.md) as the authority for page roles and
geometry. Stickers carry text, item-set marks perform layout, photo cells carry content,
and chrome repeats as interface; none of those is optional decoration.
[decoration/decoration.html](decoration/decoration.html) renders and names the qualifying
decoration types without chrome.

- A sticker is a text-bearing signature label, not decoration. Use it only in the page
  roles documented in `PLACEMENT.md`, rotate it, and retain its offset shadow so it does
  not read as a button.
- Use an asterisk only where `PLACEMENT.md` calls for one. Keep it whole and omit it when
  it competes with content.
- The big circle belongs to section dividers and nowhere else. Use its documented
  right-edge crop and colour treatment.

Structural item sets are all-or-nothing: `numbered-points` gives every row a `badge`, and
`process-steps` / `flow-diagram` / `timeline` give every step a `node` plus one
connector treatment. Three items with a structural mark and a fourth without reads as a
bug. These marks remain in the named layout files; they do not qualify for an optional
decoration `item-sets.html`.

### Colour roles

- **`--s1`, `--s2`, `--s3` and `--accent` are never text colours.** On the standard `--bg`
  use `--ka`, `--k1`, `--k2`, `--k3`; on a `--g?` ground use the matching `--t?`.
- **Never paint `--surface`.** Use the documented ground and field tokens instead.
- On a full-bleed page, put the ground colour on `.stage` and content directly on it.
  A kicker inherits the page foreground instead of forcing `--ka`.
- The persistent chrome carries **no colour token** — it inherits from `.stage` so it flips
  automatically on a full-bleed page. Do not pin it to `.soft`.

### Images are content choices, not decoration

Use a photograph or other image whenever it communicates the slide more clearly,
credibly, or memorably than text alone. The supplied material does not have to
explicitly request an image; make that editorial choice from the content.

- Choose sources in this order: user-supplied images and visual materials first,
  including media embedded in or linked from the supplied material; then relevant
  imagery from the supplied references and related information; then an AI-generated
  image grounded in the slide's actual subject when it would work better or no suitable
  sourced image exists.
- Never add or generate an image merely to fill an empty region or make a slide look
  finished. When no image improves the slide, use the template's
  non-photographic treatments instead: a colour field, a panel, a large figure,
  a motif, or generous space. Drop the `data-photocell` frame rather than leaving an empty
  box.
- Every caption, alt text, and label beside an image must come from the
  material. Never invent a caption to justify a picture.
- A generated image that illustrates nothing in the material makes that slide
  unfaithful to its source, which costs far more than the missing picture would.

### Never do this

- **Never use a disc-bulleted list.** Structure a list as numbered rows
  (`numbered-points`), as ruled rows, as a row of cards, or with the template's own motifs.
- Never invent a colour outside the inlined colour-system tokens.
- Never leave a slide without the chrome named in `Required chrome`.
- Never let an ornament sit on top of a title or a paragraph.
- Never invent substitute circles, squares, arches or colour blocks. Optional decoration is
  closed to asterisk and divider big circle. The sticker is a required text-bearing
  signature label, not decoration. Numbered badges and nodes/connectors are structural
  item-set marks; brush letters are typography; image cells are content; cards, squares,
  rectangles, colour fields, content containers and grid cells are layout, not decoration.
- Never write a `.bz` handwritten letter onto a space. It renders nothing, and the slide
  silently loses the template's signature move.

## Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Getting the container right

A percentage bar height resolves against its parent's **definite** height. Break
that chain and the bar computes to exactly `0` — it vanishes while the labels,
values and legend still render, so the page reads as merely empty. Measured on
generated decks: 52 of 558 percentage bars rendered at zero, and one deck spent
455s of gate repair on this alone.

`layouts/chart-*.html` already carries a structure that works. Copy it rather
than inventing lanes. Three rules make the chain definite:

1. **A bar is a direct child of the plot box.** Any level between them needs its
   own definite height, and one that lacks it zeroes everything below.
2. **All columns share one grid, so the label row is shared.** A label that wraps
   to two lines must cost every column the same height, or the bar above it is
   measured against a shorter ruler than its neighbours. Make the plot
   `display:grid; grid-auto-flow:column; grid-auto-columns:1fr` with
   `grid-template-rows:1fr auto …` (one row per item in a column, exactly — a
   spare row pulls the next column's first item into the previous column), and
   give each column wrapper `display:contents`. The markup grouping stays "one
   div per column"; only the rows become shared.

   Measured on the template's own `chart-bar.html`, changing nothing but one
   label to a wrapping name: baseline offset 0 → 19px, and the fourth bar 342 →
   324px — the value never changed, the bar just lost 5%. With the shared grid
   the same label costs all four bars the same 8%, and the ratios stay exact.

3. **Every level is either `flex:none` or `flex:1`** — sized by its content, or
   taking the remainder. There is no third kind.

4. **A value label never shares the lane with the bar it labels.** If it does,
   flex has to fit label + gap + bar into the lane, so it shrinks the bar — and
   only the bars tall enough to run out of room. The scale stops being linear at
   the top: measured on `bloom/chart-bar.html`, lane 336px, label 19px, gap 6px,
   every value above 92.5% rendered at the same 310px, so **96 and 100 drew
   identically**. Under the template's own "percentages of the tallest value"
   convention the tallest bar is always 100%, so this fires on every chart.
   Reserve the label row on the lane (`padding-top`, measured once per template)
   and set both children `flex:none`; the bar then resolves against the lane
   minus that reserve, the same reserve for every column.

Grouping two bars per category still obeys this, but the group wrapper needs
`align-self:stretch`, or it is sized by content and the lane inside it collapses.

Do not "fix" a flat chart by enlarging the numbers or switching to a table. The
values are right; the container chain is not.

## How full a page should be

Measured across all 902 layouts in the 23 shared templates, so this is what the
system already does — not a target invented for the occasion:

|                                                                                  | p25 |  median | p75 |
| -------------------------------------------------------------------------------- | --: | ------: | --: |
| vertical coverage (share of the stage height that carries ink or a filled block) | 33% | **43%** | 61% |
| ink area (share of the stage area)                                               |  9% | **12%** | 16% |
| lowest ink (how far down the page the content reaches)                           | 68% | **75%** | 90% |

**Aim for the middle column.** A content page that stops at 40% of the height and
leaves the rest blank reads as unfinished; one that runs past 25% ink area reads as
a wall. Both are allowed when the material calls for it — a statement page is one
huge line at 6% coverage, a table or a longform page is legitimately dense — but
neither is the default.

Two things that are **not** the same:

- **A void at the bottom.** Content stops early and nothing follows. This is the
  one to avoid; measured on the naked layouts, 73 of 902 pages do it.
- **Air between blocks.** A title, then a band of columns centred in the space
  below it. That is composition, not a defect — do not fill it just to fill it.

If the material genuinely does not fill the page, cut a column or merge the page
into its neighbour rather than padding sentences.

## 5. Verify before delivery

### Automated advisory check

- After fonts and images settle, run `tools/run.sh` once at 1600×900; rerun only when
  the HTML changes.
- The report is the visual review, so there is no need to take screenshots, create
  contact sheets, run image recognition, or visually review slides unless the user
  explicitly asks. It measures overflow, safe area, chrome band, column alignment,
  contrast, underfill, ornament vocabulary, empty photocells, text collisions, and deck
  navigation.
- Every reported item is a recommendation, never a blocker: fix the ones worth fixing
  from the slide, element, and DOM values it names; a zero report is not required.

### Check what the report cannot see

- Check narrative sequence from the final HTML source.
- **Press the arrow keys.** `←` `↑` `→` `↓`, `Home`, `End`. Confirm you can reach the last
  slide. A deck whose slides are nested one level too deep scrolls and screenshots
  perfectly and stops navigating at page 2.
- Match the final HTML to the outline: titles, communication jobs, evidence, source status, and no planning notes in audience copy.
- Check chart and data labels, unresolved placeholder text, and motif consistency.
- Confirm the prompt-selected colour-system is used exactly, or record the valid token chosen when the prompt omitted it. If the deck renders unstyled, the colour-system CSS did not resolve — every other check still passes when it does not.
- Confirm the delivered HTML contains one live `.deck`, one navigation runtime, and only the markup and CSS used by its rendered slides.

### Identity audit before delivery

First confirm the content survived: every point is still on its slide and no
image or caption appears that the material does not support. Then audit
identity:

- every slide carries the chrome and the page number;
- stickers and asterisks follow the page roles in `decoration/PLACEMENT.md`;
- the big circle appears on section dividers and nowhere else;
- every ornament maps to a named item and page role in `Motif library` or
  `decoration/PLACEMENT.md`;
- no text is set in `--s1`, `--s2`, `--s3` or `--accent`, and nothing is painted
  `--surface`;
- no text begins above 11% of stage height, and none sits outside the 6% safe area;
- exactly one `data-color-system` token, and it is one of the preferred tokens;
- no ornament sits on top of type.

Fix the deck and re-render before delivering if any line fails.

## Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
