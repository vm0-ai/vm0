#!/usr/bin/env bash
# Usage:  ./run.sh <file-or-url> [more...]
# Renders each deck at 1600x900 and prints the audit JSON.
#
#   ./run.sh ../layouts/toc.html                      # one canonical layout
#   ./run.sh https://your-generated-deck.sites.vm0.io   # a generated deck
#
# Structure is calibrated against this template's layouts. Final decks require
# outsideSafeArea=0 and emptyPhotocells=0 without a reference exception.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
for TARGET in "$@"; do
  case "$TARGET" in
    http*) URL="$TARGET" ;;
    *)     URL="file://$(cd "$(dirname "$TARGET")" && pwd)/$(basename "$TARGET")" ;;
  esac
  printf '%s\n' "=== $TARGET ==="
  agent-browser set viewport 1600 900 >/dev/null 2>&1
  agent-browser open "$URL" >/dev/null 2>&1
  # wait for fonts, images AND two frames; without this the readings drift
  agent-browser eval '(async()=>{
    await Promise.race([document.fonts.ready, new Promise(r=>setTimeout(r,12000))]);
    await Promise.race([Promise.all(Array.from(document.images).filter(i=>!i.complete).map(i=>new Promise(r=>{i.onload=i.onerror=r}))),new Promise(r=>setTimeout(r,12000))]);
    const urls = s => [...s.matchAll(/url\("?([^")]+)"?\)/gi)].map(m=>m[1]);
    await Promise.all(Array.from(document.querySelectorAll("[data-photocell]")).map(async cell=>{
      const found=urls(getComputedStyle(cell).backgroundImage||"");
      if(!found.length){cell.dataset.photocellBackgroundLoaded="false";return;}
      const ok=await Promise.all(found.map(src=>new Promise(resolve=>{
        const im=new Image(); im.onload=()=>resolve(true); im.onerror=()=>resolve(false); im.src=src;
      })));
      cell.dataset.photocellBackgroundLoaded=String(ok.some(Boolean));
    }));
    await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
    return 1})()' >/dev/null 2>&1
  # SAFE=<fraction> overrides the safe-area constant for templates whose inset is not 6%
  [ -n "${SAFE:-}" ] && agent-browser eval "window.__SAFE=${SAFE};1" >/dev/null 2>&1
  agent-browser eval -b "$(base64 -w0 "$HERE/audit.js")" 2>&1 | tail -1 |
    python3 -c 'import json,sys; print(json.loads(sys.stdin.read()))' 2>/dev/null ||
    agent-browser eval -b "$(base64 -w0 "$HERE/audit.js")" 2>&1 | tail -1
  echo
done
