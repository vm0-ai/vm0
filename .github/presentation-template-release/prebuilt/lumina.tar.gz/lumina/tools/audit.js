// Template-local deck audit. Paste into agent-browser eval, or run via ./probes/run.sh.
// Reusable structure is measured against this template's canonical layouts. Final-deck
// contracts additionally require zero safe-area and unresolved-media findings.
(() => {
  // Decoration must be declared as decoration. Content frames, cards, tiles,
  // badges, background fields, grid nodes and connectors are layout/content and
  // must never disappear from text checks or inflate ornament counts merely
  // because they are geometric. A declared decoration is still required to be
  // textless below.
  const DECO = "[data-decoration],[data-deco],[data-ornament],[data-bigcircle]";
  // These visuals may legitimately sit behind type, so intersections are review
  // candidates rather than automatic failures. The model must inspect legibility.
  const REVIEW_VISUAL =
    "[data-mosaic],[data-decoration],[data-deco],[data-ornament]";

  const ownText = (e) =>
    [...e.childNodes]
      .filter((n) => n.nodeType === 3)
      .map((n) => n.textContent.trim())
      .join("")
      .trim();
  const isStrictDecoration = (d) =>
    d &&
    !d.textContent.trim() &&
    !d.matches(
      "[data-photocell],[data-tile],[data-badge],[data-bbadge],[data-node],[data-connector],[data-background-field],[data-metric-disc]",
    ) &&
    !d.closest(".fit,[data-device]");

  const lum = (c) => {
    const m = (c.match(/\d+/g) || [0, 0, 0]).map(Number);
    const f = (v) => {
      v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    };
    return 0.2126 * f(m[0]) + 0.7152 * f(m[1]) + 0.0722 * f(m[2]);
  };
  const bgOf = (e) => {
    let n = e;
    while (n && n !== document.documentElement) {
      const c = getComputedStyle(n).backgroundColor;
      if (c && !/rgba?\(0, 0, 0, 0\)|transparent/.test(c)) return c;
      n = n.parentElement;
    }
    return "rgb(255,255,255)";
  };
  const intersects = (a, b) =>
    Math.min(a.right, b.right) - Math.max(a.left, b.left) > 1 &&
    Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top) > 1;
  const textRuns = (root, { excludeOverlapOk = true } = {}) => {
    const runs = [];
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (!node.textContent.trim()) continue;
      const parent = node.parentElement;
      if (
        !parent ||
        parent.closest("[data-plot-mark]") ||
        (excludeOverlapOk && parent.closest("[data-overlap-ok]"))
      )
        continue;
      const style = getComputedStyle(parent);
      if (style.display === "none" || style.visibility === "hidden") continue;
      const range = document.createRange();
      range.selectNodeContents(node);
      [...range.getClientRects()].forEach((r) => {
        if (r.width > 1 && r.height > 1) runs.push({ rect: r, parent });
      });
    }
    return runs;
  };
  const textRects = (root, options) =>
    textRuns(root, options).map((run) => run.rect);
  // Range rectangles include line leading, which makes two visibly separated lines look
  // overlapped. Trim only the semantic-collision probe to a conservative ink proxy; the
  // general geometry checks above continue to use the full rendered line rectangles.
  const inkRect = (r) => {
    const dy = r.height * 0.16;
    return {
      left: r.left,
      right: r.right,
      top: r.top + dy,
      bottom: r.bottom - dy,
      width: r.width,
      height: r.height - dy * 2,
    };
  };
  const paintsBox = (e) => {
    const cs = getComputedStyle(e);
    const bg = cs.backgroundColor || "";
    const hasBackground = bg && !/rgba?\(0, 0, 0, 0\)|transparent/.test(bg);
    const hasBorder = ["Top", "Right", "Bottom", "Left"].some(
      (side) =>
        parseFloat(cs[`border${side}Width`]) > 0 &&
        cs[`border${side}Style`] !== "none",
    );
    const hasShadow = cs.boxShadow && cs.boxShadow !== "none";
    return (
      hasBackground ||
      hasBorder ||
      hasShadow ||
      /^(IMG|SVG|CANVAS)$/.test(e.tagName)
    );
  };
  const paintedRects = (root, { excludeOverlapOk = true } = {}) =>
    [...root.querySelectorAll("*")]
      .filter(
        (e) =>
          (!excludeOverlapOk || !e.closest("[data-overlap-ok]")) &&
          paintsBox(e),
      )
      .map((e) => e.getBoundingClientRect())
      .filter((r) => r.width > 1 && r.height > 1);
  const intersectsBigcircle = (circle, rect) => {
    const cr = circle.getBoundingClientRect();
    if (!intersects(cr, rect)) return false;
    const cs = getComputedStyle(circle);
    const radius = parseFloat(cs.borderTopLeftRadius) || 0;
    const isRound = radius >= Math.min(cr.width, cr.height) * 0.4;
    if (!isRound) return true;
    const cx = (cr.left + cr.right) / 2,
      cy = (cr.top + cr.bottom) / 2;
    const rx = cr.width / 2,
      ry = cr.height / 2;
    const x = Math.max(rect.left, Math.min(cx, rect.right));
    const y = Math.max(rect.top, Math.min(cy, rect.bottom));
    return (
      ((x - cx) * (x - cx)) / (rx * rx) + ((y - cy) * (y - cy)) / (ry * ry) < 1
    );
  };
  const lengthInPixels = (value, stageRect) => {
    const n = parseFloat(value) || 0;
    if (value.endsWith("cqw") || value.endsWith("vw"))
      return (stageRect.width * n) / 100;
    if (value.endsWith("cqh") || value.endsWith("vh"))
      return (stageRect.height * n) / 100;
    return n;
  };

  const R = {
    pages: 0,
    // --- navigation: the runtime keys off [...deck.children].filter(.slide) ---
    navigableSlides: 0, // slides the arrow keys can actually reach
    orphanSlides: 0, // .slide outside every .deck. reference: 0
    indirectSlides: 0, // .slide inside a .deck but not a direct child. reference: 0
    decks: 0, // reference: 1
    // --- geometry ---
    overflow: 0, // text crossing the stage edge. reference: 0
    safeAreaShells: 0, // missing .fit or horizontal padding below data-safe-area. reference: 0
    outsideSafeArea: 0, // content inside the stage but outside the 6% safe area. reference: 0
    aboveChromeBand: 0, // text starting above 11% of stage height. reference: 0
    columnsMisaligned: 0, // top-aligned peer columns whose first lines differ by >8px. reference: 0
    railOverlaps: 0, // content box crosses a declared right rail + gap. reference: 0
    textGraphicOverlaps: 0, // a declared plot mark intersects rendered text ink. reference: 0
    titleBodyOverlaps: 0, // title ink intersects later in-flow body ink or paint. reference: 0
    bodyCtaOverlaps: 0, // body ink intersects out-of-flow CTA chrome. reference: 0
    textBigcircleOverlaps: 0, // rendered text ink intersects a [data-bigcircle]. reference: 0
    textVisualOverlapCandidates: 0, // text intersects a motif/decorative visual; inspect legibility
    fitFloorOverflows: 0, // local auto-fit hit its 0.90 floor and still does not fit. reference: 0
    emptyPhotocells: 0, // media slots with no img source and no CSS url(...)
    // --- colour ---
    lowContrast: 0, // text under 3.0:1 against its own ground. reference: 0
    surfaceUses: 0, // count them, then compare with your reference's count
    darkPanels: 0, // filled boxes >8% x >6% of stage with luminance <70
    fullBleedPages: 0, // ground colour on .stage itself
    // --- filled boxes ---
    boxesUnderfilledV: 0, // visible fill whose content reaches <75% of its height
    boxesUnderfilledH: 0, // visible fill whose text spans <80% of its width
    boxesOnFullBleed: 0, // a filled box sitting on a full-bleed page
    // --- ornaments ---
    bigOrnaments: 0,
    bigPerPage: 0,
    pagesWithPair: 0,
    bleedingPct: 0,
    smallOrnaments: 0,
    smallPerPage: 0,
    offVocabularyShapes: 0,
    samples: [],
    visualOverlapSamples: [],
  };

  let bleed = 0,
    inside = 0,
    colSpreads = [],
    smallCount = 0;

  document.querySelectorAll(".slide .stage, .stage").forEach((st, pi) => {
    R.pages++;
    const sr = st.getBoundingClientRect();
    const stageBg = getComputedStyle(st).backgroundColor;
    const fullBleed =
      stageBg && !/rgba?\(0, 0, 0, 0\)/.test(stageBg) && lum(stageBg) < 0.85;
    if (fullBleed) R.fullBleedPages++;

    // ---- text-level checks ----
    const fit = st.querySelector(".fit");
    const SAFE = +(
      window.__SAFE ||
      document.documentElement.dataset.safeArea ||
      0.06
    );
    if (!fit) {
      R.safeAreaShells++;
      if (R.samples.length < 8)
        R.samples.push(`p${pi + 1} missing .fit safe-area root`);
    } else {
      const fcs = getComputedStyle(fit),
        need = sr.width * SAFE;
      const pl = parseFloat(fcs.paddingLeft) || 0,
        pr = parseFloat(fcs.paddingRight) || 0;
      if (pl < need - 3 || pr < need - 3) {
        R.safeAreaShells++;
        if (R.samples.length < 8)
          R.samples.push(
            `p${pi + 1} .fit padding ${pl.toFixed(1)}/${pr.toFixed(1)}px < ${need.toFixed(1)}px`,
          );
      }
    }
    // content lives inside .fit and in normal flow; the persistent chrome does not and
    // is *supposed* to sit in the top band.
    //
    // .fit is ITSELF position:absolute, and canonical v3 layouts write that inline. A
    // `closest('[style*="position:absolute"]')` test therefore matches .fit for every
    // descendant and silently excludes the entire content tree: measured on the two
    // references, 0 of 224 (bloom) and 0 of 236 (meridian) text elements were ever
    // tested. That makes aboveChromeBand, columnsMisaligned and outsideSafeArea read a
    // vacuous 0 on any deck that writes .fit inline, while a deck that styles .fit from
    // the class alone still gets measured — the reference and the generated deck were
    // being held to different rules. Stop the search at .fit, which is the content root.
    const inFlowContent = (e) => {
      if (!fit) return true;
      if (!fit.contains(e)) return false;
      for (let n = e; n && n !== fit; n = n.parentElement)
        if (getComputedStyle(n).position === "absolute") return false;
      return true;
    };
    st.querySelectorAll("*").forEach((e) => {
      if (isStrictDecoration(e.closest(DECO))) return;
      const isContent = inFlowContent(e);
      const t = ownText(e);
      if (t.length < 2) return;
      const r = e.getBoundingClientRect();
      if (r.width < 6 || r.height < 5) return;

      if (
        r.right > sr.right + 2 ||
        r.left < sr.left - 2 ||
        r.bottom > sr.bottom + 2 ||
        r.top < sr.top - 2
      )
        R.overflow++;

      // inside the stage but outside the safe area — a different defect from overflow.
      // The safe area is a template constant; measure against it, not against whatever
      // padding this particular page happened to set.
      if (isContent) {
        // The safe area is a per-template constant. bloom is 6%; measure your own as the
        // modal left edge of content on your reference (meridian: 5.6%) and pass it in as
        // window.__SAFE rather than editing this probe default.
        const safeL = sr.left + sr.width * SAFE,
          safeR = sr.right - sr.width * SAFE;
        const rg = document.createRange();
        rg.selectNodeContents(e);
        const runs = [...rg.getClientRects()].filter((x) => x.width > 2);
        if (runs.length) {
          const L = Math.min(...runs.map((x) => x.left)),
            Rr = Math.max(...runs.map((x) => x.right));
          if (L < safeL - 3 || Rr > safeR + 3) {
            R.outsideSafeArea++;
            if (R.samples.length < 8)
              R.samples.push(
                `p${pi + 1} outside-safe "${t.slice(0, 20)}" L=${(((L - sr.left) / sr.width) * 100).toFixed(1)}%`,
              );
          }
        }
      }

      const relTop = (r.top - sr.top) / sr.height;
      if (isContent && relTop < 0.11 && relTop > -0.5) {
        R.aboveChromeBand++;
        if (R.samples.length < 8)
          R.samples.push(`p${pi + 1} above-band "${t.slice(0, 24)}"`);
      }

      const fg = getComputedStyle(e).color,
        bg = bgOf(e);
      const a = lum(fg),
        b = lum(bg);
      const ratio = (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
      if (ratio < 3.0 && ratio > 1.05) {
        // ratio ~1 means the probe found the wrong ground
        R.lowContrast++;
        if (R.samples.length < 8)
          R.samples.push(
            `p${pi + 1} contrast ${ratio.toFixed(2)} "${t.slice(0, 20)}"`,
          );
      }
    });

    // ---- explicit layout-safety contracts ----
    // A right rail is a reserved layout region, not decoration. The template primitive
    // reduces .fit's content box by --rail-width + --rail-gap; compare those actual
    // computed edges so an inline padding regression cannot hide behind the field's z-index.
    const rail = st.querySelector(
      ':scope > [data-background-field="right-rail"]',
    );
    if (st.hasAttribute("data-right-rail") && rail && fit) {
      const railRect = rail.getBoundingClientRect();
      const fitStyle = getComputedStyle(fit);
      const contentRight =
        fit.getBoundingClientRect().right - parseFloat(fitStyle.paddingRight);
      const gapValue = fitStyle.getPropertyValue("--rail-gap").trim() || "2cqw";
      const gap = lengthInPixels(gapValue, sr);
      if (contentRight > railRect.left - gap + 1) {
        R.railOverlaps++;
        if (R.samples.length < 8)
          R.samples.push(
            `p${pi + 1} rail-overlap ${(contentRight - (railRect.left - gap)).toFixed(1)}px`,
          );
      }
    }

    // Plot marks opt in explicitly. Compare them with text-node rectangles, not parent
    // boxes, so a chart beside a title does not fail merely because their containers span
    // the same row. data-overlap-ok is the narrow escape hatch for intentional labels.
    const type = fit ? textRects(fit) : [];
    let plotCollision = false;
    st.querySelectorAll("[data-plot-mark]").forEach((mark) => {
      const mr = mark.getBoundingClientRect();
      if (mr.width < 2 || mr.height < 2) return;
      if (type.some((tr) => intersects(mr, tr))) plotCollision = true;
    });
    if (plotCollision) {
      R.textGraphicOverlaps++;
      if (R.samples.length < 8)
        R.samples.push(`p${pi + 1} plot-mark intersects text`);
    }

    // Three semantic collision gates. Use rendered text-node line rectangles instead of
    // transparent parent boxes; only visible paint contributes on the non-text side.
    // Unlike plot labels, these relationships have no escape hatch: a real collision
    // between semantic regions is always blocking.
    if (fit) {
      const title = [
        ...fit.querySelectorAll("h1,.h1,.display,[data-title]"),
      ].find(
        (e) =>
          inFlowContent(e) && textRects(e, { excludeOverlapOk: false }).length,
      );
      if (title) {
        const followsTitle = (e) =>
          !!(
            title.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING
          );
        const titleInk = textRects(title, { excludeOverlapOk: false }).map(
          inkRect,
        );
        const laterText = textRuns(fit, { excludeOverlapOk: false })
          .filter(
            (run) =>
              !title.contains(run.parent) &&
              followsTitle(run.parent) &&
              !run.parent.closest("h1,.h1,.display,[data-title],[data-device]"),
          )
          .map((run) => inkRect(run.rect));
        const laterPaint = [...fit.querySelectorAll("*")]
          .filter(
            (e) =>
              !title.contains(e) &&
              followsTitle(e) &&
              inFlowContent(e) &&
              !e.contains(title) &&
              !e.closest("[data-device]") &&
              paintsBox(e),
          )
          .map((e) => e.getBoundingClientRect())
          .filter((r) => r.width > 1 && r.height > 1);
        if (
          titleInk.some((tr) =>
            [...laterText, ...laterPaint].some((br) => intersects(tr, br)),
          )
        ) {
          R.titleBodyOverlaps++;
          if (R.samples.length < 8)
            R.samples.push(`p${pi + 1} title intersects body`);
        }
      }

      const bodyInk = textRuns(fit, { excludeOverlapOk: false })
        .filter(
          (run) =>
            !run.parent.closest(
              "h1,h2,h3,.h1,.h2,.h3,.display,.kicker,[data-title],[data-device]",
            ),
        )
        .map((run) => inkRect(run.rect));
      const floatingCtas = [
        ...st.querySelectorAll('[data-device="cta"]'),
      ].filter((cta) => {
        const pos = getComputedStyle(cta).position;
        return !fit.contains(cta) || pos === "absolute" || pos === "fixed";
      });
      const ctaPaint = floatingCtas.flatMap((cta) => [
        ...(paintsBox(cta) ? [cta.getBoundingClientRect()] : []),
        ...paintedRects(cta, { excludeOverlapOk: false }),
        ...textRects(cta, { excludeOverlapOk: false }),
      ]);
      if (bodyInk.some((br) => ctaPaint.some((cr) => intersects(br, cr)))) {
        R.bodyCtaOverlaps++;
        if (R.samples.length < 8)
          R.samples.push(`p${pi + 1} body intersects cta`);
      }
    }

    const stageInk = textRuns(st, { excludeOverlapOk: false })
      .filter((run) => !run.parent.closest("[data-bigcircle]"))
      .map((run) => inkRect(run.rect));
    let circleCollision = false;
    st.querySelectorAll("[data-bigcircle]").forEach((circle) => {
      if (circleCollision) return;
      const circleRect = circle.getBoundingClientRect();
      const isStructuralField =
        (circleRect.width > sr.width * 0.3 ||
          circleRect.height > sr.height * 0.55) &&
        !!circle.querySelector("h1,h2,h3,.h1,.h2,.h3,.display,[data-title]");
      if (isStructuralField) return;
      // A textless circle below .fit is a background field, not an occluding motif.
      // Label-bearing circles are checked regardless of z-order because their fill can
      // erase same-colour type even when the text layer itself paints above the circle.
      const circleZ = parseInt(getComputedStyle(circle).zIndex, 10) || 0;
      const fitZ = fit ? parseInt(getComputedStyle(fit).zIndex, 10) || 0 : 0;
      if (!circle.textContent.trim() && circleZ < fitZ) return;
      if (stageInk.some((tr) => intersectsBigcircle(circle, tr)))
        circleCollision = true;
    });
    if (circleCollision) {
      R.textBigcircleOverlaps++;
      if (R.samples.length < 8)
        R.samples.push(`p${pi + 1} bigcircle intersects text`);
    }

    // Decorative visuals can cross type intentionally, so this is an advisory rather
    // than a geometry gate. Report the candidate with the affected text and let the
    // visual review decide: obscured or unreadable glyphs must be repaired; clearly
    // legible type may keep the intentional overlap.
    const reviewVisuals = [...st.querySelectorAll(REVIEW_VISUAL)].filter(
      (v) => {
        if (v.parentElement && v.parentElement.closest(REVIEW_VISUAL))
          return false;
        const cs = getComputedStyle(v),
          r = v.getBoundingClientRect();
        return (
          cs.display !== "none" &&
          cs.visibility !== "hidden" &&
          parseFloat(cs.opacity || "1") > 0 &&
          r.width > 2 &&
          r.height > 2
        );
      },
    );
    const reviewText = textRuns(st, { excludeOverlapOk: false })
      .filter((run) => !run.parent.closest(REVIEW_VISUAL))
      .map((run) => ({ ...run, rect: inkRect(run.rect) }));
    const visualHit = reviewText.find((run) =>
      reviewVisuals.some((v) =>
        intersects(run.rect, v.getBoundingClientRect()),
      ),
    );
    if (visualHit) {
      R.textVisualOverlapCandidates++;
      if (R.visualOverlapSamples.length < 12)
        R.visualOverlapSamples.push(
          `p${pi + 1} "${visualHit.parent.textContent.trim().slice(0, 36)}"`,
        );
    }

    const floorOverflows = st.querySelectorAll(
      '[data-fit-content][data-overflow="fit-floor"]',
    ).length;
    R.fitFloorOverflows += floorOverflows;
    if (floorOverflows && R.samples.length < 8)
      R.samples.push(`p${pi + 1} fit-floor overflow x${floorOverflows}`);

    // Solid fills and gradients are placeholders. run.sh preloads CSS background URLs
    // and stamps the cell only after a successful load; an unverified or broken URL is
    // therefore a failure just like a broken <img>.
    st.querySelectorAll("[data-photocell]").forEach((cell) => {
      const img = cell.matches("img") ? cell : cell.querySelector("img");
      const hasImgSource = !!(
        img &&
        (img.currentSrc ||
          img.getAttribute("src") ||
          img.getAttribute("srcset")) &&
        img.complete &&
        img.naturalWidth > 0 &&
        img.naturalHeight > 0
      );
      const hasLoadedCssImage =
        cell.dataset.photocellBackgroundLoaded === "true";
      if (hasImgSource || hasLoadedCssImage) return;
      R.emptyPhotocells++;
      if (R.samples.length < 8) R.samples.push(`p${pi + 1} empty photocell`);
    });

    // ---- peer columns: first lines must agree ----
    [...st.querySelectorAll("*")].forEach((row) => {
      const cs = getComputedStyle(row);
      if (cs.display !== "flex" || cs.flexDirection !== "row") return;
      // A row that explicitly centres its peers is a left/right composition: each
      // column owns its vertical rhythm, so differing first-line tops are intentional.
      if (
        cs.alignItems === "center" ||
        cs.alignItems === "safe center" ||
        row.hasAttribute("data-peer-center")
      )
        return;
      const kids = [...row.children].filter(
        (k) => getComputedStyle(k).flexGrow !== "0",
      );
      if (kids.length < 2) return;
      if (row.getBoundingClientRect().width < sr.width * 0.4) return;
      if (kids.some((k) => getComputedStyle(k).justifyContent === "center"))
        return; // hub, legend
      const tops = kids
        .map((k) => {
          let top = Infinity,
            textels = 0;
          k.querySelectorAll("*").forEach((e) => {
            if (ownText(e).length < 2) return;
            if (getComputedStyle(e).position === "absolute") return; // out-of-flow badge
            if (e.closest('[style*="position:absolute"]')) return;
            textels++;
            const rg = document.createRange();
            rg.selectNodeContents(e);
            [...rg.getClientRects()].forEach((x) => {
              if (x.width > 2) top = Math.min(top, x.top);
            });
          });
          return textels >= 2 ? top : Infinity; // 1 label = a bar or a legend, not a column
        })
        .filter((t) => isFinite(t));
      if (tops.length < 2) return;
      const spread = Math.max(...tops) - Math.min(...tops);
      if (spread > 8) {
        R.columnsMisaligned++;
        colSpreads.push(Math.round(spread));
      }
    });

    // ---- filled boxes ----
    st.querySelectorAll("*").forEach((e) => {
      const cs = getComputedStyle(e),
        bg = cs.backgroundColor;
      if (!bg || /rgba?\(0, 0, 0, 0\)/.test(bg)) return;
      const r = e.getBoundingClientRect();
      if (r.width < sr.width * 0.08 || r.height < sr.height * 0.06) return;
      if (e.querySelector("canvas,img")) return;
      if (e === st) return;
      const br = cs.borderRadius || "";
      const round =
        /50%|9999px|999px/.test(br) || parseFloat(br) >= r.width * 0.45;
      if (round) return; // a disc or pill is not 'underfilled'

      if (lum(bg) < 0.09) R.darkPanels++;
      if (fullBleed) R.boxesOnFullBleed++;

      const parent = e.parentElement;
      let peers = false;
      if (parent) {
        const pcs = getComputedStyle(parent);
        if (pcs.display === "grid" && parent.children.length >= 2) peers = true;
        else if (
          pcs.display === "flex" &&
          pcs.flexDirection === "row" &&
          [...parent.children].filter(
            (k) => getComputedStyle(k).flexGrow !== "0",
          ).length >= 2
        )
          peers = true;
      }

      let inkBottom = 0,
        L = Infinity,
        Rt = -Infinity;
      e.querySelectorAll("*").forEach((k) => {
        if (ownText(k).length < 1) return;
        const rg = document.createRange();
        rg.selectNodeContents(k);
        [...rg.getClientRects()].forEach((x) => {
          if (x.width < 2) return;
          inkBottom = Math.max(inkBottom, x.bottom);
          L = Math.min(L, x.left);
          Rt = Math.max(Rt, x.right);
        });
      });
      if (!inkBottom) return;
      const pad = parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight);
      if (!peers && (inkBottom - r.top) / r.height < 0.75)
        R.boxesUnderfilledV++;
      if (!peers && isFinite(L) && (Rt - L + pad) / r.width < 0.8)
        R.boxesUnderfilledH++;
    });

    // ---- declared decoration ----
    // Do not infer decoration from geometry. In particular, an empty SVG may be
    // a chart or an icon inside a content cell; a rectangle may be a background
    // field; and tiles/nodes/connectors are layout vocabulary. Only explicitly
    // declared, textless, non-content elements enter these diagnostic counts.
    let big = [...st.querySelectorAll(DECO)].filter((d) => {
      if (!isStrictDecoration(d)) return false;
      const r = d.getBoundingClientRect();
      return r.width >= 8 && r.height >= 8;
    });
    R.bigOrnaments += big.length;
    if (big.length >= 2) R.pagesWithPair++;
    big.forEach((d) => {
      const r = d.getBoundingClientRect();
      const out =
        r.left < sr.left - 1 ||
        r.right > sr.right + 1 ||
        r.top < sr.top - 1 ||
        r.bottom > sr.bottom + 1;
      out ? bleed++ : inside++;
      const svg = d.querySelector("svg");
      const marked = d.matches(DECO);
      if (svg && marked) {
        const rect = svg.querySelectorAll("rect").length,
          path = svg.querySelectorAll("path").length,
          circ = svg.querySelectorAll("circle,ellipse").length;
        const known =
          (rect === 4 && !path && !circ) || (path === 1 && !rect && !circ);
        if (!known) R.offVocabularyShapes++;
      }
    });
    smallCount += st.querySelectorAll(
      '[data-decoration-size="small"],[data-deco-small]',
    ).length;
  });

  // ---- navigation structure ----
  // The deck runtime collects slides with [...deck.children].filter(n => n.classList
  // .contains('slide')). A slide nested one level deeper renders fine and is unreachable
  // by keyboard. One generated deck had 27 slides and navigated 2 of them.
  const decks = [...document.querySelectorAll(".deck")];
  const allSlides = [...document.querySelectorAll(".slide")];
  R.decks = decks.length;
  R.navigableSlides = decks.reduce(
    (n, d) =>
      n + [...d.children].filter((c) => c.classList.contains("slide")).length,
    0,
  );
  R.orphanSlides = allSlides.filter((s) => !s.closest(".deck")).length;
  R.indirectSlides = allSlides.filter((s) => {
    const d = s.closest(".deck");
    return d && s.parentElement !== d;
  }).length;
  if (R.orphanSlides || R.indirectSlides)
    R.samples.push(
      `nav: ${allSlides.length} slides, ${R.navigableSlides} reachable`,
    );

  R.surfaceUses = (
    document.documentElement.outerHTML.match(/var\(--surface\)/g) || []
  ).length;
  R.smallOrnaments = smallCount;
  R.bigPerPage = +(R.bigOrnaments / R.pages).toFixed(2);
  R.smallPerPage = +(R.smallOrnaments / R.pages).toFixed(3);
  R.pagesWithPairPct = +(R.pagesWithPair / R.pages).toFixed(2);
  R.bleedingPct = +(bleed / (bleed + inside || 1)).toFixed(3);
  R.fullBleedPct = +(R.fullBleedPages / R.pages).toFixed(2);
  R.layoutSafetyFailures =
    R.safeAreaShells +
    R.outsideSafeArea +
    R.emptyPhotocells +
    R.railOverlaps +
    R.textGraphicOverlaps +
    R.titleBodyOverlaps +
    R.bodyCtaOverlaps +
    R.textBigcircleOverlaps +
    R.fitFloorOverflows;
  if (colSpreads.length) R.worstColumnSpreadPx = Math.max(...colSpreads);
  return JSON.stringify(R, null, 1);
})();
