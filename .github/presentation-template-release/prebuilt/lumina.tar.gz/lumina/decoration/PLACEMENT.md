# lumina — decoration placement

Everything here is measured from the original reference deck (15 pages at 1600×900) using the
strict playbook definition: decoration must be template-specific, carry no text or data,
and perform no layout function.

The reference therefore has **17 optional decorations**: 14 asterisks + 3 divider circles.
Its 21 stickers are signature labels with text, not decoration; 2 badges + 4 nodes + 1
connector are layout structure; 15 photo cells are content. Those excluded elements remain
part of the template, but none enters optional-decoration statistics.

Open `decoration.html` to see the two qualifying decorations rendered and named. It carries
no fixed chrome and no structural item-set sample, so the preview count is exact.

**Do not carry bloom's decoration rules over.** They were measured on a different deck and
lumina disagrees with them on the two biggest ones — see §G. This file is what lumina
actually does.

## The layer model

| z-index | layer | where it comes from |
|---|---|---|
| 1 | `bigcircle` | this folder |
| 4 | `doodle` (the asterisk) | this folder |
| 5 | `sticker` signature label (not decoration) | this folder |
| 6 | persistent chrome (not decoration) | the shell |
| 40 | `.fit` — all content, including media frames | `../layouts/*.html` |
| 45 | `pagenum` | the shell |

Every optional decoration sits **below** `.fit` and none is inside it. The sticker label is
also below `.fit`, but remains excluded because it carries text and is marked
`data-device="sticker"`. If a layout and any of these devices collide, move the device —
never the copy.

## A · Persistent chrome — identical on every page, never optional decoration

On 15 of 15 reference slides. Copy verbatim; the naked layouts do not include it.

```html
<div style="position:absolute;left:6cqw;right:6cqw;top:5cqh;display:flex;justify-content:space-between;align-items:center;z-index:6">
  <span class="kicker" style="opacity:.75">Your company</span>
  <span class="kicker" style="opacity:.75">2026</span>
  <span class="kicker" style="opacity:.75">Company studio</span>
</div>
<div style="position:absolute;left:6cqw;right:6cqw;top:9cqh;height:1px;background:color-mix(in srgb,var(--ink) 18%,transparent);z-index:6"></div>
<div class="pagenum">01</div>
```

**The three labels carry no colour token, and that is deliberate.** They inherit from
`.stage`, so they are `--ink` on a pale page and `--t0` on a full-bleed one. Writing
`class="kicker soft"` instead pins them to `--soft`, which measures 2.3:1 on the purple
divider — an early version of this folder did exactly that and the probe caught it.

The band occupies 5–8cqh. `.fit` starts at 12cqh, so nothing collides. Measured with the
same in-flow-text predicate as the probe: the earliest reference content starts at 12.0%
of stage height.

## B · The sticker is a signature label — 21 uses, excluded from decoration

**Every page carries one or two stickers. Never zero, never three.** Measured: 15 of 15
pages, 21 stickers, distribution 1 or 2 — no page has any other count.

| page role | stickers |
|---|---|
| cover, section divider, closing | **2** |
| thesis / paired-claim page (reference p5) | **2** |
| ordinary content page | **1** |

This is the identity rule most likely to be dropped, because a sticker is small and reads
as optional. It carries more of this template's identity than any other device.
`design-system.md` counts 1.4 labelled boxes per slide — those 1.4 *are* these stickers.
But the label carries text, so the strict decoration probe deliberately excludes it.

Copy the markup, change only the anchor, the rotation, the ground token and the word:

```html
<div data-device="sticker" style="position:absolute;right:9cqw;top:52cqh;transform:rotate(-5deg);background:var(--g2);color:var(--t2);padding:.7cqh 1.1cqw;border-radius:.5cqw;font-family:var(--fd);font-weight:600;font-size:1.15cqw;letter-spacing:.12em;text-transform:uppercase;white-space:nowrap;box-shadow:0 2px 8px color-mix(in srgb, var(--ink) 12%, transparent);z-index:5">Photography</div>
```

Measured across all 21:

- **rotation is never zero** — `rotate(-5deg)` ×8, `rotate(-6deg)` ×1,
  `rotate(5deg)` ×5, `rotate(4deg)` ×4, `rotate(-4deg)` ×3. A sticker set straight reads
  as a button.
- **the shadow is on all 21.** It is the offset that makes it a sticker and not a chip.
- width 6.4–16.3% of the stage (mean 11.5). `white-space:nowrap` — one or two words.
- **never cropped by the stage edge**: 0 of 21 bleed. Anchor it 6–9cqw in from an edge.
- it leans right and high: mean centre x 69%, mean centre y 37%.
- ground cycles `--g0 --g1 --g2 --g3` with the matching `--t?` for its text.

## C · Optional decoration 1/2 — the asterisk, normally one and never cropped

`doodle` is the eight-point asterisk: four rounded bars at 0/45/90/135°. 14 uses on 15
pages.

- **at most one per page.** No reference page carries two. The one page with none (p14) is
  the densest page in the deck — when a page is full, drop it rather than squeeze it.
- **never cropped**: 0 of 14 bleed. This is the opposite of the big circle.
- 5–8cqw (mean 6.7). Fill with a raw hue — `--s1`, `--s2`, `--s3` or `--accent` — or with
  `--ink` on a pale page; on a full-bleed page it goes white.
- it goes wherever the content is not: measured centres run 9–90% across and 18–86% down.

```html
<div data-decoration="asterisk" data-doodle="1" style="position:absolute;right:34cqw;top:16cqh;width:6cqw;height:6cqw;z-index:4"><svg viewBox="0 0 100 100" style="width:100%;height:100%;display:block"><rect x="4" y="42.5" width="92" height="15" rx="7.5" transform="rotate(0 50 50)" fill="var(--ink)"/><rect x="4" y="42.5" width="92" height="15" rx="7.5" transform="rotate(45 50 50)" fill="var(--ink)"/><rect x="4" y="42.5" width="92" height="15" rx="7.5" transform="rotate(90 50 50)" fill="var(--ink)"/><rect x="4" y="42.5" width="92" height="15" rx="7.5" transform="rotate(135 50 50)" fill="var(--ink)"/></svg></div>
```

## D · Optional decoration 2/2 — the divider big circle

3 uses in the deck, all three on the three section dividers. **Zero on content pages.**

- one per divider, **always cropped by the right edge** (3 of 3 bleed, anchored
  `right:-22cqw` to `-23cqw`)
- 44–46cqw — nearly half the stage
- fill cycles `--s1 → --s2 → --s3` across successive dividers, never repeating consecutively
- `z-index:1`, under everything

```html
<div data-decoration="bigcircle" data-bigcircle="1" style="position:absolute;right:-23cqw;bottom:-12.88cqh;width:46cqw;height:46cqw;background:var(--s1);border-radius:50%;opacity:1;z-index:1"></div>
```

Putting one on a content page is the single fastest way to make a lumina deck look like a
different template. It is a divider device.

## E · Structural item sets — every member gets one, none are decoration

Two layout families attach a structural mark to each item of a peer set. The rule is
all-or-nothing: a set where three items have a badge and the fourth does not reads as a bug.
Because the marks label or connect content, the strict playbook says not to create an
optional-decoration `item-sets.html`; copy them from the named layout files instead.

| layout | attach | reference |
|---|---|---|
| `numbered-points` | one `badge` per row, ground cycling `--g0 --g1 --g3` | 2 of 2 rows |
| `process-steps`, `flow-diagram`, `timeline` | one `node` per step + one connector treatment | 4 of 4 steps |
| everything else | nothing — the hairline rules already in the layout do the work | — |

`design-system.md` requires the number inside a `badge` to be wrapped in a `<span>` and
the box sized with `--sz`, because `.badge>span` scales the figure against the badge's own
width. The layouts here size `--sz` in `em` so the badge follows the type instead of
freezing to the stage.

## F · What counts as decoration — and what does not

`offVocabularyShapes` reads 0 on the reference. The optional-decoration vocabulary is
closed:

**asterisk · big circle.**

The sticker remains a required signature label, but its text makes it ineligible for this
optional-decoration list.

`numbered badge` and `node + connector` are item-set marks in `../layouts/`; they are not
counted as optional decoration. A brush letter is
typography. An image cell is content. A colour field, card, square, rectangle, content
container or grid cell is layout/background treatment, not decoration.

No generic substitute circles, squares, arches, pills or colour blocks. A plain outlined
box or an empty colour rectangle is not a motif.

## G · Two bloom rules that are wrong here — measured, not assumed

Both of these are bloom's headline decoration findings. lumina's reference contradicts
both, so importing them would have made every generated deck worse.

| bloom | lumina, measured |
|---|---|
| "15 of 17 pages carry **exactly two** big ornaments, one of each shape" | **3 of 15** pages carry a pair, and those are exactly the three dividers: one asterisk + one big circle. Ordinary content pages never pair. |
| "**31 of 33** ornaments hang off the stage edge" (94%) | Under the strict declared-decoration probe, **3 of 17 = 17.6%** bleed. All three are divider circles; all 14 asterisks sit fully inside. |

So: do not pair on ordinary content pages, and do not bleed the asterisk. The one thing
lumina *does* crop is the divider circle, a single element on a single page role.

## H · The lower third is not automatically free

Measured ornament centres run to 86% of stage height, so the bottom of the stage is in
use. But lumina also anchors real content there — the cover's standfirst sits at 92%, the
closing page's two contact bars at 87–94%.

Before deciding a layout looks empty at the bottom and pushing content down into it,
overlay this page's ornaments and check. Two of bloom's layout changes were reverted after
exactly that overlay showed the ornament landing on the copy.
