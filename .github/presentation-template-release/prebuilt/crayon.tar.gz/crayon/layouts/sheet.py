#!/usr/bin/env python3
"""Build labelled browser-review sheets from every crayon layout."""

from pathlib import Path
import re


HERE = Path(__file__).parent
SHELL = (HERE / "_shell.html").read_text()
HEAD = SHELL[: SHELL.index("</style>")]

GROUPS = [
    ("Opening and closing", ["cover", "toc", "section-divider", "section-divider-field", "close"]),
    ("Prose", ["longform", "bullets", "numbered-list", "two-column", "three-column", "color-cards"]),
    ("Quotation", ["big-quote", "quote-cards"]),
    ("Numbers", ["stat-highlight", "kpi-row", "table", "chart-bar", "chart-line", "chart-pie", "pricing"]),
    ("Time and sequence", ["process-steps", "timeline", "roadmap", "gantt"]),
    ("Structure", ["mindmap", "flow-diagram", "architecture", "sketch-explainer"]),
    ("Options and evidence", ["comparison", "versus", "pros-cons", "case-study"]),
    ("Imagery and people", ["image-left", "image-right", "image-hero", "image-grid", "team"]),
]

SHEET_CSS = """
.deck{scroll-snap-type:none;height:auto;overflow:visible;background:#17151d}
.slide{width:auto;height:auto;display:block;background:transparent}
.stage{width:1600px;height:900px;margin:0}
.layout-chunk{width:1600px;background:#17151d}
.layout-label{font:600 28px/1.4 ui-monospace,monospace;color:#fff;background:#17151d;
  padding:12px 20px;letter-spacing:.04em;border-top:2px solid #45404f}
.layout-group{font:700 32px/1.4 ui-monospace,monospace;color:#17151d;background:#f7c95a;
  padding:16px 20px;letter-spacing:.08em}
</style>
"""

entries = []
for group, names in GROUPS:
    for name in names:
        source = (HERE / f"{name}.html").read_text()
        match = re.search(
            r'(<div class="stage".*</div>)\s*</div>\s*</div>\s*</body>',
            source,
            re.S,
        )
        if not match:
            raise RuntimeError(f"could not extract stage from {name}.html")
        entries.append(
            (
                group,
                f'<div class="layout-label">{name}.html</div>'
                f'<div class="slide">{match.group(1)}</div>',
            )
        )

parts = []
for chunk_index in range(0, len(entries), 10):
    chunk = entries[chunk_index : chunk_index + 10]
    chunk_parts = []
    previous_group = None
    for group, markup in chunk:
        if group != previous_group:
            chunk_parts.append(f'<div class="layout-group">{group}</div>')
            previous_group = group
        chunk_parts.append(markup)
    parts.append(
        f'<section class="layout-chunk" id="chunk-{chunk_index // 10 + 1}">'
        + "\n".join(chunk_parts)
        + "</section>"
    )


def document(markup):
    return (
        HEAD
        + SHEET_CSS
        + '\n</head><body><div class="deck">\n'
        + markup
        + "\n</div></body></html>\n"
    )


(HERE / "_sheet.html").write_text(document("\n".join(parts)))
for index, part in enumerate(parts, 1):
    (HERE / f"_sheet-{index}.html").write_text(document(part))

print(f"wrote {len(entries)} layouts across {len(parts)} labelled sheets")
