# crayon — undecorated layouts

37 layouts with no optional decoration. They contain no blobs or sparks and no measured
placeholder geometry. Inline marker typography and content/layout devices stay here:
badges carry list identifiers, burst-stars carry figures, and nodes/connectors express a
process.
Pair one of these with [../decoration/PLACEMENT.md](../decoration/PLACEMENT.md) to
build a slide.

One deliberate exception: the **marker-highlight stays in the layouts**. It is inline
type, not a placed ornament, and it is on 15 of the 15 titles in the reference deck —
the single most identifying thing crayon does. Stripping it out of the layouts is the
fastest way to make it disappear from generated decks.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 37: zero `width` / `max-width` / `min-width` / `height` / `left` /
`top` / `right` / `bottom` / `flex` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

`flex-basis` counts. `flex:0 0 4cqw` freezes a column exactly the way a `width` does.

Five exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline rule.
- **`em`** on a content device that carries a figure and no prose — the `badge` and the
  `burst-star`. `em` scales with the type inside it, so the box cannot freeze. This is
  why `.badge` here is `width:2.4em` and not the `width:var(--sz,5cqw)` that
  `design-system.md` shows: that version freezes a box that holds a number.
- **`%`** in `chart-bar` and `gantt`, where the number *is* the datum. A bar at 82%
  reports 82; a schedule bar's offset and span report its place on the calendar.
- text that merely *displays* a CSS string. Strip text nodes before matching.

Everything else stretches. Columns are `flex:1`. **The safe area is set once, by the
padding on `.fit` (`12cqh 8cqw 8cqh`)** — no layout writes a margin to place itself.

The modal left edge of in-flow text in the reference is 8% (25 runs; the next most
common edges were 6% with 13 and 7% with 12). That measured mode is the template
constant. The reference pages that had been written back at 6% or 7% were brought onto
the same 8% inset; with `data-safe-area="0.08"`, all 169 text runs now pass
`outsideSafeArea`. Do not infer the safe area from a page's own padding.

This matters because the removed full-deck HTML example was produced by measuring a rendered deck
and writing the numbers back — `width:62cqw`, `min-height:61.05cqh`,
`margin-top:31.02cqh` are observations of one string at one font size. These carry none.

Any flex child holding an SVG or a percentage-height bar needs `min-height:0`, or the
SVG's intrinsic ratio pushes it past the stage edge.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions.
Not a slide.

`sheet.py` builds `_sheet.html` and top-anchored `_sheet-N.html` review pages from the
inventory below. Generated sheets are review artifacts, not layouts.

**Opening and closing** · `cover` `toc` `section-divider` `section-divider-field` `close`

**Prose** · `longform` `bullets` `numbered-list` `two-column` `three-column`
`color-cards`

**Quotation** · `big-quote` `quote-cards`

**Numbers** · `stat-highlight` `kpi-row` `table` `chart-bar` `chart-line` `chart-pie`
`pricing`

**Time and sequence** · `process-steps` `timeline` `roadmap` `gantt`

**Structure** · `mindmap` `flow-diagram` `architecture` `sketch-explainer`

**Two things compared** · `comparison` `versus` `pros-cons`

**Evidence stories** · `case-study`

**Imagery** · `image-left` `image-right` `image-hero` `image-grid` `team` — all five delete cleanly.
`image-left` / `image-right` are a split row: the frame is `flex:1`, the copy `flex:1.15`.
When the source has no imagery, drop the `data-photocell` frame and use a prose layout;
do not leave an empty box.

## Where the set came from

13 of these are the layouts the reference deck already demonstrates, one per page role:
`cover` `toc` `section-divider` `image-left` `numbered-list` `team` `color-cards`
`process-steps` `image-grid` `stat-highlight` `quote-cards` `pricing` `close`.
Those were not up for debate.

3 more come from `../composition-recipes.html`, which holds treatments the example does
not: `big-quote`, `comparison`, `table`.

The next 13 are additions a real deck needs and crayon had no answer for, each
re-expressed in crayon's own vocabulary rather than imported: `section-divider-field`
`bullets` `two-column` `three-column` `kpi-row` `chart-bar` `chart-line` `chart-pie`
`timeline` `roadmap` `mindmap` `versus` `image-right`.

The review-led coverage pass added eight independent communication jobs:

- `longform` sustains a sourced narrative without inventing an empty companion column.
- `image-hero` gives one large image vertical emphasis while keeping copy outside it.
- `gantt` shows overlap and dependency across calendar windows, not merely phases.
- `flow-diagram` handles a split and convergence that a linear process cannot express.
- `architecture` separates experience, coordination and foundation layers.
- `pros-cons` pairs each benefit with its direct cost instead of comparing two entities.
- `case-study` carries challenge, intervention and measurable outcome on one page.
- `sketch-explainer` annotates a mechanism in crayon's hand-drawn visual language.

Two considered additions remain deliberately absent: `todo-checklist` is `bullets` with
a different marker, and `chart-radar` adds no requested analytical job. A separate
`statement` would duplicate `big-quote`; another linear flow would duplicate
`process-steps`. The number is an outcome: 37 distinct purposes, not a quota.

## Content and layout devices stay in layouts

Several of these describe a **set of peer items**, and in crayon every item in such a set
carries the same content device — never a subset. These are not optional decorations and
are intentionally absent from `../decoration/`.

| layout | attach |
|---|---|
| `numbered-list` | one `badge` per item, grounds cycling `--g0 --g2 --g1` |
| `stat-highlight` | one `burst-star` per figure, each a different fill |
| `kpi-row` | unboxed figures; no burst-stars |
| `process-steps` | one `node` per stage + one `connector` behind the row |
| `flow-diagram` | one arrow per relationship; paired branches carry the same card treatment |
| `architecture` | peer nodes within each layer + arrows only between dependency layers |
| `pros-cons` | one arrow between each directly paired benefit and cost |
| `sketch-explainer` | one labelled SVG loop + one badge per annotation |
| `gantt` | schedule bars encode calendar position and duration; they are data, not decoration |
| `cover` `toc` `image-grid` | at most one `pill-tag`, in a corner, clear of the title |
| `mindmap` | one `badge` per branch, `border-radius:var(--r-round)` |
| everything else | no attached content device |

During the identity pass, every layout also gets **≥2 peripheral blobs and ≥1 spark**,
because 15 of 15 reference pages do. Those two textless motifs are optional decoration.
The footer label and page number are fixed chrome and are counted separately.

## Ruled or filled — crayon leans the other way from bloom

Only **7 hairline rules across the whole reference deck**, on 2 of 15 pages (the agenda
and the price cards). Crayon's habit is the opposite of bloom's: it reaches for a
**filled `--gN` card** — service cards, quote cards, price cards are all filled. So the
menu risk here is a deck where every slide is a row of coloured cards.

Each peer-row content type therefore has both treatments, and neither is more
on-template:

| content | ruled | filled |
|---|---|---|
| a list of points | `bullets` | `numbered-list` |
| three peer columns | `three-column` | `color-cards` |
| a row of numbers | `kpi-row` | `stat-highlight` |
| two things compared | `comparison` | `versus` |
| a sequence | `timeline` | `roadmap` |

The filled versions cycle `--g0 --g2 --g1 --g3` so neighbours never share a hue.

## A filled box is sized by its content, never by the stage

```
height  row     flex:none        — from the tallest child, not the stage
        child   flex:1           — every sibling matches that tallest child
        group   wrapped in flex:1;min-height:0; … justify-content:center

width   box     align-self:flex-start; max-width:100%
```

`.fit` is a column flex with `align-items:stretch`, so **every child is full-width by
default**. `roadmap` shipped with its three phase headers full-lane-width around two
short words — 3 underfilled boxes — until each got `align-self:flex-start`. One box
hugs; a **row** of boxes divides the safe area and stays equal.

`flex:1` on the **row** and `flex:1` on the **child** look like the same instruction and
do opposite things: on the row it fills the stage and the cards inherit the stage's
height, which is how you get a slab of colour that is half empty.

Reserve a filling `flex:1` for an image frame or a chart plot area.

## Equal height is stress-tested, not assumed

Every peer group was re-measured with an extra sentence injected into its first item.
All true peer groups equalise to the tallest item.

The one that does not is `stat-highlight`, and it is correct: its two halves are a
prose block and a row of figures, not peers. They share a first baseline
(`columnsMisaligned` 0) and their heights differ because their content does. Forcing
those two to equal height would be the same over-application of `align-items:stretch`
that put bloom's numbered rows above their own headings.

## Colour

- **Never `--surface`.** On prism it is `#F7F7FA` on a `#FFFFFF` page — 1.04:1, a white
  card on a white page. The reference uses it zero times; so do these 37.
- **Only `--ka` is legible as text** among the hue tokens on the white ground: 4.97:1,
  against `--s1` 2.82, `--s3` 2.56, `--s2` 1.48. The source hues are fills. The
  reference's agenda numbers broke this rule and were fixed rather than exempted.
- **`--ink` grounds only small things** — the circular process node, a pill. A large
  dark rounded rectangle reads as a photo placeholder.
- **Nothing sits on a full-bleed page.** `section-divider-field` puts its ground on
  `.stage` and carries no box at all.

Checked on all 37: zero text below 3.0:1, zero `--surface`, zero dark panels.

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` ·
structure `stage fit deck slide card tile badge` ·
marks `marker dot rule rule-on soft dim pagenum`.

Sizes live in those classes. If something needs to be bigger, use the next class up.

Older guidance named `.mono`, `.panel`, `.gridpaper`, `.mat` and `.track` as helpers.
**None of them is defined anywhere in this template**, in its shell or its example.
They are not available; do not reach for them.
