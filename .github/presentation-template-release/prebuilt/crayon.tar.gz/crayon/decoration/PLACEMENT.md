# crayon — where the decoration goes

measured from the original reference deck, 15 pages, rendered at 1600×900. Every number
below is a reference reading, not a preference. `../layouts/` carries no optional
decoration; pair a layout with this file to build a slide.

Vocabulary rendered with no text: [decoration.html](decoration.html).
There is deliberately no item-set file. Crayon has no textless motif that attaches to
repeated items: badges, burst figures, process nodes, and connectors convey content or
layout structure, so they remain in the relevant layout files.

## The two big findings, and they point opposite ways

Crayon has two ornaments that appear on every single page, and their placement rules
are **exact opposites**. This is the thing to get right; it is also the thing a deck
built from the example alone gets wrong, because the example never says it.

| | reference | rule |
|---|---|---|
| `peripheral-blob` | **39 of 39** hang off the stage edge | always cropped, never floating |
| `doodle-spark` | **0 of 16** hang off the stage edge | always whole, never cropped |

Both are exact-equality readings across the whole deck, so both gate. A blob that
sits entirely inside the stage is wrong. A spark that gets clipped by the edge is
wrong. There is no page where either is a judgement call.

## Optional decoration: how many, and what it attaches to

A class with a frequency but no attachment gets dropped — bloom watched its small
ornaments fall from 0.214 to 0.022 per page for exactly that reason. So every row
here carries both.

| optional ornament | reference rate | attaches to |
|---|---|---|
| `peripheral-blob` | 2.6 / slide, **≥2 on 15 of 15 slides** | the stage, at a corner; free of any layout |
| `doodle-spark` | 1.07 / slide, **≥1 on 15 of 15 slides** | the stage, inside the safe margin; free of any layout |

These are the only two optional-decoration classes. Fixed footer/page chrome is excluded.
The following measured devices are also excluded because they carry text, data, media,
or structure: marker-highlight (inline title typography), badges (identifiers),
burst-stars (figures), nodes/connectors (process structure), pill-tags (labels), and
photographs (content). Repeated content-device sets are still **all-or-nothing**: every
peer gets the device or none do.

## Blobs

- **Size** 22cqw–46cqw, median 34cqw. Under 20cqw it reads as a stray dot, over 50cqw
  it swallows the page.
- **Anchor** all four corners, evenly: left-top 10, right-top 11, right-bottom 9,
  left-bottom 9. Do not pile them into one corner.
- **Offset** every one of the 39 carries a negative `left/right/top/bottom`, which is
  what pushes it off the edge. That negative number is the whole technique.
- **Hue** rotates `--s1` / `--s2` / `--s3` evenly (11 / 11 / 11) with `--accent` on 6.
  **All 15 pages use distinct hues for their blobs** — no page repeats a fill. That is
  15 of 15, so it gates.
- **Path** the reference draws 27 distinct paths for 39 blobs. The irregularity is the
  point: never substitute a `<circle>`, `<ellipse>` or a rounded rectangle. Vary the
  path; four representative ones are in `decoration.html`.
- `z-index:0`, behind everything.

## Sparks

- **Size** 5–7cqw, and nothing else in the deck is that size.
- **Rotation** 9 distinct angles across 16 sparks. Rotate every one differently.
- **Hue** `--s1` (9), `--accent` (5), `--s3` (2) — and **never `--s2`**. On prism `--s2`
  is `#AEE63E` at 1.48:1 against the white ground; as a 7-unit stroke it disappears.
  The reference never uses it for a spark. Check the same ratio before using any hue
  for a thin stroke in another colour system.
- `z-index:2`, above the blobs, below the content.

## The lower third is not empty

Sparks and blobs both work the bottom of the stage: 9 of the 16 sparks sit below the
half line, and 18 of 39 blobs anchor to a bottom corner. Before deciding a layout looks
empty and bottom-anchoring its content to fill the space, overlay this file's ornament
pair on it and look. bloom "fixed" two layouts that way and had to revert both.

## The content frame is measured, not chosen per page

- **Horizontal safe area: 8% on both sides.** At 1600x900 the modal left edge of
  in-flow reference text is 8% (25 of 169 runs; 6% and 7% were the two smaller legacy
  write-back positions). Those legacy pages were aligned to the measured mode, and the
  reference now reads `outsideSafeArea 0` with `data-safe-area="0.08"`. Set the inset
  once as `padding:12cqh 8cqw 8cqh` on `.fit`; never let one slide redefine it.
- **Top 11% is not content.** It is where an optional pill tag and peripheral marks may
  sit. In-flow text begins at 12%; the reference reads `aboveChromeBand 0`. A title at
  10% produced three violations and was moved into the shared content frame.

## Colour, measured on prism against the `#FFFFFF` ground

| token | value | contrast | use as |
|---|---|---|---|
| `--ka` / `--accent` | `#7257E6` | 4.97 | text or fill |
| `--s1` | `#FF6B4A` | 2.82 | **fill only** |
| `--s3` | `#3FA9F5` | 2.56 | **fill only** |
| `--s2` | `#AEE63E` | 1.48 | **fill only** |
| `--surface` | `#F7F7FA` | 1.04 vs `--bg` | **never** — a white card on a white page |

Recompute these for whatever colour system the deck actually loads; the token names are
shared but the values are not.

- The reference uses `--surface` **zero times** in its markup. So does every layout.
- `--ink` grounds only small things: the 6cqw circular process `node` and one pill.
  Never a large dark rounded rectangle — it reads as a photo placeholder.
- On a `--gN` ground use the matching `--tN`, and let a kicker take `color:inherit`.
  `--ka` on a colour field is the accent again and vanishes.

## Two legacy claims rejected by the reference measurement

Both remain recorded here so they do not creep back in: a rule the reference fails
cannot gate.

- **`full-stage colour field`, "2–3 per deck".** The reference deck has **0 of 15**.
  `../layouts/section-divider-field.html` is offered for when a deck wants one, and
  nothing carries a box on it, but there is no measured basis for requiring any.
- **`pill-tag` on "the cover and closing slide".** The reference puts one on the cover,
  the agenda and the gallery, and **none on the closing slide**.
