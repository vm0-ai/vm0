---
name: crayon
description: Create a standalone 16:9 HTML presentation deck with the Crayon visual identity and direct-HTML workflow. Use when the user selects the Crayon presentation template or explicitly names crayon as the deck style. Best suited to handmade, colourful education, family, youth, and workshop presentations.
---

# Crayon presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

Choose by what the slide has to do, then copy that file's structure.

| the slide is                                      | layout                                                           |
| ------------------------------------------------- | ---------------------------------------------------------------- |
| the opening                                       | `cover`                                                          |
| an agenda or contents                             | `toc`                                                            |
| a chapter break                                   | `section-divider`, or `section-divider-field` on a colour ground |
| a list of points, ruled                           | `bullets`                                                        |
| a list of points, with numbered badges            | `numbered-list`                                                  |
| a sustained narrative or long-form argument       | `longform`                                                       |
| two blocks of prose                               | `two-column`                                                     |
| three parallel ideas, ruled                       | `three-column`                                                   |
| three or four parallel ideas, filled              | `color-cards`                                                    |
| one decisive statement                            | `big-quote`                                                      |
| several testimonials                              | `quote-cards`                                                    |
| two or three headline figures beside prose        | `stat-highlight`                                                 |
| a row of four figures                             | `kpi-row`                                                        |
| rows of records, codes or metrics                 | `table`                                                          |
| a magnitude comparison                            | `chart-bar`                                                      |
| a trend over time                                 | `chart-line`                                                     |
| a share of a whole                                | `chart-pie`                                                      |
| tiers or packages                                 | `pricing`                                                        |
| stages of a process                               | `process-steps`                                                  |
| dated events                                      | `timeline`                                                       |
| phased plans                                      | `roadmap`                                                        |
| scheduled work across calendar windows            | `gantt`                                                          |
| a hub with branches                               | `mindmap`                                                        |
| a branching flow that later converges             | `flow-diagram`                                                   |
| system layers and dependencies                    | `architecture`                                                   |
| an annotated mechanism in crayon vocabulary       | `sketch-explainer`                                               |
| two things compared, quiet                        | `comparison`                                                     |
| two things compared, loud                         | `versus`                                                         |
| paired benefits and costs                         | `pros-cons`                                                      |
| a challenge, intervention and outcome             | `case-study`                                                     |
| a subject with one picture                        | `image-left` / `image-right`                                     |
| one large image with separate context and caption | `image-hero`                                                     |
| several pictures                                  | `image-grid`                                                     |
| people                                            | `team`                                                           |
| the closing                                       | `close`                                                          |

Vary the register: if the last slide was a row of filled cards, make this one ruled.
`layouts/README.md` lists the ruled/filled pair for each content type.

### Then build the deck

- Produce one standalone HTML file with one live `.deck`. Keep every `.slide` as a direct child, give it one 16:9 `.stage`, and include the deck CSS and keyboard-navigation script once.
- Copy the shell from [layouts/\_shell.html](layouts/_shell.html) verbatim into the single
  `<style>` block and build slides out of its class names. **The safe area is the padding
  on `.fit`, written once: `12cqh 8cqw 8cqh`.** It is recorded as
  `data-safe-area="0.08"`. Do not place a block with
  `margin-left:8%` or size one with
  `width:62cqw`; that is the frozen geometry this split exists to remove.
- Build every slide in three layers: **ground** (stage background, any colour field),
  **decoration** (blobs and sparks, `position:absolute`, `z-index:0`–`2`, free to be
  cropped by the stage edge), and **content** (`.fit` and the text, `z-index:40`).
  Place the decoration first. Decoration added at the end always ends up as an
  afterthought in a corner.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

### Required identity and chrome

Every slide carries all four, or the deck is incomplete. The first two are optional
decoration motifs, the marker is inline typography, and the footer/page number are fixed
chrome; keep those categories separate when counting decoration.

1. Use `peripheral-blob` and `doodle-spark` only for the page roles documented in
   `decoration/PLACEMENT.md`; crop blobs at the stage edge and keep sparks whole.
2. Use a marker-highlight on ordinary titles. On `section-divider-field`, let the title
   inherit the field text colour instead of adding a marker box.
3. **Footer label and page number**: `<div class="kicker" …>Brand · 04</div>` bottom-left
   and `<div class="pagenum">04</div>` bottom-right.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

- Every photograph uses a documented template treatment: circles for portraits and
  avatars, `--r-md` for a team row, `--r-lg` for gallery cells, or `--r-xl` for a hero
  image. Never square.
- Use photographs only when the content supports them; zero photographs is valid.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

- Read [design-system.md](design-system.md) completely before writing any HTML, for the
  colour tokens, the type scale, the radius scale and the `Never do this` list.
- Read [layouts/README.md](layouts/README.md). It carries the sizing law, the
  ruled-versus-filled pairs, and the box-sizing rules that decide whether a deck looks
  built or assembled.
- Read [decoration/PLACEMENT.md](decoration/PLACEMENT.md) and copy the optional,
  textless ornament markup from [decoration/decoration.html](decoration/decoration.html).
  Crayon has no genuine item-set decorations: its badges, burst figures, nodes, and
  connectors are content or layout structure and remain in the layouts. **Copy the
  decoration snippets. Do not
  paraphrase them, redraw them, simplify them, or substitute a shape you find easier to
  write.** Change only size, position, colour token, and text content.
- Read [composition-recipes.html](composition-recipes.html) before laying out a slide
  whose content is a table, a list of records, or repeated rows. A column holding
  identifiers, codes, or numbers takes the width its content needs and never wraps; only
  the prose column absorbs the slack.
- Use the prompt's `color-system` when supplied, otherwise a preferred token from
  `design-system.md`. Inline that one `color-systems/<token>.css` in the final HTML.

**Order of priority when two of these pull against each other:**

1. the content is accurate and complete against the supplied material;
2. every slide is legible at presentation size;
3. the template's identity is intact — marker-highlighted titles, blobs, sparks, chrome;
4. every optional ornament and content device follows its documented role and placement.

Decoration never wins against 1 or 2. It must not displace content, shrink copy, drop a
point from a slide, or invent something to fill a slot. A deck that is accurate but
visually anonymous also fails.

### Build a slide from the layout and decoration catalogues

A slide is a **layout** plus a **decoration** pass.

- [layouts/](layouts/) — 37 undecorated layouts, one file each. They retain
  content-bearing and structural devices such as badges, burst figures, nodes, and
  connectors. Copy the structure.
- [decoration/PLACEMENT.md](decoration/PLACEMENT.md) — which ornaments are allowed,
  their page roles, and their placement. Apply it with the layout.

Read `layouts/` for rhythm and page-role mix; take reusable structure from
`layouts/` and ornament placement from `decoration/PLACEMENT.md`.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Reported checks

The single report lists these fields:

`overflow` · `outsideSafeArea` · `lowContrast` · `aboveChromeBand` ·
`boxesUnderfilledV` · `boxesUnderfilledH` · `boxesOnFullBleed` · `darkPanels`

Plus, by inspection:

- every optional motif follows the page-role and placement rules in `PLACEMENT.md`
- blobs are cropped by the stage edge and sparks are not cropped
- ordinary titles carry a marker-highlight; `section-divider-field` does not
- `surfaceUses` reports no live `--surface` element; dead CSS rules do not count
- a content-device set is all-or-nothing: every peer item carries the device, or none do

#### Search the finished HTML for each of these and remove every hit

- a title in one flat colour with no marker highlight, except `section-divider-field`
- a rendered `--surface` panel
- a `<circle>` or `<ellipse>` standing in for a blob path
- a `stat-highlight` figure in a plain box instead of a burst-star (`kpi-row` is the
  deliberate unboxed numerical treatment)
- disc or dot list bullets, including a literal `•`
- a square-cornered photograph
- a drop shadow
- a slide missing its footer label or page number
- fewer than three visible hues in the deck
- `.mono`, `.panel`, `.gridpaper`, `.mat` or `.track` — these class names appear in older
  guidance but are **not defined** in this template's shell

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
