---
name: crayon
description: Create, revise, or review standalone 16:9 HTML presentation decks with the Crayon visual identity and direct-HTML workflow. Use when the user selects the Crayon presentation template or explicitly names crayon as the deck style. Best suited to handmade, colourful education, family, youth, and workshop presentations.
---

# Crayon presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## Build a slide from the layout and decoration catalogues

A slide is a **layout** plus a **decoration** pass.

- [layouts/](layouts/) — 37 undecorated layouts, one file each. They retain
  content-bearing and structural devices such as badges, burst figures, nodes, and
  connectors. Copy the structure.
- [decoration/PLACEMENT.md](decoration/PLACEMENT.md) — which ornaments are allowed,
  their page roles, and their placement. Apply it with the layout.

Read `layouts/` for rhythm and page-role mix; take reusable structure from
`layouts/` and ornament placement from `decoration/PLACEMENT.md`.

## Choose the task mode

- Create: use Sections 1–5 and complete Section 2 before writing any slide HTML.
- Revise: inspect the existing HTML, reconstruct or update the outline for the affected sequence, and complete Section 2 before editing slide HTML; then use Sections 3–5 as relevant while preserving valid shell, token, motif, and runtime implementation.
- Review: use Sections 1–3 for context and Section 5 as the checklist; infer the deck's throughline and slide-level content contract, skip Section 4, and do not edit. Report slide-specific findings in P1 / P2 / P3 order (blocking / material / polish), include evidence and a fix direction, or state explicitly that there are no actionable findings.

## 1. Define the communication job

- Read the prompt and all supplied source material before composing slides.
- Identify the audience, purpose, desired audience outcome, core takeaway, and required evidence.
- Express the communication job in one sentence: by the end, the audience should reach the desired outcome because of the core takeaway.
- Ground every factual claim and number in supplied or verified sources; label forecasts, targets, and assumptions explicitly.

## 2. Complete the slide outline before HTML

- Before creating or changing slide HTML, write a lightweight plain-text or Markdown outline. State the one-sentence throughline, then list the slides in order.
- For each slide, record its working takeaway title, the point it must establish, and the evidence or data that supports it with its supplied or verified source. Mark forecasts, targets, assumptions, and slides that need no evidence.
- Review the complete outline for narrative flow, duplicated claims, missing evidence, and a deliberate opening and ending. Choose the slide count from the content.
- Treat the completed outline as the content contract for implementation, not as a layout schema. Keep layouts and motifs out of it, keep it out of audience-facing HTML unless requested, and update it first when a slide's title, communication job, or evidence changes materially.

## 3. Load the local identity

- Read [design-system.md](design-system.md) completely before writing any HTML, for the
  colour tokens, the type scale, the radius scale and the `Never do this` list.
- Read [layouts/README.md](layouts/README.md). It carries the sizing law, the
  ruled-versus-filled pairs, and the box-sizing rules that decide whether a deck looks
  built or assembled.
- Read [decoration/PLACEMENT.md](decoration/PLACEMENT.md) and copy the optional,
  textless ornament markup from [decoration/decoration.html](decoration/decoration.html).
  Crayon has no genuine item-set decorations: its badges, burst figures, nodes, and
  connectors are content or layout structure and remain in the layouts. **Copy the
  decoration snippets. Do not
  paraphrase them, redraw them, simplify them, or substitute a shape you find easier to
  write.** Change only size, position, colour token, and text content.
- Read [composition-recipes.html](composition-recipes.html) before laying out a slide
  whose content is a table, a list of records, or repeated rows. A column holding
  identifiers, codes, or numbers takes the width its content needs and never wraps; only
  the prose column absorbs the slack.
- Use a valid prompt `color-system` when supplied. Otherwise select one of the
  **preferred tokens** named in `design-system.md`. Load exactly one
  `color-systems/<token>.css` and inline its CSS in the final HTML.

**Order of priority when two of these pull against each other:**

1. the content is accurate and complete against the supplied material;
2. every slide is legible at presentation size;
3. the template's identity is intact — marker-highlighted titles, blobs, sparks, chrome;
4. every optional ornament and content device follows its documented role and placement.

Decoration never wins against 1 or 2. It must not displace content, shrink copy, drop a
point from a slide, or invent something to fill a slot. A deck that is accurate but
visually anonymous also fails.

## 4. Pick a layout per slide

Choose by what the slide has to do, then copy that file's structure.

| the slide is                                      | layout                                                           |
| ------------------------------------------------- | ---------------------------------------------------------------- |
| the opening                                       | `cover`                                                          |
| an agenda or contents                             | `toc`                                                            |
| a chapter break                                   | `section-divider`, or `section-divider-field` on a colour ground |
| a list of points, ruled                           | `bullets`                                                        |
| a list of points, with numbered badges            | `numbered-list`                                                  |
| a sustained narrative or long-form argument       | `longform`                                                       |
| two blocks of prose                               | `two-column`                                                     |
| three parallel ideas, ruled                       | `three-column`                                                   |
| three or four parallel ideas, filled              | `color-cards`                                                    |
| one decisive statement                            | `big-quote`                                                      |
| several testimonials                              | `quote-cards`                                                    |
| two or three headline figures beside prose        | `stat-highlight`                                                 |
| a row of four figures                             | `kpi-row`                                                        |
| rows of records, codes or metrics                 | `table`                                                          |
| a magnitude comparison                            | `chart-bar`                                                      |
| a trend over time                                 | `chart-line`                                                     |
| a share of a whole                                | `chart-pie`                                                      |
| tiers or packages                                 | `pricing`                                                        |
| stages of a process                               | `process-steps`                                                  |
| dated events                                      | `timeline`                                                       |
| phased plans                                      | `roadmap`                                                        |
| scheduled work across calendar windows            | `gantt`                                                          |
| a hub with branches                               | `mindmap`                                                        |
| a branching flow that later converges             | `flow-diagram`                                                   |
| system layers and dependencies                    | `architecture`                                                   |
| an annotated mechanism in crayon vocabulary       | `sketch-explainer`                                               |
| two things compared, quiet                        | `comparison`                                                     |
| two things compared, loud                         | `versus`                                                         |
| paired benefits and costs                         | `pros-cons`                                                      |
| a challenge, intervention and outcome             | `case-study`                                                     |
| a subject with one picture                        | `image-left` / `image-right`                                     |
| one large image with separate context and caption | `image-hero`                                                     |
| several pictures                                  | `image-grid`                                                     |
| people                                            | `team`                                                           |
| the closing                                       | `close`                                                          |

Vary the register: if the last slide was a row of filled cards, make this one ruled.
`layouts/README.md` lists the ruled/filled pair for each content type.

### Then build the deck

- Produce one standalone HTML file with one live `.deck`. Keep every `.slide` as a direct child, give it one 16:9 `.stage`, and include the deck CSS and keyboard-navigation script once.
- Copy the shell from [layouts/\_shell.html](layouts/_shell.html) verbatim into the single
  `<style>` block and build slides out of its class names. **The safe area is the padding
  on `.fit`, written once: `12cqh 8cqw 8cqh`.** It is recorded as
  `data-safe-area="0.08"`. Do not place a block with
  `margin-left:8%` or size one with
  `width:62cqw`; that is the frozen geometry this split exists to remove.
- Build every slide in three layers: **ground** (stage background, any colour field),
  **decoration** (blobs and sparks, `position:absolute`, `z-index:0`–`2`, free to be
  cropped by the stage edge), and **content** (`.fit` and the text, `z-index:40`).
  Place the decoration first. Decoration added at the end always ends up as an
  afterthought in a corner.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

### Required identity and chrome

Every slide carries all four, or the deck is incomplete. The first two are optional
decoration motifs, the marker is inline typography, and the footer/page number are fixed
chrome; keep those categories separate when counting decoration.

1. Use `peripheral-blob` and `doodle-spark` only for the page roles documented in
   `decoration/PLACEMENT.md`; crop blobs at the stage edge and keep sparks whole.
2. Use a marker-highlight on ordinary titles. On `section-divider-field`, let the title
   inherit the field text colour instead of adding a marker box.
3. **Footer label and page number**: `<div class="kicker" …>Brand · 04</div>` bottom-left
   and `<div class="pagenum">04</div>` bottom-right.

### Images are content choices, not decoration

Use a photograph or other image whenever it communicates the slide more clearly,
credibly, or memorably than text alone. The supplied material does not have to
explicitly request an image; make that editorial choice from the content.

- Choose sources in this order: user-supplied images and visual materials first,
  including media embedded in or linked from the supplied material; then relevant
  imagery from the supplied references and related information; then an AI-generated
  image grounded in the slide's actual subject when it would work better or no suitable
  sourced image exists.
- Never add or generate an image merely to fill an empty region. When no image improves
  the slide, use a non-photographic treatment: a
  colour field, a filled card, a large figure, an ornament, or generous space.
- Every caption, alt text, and label beside an image must come from the material. Never
  invent a caption to justify a picture.
- Every photograph uses a documented template treatment: circles for portraits and
  avatars, `--r-md` for a team row, `--r-lg` for gallery cells, or `--r-xl` for a hero
  image. Never square.
- Use photographs only when the content supports them; zero photographs is valid.

## Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Getting the container right

A percentage bar height resolves against its parent's **definite** height. Break
that chain and the bar computes to exactly `0` — it vanishes while the labels,
values and legend still render, so the page reads as merely empty. Measured on
generated decks: 52 of 558 percentage bars rendered at zero, and one deck spent
455s of gate repair on this alone.

`layouts/chart-*.html` already carries a structure that works. Copy it rather
than inventing lanes. Three rules make the chain definite:

1. **A bar is a direct child of the plot box.** Any level between them needs its
   own definite height, and one that lacks it zeroes everything below.
2. **All columns share one grid, so the label row is shared.** A label that wraps
   to two lines must cost every column the same height, or the bar above it is
   measured against a shorter ruler than its neighbours. Make the plot
   `display:grid; grid-auto-flow:column; grid-auto-columns:1fr` with
   `grid-template-rows:1fr auto …` (one row per item in a column, exactly — a
   spare row pulls the next column's first item into the previous column), and
   give each column wrapper `display:contents`. The markup grouping stays "one
   div per column"; only the rows become shared.

   Measured on the template's own `chart-bar.html`, changing nothing but one
   label to a wrapping name: baseline offset 0 → 19px, and the fourth bar 342 →
   324px — the value never changed, the bar just lost 5%. With the shared grid
   the same label costs all four bars the same 8%, and the ratios stay exact.

3. **Every level is either `flex:none` or `flex:1`** — sized by its content, or
   taking the remainder. There is no third kind.

4. **A value label never shares the lane with the bar it labels.** If it does,
   flex has to fit label + gap + bar into the lane, so it shrinks the bar — and
   only the bars tall enough to run out of room. The scale stops being linear at
   the top: measured on `bloom/chart-bar.html`, lane 336px, label 19px, gap 6px,
   every value above 92.5% rendered at the same 310px, so **96 and 100 drew
   identically**. Under the template's own "percentages of the tallest value"
   convention the tallest bar is always 100%, so this fires on every chart.
   Reserve the label row on the lane (`padding-top`, measured once per template)
   and set both children `flex:none`; the bar then resolves against the lane
   minus that reserve, the same reserve for every column.

Grouping two bars per category still obeys this, but the group wrapper needs
`align-self:stretch`, or it is sized by content and the lane inside it collapses.

Do not "fix" a flat chart by enlarging the numbers or switching to a table. The
values are right; the container chain is not.

## How full a page should be

Measured across all 902 layouts in the 23 shared templates, so this is what the
system already does — not a target invented for the occasion:

|                                                                                  | p25 |  median | p75 |
| -------------------------------------------------------------------------------- | --: | ------: | --: |
| vertical coverage (share of the stage height that carries ink or a filled block) | 33% | **43%** | 61% |
| ink area (share of the stage area)                                               |  9% | **12%** | 16% |
| lowest ink (how far down the page the content reaches)                           | 68% | **75%** | 90% |

**Aim for the middle column.** A content page that stops at 40% of the height and
leaves the rest blank reads as unfinished; one that runs past 25% ink area reads as
a wall. Both are allowed when the material calls for it — a statement page is one
huge line at 6% coverage, a table or a longform page is legitimately dense — but
neither is the default.

Two things that are **not** the same:

- **A void at the bottom.** Content stops early and nothing follows. This is the
  one to avoid; measured on the naked layouts, 73 of 902 pages do it.
- **Air between blocks.** A title, then a band of columns centred in the space
  below it. That is composition, not a defect — do not fill it just to fill it.

If the material genuinely does not fill the page, cut a column or merge the page
into its neighbour rather than padding sentences.

## 5. Verify before delivery

### Automated advisory check

- After fonts and images settle, run `tools/run.sh` once at 1600×900; rerun only when
  the HTML changes.
- The report is the visual review, so there is no need to take screenshots, create
  contact sheets, run image recognition, or visually review slides unless the user
  explicitly asks. It measures overflow, safe area, chrome band, column alignment,
  contrast, underfill, ornament vocabulary, empty photocells, text collisions, and deck
  navigation.
- Every reported item is a recommendation, never a blocker: fix the ones worth fixing
  from the slide, element, and DOM values it names; a zero report is not required.

### Reported checks

The single report lists these fields:

`overflow` · `outsideSafeArea` · `lowContrast` · `columnsMisaligned` · `aboveChromeBand` ·
`boxesUnderfilledV` · `boxesUnderfilledH` · `boxesOnFullBleed` · `darkPanels`

Plus, by inspection:

- every optional motif follows the page-role and placement rules in `PLACEMENT.md`
- blobs are cropped by the stage edge and sparks are not cropped
- ordinary titles carry a marker-highlight; `section-divider-field` does not
- `--surface` appears zero times
- a content-device set is all-or-nothing: every peer item carries the device, or none do

### Search the finished HTML for each of these and remove every hit

- a title in one flat colour with no marker highlight, except `section-divider-field`
- `var(--surface)` anywhere
- a `<circle>` or `<ellipse>` standing in for a blob path
- a `stat-highlight` figure in a plain box instead of a burst-star (`kpi-row` is the
  deliberate unboxed numerical treatment)
- disc or dot list bullets, including a literal `•`
- a square-cornered photograph
- a drop shadow
- a slide missing its footer label or page number
- fewer than three visible hues in the deck
- `.mono`, `.panel`, `.gridpaper`, `.mat` or `.track` — these class names appear in older
  guidance but are **not defined** in this template's shell

## Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
