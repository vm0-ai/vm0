# Crayon

## Visual identity

A white ground with buoyant, handmade energy. Coloured words, marker highlights, organic edge shapes, and doodled sparks create a lively rhythm.

## Color system tokens

Before generating, read `color-system` from the prompt. If the prompt provides one of the valid tokens below, use it exactly. If it does not, select a token according to the content, audience, mood, information density, and readability. Use only one token throughout a deck.

The presentation category documented for this template is **V (multicolour)** and its example token is `prism`; determine the generation token using the rule above.

Valid tokens are limited to the following snake_case values:

- Single-primary M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`prism`, `carnival`, `pop_art`, `bauhaus_primary`, `citrus_fresh`

The default color system used in `example/reference.jpg` is `prism`.
Crayon needs at least three distinct bright hues at once for its coloured words, blobs and marker highlights. A single-primary muted token cannot express it and must not be chosen by default.


After selecting a token, read `color-systems/<token>.css`, inline its only CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="prism" data-safe-area="0.08">
```

- Use `--bg`, `--ink`, `--soft`, and `--ph` for the page, body copy, secondary text,
  and image placeholders. Do not use `--surface`: on the reference `prism` system it
  is `#F7F7FA` on a `#FFFFFF` page (1.04:1), and the reference uses it zero times.
- `--accent`, `--s1`, `--s2`, and `--s3` are source hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected by v1 for those source hues; use them for large icons or decorative symbols. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text. On an `--ink` colour field, use `--kad` for accent text. When a source hue needs stronger text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour blocks containing text, use `--g0` through `--g3` and pair the text with the corresponding `--t0` through `--t3`.
- HTML/CSS components must reference colours only through `var(--...)`; derive transparency, strokes, shadows, and gradients from defined tokens as well.

Use `--bg` as the ground throughout the deck. Use the four source hues for edge blobs and graphics; use `--ka` / `--k1` / `--k2` / `--k3` for coloured title words, and pair `--g0` / `--t0` through `--g3` / `--t3` for marker treatments.

```css
.slide { background: var(--bg); color: var(--ink); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Fredoka` as the display typeface and `Quicksand` as the body typeface.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;500;600&family=Quicksand:wght@400;500;600;700&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Fredoka";
  --fb: "Quicksand";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600; available body weights are 400 / 500 / 600 / 700. Use `--fd` for titles, hero numbers, and section numbers. Use `--fb` for body copy, labels, chart annotations, and tables. For CJK text, preserve the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the template's own base stylesheet. Copy it verbatim into the single
`<style>` block, immediately after the inlined colour-system CSS, before writing
any slide. It defines the 16:9 stage, the type scale, fixed chrome
(`.kicker`, `.pagenum`), and content/layout helpers (`.dot`, `.badge`, `.tile`,
`.card`) that the rest of this document refers to. Optional decoration is copied
from `decoration/decoration.html`. A deck that invents its own class
names instead of using these will not look like this template.

The radius scale below is the one measured in the reference and is part of the
template's character. This block is the same shell as `layouts/_shell.html`; keep the
two in sync. The 8% horizontal safe area is the modal reference text edge and is set
once on `.fit`.

```css
:root{
  --r-xs: .5cqw;
  --r-sm: .9cqw;
  --r-md: 1.7cqw;
  --r-lg: 3cqw;
  --r-xl: 5cqw;
  --r-pill: 999px;
  --r-round: 50%;
  --fd: "Fredoka";
  --fb: "Quicksand";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);overflow-wrap:break-word;word-break:normal;}
.stage *{overflow-wrap:break-word !important;word-break:normal !important;}
/* The safe area, written once. Every layout inherits it; no layout writes a width. */
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;
  display:flex;flex-direction:column;align-items:stretch;padding:12cqh 8cqw 8cqh;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:45;}

/* Identity helpers. Sized in em so they scale with their own type and cannot
   freeze a text box the way a cqw width does. */
.marker{display:inline-block;background:var(--g1);color:var(--t1);
  border-radius:.9em .7em .8em .6em / .7em .9em .6em .8em;
  padding:0 .3em;margin:0 .04em;transform:rotate(-1.6deg);}
.badge{display:inline-flex;align-items:center;justify-content:center;flex:none;
  width:2.4em;height:2.4em;border-radius:var(--r-md);
  font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;}
.tile{display:inline-flex;align-items:center;justify-content:center;flex:none;
  width:2.4em;height:2.4em;border-radius:var(--r-md);}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.card{border-radius:var(--r-lg);}
.dot{border-radius:50%;}
.rule{height:1px;background:color-mix(in srgb,var(--ink) 14%,transparent);}
.rule-on{height:1px;background:currentColor;opacity:.25;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
```

`badge` and `tile` are sized in `em` because they can carry a figure. Do not replace
those dimensions with `cqw`, `cqh`, `px`, `vw`, or `vh`: a container/viewport-sized
box holding text violates the sizing rule and freezes the placeholder geometry.


## Signature elements

The identity spans distinct classes that must not be conflated. Only the textless
`peripheral-blob` and `doodle-spark` are optional decoration. Marker highlights are
inline typography; burst-stars, pill-tags, photographs, badges, nodes, and connectors
carry content or layout structure; footer labels and page numbers are fixed chrome.
A deck that drops the role-appropriate identity is generic, but those classes stay
separate in decoration counts and audits.

Each element below is given as exact markup. Copy the snippet, keep its geometry
and its `var(--...)` colours, and change only size, position, and text content.
The listed counts describe reference usage; they are not minimums or delivery
quotas. Use only the elements supported by the closest reference page role.

## Element reference patterns

These counts describe how a 13–15 slide reference deck uses the named elements.
They help reveal the template's rhythm, but are neither floors nor a request to
fill every page. More ornament is not more fidelity: past a point it costs
legibility, which costs more than the ornament was worth.

| Element | Class | Reference count per 13–15 slide deck | Note |
| --- | --- | --- | --- |
| `peripheral-blob` | optional decoration | 39 (2.6 / slide) | at least two per slide, different hues, all 39 cropped by the edge |
| `marker-highlight` | inline typography | 17 (1.13 / slide) | present on all 15 titles |
| `doodle-spark` | optional decoration | 16 (1.07 / slide) | at least one per slide; nine observed rotations |
| `burst-star` | content device | 3, all on one slide | one per figure on the reference stat-highlight; fills all different |
| `pill-tag` | labelled content device | 3, on three slides | cover, agenda and gallery; no more than one per slide |
| `circle-photo` | media content | only what the material supports | never generate one to hit a number |
| `full-stage colour field` | layout ground | 0 | optional alternate layout, never a requirement |

Do not scale these counts mechanically for a longer or shorter deck. Rows that
say *only what the material supports* are content, not decoration: see the
photograph rule in `SKILL.md`. Use the table to check identity and page-role
rhythm, not to decide how many elements to add.

### 1. `peripheral-blobs` — the organic edge shapes

Large hand-drawn blobs in the supporting hues, pushed off the stage so the edge
crops them. They sit behind everything and give the white ground its playful
energy. The path data is irregular on purpose — do not replace it with a circle
or an ellipse.

**Reference use: every slide carries at least two blobs, in different hues, anchored to
different corners.** Width `26cqw`–`50cqw`, `z-index:0`, always partly outside
the stage.

```html
<div data-bigcircle="1" style="position:absolute;left:-14cqw;top:-16cqh;width:34cqw;height:34cqw;z-index:0">
  <svg viewBox="0 0 100 100" style="width:100%;height:100%;display:block">
    <path d="M 96.9 50.0 C 96.4 59.3 84.2 70.7 76.4 76.4 C 68.6 82.1 58.5 84.4 50.0 84.1 C 41.5 83.8 32.9 80.2 25.5 74.5 C 18.1 68.8 6.3 59.1 5.4 50.0 C 4.5 40.9 12.7 24.3 20.2 20.2 C 27.6 16.0 40.1 24.8 50.0 24.9 C 59.9 25.0 71.6 16.4 79.4 20.6 C 87.2 24.8 97.4 40.7 96.9 50.0 Z" fill="var(--s2)"/>
  </svg>
</div>
```

A second, differently-shaped blob for variety:

```html
<div data-bigcircle="1" style="position:absolute;right:-18cqw;top:-12cqh;width:44cqw;height:44cqw;opacity:.92;z-index:0">
  <svg viewBox="0 0 100 100" style="width:100%;height:100%;display:block">
    <path d="M 83.5 50.0 C 83.8 57.9 80.2 67.7 74.6 74.6 C 69.0 81.5 59.4 90.2 50.0 91.4 C 40.6 92.7 22.6 89.0 17.9 82.1 C 13.3 75.2 20.9 59.4 22.1 50.0 C 23.4 40.6 20.8 34.1 25.5 25.5 C 30.1 16.8 42.1 -2.2 50.0 -1.9 C 57.9 -1.7 67.3 18.4 72.9 27.1 C 78.5 35.7 83.3 42.1 83.5 50.0 Z" fill="var(--s3)"/>
  </svg>
</div>
```

### 2. `marker-highlight` + `multi-colour-title` — the coloured words

On every reference role, titles are never one flat colour. Individual words are
lifted out: some recoloured, some wrapped in a wobbly marker highlight with an uneven
border radius and a slight rotation. The optional full-stage field is the measured
exception documented under Required identity and chrome.

**Reference use: every title in the deck (`.display`, `.h1`, `.h2`) has at least one
marker-highlighted word, and no title is a single flat colour.** Rotate the
highlight hue through `--g1`, `--g2`, `--g3` across the deck.

```html
<h1 class="display" style="font-size:8.6cqw;line-height:1.02">
  <span style="color:var(--ink)">Where</span>
  <span style="display:inline-block;background:var(--g2);color:var(--t2);
               border-radius:.9em .7em .8em .6em / .7em .9em .6em .8em;
               padding:0 .3em;margin:0 .04em;transform:rotate(-1.6deg)">play</span>
  <span style="color:var(--ink)">becomes</span>
  <span style="display:inline-block;background:var(--g1);color:var(--t1);
               border-radius:.9em .7em .8em .6em / .7em .9em .6em .8em;
               padding:0 .3em;margin:0 .04em;transform:rotate(-1.6deg)">Wonder</span>
</h1>
```

### 3. `doodle-sparks` — the three slanted strokes

Three short parallel rounded strokes, like a hand-drawn motion mark. Rotate the
whole group so no two sparks on a slide sit at the same angle.

**Reference use: at least one spark on every slide; at least four different rotations
across the deck.** Width `4cqw`–`7cqw`.

```html
<div data-doodle="1" data-deco-small="1" style="position:absolute;left:6cqw;bottom:26cqh;width:6cqw;height:6cqw;z-index:2">
  <svg viewBox="0 0 100 100" style="width:100%;height:100%;display:block;overflow:visible">
    <g transform="rotate(40 50 50)">
      <line x1="30" y1="64" x2="44" y2="34" stroke="var(--s1)" stroke-width="7" stroke-linecap="round"/>
      <line x1="46" y1="64" x2="60" y2="34" stroke="var(--s1)" stroke-width="7" stroke-linecap="round"/>
      <line x1="62" y1="64" x2="76" y2="34" stroke="var(--s1)" stroke-width="7" stroke-linecap="round"/>
    </g>
  </svg>
</div>
```

### 4. `burst-star` — the spiky figure badge

Statistics live inside spiky stars, not in boxes. Keep the polygon points
exactly as written.

**Reference use: the one stat-highlight slide carries three burst-stars, one per
figure, each a different fill.** Their rendered size is `10cqw`–`14cqw`; because the
shape contains text, encode that size as a ratio to the figure's font size in `em`,
never as a container/viewport width or height.

```html
<div style="position:relative;width:3.57em;height:3.57em;font-size:3.36cqw;display:inline-flex;align-items:center;justify-content:center">
  <svg viewBox="0 0 100 100" style="position:absolute;inset:0;width:100%;height:100%;display:block">
    <polygon points="50.00,1.00 58.01,14.90 71.26,5.85 72.45,21.85 88.31,19.45 82.43,34.38 97.77,39.10 86.00,50.00 97.77,60.90 82.43,65.62 88.31,80.55 72.45,78.15 71.26,94.15 58.01,85.10 50.00,99.00 41.99,85.10 28.74,94.15 27.55,78.15 11.69,80.55 17.57,65.62 2.23,60.90 14.00,50.00 2.23,39.10 17.57,34.38 11.69,19.45 27.55,21.85 28.74,5.85 41.99,14.90" fill="var(--accent)"/>
  </svg>
  <div style="position:relative;text-align:center;line-height:1;font-family:var(--fd),var(--cjk-display);font-weight:600;color:var(--oa)">1.3k</div>
</div>
```

### 5. `pill-tag` — the rounded capsule label

A capsule label, often prefixed with `★`, used for the brand mark and chapter
labels.

**Reference use: exactly three slides carry a pill-tag — the cover, agenda and gallery.
The closing slide carries none.**

**Keep it clear of the title.** Titles in the reference deck start between 10cqh
and 13cqh, so a tag pinned at `top:11cqh` lands on the first line — it carries
text, so that reads as content covering content, not as decoration. Put it above
the title in the kicker band, or in a bottom corner.

```html
<div style="position:absolute;left:8cqw;top:4cqh;background:var(--g0);color:var(--t0);
            padding:.85cqh 1.7cqw;border-radius:var(--r-pill);font-family:var(--fd),var(--cjk-display);
            font-weight:600;font-size:1.2cqw;letter-spacing:.02em;white-space:nowrap;">★ Brightside</div>
```

### 6. `circle-photo` — the round photograph

The reference has 16 image cells: seven circles for portraits/avatars, four `--r-md`
team cells, four `--r-lg` gallery cells, and one `--r-xl` hero cell. These are the
allowed treatments; never square.

Image cells are not a quota. Use a photograph only where the supplied material
describes a subject worth showing. If it describes no such subject, carry no
photograph and let the blobs and marker highlights do the work.

```html
<div style="position:absolute;right:13cqw;bottom:13cqh;width:15cqw;height:15cqw;background:var(--ph);
            border-radius:var(--r-round);overflow:hidden;
            background-size:cover;background-position:center;background-repeat:no-repeat;
            background-image:url('<image>')"></div>
```

## Decoration reference profile (diagnostic only)

Observed from this template's own 15-slide reference deck at 1600×900. The profile
contains only declared, textless, non-content optional decoration.

| optional decoration | per slide | rendered size | crop reading |
| --- | ---: | --- | --- |
| `peripheral-blob` | **2.6** | 22–46cqw | 39 of 39 cropped by the stage edge |
| `doodle-spark` | **1.07** | 5–7cqw | 0 of 16 cropped |

These figures are diagnostics, never quotas. First choose the closest page role in
[layouts/](layouts/), then judge fidelity by motif identity,
placement, and composition. Sparse slides may correctly carry only the reference-wide
minimum identity pass.

Marker typography, pills, burst-stars, badges, nodes, connectors, photographs, cards,
colour fields, content containers, grid cells, and fixed chrome are excluded from this
profile. The reference separately contains **1.6 labelled content boxes per slide** and
**1.1 image cells per slide**; neither rate is a target, and no device or image may be
invented merely to hit it.

**A kicker is not a chip.** In this template's reference deck the `kicker`, the
page number, the running head and the standfirst are plain text — no background,
no border, no shadow, no rounded pill around them. The reference deck is consistent
on this, and giving them a box is the single most common way a generated deck drifts:
a kicker appears on every slide, so boxing it adds one
false chip per slide and doubles this template's labelled-box count on its own.

Only the elements the motif library actually draws as chips — `badge`, `tag`,
`pill`, and whatever else this file shows with a fill — carry a background.
Everything else that is text stays text.

**Before delivering, audit identity.** On three representative slides, verify that every
optional decoration maps to one of the two named motifs and every content device maps to
a specific reference composition. Use the table above only to notice gross whole-deck drift.

Content still comes first. Never push text off the stage, cover it, or drop a point. Never add a photograph
the source material does not support. A slide carrying six bullets may correctly
carry no optional ornament at all.


## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** A label positioned with `left:88cqw` will
overflow the moment its text is longer than the author guessed, and CJK copy is
routinely wider than the Latin draft it was written against. Anchor anything in
the right third with `right:` instead of `left:`, and anything in the bottom
third with `bottom:` instead of `top:`. A block anchored to the edge it is near
grows inward, where there is room, instead of outward into nothing. Give any
absolutely-positioned text an explicit `max-width` so it wraps rather than
extends.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

Both faults hide from a quick glance at the whole deck and are obvious on the
slide itself. Before delivering, look at every slide that carries a set of
things and check that the set is aligned and that nothing touches an edge it was
not meant to touch.

## Required identity and chrome

Every slide carries all four, or the deck is incomplete. Items 1–2 are fixed chrome,
item 3 is optional decoration, and item 4 is inline typography; do not combine them in
decoration statistics.

1. **Footer label**, bottom-left or bottom-right — an uppercase `.kicker` such as
   `Brightside &nbsp;·&nbsp; 04`, using a stable brand word drawn from the deck's subject:
   `<div class="kicker" style="position:absolute;left:8cqw;bottom:3.4cqh;opacity:.65">Brightside · 04</div>`
2. **Page number**, bottom-right: `<div class="pagenum">04</div>` — two digits, zero-padded.
3. **At least two blobs and one doodle-spark.**
4. **A marker-highlight on the title.** The reference reads 15 of 15. The optional
   full-stage field is the only exception: its title inherits the field text colour,
   because adding a marker changes `boxesOnFullBleed` from 0 to 1.

## Background rhythm

The reference uses white/`--bg` on all 15 slides — the blobs supply the colour. A
full-stage colour field is an optional alternate for a big quote or section divider,
not a delivery quota: the reference reading is 0 of 15. When one is supported by the
sequence, pair a `--gN` ground with its matching `--tN` text colour:

```html
<div class="slide"><div class="stage" style="background:var(--g1);color:var(--t1)"> … </div></div>
```

Those colour-field slides still carry blobs, in a contrasting hue.

## Decoration safe area

Decoration is placed before content, but it never fights the content.

- Every slide has a **text safe area**: the region actually occupied by the
  title, body copy, figures, and labels. No decoration may sit on top of it.
- Decoration belongs in one of three places: outside the safe area entirely
  (edges, corners, the empty half of the stage); behind it at `z-index:0`–`1`
  **and** at a contrast low enough that the text stays fully legible; or
  deliberately overlapping a photograph or colour field where the reference
  shows exactly that.
- A large ornament — a wire globe, a big circle, a blob, an oversized sprig —
  must be cropped by the stage edge rather than floated in the middle of the
  composition, unless it carries content itself.
- Never place body copy or a caption directly on top of a photograph unless the
  photograph is a full-bleed field with a text-safe treatment behind the copy.
- After rendering, look at every slide for a decoration that lands on text or
  makes a title hard to read. Move the decoration, not the text.

## Never do this

- Never render a title in one flat colour with no marker highlight, except on the
  optional full-stage field documented above.
- Never replace the blob paths with circles, ellipses, or rounded rectangles.
  The irregularity is the point.
- Never render a `stat-highlight` figure in a plain box. That layout uses burst-stars;
  `kpi-row` is the deliberate unboxed numerical treatment.
- Never use disc/dot list bullets. Use numbered rows with a hairline under each,
  or pill-tags.
- Never use square-cornered photos.
- Never use drop shadows.
- Never let a slide go out without its footer label and page number.
- Never build a deck with fewer than three visible hues; this template needs a
  multicolour token.

## Self-check before delivery

Review identity and page-role fidelity. Fix the deck before
delivery if any line fails.

0. Every optional decoration maps to `peripheral-blob` or `doodle-spark`; every content
   device maps to a specific composition in `layouts/`.
1. Signature elements appear only on the page roles where the reference uses
   them, with clear space and no text collision.
2. Every slide carries the items listed under `Required identity and chrome`.
3. Every photograph follows the documented template treatment and illustrates
   a subject the material describes. Zero photographs is valid.
4. Every prohibition under `Never do this` was checked against the final HTML.
5. Exactly one `data-color-system` token is present and it is preferred.
6. The decoration profile was read only as a gross drift signal.

Visual reference: [example/reference.jpg](example/reference.jpg) —
the rendered proof of every rule above. [layouts/](layouts/)
is the same deck in code; open it when a snippet here needs more context.
