# pixel-glitch — decoration placement

Everything here is measured from the original reference deck — 15 pages, 15 glyphs, 9 small
ornaments, 13 image frames, rendered at 1600×900. Numbers, not taste.

Open [decoration.html](decoration.html) to see each item rendered with no text on the page,
and [item-sets.html](item-sets.html) for the ornaments that attach to repeated items.

**Do not carry bloom's decoration rules over.** They were measured on a different deck and
two of them are the *opposite* of what this template does. The differences are in §B.

## The layer model

A pixel-glitch slide is four independent layers. Build them in this order and they cannot
fight each other:

| z-index | layer | where it comes from |
|---|---|---|
| 1 | the glyph, and any image frame | this folder |
| 6 | page number | the shell |
| 9 | masthead | §A below, identical on every page |
| 40 | `.fit` — all text | `../layouts/*.html` |

The glyph sits **below** text and is never inside `.fit`. If a layout and the glyph collide,
move the glyph — never the copy.

## A · Persistent chrome — identical on every page, 15 of 15

Two items, and they are the reason this template's top band is not empty. Copy verbatim:

- **masthead** at `left:6cqw; right:6cqw; top:5cqh` — a 4-cell pixel logo at `1.9cqw`, the
  wordmark at `1.9cqw/700`, a right-hand label at `1.35cqw/500`, then a `.28cqw` ink rule
  under both. It occupies **5cqh to 11.2cqh**, measured.
- **page number** at `right:3cqw; bottom:3.2cqh`, `1cqw`, `opacity:.65`.

On a full-bleed page both switch to `var(--bg)`, including the four logo cells.

Because the masthead really does live in the top band, `.fit` starts its content at
**16cqh** and nothing else may begin above 12% of stage height. Reference content pages
start at 16–18cqh; dividers and the closing page at 37–45cqh.

## B · One glyph per page — and this is where bloom is backwards

**15 of 15 reference pages carry exactly one `pixel-glyph`. Not two. Never zero.**

    glyphs per page          1.00   (15 / 15 pages)
    pages carrying two        0      (0%)
    pages carrying none       0

bloom's `PLACEMENT.md` §B says to put **two** big ornaments on a content page, because 15
of bloom's 17 pages carry a pair. That rule is true of bloom and false here. Applying it to
pixel-glitch doubles this template's ornament rate against its own reference. One glyph.

Two more places bloom's numbers do not transfer:

- bloom forbids `--surface` outright (its reference uses it 0 times). **This reference uses
  it 4 times in 15 pages** — see §E. It is permitted here.
- bloom's lower third is its decoration zone. **Here it is mostly just empty**: only 3 of 15
  glyphs sit low, and reference content ends at a median of 75.8% of stage height. Do not
  bottom-anchor copy to fill it, and do not assume an ornament is coming to fill it either.

## C · Where the glyph goes

Measured over the 15 reference glyphs:

| | |
|---|---|
| bleeding off the stage edge | **13 of 15 — 86.7%** |
| `data-edge="rt"` top right | 7 |
| `data-edge="rm"` middle right | 5 |
| `data-edge="lb"` lower left | 2 |
| `data-edge="rb"` lower right | 1 |
| `lt` / `lm` | **0 — never used** |

So: the right edge takes 13 of 15. The glyph is anchored to an edge and cropped by it; it
never floats in the middle of the composition. Use the `data-edge` attribute — it already
carries the mirroring and the transform-origin. Do not write your own offsets.

`rt` pairs with `top:12cqh` so the glyph clears the masthead rule.

## D · Which contour, and what colour

All six contours are in rotation; none is a default:

    signal 3   step 3   corner 3   fragments 2   splice 2   bars 2

Rotate them across the deck rather than repeating one. Colour, measured:

| page kind | `--pixel-colour` |
|---|---|
| normal `--bg` page (11 of 15) | cycles `--accent` (4), `--s3` (4), `--s1` (3) |
| full-bleed colour field (4 of 15) | `--bg` — always, on all four |

These are *fills*, so the source hues are correct here. They are wrong on type: see §E.

## E · Colour, measured across all 19 colour systems

This template can be generated with any of 19 colour systems, and the reference was
rendered in only one of them. That is how the following defect hid.

**Text takes `--ka` / `--k1` / `--k2` / `--k3`. Nothing else.** Measured contrast against
each system's own `--bg`, across all 19:

| used as text | fails 3.0:1 in |
|---|---|
| `--s2` | 17 of 19 systems |
| `--s1` | 7 of 19, including `mint_tech` (2.72) |
| `--accent` | 6 of 19, including `mint_tech` (2.51) |
| `--s3` | 4 of 19 |
| `--g0..--g3` | worst case 1.23 |
| **`--ka --k1 --k2 --k3`** | **0 of 19 — never below 3.0** |

The reference's agenda used `--accent` / `--s1` / `--s3` for its index numbers. Under
`bauhaus_primary` those measure 3.82 / 5.21 / 15.42 and pass. Re-render the identical file
under `mint_tech` — a **preferred** token for this template — and the same three numbers
read 2.51 / 2.72 / 9.27, and the probe reports `lowContrast: 3`. The example has been
fixed; this is why.

Source hues stay on fills, rules, glyph colours and chart series. Where a chart legend
needs to key a colour, the colour goes in a filled swatch and the words stay in `--ka`.

Other measured colour facts:

- **`--surface` is permitted, and it is quiet.** 4 uses in 15 pages, all of them the
  icon-cell ground on one page. It is 1.13:1 against `--bg` — a faint panel, not a card.
  Use it where a soft field is wanted; use the `.28cqw` ink border where an edge must read.
- **Large filled panels cycle `--g0 --g1 --g2`.** `--g3` is near-black; at panel size it
  reads as a photo placeholder. The reference's own card sets (quotes, prices) use
  `g0/g1/g2` and never `g3`. `--ink` and `--g3` ground only small squares — tiles, badges,
  nodes — and the full-bleed stage itself.
- **4 of 15 pages are full-bleed colour fields** (27%): three section dividers and the
  closing page. On those, the kicker uses `color:inherit`, never `--ka`.
- **Nothing sits on a full-bleed page.** The reference's four colour-field pages carry no
  boxes at all.

## F · Small ornaments belong to item sets, not to sprinkling

Measured: 0.6 small ornaments per page, and they are not scattered. They are the device of
one page type — a set of 3–4 peer items — and on those pages **every item gets one**.

| the items are | ornament | size | colour |
|---|---|---|---|
| capabilities, services, categories | `tile` | `--sz:5cqw` square | ground cycles `--g0..--g3`, icon `--t0..--t3` |
| ordered stages | `node` + one `connector` | `6cqw` square, hard ink border | `--ink` ground, `--bg` mark; connector `.55cqh` at `z-index:0` |
| numbered rows | `badge` | `--sz:5cqw` square, hard ink border | ground cycles `--g0..--g2`, figure in `--t?` |
| peer items that are themselves paragraphs | **nothing** | | separate them with the hairline the layout already has |

Copyable markup is in [item-sets.html](item-sets.html), not in this sentence. bloom
regressed its small ornaments from 0.214 to 0.022 per page (p=0.0043) by describing them in
prose instead of shipping the markup.

Size these with `--sz`, never `width`/`height` — the figure inside a `badge` is measured
against the badge's own width, so a box sized any other way renders a small number in a
large frame.

## G · A kicker is not a chip

Measured: **0.27 labelled boxes per page** — three numbered badges and one "Most popular"
pill, in 15 pages. That is the entire budget.

The kicker, the page number, the running head and the standfirst are plain text on every
one of the 15 pages: no background, no border, no pill. A kicker appears on every slide, so
boxing it adds one false chip per page and quadruples this template's chip count on its own.

## H · Image frames are content

13 image frames in 15 pages (0.87 per page), but that is not a target. `photocell` is the
frame itself; when the material supports no picture, **delete the frame** rather than
leaving an empty box. A text-only source is right to draw none.

The frame is `--ph` with a `.28cqw solid var(--ink)` border — the hard outline is the
template's, and a borderless grey rectangle is not this template.

## I · Reference audit contract

The reference deck produces this diagnostic column:

    glyphs per page                reference 1.00      (never 0, never 2)
    pages carrying two glyphs      reference 0
    bleeding glyphs                reference 86.7%
    small ornaments per page       reference 0.60
    labelled boxes per page        reference 0.27
    hairline rules per page        reference 2.67
    image frames per page          reference 0.87      (0 is correct for a text-only source)
    full-bleed pages               reference 27%
    uses of --surface              reference 4 in 15 pages

and these, which must read exactly 0 — the reference does:

    overflow · outsideSafeArea · aboveChromeBand · lowContrast
    darkPanels · boxesUnderfilledV · boxesUnderfilledH · boxesOnFullBleed
    offVocabularyShapes · orphanSlides · indirectSlides

plus `decks` = 1 and `navigableSlides` = the deck's page count. Arrow-key input must
change the active slide, so rendered pages remain reachable through the live runtime.
