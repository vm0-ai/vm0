# pixel-glitch — naked layouts

43 layouts, text only. No glyph, no chrome, no measured geometry. Pair one of these with
[../decoration/PLACEMENT.md](../decoration/PLACEMENT.md) to build a slide.

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions. Not a slide.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 43: zero `width` / `max-width` / `min-width` / `height` / `left` / `top` /
`right` / `bottom` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex-basis`. A number gutter written `flex:0 0 4cqw` freezes exactly the way a
`width` does.

Four exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`, like the chrome or the "most popular" flag. That is where it goes,
  not how big it is.
- **`height:1px`** for a hairline.
- **`em`** on marks that contain no prose — a legend swatch, a timeline tick, a number
  gutter. `em` scales with the type around it and cannot freeze a text box.
- **`%`** where the number *is* the datum: bar heights in `chart-bar`, the dash array in
  `ring-grid`. A bar at 61% is reporting 61.

Everything else stretches. Columns are `flex:1`. The safe area is set once, by the padding
on `.fit` — `16cqh 6cqw 8cqh`, or `16cqh 6cqw 24cqh` on the three full-bleed page types.

The 16cqh top is not arbitrary: the masthead occupies 5cqh to 11.2cqh, measured, and
reference content pages start at 16–18cqh.

This matters because the original reference deck was produced by measuring a rendered deck and writing
the numbers back — `width:54%`, `height:52.41cqh`, `min-height:41.72cqh` are observations of
one string at one font size, not design decisions. Copying them reproduces that string.
These carry none.

Any flex child holding an SVG or a percentage-height bar needs `min-height:0`, or the SVG's
intrinsic aspect ratio pushes the box past the stage edge.

## Files

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `statement` `long-form` `key-points` `two-column` `three-column` `color-cards`
`numbered-list` `big-quote`

**Numbers** · `kpi-grid` `kpi-cards` `stat-highlight` `ring-grid` `chart-bar` `chart-line`
`chart-area` `chart-donut` `chart-scatter` `benchmark-scorecard` `table`

**Time and sequence** · `process-steps` `timeline` `roadmap` `gantt`

**Two things compared** · `comparison` `versus` `pros-cons`

**Imagery and people** · `image-left` `image-right` `image-grid` `image-hero` `team-grid`

**Card sets** · `icon-cards` `quote-cards` `price-cards`

**Structure** · `flow-diagram` `architecture` `mind-map`

**Evidence and scene-specific** · `case-study` `release-notes` `benchmark-scorecard`

## Coverage inventory

Every filename names one communication job. The inventory below is the coverage check;
rows are not aliases for one another.

| layout | independent purpose |
|---|---|
| `cover` | open the deck with title, premise and identity |
| `toc` | orient the audience to the sequence |
| `section-divider` | announce a new chapter on a full colour field |
| `close` | end with a memorable sign-off and contact |
| `statement` | land one authored thesis without supporting structure |
| `long-form` | sustain an editorial argument across several paragraphs |
| `key-points` | present unordered takeaways without default disc bullets |
| `two-column` | pair one concept with one proof or example |
| `three-column` | give three peer arguments a quiet ruled treatment |
| `color-cards` | give three peer arguments a filled treatment |
| `numbered-list` | show an ordered set where sequence matters |
| `big-quote` | foreground one sourced voice or quotation |
| `kpi-grid` | compare a ruled row of metrics |
| `kpi-cards` | compare a filled row of metrics |
| `stat-highlight` | make one dominant figure the entire takeaway |
| `ring-grid` | compare several independent percentages |
| `chart-bar` | compare discrete values over ordered periods |
| `chart-line` | compare one or more trends over time |
| `chart-area` | show cumulative magnitude changing over time |
| `chart-donut` | explain the composition of one whole |
| `chart-scatter` | show a relationship between two measures |
| `benchmark-scorecard` | evaluate a creative-technology system across criteria |
| `table` | present record-level evidence with aligned fields |
| `process-steps` | explain the ordered stages of a method |
| `timeline` | place dated events in historical sequence |
| `roadmap` | distribute priorities across now, next and later horizons |
| `gantt` | show task duration and overlap on a fixed schedule |
| `comparison` | contrast before and after in a quiet register |
| `versus` | force a high-stakes choice between two routes |
| `pros-cons` | balance benefits against costs or risks |
| `image-left` | place evidence imagery before its explanation |
| `image-right` | place explanation before its evidence imagery |
| `image-grid` | survey several images as one body of work |
| `image-hero` | give one supported image maximum visual priority |
| `team-grid` | introduce people with consistent role metadata |
| `icon-cards` | catalogue services or capabilities |
| `quote-cards` | compare several testimonials or sourced voices |
| `price-cards` | compare packages, tiers or commercial options |
| `flow-diagram` | trace a linear system from input to output |
| `architecture` | explain a technical system as dependency layers |
| `mind-map` | branch several themes from one central idea |
| `case-study` | connect a challenge and intervention to measured outcomes |
| `release-notes` | communicate a game or product version update |

## Where the set came from

17 of the 43 are compositions this template already demonstrates: every page role in
`../layouts/` (cover, agenda, divider, prose-with-image, numbered list, team
grid, icon cards, process, portfolio grid, ring charts, quote cards, price cards, close)
plus the three packets in `../composition-recipes.html` (`big-quote`, `versus`, `table`).
Those are non-negotiable — they are the compositions the template actually knows.

The next 13 are gaps a real deck hits and this template originally had no answer for: a plain two- or
three-column prose page, a row of numbers in either register, one dominant statistic, a bar
chart, a line chart, a dated timeline, a pros-and-cons split, a mirrored image page, a
full-width image, and a flow of hard-outlined boxes. A second coverage audit added 13
further jobs that were still absent: a single thesis, long-form reading, unordered key
points without default bullets, area/composition/relationship charts, product roadmap,
Gantt schedule, layered architecture, radial idea map, case-study evidence, and two
scene-specific pages for creative technology and gaming (`benchmark-scorecard`,
`release-notes`). Each communicates a different relationship; none is a renamed copy of
an existing composition.

Each is written in this template's own vocabulary — square corners, `.28cqw` ink rules and
borders, the offset accent shadow — not imported from another design language. There is no
terminal, no code block, no call-to-action button, no rounded anything: `--r-xs` through
`--r-xl` are all forced to `0`, so a rounded shape is by construction not from here.

## Which ornament attaches to which layout

The layouts are naked on purpose, but several describe a **set of peer items**, and on those
pages every item carries a mark. Copyable markup is in
[../decoration/item-sets.html](../decoration/item-sets.html).

| layout | attach |
|---|---|
| `icon-cards` `three-column` | one `tile` per item, ground cycling `--g0..--g3` |
| `process-steps` `flow-diagram` | one `node` per stage + one `connector` |
| `numbered-list` | one `badge` per row, ground cycling `--g0..--g2` |
| `two-column` `comparison` `table` `pros-cons` `timeline` `long-form` `key-points` `roadmap` `gantt` `architecture` `mind-map` `case-study` `release-notes` `benchmark-scorecard` | nothing — these hold prose or data, use the rules already in them |
| `color-cards` `kpi-cards` `quote-cards` `price-cards` | nothing — the fill *is* the mark |

Every layout also takes exactly **one** `pixel-glyph` and the persistent chrome. One, not
two — see `PLACEMENT.md` §B, where this template and bloom point in opposite directions.

## Ruled or filled — every peer row has both

The reference separates items with a hairline 2.67 times per page. Left as the only option
that becomes the same horizontal line on every slide, so each peer-row content type has two
treatments and neither is more on-template:

| content | ruled | filled |
|---|---|---|
| three peer points | `three-column` | `color-cards` |
| a row of numbers | `kpi-grid` | `kpi-cards` |
| two things compared | `comparison` | `versus` |
| a set of short items | `numbered-list` | `icon-cards` |

The filled versions cycle `--g0 --g1 --g2` so neighbours never share a colour. `--g3` is
near-black and is not a panel colour here — at panel size it reads as a photo placeholder.
The reference's own card sets use `g0/g1/g2` and never `g3`.

## A filled box is sized by its content, never by the stage

```
height  row     flex:none        — from the tallest child, not the stage
        child   flex:1           — every sibling matches that tallest child
        group   wrapped in flex:1;min-height:0;justify-content:center

width   box     align-self:flex-start; max-width:100%
        row     flex:1 peers divide the safe area
```

`.fit` is a column flex with `align-items:stretch`, so every child is full-width by default.
`flex:1` on the **row** and `flex:1` on the **child** look like the same instruction and do
opposite things: on the row it fills the stage and the cards inherit the stage's height, so
you get a slab of colour that is half empty.

Stress-tested on all 43: an extra sentence injected into the first item of every detected
content peer row leaves sibling heights differing by **0px** across all 25 rows exercised.
Chart marks and unequal-role structures such as a hub with branch stacks are excluded.

## The lower fifth is usually just empty

Reference content ends at a median of **75.8%** of stage height, and only 3 of 15 glyphs sit
low. Unlike bloom, this template's lower third is not a decoration zone with something
coming to fill it — it is margin. Do not bottom-anchor a trailing line to reach it: that
leaves a void above the line and drops the line into the one place a `lb` glyph does go.
`section-divider`, `close` and `stat-highlight` therefore carry `24cqh` of bottom padding,
which lands their titles at 76–79%, matching the reference's 73.7–75.8%.

## Colour

Text is `--ka` / `--k1` / `--k2` / `--k3` and nothing else. Measured across all 19 colour
systems this template can be generated with, those four never fall below 3.0:1 against the
page; `--accent` fails in 6 systems and `--s1` in 7, both including `mint_tech`, which is one
of this template's **preferred** tokens. The source hues are for fills, rules, glyph colours
and chart series. A chart legend keys its colour with a filled swatch and keeps the words in
`--ka`. Full details and the positive control are in `../decoration/PLACEMENT.md` §E.

`--surface` is permitted here — the reference uses it 4 times in 15 pages as the icon-cell
ground — but it is 1.13:1 against `--bg`, a faint field rather than a card. Where an edge
must read, use the `.28cqw` ink border.

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` · structure `stage fit deck slide
band card tile badge` · marks `dot tick soft dim pagenum glitch`.

Sizes live in those classes. If something needs to be bigger, use the next class up rather
than writing a `font-size`. `.glitch` is the RGB title split and belongs on display type
only.

## Verified

- static sizing audit: **0** across all 43
- `probes/run.sh` on all 43: `overflow` `outsideSafeArea` `aboveChromeBand`
  `lowContrast` `darkPanels` `boxesUnderfilledV` `boxesUnderfilledH`
  `boxesOnFullBleed` `offVocabularyShapes` `orphanSlides` `indirectSlides` all **0**,
  `decks` 1, `navigableSlides` = page count
- equal-height stress test: sibling spread **0px** on all 25 content peer rows
- every layout rendered at 1600×900 and looked at, with the colour system confirmed loaded
  (`.stage` computes to `rgb(245,241,230)`, not the unstyled default)
