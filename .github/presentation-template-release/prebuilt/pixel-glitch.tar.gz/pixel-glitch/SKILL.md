---
name: pixel-glitch
description: Create a standalone 16:9 HTML presentation deck with the Pixel Glitch visual identity and direct-HTML workflow. Use when the user selects the Pixel Glitch presentation template or explicitly names pixel-glitch as the deck style. Best suited to Y2K pixel stories for gaming, music, creative technology, and internet culture.
---

# Pixel Glitch presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one standalone HTML file with one live `.deck`.
- **Every `.slide` must be a direct child of that `.deck`.** The navigation runtime
  collects pages with `[...deck.children].filter(n => n.classList.contains('slide'))`, so a
  slide nested one level deeper renders perfectly, scrolls perfectly, screenshots perfectly
  and is unreachable by keyboard. Give each slide one 16:9 `.stage`, and include the deck CSS and
  keyboard-navigation script once.
- Before delivering, count them:
  `document.querySelectorAll('.slide').length` must equal
  `[...document.querySelector('.deck').children].filter(n => n.classList.contains('slide')).length`.
  The final QA hard gate dispatches the keys and verifies the live state; do not repeat
  that check manually.
- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Create one direct-child `.slide` per planned page and one 16:9 `.stage` inside each slide.

### Layout — start from a canonical layout

For each slide, pick the layout in [layouts/](layouts/) whose name matches what the slide
has to do, and adapt it. Read [layouts/README.md](layouts/README.md) for the index, the
sizing rule and the ruled/filled pairs. The 43 files are text only, so what you copy is the
structure and nothing else.

| the slide is                                | use                                                                   |
| ------------------------------------------- | --------------------------------------------------------------------- |
| the title page                              | `cover`                                                               |
| an agenda or contents                       | `toc`                                                                 |
| a section break                             | `section-divider` (full-bleed colour field)                           |
| the closing page                            | `close`                                                               |
| a concept beside its example                | `two-column`                                                          |
| three peer points                           | `three-column` (ruled) · `color-cards` (filled)                       |
| an ordered set of points                    | `numbered-list`                                                       |
| one thesis that must land                   | `statement`                                                           |
| an editorial argument with sustained prose  | `long-form`                                                           |
| unordered key points                        | `key-points` (never default disc bullets)                             |
| one sentence that must land                 | `big-quote`                                                           |
| a row of metrics                            | `kpi-grid` (ruled) · `kpi-cards` (filled)                             |
| one dominant statistic                      | `stat-highlight` (full-bleed)                                         |
| several percentages                         | `ring-grid`                                                           |
| a series over time                          | `chart-bar` · `chart-line` · `chart-area`                             |
| composition of one whole                    | `chart-donut`                                                         |
| relationship between two measures           | `chart-scatter`                                                       |
| tabular evidence                            | `table`                                                               |
| stages of a method                          | `process-steps`                                                       |
| dated events                                | `timeline`                                                            |
| now / next / later priorities               | `roadmap`                                                             |
| scheduled work with duration                | `gantt`                                                               |
| two things compared                         | `comparison` (quiet) · `versus` (hard frame, diagonal, offset shadow) |
| what it buys and what it costs              | `pros-cons`                                                           |
| a system end to end                         | `flow-diagram`                                                        |
| a layered technical system                  | `architecture`                                                        |
| one idea branching into themes              | `mind-map`                                                            |
| copy beside a picture                       | `image-left` · `image-right`                                          |
| several pictures                            | `image-grid` · `image-hero`                                           |
| people                                      | `team-grid`                                                           |
| services or capabilities                    | `icon-cards`                                                          |
| testimonials                                | `quote-cards`                                                         |
| packages or tiers                           | `price-cards`                                                         |
| challenge, intervention and measured result | `case-study`                                                          |
| a game or product version update            | `release-notes`                                                       |
| a creative-technology evaluation            | `benchmark-scorecard`                                                 |

Then add the `pixel-glyph` treatment and persistent chrome documented for that page role
in [decoration/PLACEMENT.md](decoration/PLACEMENT.md).

When a layout describes a set of peer items, attach the matching mark from
[decoration/item-sets.html](decoration/item-sets.html) — copy that markup rather than
inventing a shape.

### Recommended layout approach

- Recommended starting point: use a clear top-to-bottom or left-to-right Grid/Flex relationship. Aim to balance the visual weight of its regions and place each primary content group near the optical center of its own region. A left-to-right composition can vertically center the groups on each side; a top-to-bottom composition can center groups within balanced bands. Adapt alignment and asymmetry to the content and the template's visual character.
- Use a `data-layout` container with CSS Grid or Flexbox for the primary spatial relationship when it helps the composition remain stable. Keep content groups in normal flow where appropriate, and use absolute positioning when an element's meaning or visual role depends on layering. Adapt proportions, nesting, and positioning to each slide's communication job.
- Preserve the template's original visual character from `design-system.md` and the examples. Compose content and signature elements together according to their visual and semantic roles, whether they belong inside the main layout or on a separate layer.
- Review all regions and layers as one composition. Aim for readable balance, allowing intentional overlap and out-of-flow placement when they strengthen hierarchy, meaning, or the template's signature style.
- Treat every slide as a projected presentation canvas. Write concise visible copy for the audience and keep one clear hierarchy of title, supporting content, and evidence on each page.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

- Read [design-system.md](design-system.md) for the deck shell, motif library, and
  required chrome.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — motifs, background treatment, chrome;
  4. every optional motif follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is accurate but visually anonymous also fails.

- Optional: [example/reference.jpg](example/reference.jpg) for the visual identity and [layouts/](layouts/) for full-slide scale, rhythm, and composition.
- A pixel-glitch slide is **four independent layers**, and this folder keeps them in
  separate places. Build them in this order and they cannot fight each other:

  | z-index | layer                                  | source                                                                                                       |
  | ------- | -------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
  | 1       | one `pixel-glyph`, and any image frame | [decoration/PLACEMENT.md](decoration/PLACEMENT.md), [decoration/decoration.html](decoration/decoration.html) |
  | 6       | page number                            | `layouts/_shell.html`                                                                                        |
  | 9       | masthead                               | `PLACEMENT.md` section A                                                                                     |
  | 40      | all text, inside `.fit`                | [layouts/](layouts/) — 43 naked layouts                                                                      |

  `layouts/` shows all four fused together at full scale. Use it to judge
  rhythm and colour; take **structure** from `layouts/` and **ornament placement** from
  `PLACEMENT.md`.

- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. Its packets carry this template's column, spacing, and chrome behaviour; adapt one rather than inventing table markup, which is where these decks lose content. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- **Text takes `--ka` / `--k1` / `--k2` / `--k3`, and nothing else.** The source hues are for
  fills, rules, glyph colours and chart series. Where a chart legend must key a colour, put
  the colour in a filled swatch and keep the words in `--ka`.
- Use the prompt's `color-system` when supplied, otherwise a preferred token from
  `design-system.md`. Inline that one `color-systems/<token>.css` in the final HTML.

#### Decoration

Decoration is not bound by the safe area: an ornament may cross it and bleed off the
stage where `PLACEMENT.md` says so. The safe area binds type and content.

- Decoration goes outside the region the content occupies — the empty half of
  the stage, the margins, the corners — or behind it at a contrast low enough
  that the text stays fully legible. A title crossing a background shape is the
  most common way these decks lose a layout mark.
- A large ornament must be cropped by the stage edge rather than floated in the
  middle of the composition, unless it carries content itself.
- Never place body copy on top of a photograph unless the photograph is a
  full-bleed field and the copy sits on a text-safe treatment.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Identity checks while authoring

First confirm the content survived: every point is still on its slide and no
image or caption appears that the material does not support. Then audit
identity:

- every slide carries the masthead and the page number from `PLACEMENT.md` section A;
- every `pixel-glyph` follows the page role and edge treatment in `PLACEMENT.md`;
- every ornament maps to a named item and page role in `decoration/PLACEMENT.md`, in its
  own geometry, without generic substitute
  circles, squares, arches, or colour blocks — every `--r-*` radius is forced to `0`, so a
  rounded shape is by construction not from this template;
- text uses only `--ka` / `--k1` / `--k2` / `--k3`;
- kickers, page numbers, running heads and standfirsts are plain text with no box around
  them;
- large filled panels use `--g0` / `--g1` / `--g2`; `--ink` and `--g3` ground only small
  squares and the full-bleed stage itself;
- exactly one `data-color-system` token, and it is one of the preferred tokens;
- keep authored ornaments clear of type; any reported geometric crossing remains an
  optional-review candidate under `Automated QA` below.

Resolve any failure before running Automated QA.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
