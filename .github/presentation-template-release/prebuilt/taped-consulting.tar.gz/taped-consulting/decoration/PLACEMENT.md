# taped-consulting — identity placement

Everything here is measured from the original reference deck (15 pages, rendered at
1600×900). These are this template's readings, not bloom's.

## Classification result: zero optional decorations

Classify before counting. Optional decoration must be template-specific, textless,
data-free, outside `.fit`, independent of media, and perform no content or layout
function. The taped-consulting reference contains **zero** elements that meet that
definition.

- the inset page frame, top-right tape and page number are persistent chrome;
- a taped Polaroid — mount, photocell and attached tape strip — is media content and
  media treatment, not an independent ornament;
- the large section numeral carries information;
- badges, process nodes, connectors, feature icons and KPI rules are content-bearing or
  layout structure;
- cards, colour fields, panels, rectangular backgrounds, content containers and grid
  cells are layout.

Therefore this template has no `data-decoration`, `data-deco`,
`data-decoration-size="small"` or `data-deco-small` elements, and no
`item-sets.html`. Do not invent a circle, square, arch, blob, pill, empty colour block or
other geometry to satisfy a decoration quota. See [decoration.html](decoration.html) for
the rendered **“No optional decorations”** proof.

Decoration ratio is advisory telemetry only. A value below 50% is valid for this
zero-optional-decoration template and must never block completion or trigger a repair.

## Layer model

| z-index | layer | contents |
|---|---|---|
| 0 | ground / persistent chrome | stage colour, inset page frame, top-right chrome tape |
| 2 | media | taped photographs supported by the source material |
| 40 | content | `.fit`, text and content components |
| 45 | persistent chrome | page number |

There is no optional-decoration layer.

## A · Persistent chrome — calibrated separately

Measured: the page frame appears on **10/15** pages, the chrome tape on **10/15**, and
the page number on **15/15**. The ten framed pages are precisely the ten pages that are
not full-bleed. **No full-bleed page carries a frame or chrome tape: 0/5.**

On a cream page, both:

```html
<div style="position:absolute;inset:3cqh 2.4cqw;border:1px solid color-mix(in srgb,var(--ink) 20%,transparent);z-index:0"></div>
<div style="position:absolute;right:2.4cqw;top:3cqh;font-size:1cqw;width:4.5em;height:.62em;background:var(--s2);transform:translateY(-50%);z-index:0"></div>
```

On every page, cream or colour:

```html
<div class="pagenum">page 01</div>
```

The chrome occupies 2.4–3.6% of stage height. The reference's earliest flow content
starts at **11.2%**, and `.fit` starts at 12cqh. `aboveChromeBand` therefore gates at 0.

## B · Taped photographs are media content

The media treatment is the template's strongest visual signature, but it is not optional
decoration under the strict classification above. Add a photograph only when the source
material supports that subject; otherwise delete the whole mount.

Thirteen of fifteen pages carry large taped photographs:

- **ten collage pages** carry 2–3 overlapping photographs: p1–5, p7, p10–12 and p15;
- **one team page** carries a level row of three similarly sized portraits (p6);
- **two full-width content pages** carry one small corner photograph (p8 and p9).

The reference also has three circular testimonial avatars on p13. Those are media
content too, and are excluded from the 32 large-photo readings below.

Within each of the ten collage clusters:

- mounts have deliberately different sizes: 15.2–29.7cqw wide;
- every rotation is between **−6° and +4°**, none is 0°, and neighbouring signs alternate;
- the cluster is anchored with `right:` and `top:` / `bottom:` so it grows inward;
- every mount has one attached tape strip, `--s2` at 80%, rotated +6° or +7°.

All 32 outer mounts stay inside the stage. On the ten collage pages, flow text and outer
mounts have **0 horizontal overlap** after p12's two mounts were moved fully into their
right-side well.

Four layouts ship that well as a **visible** taped cell — `--bg` mount, `data-photocell`
at `aspect-ratio:4/3` filled with `var(--ph)`, tape strip: `cover`, `toc`,
`section-divider` and `close`. It is still media, not optional decoration, and the count
above stays 0. That visible cell is an authoring placeholder, not valid final output:
resolve it with source-supported media or remove the entire mount before delivery. No
layout reserves a transparent empty column; `statement`,
`numbered-list`, `stat-highlight` and `kpi-grid` run the full safe area instead.
`gallery`, `team`, and the avatars in `quote-cards` own their media as
content. A full-width non-imagery page takes at most one supported corner photograph,
or none.

## C · Content and layout devices — keep them in their layouts

| component | marker | role |
|---|---|---|
| photocell | `data-photocell` | media content inside a taped mount |
| badge | `data-badge` | numbered content label |
| node | `data-node` | process-stage component |
| connector | `data-connector` | process relationship |
| feature icon | inline SVG | semantic card content |
| KPI rule | unlabelled short rule | number-to-caption layout separator |

These devices are already embedded in their matching layout files. They are not copied
from a decoration item-set and never enter optional-decoration counts.

## D · Colour

- `--surface` needs its 1px border: it is only 1.02–1.09:1 against `--bg` in the five
  preferred systems.
- `--g3` never grounds a card. It is dark in four systems and pale in
  `terracotta_clay`; use the stable card cycle `--g0 --g2 --g1`.
- `--ink` grounds only small content devices such as a process node.
- `--s2`, `--s1`, `--s3` and `--accent` are fill-only when their contrast is unsafe.
  For coloured type use `--ka` or `--soft`; both clear 5.33:1 in every preferred system.
- Full-stage colour appears on **5/15 pages (33%)**. A full-bleed kicker uses
  `color:currentColor`, never `--ka`.

## Verification

```bash
cd ../tools
SAFE=.07 ./run.sh ../../layouts/*.html
```

Reference exact gates:

```
overflow 0             outsideSafeArea 0
lowContrast 0          columnsMisaligned 0
aboveChromeBand 0      boxesUnderfilledV/H 0
orphanSlides 0         indirectSlides 0
optional decoration 0  small optional decoration 0
```

On a final delivered deck, the same probe must also report `emptyPhotocells 0`.
Decoration counts and ratios remain diagnostic and never set failure status.

Also require `navigableSlides == pages`, and actually press an arrow key. Report
`boxesOnFullBleed` separately: the reference reads 36 because the probe sees photo
furniture on the five full-bleed pages; it is media, not a card or panel defect.
