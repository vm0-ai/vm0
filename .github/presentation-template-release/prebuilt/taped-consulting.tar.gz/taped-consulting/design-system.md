# Taped Consulting

## Visual identity

An elegant consulting collage: taped Polaroids, two-tone weighted titles, a fine page frame, and large accent-colour numerals. Formal yet warm.

## Color system tokens

Read `color-system` from the prompt before generation. If the prompt supplies one of the valid tokens below, use it exactly. If it omits the token, let the Agent choose from the list based on content, audience, mood, information density, and readability. Use one token for the entire deck.

The demonstration category documented for this template is **M (single-primary)**, with example token `slate_corporate`; generation still follows the rule above.

Use only the following snake_case token values:

- M, single-primary: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- V, multicolour: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`slate_corporate`, `warm_sand`, `mono_ink`, `nordic_frost`, `terracotta_clay`

The default color system used in `example/reference.jpg` is `slate_corporate`.
Picking a token outside this list is how a deck ends up looking like a different
template: a finance source, for instance, pulls every template toward the same
muted corporate grey unless the list stops it.


After choosing a token, read `color-systems/<token>.css`, inline its only CSS block in the final HTML, and write the same token on the document root. The canonical root value is:

```html
<html data-color-system="slate_corporate">
```

- Use `--bg`, `--surface`, `--ink`, `--soft`, and `--ph` for the page, surfaces, primary text, secondary text, and image placeholders.
- `--accent`, `--s1`, `--s2`, and `--s3` are raw hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected for those hues in v1, for large icons or decorative symbols. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use the contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text; use `--kad` for accent text on an `--ink` colour field. When a raw hue needs more text contrast, these tokens fall back to the corresponding readable text colour.
- For large colour fields containing text, use `--g0` through `--g3` and pair each with its matching `--t0` through `--t3`.
- HTML/CSS components reference colours only through `var(--...)`; derive transparency, outlines, shadows, and gradients from defined tokens as well.

Use `--bg` and bordered `--surface` for primary content, `--ka` for accent text,
`--s2` for tape and other non-text marks, and the matched `--g?` / `--t?` pairs for
large colour fields. Two-tone titles pair `--ka` with `--ink` on cream pages.

```css
.slide { background: var(--bg); color: var(--ink); }
.surface { background: var(--surface); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Montserrat` as the display face and `Lora` as the body face.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&family=Lora:wght@400;500;600&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Montserrat";
  --fb: "Lora";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "Songti SC", "STSong", "Noto Serif CJK SC", "Noto Serif SC", serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600, and body weights are 400 / 500 / 600. Use `--fd` for headings, hero numerals, and section indices; use `--fb` for body copy, labels, chart annotations, and tables. Chinese text uses `--cjk-display` and `--cjk-body` to preserve the display/body hierarchy.

## Deck shell

This is the template's normalized base stylesheet, derived from `layouts/`
and used by the layouts in this folder. Copy it into the single `<style>` block, immediately after the inlined
colour-system CSS, before writing any slide. It defines the 16:9 stage, the type
scale, and the chrome and decoration classes the rest of this document refers
to. A deck that invents its own class names instead of using these will not look
like this template.

```css
:root{
  --r-xs: .5cqw;
  --r-sm: .9cqw;
  --r-md: 1.7cqw;
  --r-lg: 3cqw;
  --r-xl: 5cqw;
  --fd: "Montserrat";
  --fb: "Lora";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "Songti SC", "STSong", "Noto Serif CJK SC", "Noto Serif SC", serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);overflow-wrap:break-word;word-break:normal;}
.stage *{overflow-wrap:break-word !important;word-break:normal !important;}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}
  

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:45;}

.tile{width:var(--sz,5em);height:var(--sz,5em);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;}
.tile>span{font-size:40cqw;line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{width:var(--sz,5em);height:var(--sz,5em);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;}
.badge>span{font-size:40cqw;line-height:1;}
.tick{position:absolute;}
.card{background:var(--surface);border-radius:var(--r-md);}
.dot{border-radius:50%;}.qcircle{border-radius:50% 0 0 0;}.semi{border-radius:999px 999px 0 0;}.tri{width:0;height:0;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}
```
The number inside a `badge` and any text inside a `tile` must be wrapped in a
`<span>`. The wrapper is what makes the text scale with the box: it is measured
against the badge's own width, so the figure stays in proportion at any size.
Text placed directly in the box only follows `--sz`, and a deck that sizes the
box with `width`/`height` instead will render a small number in a large frame.
Size these with `--sz`, not `width`/`height`.


## Signature elements

Available signature elements: `taped-photo`, `two-tone-title`, and `big-number`.


Visual reference: [example/reference.jpg](example/reference.jpg)

## Motif library

Every motif below is copied out of this template's own reference deck. This is
the geometry that makes the template recognisable, and it is the part that goes
missing when a deck is authored from the prose alone — the shapes exist nowhere
else; it is reproduced here so generation never needs a full-deck HTML example.

**Copy these snippets. Do not paraphrase them, redraw them, or substitute a
shape that is easier to write.** Change only size, position, colour token, and
text content. The count beside each motif is how many times the reference deck
uses it across fifteen slides. It records prevalence; it is not a floor, quota,
or target to scale mechanically. Use a motif only where the closest reference
page role uses it and the composition benefits.


### `badge` — used 3× in the reference deck

```html
<div class="badge" data-badge="1" style="font-size:1cqw;--sz:5em;background:var(--g0);color:var(--t0)"><span>01</span></div>
```

### `multicolor` — used 15× in the reference deck

This motif is too long to reproduce here without cutting it mid-tag, so it is
not inlined. Find it in [layouts/](layouts/) by
searching for the opening tag below, and copy the whole element from there —
including everything nested inside it.

```html
<h1 class="display" data-multicolor="1" style="font-size:7.6cqw;margin-top:2cqh;line-height:1.0">
```



### CSS signatures

These declarations are part of the template's look. The counts are from the reference deck.

| property | values it actually uses | why it matters |
| --- | --- | --- |
| `box-shadow` | `0 .2cqw .5cqw color-mix(in srgb, var(--ink) 6%, transparent)` ×32<br>`0 1.3cqw 2.6cqw color-mix(in srgb, var(--ink) 16%, transparent)` ×29<br>`0 1.2cqw 2.4cqw color-mix(in srgb, var(--ink) 16%, transparent)` ×3 | offset shadows are a signature, not a default |
| `border-radius` | `50% 0 0 0` ×1<br>`999px 999px 0 0` ×1<br>`999px` ×1 | observed content geometry, not extra optional ornaments |
| `transform` | `rotate(-4deg)` ×7<br>`rotate(3deg)` ×6<br>`rotate(4deg)` ×5<br>`rotate(-6deg)` ×4 | deliberate tilt |


### Not captured above

These named signature elements have no extractable snippet in this library: `taped-photo`, `two-tone-title`, `big-number`. Read [layouts/](layouts/) for them and copy the markup from the slide that uses them; do not improvise a substitute.

## Decoration reference profile

The strict optional vocabulary is closed and measured from the 15-page reference. It
contains **zero optional decorations**. A taped Polaroid and its attached tape strip are
one media-content treatment, not an independent ornament. The big numeral carries
information; badges, process nodes, connectors, feature icons and KPI rules are content
or layout devices. The page frame, top-right tape and page number are persistent chrome.
Cards, colour fields, backgrounds, containers and grid cells are layout.

Do not invent geometry to satisfy a decoration quota, and do not create an
`item-sets.html` for content components. [decoration/PLACEMENT.md](decoration/PLACEMENT.md)
contains the measured media, chrome and classification rules.

Treat decoration ratio as advisory telemetry only. This template's valid optional count
is zero, so decoration ratio never blocks delivery.

## Media and chrome safe area

There is no optional-decoration layer, but media and chrome must still respect content.

- Every slide has a **text safe area**: the region actually occupied by its title, body
  copy, figures and labels. Media and chrome never cover it.
- **Every outer photo mount stays fully inside the stage.** Measured on this template's
  reference deck: **0 of 32** cross the stage bounds. A taped Polaroid that runs off the
  edge stops reading as a photograph someone put down on the page.
- **The collage well is the right half, not the lower third.** Ten reference pages use a
  right-side collage. After p12's two mounts were moved fully into its well, flow text
  and outer mounts have **0 horizontal overlap on all ten**. The level team row, three
  testimonial avatars and p8/p9's single corner photograph are role-specific media
  compositions, not optional decoration.

See [decoration/PLACEMENT.md](decoration/PLACEMENT.md) for the full measured
placement rules and [layouts/README.md](layouts/README.md) for the four layouts that
carry a visible taped photo cell in the right half — and why none of them reserves an
empty column to do it.

## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** A label positioned with `left:88cqw` will
overflow the moment its text is longer than the author guessed, and CJK copy is
routinely wider than the Latin draft it was written against. Anchor anything in
the right third with `right:` instead of `left:`, and anything in the bottom
third with `bottom:` instead of `top:`. A block anchored to the edge it is near
grows inward, where there is room, instead of outward into nothing. Give any
absolutely-positioned text an explicit `max-width` so it wraps rather than
extends.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

A finished slide keeps repeated items on one structural alignment and keeps
content clear of every unintended stage edge.

## Never do this

- **Never use a disc-bulleted list.** Not one of the twenty-three V3 reference
  decks contains a single `<ul>` with default bullets, and a bulleted list is the
  fastest way to make a designed template look like a plain document. Structure a
  list as numbered rows with a hairline rule between them, as key–value rows, as
  a row of cards, or with the template's own motifs — whatever the reference deck
  does for the same job.
- Never invent a colour outside the inlined colour-system tokens; every colour
  goes through `var(--...)`.
- Never leave a slide without the chrome required for its page role.
- Never let media or chrome sit on top of a title or a paragraph.
- Never generate a photograph the supplied material does not call for.

## Required chrome

Chrome is the cheapest part of a template's identity and the most frequently
dropped: across the benchmark's baseline decks, four of six templates carried a
footer on 0-2 slides out of 17. This template's reference deck carries the
following, and the count is measured from that deck, not assumed.


### Conditional frame and tape; universal page number

Cream pages carry both the fine inset frame and the top-right tape; full-bleed pages
carry neither. That is 10 of 15 versus 0 of 5 in the reference. Copy both from
[decoration/PLACEMENT.md](decoration/PLACEMENT.md), rather than treating either as an
optional ornament.

```html
<div style="position:absolute;right:2.4cqw;top:3cqh;width:4.5cqw;height:1.1cqh;background:var(--s2);transform:translateY(-50%);z-index:0">
```
<sub>on 10 of 15 reference slides</sub>

**Page number** — on 15 of 15 slides:

```html
<div class="pagenum">page 01</div>
```

Carry page number on **every** slide, including the cover and the closing slide.
