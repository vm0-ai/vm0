# taped-consulting — naked layouts

42 content layouts. There is no optional decoration and no measured text geometry.
`gallery`, `team`, the three image-led layouts and testimonial avatars keep media frames intrinsic to their content;
four more carry a visible authoring-time taped photo cell. No layout reserves an empty
column. Final delivered decks must resolve every `data-photocell` with supported media
or remove its entire mount. Add media only when the source calls for it, then apply persistent chrome from
[../decoration/PLACEMENT.md](../decoration/PLACEMENT.md).

Every number in this file was measured on the original reference deck at 1600×900,
15 pages. They are this template's numbers, not another template's.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 42: zero `width` / `max-width` / `min-width` / `height` /
`left` / `top` / `right` / `bottom` / `flex` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex-basis`. `flex:0 0 5cqw` on an agenda number freezes exactly the way a
`width` does — the reference writes `width:5cqw` on all five of its agenda numbers, and
that is an observation of the string "01" at one font size, not a design decision.

Four exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` or `inset` on
  something that is `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline rule.
- **`em`** on a textless media or layout device — an attached tape strip, the rule under
  a KPI, a legend swatch. `em` scales with the type around it, so it cannot freeze a text box.
  The template's own `--sz` knob on `.tile` / `.badge` is used this way:
  `style="font-size:1cqw;--sz:5em"`, never `width:5cqw`.
- **`%`** in `chart-bar`, `chart-waterfall` and `gantt` (the length or offset *is* the datum), in `table` (`width:1%` is the
  shrink-to-fit idiom `composition-recipes.html` already uses for identifier columns),
  and in `comparison` (the clipped field is a percentage **of its row**, so it follows
  wherever flex puts the split).

Everything else stretches. Columns are `flex:1`. **The safe area is set once, by the
padding on `.fit`: `12cqh 7cqw 8cqh`.**

`7cqw` is not a guess. The reference starts its text at exactly 7.0% of stage width on
14 of its 15 pages (the 15th is the centred team page at 14.3%), and its widest page
ends at 91.9% against a 93% limit. Run the template-local probe as `SAFE=0.07 ./run.sh ...`;
the default `0.06` is bloom's constant and must not be used for this template.

Any flex child holding an SVG or a percentage-height bar needs `min-height:0`, or the
SVG's intrinsic aspect ratio pushes the box past the stage edge.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions.
Not a slide.

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `statement` `long-form` `bullet-list` `two-column` `three-column` `numbered-list` `big-quote`

**Filled peers** · `color-cards` `feature-cards` `quote-cards`

**Numbers and charts** · `kpi-grid` `kpi-cards` `stat-highlight` `table` `chart-bar` `chart-line` `chart-donut` `chart-waterfall`

**Sequence and plans** · `process-steps` `timeline` `roadmap` `gantt`

**Systems and relationships** · `architecture` `mind-map` `issue-tree` `matrix-2x2`

**Choices and trade-offs** · `comparison` `versus` `pros-cons` `pricing`

**Imagery as content** · `image-left` `image-right` `hero-image` `gallery` `team`

**Consulting decisions** · `executive-summary` `case-study` `recommendations`

Thirteen of these are compositions the reference deck actually demonstrates. Three come
from `../composition-recipes.html` (`big-quote`, `comparison`, `table`). The remaining
eight — `two-column`, `three-column`, `kpi-cards`, `stat-highlight`, `chart-bar`,
`chart-line`, `timeline`, `color-cards` — are gaps a real board deck hits that the
reference never shows. A later coverage review added eighteen communication jobs the
original set could not express without improvising: editorial long-form and bullets;
left-, right- and hero-image pages; donut and waterfall charts; roadmap and Gantt;
architecture, mind map, issue tree and 2×2 matrix; filled versus and pros/cons; and the
consulting-specific executive summary, case study and recommendation stack. Each has a
different content contract; none is a relabelled duplicate of an existing page.

## The photo well — this template's strongest structural fact

Ten reference pages use a right-side collage rather than an image row: p1–5, p7, p10–12
and p15. After moving p12's two mounts fully into its right well, the horizontal overlap
between flow text and those collage mounts is **0 on all ten pages**. The team page is a
different composition — three equal portrait columns — and p8/p9 each use one small
corner photograph rather than a collage.

**A reserved empty column is not a photo well — it is a blank half page.** The earlier
revision left `<div data-photo-well="1" style="flex:1"></div>` — no text, no fill, no
border — on eight layouts. Measured at 1600×900 against the 1376px safe area, that box
took **48.3% of the safe width × 100% of the height** on seven of them and 26.8% on
`kpi-grid`, and it squeezed the copy beside it into **11 mid-phrase wraps**
(`Delivering Data-` / `Driven Growth`). Both readings are now 0, and the reference reads
0 on both, which is what makes them gates rather than opinions.

Four layouts — `cover`, `toc`, `section-divider`, `close` — now carry a **real taped
photo cell**: a `--bg` mount with a `data-photocell` at `aspect-ratio:4/3` filled with
`var(--ph)`, plus its tape strip. It renders as a visible placeholder even with no image
supplied, exactly like `team` and `gallery`. Sized by `flex` and `aspect-ratio`, never by
a measured width. Half-width copy is legitimate on these four because something real sits
beside it. This placeholder is valid in the source catalogue only; it must not survive in
a final delivered deck.

Four more — `statement`, `numbered-list`, `stat-highlight`, `kpi-grid` — dropped the
well and run the full 1376px safe area instead. `statement`'s title now sets on one line.

Portrait `3/4` is wrong for these mounts: at the 664px column width it computes to an
861px-tall card on a 900px stage, bursting the safe area. Use `4/3`.

The other thirty-four expose no photo cell. `gallery`, `team`, `quote-cards`,
`image-left`, `image-right` and `hero-image` own their image frames as content. Among the remaining full-width layouts, the reference
uses one small photograph in a corner (p8 bottom-right, p9 top-right) or none (p14).
Do not force a three-photo collage onto one of those full-width layouts.

## Content, media and layout devices are already classified

There is no optional `item-sets.html`. Taped photo assemblies are media; badges, nodes,
connectors, icons and short KPI rules are content or layout devices. The matching
components are already present inside their layout files.

| layout | built-in structure or supported addition |
|---|---|
| `cover` `section-divider` `close` `toc` | one authoring placeholder (`--ph`, `aspect-ratio:4/3`); resolve it with supported media or remove the whole mount before delivery |
| `statement` `numbered-list` `stat-highlight` | copy spans the full safe area; no photo cell, no reserved column |
| `kpi-grid` | four KPIs across the full safe area, one short `--s2` separator under each number |
| `gallery` `team` `image-left` `image-right` `hero-image` | taped media frames are intrinsic content |
| `quote-cards` | circular testimonial avatars are intrinsic content |
| `numbered-list` | one content-bearing badge per row, grounds cycling `--g0 --g1 --g2` |
| `process-steps` | one process node per step plus one structural connector |
| `feature-cards` | one semantic 24×24 stroke icon per card, in `--ka` |
| all remaining layouts | no additional media or component unless the source and page role justify it |

## Ruled or filled — every peer row has both

The reference separates items with a hairline on 8 of its 15 pages. That is a skewed
menu: an agent sampling it puts the same horizontal line on every slide. Each peer-row
content type therefore has two treatments, and neither is more on-template:

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `color-cards` |
| a row of numbers | `kpi-grid` | `kpi-cards` |
| capabilities | `three-column` | `feature-cards` |
| two alternatives | `comparison` | `versus` |

The filled versions cycle `--g0 --g2 --g1` so neighbours never share a colour.

**Do not extend that cycle to `--g3`.** It is dark in four preferred systems and pale in
`terracotta_clay`; in `slate_corporate` it is byte-identical to `--ink`. The reference
uses `--g3` exactly once, full-bleed on `.stage` (p7), and **never on a box**. A `--g3`
card therefore changes semantic weight with the token and reads as a photo placeholder
in the default. `kpi-cards` now cycles the stable grounds `--g0 --g2 --g1 --g0`.

## A filled box is sized by its content, never by the stage

```
height   row     flex:none      height comes from the tallest child, not the stage
         child   flex:1         siblings equalise to that tallest child
         group   wrapped in flex:1;min-height:0;…;justify-content:center

width    box     align-self:flex-start; max-width:100%
```

`.fit` is a column flex with `align-items:stretch`, so every child is full-width by
default. A row of peers — cards, columns — stays equal-width and divides the safe area.
One box hugs, a row of boxes divides.

**Stress-test equal height rather than trusting `align-items`.** Inject an extra sentence
into the first item of each peer row and compare sibling heights. `team` shipped with
`align-items:flex-start` and read 121/121/121 before injection and 301/121/121 after —
invisible until one name wraps. It now reads 301/301/301.

## Two traps this template sets, both found by eye after every probe passed

**A frame with no definite width collapses to nothing.** `team`'s member column is
`align-items:center`, so the taped photo mount shrank to its content width — zero — and
`aspect-ratio` then resolved its height to zero too. The photographs vanished; the tape
strips and the names rendered normally and every probe read clean. The mount needs
`align-self:stretch`. `gallery` never had the bug because its frames are `flex:1` in a row.

**A word-length price wraps its unit and breaks the row.** `pricing`'s third card reads
"Custom", not "$32K"; at `.h1` the `/ retainer` dropped to a second line, pushing that
card's hairline and its three bullets out of line with the other two. Prices are `.h2`
with `white-space:nowrap` so every unit stays inline whatever the value.

## Colour: measured on all five preferred tokens, not just the demo one

the original reference deck renders in `slate_corporate`. Checking only that token hides real defects —
the reference's agenda numbers used `--accent` and `--s3` as text on cream, which reads
0 violations in `slate_corporate` and **3 in `warm_sand`, 2 in `terracotta_clay`**.
They are now `--ka` and `--soft`, and all five read 0.

Contrast against each system's own `--bg`:

| token | slate | warm_sand | mono_ink | nordic | terracotta | use as |
|---|---|---|---|---|---|---|
| `--ka` | 5.95 | 14.89 | 19.80 | 14.36 | 12.52 | **text** — the safe accent |
| `--soft` | 5.82 | 6.78 | 5.33 | 5.33 | 6.39 | **text** |
| `--accent` | 5.95 | 2.18 | 4.24 | 3.34 | 3.53 | fill — fails in `warm_sand` |
| `--s1` | 3.47 | 2.25 | 19.80 | 1.90 | 2.06 | fill |
| `--s2` | 2.14 | 1.73 | 1.84 | 1.73 | 4.07 | fill — the tape colour |
| `--s3` | 15.56 | 6.62 | 19.80 | 14.36 | 1.26 | fill — fails in `terracotta_clay` |
| `--surface` | 1.06 | 1.02 | 1.04 | 1.03 | 1.09 | see below |

For coloured text use `--ka` or `--soft`. Nothing else is safe in all five.
On a `--g?` ground use the matching `--t?` (4.61–19.8 everywhere), never a scheme colour.

**`--surface` is invisible on its own.** It is within 1.09:1 of `--bg` in every preferred
system. Unlike bloom, this template's reference does use it — 3 times, on `feature-cards`
— but always with `border:1px solid color-mix(in srgb,var(--ink) 12%,transparent)`.
The border is what makes the card exist. A `--surface` panel with no border is a white
rectangle on a white page. Reference uses of unbordered `--surface`: **0**.

`--ink` grounds only small things: the "most chosen" pill. `darkPanels` reads 0 on the
four non-mono preferred references. `mono_ink` legitimately reads 2 because both its
`--g1` and `--g3` are black; for that token, report against 2 instead of gating on 0.

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` ·
structure `stage fit deck slide band card tile badge` ·
marks `dot tick soft dim pagenum`.

Sizes live in those classes. If something needs to be bigger, use the next class up —
do not write a `font-size` outside the two-tone title, whose size varies by page role.

## Before you ship a deck built from these

```
document.querySelectorAll('.slide').length ===
  [...document.querySelector('.deck').children].filter(n => n.classList.contains('slide')).length
```

Every `.slide` must be a **direct child** of `.deck`. Nest one level deeper and the
navigation runtime cannot see it: the deck renders perfectly, scrolls perfectly,
screenshots perfectly, and the arrow keys stop at page 2. Then press an arrow key
yourself — this defect is found by a keypress, not by a probe.
