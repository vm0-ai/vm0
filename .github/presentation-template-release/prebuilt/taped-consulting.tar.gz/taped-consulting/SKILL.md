---
name: taped-consulting
description: Create a standalone 16:9 HTML presentation deck with the Taped Consulting visual identity and direct-HTML workflow. Use when the user selects the Taped Consulting presentation template or explicitly names taped-consulting as the deck style. Best suited to warm, formal board updates, consulting cases, and recommendation decks.
---

# Taped Consulting presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one standalone HTML file with one live `.deck`. Include the deck CSS and keyboard-navigation script once.
- **Every `.slide` must be a direct child of `.deck`.** This is the single most damaging
  defect this format has, because nothing reveals it except pressing a key: the navigation
  runtime collects slides with `[...deck.children].filter(n => n.classList.contains('slide'))`,
  so a slide nested one level deeper renders, scrolls and screenshots perfectly and the
  arrow keys simply stop at it. Slides written after the deck's closing `</div>` are lost
  the same way.
- Translate the completed outline directly into HTML in the same order, one `.slide` per planned page, one 16:9 `.stage` inside each.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

Decoration ratio is diagnostic and **never blocks completion**. This template has zero
optional decorations, so a low ratio is valid and must never trigger invented geometry,
extra photo mounts, or additional repair rounds.

### Where the template lives

This template is split into three parts. Read them in this order.

| file                                                                            | what it is                                                  | what you take from it                |
| ------------------------------------------------------------------------------- | ----------------------------------------------------------- | ------------------------------------ |
| [design-system.md](design-system.md)                                            | colour roles, typography, motifs, required chrome           | tokens and identity                  |
| [layouts/README.md](layouts/README.md) + [layouts/](layouts/)                   | 42 content layouts                                          | **structure — copy these**           |
| [decoration/PLACEMENT.md](decoration/PLACEMENT.md) + [decoration/](decoration/) | strict classification, media treatment and chrome placement | **identity placement — follow this** |

A slide starts with one layout from `layouts/`, then adds only source-supported media and
the chrome `PLACEMENT.md` prescribes. This template has zero optional decorations.

Use `layouts/` for rhythm, scale, and page-role sequence; take reusable
structure from `layouts/` and do not copy content-specific fixed geometry.

### Pick a layout for every slide

Choose from `layouts/`. Do not invent a composition when one of these fits.

| the slide's job                                | layout              |
| ---------------------------------------------- | ------------------- |
| open the deck                                  | `cover`             |
| agenda / contents                              | `toc`               |
| start a section                                | `section-divider`   |
| close, thank, contact                          | `close`             |
| one claim with supporting prose                | `statement`         |
| sustained context with several paragraphs      | `long-form`         |
| unranked key takeaways                         | `bullet-list`       |
| two ideas side by side in prose                | `two-column`        |
| three parallel ideas, quiet                    | `three-column`      |
| three parallel ideas, loud                     | `color-cards`       |
| capabilities or services                       | `feature-cards`     |
| ordered principles or criteria                 | `numbered-list`     |
| one decisive statement                         | `big-quote`         |
| client testimony                               | `quote-cards`       |
| a row of metrics, quiet                        | `kpi-grid`          |
| a row of metrics, loud                         | `kpi-cards`         |
| one number that carries the slide              | `stat-highlight`    |
| rows of records, IDs, counts                   | `table`             |
| a quantity across categories                   | `chart-bar`         |
| a quantity over time                           | `chart-line`        |
| composition or share of a whole                | `chart-donut`       |
| a bridge from baseline to target               | `chart-waterfall`   |
| an ordered method                              | `process-steps`     |
| dated milestones                               | `timeline`          |
| now / next / later change horizons             | `roadmap`           |
| workstreams across a dated delivery window     | `gantt`             |
| layers, modules and interfaces                 | `architecture`      |
| associations around one central idea           | `mind-map`          |
| a diagnostic question decomposed into drivers  | `issue-tree`        |
| prioritise options on two axes                 | `matrix-2x2`        |
| before / after, us / them                      | `comparison`        |
| two alternatives with equal visual weight      | `versus`            |
| benefits and risks of one choice               | `pros-cons`         |
| tiers or engagement options                    | `pricing`           |
| image-led story with media on the left         | `image-left`        |
| image-led story with media on the right        | `image-right`       |
| one large image as the main evidence           | `hero-image`        |
| a body of work as images                       | `gallery`           |
| people                                         | `team`              |
| situation, insight and decision for executives | `executive-summary` |
| challenge, intervention and measured impact    | `case-study`        |
| ranked actions with rationale and ownership    | `recommendations`   |

Ruled and filled treatments are paired on purpose: `three-column`/`color-cards`,
`kpi-grid`/`kpi-cards`, `comparison`/`versus`. Alternate them. If the previous slide
was ruled, prefer filled.

#### The rules that come with the layouts

- **The safe area is `padding:12cqh 7cqw 8cqh` on `.fit`, set once.**
- **No sizing in `cqw`/`cqh`/`px`/`vw`/`vh` on anything that holds text** — not
  `width`, `height`, `min-width`, `max-width`, nor `flex-basis`. Columns are `flex:1`.
  Full rule and its four exemptions: [layouts/README.md](layouts/README.md).
- **A filled box is sized by its content, never by the stage.** Row `flex:none`,
  children `flex:1`, group wrapped in `flex:1;min-height:0;justify-content:center`.
- **Everything is flex.** No grid, no float, no absolute positioning for layout.

### Place media and chrome

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

Read [decoration/PLACEMENT.md](decoration/PLACEMENT.md) in full. Apply these four rules:

1. **Taped Polaroids are media content, not optional decoration.** Use the collage,
   portrait-row, or corner-photo composition documented for the selected page role.
   Keep mounts visibly rotated.
2. **No outer photo mount bleeds off the stage.**
3. **The collage goes in the right half, and it is never an empty box.** Keep flow text
   clear of outer photo mounts. `cover`, `toc`,
   `section-divider` and `close` ship a visible taped cell — a `--bg` mount around a
   `data-photocell` at `aspect-ratio:4/3` filled with `var(--ph)` — as an authoring
   placeholder only. Resolve it with supported media or remove the entire mount before
   delivery. Never reserve a transparent empty media column. `statement`, `numbered-list`,
   `stat-highlight` and `kpi-grid` carry no photo cell and run the full safe area.
   `gallery`, `team`, `image-left`, `image-right`, `hero-image`, and testimonial avatars own their imagery as
   content; a full-width non-imagery layout gets one small corner photograph or none.
4. **The page frame and corner tape are cream-page chrome only.** Omit them on
   full-bleed pages. Keep the page number on every page.

#### Colour roles

- For coloured text use **`--ka`** (5.95–19.80:1) or **`--soft`** (5.33–6.78:1). Nothing
  else clears 3.0:1 in all five preferred systems. `--accent` fails in `warm_sand` (2.18),
  `--s3` fails in `terracotta_clay` (1.26), `--s2` and `--s1` are fill-only.
- On a `--g?` ground use the matching `--t?`. On a full-bleed page a kicker uses
  `color:currentColor`, never `--ka`.
- **`--surface` needs its 1px border** so it remains distinct from `--bg`.
- **`--g3` never grounds a box.** It is dark in four systems and pale only in
  `terracotta_clay`; a `--g3` card therefore changes semantic weight with the token and
  reads like a photo placeholder in the default. Use the stable cycle `--g0 --g2 --g1`.
- `--ink` grounds only small things — a pill, a process node.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

The root `data-safe-area="0.07"` supplies this template's constant. The final QA checks
the direct-child count and live key state without a separate console or key pass.
Recommended diagnostics:

```
overflow  outsideSafeArea  aboveChromeBand
lowContrast  boxesUnderfilledV  boxesUnderfilledH
orphanSlides  indirectSlides            navigableSlides == pages
```

Authoring layouts may contain placeholders, but the delivered deck should not. An
`emptyPhotocells` reading is resolved only by an `<img>` source or a CSS `url(...)`;
`var(--ph)`, a solid fill, or a gradient is still empty. If one remains, delete its
entire media mount and reflow the page or choose a non-media layout. Do not generate an
unsupported photograph merely to clear it.

`darkPanels` is token-dependent: review it for non-mono preferred systems; report it for
`mono_ink`, where dark grounds are part of the token.

Review each `boxesOnFullBleed` reading by role: photo furniture can legitimately belong
on cover, divider, and closing pages.

#### Identity checks while authoring

First confirm the content survived: every point is still on its slide and no image or
caption appears that the material does not support. Then audit identity:

- every cream slide carries the page frame and the corner tape; every slide carries the page number;
- every collage uses 2–3 differently sized mounts in the right well; the team row and
  single-corner variants are used only for their documented page roles; every mount is
  rotated within −6° to +4° and none bleeds off the stage;
- exactly one `data-color-system` token: the prompt's valid token when supplied,
  otherwise one of the five preferred tokens;
- no media or chrome sits on top of type; no optional decoration has been invented.
- no empty `data-photocell` remains in the delivered HTML; decoration ratio is reported
  only and does not affect pass/fail.

Resolve any failure before running Automated QA.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
