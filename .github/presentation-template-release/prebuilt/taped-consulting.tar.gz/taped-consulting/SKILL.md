---
name: taped-consulting
description: Create, revise, or review standalone 16:9 HTML presentation decks with the Taped Consulting visual identity and direct-HTML workflow. Use when the user selects the Taped Consulting presentation template or explicitly names taped-consulting as the deck style. Best suited to warm, formal board updates, consulting cases, and recommendation decks.
---

# Taped Consulting presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## Where the template lives

This template is split into three parts. Read them in this order.

| file                                                                            | what it is                                                  | what you take from it                |
| ------------------------------------------------------------------------------- | ----------------------------------------------------------- | ------------------------------------ |
| [design-system.md](design-system.md)                                            | colour roles, typography, motifs, required chrome           | tokens and identity                  |
| [layouts/README.md](layouts/README.md) + [layouts/](layouts/)                   | 42 content layouts                                          | **structure — copy these**           |
| [decoration/PLACEMENT.md](decoration/PLACEMENT.md) + [decoration/](decoration/) | strict classification, media treatment and chrome placement | **identity placement — follow this** |

A slide starts with one layout from `layouts/`, then adds only source-supported media and
the chrome `PLACEMENT.md` prescribes. This template has zero optional decorations.

Use `layouts/` for rhythm, scale, and page-role sequence; take reusable
structure from `layouts/` and do not copy content-specific fixed geometry.

## Choose the task mode

- Create: use Sections 1–5 and complete Section 2 before writing any slide HTML.
- Revise: inspect the existing HTML, reconstruct or update the outline for the affected sequence, and complete Section 2 before editing slide HTML; then use Sections 3–5 as relevant while preserving valid shell, token, motif, and runtime implementation.
- Review: use Sections 1–3 for context and Section 5 as the checklist; infer the deck's throughline and slide-level content contract, skip Section 4, and do not edit. Report slide-specific findings in P1 / P2 / P3 order (blocking / material / polish), include evidence and a fix direction, or state explicitly that there are no actionable findings.

## 1. Define the communication job

- Read the prompt and all supplied source material before composing slides.
- Identify the audience, purpose, desired audience outcome, core takeaway, and required evidence.
- Express the communication job in one sentence: by the end, the audience should reach the desired outcome because of the core takeaway.
- Ground every factual claim and number in supplied or verified sources; label forecasts, targets, and assumptions explicitly.

## 2. Complete the slide outline before HTML

- Before creating or changing slide HTML, write a lightweight plain-text or Markdown outline. State the one-sentence throughline, then list the slides in order.
- For each slide, record its working takeaway title, the point it must establish, and the evidence or data that supports it with its supplied or verified source. Mark forecasts, targets, assumptions, and slides that need no evidence.
- Review the complete outline for narrative flow, duplicated claims, missing evidence, and a deliberate opening and ending. Choose the slide count from the content.
- Treat the completed outline as the content contract for implementation, not as a layout schema. Keep layouts and motifs out of it, keep it out of audience-facing HTML unless requested, and update it first when a slide's title, communication job, or evidence changes materially.

## 3. Pick a layout for every slide

Choose from `layouts/`. Do not invent a composition when one of these fits.

| the slide's job                                | layout              |
| ---------------------------------------------- | ------------------- |
| open the deck                                  | `cover`             |
| agenda / contents                              | `toc`               |
| start a section                                | `section-divider`   |
| close, thank, contact                          | `close`             |
| one claim with supporting prose                | `statement`         |
| sustained context with several paragraphs      | `long-form`         |
| unranked key takeaways                         | `bullet-list`       |
| two ideas side by side in prose                | `two-column`        |
| three parallel ideas, quiet                    | `three-column`      |
| three parallel ideas, loud                     | `color-cards`       |
| capabilities or services                       | `feature-cards`     |
| ordered principles or criteria                 | `numbered-list`     |
| one decisive statement                         | `big-quote`         |
| client testimony                               | `quote-cards`       |
| a row of metrics, quiet                        | `kpi-grid`          |
| a row of metrics, loud                         | `kpi-cards`         |
| one number that carries the slide              | `stat-highlight`    |
| rows of records, IDs, counts                   | `table`             |
| a quantity across categories                   | `chart-bar`         |
| a quantity over time                           | `chart-line`        |
| composition or share of a whole                | `chart-donut`       |
| a bridge from baseline to target               | `chart-waterfall`   |
| an ordered method                              | `process-steps`     |
| dated milestones                               | `timeline`          |
| now / next / later change horizons             | `roadmap`           |
| workstreams across a dated delivery window     | `gantt`             |
| layers, modules and interfaces                 | `architecture`      |
| associations around one central idea           | `mind-map`          |
| a diagnostic question decomposed into drivers  | `issue-tree`        |
| prioritise options on two axes                 | `matrix-2x2`        |
| before / after, us / them                      | `comparison`        |
| two alternatives with equal visual weight      | `versus`            |
| benefits and risks of one choice               | `pros-cons`         |
| tiers or engagement options                    | `pricing`           |
| image-led story with media on the left         | `image-left`        |
| image-led story with media on the right        | `image-right`       |
| one large image as the main evidence           | `hero-image`        |
| a body of work as images                       | `gallery`           |
| people                                         | `team`              |
| situation, insight and decision for executives | `executive-summary` |
| challenge, intervention and measured impact    | `case-study`        |
| ranked actions with rationale and ownership    | `recommendations`   |

Ruled and filled treatments are paired on purpose: `three-column`/`color-cards`,
`kpi-grid`/`kpi-cards`, `comparison`/`versus`. Alternate them. If the previous slide
was ruled, prefer filled.

### The rules that come with the layouts

- **The safe area is `padding:12cqh 7cqw 8cqh` on `.fit`, set once.**
- **No sizing in `cqw`/`cqh`/`px`/`vw`/`vh` on anything that holds text** — not
  `width`, `height`, `min-width`, `max-width`, nor `flex-basis`. Columns are `flex:1`.
  Full rule and its four exemptions: [layouts/README.md](layouts/README.md).
- **A filled box is sized by its content, never by the stage.** Row `flex:none`,
  children `flex:1`, group wrapped in `flex:1;min-height:0;justify-content:center`.
- **Everything is flex.** No grid, no float, no absolute positioning for layout.

## 4. Place media and chrome

Read [decoration/PLACEMENT.md](decoration/PLACEMENT.md) in full. Apply these four rules:

1. **Taped Polaroids are media content, not optional decoration.** Use the collage,
   portrait-row, or corner-photo composition documented for the selected page role.
   Keep mounts visibly rotated.
2. **No outer photo mount bleeds off the stage.**
3. **The collage goes in the right half, and it is never an empty box.** Keep flow text
   clear of outer photo mounts. `cover`, `toc`,
   `section-divider` and `close` ship a visible taped cell — a `--bg` mount around a
   `data-photocell` at `aspect-ratio:4/3` filled with `var(--ph)` — as an authoring
   placeholder only. Resolve it with supported media or remove the entire mount before
   delivery. Never reserve a transparent empty media column. `statement`, `numbered-list`,
   `stat-highlight` and `kpi-grid` carry no photo cell and run the full safe area.
   `gallery`, `team`, `image-left`, `image-right`, `hero-image`, and testimonial avatars own their imagery as
   content; a full-width non-imagery layout gets one small corner photograph or none.
4. **The page frame and corner tape are cream-page chrome only.** Omit them on
   full-bleed pages. Keep the page number on every page.

### Images are content choices, not filler

Use a photograph or other image whenever it communicates the slide more clearly,
credibly, or memorably than text alone. The source does not have to request one
explicitly; make that editorial choice from the content. Choose sources in this
order: user-supplied images and visual materials first, including media embedded
in or linked from the supplied material; then relevant imagery from the supplied
references and related information; then an AI-generated image grounded in the
slide's actual subject when it would work better or no suitable sourced image
exists. Never add or generate an image merely to fill an empty frame. Captions,
alt text, and adjacent labels remain factual and grounded in the source. If no
image improves the slide, delete the frame and use a colour field, panel, or
generous space instead.

Decoration ratio is diagnostic and **never blocks completion**. This template has zero
optional decorations, so a low ratio is valid and must never trigger invented geometry,
extra photo mounts, or additional repair rounds.

### Colour roles

- For coloured text use **`--ka`** (5.95–19.80:1) or **`--soft`** (5.33–6.78:1). Nothing
  else clears 3.0:1 in all five preferred systems. `--accent` fails in `warm_sand` (2.18),
  `--s3` fails in `terracotta_clay` (1.26), `--s2` and `--s1` are fill-only.
- On a `--g?` ground use the matching `--t?`. On a full-bleed page a kicker uses
  `color:currentColor`, never `--ka`.
- **`--surface` needs its 1px border** so it remains distinct from `--bg`.
- **`--g3` never grounds a box.** It is dark in four systems and pale only in
  `terracotta_clay`; a `--g3` card therefore changes semantic weight with the token and
  reads like a photo placeholder in the default. Use the stable cycle `--g0 --g2 --g1`.
- `--ink` grounds only small things — a pill, a process node.

## 5. Build the deck

- Produce one standalone HTML file with one live `.deck`. Include the deck CSS and keyboard-navigation script once.
- **Every `.slide` must be a direct child of `.deck`.** This is the single most damaging
  defect this format has, because nothing reveals it except pressing a key: the navigation
  runtime collects slides with `[...deck.children].filter(n => n.classList.contains('slide'))`,
  so a slide nested one level deeper renders, scrolls and screenshots perfectly and the
  arrow keys simply stop at it. Slides written after the deck's closing `</div>` are lost
  the same way.
- Translate the completed outline directly into HTML in the same order, one `.slide` per planned page, one 16:9 `.stage` inside each.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

## Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Getting the container right

A percentage bar height resolves against its parent's **definite** height. Break
that chain and the bar computes to exactly `0` — it vanishes while the labels,
values and legend still render, so the page reads as merely empty. Measured on
generated decks: 52 of 558 percentage bars rendered at zero, and one deck spent
455s of gate repair on this alone.

`layouts/chart-*.html` already carries a structure that works. Copy it rather
than inventing lanes. Three rules make the chain definite:

1. **A bar is a direct child of the plot box.** Any level between them needs its
   own definite height, and one that lacks it zeroes everything below.
2. **All columns share one grid, so the label row is shared.** A label that wraps
   to two lines must cost every column the same height, or the bar above it is
   measured against a shorter ruler than its neighbours. Make the plot
   `display:grid; grid-auto-flow:column; grid-auto-columns:1fr` with
   `grid-template-rows:1fr auto …` (one row per item in a column, exactly — a
   spare row pulls the next column's first item into the previous column), and
   give each column wrapper `display:contents`. The markup grouping stays "one
   div per column"; only the rows become shared.

   Measured on the template's own `chart-bar.html`, changing nothing but one
   label to a wrapping name: baseline offset 0 → 19px, and the fourth bar 342 →
   324px — the value never changed, the bar just lost 5%. With the shared grid
   the same label costs all four bars the same 8%, and the ratios stay exact.

3. **Every level is either `flex:none` or `flex:1`** — sized by its content, or
   taking the remainder. There is no third kind.

4. **A value label never shares the lane with the bar it labels.** If it does,
   flex has to fit label + gap + bar into the lane, so it shrinks the bar — and
   only the bars tall enough to run out of room. The scale stops being linear at
   the top: measured on `bloom/chart-bar.html`, lane 336px, label 19px, gap 6px,
   every value above 92.5% rendered at the same 310px, so **96 and 100 drew
   identically**. Under the template's own "percentages of the tallest value"
   convention the tallest bar is always 100%, so this fires on every chart.
   Reserve the label row on the lane (`padding-top`, measured once per template)
   and set both children `flex:none`; the bar then resolves against the lane
   minus that reserve, the same reserve for every column.

Grouping two bars per category still obeys this, but the group wrapper needs
`align-self:stretch`, or it is sized by content and the lane inside it collapses.

Do not "fix" a flat chart by enlarging the numbers or switching to a table. The
values are right; the container chain is not.

## How full a page should be

Measured across all 902 layouts in the 23 shared templates, so this is what the
system already does — not a target invented for the occasion:

|                                                                                  | p25 |  median | p75 |
| -------------------------------------------------------------------------------- | --: | ------: | --: |
| vertical coverage (share of the stage height that carries ink or a filled block) | 33% | **43%** | 61% |
| ink area (share of the stage area)                                               |  9% | **12%** | 16% |
| lowest ink (how far down the page the content reaches)                           | 68% | **75%** | 90% |

**Aim for the middle column.** A content page that stops at 40% of the height and
leaves the rest blank reads as unfinished; one that runs past 25% ink area reads as
a wall. Both are allowed when the material calls for it — a statement page is one
huge line at 6% coverage, a table or a longform page is legitimately dense — but
neither is the default.

Two things that are **not** the same:

- **A void at the bottom.** Content stops early and nothing follows. This is the
  one to avoid; measured on the naked layouts, 73 of 902 pages do it.
- **Air between blocks.** A title, then a band of columns centred in the space
  below it. That is composition, not a defect — do not fill it just to fill it.

If the material genuinely does not fill the page, cut a column or merge the page
into its neighbour rather than padding sentences.

## 6. Verify before delivery

### Automated advisory check

- After fonts and images settle, run `tools/run.sh` once at 1600×900; rerun only when
  the HTML changes.
- The report is the visual review, so there is no need to take screenshots, create
  contact sheets, run image recognition, or visually review slides unless the user
  explicitly asks. It measures overflow, safe area, chrome band, column alignment,
  contrast, underfill, ornament vocabulary, empty photocells, text collisions, and deck
  navigation.
- Every reported item is a recommendation, never a blocker: fix the ones worth fixing
  from the slide, element, and DOM values it names; a zero report is not required.

Run this one-liner first; it is cheap and it catches the defect above:

```js
document.querySelectorAll(".slide").length ===
  [...document.querySelector(".deck").children].filter((n) =>
    n.classList.contains("slide"),
  ).length;
```

Then **press `←` and `→` through the whole deck yourself**, plus `Home` and `End`.

For the single report above, use `SAFE=0.07` (this template's safe area is 7%, not the
probe default of 6%). Recommended targets:

```
overflow  outsideSafeArea  aboveChromeBand  columnsMisaligned
lowContrast  boxesUnderfilledV  boxesUnderfilledH
orphanSlides  indirectSlides            navigableSlides == pages
```

Authoring layouts may contain placeholders, but the delivered deck should not. An
`emptyPhotocells` reading is resolved only by an `<img>` source or a CSS `url(...)`;
`var(--ph)`, a solid fill, or a gradient is still empty. If one remains, delete its
entire media mount and reflow the page or choose a non-media layout. Do not generate an
unsupported photograph merely to clear it.

`darkPanels` is token-dependent: review it for non-mono preferred systems; report it for
`mono_ink`, where dark grounds are part of the token.

Review each `boxesOnFullBleed` reading by role: photo furniture can legitimately belong
on cover, divider, and closing pages.

### Check what the report cannot see

- Match the final HTML to the outline: titles, communication jobs, evidence, source status, and no planning notes in audience copy.
- Check the narrative sequence, chart and data labels, unresolved placeholder text, and
  motif consistency.
- Confirm from computed styles that the colour-system CSS resolved; a wrong path can
  leave the deck unstyled while every report reading looks normal.
- Confirm the prompt-selected colour-system is used exactly, or record the valid token chosen when the prompt omitted it.
- Confirm the delivered HTML contains one live `.deck`, one navigation runtime, and only the markup and CSS used by its rendered slides.

### Identity audit before delivery

First confirm the content survived: every point is still on its slide and no image or
caption appears that the material does not support. Then audit identity:

- every cream slide carries the page frame and the corner tape; every slide carries the page number;
- every collage uses 2–3 differently sized mounts in the right well; the team row and
  single-corner variants are used only for their documented page roles; every mount is
  rotated within −6° to +4° and none bleeds off the stage;
- exactly one `data-color-system` token: the prompt's valid token when supplied,
  otherwise one of the five preferred tokens;
- no media or chrome sits on top of type; no optional decoration has been invented.
- no empty `data-photocell` remains in the delivered HTML; decoration ratio is reported
  only and does not affect pass/fail.

Fix the deck and re-render before delivering if any line fails.

## Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
