---
name: data-report
description: Create a standalone 16:9 HTML presentation deck with the Data Report visual identity and direct-HTML workflow. Use when the user selects the Data Report presentation template or explicitly names data-report as the deck style. Best suited to bold, chart-led annual reports, research findings, and data-insight presentations.
---

# Data Report presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one standalone HTML file with one live `.deck`. **Every `.slide` must
  be a direct child of that `.deck`**. The runtime collects pages with
  `[...deck.children].filter(n => n.classList.contains('slide'))`; a nested slide
  renders but cannot be reached by the arrow keys. Give every slide one 16:9
  `.stage`, and include the deck CSS and keyboard-navigation script once.
- Before delivery, assert
  `document.querySelectorAll('.slide').length === [...document.querySelector('.deck').children].filter(n => n.classList.contains('slide')).length`.
- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Create one direct-child `.slide` per planned page and one 16:9 `.stage` inside each slide.

### Layout — start from a naked layout

Pick the file in [layouts/](layouts/) whose name matches the slide's job. Read
[layouts/README.md](layouts/README.md) for provenance and the full sizing audit.

| the slide is                                   | use                                                                                 |
| ---------------------------------------------- | ----------------------------------------------------------------------------------- |
| title, contents, chapter break, closing        | `cover` `toc` `section-divider` `close`                                             |
| one-page conclusion or findings                | `executive-summary` `three-insights` `numbered-findings` `action-cases` `big-quote` |
| prose or two-state comparison                  | `two-column` `comparison` loud · `comparison-ruled` quiet                           |
| KPI overview, scorecard, or metric drill-down  | `overview-kpis` `kpi-grid` `stat-highlight` `metric-deep-dive` `scorecard`          |
| period or plan variance                        | `period-comparison` `actual-vs-target`                                              |
| bar, line, area, part-to-whole, combo          | `chart-bar` `line-chart` `area-chart` `doughnut-row` `stacked-bar` `combo-chart`    |
| ranking, segment, or relationship              | `bar-ranking` `segment-comparison` `scatter-plot` `bubble-chart`                    |
| contribution, journey, cohort, or distribution | `waterfall` `funnel` `cohort-retention` `distribution-outliers`                     |
| table, matrix, or detail with summary          | `table` `heatmap-matrix` `detail-summary` `labelled-bars` `share-strip`             |
| roadmap, forecast, risk, or recommendation     | `roadmap` `forecast-scenarios` `risk-recommendations`                               |
| methods, appendix, or source-supported imagery | `methods-definitions` `appendix-index` `image-evidence`                             |

Rules carried by every layout:

- Everything structural is Flexbox. No Grid, float, or absolute positioning for
  prose.
- On rendered layout markup, do not write `width`, `max-width`, `min-width`,
  `height`, `left`, `top`, `right`, `bottom`, `flex`, or `flex-basis` in
  `cqw`, `cqh`, `px`, `vw`, or `vh` on an element that contains text.
- The safe area exists once: `.fit { padding:12cqh 8cqw 8cqh; }`. Peer columns
  are `flex:1`; an empty column collapses.
- Allowed graphical exceptions are `%` when it encodes a datum, `em` on an
  element containing no prose, and a `1px` hairline. Absolute placement is for
  text-free ornaments and fixed chrome, not content layout.
- A visible filled box takes both dimensions from content. A row is
  `flex:none`, its peer children are `flex:1`, and only a plot or
  source-supported image may fill remaining height. A single box uses
  `align-self:flex-start;max-width:100%`.
- **A media cell is centred in its region, never pinned to the top of it.** Put the
  cell inside `[data-media-lane]`; the lane takes the row's full height and centres
  the cell in it. An image sized by its own aspect ratio is shorter than the lane, so
  `align-self:flex-start` on the cell leaves a band of empty ground under the picture.
- Use the type classes rather than inventing sizes. If copy does not fit, edit or
  split the slide; do not freeze a placeholder-sized box around it.

- Preserve the template's broad colour fields, fine rules, bare figures, and
  light display type while adapting the selected structure to real content.
- Treat every slide as a projected presentation canvas. Write concise visible copy for the audience and keep one clear hierarchy of title, supporting content, and evidence on each page.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

- Read [design-system.md](design-system.md) for the deck shell, motif library, and
  required chrome.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — motifs, background treatment, chrome;
  4. every optional motif follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is accurate but visually anonymous also fails.

- Optional: [example/reference.jpg](example/reference.jpg) for the visual identity and [layouts/](layouts/) for full-slide scale, rhythm, and composition.
- A data-report slide is three independent layers. Build them in this order:

  | z-index | layer                                     | source                                             |
  | ------- | ----------------------------------------- | -------------------------------------------------- |
  | 0–2     | token ground and optional ornament        | [decoration/PLACEMENT.md](decoration/PLACEMENT.md) |
  | 40      | all audience-facing content inside `.fit` | [layouts/](layouts/) — 44 naked layouts            |
  | 45      | footer label and page number              | `decoration/PLACEMENT.md` section A                |

  `layouts/` shows the layers fused at full scale. Use it to
  judge rhythm, but take structure from `layouts/` and ornament placement from
  `decoration/PLACEMENT.md`.

- Read [composition-recipes.html](composition-recipes.html) before laying out a
  slide whose content is a quote, comparison, table, list of records, or repeated
  rows. Its three semantic packets have already been normalised into
  `layouts/big-quote.html`, `layouts/comparison.html`, and `layouts/table.html`;
  implement from those naked layouts. Do not copy fixed container-unit widths from
  the recipe file. In a record set, identifiers, codes, and
  numbers stay unbroken while only the prose column absorbs slack.
- Use the prompt's `color-system` when supplied, otherwise a preferred token from
  `design-system.md`. Inline that one `color-systems/<token>.css` in the final HTML.

#### Decoration

Decoration is not bound by the safe area: an ornament may cross it and bleed off the
stage where `PLACEMENT.md` says so. The safe area binds type and content.

Read [decoration/PLACEMENT.md](decoration/PLACEMENT.md) and render
[decoration/decoration.html](decoration/decoration.html). Apply these rules:

- The safe-area constant is **8% on both sides**. Set it once with `.fit` padding. A per-page
  padding override does not redefine the safe area; it violates it.
- The top **11%** is the chrome band. `.fit` begins at `12cqh`, so in-flow text
  starts below it.
- The only repeated drawn ornament is a small `+` cross. Normal pages carry the
  top-left/top-right pair, section dividers add bottom-right, the close adds
  bottom-left, and the one single-stat exception keeps only top-right. Crosses
  never bleed and never enter `.fit`.
- The cover uses one three-square palette swatch instead of crosses. A chart,
  coloured data field, card, grid cell, content box, and full-bleed ground are
  not optional ornaments.
- Footer label and page number are fixed chrome on every page; do not count
  them as optional decoration.
- Do not paint `--surface` or put white
  cards on the colour fields. Use `--g0..--g3` with matching `--t0..--t3`, or
  `--ink` with `--bg`.
- Raw `--accent` and `--s1..--s3` are fill colours. Text uses the readable
  `--ka` / `--k1..--k3` tokens or a matched field pair.

Decoration stays below copy. If a cross and content collide, use the documented
page-role exception; never move content outside the safe area. Never place body
copy over a photograph unless the material calls for a full-bleed image and the
copy has a source-appropriate text-safe treatment.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Identity checks while authoring

First confirm the content survived: every point is still on its slide and no
image or caption appears that the material does not support. Then audit
identity:

- every slide carries the footer label and readable two-digit page number from
  `decoration/PLACEMENT.md` section A;
- every optional ornament is either the named cross or the cover palette swatch,
  in the page-role set documented in `PLACEMENT.md`; charts, cards, fields,
  containers, grid cells, and chrome are not counted as optional ornaments;
- each page ground follows the role documented for its chosen layout;
- `surfaceUses` reports no live `--surface` element; dead CSS rules do not count;
- every text-bearing layout element passes the sizing rule above;
- exactly one `data-color-system` token, and it is one of the preferred tokens;
- keep authored ornaments clear of type; any reported geometric crossing remains an
  optional-review candidate under `Automated QA` below.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
