# Data Report

## Visual identity

A colour stage with almost no empty space: large charts, oversized numbers, fine grid lines, and huge light-weight titles. Pages feel bold, and data relationships read at a glance.

## Color system tokens

Read the prompt's `color-system` before generating. If it supplies one of the valid tokens below, use that token exactly. If it does not, choose from the tokens below according to the content, audience, mood, information density, and readability. Use only one token throughout a deck.

The presentation category documented for this template is **V (multicolour)**, with `prism` as its example token. Determine the generated deck's token using the rule above.

Use only the following snake_case values as valid tokens:

- Single-primary M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`prism`, `carnival`, `pop_art`, `bauhaus_primary`, `mint_tech`

The default color system used in `example/reference.jpg` is `prism`.
Picking a token outside this list is how a deck ends up looking like a different
template: a finance source, for instance, pulls every template toward the same
muted corporate grey unless the list stops it.

After selecting a token, read `color-systems/<token>.css`, inline that file's single CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="prism" data-safe-area="0.08"></html>
```

- Use `--bg`, `--ink`, `--soft`, and `--ph` for the page, body copy,
  secondary text, and source-supported image placeholders. The colour system
  defines `--surface`, but this template's corrected reference and all 44 naked
  layouts use it **zero times**; do not turn it into a card system.
- `--accent`, `--s1`, `--s2`, and `--s3` are raw hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected for those raw hues in v1; use them for large icons or decorative symbols. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use the contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text. Use `--kad` for accent text on an `--ink` field. When a raw hue needs higher text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour fields containing text, use `--g0` through `--g3` and pair each with the matching `--t0` through `--t3`.
- HTML/CSS components must reference colours only through `var(--...)`; derive transparency, strokes, shadows, and gradients from defined tokens as well.

Use `--g0` through `--g3` as full-bleed colour fields on most slides and rotate them across the deck. Place charts and oversized numbers directly on these fields, with text set in the matching `--t0` through `--t3`.

```css
.slide {
  background: var(--bg);
  color: var(--ink);
}
.muted {
  color: var(--soft);
}
.safe-emphasis {
  color: var(--ka);
}
.accent-shape {
  background: var(--accent);
  color: var(--oa);
}
.accent-field {
  background: var(--g0);
  color: var(--t0);
}
```

## Typography tokens

Use `Sora` as the display typeface and `Inter` as the body typeface.

```html
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link
  href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600&family=Inter:wght@300;400;500;600&display=swap"
  rel="stylesheet"
/>
```

```css
:root {
  --fd: "Sora";
  --fb: "Inter";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display:
    "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC",
    sans-serif;
  --cjk-body:
    "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC",
    sans-serif;
}

h1,
h2,
h3,
.display,
.kpi {
  font-family: var(--fd), var(--cjk-display);
  font-weight: var(--fw-display);
}
.kicker,
.label {
  font-family: var(--fd), var(--cjk-display);
  font-weight: var(--fw-label);
}
body,
p,
li,
table {
  font-family: var(--fb), var(--cjk-body);
  font-weight: var(--fw-body);
}
```

Available display weights are 400 / 500 / 600; available body weights are 300 / 400 / 500 / 600. Use `--fd` for titles, hero numbers, and section numbers; use `--fb` for body copy, labels, chart annotations, and tables. For CJK content, preserve the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the canonical template shell, normalised from `layouts/`.
Copy it into the single `<style>` block immediately after the inlined
colour-system CSS. It defines the 16:9 stage, one measured safe area, the type
scale, and the classes the rest of this document refers to. The reference's
per-string measured wrappers are evidence, not reusable layout CSS.

```css
:root {
  --r-xs: 0.2cqw;
  --r-sm: 0.2cqw;
  --r-md: 0.3cqw;
  --r-lg: 0.35cqw;
  --r-xl: 0.5cqw;
  --fd: "Sora";
  --fb: "Inter";
  --fw-display: 500;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display:
    "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC",
    sans-serif;
  --cjk-body:
    "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC",
    sans-serif;
}
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
html,
body {
  background: var(--ink);
  color: var(--ink);
  font-family: var(--fb), var(--cjk-body), sans-serif;
  -webkit-text-size-adjust: none;
  text-size-adjust: none;
}
.deck {
  scroll-snap-type: y mandatory;
  height: 100vh;
  overflow-y: scroll;
}
.slide {
  width: 100vw;
  height: 100vh;
  scroll-snap-align: start;
  display: flex;
  background: var(--ink);
}
.stage {
  position: relative;
  width: min(100vw, 177.7778vh);
  height: min(56.25vw, 100vh);
  margin: auto;
  overflow: hidden;
  container-type: size;
  background: var(--bg);
  color: var(--ink);
  border: 1px solid color-mix(in srgb, var(--ink) 12%, transparent);
  overflow-wrap: break-word;
  word-break: normal;
}
.stage * {
  overflow-wrap: break-word !important;
  word-break: normal !important;
}
.fit {
  position: absolute;
  inset: 0;
  transform-origin: top center;
  z-index: 40;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  padding: 12cqh 8cqw 8cqh;
}
img {
  max-width: 100%;
  object-fit: contain !important;
}
.photo,
[data-photocell] img {
  width: 100%;
  height: 100%;
  display: block;
}

/* The media lane owns its row's full height; the cell inside it is centred.
   An image whose box is shorter than the lane — anything carrying a fixed
   aspect-ratio — then sits in the middle of its region instead of being pinned
   to the top of it. */
[data-media-lane] {
  display: flex;
  align-items: center;
  justify-content: center;
  align-self: stretch;
}
[data-media-lane] > [data-photocell] {
  align-self: center !important;
  max-width: 100%;
  max-height: 100%;
}
/* Safety net for a cell written without the lane: a fixed aspect-ratio gives it a
   definite height, so it can never fill its lane. Auto block margins centre it
   there, and auto margins win over `align-self:flex-start`. */
[data-photocell][style*="aspect-ratio"] {
  margin-block: auto;
}

.display,
.h1,
.h2,
.h3,
.stat,
.metric,
.hero-stat {
  font-family: var(--fd), var(--cjk-display), sans-serif;
}
.display {
  font-size: 7.8cqw;
  font-weight: 400;
  line-height: 0.96;
  letter-spacing: -0.03em;
}
.h1 {
  font-size: 4.6cqw;
  font-weight: 400;
  line-height: 1.02;
  letter-spacing: -0.015em;
}
.h2 {
  font-size: 3.2cqw;
  font-weight: 400;
  line-height: 1.06;
  letter-spacing: -0.015em;
}
.h3 {
  font-size: 1.95cqw;
  font-weight: 500;
  line-height: 1.18;
}
.stat {
  font-size: 5.2cqw;
  font-weight: 500;
  line-height: 1;
  letter-spacing: -0.015em;
}
.kicker {
  font-family: var(--fd), var(--cjk-display), sans-serif;
  font-size: 1.15cqw;
  font-weight: 500;
  line-height: 1.2;
  letter-spacing: 0.2em;
  text-transform: uppercase;
}
.lead {
  font-size: 2cqw;
  font-weight: 300;
  line-height: 1.5;
}
.body {
  font-size: 1.5cqw;
  font-weight: 400;
  line-height: 1.5;
}
.cap {
  font-size: 1.2cqw;
  font-weight: 400;
  line-height: 1.4;
  letter-spacing: 0.01em;
}
.pagenum {
  position: absolute;
  right: 3cqw;
  bottom: 3.2cqh;
  font-family: var(--fd), var(--cjk-display);
  font-size: 1cqw;
  font-weight: 500;
  letter-spacing: 0.06em;
  opacity: 0.65;
  z-index: 45;
}

.metric {
  font-size: 3.6cqw;
  font-weight: 500;
  line-height: 1;
  letter-spacing: -0.01em;
}
.hero-stat {
  font-size: 10cqw;
  font-weight: 500;
  line-height: 0.85;
  letter-spacing: -0.04em;
}
.dim {
  opacity: 0.78;
}
.faint {
  opacity: 0.58;
}
.rule {
  height: 1px;
  background: currentColor;
  opacity: 0.28;
}
.card {
  border: 0.18cqw solid currentColor;
  border-top-width: 0.75cqw;
  padding: 2.3cqh 1.5cqw;
  display: flex;
  flex-direction: column;
}
.plot {
  flex: 1;
  min-height: 0;
  position: relative;
}
```

The shell intentionally contains no text-bearing tile or badge with a fixed
container-unit box. Every layout must pass the sizing rule in
[layouts/README.md](layouts/README.md).

## Signature elements

Available signature elements: `frameless-number`, `area-chart`, `combo-chart`, `line-chart`, `doughnut`, `bubble-chart`.

Visual reference: [example/reference.jpg](example/reference.jpg)

## Motif library

The complete optional ornament vocabulary is deliberately small:

1. a small SVG `+` cross, used in measured corner sets;
2. the cover's three-square palette swatch, used once instead of crosses.

Render [decoration/decoration.html](decoration/decoration.html) for the naked
vocabulary and all five page-role sets, and read
[decoration/PLACEMENT.md](decoration/PLACEMENT.md) for exact snippets and
measurements. Do not substitute generic circles, rectangles, cards, blocks,
arches, blobs, or gradients. A chart mark or a field that carries data is
content, not decoration; footer label and page number are fixed chrome.

The chart geometries named under `Signature elements` stay in the layout layer.
Start from [layouts/](layouts/) instead of extracting their measured wrappers
from the reference.

## Decoration reference profile (diagnostic only)

Measured at 1600×900 from all 15 reference pages after the reference corrections:

| measure                         | reference |
| ------------------------------- | --------: |
| crosses                         |        31 |
| crosses per page                |      2.07 |
| pages with at least two crosses |     13/15 |
| crosses bleeding off stage      |      0/31 |
| top-left / top-right            |   13 / 14 |
| bottom-right / bottom-left      |     3 / 1 |
| cover palette swatches          |         1 |
| full-bleed token fields         |     14/15 |
| image placeholders              |         0 |
| `--surface` uses                |         0 |

The cross and ground figures are whole-deck distributions, not quotas. Compare
reference/generated/n before making a claim. The exact-zero readings may gate;
the non-zero distributions may not be converted into arbitrary thresholds.

Normal content pages use the top-left/top-right pair. Section dividers add a
bottom-right cross; the close adds bottom-left. The single-stat page omits the
occupied top-left cross. The cover uses the palette swatch and no crosses. These
are the only optional page-role sets.

## Decoration safe area

The measured constant is 8% at both sides: 62 in-flow reference text runs land
at that modal left edge and the modal right inset is also 8%. Set the boundary
once with `.fit { padding:12cqh 8cqw 8cqh; }`; a slide-specific padding value
does not redefine the safe area.

Crosses stay outside `.fit`, at the measured 6cqw / 6cqh corner anchors, below
content at z-index 0–2. The top 11% is the chrome band; in-flow content begins at
12cqh. Reference readings are `outsideSafeArea=0` and `aboveChromeBand=0`.
If a cross collides with copy, use the documented page-role exception in
`decoration/PLACEMENT.md`; never move the copy outside the safe area.

## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** A label positioned with `left:88cqw` will
overflow the moment its text is longer than the author guessed, and CJK copy is
routinely wider than the Latin draft it was written against. Anchor anything in
the right third with `right:` instead of `left:`, and anything in the bottom
third with `bottom:` instead of `top:`. A block anchored to the edge it is near
grows inward, where there is room, instead of outward into nothing. Give any
absolutely-positioned text an explicit `max-width` so it wraps rather than
extends.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

Both faults hide from a quick glance at the whole deck and are obvious on the
slide itself. Before delivering, look at every slide that carries a set of
things and check that the set is aligned and that nothing touches an edge it was
not meant to touch.

## Never do this

- **Never use a disc-bulleted list.** Not one of the twenty-three V3 reference
  decks contains a single `<ul>` with default bullets, and a bulleted list is the
  fastest way to make a designed template look like a plain document. Structure a
  list as numbered rows with a hairline rule between them, as key–value rows, as
  a row of cards, or with the template's own motifs — whatever the reference deck
  does for the same job.
- Never invent a colour outside the inlined colour-system tokens; every colour
  goes through `var(--...)`.
- Never leave a slide without the chrome named in `Required chrome`.
- Never let an ornament sit on top of a title or a paragraph.
- Never generate a photograph the supplied material does not call for.

## Required chrome

Chrome is the cheapest part of a template's identity and the most frequently
dropped: across the benchmark's baseline decks, four of six templates carried a
footer on 0-2 slides out of 17. This template's reference deck carries the
following, and the count is measured from that deck, not assumed.

### Repeats on every slide

After the reference corrections made during this split, both required chrome
items carry readable text on **15 of 15** reference slides.

**Edge-pinned label** — a wide-tracked uppercase `.kicker` carrying a stable
word drawn from the deck's own subject:

```html
<div
  class="kicker"
  style="position:absolute;left:8cqw;bottom:4cqh;opacity:.6;z-index:45"
>
  Data report · 07
</div>
```

**Readable two-digit page number** — 15 of 15 slides:

```html
<div class="pagenum">01</div>
```

Carry both items on **every** slide, including cover, section dividers, and
closing. They are fixed chrome and are excluded from optional-decoration counts.
