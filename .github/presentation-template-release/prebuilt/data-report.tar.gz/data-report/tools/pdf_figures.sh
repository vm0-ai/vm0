#!/usr/bin/env bash
# Extract the source paper's figures at tight bounds, in one pass.
#
# Usage: ./pdf_figures.sh <paper.pdf> <output-dir> [figure-number ...]
#
# Prints one line per figure: number, page, pixel size, path. A figure's bounds are
# already recorded in the PDF, so read them; cropping by eye costs several rounds of
# guess, render, look and re-guess.
#
# Called with no arguments it prints the full contract: output naming, what is and
# is not extracted, exit codes, and how a figure has to reach the deck.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
exec python3 "$HERE/pdf_figures.py" "$@"
