#!/usr/bin/env bash
# Usage: ./run.sh [--final] <file-or-url> [more...]
#
# The default mode prints rendered diagnostics. --final additionally enforces
# the template's hard gates and writes one two-column QA image per deck.
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
FINAL=0
if [ "${1:-}" = "--final" ]; then
  FINAL=1
  shift
fi

if [ "$#" -eq 0 ]; then
  printf 'usage: %s [--final] <file-or-url> [more...]\n' "$0" >&2
  exit 2
fi

SESSION="template-qa-$$"
AB=(agent-browser --session "$SESSION")
trap '"${AB[@]}" close >/dev/null 2>&1 || true' EXIT

if [ "$FINAL" -eq 1 ]; then
  QA_OUTPUT_DIR="${QA_OUTPUT_DIR:-$PWD/qa}"
  mkdir -p "$QA_OUTPUT_DIR"
  QA_OUTPUT_DIR="$(cd "$QA_OUTPUT_DIR" && pwd)"
  CONFIG_B64="$(base64 -w0 "$HERE/qa-config.json")"
  CONTACT_SHEET_B64="$(base64 -w0 "$HERE/contact-sheet.js")"
fi

AUDIT_B64="$(base64 -w0 "$HERE/audit.js")"
INDEX=0
BLOCKED=0
for TARGET in "$@"; do
  INDEX=$((INDEX + 1))
  case "$TARGET" in
    http*) URL="$TARGET" ;;
    *) URL="file://$(cd "$(dirname "$TARGET")" && pwd)/$(basename "$TARGET")" ;;
  esac

  "${AB[@]}" set viewport 1600 900 >/dev/null 2>&1
  "${AB[@]}" set media reduced-motion >/dev/null 2>&1
  "${AB[@]}" open "$URL" >/dev/null 2>&1

  # Wait for fonts, images, CSS background images, and two paint frames. Without
  # this settling point the rendered readings drift.
  "${AB[@]}" eval '(async()=>{
    await Promise.race([document.fonts.ready, new Promise(r=>setTimeout(r,12000))]);
    await Promise.race([Promise.all(Array.from(document.images).filter(i=>!i.complete).map(i=>new Promise(r=>{i.onload=i.onerror=r}))),new Promise(r=>setTimeout(r,12000))]);
    const urls = s => [...s.matchAll(/url\("?([^"\)]+)"?\)/gi)].map(m=>m[1]);
    await Promise.all(Array.from(document.querySelectorAll("[data-photocell]")).map(async cell=>{
      const found=urls(getComputedStyle(cell).backgroundImage||"");
      if(!found.length){cell.dataset.photocellBackgroundLoaded="false";return;}
      const ok=await Promise.all(found.map(src=>new Promise(resolve=>{
        const im=new Image(); im.onload=()=>resolve(true); im.onerror=()=>resolve(false); im.src=src;
      })));
      cell.dataset.photocellBackgroundLoaded=String(ok.some(Boolean));
    }));
    await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
    return 1
  })()' >/dev/null 2>&1

  # SAFE=<fraction> overrides the safe-area constant for templates whose inset
  # is not 6%.
  if [ -n "${SAFE:-}" ]; then
    "${AB[@]}" eval "window.__SAFE=${SAFE};1" >/dev/null 2>&1
  fi
  if [ "$FINAL" -eq 1 ]; then
    "${AB[@]}" eval "window.__QA_FINAL=true;window.__QA_CONFIG=JSON.parse(atob('$CONFIG_B64'));1" >/dev/null 2>&1
  fi

  RAW_REPORT="$("${AB[@]}" eval -b "$AUDIT_B64" 2>&1 | tail -1)"
  REPORT="$(printf '%s' "$RAW_REPORT" | python3 -c 'import json,sys; value=json.loads(sys.stdin.read()); print(value if isinstance(value,str) else json.dumps(value))')"
  REPORT="$(printf '%s' "$REPORT" | python3 -c 'import json,sys; report=json.load(sys.stdin); report["target"]=sys.argv[1]; print(json.dumps(report,ensure_ascii=False))' "$TARGET")"

  if [ "$FINAL" -eq 1 ]; then
    TARGET_BLOCKED=0
    if printf '%s' "$REPORT" | python3 -c 'import json,sys; sys.exit(0 if json.load(sys.stdin)["hardGateFailures"] else 1)'; then
      BLOCKED=1
      TARGET_BLOCKED=1
    fi
    BASENAME="${TARGET%%\?*}"
    BASENAME="${BASENAME%/}"
    BASENAME="${BASENAME##*/}"
    BASENAME="${BASENAME%.*}"
    BASENAME="$(printf '%s' "${BASENAME:-deck}" | tr -cs '[:alnum:]_-' '-')"
    QA_IMAGE="$QA_OUTPUT_DIR/qa-$(printf '%02d' "$INDEX")-$BASENAME.png"

    # A passing gate needs no picture: the JSON verdict is the whole answer, and
    # rendering one costs a full-page screenshot for nothing. A failing gate gets the
    # offending pages at their native 1600x900 -- the two-column contact sheet halved
    # every slide, which is how a blocked run ended up re-rendering pages by hand.
    if [ "$TARGET_BLOCKED" -eq 1 ]; then
      FAIL_PAGES="$(printf '%s' "$REPORT" | python3 -c '
import json, re, sys

report = json.load(sys.stdin)
GATE = (
    "zero-height", "missing .fit", ".fit padding", "overflow \"",
    "intersects", "fit-floor overflow", "empty photocell",
    "photocell collapsed", "color-system", "chrome",
)
pages = []
for sample in report.get("samples", []):
    if not any(token in sample for token in GATE):
        continue
    match = re.match(r"p(\d+)\s", sample)
    if match and int(match.group(1)) not in pages:
        pages.append(int(match.group(1)))
print(" ".join(str(p) for p in pages[:6]))
')"
      QA_IMAGES=""
      for PAGE in $FAIL_PAGES; do
        PAGE_IMAGE="$QA_OUTPUT_DIR/qa-$(printf '%02d' "$INDEX")-$BASENAME-p$(printf '%02d' "$PAGE").png"
        "${AB[@]}" eval "(()=>{const s=document.querySelectorAll('.slide')[$PAGE-1];if(s)s.scrollIntoView({block:'start'});return 1})()" >/dev/null 2>&1
        "${AB[@]}" screenshot "$PAGE_IMAGE" >/dev/null 2>&1
        QA_IMAGES="$QA_IMAGES $PAGE_IMAGE"
      done
      printf '%s' "$REPORT" | python3 -c '
import json, sys

report = json.load(sys.stdin)
report["qaImages"] = sys.argv[1].split()
report["qaImageNote"] = (
    "One native 1600x900 capture per failing page. Open only these; every other "
    "page passed the gate."
)
print(json.dumps(report, indent=1, ensure_ascii=False))
' "$QA_IMAGES"
    else
      printf '%s' "$REPORT" | python3 -c '
import json, sys

report = json.load(sys.stdin)
report["qaImages"] = []
report["qaImageNote"] = "Gate passed; no image is rendered. Publish."
print(json.dumps(report, indent=1, ensure_ascii=False))
'
    fi
  else
    printf '%s\n' "$REPORT"
  fi
  printf '\n'
done

exit "$BLOCKED"
