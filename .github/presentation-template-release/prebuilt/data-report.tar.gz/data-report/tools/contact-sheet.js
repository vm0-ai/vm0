// Reflow the already-rendered deck into one two-column QA image. The audit runs
// before this script, at the canonical 1600x900 viewport; this changes only the
// final screenshot layout and never the measurements in the JSON report.
(() => {
  const deck = document.querySelector(".deck");
  const slides = deck
    ? [...deck.children].filter((child) => child.classList.contains("slide"))
    : [];

  if (!deck || !slides.length) {
    return JSON.stringify({ pages: 0, error: "no navigable slides" });
  }

  document.getElementById("qa-contact-sheet-style")?.remove();
  const style = document.createElement("style");
  style.id = "qa-contact-sheet-style";
  style.textContent = `
    html, body {
      width: 100% !important;
      height: auto !important;
      min-height: 0 !important;
      overflow: visible !important;
      margin: 0 !important;
      background: #d8d8d8 !important;
    }
    body { padding: 16px !important; }
    .deck {
      width: 100% !important;
      height: auto !important;
      min-height: 0 !important;
      overflow: visible !important;
      display: grid !important;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      gap: 16px !important;
      scroll-snap-type: none !important;
    }
    .deck > .slide {
      width: 100% !important;
      height: auto !important;
      min-width: 0 !important;
      aspect-ratio: 16 / 9 !important;
      overflow: hidden !important;
      scroll-snap-align: none !important;
      outline: 1px solid rgba(0, 0, 0, .2) !important;
      box-shadow: 0 2px 8px rgba(0, 0, 0, .14) !important;
    }
    .deck > .slide > .stage {
      width: 100% !important;
      height: 100% !important;
      margin: 0 !important;
    }
  `;
  document.head.appendChild(style);
  deck.scrollTop = 0;
  window.scrollTo(0, 0);

  return JSON.stringify({ pages: slides.length, columns: 2 });
})();
