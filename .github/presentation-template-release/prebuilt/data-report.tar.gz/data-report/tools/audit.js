// Template-local rendered deck audit. Run it through ./tools/run.sh. Most readings are
// page-located recommendations; --final promotes only the four named exact contracts to
// hard gates and leaves visual candidates advisory.
(async () => {
  const QA_FINAL = window.__QA_FINAL === true;
  const QA_CONFIG = window.__QA_CONFIG || { requiredChrome: [] };
  // Decoration must be declared as decoration. Content frames, cards, tiles,
  // badges, background fields, grid nodes and connectors are layout/content and
  // must never disappear from text checks or inflate ornament counts merely
  // because they are geometric. A declared decoration is still required to be
  // textless below.
  const DECO = "[data-decoration],[data-deco],[data-ornament],[data-bigcircle]";
  // These visuals may legitimately sit behind type, so intersections are review
  // candidates rather than automatic failures. The model must inspect legibility.
  const REVIEW_VISUAL =
    "[data-mosaic],[data-decoration],[data-deco],[data-ornament]";
  const ORNAMENT_VISUAL = [
    "[data-decoration]",
    "[data-deco]",
    "[data-ornament]",
    "[data-bigcircle]",
    "[data-doodle]",
    "[data-mosaic]",
    "[data-asterisk]",
    "[data-gridblock]",
    '[data-device="squares"]',
    '[data-device="sqm"]',
    '[data-device="ring"]',
    "[data-motif-root]",
  ].join(",");

  const ownText = (e) =>
    [...e.childNodes]
      .filter((n) => n.nodeType === 3)
      .map((n) => n.textContent.trim())
      .join("")
      .trim();
  const isStrictDecoration = (d) =>
    d &&
    !d.textContent.trim() &&
    !d.matches(
      "[data-photocell],[data-tile],[data-badge],[data-bbadge],[data-node],[data-connector],[data-background-field],[data-metric-disc]",
    ) &&
    !d.closest(".fit,[data-device]");

  const lum = (c) => {
    const m = (c.match(/\d+/g) || [0, 0, 0]).map(Number);
    const f = (v) => {
      v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    };
    return 0.2126 * f(m[0]) + 0.7152 * f(m[1]) + 0.0722 * f(m[2]);
  };
  const rgba = (c) => {
    const m = String(c || "").match(/[\d.]+/g);
    if (!m || m.length < 3) return null;
    return {
      r: +m[0],
      g: +m[1],
      b: +m[2],
      a: m.length > 3 ? +m[3] : 1,
    };
  };
  const sameRgb = (a, b, tolerance = 0.5) => {
    const x = rgba(a),
      y = rgba(b);
    return (
      x &&
      y &&
      Math.abs(x.r - y.r) <= tolerance &&
      Math.abs(x.g - y.g) <= tolerance &&
      Math.abs(x.b - y.b) <= tolerance
    );
  };
  const contrast = (a, b) => {
    const x = lum(a),
      y = lum(b);
    return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
  };
  const colorDistance = (a, b) => {
    const x = rgba(a),
      y = rgba(b);
    return x && y ? Math.hypot(x.r - y.r, x.g - y.g, x.b - y.b) : Infinity;
  };
  const composite = (paint, ground, opacity = 1) => {
    const p = rgba(paint),
      g = rgba(ground);
    if (!p || !g) return paint;
    const alpha = Math.max(0, Math.min(1, p.a * opacity));
    return `rgb(${Math.round(p.r * alpha + g.r * (1 - alpha))}, ${Math.round(
      p.g * alpha + g.g * (1 - alpha),
    )}, ${Math.round(p.b * alpha + g.b * (1 - alpha))})`;
  };
  const opaque = (c) => {
    const parsed = rgba(c);
    return parsed && parsed.a > 0.01;
  };
  const visible = (e) => {
    const cs = getComputedStyle(e);
    return (
      cs.display !== "none" &&
      cs.visibility !== "hidden" &&
      parseFloat(cs.opacity || "1") > 0
    );
  };
  const bgOf = (e) => {
    let n = e;
    while (n && n !== document.documentElement) {
      const c = getComputedStyle(n).backgroundColor;
      if (c && !/rgba?\(0, 0, 0, 0\)|transparent/.test(c)) return c;
      n = n.parentElement;
    }
    return "rgb(255,255,255)";
  };
  const resolvedTokenColor = (name) => {
    const probe = document.createElement("span");
    probe.style.cssText = `position:fixed;left:-9999px;color:var(${name})`;
    document.body.appendChild(probe);
    const value = getComputedStyle(probe).color;
    probe.remove();
    return value;
  };
  const hasVisibleEdge = (e, ground) => {
    const cs = getComputedStyle(e);
    const shadowColors = cs.boxShadow?.match(/rgba?\([^)]*\)/g) || [];
    if (
      shadowColors.some(
        (color) => opaque(color) && contrast(color, ground) >= 1.1,
      )
    )
      return true;
    return ["Top", "Right", "Bottom", "Left"].some((side) => {
      const width = parseFloat(cs[`border${side}Width`]) || 0;
      const style = cs[`border${side}Style`];
      const color = cs[`border${side}Color`];
      return (
        width > 0 &&
        style !== "none" &&
        opaque(color) &&
        contrast(color, ground) >= 1.1
      );
    });
  };
  const ornamentPaintColors = (root, ground) => {
    const colors = [];
    [root, ...root.querySelectorAll("*")].forEach((e) => {
      if (!visible(e)) return;
      const r = e.getBoundingClientRect();
      if (r.width < 1 || r.height < 1) return;
      const cs = getComputedStyle(e);
      let opacity = 1;
      for (let n = e; n; n = n.parentElement) {
        opacity *= parseFloat(getComputedStyle(n).opacity || "1");
        if (n === root) break;
      }
      const add = (color) => {
        if (opaque(color)) colors.push(composite(color, ground, opacity));
      };
      add(cs.backgroundColor);
      ["Top", "Right", "Bottom", "Left"].forEach((side) => {
        if (
          parseFloat(cs[`border${side}Width`]) > 0 &&
          cs[`border${side}Style`] !== "none" &&
          opaque(cs[`border${side}Color`])
        )
          add(cs[`border${side}Color`]);
      });
      if (
        /^(path|rect|circle|ellipse|polygon|polyline|line)$/i.test(e.tagName)
      ) {
        if (cs.fill !== "none") add(cs.fill);
        if (cs.stroke !== "none") add(cs.stroke);
      }
      for (const pseudo of ["::before", "::after"]) {
        const ps = getComputedStyle(e, pseudo);
        if (ps.content === "none" || ps.display === "none") continue;
        add(ps.backgroundColor);
      }
    });
    return colors;
  };
  const intersects = (a, b) =>
    Math.min(a.right, b.right) - Math.max(a.left, b.left) > 1 &&
    Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top) > 1;
  // A gate finding has to be actionable without opening a picture. Name the element
  // that failed, and when it carries no text of its own, the nearest labelled ancestor.
  const snip = (el) =>
    ((el && el.textContent) || "").trim().replace(/\s+/g, " ").slice(0, 30);
  const where = (el) => {
    if (!el) return "?";
    const tag = el.tagName.toLowerCase();
    const cls = (el.getAttribute("class") || "").trim().split(/\s+/)[0];
    const id = cls ? `${tag}.${cls}` : tag;
    let t = snip(el);
    if (t) return `${id} "${t}"`;
    for (
      let n = el.parentElement, hop = 0;
      n && hop < 3;
      n = n.parentElement, hop++
    ) {
      t = snip(n);
      if (t) return `${id} near "${t}"`;
    }
    return id;
  };
  const textRuns = (root, { excludeOverlapOk = true } = {}) => {
    const runs = [];
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (!node.textContent.trim()) continue;
      const parent = node.parentElement;
      if (
        !parent ||
        parent.closest("[data-plot-mark]") ||
        (excludeOverlapOk && parent.closest("[data-overlap-ok]"))
      )
        continue;
      const style = getComputedStyle(parent);
      if (style.display === "none" || style.visibility === "hidden") continue;
      const range = document.createRange();
      range.selectNodeContents(node);
      [...range.getClientRects()].forEach((r) => {
        if (r.width > 1 && r.height > 1) runs.push({ rect: r, parent });
      });
    }
    return runs;
  };
  const textRects = (root, options) =>
    textRuns(root, options).map((run) => run.rect);
  // Range rectangles include line leading, which makes two visibly separated lines look
  // overlapped. Trim only the semantic-collision probe to a conservative ink proxy; the
  // general geometry checks above continue to use the full rendered line rectangles.
  const inkRect = (r) => {
    const dy = r.height * 0.16;
    return {
      left: r.left,
      right: r.right,
      top: r.top + dy,
      bottom: r.bottom - dy,
      width: r.width,
      height: r.height - dy * 2,
    };
  };
  const paintsBox = (e) => {
    const cs = getComputedStyle(e);
    const bg = cs.backgroundColor || "";
    const hasBackground = bg && !/rgba?\(0, 0, 0, 0\)|transparent/.test(bg);
    const hasBorder = ["Top", "Right", "Bottom", "Left"].some(
      (side) =>
        parseFloat(cs[`border${side}Width`]) > 0 &&
        cs[`border${side}Style`] !== "none",
    );
    const hasShadow = cs.boxShadow && cs.boxShadow !== "none";
    return (
      hasBackground ||
      hasBorder ||
      hasShadow ||
      /^(IMG|SVG|CANVAS)$/.test(e.tagName)
    );
  };
  const paintedRects = (root, { excludeOverlapOk = true } = {}) =>
    [...root.querySelectorAll("*")]
      .filter(
        (e) =>
          (!excludeOverlapOk || !e.closest("[data-overlap-ok]")) &&
          paintsBox(e),
      )
      .map((e) => e.getBoundingClientRect())
      .filter((r) => r.width > 1 && r.height > 1);
  const intersectsBigcircle = (circle, rect) => {
    const cr = circle.getBoundingClientRect();
    if (!intersects(cr, rect)) return false;
    const cs = getComputedStyle(circle);
    const radius = parseFloat(cs.borderTopLeftRadius) || 0;
    const isRound = radius >= Math.min(cr.width, cr.height) * 0.4;
    if (!isRound) return true;
    const cx = (cr.left + cr.right) / 2,
      cy = (cr.top + cr.bottom) / 2;
    const rx = cr.width / 2,
      ry = cr.height / 2;
    const x = Math.max(rect.left, Math.min(cx, rect.right));
    const y = Math.max(rect.top, Math.min(cy, rect.bottom));
    return (
      ((x - cx) * (x - cx)) / (rx * rx) + ((y - cy) * (y - cy)) / (ry * ry) < 1
    );
  };
  const lengthInPixels = (value, stageRect) => {
    const n = parseFloat(value) || 0;
    if (value.endsWith("cqw") || value.endsWith("vw"))
      return (stageRect.width * n) / 100;
    if (value.endsWith("cqh") || value.endsWith("vh"))
      return (stageRect.height * n) / 100;
    return n;
  };

  const R = {
    pages: 0,
    // --- navigation: the runtime keys off [...deck.children].filter(.slide) ---
    navigableSlides: 0, // slides the arrow keys can actually reach
    orphanSlides: 0, // .slide outside every .deck. reference: 0
    indirectSlides: 0, // .slide inside a .deck but not a direct child. reference: 0
    decks: 0, // reference: 1
    // --- geometry ---
    overflow: 0, // text crossing the stage edge. reference: 0
    safeAreaShells: 0, // missing .fit or horizontal padding below data-safe-area. reference: 0
    outsideSafeArea: 0, // content inside the stage but outside the 6% safe area. reference: 0
    aboveChromeBand: 0, // text starting above 11% of stage height. reference: 0
    railOverlaps: 0, // content box crosses a declared right rail + gap. reference: 0
    textGraphicOverlaps: 0, // a declared plot mark intersects rendered text ink. reference: 0
    titleBodyOverlaps: 0, // title ink intersects later in-flow body ink or paint. reference: 0
    bodyCtaOverlaps: 0, // body ink intersects out-of-flow CTA chrome. reference: 0
    textBigcircleOverlaps: 0, // rendered text ink intersects a [data-bigcircle]. reference: 0
    textVisualOverlapCandidates: 0, // text intersects a motif/decorative visual; inspect legibility
    emptyPhotocells: 0, // media slots with no img source and no CSS url(...)
    zeroHeightBars: 0, // non-zero percentage bars rendered below one pixel. hard gate
    colorSystemFailures: 0, // data-color-system missing or not responsible for live colour tokens. hard gate
    requiredChromeFailures: 0, // required per-slide chrome role count differs from qa-config.json. hard gate
    keyboardNavigationFailures: 0, // dispatched keys do not move the live navigation state. hard gate
    // --- colour ---
    lowContrast: 0, // text under 3.0:1 against its own ground. reference: 0
    surfaceUses: 0, // rendered elements whose computed background is --surface
    surfaceVisibilityCandidates: 0, // rendered --surface panels with no visible separation from their ground
    ornamentContrastCandidates: 0, // rendered ornaments whose paint is effectively identical to their ground
    darkPanels: 0, // filled boxes >8% x >6% of stage with luminance <70
    fullBleedPages: 0, // ground colour on .stage itself
    // --- filled boxes ---
    boxesUnderfilledV: 0, // visible fill whose content reaches <75% of its height
    boxesUnderfilledH: 0, // visible fill whose text spans <80% of its width
    boxesOnFullBleed: 0, // a filled box sitting on a full-bleed page
    // --- ornaments ---
    bigOrnaments: 0,
    bigPerPage: 0,
    pagesWithPair: 0,
    bleedingPct: 0,
    smallOrnaments: 0,
    smallPerPage: 0,
    offVocabularyShapes: 0,
    samples: [],
    visualOverlapSamples: [],
    targetedReviewPages: [],
  };
  // Locate every kind of finding. One shared cap let the loudest check spend the
  // whole budget and leave the quieter ones as bare counts, which is exactly the
  // reading that cannot be acted on.
  const sampleSeen = {};
  const note = (msg) => {
    const kind = String(msg)
      .replace(/^p\d+\s+/, "")
      .replace(/["\d].*$/, "")
      .trim();
    sampleSeen[kind] = (sampleSeen[kind] || 0) + 1;
    if (sampleSeen[kind] <= 2 && R.samples.length < 24) R.samples.push(msg);
  };

  let bleed = 0,
    inside = 0,
    smallCount = 0;
  const targetedReviewPages = new Set();

  // The token must exist, provide the complete live palette, and actually control it.
  // Temporarily swapping only the root attribute gives an exact rendered-state test:
  // a copied fallback :root block does not pass as an active colour system.
  const root = document.documentElement;
  const colorToken = (root.getAttribute("data-color-system") || "").trim();
  const colorProps = ["--bg", "--surface", "--ink", "--g0", "--t0"];
  const readColorSignature = () => {
    const cs = getComputedStyle(root);
    return colorProps.map((name) => cs.getPropertyValue(name).trim());
  };
  const activeColors = readColorSignature();
  let inactiveColors = [];
  if (colorToken) {
    root.setAttribute("data-color-system", "__qa_unmatched_color_system__");
    inactiveColors = readColorSignature();
    root.setAttribute("data-color-system", colorToken);
  }
  const colorSystemActive =
    colorToken &&
    activeColors.every(Boolean) &&
    activeColors.some((value, i) => value !== inactiveColors[i]);
  if (!colorSystemActive) {
    R.colorSystemFailures++;
    const reason = !colorToken
      ? "missing data-color-system"
      : activeColors.some((value) => !value)
        ? "incomplete computed palette"
        : "data-color-system does not activate the palette";
    note(`p1 color-system ${reason}`);
  }
  const surfaceColor = activeColors[1] ? resolvedTokenColor("--surface") : "";
  const bgTokenColor = activeColors[0] ? resolvedTokenColor("--bg") : "";

  document.querySelectorAll(".slide .stage, .stage").forEach((st, pi) => {
    R.pages++;
    const sr = st.getBoundingClientRect();
    const stageBg = getComputedStyle(st).backgroundColor;
    const fullBleed =
      stageBg && !/rgba?\(0, 0, 0, 0\)/.test(stageBg) && lum(stageBg) < 0.85;
    if (fullBleed) R.fullBleedPages++;

    // A non-zero percentage datum with zero rendered height is never intentional.
    // This is the final-deck version of the canonical chart-layout regression test.
    st.querySelectorAll("*").forEach((e) => {
      const style = e.getAttribute("style") || "";
      const declared = /(?:^|;)\s*height\s*:\s*([\d.]+)%/i.exec(style);
      if (!declared || +declared[1] <= 0) return;
      if (e.getBoundingClientRect().height >= 1) return;
      // The shell's layout guard hides a decoration that hurts legibility by setting
      // display:none, and a hidden box measures zero. That is the guard doing its job,
      // not a collapsed bar, so it is reported separately and never gates.
      // The shell's layout guard hides a decoration that hurts legibility by setting
      // display:none, and a hidden box measures zero. That is the guard doing its
      // job. It is not reported at all: the author has nothing to fix, and a counter
      // that reads non-zero gets chased whatever the report calls it.
      if (e.closest("[data-guard-hidden]")) return;
      R.zeroHeightBars++;
      // A percentage height resolves against the parent. Name the parent and quote the
      // size it actually declares: the fix is almost always a height the parent is
      // missing, and "bar" is the wrong word when the element is an ornament.
      const par = e.parentElement;
      const parStyle = (par && par.getAttribute("style")) || "";
      const parSize =
        (parStyle.match(/(?:^|;)\s*(width|height)\s*:\s*[^;]+/gi) || [])
          .map((s) => s.replace(/^;\s*/, "").trim())
          .join("; ") || "no width/height";
      const kind = e.closest(
        "[data-device],[data-deco],[data-mosaic],[data-bigcircle]",
      )
        ? "ornament"
        : "bar";
      note(
        `p${pi + 1} zero-height ${kind} ${declared[1]}% ${where(e)} — parent ${par ? where(par) : "?"} declares ${parSize}`,
      );
    });

    // Required chrome is a per-template exact contract. The local qa-config names
    // roles; data-chrome keeps the check independent of copy and visual styling.
    if (QA_FINAL) {
      for (const rule of QA_CONFIG.requiredChrome || []) {
        if (rule.when === "stage-is-bg" && !sameRgb(stageBg, bgTokenColor))
          continue;
        const selector =
          rule.selector || `[data-chrome="${CSS.escape(rule.role)}"]`;
        const count = [...st.querySelectorAll(selector)].filter(visible).length;
        const min = rule.min ?? 1;
        const max = rule.max ?? min;
        if (count >= min && count <= max) continue;
        R.requiredChromeFailures++;
        note(
          `p${pi + 1} chrome ${rule.role} count ${count}, expected ${min}${max === min ? "" : `-${max}`}`,
        );
      }
    }

    // Count only live --surface paint. A dead .card rule in a <style> block no longer
    // appears here. Near-identical, edgeless panels are review candidates, not gates.
    if (surfaceColor) {
      st.querySelectorAll("*").forEach((e) => {
        if (!visible(e)) return;
        const r = e.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) return;
        const bg = getComputedStyle(e).backgroundColor;
        if (!opaque(bg) || !sameRgb(bg, surfaceColor)) return;
        R.surfaceUses++;
        const ground = bgOf(e.parentElement || st);
        if (sameRgb(ground, surfaceColor)) return;
        if (
          r.width >= sr.width * 0.08 &&
          r.height >= sr.height * 0.06 &&
          contrast(bg, ground) < 1.1 &&
          !hasVisibleEdge(e, ground)
        ) {
          R.surfaceVisibilityCandidates++;
          targetedReviewPages.add(pi + 1);
          note(
            `p${pi + 1} surface panel contrast ${contrast(bg, ground).toFixed(2)} without edge`,
          );
        }
      });
    }

    // Measure the paint that an ornament actually renders, including SVG and pseudo
    // elements. Only an ornament whose strongest paint is effectively the ground is
    // flagged; deliberately subtle but still visible motifs remain untouched.
    const ornamentRoots = [...st.querySelectorAll(ORNAMENT_VISUAL)].filter(
      (e) =>
        visible(e) &&
        !e.closest(".fit,[data-chrome]") &&
        !e.parentElement?.closest(ORNAMENT_VISUAL) &&
        !e.matches(
          "[data-photocell],[data-tile],[data-badge],[data-bbadge],[data-node],[data-connector],[data-background-field],[data-metric-disc]",
        ),
    );
    ornamentRoots.forEach((ornament) => {
      const ground = bgOf(ornament.parentElement || st);
      const paints = ornamentPaintColors(ornament, ground);
      if (!paints.length) return;
      const best = Math.max(...paints.map((paint) => contrast(paint, ground)));
      const bestDistance = Math.max(
        ...paints.map((paint) => colorDistance(paint, ground)),
      );
      // Luminance alone treats two equally dark but strongly different hues as
      // invisible. Require both near-zero luminance contrast and near-identical
      // rendered RGB before asking for review.
      if (best > 1.02 || bestDistance > 12) return;
      R.ornamentContrastCandidates++;
      targetedReviewPages.add(pi + 1);
      const role =
        ornament.getAttribute("data-decoration") ||
        ornament.getAttribute("data-ornament") ||
        ornament.getAttribute("data-device") ||
        ornament.className ||
        ornament.tagName.toLowerCase();
      note(
        `p${pi + 1} ornament ${String(role).slice(0, 24)} contrast ${best.toFixed(2)}, rgb distance ${bestDistance.toFixed(0)}`,
      );
    });

    // ---- text-level checks ----
    const fit = st.querySelector(".fit");
    const SAFE = +(
      window.__SAFE ||
      document.documentElement.dataset.safeArea ||
      0.06
    );
    if (!fit) {
      R.safeAreaShells++;
      note(`p${pi + 1} missing .fit safe-area root`);
    } else {
      const fcs = getComputedStyle(fit),
        need = sr.width * SAFE;
      const pl = parseFloat(fcs.paddingLeft) || 0,
        pr = parseFloat(fcs.paddingRight) || 0;
      if (pl < need - 3 || pr < need - 3) {
        R.safeAreaShells++;
        note(
          `p${pi + 1} .fit padding ${pl.toFixed(1)}/${pr.toFixed(1)}px < ${need.toFixed(1)}px`,
        );
      }
    }
    // content lives inside .fit and in normal flow; the persistent chrome does not and
    // is *supposed* to sit in the top band.
    //
    // .fit is ITSELF position:absolute, and canonical v3 layouts write that inline. A
    // `closest('[style*="position:absolute"]')` test therefore matches .fit for every
    // descendant and silently excludes the entire content tree: measured on the two
    // references, 0 of 224 (bloom) and 0 of 236 (meridian) text elements were ever
    // tested. That makes aboveChromeBand and outsideSafeArea read a
    // vacuous 0 on any deck that writes .fit inline, while a deck that styles .fit from
    // the class alone still gets measured — the reference and the generated deck were
    // being held to different rules. Stop the search at .fit, which is the content root.
    const inFlowContent = (e) => {
      if (!fit) return true;
      if (!fit.contains(e)) return false;
      for (let n = e; n && n !== fit; n = n.parentElement)
        if (getComputedStyle(n).position === "absolute") return false;
      return true;
    };
    st.querySelectorAll("*").forEach((e) => {
      if (isStrictDecoration(e.closest(DECO))) return;
      const isContent = inFlowContent(e);
      const t = ownText(e);
      if (t.length < 2) return;
      const r = e.getBoundingClientRect();
      if (r.width < 6 || r.height < 5) return;

      if (
        r.right > sr.right + 2 ||
        r.left < sr.left - 2 ||
        r.bottom > sr.bottom + 2 ||
        r.top < sr.top - 2
      ) {
        R.overflow++;
        // Say by how much and in which direction. "It overflows" leaves the author
        // guessing whether to trim a word or restructure the slide.
        const past = [
          r.right - sr.right > 2 &&
            `right by ${Math.round(r.right - sr.right)}px`,
          sr.left - r.left > 2 && `left by ${Math.round(sr.left - r.left)}px`,
          r.bottom - sr.bottom > 2 &&
            `bottom by ${Math.round(r.bottom - sr.bottom)}px`,
          sr.top - r.top > 2 && `top by ${Math.round(sr.top - r.top)}px`,
        ]
          .filter(Boolean)
          .join(", ");
        note(`p${pi + 1} overflow ${where(e)} — past the stage ${past}`);
      }

      // inside the stage but outside the safe area — a different defect from overflow.
      // The safe area is a template constant; measure against it, not against whatever
      // padding this particular page happened to set.
      if (isContent) {
        // The safe area is a per-template constant. bloom is 6%; measure your own as the
        // modal left edge of content on your reference (meridian: 5.6%) and pass it in as
        // window.__SAFE rather than editing this probe default.
        const safeL = sr.left + sr.width * SAFE,
          safeR = sr.right - sr.width * SAFE;
        const rg = document.createRange();
        rg.selectNodeContents(e);
        const runs = [...rg.getClientRects()].filter((x) => x.width > 2);
        if (runs.length) {
          const L = Math.min(...runs.map((x) => x.left)),
            Rr = Math.max(...runs.map((x) => x.right));
          if (L < safeL - 3 || Rr > safeR + 3) {
            R.outsideSafeArea++;
            note(
              `p${pi + 1} outside-safe "${t.slice(0, 20)}" L=${(((L - sr.left) / sr.width) * 100).toFixed(1)}%`,
            );
          }
        }
      }

      const relTop = (r.top - sr.top) / sr.height;
      if (isContent && relTop < 0.11 && relTop > -0.5) {
        R.aboveChromeBand++;
        note(`p${pi + 1} above-band "${t.slice(0, 24)}"`);
      }

      const fg = getComputedStyle(e).color,
        bg = bgOf(e);
      const a = lum(fg),
        b = lum(bg);
      const ratio = (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
      if (ratio < 3.0 && ratio > 1.05) {
        // ratio ~1 means the probe found the wrong ground
        R.lowContrast++;
        note(`p${pi + 1} contrast ${ratio.toFixed(2)} "${t.slice(0, 20)}"`);
      }
    });

    // ---- explicit layout-safety contracts ----
    // A right rail is a reserved layout region, not decoration. The template primitive
    // reduces .fit's content box by --rail-width + --rail-gap; compare those actual
    // computed edges so an inline padding regression cannot hide behind the field's z-index.
    const rail = st.querySelector(
      ':scope > [data-background-field="right-rail"]',
    );
    if (st.hasAttribute("data-right-rail") && rail && fit) {
      const railRect = rail.getBoundingClientRect();
      const fitStyle = getComputedStyle(fit);
      const contentRight =
        fit.getBoundingClientRect().right - parseFloat(fitStyle.paddingRight);
      const gapValue = fitStyle.getPropertyValue("--rail-gap").trim() || "2cqw";
      const gap = lengthInPixels(gapValue, sr);
      if (contentRight > railRect.left - gap + 1) {
        R.railOverlaps++;
        note(
          `p${pi + 1} rail-overlap ${(contentRight - (railRect.left - gap)).toFixed(1)}px`,
        );
      }
    }

    // Plot marks opt in explicitly. Compare them with text-node rectangles, not parent
    // boxes, so a chart beside a title does not fail merely because their containers span
    // the same row. data-overlap-ok is the narrow escape hatch for intentional labels.
    const type = fit ? textRects(fit) : [];
    let plotCollision = false;
    st.querySelectorAll("[data-plot-mark]").forEach((mark) => {
      const mr = mark.getBoundingClientRect();
      if (mr.width < 2 || mr.height < 2) return;
      if (type.some((tr) => intersects(mr, tr))) plotCollision = true;
    });
    if (plotCollision) {
      R.textGraphicOverlaps++;
      note(`p${pi + 1} plot-mark intersects text`);
    }

    // Three semantic collision gates. Use rendered text-node line rectangles instead of
    // transparent parent boxes; only visible paint contributes on the non-text side.
    // Unlike plot labels, these relationships have no escape hatch: a real collision
    // between semantic regions is always blocking.
    if (fit) {
      const title = [
        ...fit.querySelectorAll("h1,.h1,.display,[data-title]"),
      ].find(
        (e) =>
          inFlowContent(e) && textRects(e, { excludeOverlapOk: false }).length,
      );
      if (title) {
        const followsTitle = (e) =>
          !!(
            title.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING
          );
        const titleInk = textRuns(title, { excludeOverlapOk: false }).map(
          (run) => ({ rect: inkRect(run.rect), parent: run.parent }),
        );
        const laterText = textRuns(fit, { excludeOverlapOk: false })
          .filter(
            (run) =>
              !title.contains(run.parent) &&
              followsTitle(run.parent) &&
              !run.parent.closest("h1,.h1,.display,[data-title],[data-device]"),
          )
          .map((run) => ({ rect: inkRect(run.rect), parent: run.parent }));
        const laterPaint = [...fit.querySelectorAll("*")]
          .filter(
            (e) =>
              !title.contains(e) &&
              followsTitle(e) &&
              inFlowContent(e) &&
              !e.contains(title) &&
              !e.closest("[data-device]") &&
              paintsBox(e),
          )
          .map((e) => ({ rect: e.getBoundingClientRect(), parent: e }))
          .filter((r) => r.rect.width > 1 && r.rect.height > 1);
        let titleClash = null;
        for (const tr of titleInk) {
          const other = [...laterText, ...laterPaint].find((br) =>
            intersects(tr.rect, br.rect),
          );
          if (other) {
            titleClash = { title: tr.parent, other: other.parent };
            break;
          }
        }
        if (titleClash) {
          R.titleBodyOverlaps++;
          note(
            `p${pi + 1} title ${where(titleClash.title)} intersects ${where(titleClash.other)}`,
          );
        }
      }

      const bodyInk = textRuns(fit, { excludeOverlapOk: false })
        .filter(
          (run) =>
            !run.parent.closest(
              "h1,h2,h3,.h1,.h2,.h3,.display,.kicker,[data-title],[data-device]",
            ),
        )
        .map((run) => ({ rect: inkRect(run.rect), parent: run.parent }));
      const floatingCtas = [
        ...st.querySelectorAll('[data-device="cta"]'),
      ].filter((cta) => {
        const pos = getComputedStyle(cta).position;
        return !fit.contains(cta) || pos === "absolute" || pos === "fixed";
      });
      const ctaPaint = floatingCtas.flatMap((cta) =>
        [
          ...(paintsBox(cta) ? [cta.getBoundingClientRect()] : []),
          ...paintedRects(cta, { excludeOverlapOk: false }),
          ...textRects(cta, { excludeOverlapOk: false }),
        ].map((rect) => ({ rect, parent: cta })),
      );
      let ctaClash = null;
      for (const br of bodyInk) {
        const cr = ctaPaint.find((c) => intersects(br.rect, c.rect));
        if (cr) {
          ctaClash = { body: br.parent, cta: cr.parent };
          break;
        }
      }
      if (ctaClash) {
        R.bodyCtaOverlaps++;
        note(
          `p${pi + 1} body ${where(ctaClash.body)} intersects cta ${where(ctaClash.cta)}`,
        );
      }
    }

    const stageInk = textRuns(st, { excludeOverlapOk: false })
      .filter((run) => !run.parent.closest("[data-bigcircle]"))
      .map((run) => ({ rect: inkRect(run.rect), parent: run.parent }));
    let circleCollision = null;
    st.querySelectorAll("[data-bigcircle]").forEach((circle) => {
      if (circleCollision) return;
      const circleRect = circle.getBoundingClientRect();
      const isStructuralField =
        (circleRect.width > sr.width * 0.3 ||
          circleRect.height > sr.height * 0.55) &&
        !!circle.querySelector("h1,h2,h3,.h1,.h2,.h3,.display,[data-title]");
      if (isStructuralField) return;
      // A textless circle below .fit is a background field, not an occluding motif.
      // Label-bearing circles are checked regardless of z-order because their fill can
      // erase same-colour type even when the text layer itself paints above the circle.
      const circleZ = parseInt(getComputedStyle(circle).zIndex, 10) || 0;
      const fitZ = fit ? parseInt(getComputedStyle(fit).zIndex, 10) || 0 : 0;
      if (!circle.textContent.trim() && circleZ < fitZ) return;
      const hitRun = stageInk.find((tr) =>
        intersectsBigcircle(circle, tr.rect),
      );
      if (hitRun) circleCollision = { circle, text: hitRun.parent };
    });
    if (circleCollision) {
      R.textBigcircleOverlaps++;
      note(
        `p${pi + 1} bigcircle ${where(circleCollision.circle)} intersects ${where(circleCollision.text)}`,
      );
    }

    // Decorative visuals can cross type intentionally, so this remains advisory.
    // Name the page and make it available in the QA contact sheet; opening that already
    // generated image is optional and never requires another screenshot pass.
    const reviewVisuals = [...st.querySelectorAll(REVIEW_VISUAL)].filter(
      (v) => {
        if (v.parentElement && v.parentElement.closest(REVIEW_VISUAL))
          return false;
        const cs = getComputedStyle(v),
          r = v.getBoundingClientRect();
        return (
          cs.display !== "none" &&
          cs.visibility !== "hidden" &&
          parseFloat(cs.opacity || "1") > 0 &&
          r.width > 2 &&
          r.height > 2
        );
      },
    );
    const reviewText = textRuns(st, { excludeOverlapOk: false })
      .filter((run) => !run.parent.closest(REVIEW_VISUAL))
      .map((run) => ({ ...run, rect: inkRect(run.rect) }));
    const visualHit = reviewText.find((run) =>
      reviewVisuals.some((v) =>
        intersects(run.rect, v.getBoundingClientRect()),
      ),
    );
    if (visualHit) {
      R.textVisualOverlapCandidates++;
      targetedReviewPages.add(pi + 1);
      if (R.visualOverlapSamples.length < 12)
        R.visualOverlapSamples.push(
          `p${pi + 1} "${visualHit.parent.textContent.trim().slice(0, 36)}"`,
        );
    }

    // Solid fills and gradients are placeholders. run.sh preloads CSS background URLs
    // and stamps the cell only after a successful load; an unverified or broken URL is
    // therefore a failure just like a broken <img>.
    st.querySelectorAll("[data-photocell]").forEach((cell) => {
      const img = cell.matches("img") ? cell : cell.querySelector("img");
      const hasImgSource = !!(
        img &&
        (img.currentSrc ||
          img.getAttribute("src") ||
          img.getAttribute("srcset")) &&
        img.complete &&
        img.naturalWidth > 0 &&
        img.naturalHeight > 0
      );
      const hasLoadedCssImage =
        cell.dataset.photocellBackgroundLoaded === "true";
      // A loaded source is not a rendered picture. A cell whose own box collapses
      // paints nothing, and the img element reports a healthy naturalWidth all the
      // same, so the source test alone passes a visibly empty slot.
      const cellBox = cell.getBoundingClientRect();
      if (cellBox.width < 2 || cellBox.height < 2) {
        R.emptyPhotocells++;
        note(
          `p${pi + 1} photocell collapsed ${Math.round(cellBox.width)}x${Math.round(cellBox.height)} ${where(cell)}`,
        );
        return;
      }
      if (hasImgSource || hasLoadedCssImage) return;
      R.emptyPhotocells++;
      note(`p${pi + 1} empty photocell ${where(cell)}`);
    });

    // ---- filled boxes ----
    st.querySelectorAll("*").forEach((e) => {
      const cs = getComputedStyle(e),
        bg = cs.backgroundColor;
      if (!bg || /rgba?\(0, 0, 0, 0\)/.test(bg)) return;
      const r = e.getBoundingClientRect();
      if (r.width < sr.width * 0.08 || r.height < sr.height * 0.06) return;
      if (e.querySelector("canvas,img")) return;
      if (e === st) return;
      const br = cs.borderRadius || "";
      const round =
        /50%|9999px|999px/.test(br) || parseFloat(br) >= r.width * 0.45;
      if (round) return; // a disc or pill is not 'underfilled'

      if (lum(bg) < 0.09) {
        R.darkPanels++;
        note(`p${pi + 1} dark panel`);
      }
      if (fullBleed) {
        R.boxesOnFullBleed++;
        note(`p${pi + 1} box on full-bleed page`);
      }

      const parent = e.parentElement;
      let peers = false;
      if (parent) {
        const pcs = getComputedStyle(parent);
        if (pcs.display === "grid" && parent.children.length >= 2) peers = true;
        else if (
          pcs.display === "flex" &&
          pcs.flexDirection === "row" &&
          [...parent.children].filter(
            (k) => getComputedStyle(k).flexGrow !== "0",
          ).length >= 2
        )
          peers = true;
      }

      let inkBottom = 0,
        L = Infinity,
        Rt = -Infinity;
      e.querySelectorAll("*").forEach((k) => {
        if (ownText(k).length < 1) return;
        const rg = document.createRange();
        rg.selectNodeContents(k);
        [...rg.getClientRects()].forEach((x) => {
          if (x.width < 2) return;
          inkBottom = Math.max(inkBottom, x.bottom);
          L = Math.min(L, x.left);
          Rt = Math.max(Rt, x.right);
        });
      });
      if (!inkBottom) return;
      const pad = parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight);
      if (!peers && (inkBottom - r.top) / r.height < 0.75) {
        R.boxesUnderfilledV++;
        note(`p${pi + 1} box underfilled V`);
      }
      if (!peers && isFinite(L) && (Rt - L + pad) / r.width < 0.8) {
        R.boxesUnderfilledH++;
        note(`p${pi + 1} box underfilled H`);
      }
    });

    // ---- declared decoration ----
    // Do not infer decoration from geometry. In particular, an empty SVG may be
    // a chart or an icon inside a content cell; a rectangle may be a background
    // field; and tiles/nodes/connectors are layout vocabulary. Only explicitly
    // declared, textless, non-content elements enter these diagnostic counts.
    let big = [...st.querySelectorAll(DECO)].filter((d) => {
      if (!isStrictDecoration(d)) return false;
      const r = d.getBoundingClientRect();
      return r.width >= 8 && r.height >= 8;
    });
    R.bigOrnaments += big.length;
    if (big.length >= 2) R.pagesWithPair++;
    big.forEach((d) => {
      const r = d.getBoundingClientRect();
      const out =
        r.left < sr.left - 1 ||
        r.right > sr.right + 1 ||
        r.top < sr.top - 1 ||
        r.bottom > sr.bottom + 1;
      out ? bleed++ : inside++;
      const svg = d.querySelector("svg");
      const marked = d.matches(DECO);
      if (svg && marked) {
        const rect = svg.querySelectorAll("rect").length,
          path = svg.querySelectorAll("path").length,
          circ = svg.querySelectorAll("circle,ellipse").length;
        const known =
          (rect === 4 && !path && !circ) || (path === 1 && !rect && !circ);
        if (!known) {
          R.offVocabularyShapes++;
          note(`p${pi + 1} off-vocabulary shape`);
        }
      }
    });
    smallCount += st.querySelectorAll(
      '[data-decoration-size="small"],[data-deco-small]',
    ).length;
  });

  // ---- navigation structure ----
  // The deck runtime collects slides with [...deck.children].filter(n => n.classList
  // .contains('slide')). A slide nested one level deeper renders fine and is unreachable
  // by keyboard. One generated deck had 27 slides and navigated 2 of them.
  const decks = [...document.querySelectorAll(".deck")];
  const allSlides = [...document.querySelectorAll(".slide")];
  R.decks = decks.length;
  R.navigableSlides = decks.reduce(
    (n, d) =>
      n + [...d.children].filter((c) => c.classList.contains("slide")).length,
    0,
  );
  R.orphanSlides = allSlides.filter((s) => !s.closest(".deck")).length;
  R.indirectSlides = allSlides.filter((s) => {
    const d = s.closest(".deck");
    return d && s.parentElement !== d;
  }).length;
  if (R.orphanSlides || R.indirectSlides)
    note(`nav: ${allSlides.length} slides, ${R.navigableSlides} reachable`);

  // Exercise the live key handler, not merely the DOM structure. Reduced motion is set
  // by run.sh, so the state change is deterministic and does not wait for animation.
  if (QA_FINAL && allSlides.length > 1) {
    const frame = () =>
      new Promise((resolve) =>
        requestAnimationFrame(() => requestAnimationFrame(resolve)),
      );
    const press = async (key) => {
      document.dispatchEvent(
        new KeyboardEvent("keydown", {
          key,
          code: key,
          bubbles: true,
          cancelable: true,
        }),
      );
      await frame();
    };
    const marked = () =>
      allSlides.findIndex(
        (slide) => slide.getAttribute("aria-current") === "page",
      );
    const nearest = () => {
      const deck = decks[0];
      if (!deck) return -1;
      const top = deck.getBoundingClientRect().top;
      return allSlides.reduce(
        (best, slide, i) => {
          const distance = Math.abs(slide.getBoundingClientRect().top - top);
          return distance < best.distance ? { i, distance } : best;
        },
        { i: -1, distance: Infinity },
      ).i;
    };
    const index = () => {
      const active = marked();
      return active >= 0 ? active : nearest();
    };
    const observed = [];
    await press("Home");
    observed.push(index());
    await press("End");
    observed.push(index());
    await press("Home");
    document.dispatchEvent(
      new KeyboardEvent("keydown", {
        key: "ArrowRight",
        code: "ArrowRight",
        bubbles: true,
        cancelable: true,
      }),
    );
    await press("ArrowRight");
    observed.push(index());
    const expected = [
      0,
      allSlides.length - 1,
      Math.min(2, allSlides.length - 1),
    ];
    if (observed.some((value, i) => value !== expected[i])) {
      R.keyboardNavigationFailures++;
      note(
        `p1 keyboard navigation ${observed.join("/")} expected ${expected.join("/")}`,
      );
    }
    await press("Home");
  }

  R.smallOrnaments = smallCount;
  R.bigPerPage = +(R.bigOrnaments / R.pages).toFixed(2);
  R.smallPerPage = +(R.smallOrnaments / R.pages).toFixed(3);
  R.pagesWithPairPct = +(R.pagesWithPair / R.pages).toFixed(2);
  R.bleedingPct = +(bleed / (bleed + inside || 1)).toFixed(3);
  R.fullBleedPct = +(R.fullBleedPages / R.pages).toFixed(2);
  R.layoutSafetyFailures =
    R.safeAreaShells +
    R.outsideSafeArea +
    R.emptyPhotocells +
    R.railOverlaps +
    R.textGraphicOverlaps +
    R.titleBodyOverlaps +
    R.bodyCtaOverlaps +
    R.textBigcircleOverlaps;
  // Every counter added here reads exactly 0 on this template's own reference deck
  // and on all 903 shipped layouts. Counters whose reference is non-zero
  // (aboveChromeBand, both underfill counts, surfaceUses) stay
  // report-only: a hard zero for them would reject the reference itself.
  R.hardGateFailures = QA_FINAL
    ? R.zeroHeightBars +
      R.colorSystemFailures +
      R.requiredChromeFailures +
      R.keyboardNavigationFailures +
      R.overflow +
      R.orphanSlides +
      R.indirectSlides +
      R.safeAreaShells +
      R.emptyPhotocells +
      R.titleBodyOverlaps +
      R.bodyCtaOverlaps +
      R.textBigcircleOverlaps
    : 0;
  R.status = QA_FINAL
    ? R.hardGateFailures
      ? "BLOCKED"
      : "READY_TO_PUBLISH"
    : "AUDIT_COMPLETE";
  R.targetedReviewPages = [...targetedReviewPages].sort((a, b) => a - b);

  // Forty counters, thirty-eight of them zero, printed next to READY_TO_PUBLISH is an
  // invitation to go looking, and going looking is what once put 45% of a run after the
  // gate had already passed. A zero is not a finding. So a pass says pass and what to do
  // next, and nothing else; a block names only what is actually non-zero, with the
  // counters that block kept in their own object so nobody has to check a list to learn
  // which of them matters.
  const GATE_KEYS = [
    "zeroHeightBars",
    "colorSystemFailures",
    "requiredChromeFailures",
    "keyboardNavigationFailures",
    "overflow",
    "orphanSlides",
    "indirectSlides",
    "safeAreaShells",
    "emptyPhotocells",
    "titleBodyOverlaps",
    "bodyCtaOverlaps",
    "textBigcircleOverlaps",
  ];
  // Shape of the deck, not a verdict on it: these stay whatever they read.
  const STRUCTURAL = ["pages", "navigableSlides", "decks"];
  // layoutSafetyFailures is the aggregate that used to sit next to READY_TO_PUBLISH and
  // contradict it. Its parts are now either in `blocking` or gone.
  const SUPPRESSED = ["layoutSafetyFailures", "hardGateFailures", "status"];

  const nonZero = (keys) => {
    const out = {};
    for (const k of keys) if (R[k]) out[k] = R[k];
    return out;
  };

  const emitted = {};
  for (const k of STRUCTURAL) emitted[k] = R[k];
  emitted.status = R.status;
  emitted.hardGateFailures = R.hardGateFailures;

  if (R.status === "READY_TO_PUBLISH") {
    emitted.next = "publish";
  } else {
    if (QA_FINAL) {
      emitted.blocking = nonZero(GATE_KEYS);
      emitted.next = "fix every finding under `blocking`, then run this command again";
    } else {
      emitted.next = "this is the diagnostic pass; run with --final before publishing";
    }
    const advisory = nonZero(
      Object.keys(R).filter(
        (k) =>
          typeof R[k] === "number" &&
          !GATE_KEYS.includes(k) &&
          !STRUCTURAL.includes(k) &&
          !SUPPRESSED.includes(k),
      ),
    );
    if (Object.keys(advisory).length) emitted.advisory = advisory;
    if (R.samples.length) emitted.samples = R.samples;
    if (R.visualOverlapSamples.length)
      emitted.visualOverlapSamples = R.visualOverlapSamples;
    if (R.targetedReviewPages.length)
      emitted.targetedReviewPages = R.targetedReviewPages;
  }

  return JSON.stringify(emitted, null, 1);
})();
