#!/usr/bin/env python3
"""Extract a paper's figures at tight bounds, in one pass.

A figure in a typeset paper is the band between the caption that names it and the
last line of body text above that caption. Inside that band the figure itself is a
set of vector drawings and raster images; their union is the crop. Reading that
union from the PDF is exact, which is the whole point: cropping by eye takes three
rounds of guess, render, look, and re-guess.

Usage:
  pdf_figures.sh <paper.pdf> <output-dir> [figure-number ...]

  Naming no figure numbers extracts every figure in the paper. One invocation
  reads every page either way, so there is nothing to gain from calling it once
  per figure.

Prints one line per extracted figure, and nothing else:
  figure 2  page 4  1180x742  out/figure-02.png

Contract:
  - Output lands at <output-dir>/figure-NN.png, zero-padded, rendered at 3x. The
    names are predictable, so stdout does not have to be parsed to find them.
  - Only `Figure N` and `Fig. N` captions are extracted. A `Table N` caption
    bounds the band above a figure but is never itself extracted.
  - pymupdf installs itself on first use. Installing it beforehand only costs a
    step.
  - Exit 0 wrote at least one figure, 1 found no figure captions, 2 was called
    with the wrong arguments. Failures write nothing to stdout.
  - The deck is one directly openable HTML file, so a PNG on disk cannot be
    referenced by path. Embed whichever figures you use as data URIs.
"""

from __future__ import annotations

import importlib
import re
import site
import subprocess
import sys
from pathlib import Path

CAPTION = re.compile(r"^\s*(?:Figure|Fig\.?)\s*(\d+)\s*[:.]?\s", re.IGNORECASE)
ANY_CAPTION = re.compile(
    r"^\s*(?:Figure|Fig\.?|Table)\s*(\d+)\s*[:.]?\s", re.IGNORECASE
)
ZOOM = 3.0
MARGIN = 6.0


def load_pymupdf():
    try:
        import pymupdf  # noqa: PLC0415

        return pymupdf
    except ImportError:
        pass
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "--quiet",
         "--break-system-packages", "--disable-pip-version-check",
         "--no-warn-script-location", "pymupdf"],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    # On a machine that has never had a user install, pip creates the user site
    # directory only now, and a directory that did not exist when this interpreter
    # started is not on sys.path. Without these two lines the import below fails
    # with ModuleNotFoundError on exactly the first run and succeeds ever after,
    # which is the worst way for it to fail.
    user_site = site.getusersitepackages()
    if user_site not in sys.path:
        sys.path.append(user_site)
    importlib.invalidate_caches()

    import pymupdf  # noqa: PLC0415

    return pymupdf


def union(boxes):
    if not boxes:
        return None
    x0 = min(b[0] for b in boxes)
    y0 = min(b[1] for b in boxes)
    x1 = max(b[2] for b in boxes)
    y1 = max(b[3] for b in boxes)
    return [x0, y0, x1, y1]


def figure_bbox(page, caption_rect, captions, blocks, pymupdf):
    """The band between this caption and the previous one, tightened to what is drawn.

    Body text is text, not paint, so a union of the page's drawings and images inside
    the band lands on the figure and nothing else. Bounding the band by the previous
    caption rather than by the previous line of text matters: a vector figure carries
    its own labels, and those labels are text blocks sitting immediately above the
    caption, which would otherwise collapse the band to nothing.
    """
    # A caption spans its own column, so its horizontal range is the column. Without
    # this a two-column page hands back both figures in one crop, plus the caption
    # of whichever one sits lower.
    tol = page.rect.width * 0.02
    col0, col1 = caption_rect[0] - tol, caption_rect[2] + tol

    def in_column(x0, x1):
        # Most of the element has to sit in this column. Testing the centre alone lets
        # the neighbouring figure's legend bleed into the crop.
        width = max(x1 - x0, 0.01)
        inside = max(0.0, min(x1, col1) - max(x0, col0))
        return inside / width >= 0.6

    top = 0.0
    for c in captions:
        if not in_column(c[2], c[3]):
            continue
        if c[1] <= caption_rect[1] - 1 and c[1] > top:
            top = c[1]
    band = (top, caption_rect[1])
    if band[1] - band[0] < 20:
        return None

    painted = []
    for d in page.get_drawings():
        r = d.get("rect")
        if r is None:
            continue
        if (
            r.y0 >= band[0] - 2
            and r.y1 <= band[1] + 2
            and r.width > 1
            and r.height > 1
            and in_column(r.x0, r.x1)
        ):
            painted.append([r.x0, r.y0, r.x1, r.y1])
    for info in page.get_image_info():
        r = info.get("bbox")
        if (
            r
            and r[1] >= band[0] - 2
            and r[3] <= band[1] + 2
            and in_column(r[0], r[2])
        ):
            painted.append(list(r))

    box = union(painted)
    if box is None or box[2] - box[0] < 20 or box[3] - box[1] < 20:
        # A figure typeset entirely from text -- a table, a formula block. The band
        # itself is the crop.
        box = [max(0.0, col0), band[0], min(page.rect.width, col1), band[1]]
    else:
        # A label that overhangs the drawing must not be sliced off.
        for b in blocks:
            if b[6] != 0:
                continue
            if b[1] >= band[0] - 2 and b[3] <= band[1] + 2:
                if b[2] > box[0] and b[0] < box[2] and in_column(b[0], b[2]):
                    box = union([box, [b[0], b[1], b[2], b[3]]])

    # The bottom margin must not reach into the caption. A crop that carries the words
    # "Figure 3: ..." is a picture with text in it, which is the one thing an author
    # then feels obliged to go and check.
    bottom = min(page.rect.height, box[3] + MARGIN)
    bottom = min(bottom, caption_rect[1] - 2)
    return [
        max(0.0, box[0] - MARGIN),
        max(0.0, box[1] - MARGIN),
        min(page.rect.width, box[2] + MARGIN),
        max(box[1] + 1, bottom),
    ]


def main() -> int:
    if len(sys.argv) < 3:
        print(__doc__.strip(), file=sys.stderr)
        return 2
    pdf_path = Path(sys.argv[1])
    out_dir = Path(sys.argv[2])
    wanted = {int(a) for a in sys.argv[3:]} if len(sys.argv) > 3 else None
    out_dir.mkdir(parents=True, exist_ok=True)

    pymupdf = load_pymupdf()
    doc = pymupdf.open(pdf_path)
    seen = set()
    found = 0

    for page_index in range(doc.page_count):
        page = doc[page_index]
        blocks = page.get_text("blocks")
        captions = [
            (b[1], b[3], b[0], b[2])
            for b in blocks
            if b[6] == 0 and ANY_CAPTION.match(b[4])
        ]
        for b in blocks:
            if b[6] != 0:
                continue
            match = CAPTION.match(b[4])
            if not match:
                continue
            number = int(match.group(1))
            if number in seen or (wanted is not None and number not in wanted):
                continue
            box = figure_bbox(
                page, [b[0], b[1], b[2], b[3]], captions, blocks, pymupdf
            )
            if box is None:
                continue
            clip = pymupdf.Rect(*box)
            pix = page.get_pixmap(matrix=pymupdf.Matrix(ZOOM, ZOOM), clip=clip)
            out = out_dir / f"figure-{number:02d}.png"
            pix.save(out)
            seen.add(number)
            found += 1
            print(
                f"figure {number}  page {page_index + 1}  "
                f"{pix.width}x{pix.height}  {out}"
            )

    if not found:
        print("no figure captions found", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
