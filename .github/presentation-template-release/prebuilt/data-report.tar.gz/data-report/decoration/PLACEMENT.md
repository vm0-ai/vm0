# data-report — decoration placement

measured from the original reference deck: 15 pages at 1600×900. These are
data-report numbers, not bloom numbers.

Open `decoration.html` to see the complete vocabulary and all five page-role
sets rendered without prose.

There is no `item-sets.html`: data-report has no optional motif attached to each
member of a peer content set. The corner cross attaches to a page role, never to
a card, tile, content box, grid cell, node, or connector.

## Layer model

| z-index | layer                                               |
| ------- | --------------------------------------------------- |
| 0–2     | colour ground, corner crosses, cover palette swatch |
| 40      | all audience-facing content inside `.fit`           |
| 45      | footer label and page number                        |

Decoration is outside `.fit`. If a cross and content collide, omit or move the
cross according to the measured exception below; never move the content outside
its 8% safe area.

## A · Required chrome — every page

Two text items are required after the reference correction made during this
split:

- **footer label**, bottom-left: `.kicker`,
  `left:8cqw; bottom:4cqh; opacity:.6`;
- **page number**, bottom-right: `.pagenum`,
  `right:3cqw; bottom:3.2cqh`, two digits.

The original reference carried the footer label on 14/15 and blank page-number
elements on three section dividers. That contradicted its own Required chrome
section. The reference now carries readable text in both places on all 15
pages.

```html
<div
  class="kicker"
  style="position:absolute;left:8cqw;bottom:4cqh;opacity:.6;z-index:45"
>
  Data report &nbsp;·&nbsp; 07
</div>
<div class="pagenum">07</div>
```

The cover may use the domain as its footer label. The closing page keeps the
standard footer even when a contact line also appears in the content.

## B · The corner cross — the repeated motif

The only repeated drawn ornament is a small `+` cross made from one SVG path.

Measured reference:

| measure                    |             reference |
| -------------------------- | --------------------: |
| total crosses              |                **31** |
| crosses per page           |              **2.07** |
| pages carrying 2 or more   |       **13/15 = 87%** |
| crosses bleeding off stage |         **0/31 = 0%** |
| top-left                   |                **13** |
| top-right                  |                **14** |
| bottom-right               |                 **3** |
| bottom-left                |                 **1** |
| CSS size                   | **1.0–1.6cqw square** |

They never bleed. Top crosses sit at `6cqw / 6cqh`. Lower crosses sit
`6cqw` from the side and `7cqh` from the bottom, clearing the footer.

The stroke is `currentColor`, not a fixed scheme hue. That makes it
`--t0..--t3` on a colour field and `--ink` on the white cover.

```html
<svg
  class="dot"
  data-decoration="corner-cross"
  data-cross="top-right"
  style="position:absolute;right:6cqw;top:6cqh;width:1.4cqw;height:1.4cqw;z-index:2"
  viewBox="0 0 24 24"
  aria-hidden="true"
>
  <path
    d="M12 4 V20 M4 12 H20"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
  />
</svg>
```

The reference uses CSS `width` and `height` here because this is a
text-free ornament. The sizing ban still applies to every element that contains
text.

## C · Page-role sets

### Normal content and contents pages

Use the diagonal top pair: one larger cross at top-left, one slightly smaller at
top-right. This is the reference treatment on p2, p4, p5, p7–p10, p13, and p14.

### Section divider

Use the top pair plus one small cross at bottom-right. Reference p3, p6, p11.

### Closing page

Use the top pair plus one small cross at bottom-left. Reference p15.

### Single-stat exception

Reference p12 carries only the top-right cross because the kicker and 8.7B
figure occupy the top-left. This is the only one-cross page. Omit the colliding
cross; do not move it into the middle of the stage.

The cover does not use crosses. It uses the palette swatch in D.

## D · Cover palette swatch — once per deck

Three adjacent 3cqw squares at `right:8cqw; top:8cqh`, with a 1cqw gap.
Order: `--accent`, `--s2`, `--s1`.

```html
<div
  data-decoration="cover-palette"
  data-palette="cover"
  style="position:absolute;right:8cqw;top:8cqh;display:flex;gap:1cqw;z-index:2"
  aria-hidden="true"
>
  <span style="width:3cqw;height:3cqw;background:var(--accent)"></span>
  <span style="width:3cqw;height:3cqw;background:var(--s2)"></span>
  <span style="width:3cqw;height:3cqw;background:var(--s1)"></span>
</div>
```

Do not turn the swatch into a legend or add words inside it.

## E · Ground rhythm — almost every page is a field

Measured ground distribution:

| ground  | pages |
| ------- | ----: |
| `--bg`  |     1 |
| `--g0`  |     5 |
| `--g1`  |     2 |
| `--g2`  |     2 |
| `--g3`  |     2 |
| `--ink` |     3 |

**14/15 pages (93%) are full-bleed colour fields.** The white page is the
cover. Rotate `--g0..--g3` and `--ink`; pair each `--gN` with its
`--tN`, and pair `--ink` with `--bg`.

This is a page-role profile, not a per-slide score threshold. Report the
generated distribution before treating it as a gate.

## F · What is not decoration

The area, combo, line, doughnut, bar, and bubble graphics carry data. They stay
inside the layout layer and do not count toward the ornament budget.

The three colour fields on reference p5 also carry categories and prose. They
produce `boxesOnFullBleed=3`, and that is a legitimate reference reading.
Report that metric; do not gate it at zero.

A source-supported photograph is content. The reference fills zero image
placeholders. Use `layouts/image-evidence.html` only when the material itself
contains or requires that visual; otherwise delete the frame.

## G · Vocabulary boundary

The complete decorative vocabulary is:

1. top-left / top-right / lower-corner `+` cross;
2. the three-square cover palette swatch;
3. the stage's full-bleed token ground;
4. footer label and page number chrome.

Do not invent blobs, flowers, plain decorative circles, arches, gradients,
floating cards, or large geometric blocks. A circle whose area encodes a value
in `bubble-chart` is data, not an excuse to sprinkle circles elsewhere.

`--surface` is absent from the corrected reference and all layouts. A white or
grey generic card over a colour field is not this template.

## H · Exact checks and report-only checks

Reference after correction:

```
decks / navigable / orphan / indirect   1 / 15 / 0 / 0
overflow                                0
outsideSafeArea                         0
aboveChromeBand                         0
lowContrast                             0
surfaceUses                             0
boxesUnderfilledV / H                   0 / 0
boxesOnFullBleed                        3  report-only
fullBleedPages                         14  distribution
crosses                                31  distribution
crosses/page                          2.07  distribution
crosses bleeding                        0
declared optional ornaments             32  (31 crosses + 1 cover palette)
```

The zero rows can gate. The non-zero rows must be compared as
reference/generated/n and may not be converted into an arbitrary threshold.
