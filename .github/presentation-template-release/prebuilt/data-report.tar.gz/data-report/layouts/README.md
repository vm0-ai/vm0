# data-report — naked layouts

52 layouts, separated from the corner crosses, footer chrome, palette swatches, and
ground rhythm in [../decoration/PLACEMENT.md](../decoration/PLACEMENT.md).

`_shell.html` is the head, fonts, colour-system link, type scale, and safe area.
It is not a slide. `_base.css` is the same shell extracted once for the newer
layout files; it contains no layout-specific composition.

## The rule that all 52 satisfy

**No container- or viewport-unit sizing on anything that holds text.**

There are zero `width`, `max-width`, `min-width`, `height`, `left`,
`top`, `right`, `bottom`, `flex`, or `flex-basis` values in
`cqw`, `cqh`, `px`, `vw`, or `vh` on the rendered layout markup. The §3 audit
reads **0** across all 52 files.

This includes `flex:0 0 4cqw`: the basis freezes a text box just as surely as
a width. The checkable exceptions are:

- placement of an out-of-flow element, where `left/top/right/bottom` says where
  it goes rather than how large its text box is;
- a `height:1px` hairline;
- `%` in a chart datum — a bar length, column height, or part-to-whole share;
- `em` on a graphical bar or legend mark, which follows the surrounding type.

Everything structural is flex. Peer columns are `flex:1`; plot areas alone may
fill the remaining stage. No layout uses Grid, float, or absolute positioning
for prose.

## The safe area is 8%, measured on this template

At 1600×900 the modal left edge of the reference's in-flow text is **8.0%** of
the stage: 62 text runs land there. The modal right inset is also 8.0%.
Therefore the constant is `0.08`, exposed as
`data-safe-area="0.08"`.

The safe area is set exactly once:

```css
.fit {
  padding: 12cqh 8cqw 8cqh;
}
```

No slide redefines that boundary. The 12% top inset clears the corner-cross band
at 6cqh and keeps all in-flow text below the audit's 11% chrome line.

## Files

**Opening, closing, and one-page conclusion** · `cover` `toc`
`section-divider` `executive-summary` `close`

**Prose and findings** · `overview-kpis` `two-column` `three-column`
`three-insights` `numbered-findings` `action-cases` `big-quote` `quote-cards`

**KPI and scorecard work** · `overview-kpis` `kpi-grid` `stat-highlight`
`metric-deep-dive` `scorecard` `period-comparison` `actual-vs-target`

**Core charts** · `chart-bar` `area-chart` `combo-chart` `line-chart`
`doughnut-row` `stacked-bar` `scatter-plot` `bubble-chart`

**Cuts, ranking, and contribution** · `bar-ranking` `segment-comparison`
`labelled-bars` `share-strip` `waterfall`

**Journey and diagnostic analysis** · `funnel` `cohort-retention`
`distribution-outliers` `heatmap-matrix`

**Records and detail** · `table` `detail-summary`

**Two things compared** · `comparison` (diagonal colour field, loud)
`comparison-ruled` (two ruled columns, quiet)

**Time, outlook, and action** · `timeline` `roadmap` `process-steps`
`forecast-scenarios` `risk-recommendations`

**Methods and supporting material** · `methods-definitions`
`appendix-index` `feature-cards` `team`

**Commercial cuts** · `pricing`

**Image pages, source-gated** · `image-evidence` `image-grid`

`image-evidence` and `image-grid` are the only image layouts, and both are
source-gated. The reference contains zero image placeholders, so a decorative
hero image would teach a behaviour this template does not demonstrate. Use the
single evidence frame, or the six-frame grid when the material genuinely carries
a repeated series, only when the supplied source contains or explicitly calls
for those images; otherwise delete the page and use a prose or chart layout.

## Coverage inventory

The 2026-08 review expanded the set by task, not by visual variant:

| analytical job                          | layouts                                                                                         | coverage decision                                                                                      |
| --------------------------------------- | ----------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| KPI overview                            | `overview-kpis` `kpi-grid`                                                                      | existing overview treatments retained                                                                  |
| single metric                           | `stat-highlight` `metric-deep-dive`                                                             | the new diagnostic adds trend and named drivers rather than another hero number                        |
| grouped scorecard                       | `scorecard`                                                                                     | new Growth / Efficiency / Reliability hierarchy with actuals and thresholds                            |
| bar / line / area / doughnut / combo    | `chart-bar` `line-chart` `area-chart` `doughnut-row` `combo-chart`                              | existing chart grammar retained                                                                        |
| stacked and relationship plots          | `stacked-bar` `scatter-plot` `bubble-chart`                                                     | stacked composition is new; scatter uses equal point weight while bubble size carries a third variable |
| period and plan variance                | `period-comparison` `actual-vs-target`                                                          | new MoM / YoY table and target-marker chart                                                            |
| segment, channel, and region cuts       | `segment-comparison` `bar-ranking`                                                              | cross-segment score columns complement the existing ranked region bars                                 |
| contribution and journey                | `waterfall` `funnel`                                                                            | new cumulative bridge and stage-conversion structures                                                  |
| cohort and distribution                 | `cohort-retention` `distribution-outliers`                                                      | new triangular retention matrix plus histogram / box-plot diagnostic                                   |
| records, ranking, and matrices          | `table` `bar-ranking` `heatmap-matrix` `detail-summary`                                         | heatmap and detail-with-summary add jobs the existing table and ranking cannot do                      |
| time, milestone, and scenarios          | `line-chart` `area-chart` `roadmap` `forecast-scenarios`                                        | existing history and roadmap retained; branching forecast is new                                       |
| risks and recommendations               | `risk-recommendations` `action-cases`                                                           | paired risk signal, response, owner, and horizon is new                                                |
| conclusion, findings, methods, appendix | `executive-summary` `three-insights` `numbered-findings` `methods-definitions` `appendix-index` | new one-page decision summary, calculation notes, and appendix navigation complete the report sequence |

The 2026-08-12 review added eight core page types this set had no equivalent
for. Each is a job the previous 44 could not do, written in this template's own
rules, colour fields, and bare figures — not a renamed chart page:

| analytical job                  | layout          | why it is not one of the existing 44                                                                                         |
| ------------------------------- | --------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| three parallel prose readings   | `three-column`  | `three-insights` is a numbered signal callout, one sentence per column; this is a multi-paragraph reading page with subheads |
| retrospective chronology        | `timeline`      | `roadmap` is three forward horizons; this is dated events on a continuous spine                                              |
| method as a linear flow         | `process-steps` | `funnel` carries conversion volumes; this carries ordered steps and drawn connectors, no datum                               |
| named owners                    | `team`          | no people page existed anywhere in the set                                                                                   |
| several short attributed quotes | `quote-cards`   | `big-quote` is one hero pull quote; this is three side-by-side reactions with attribution                                    |
| plan and tier economics         | `pricing`       | the price/feature grid is not expressible by `table` or `comparison-ruled`                                                   |
| a repeated visual series        | `image-grid`    | `image-evidence` is a single frame; source-gated in the same way                                                             |
| stated properties of the report | `feature-cards` | the only layout that uses four `--gN` fields as the card system itself                                                       |

## Where the set came from

The first thirteen roles are the reference deck's own compositions, walked page
by page:

| reference page | naked layout      |
| -------------- | ----------------- |
| 1              | `cover`           |
| 2              | `toc`             |
| 3, 6, 11       | `section-divider` |
| 4              | `overview-kpis`   |
| 5              | `labelled-bars`   |
| 7              | `area-chart`      |
| 8              | `combo-chart`     |
| 9              | `doughnut-row`    |
| 10             | `bar-ranking`     |
| 12             | `bubble-chart`    |
| 13             | `line-chart`      |
| 14             | `action-cases`    |
| 15             | `close`           |

The three packets in `../composition-recipes.html` contribute
`big-quote`, `comparison`, and `table`.

The remaining thirty-six are actual missing jobs for an analytical report,
expressed in this template's own broad colour fields, fine rules, bare figures,
and light display type: `two-column`, `three-insights`, `numbered-findings`,
`kpi-grid`, `stat-highlight`, `chart-bar`, `share-strip`,
`comparison-ruled`, `roadmap`, the single `image-evidence` layout,
`metric-deep-dive`, `scorecard`, `stacked-bar`, `scatter-plot`,
`period-comparison`, `actual-vs-target`, `segment-comparison`, `waterfall`,
`funnel`, `cohort-retention`, `distribution-outliers`, `heatmap-matrix`,
`detail-summary`, `forecast-scenarios`, `risk-recommendations`,
`executive-summary`, `methods-definitions`, `appendix-index`, `three-column`,
`timeline`, `process-steps`, `team`, `quote-cards`, `pricing`, `image-grid`,
and `feature-cards`.

Deliberately absent: terminal and code furniture, button-like CTA rows,
mindmaps, architecture diagrams, flowcharts, radar charts, and a separate pie
layout. They are not demonstrated by this reference, and the doughnut treatment
already covers part-to-whole data.

## Colour is part of the datum, not a card system

The reference is a colour-stage deck: **14 of 15 pages (93%)** put
`--g0`, `--g1`, `--g2`, `--g3`, or `--ink` on the stage. The
cover is the one `--bg` page. Ground rotation belongs to the decoration layer;
the layout files show contrast-safe examples so they can be rendered and
inspected independently.

- On `--gN`, always use the matching `--tN`.
- `--accent` and `--s1..--s3` are chart and shape fills.
- Text on a raw hue uses `--ka` or `--k1..--k3`; never assume
  `--o1..--o3` is readable. The reference's original bubble labels measured
  2.82:1 and 2.56:1 before being corrected.
- `--surface` appears zero times. A generic surface card is not this
  template's vocabulary.
- Three coloured boxes do sit on the reference's full-bleed page 5. They are the
  three data fields in `labelled-bars`, not generic panels. Accordingly
  `boxesOnFullBleed=3` is reported, not gated.

## Filled boxes take their height from content

A visible field is never stretched merely because the stage has room:

```
row     flex:none    height comes from its tallest child
child   flex:1       peers match that tallest child
plot    flex:1       only charts and source-supported images fill
```

A single box shrink-wraps its content with `align-self:flex-start;
max-width:100%`. A row of peers remains equal-width and divides the safe area.

A media cell is the exception. Wrap it in `[data-media-lane]`: the lane stretches to the
row's height and centres the cell inside it, so an image sized by its own aspect ratio
sits in the middle of its region rather than at the top with empty ground beneath it.
`image-evidence` shows the pattern; the shared CSS also centres any `[data-photocell]`
that carries an inline `aspect-ratio`, whichever layout it came from.

The 26 detected peer rows in this set were stress-tested by appending a wrapping sentence
to the first item. Every row stayed equal-height; maximum sibling spread was
**0px**.

## What attaches from the decoration layer

The layout files contain no corner crosses, footer label, page number, or cover
palette swatches. Add those after choosing the layout:

- normal content page: the top-left + top-right cross pair;
- section divider or close: the pair plus the measured lower-corner cross;
- cover: the three-square palette swatch instead of crosses;
- footer label and page number: every page.

Exact snippets and the measured exceptions are in
[../decoration/PLACEMENT.md](../decoration/PLACEMENT.md).

## Verification baseline

After the reference corrections made during this split:

```
pages / navigable           15 / 15
decks / orphan / indirect    1 / 0 / 0
overflow                     0
outsideSafeArea              0
aboveChromeBand              0
columnsMisaligned            0
lowContrast                  0
surfaceUses                  0
boxesUnderfilledV/H          0 / 0
fullBleedPages              14
boxesOnFullBleed             3  (report-only: the p5 data fields)
```

All 52 layouts independently read 1 deck, 1 page, 1 navigable slide, zero
orphan/indirect slides, and zero on every blocking geometry, contrast, alignment,
and underfill check at both 1600×900 and 430×932. Every render reported loaded
fonts, at least two resolved stylesheets, and a non-transparent token ground.

## Two geometry checks added by the 2026-08-12 review

Both are measured against the reference before being used, per the playbook's
calibrate-both-sides rule.

**Empty wide column** — an in-flow box holding no text, where nothing inside it
paints either (no background, border, shadow, or vector), that still occupies
≥8% of the safe-area width. Reference reads **0**; the set now reads **0**. The
three empty cells in `cohort-retention`'s triangular matrix are the only ones
this ever found, and they now carry an explicit "not yet observed" em dash
rather than a hole. This one is a gate.

**Narrow-box wrap** — text wrapping to two or more lines inside a box far
narrower than the safe area, with nothing to its right. The reference reads
**1**: its cover subtitle is a deliberate half-width `.lead` at 49.9% of the
safe area. A criterion its own reference fails cannot gate, so this is
**report-only above a 15% box width**. Below 15% — where a one-word chart legend
would sit — reference and set both read **0**, and that band is a gate.

Measuring the wrap requires the client rects of the **text nodes only**.
Selecting whole element contents also returns a rect for an inline legend
swatch, whose top sits below the text baseline; merging the two reads as a
phantom second line on every legend row in the set. Legend rows now also carry
`white-space:nowrap`, so a one-word series label cannot wrap under any font
fallback.

## Classes available

Typography `display h1 h2 h3 stat metric hero-stat kicker lead body cap` ·
structure `deck slide stage fit card plot rule` · state `dim faint`.

Sizes live in these classes. If an audience-facing item needs more emphasis, use
the next class up instead of freezing a box around its placeholder text.
