# nocturne — decoration placement

Everything here is measured from the original reference deck: 15 pages, 23 large ornaments,
16 small ones. Numbers, not taste.

Open [`decoration.html`](decoration.html) to see each rule rendered with no text on the
page, and [`item-sets.html`](item-sets.html) for the repeated-item treatments as copyable
markup.

## The layer model

| z-index | layer | where it comes from |
|---|---|---|
| 0 | blobs | this folder |
| 1 | the ring | this folder |
| 6 | persistent brand chrome | fixed, see A |
| 40 | `.fit` — all slide content | `../layouts/*.html` |
| 45 | `pagenum` | fixed, see A |

Decoration sits **below** text and is never inside `.fit`. If a layout and an ornament
collide, move the ornament — never the copy.

## A · Persistent chrome

Two items. The reference carries `brand` on **11 of 15** slides and `pagenum` on
**15 of 15**.

```html
<div data-device="brand" style="position:absolute;left:6cqw;top:5.5cqh;display:flex;align-items:center;gap:.9cqw;z-index:6">
  <div style="position:relative;width:3.1cqw;height:3.1cqw;background:var(--accent);border-radius:.9cqw">
    <div style="position:absolute;left:50%;top:50%;width:1.2cqw;height:1.2cqw;background:var(--bg);border-radius:.3cqw;transform:translate(-50%,-50%) rotate(45deg)"></div>
  </div>
  <span style="font-family:var(--fd);font-weight:600;font-size:1.5cqw;letter-spacing:-.01em;color:var(--ink)">Your brand</span>
</div>
<div class="pagenum">01</div>
```

The chrome occupies **5.5–11cqh**, so `.fit` starts at `12cqh` and nothing in normal flow
may begin above 11 % of stage height. The reference reads 0 there — but only once the
chrome itself is excluded from the count. The chrome *is* text and it *is* in that band,
by design; measuring it as a violation reads 11 defects on a clean reference.

## B · Vocabulary — five items, nothing else

| name | marker | what it is | count |
|---|---|---|---|
| blob | `data-bigcircle` | one organic `<path>` in a `0 0 100 100` viewBox | 17 |
| ring | `data-device="ring"` | a disc with a 52 % `--bg` disc inside — the donut | 6 |
| node | `data-node` | small circle, `--ink` ground, `--bg` numeral | 4 |
| connector | `data-connector` | horizontal bar, `color-mix(--ink 24%)`, `z-index:0` | 1 |
| photocell | `data-photocell` | image frame, `--ph` | 11 |

The four blob paths the reference actually draws are in `decoration.html`. **Copy them.**
Do not invent plain circles, squares, arches or colour blocks — and note that the ring
is a *donut*, not a filled disc: the `--bg` hole is what makes it read as nocturne's
`donut-ring` rather than a generic circle.

## C · How many, and where — this is by page role, not a flat average

The whole-deck average is 1.53 large ornaments per page, and that average is useless: it
mixes page roles that behave completely differently. Measured:

| page role | pages | large ornaments | composition |
|---|---|---|---|
| cover, agenda | 2 | **exactly 2** | ring + one blob |
| section divider, close | 4 | **exactly 3** | ring + large blob + small `--bg` cut-out |
| content, sparse | 5 | 1 or 2 | blobs only |
| content, dense | 4 | **0** | nothing at all |

Two exact separations fall out of this, and both are worth stating because a flat
per-page number would destroy them:

- **The ring never appears on a content page.** 6 of 6 rings sit on a cover, agenda,
  divider or close; 0 of 9 content pages carry one.
- **A page whose content fills the stage carries no ornament.** All four dense content
  pages — the bento, the gallery, the chart-plus-figures page, the pricing page — carry
  zero. Sparse pages carry one or two.

## D · Bleed

**20 of 20** rings and large blobs hang off a stage edge, by **0.35–0.68× their own
width**. Anchor with a negative offset (`left:-14cqw`, `bottom:-16cqh`).

The three that sit fully inside are the small `--bg` cut-outs on the dividers, and that
is their job: on a `--g0` field a `--bg` blob reads as a hole punched through the colour,
which is the divider's signature. Sizes: ring 34–40cqw, large blob 22–34cqw, cut-out
12–18cqw.

## E · Within a page, everything differs

**8 of 8** pages carrying two or more ornaments give each a different fill, a different
size and a different shape. Fills are drawn from `--accent --s1 --s2 --s3 --bg`.

**Opacity is 1.** 20 of 23 ornaments render at full opacity; only the small `--bg`
cut-out is at 0.9. This is the opposite of bloom, whose rule is "0.7–0.92, never 1" —
copying that number here would wash every ornament out against the dark ground.

## F · Colour fields

**4 of 15 pages** (27 %) put a ground colour on `.stage` itself: the three section
dividers and the closing page. They use `--g0`, `--g3` and `--g1`.

**`--g2` is never a page ground**, and the measurement says why: `--g2` against `--bg`
reads 1.5–1.8:1 in four of the five preferred tokens, so a `--g2` "colour field" would be
indistinguishable from an ordinary page.

On a colour field the reference carries **no panels** — one small `--bg` contact pill on
the closing page, and nothing else. A card on a colour field is a hole. A kicker on a
colour field uses `color:inherit`, never `--ka`.

Note that a probe looking for "full-bleed pages" by stage luminance reports **15 of 15**
here, because every nocturne page is dark. That reading is meaningless for this template;
the one that means something is whether `.stage` carries an inline `--g?` background.

## G · Small ornaments belong to one page type

`node` and `connector` are not sprinkled. They are the device of a single page role — an
ordered sequence — and on that page **every stage gets one node and the row gets one
connector**. One of 15 reference pages is a sequence page; it carries 4 nodes and 1
connector, never 1 or 2.

`photocell` is the image frame itself. When the source has no imagery, **delete the
frame** — do not leave an empty box and do not substitute a grid of rounded rectangles.
The reference fills 11 frames across 3 pages: a 4-up team row, a 4-up gallery, and three
avatars inside quote cards.

Both treatments are in [`item-sets.html`](item-sets.html) as copyable markup, because a
sentence describing an ornament does not survive: what is not provided as markup gets
dropped.

## H · What is not stated, dies

bloom's small ornaments fell from 0.214 to 0.022 per page across 18 generated decks
because they were listed as a vocabulary and not given a frequency and an attachment
(p=0.0043). Every entry in section B above therefore has both a count and a page role
attached, and the two treatments that repeat are shipped as markup rather than prose.

## I · When to place nothing

Four of 15 reference pages carry no ornament. A page whose copy already fills the stage
should carry none — an ornament crowded against text is worse than no ornament.

**Do not judge a naked layout for looking empty.** The layouts in `../layouts/` are
deliberately bare, and their lower third is where the blobs bleed in. Overlay
`decoration.html` before deciding a layout needs more content.

## Verifying your own deck

```
large ornaments per page          reference 1.53
ring on a content page            reference 0 of 9        <- exact
ornaments on a dense content page reference 0 of 4        <- exact
rings/large blobs that bleed      reference 20 of 20      <- exact
pages with 2+ that differ in fill reference 8 of 8        <- exact
opacity 1                         reference 20 of 23
colour-field pages                reference 4 of 15 (27 %)
--g2 as a page ground             reference 0             <- exact
panels on a colour field          reference 0
uses of --surface                 reference 2 (report only, not a gate)
--ink-grounded box wider than 12cqw  reference 0          <- exact
```
