# nocturne — naked layouts

40 layouts, text only. No decoration, no measured geometry. Pair one of these with
[`../decoration/PLACEMENT.md`](../decoration/PLACEMENT.md) to build a slide.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 40: zero `width` / `max-width` / `min-width` / `height` / `left` /
`top` / `right` / `bottom` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex-basis`. A number gutter written `flex:0 0 5cqw` freezes exactly the way
a `width` does — the original reference deck had ten of them in `toc` alone, plus four in the
proportion bands, and they are the observed width of one two-digit string at one font
size. They are now `flex:0 0 2.8em`.

Exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline. A hairline is a hairline at any scale.
- **`em`** on anything that holds no prose — a node, a connector, a legend dot, a
  graduated bubble. `em` scales with type, so it cannot freeze a text box.
- **`%`** where the number _is_ the datum: bar heights in `chart-bar`, the conic stops in
  `chart-donut`, the weighted flex ratios in `proportion-bands`, and the `width:1%`
  shrink-to-fit columns in `data-table`.
- text that merely _displays_ a CSS string — strip text nodes before matching.

Everything else stretches. Columns are `flex:1`. The safe area is set once, by the
padding on `.fit` (`12cqh 6cqw 8cqh`) — measured as this template's constant: the modal
left edge is 6 % (29 of 72 in-flow leaf text runs), and none sits outside it.

Any flex child holding an SVG or a percentage-height bar needs `min-height:0`, and its
**row** needs `align-items:stretch`. A row set to `align-items:flex-end` leaves the
columns content-height, so a bar's `height:73%` has no definite parent to resolve
against — the first version of `chart-bar` rendered all five bars at **0px** and still
passed the probe gates. Percentage heights are only checkable by measuring the rendered
bar.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions. Not a
slide.

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `statement` `longform` `two-column` `three-column` `numbered-rows`
`big-quote` `pros-cons` `comparison` `versus`

**Numbers** · `kpi-grid` `kpi-cards` `stat-highlight` `data-table` `chart-bar`
`chart-line` `chart-donut` `bubble-scale`

**Filled structure** · `feature-cards` `bento-grid` `proportion-bands` `arch-diagram`
`flow-diagram` `mindmap`

**Time and sequence** · `process-steps` `timeline` `roadmap` `gantt`

**People and imagery** · `team-grid` `image-gallery` `image-left` `image-right`
`image-hero`

**Testimony, proof and offer** · `quote-cards` `case-study` `pricing`

**Technology and risk** · `risk-matrix`

Thirteen of these are the compositions the original reference deck already demonstrates — `cover`
`toc` `section-divider` `close` `bubble-scale` `proportion-bands` `team-grid`
`bento-grid` `process-steps` `image-gallery` `chart-bar` `quote-cards` `pricing`. Three
come from `composition-recipes.html` — `big-quote` `comparison` `data-table`. The rest
fill gaps a real deck has and the reference does not cover.

## Functional coverage audit

Every file below has one communication job. Similar-looking ideas are kept in one file:
`numbered-rows` already covers key points, so there is no duplicate `bullet-list`; `gantt`
shows overlapping duration against a shared calendar, while `timeline` records dated
events and `roadmap` groups horizons.

| requested job                                 | layout files                                                                                                     |
| --------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| cover / contents / chapter / close            | `cover` `toc` `section-divider` `close`                                                                          |
| pure statement / long-form prose / key points | `statement` `longform` `numbered-rows`                                                                           |
| feature cards / colour-block cards            | `feature-cards`                                                                                                  |
| two / three parallel columns                  | `two-column` `three-column`                                                                                      |
| image left / right / hero / gallery           | `image-left` `image-right` `image-hero` `image-gallery`                                                          |
| quotation / testimony                         | `big-quote` `quote-cards`                                                                                        |
| KPI and charts                                | `kpi-grid` `kpi-cards` `stat-highlight` `chart-bar` `chart-line` `chart-donut` `bubble-scale` `proportion-bands` |
| table                                         | `data-table`                                                                                                     |
| timeline / roadmap / Gantt                    | `timeline` `roadmap` `gantt`                                                                                     |
| flow / architecture / mind map                | `flow-diagram` `arch-diagram` `mindmap`                                                                          |
| comparison / versus / pros and cons           | `comparison` `versus` `pros-cons`                                                                                |
| case study / team                             | `case-study` `team-grid`                                                                                         |
| Nocturne specialist work                      | `risk-matrix` `bento-grid` `process-steps` `pricing`                                                             |

`feature-cards` is the colour-block card page: three equal cards on `--g0 --g1 --g2`,
each an icon tile, a name and the benefit under it. It is not `bento-grid` (mixed cell
sizes, figure-led) and not `kpi-cards` (a figure per card); its job is "here are the N
things this offers", where the ground colour is what separates one from the next.

`mindmap` and `gantt` are expressed in Nocturne's own grammar rather than imported from
another template. `mindmap` is a dark constellation of ruled branches around one luminous
idea field, not a generic radial-circle diagram. `gantt` uses restrained luminous data
bars on the dark ground; percentage length and offset encode the actual schedule.

## Colour: measured against `--bg`, across all five preferred tokens

Nocturne is a **dark** template, so every one of bloom's colour rules inverts or voids.
These figures are the minimum and maximum contrast each token reaches against `--bg`
across `midnight_mono` `ocean_deep` `mono_ink` `sunset_maroon` `gold_luxe`:

| token                                  | contrast on `--bg`       | use as                                     |
| -------------------------------------- | ------------------------ | ------------------------------------------ |
| `--ink` 13.6–19.8 · `--k1` `--k2` same | pass everywhere          | body text                                  |
| `--ka` `--k3` 7.2–19.8                 | pass everywhere          | accent text                                |
| `--soft` 5.3–7.4                       | pass everywhere          | secondary text                             |
| `--s1` 3.7–19.8                        | pass everywhere          | the smallest legible label                 |
| `--accent` **2.9**–15.8                | fails in `sunset_maroon` | **fill only — use `--ka` for accent type** |
| `--s2` **1.5–1.9**                     | fails in all five        | **fill only, never type**                  |

The reference broke its own rule once: the `toc` numbered its rows
`--accent / --s1 / --s3 / --s2`, and `--s2` on `--bg` reads **1.71:1**. That is now
`--ka / --soft / --s1`, which clears 3.0 in every preferred token. Reference
`lowContrast` was 1; it is now 0, which is what makes the criterion able to gate at all.

### There are only three distinct grounds, not four

Measured: `--g3` is byte-identical to `--g0` in `midnight_mono`, `ocean_deep` and
`gold_luxe`, and to `--g1` in `mono_ink`. Only `sunset_maroon` has four distinct
grounds. Separately, `--g2` reads **1.5–1.8:1 against `--bg`** in four of the five, so a
lone `--g2` panel on the dark ground has no visible edge at all.

So bloom's "cycle `--g0 --g2 --g1 --g3` so neighbours never share a colour" is exactly
wrong here — it yields two identical cards and one invisible one. Nocturne cycles
**`--g0 --g1 --g2`**, and a fourth peer takes an **outline**
(`1.6px solid color-mix(in srgb,var(--ink) 32%,transparent)`) rather than a fill. That is
what `kpi-cards` does.

`--g2` is fine _inside_ a set beside `--g0` and `--g1`, where the row's shape carries it.
It is not a page ground: 4 of 15 reference pages are colour fields and they use
`--g0`, `--g3`, `--g1` — `--g2` **zero** times.

### `--surface` needs an edge

`--surface` lifts only **1.04–1.19** above `--bg` across the five tokens. It is not the
white-on-cream hole bloom had, but it is close to invisible on its own. The reference
uses it twice, both times as a bento cell surrounded by bright neighbours. Wherever these
layouts use it — `bento-grid`, `comparison`, `flow-diagram` — it carries a
`1.4px` hairline so the box has a definite edge. The literal `surfaceUses` audit reads 3
because it also sees the shared `.card` CSS rule. Either way the reference is not 0, so
this is a stated design rule, **not** a gate.

### `--ink` grounds only small things

`--ink` is near-white here, so a large `--ink` panel is a white slab on a dark deck — the
mirror image of bloom's problem, same rule. The reference grounds exactly five things in
`--ink` and the widest is **11.6cqw**: four 6cqw process nodes and one pill badge.
`process-steps` keeps the reference's white nodes; cycling them through `--g0..--g3`
was tried and rejected, because the `--g2` node disappears.

## A filled box is sized by its content, never by the stage

```
height  row     flex:none      — from the tallest child, not the stage
        child   flex:1         — every sibling matches that tallest child
width   box     align-self:flex-start; max-width:100%
```

`.fit` is a column flex with `align-items:stretch`, so every child is full-width by
default; `align-self:flex-start` opts one box out. A **row of peers** stays equal-width
and divides the safe area — one box hugs, a row of boxes divides.

`.fit` also carries `justify-content:center`, so the whole content block is centred as
one unit the way the reference's inner wrapper is. An earlier version put the heading at
the top and centred only the body beneath it, which opened a void between title and
content on every prose layout.

**Stress-tested, not assumed.** An extra sentence was injected into the first child of
every peer row in all 40 layouts and sibling heights compared. All pass. The one row that
moves is `bento-grid`'s heading-and-standfirst row, which is `align-items:flex-end`,
holds no fills, and is meant to sit on a common baseline.

`border-radius:999px` on a stretched box is not a pill, it is an oval. `flow-diagram`
shipped that way — its nodes were full-height lozenges. Each node now sits in a
stretching column and is itself `flex:none`, so the column carries the equal height and
the pill stays a pill.

## Ruled or filled — every peer content type has both

| content             | ruled          | filled          |
| ------------------- | -------------- | --------------- |
| three peer columns  | `three-column` | `feature-cards` |
| a row of numbers    | `kpi-grid`     | `kpi-cards`     |
| two things compared | `comparison`   | `versus`        |

`kpi-grid` is the template's own idiom — the reference's `statrow`, scaled to four:
figures in `--ka` sitting directly on the dark ground under a hairline, no boxes at all.
"Numbers float directly on the dark ground" is the first line of this template's identity,
and it is the one thing a generated deck loses first by wrapping every figure in a card.

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` · structure
`stage fit deck slide band card tile badge` · marks `dot tick soft dim pagenum`.

Sizes live in those classes. If something needs to be bigger, use the next class up.

## Probe calibration

Measured at 1600 × 900 with `SAFE=0.06`. The reference has 15 slides and reads
`navigableSlides 15 / orphanSlides 0 / indirectSlides 0`. Every naked layout has one
slide and reads `1 / 0 / 0`.

| reading             | reference | all 40 layouts | use         |
| ------------------- | --------: | -------------: | ----------- |
| `overflow`          |         0 |              0 | gate        |
| `outsideSafeArea`   |         0 |              0 | gate        |
| `aboveChromeBand`   |         0 |              0 | gate        |
| `lowContrast`       |         0 |              0 | gate        |
| `boxesUnderfilledH` |         0 |              0 | gate        |
| `boxesUnderfilledV` |     **3** |              0 | report only |

The three reference `boxesUnderfilledV` readings are the 40/30/20 % data bands: their
height is the datum and their labels are deliberately centred. The naked
`proportion-bands` fragment separates each band into two equal-height label cells, so it
keeps that appearance while the boxes themselves are genuine peer content rows.

### Empty columns and narrow wraps

Two further geometric readings, measured the same way — an in-flow box holding no text,
no fill, no border and no vector that still eats **≥ 8 %** of the safe-area width, and a
text run wrapping to two or more lines inside a box clearly narrower than the safe area
with nothing between its right edge and the safe-area edge:

| reading            | reference | all 40 layouts | use         |
| ------------------ | --------: | -------------: | ----------- |
| `emptyWideColumns` |         0 |              0 | gate        |
| `narrowWraps`      |     **2** |              0 | report only |

`emptyWideColumns` gates: the reference reads 0, so it can. `narrowWraps` cannot — the
reference reads 2, both of them a half-measure standfirst whose companion device
(`bubble-scale`'s circles, `image-gallery`'s grid) is out of flow and sits just below the
paragraph's own line band, so the strip beside the text is empty by the letter of the
rule. It is reported, not enforced. The layouts are held to 0 anyway: `bubble-scale`'s
"each circle is scaled to its value" line was a caption about the plot sitting in the
prose column, and now sits under the plot where it belongs.

Both readings are calibrated in both directions. Injecting an empty `flex:1` sibling into
`two-column`'s row reads `emptyWideColumns 1`, and capping its `h1` at a 30cqw measure
reads `narrowWraps 1`; the unmodified file reads 0 for both.

## Every slide must be a direct child of `.deck`

The navigation runtime collects pages with
`[...deck.children].filter(n => n.classList.contains('slide'))`. A slide nested one level
deeper renders perfectly, scrolls perfectly, screenshots perfectly — and cannot be
reached with an arrow key. Check it, then press the key:

```js
document.querySelectorAll(".slide").length ===
  [...document.querySelector(".deck").children].filter((n) =>
    n.classList.contains("slide"),
  ).length;
```
