---
name: nocturne
description: Create a standalone 16:9 HTML presentation deck with the Nocturne visual identity and direct-HTML workflow. Use when the user selects the Nocturne presentation template or explicitly names nocturne as the deck style. Best suited to dark, luminous keynotes about technology, cybersecurity, AI, and data.
---

# Nocturne presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual
identity.

The default deliverable is one directly openable, standalone HTML presentation.
Documented web-font links may remain external with system fallbacks; inline the selected
colour-system CSS and keep all deck HTML, CSS and JavaScript in that file. Create another
format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

Produce one standalone HTML file with one live `.deck`, one navigation runtime and one
16:9 `.stage` per page. Every `.slide` must be a direct child of `.deck`: the runtime
collects pages with `[...deck.children].filter(n => n.classList.contains('slide'))`, so
a nested slide renders normally but cannot be reached with an arrow key.
The final QA hard gate checks both the direct-child count and the live keyboard state;
do not add a separate console or manual key pass.

Translate the outline into HTML in the same order. Use concise audience-facing copy,
one clear hierarchy and only sourced evidence. Set `<html lang>`, `<title>`,
`data-color-system` and the deck's `aria-label` from the actual presentation.

### Start from one naked layout

Choose by communication job, then adapt the copy and number of peers. Do not start from
`layouts/`.

| the slide is                      | use                                                                                                              |
| --------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| opening, agenda, chapter, closing | `cover` `toc` `section-divider` `close`                                                                          |
| prose or records                  | `statement` `longform` `two-column` `three-column` `numbered-rows` `big-quote` `data-table`                      |
| comparison                        | `comparison` quiet · `versus` loud · `pros-cons`                                                                 |
| numbers or data                   | `kpi-grid` `kpi-cards` `stat-highlight` `chart-bar` `chart-line` `chart-donut` `bubble-scale` `proportion-bands` |
| structure                         | `bento-grid` `arch-diagram` `flow-diagram` `mindmap`                                                             |
| time or sequence                  | `process-steps` `timeline` `roadmap` `gantt`                                                                     |
| sourced imagery                   | `team-grid` `image-gallery` `image-left` `image-right` `image-hero`                                              |
| testimony, proof or offer         | `quote-cards` `case-study` `pricing`                                                                             |
| technology or security risk       | `risk-matrix`                                                                                                    |

`mindmap` and `gantt` are Nocturne-native additions. Use the shipped files exactly:
`mindmap` uses ruled branches around one luminous idea field rather than generic radial
circles; `gantt` uses textless luminous duration bars whose percentage offset and length
encode dates. Do not import another template's visual grammar.

Rules carried by every layout:

- **No frozen container or viewport geometry on anything that holds text.** Do not put
  `width`, `max-width`, `min-width`, `height`, or a `flex-basis` in `cqw`, `cqh`, `px`,
  `vw` or `vh` on a text holder. The same units are forbidden for
  `left/top/right/bottom` unless the element is explicitly out of flow and the value is
  placement rather than size.
- The safe area is set once: `.fit { padding:12cqh 6cqw 8cqh }`. A page cannot redefine
  its own safe area by reducing that
  padding.
- Use Flexbox for the primary layout. Columns are `flex:1`; do not use Grid, float or
  absolute positioning to reconstruct measured placeholder geometry.
- Allowed exceptions are an `em` size for an ornament with no prose, `%` when the number
  is the datum, `height:1px` for a hairline and absolute offsets for an out-of-flow badge
  or decoration.
- A flex child holding an SVG or percentage-height bar needs `min-height:0`, and its row
  needs `align-items:stretch`. Measure the rendered bar; a percentage bar can silently become
  zero pixels when its parent has no definite height.
- A single filled box hugs its content with `align-self:flex-start;max-width:100%`.
  A row of filled peers is `flex:none`, each child is `flex:1`, and siblings equalise to
  the tallest child. Reserve a filling `flex:1` for a chart plot or image frame.
- Stress-test equal height by adding a sentence to the first peer and measuring every
  sibling. Do not trust `align-items` by inspection.
- Use the typography classes from `_shell.html`; move up a class instead of inventing a
  measured font size.
- Alternate ruled and filled peers across the deck. Nocturne provides
  `three-column`/`bento-grid`, `kpi-grid`/`kpi-cards` and `comparison`/`versus`.
- Identifiers and numeric columns take only the width they need and never wrap; prose
  absorbs the remaining space.

### Add decoration by page role

Use the five-item vocabulary exactly: organic `blob`, donut `ring`, sequence `node`,
`connector` and sourced-image `photocell`. Copy the actual paths and markup from
`decoration/decoration.html` and `decoration/item-sets.html`; do not invent generic
circles, squares, arches or colour blocks.

- Cover and agenda: exactly one ring plus one blob.
- Section divider and close: ring, large blob and a smaller `--bg` cut-out; put the page
  ground on `.stage`.
- Sparse content: one or two blobs, only in genuinely empty regions.
- Dense content: no ornament.
- A ring belongs only to section dividers and the close.
- Rings and large blobs bleed off a stage edge according to `PLACEMENT.md`; keep the
  small cut-out inside its parent motif.
- Colour fields belong to dividers and the close. Use `--g0`, `--g1` or `--g3`, never
  `--g2`, and put no panel on top.
- Sequence pages give every stage one node and the whole row one connector. Do not
  sprinkle a lone node elsewhere.
- Image frames exist only where sourced imagery exists.
- Page number appears on every slide. Brand chrome appears on ordinary opening, agenda
  and content pages; omit it on full colour-field pages.
- The brand/chrome band occupies the top 11% of the stage. Normal-flow content begins at
  12%, below it.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

- When no image improves the slide, delete the `data-photocell` frame. An empty rounded box
  is not decoration.
- Do not place body copy over a photograph unless it is a full-bleed image with a tested
  text-safe treatment.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

Read all of these before writing HTML:

1. [design-system.md](design-system.md), completely to the last line;
2. [example/reference.jpg](example/reference.jpg) and
   [layouts/](layouts/) for full-deck rhythm;
3. [layouts/README.md](layouts/README.md) and the matching naked layout file;
4. [decoration/PLACEMENT.md](decoration/PLACEMENT.md), then render
   [decoration/decoration.html](decoration/decoration.html);
5. [composition-recipes.html](composition-recipes.html) for tables, record lists and
   repeated rows.

When requirements pull against one another, preserve them in this order:

1. factual accuracy and source completeness;
2. legibility at presentation size;
3. Nocturne's identity — dark ground, luminous type, chrome and motif vocabulary;
4. optional motifs follow their documented role and placement.

Decoration never displaces content, shrinks copy, drops a point or invents material to
fill a slot. A deck that is accurate but visually anonymous also fails.

#### Layout and decoration are separate layers

Build each slide in this order:

| z-index | layer                           | source                              |
| ------: | ------------------------------- | ----------------------------------- |
|       0 | organic blobs                   | `decoration/`                       |
|       1 | donut ring                      | `decoration/`                       |
|       6 | persistent brand chrome         | `decoration/PLACEMENT.md` section A |
|      40 | all slide content inside `.fit` | `layouts/`                          |
|      45 | page number                     | `layouts/_shell.html`               |

`layouts/` fuses these layers. Use it to judge rhythm, not as markup to copy. Take structure from a
naked layout and ornaments from `PLACEMENT.md`. Decoration stays outside `.fit`; when it
collides with content, move or remove the ornament, never the copy.

#### Colour roles

- If the prompt supplies a valid `color-system`, use it. Otherwise choose one preferred
  token from `design-system.md`. Load exactly one colour system and inline it in the final
  standalone HTML.
- `--ink`, `--ka`, `--soft` and `--s1` are safe for type on `--bg`.
- `--accent` and `--s2` are fill-only. `--accent` falls to 2.9:1 and `--s2` to
  1.5–1.9:1 on preferred systems. Use `--ka` for accent type.
- Nocturne has three dependable peer grounds, not four. Cycle `--g0 --g1 --g2`; give a
  fourth peer a hairline outline. `--g3` duplicates another ground in most preferred
  systems.
- `--g2` is never a page ground. It separates from `--bg` by only 1.5–1.8:1 in four of
  five preferred systems.
- `--surface` is allowed only with a visible hairline. It sits just 1.04–1.19 above
  `--bg`; without an edge the panel disappears.
- A near-white `--ink` ground is only for a small node or contact pill. Never turn it
  into a prose panel or a large white slab.
- On a `--g?` ground, use its matching `--t?`. A kicker on a colour-field page inherits
  that page's text colour rather than forcing `--ka`.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Identity checks while authoring

- Confirm every page uses exactly one preferred `data-color-system` and no ornament
  sits over type.
- Confirm every ornament maps to the five-item vocabulary and its correct page role;
  rings never occur on content pages, dense pages carry none, and all large ornaments
  bleed.
- Confirm `--accent` and `--s2` are never used as text, `--surface` always has an edge,
  `--g2` is not a page ground and no large `--ink` prose panel exists.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
