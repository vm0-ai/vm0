---
name: nocturne
description: Create, revise, or review standalone 16:9 HTML presentation decks with the Nocturne visual identity and direct-HTML workflow. Use when the user selects the Nocturne presentation template or explicitly names nocturne as the deck style. Best suited to dark, luminous keynotes about technology, cybersecurity, AI, and data.
---

# Nocturne presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual
identity.

The default deliverable is one directly openable, standalone HTML presentation.
Documented web-font links may remain external with system fallbacks; inline the selected
colour-system CSS and keep all deck HTML, CSS and JavaScript in that file. Create another
format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## Choose the task mode

- Create: use Sections 1–5 and finish the outline before writing slide HTML.
- Revise: inspect the existing deck, reconstruct the affected outline, then preserve any
  valid shell, token, motif and runtime implementation while applying Sections 3–5.
- Review: use Sections 1–3 for context and Section 5 as the checklist. Do not edit. Report
  slide-specific P1 / P2 / P3 findings with evidence and a fix direction, or state that
  there are no actionable findings.

## 1. Define the communication job

- Read the prompt and all supplied source material before composing slides.
- Identify the audience, purpose, desired outcome, core takeaway and required evidence.
- Express the job in one sentence: by the end, the audience should reach the desired
  outcome because of the core takeaway.
- Ground every factual claim and number in supplied or verified sources. Label forecasts,
  targets and assumptions explicitly.

## 2. Complete the slide outline before HTML

- Write a lightweight plain-text or Markdown outline first: one throughline, then the
  slides in order.
- For each slide record its takeaway title, the point it establishes and the evidence or
  data that supports it. Mark forecasts, targets, assumptions and slides needing no
  evidence.
- Check the sequence for narrative flow, duplicated claims, missing evidence and a
  deliberate opening and ending. Let the content determine the slide count.
- Treat the outline as the content contract, not as a layout schema. Keep layouts and
  motifs out of it, and update it before any material change to a slide's job.

## 3. Load the local identity

Read all of these before writing HTML:

1. [design-system.md](design-system.md), completely to the last line;
2. [example/reference.jpg](example/reference.jpg) and
   [layouts/](layouts/) for full-deck rhythm;
3. [layouts/README.md](layouts/README.md) and the matching naked layout file;
4. [decoration/PLACEMENT.md](decoration/PLACEMENT.md), then render
   [decoration/decoration.html](decoration/decoration.html);
5. [composition-recipes.html](composition-recipes.html) for tables, record lists and
   repeated rows.

When requirements pull against one another, preserve them in this order:

1. factual accuracy and source completeness;
2. legibility at presentation size;
3. Nocturne's identity — dark ground, luminous type, chrome and motif vocabulary;
4. optional motifs follow their documented role and placement.

Decoration never displaces content, shrinks copy, drops a point or invents material to
fill a slot. A deck that is accurate but visually anonymous also fails.

### Layout and decoration are separate layers

Build each slide in this order:

| z-index | layer                           | source                              |
| ------: | ------------------------------- | ----------------------------------- |
|       0 | organic blobs                   | `decoration/`                       |
|       1 | donut ring                      | `decoration/`                       |
|       6 | persistent brand chrome         | `decoration/PLACEMENT.md` section A |
|      40 | all slide content inside `.fit` | `layouts/`                          |
|      45 | page number                     | `layouts/_shell.html`               |

`layouts/` fuses these layers. Use it to judge rhythm, not as markup to copy. Take structure from a
naked layout and ornaments from `PLACEMENT.md`. Decoration stays outside `.fit`; when it
collides with content, move or remove the ornament, never the copy.

### Colour roles

- If the prompt supplies a valid `color-system`, use it. Otherwise choose one preferred
  token from `design-system.md`. Load exactly one colour system and inline it in the final
  standalone HTML.
- `--ink`, `--ka`, `--soft` and `--s1` are safe for type on `--bg`.
- `--accent` and `--s2` are fill-only. `--accent` falls to 2.9:1 and `--s2` to
  1.5–1.9:1 on preferred systems. Use `--ka` for accent type.
- Nocturne has three dependable peer grounds, not four. Cycle `--g0 --g1 --g2`; give a
  fourth peer a hairline outline. `--g3` duplicates another ground in most preferred
  systems.
- `--g2` is never a page ground. It separates from `--bg` by only 1.5–1.8:1 in four of
  five preferred systems.
- `--surface` is allowed only with a visible hairline. It sits just 1.04–1.19 above
  `--bg`; without an edge the panel disappears.
- A near-white `--ink` ground is only for a small node or contact pill. Never turn it
  into a prose panel or a large white slab.
- On a `--g?` ground, use its matching `--t?`. A kicker on a colour-field page inherits
  that page's text colour rather than forcing `--ka`.

### Images are content choices, not decoration

Use a photograph or other image whenever it communicates the slide more clearly,
credibly, or memorably than text alone. The supplied material does not have to
explicitly request an image; make that editorial choice from the content.

- Choose sources in this order: user-supplied images and visual materials first,
  including media embedded in or linked from the supplied material; then relevant
  imagery from the supplied references and related information; then an AI-generated
  image grounded in the slide's actual subject when it would work better or no suitable
  sourced image exists.
- Never add or generate an image merely to fill empty space. Use a colour field, figure, motif or
  generous negative space instead.
- Every caption, alt text and adjacent label must come from the source material.
- When no image improves the slide, delete the `data-photocell` frame. An empty rounded box
  is not decoration.
- Do not place body copy over a photograph unless it is a full-bleed image with a tested
  text-safe treatment.

## 4. Build the deck

Produce one standalone HTML file with one live `.deck`, one navigation runtime and one
16:9 `.stage` per page. Every `.slide` must be a direct child of `.deck`: the runtime
collects pages with `[...deck.children].filter(n => n.classList.contains('slide'))`, so
a nested slide renders normally but cannot be reached with an arrow key.

Before delivery this expression must be true, and you must press an arrow key yourself:

```js
document.querySelectorAll(".slide").length ===
  [...document.querySelector(".deck").children].filter((n) =>
    n.classList.contains("slide"),
  ).length;
```

Translate the outline into HTML in the same order. Use concise audience-facing copy,
one clear hierarchy and only sourced evidence. Set `<html lang>`, `<title>`,
`data-color-system` and the deck's `aria-label` from the actual presentation.

### 4a. Start from one naked layout

Choose by communication job, then adapt the copy and number of peers. Do not start from
`layouts/`.

| the slide is                      | use                                                                                                              |
| --------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| opening, agenda, chapter, closing | `cover` `toc` `section-divider` `close`                                                                          |
| prose or records                  | `statement` `longform` `two-column` `three-column` `numbered-rows` `big-quote` `data-table`                      |
| comparison                        | `comparison` quiet · `versus` loud · `pros-cons`                                                                 |
| numbers or data                   | `kpi-grid` `kpi-cards` `stat-highlight` `chart-bar` `chart-line` `chart-donut` `bubble-scale` `proportion-bands` |
| structure                         | `bento-grid` `arch-diagram` `flow-diagram` `mindmap`                                                             |
| time or sequence                  | `process-steps` `timeline` `roadmap` `gantt`                                                                     |
| sourced imagery                   | `team-grid` `image-gallery` `image-left` `image-right` `image-hero`                                              |
| testimony, proof or offer         | `quote-cards` `case-study` `pricing`                                                                             |
| technology or security risk       | `risk-matrix`                                                                                                    |

`mindmap` and `gantt` are Nocturne-native additions. Use the shipped files exactly:
`mindmap` uses ruled branches around one luminous idea field rather than generic radial
circles; `gantt` uses textless luminous duration bars whose percentage offset and length
encode dates. Do not import another template's visual grammar.

Rules carried by every layout:

- **No frozen container or viewport geometry on anything that holds text.** Do not put
  `width`, `max-width`, `min-width`, `height`, or a `flex-basis` in `cqw`, `cqh`, `px`,
  `vw` or `vh` on a text holder. The same units are forbidden for
  `left/top/right/bottom` unless the element is explicitly out of flow and the value is
  placement rather than size.
- The safe area is set once: `.fit { padding:12cqh 6cqw 8cqh }`. A page cannot redefine
  its own safe area by reducing that
  padding.
- Use Flexbox for the primary layout. Columns are `flex:1`; do not use Grid, float or
  absolute positioning to reconstruct measured placeholder geometry.
- Allowed exceptions are an `em` size for an ornament with no prose, `%` when the number
  is the datum, `height:1px` for a hairline and absolute offsets for an out-of-flow badge
  or decoration.
- A flex child holding an SVG or percentage-height bar needs `min-height:0`, and its row
  needs `align-items:stretch`. Measure the rendered bar; a percentage bar can silently become
  zero pixels when its parent has no definite height.
- A single filled box hugs its content with `align-self:flex-start;max-width:100%`.
  A row of filled peers is `flex:none`, each child is `flex:1`, and siblings equalise to
  the tallest child. Reserve a filling `flex:1` for a chart plot or image frame.
- Stress-test equal height by adding a sentence to the first peer and measuring every
  sibling. Do not trust `align-items` by inspection.
- Use the typography classes from `_shell.html`; move up a class instead of inventing a
  measured font size.
- Alternate ruled and filled peers across the deck. Nocturne provides
  `three-column`/`bento-grid`, `kpi-grid`/`kpi-cards` and `comparison`/`versus`.
- Identifiers and numeric columns take only the width they need and never wrap; prose
  absorbs the remaining space.

### 4b. Add decoration by page role

Use the five-item vocabulary exactly: organic `blob`, donut `ring`, sequence `node`,
`connector` and sourced-image `photocell`. Copy the actual paths and markup from
`decoration/decoration.html` and `decoration/item-sets.html`; do not invent generic
circles, squares, arches or colour blocks.

- Cover and agenda: exactly one ring plus one blob.
- Section divider and close: ring, large blob and a smaller `--bg` cut-out; put the page
  ground on `.stage`.
- Sparse content: one or two blobs, only in genuinely empty regions.
- Dense content: no ornament.
- A ring belongs only to section dividers and the close.
- Rings and large blobs bleed off a stage edge according to `PLACEMENT.md`; keep the
  small cut-out inside its parent motif.
- Colour fields belong to dividers and the close. Use `--g0`, `--g1` or `--g3`, never
  `--g2`, and put no panel on top.
- Sequence pages give every stage one node and the whole row one connector. Do not
  sprinkle a lone node elsewhere.
- Image frames exist only where sourced imagery exists.
- Page number appears on every slide. Brand chrome appears on ordinary opening, agenda
  and content pages; omit it on full colour-field pages.
- The brand/chrome band occupies the top 11% of the stage. Normal-flow content begins at
  12%, below it.

## Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Getting the container right

A percentage bar height resolves against its parent's **definite** height. Break
that chain and the bar computes to exactly `0` — it vanishes while the labels,
values and legend still render, so the page reads as merely empty. Measured on
generated decks: 52 of 558 percentage bars rendered at zero, and one deck spent
455s of gate repair on this alone.

`layouts/chart-*.html` already carries a structure that works. Copy it rather
than inventing lanes. Three rules make the chain definite:

1. **A bar is a direct child of the plot box.** Any level between them needs its
   own definite height, and one that lacks it zeroes everything below.
2. **All columns share one grid, so the label row is shared.** A label that wraps
   to two lines must cost every column the same height, or the bar above it is
   measured against a shorter ruler than its neighbours. Make the plot
   `display:grid; grid-auto-flow:column; grid-auto-columns:1fr` with
   `grid-template-rows:1fr auto …` (one row per item in a column, exactly — a
   spare row pulls the next column's first item into the previous column), and
   give each column wrapper `display:contents`. The markup grouping stays "one
   div per column"; only the rows become shared.

   Measured on the template's own `chart-bar.html`, changing nothing but one
   label to a wrapping name: baseline offset 0 → 19px, and the fourth bar 342 →
   324px — the value never changed, the bar just lost 5%. With the shared grid
   the same label costs all four bars the same 8%, and the ratios stay exact.

3. **Every level is either `flex:none` or `flex:1`** — sized by its content, or
   taking the remainder. There is no third kind.

4. **A value label never shares the lane with the bar it labels.** If it does,
   flex has to fit label + gap + bar into the lane, so it shrinks the bar — and
   only the bars tall enough to run out of room. The scale stops being linear at
   the top: measured on `bloom/chart-bar.html`, lane 336px, label 19px, gap 6px,
   every value above 92.5% rendered at the same 310px, so **96 and 100 drew
   identically**. Under the template's own "percentages of the tallest value"
   convention the tallest bar is always 100%, so this fires on every chart.
   Reserve the label row on the lane (`padding-top`, measured once per template)
   and set both children `flex:none`; the bar then resolves against the lane
   minus that reserve, the same reserve for every column.

Grouping two bars per category still obeys this, but the group wrapper needs
`align-self:stretch`, or it is sized by content and the lane inside it collapses.

Do not "fix" a flat chart by enlarging the numbers or switching to a table. The
values are right; the container chain is not.

## How full a page should be

Measured across all 902 layouts in the 23 shared templates, so this is what the
system already does — not a target invented for the occasion:

|                                                                                  | p25 |  median | p75 |
| -------------------------------------------------------------------------------- | --: | ------: | --: |
| vertical coverage (share of the stage height that carries ink or a filled block) | 33% | **43%** | 61% |
| ink area (share of the stage area)                                               |  9% | **12%** | 16% |
| lowest ink (how far down the page the content reaches)                           | 68% | **75%** | 90% |

**Aim for the middle column.** A content page that stops at 40% of the height and
leaves the rest blank reads as unfinished; one that runs past 25% ink area reads as
a wall. Both are allowed when the material calls for it — a statement page is one
huge line at 6% coverage, a table or a longform page is legitimately dense — but
neither is the default.

Two things that are **not** the same:

- **A void at the bottom.** Content stops early and nothing follows. This is the
  one to avoid; measured on the naked layouts, 73 of 902 pages do it.
- **Air between blocks.** A title, then a band of columns centred in the space
  below it. That is composition, not a defect — do not fill it just to fill it.

If the material genuinely does not fill the page, cut a column or merge the page
into its neighbour rather than padding sentences.

## 5. Verify before delivery

### Automated advisory check

- After fonts and images settle, run `tools/run.sh` once at 1600×900; rerun only when
  the HTML changes.
- The report is the visual review, so there is no need to take screenshots, create
  contact sheets, run image recognition, or visually review slides unless the user
  explicitly asks. It measures overflow, safe area, chrome band, column alignment,
  contrast, underfill, ornament vocabulary, empty photocells, text collisions, and deck
  navigation.
- Every reported item is a recommendation, never a blocker: fix the ones worth fixing
  from the slide, element, and DOM values it names; a zero report is not required.

### Check what the report cannot see

- Compare the final HTML with the outline: titles, the point each slide establishes,
  evidence, source status, unresolved placeholder text, and motif rhythm.
- Confirm from computed styles that the selected colour CSS loaded; an incorrect relative
  path can leave every slide unstyled while geometry probes still pass.
- Apply the static sizing audit in `layouts/README.md` to the final HTML.
- Inject an extra sentence into the first child of every peer row and remeasure sibling
  heights. Fix any unequal filled peer row.
- Confirm every page uses exactly one preferred `data-color-system`, all content stays
  inside the 6% safe area, no normal-flow text enters the top chrome band and no ornament
  sits over type.
- Confirm every ornament maps to the five-item vocabulary and its correct page role;
  rings never occur on content pages, dense pages carry none, and all large ornaments
  bleed.
- Confirm `--accent` and `--s2` are never used as text, `--surface` always has an edge,
  `--g2` is not a page ground and no large `--ink` prose panel exists.

## Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
