# Creative Agency

## Visual identity

Minimal and modern with generous negative space. Bold uppercase titles and monochrome imagery form the structure; a single accent colour and sparse leafy sprigs provide restrained emotion.

## Color system tokens

Before generating, read `color-system` from the prompt. If the prompt provides one of the valid tokens below, use it exactly. If it does not, select a token according to the content, audience, mood, information density, and readability. Use only one token throughout a deck.

The presentation category documented for this template is **M (single primary)** and its example token is `coral_studio`; determine the generation token using the rule above.

Valid tokens are limited to the following snake_case values:

- Single-primary M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`coral_studio`, `warm_sand`, `terracotta_clay`, `mono_ink`, `slate_corporate`, `nordic_frost`

The default color system used in `example/reference.jpg` is `coral_studio`.
This template lives on a light, warm ground with exactly one accent hue. A dark-field token (`midnight_mono`, `ocean_deep`, `sunset_maroon`) inverts the identity and must not be chosen by default.


After selecting a token, read `color-systems/<token>.css`, inline its only CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="coral_studio">
```

- Use `--bg`, `--ink`, `--soft`, and `--ph` for the page, body copy, secondary text, and image placeholders. In the reference palette `--surface` is only 1.04:1 against `--bg`, so it is not a visible panel colour.
- `--accent`, `--s1`, `--s2`, and `--s3` are source hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected by v1 for those source hues; use them for large icons or decorative symbols. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text. On an `--ink` colour field, use `--kad` for accent text. When a source hue needs stronger text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour blocks containing text, use `--g0` through `--g3` and pair the text with the corresponding `--t0` through `--t3`.
- HTML/CSS components must reference colours only through `var(--...)`; derive transparency, strokes, shadows, and gradients from defined tokens as well.

Use `--bg` itself to preserve broad areas of negative space. Let `--accent` create the single primary focal point, use `--s2` for supporting cues, and use `--s3` to organize secondary structure. The reference uses `--surface` zero times; separate prose with a hairline, or use a deliberate `--g?` field with its matching `--t?` text.

```css
.slide { background: var(--bg); color: var(--ink); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Space Grotesk` as the display typeface and `Lexend` as the body typeface.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600&family=Lexend:wght@300;400;500;600&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Space Grotesk";
  --fb: "Lexend";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600; available body weights are 300 / 400 / 500 / 600. Use `--fd` for titles, hero numbers, and section numbers. Use `--fb` for body copy, labels, chart annotations, and tables. For CJK text, preserve the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the template's own base stylesheet. Copy it verbatim into the single
`<style>` block, immediately after the inlined colour-system CSS, before writing
any slide. It defines the 16:9 stage, the type scale, and the chrome and visual
vocabulary classes (`.kicker`, `.pagenum`, `.dot`, `.badge`, `.tile`, `.card`)
that the rest of this document refers to. A deck that invents its own class
names instead of using these will not look like this template.

The radius scale is part of the template's character, not a generic default —
do not replace it, and do not add a `border-radius` that is not one of these
tokens.

```css
:root{
  /* Creative Agency is a SHARP template. Every rectangle is a true rectangle. */
  --r-xs: 0; --r-sm: 0; --r-md: 0; --r-lg: 0; --r-xl: 0;
  --r-pill: 0; --r-round: 50%;
  --fd: "Space Grotesk";
  --fb: "Lexend";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);border:1px solid color-mix(in srgb, var(--ink) 12%, transparent);}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}
  

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:6;}

.tile{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.tile>span{font-size:40cqw;line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.badge>span{font-size:40cqw;line-height:1;}
.tick{position:absolute;}
.card{border-radius:var(--r-md);}
.dot{border-radius:50%;}.qcircle{border-radius:50% 0 0 0;}.semi{border-radius:999px 999px 0 0;}.tri{width:0;height:0;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}
/* classified visual-vocabulary helpers — use these instead of repeating inline styles */
.mono{filter:grayscale(.95) contrast(.95);}
.photo{background:var(--ph);overflow:hidden;background-size:cover;background-position:center;background-repeat:no-repeat;border-radius:0;}
.dot{border-radius:50%;background:var(--accent);width:1.4cqw;height:1.4cqw;position:absolute;}
.chrome-foot{position:absolute;left:7cqw;bottom:3.4cqh;opacity:.65;}
```
The number inside a `badge` and any text inside a `tile` must be wrapped in a
`<span>`. The wrapper is what makes the text scale with the box: it is measured
against the badge's own width, so the figure stays in proportion at any size.
Text placed directly in the box only follows `--sz`, and a deck that sizes the
box with `width`/`height` instead will render a small number in a large frame.
Size these with `--sz`, not `width`/`height`.


## Visual vocabulary by role

Classify an element before counting it. Strict decoration must be
template-specific, textless, and independent of layout, data, media, content containers
and persistent chrome. By that definition, this template has **one decoration family:
`foliage-sprig`**. The other treatments below still define the template, but they keep
their actual chrome, content, media or layout role.

Each element below is given as exact markup. Copy the snippet, keep its geometry
and its `var(--...)` colours, and change only size, position, and text content.
The listed counts describe reference usage; they are not minimums or delivery
quotas. Use only the elements supported by the closest reference page role.

## Element reference patterns

These counts describe how a 13–15 slide reference deck uses the named elements.
They help reveal the template's rhythm, but are neither floors nor a request to
fill every page. More ornament is not more fidelity: past a point it costs
legibility, which costs more than the ornament was worth.

| Element | Role | Reference count per 13–15 slide deck | Note |
| --- | --- | ---: | --- |
| `foliage-sprig` | strict decoration | 25 | one on 5 slides, two on 10; paired sprigs differ in size |
| `accent-dot` | persistent chrome | 15 | exactly one on every slide; excluded from optional-decoration counts |
| `mono-photo` | media/content | 14 visual frames | not a target; use only what the material supports, always desaturated and square-cornered |
| `big-stat-hero` | content composition | 1 | use only when one figure is the slide's communication job |
| `sharp-rectangle` | layout/background treatment | structural | never count a panel, field, card or frame as decoration |
| `icon-tile` / node / badge / connector | content-bearing layout structure | 3 reference page roles | never count these as decoration or place them to satisfy a motif quota |
| `ink colour field` | background/layout | 0 | available in `layouts/comparison.html`, but not a reference habit |

Do not scale these counts mechanically for a longer or shorter deck. Rows that
say *only what the material supports* are content, not decoration: see the
photograph rule in `SKILL.md`. Use the table to check identity and page-role
rhythm, not to decide how many elements to add.

### 1. `foliage-sprig` — the coral leafy sprig

A thin curved stem carrying 4–5 pointed leaves, drawn in `--accent`. It is the
single most recognisable mark of this template.

**Reference use: 25 sprigs across 15 slides — 1.67 per slide.** 10 slides carry two, 5
carry one. Never two sprigs of the same size on one slide (10/10 reference pairs differ
in size).

**A pair goes on the diagonal: top-right + bottom-left** (9 of the 10 paired slides; the
cover is the exception, because its photo takes the right half). One sprig is the
left-leaning mirror, one the right-leaning, each leaning inward toward the middle of the
stage.

**Sprigs sit fully inside the stage.** All 25 reference sprigs are anchored at a corner
with a positive inset — `4–7cqw` horizontally, `3–10cqh` vertically. **Not one is cropped
by the stage edge.** Do not write a negative offset; that is a different template's
treatment.

A sprig may pass *behind* body copy — it is `z-index:2` and the text layer is `z-index:40`,
and 11 of the 15 reference slides do exactly this. When a sprig genuinely hurts
legibility, move the sprig, never the copy.

Full measurements: [decoration/PLACEMENT.md](decoration/PLACEMENT.md).

Left-leaning stem, shown in its measured top-right role (leaves alternate along a stem curving up-left):

```html
<svg data-decoration="foliage-sprig" data-bigcircle="1" style="position:absolute;right:4cqw;top:6cqh;width:14cqw;height:14cqw;z-index:2" viewBox="0 0 100 100">
  <path d="M 50 95 Q 50 60 18 25" stroke="var(--accent)" stroke-width="2.4" fill="none" stroke-linecap="round"/>
  <path d="M 0 0 Q 14 -8 28 0 Q 14 8 0 0 Z" transform="translate(45.2 84.5) rotate(-59.6)" fill="var(--accent)"/>
  <path d="M 0 0 Q 14 -8 28 0 Q 14 8 0 0 Z" transform="translate(39.6 72.3) rotate(-169.6)" fill="var(--accent)"/>
  <path d="M 0 0 Q 14 -8 28 0 Q 14 8 0 0 Z" transform="translate(34.0 60.0) rotate(-59.6)" fill="var(--accent)"/>
  <path d="M 0 0 Q 14 -8 28 0 Q 14 8 0 0 Z" transform="translate(28.4 47.8) rotate(-169.6)" fill="var(--accent)"/>
  <path d="M 0 0 Q 14 -8 28 0 Q 14 8 0 0 Z" transform="translate(22.8 35.5) rotate(-59.6)" fill="var(--accent)"/>
</svg>
```

Right-leaning stem, shown in its measured bottom-left role:

```html
<svg data-decoration="foliage-sprig" data-bigcircle="1" style="position:absolute;left:5cqw;bottom:8cqh;width:11cqw;height:11cqw;z-index:2" viewBox="0 0 100 100">
  <path d="M 50 95 Q 50 60 82 25" stroke="var(--accent)" stroke-width="2.4" fill="none" stroke-linecap="round"/>
  <path d="M 0 0 Q 14 -8 28 0 Q 14 8 0 0 Z" transform="translate(54.8 84.5) rotate(-10.4)" fill="var(--accent)"/>
  <path d="M 0 0 Q 14 -8 28 0 Q 14 8 0 0 Z" transform="translate(62.3 68.2) rotate(-120.4)" fill="var(--accent)"/>
  <path d="M 0 0 Q 14 -8 28 0 Q 14 8 0 0 Z" transform="translate(69.7 51.8) rotate(-10.4)" fill="var(--accent)"/>
  <path d="M 0 0 Q 14 -8 28 0 Q 14 8 0 0 Z" transform="translate(77.2 35.5) rotate(-120.4)" fill="var(--accent)"/>
</svg>
```

### 2. `accent-dot` — persistent chrome, not optional decoration

A single small filled circle in `--accent`, `1.4cqw` across, tucked into a
corner. It is the quiet counterweight to the sprig.

**Reference use: exactly one dot on every slide, 15/15.** Put it in a corner the sprigs leave free; 14/15 reference pages do. Because it is persistent chrome, do not include it in optional-decoration statistics.

```html
<div class="dot" style="position:absolute;left:7cqw;top:7cqh;width:1.4cqw;height:1.4cqw;background:var(--accent)"></div>
```

### 3. `mono-photo` — media/content, not decoration

Photographs in this template are always near-monochrome and always
square-cornered. Colour photography is not part of this identity.

**Reference use: 14 visual frames across 15 pages, concentrated on 6 page roles.** That is
diagnostic, never a quota. Use a photograph only where the supplied material describes a
subject worth showing. If the material describes no such subject, carry no photograph and
use a sprig plus generous space instead. Every photograph that is present is desaturated
and square-cornered. A full-bleed edge crop (flush to the stage edge, no margin) is the
cover treatment; interior image layouts keep the frame inside the safe area.

```html
<div style="position:absolute;right:0;top:0;width:42cqw;height:100cqh;background:var(--ph);
            border-radius:0;overflow:hidden;filter:grayscale(.95) contrast(.95);
            background-size:cover;background-position:center;background-repeat:no-repeat;
            background-image:url('<image>')"></div>
```

### 4. `big-stat-hero` — content composition, not decoration

When a slide's job is a single figure, that figure fills the slide: `.stat` at
`9cqw`–`13cqw`, aligned left, with a short caption below and secondary figures
stacked in a narrow column beside it.

**Reference use: one big-stat-hero slide.** Use it when a slide's communication job is one dominant figure; do not add one as a quota.

```html
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;padding:12cqh 7cqw 9cqh">
  <div style="flex:1;min-height:0;display:flex;align-items:center;gap:4cqw">
    <div style="flex:2;min-width:0">
      <div class="kicker" style="color:var(--ka)">A year of growth</div>
      <div class="stat" style="font-size:11cqw;margin-top:2cqh">91,2%</div>
      <p class="body soft" style="margin-top:2.4cqh">One sentence that explains the number.</p>
    </div>
    <div style="flex:1;min-width:0"><!-- secondary figures, stacked in normal flow --></div>
  </div>
</div>
```

### 5. `sharp-rectangle` — layout/background treatment, not decoration

Every panel, photo, surface and colour field in this template is a true
rectangle with square corners. This is why the radius scale above is `0`.
Rounded cards are the single most common way this template gets ruined.

### 6. `icon-tile` — content-bearing layout structure, not decoration

The reference deck draws **4 of these on one fifteen-slide page**, and generated
decks draw none, because until now this file never mentioned them. They are how
this template renders a list of capabilities, services or steps: a run of small
squares in different ground tiers, each carrying one thin line icon, set beside
or above the label rather than inside a bullet.

**Reference use: one row of four icon-tiles on the capabilities page.** Use the treatment
when the content is a comparable set of 3–4 services, capabilities, or steps. Vary the ground tier across the row exactly as below —
the row reads as one set because the icons match, not because the colours do.

```html
<div class="tile" data-tile="1" style="--sz:5cqw;flex:none;background:var(--g0);color:var(--t0)"><svg viewBox="0 0 24 24" style="width:50%;height:50%;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round"><circle cx="12" cy="8" r="6"></circle><polyline points="9 13 7 22 12 19 17 22 15 13"></polyline></svg></div>
```

The icon inside is a 24×24 line drawing at `stroke-width:1.8`, sized `50%` of
the tile so it scales with it, and it inherits `currentColor` from the tile's
own `color`. Any simple outline glyph works; do not fill them, and do not swap
in a solid pictogram.

## Strict decoration reference profile (diagnostic only)

Measured from this template's own reference at 1600×900:

| diagnostic | reference |
|---|---:|
| decoration families | 1 — `foliage-sprig` |
| declared decoration elements | 25 |
| decoration per slide | 1.67 |
| slides with a pair | 10 / 15 |
| decoration crossing the stage | 0 / 25 |
| optional item-attached motifs | 0 |

The accent dot, footer and page number are persistent chrome and are excluded. Image
frames, icon tiles, process nodes, badges, connectors, cards, colour fields, rectangular
backgrounds, content containers and grid cells are content or layout and are excluded.
There is no `item-sets.html` because the reference has no genuine textless motif attached
to repeated items.

Read the figures only as a whole-deck drift signal, never a quota. First choose the closest
page role in [layouts/](layouts/); then use its single sprig or
unequal pair. Sparse compositions are intentional.

The reference has 14 visual photo frames, but photography is content, not decoration and
never a target. A text-only source can correctly produce zero photographs.

This template paints about **0.5 labelled boxes per slide**. Those boxes remain content
structure, not decoration. Turning every label into a bordered chip still makes the deck
too busy, but it does not raise a decoration count.

**A kicker is not a chip.** In this template's reference deck the `kicker`, the
page number, the running head and the standfirst are plain text — no background,
no border, no shadow, no rounded pill around them. Every one of the 23 reference
decks agrees on this, and giving them a box is the single most common way a
generated deck drifts: a kicker appears on every slide, so boxing it adds one
false chip per slide and doubles this template's labelled-box count on its own.

Only content structures demonstrated with a fill, such as `badge` or `tile`, carry a
background.
Everything else that is text stays text.

**Before delivering, audit identity.** On three
representative slides, verify that every declared decoration is a `foliage-sprig` and that
no structural geometry has been relabelled as decoration. Use the table above only to
notice gross whole-deck drift.

Content still comes first. Never push text off the stage, cover it, or drop a point. Never add a photograph
the source material does not support. A slide carrying six bullets may correctly
carry only the page-role sprig treatment and no additional optional motif.


## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** A label positioned with `left:88cqw` will
overflow the moment its text is longer than the author guessed, and CJK copy is
routinely wider than the Latin draft it was written against. Anchor anything in
the right third with `right:` instead of `left:`, and anything in the bottom
third with `bottom:` instead of `top:`. A block anchored to the edge it is near
grows inward, where there is room, instead of outward into nothing. Give any
absolutely-positioned text an explicit `max-width` so it wraps rather than
extends.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

A finished slide keeps repeated items on one structural alignment and keeps
content clear of every unintended stage edge.

## Required chrome

Every slide carries all three, or the deck is incomplete:

1. **Footer label**, bottom-left — an uppercase, wide-tracked `.kicker`:
   `<div class="kicker" style="position:absolute;left:7cqw;bottom:3.4cqh;opacity:.65">Studio &nbsp;·&nbsp; agenda</div>`
   Use a stable left word drawn from the deck's subject, then `·`, then the
   slide's own section word.
2. **Page number**, bottom-right: `<div class="pagenum">04</div>` — two digits, zero-padded.
3. **Exactly one accent dot**, in a corner the sprigs leave free. The reference is 15/15;
   it is chrome and excluded from optional-decoration statistics.

## Required decoration rhythm

Use one or two declared `foliage-sprig` elements in the closest reference page role: one
on a dense page, or the unequal diagonal pair on a normal content page. The reference
range is 1–2, never 0 or 3. This is the only strict decoration family.

## Background rhythm

The ground is `--bg` on most slides — broad, calm, deliberately empty. Vary the
deck with these, not with texture:

- **a row of filled `--g?` cards** — this is what the reference actually uses, on its
  testimonial slide and its pricing slide. Ground them `--g0 / --g2 / --g1`, cycling so
  neighbours differ, with the matching `--t?` text;
- a full-bleed mono-photo half, as on the cover;
- one near-empty slide carrying only a large statement and a sprig;
- a full-height `--ink` field occupying 40–56% of the stage, with `--bg` text on it, for
  one comparison slide.

**Measured on the reference: zero `--ink` colour fields and zero full-bleed pages.** The
`--ink` field is available and `layouts/comparison.html` shows one, but it is not this
template's habit and no deck is wrong for omitting it. What every reference deck does have
is two filled card rows against otherwise calm `--bg`.

A deck where all 15 slides are plain `--bg` with no filled row anywhere has failed the
rhythm rule. A deck with no `--ink` field has not.

## Decoration safe area

Decoration is placed before content, but it never wins against legibility.

- The content safe area is the template constant set once on `.fit`: `12cqh 7cqw 9cqh`.
- Sprigs sit at `z-index:2` behind `.fit` at `z-index:40`. The reference has a sprig
  geometrically behind body copy on 11/15 pages (28 overlaps), so overlap itself cannot
  gate. Move a sprig only when it makes the copy harder to read; never move the copy.
- All 25 reference sprigs remain fully inside the stage, with positive insets. Never crop
  one or give it a negative edge offset.
- Never place body copy or a caption directly on top of a photograph unless the
  photograph is a full-bleed field with a text-safe treatment behind the copy.
- Decorations never land on text or reduce title legibility. When the two
  conflict, move the decoration, not the text.

## Never do this

- Never use `border-radius` on a panel, card, photo, surface, or colour field.
  The only round things in this template are the accent dot and, rarely, a
  circular photo.
- Never use disc/dot list bullets. Structure lists with a top hairline rule
  (`border-top:1px solid var(--ink)`) per row, or with `01 / 02 / 03` numerals.
- Never use drop shadows.
- Never centre the cover title. This template is left-aligned and uppercase.
- Never use more than one accent hue. One accent, one deck.
- Never let a slide go out without its footer label and page number.

## Self-check before delivery

Review identity and page-role fidelity. Fix the deck before
delivery if any line fails.

0. Every declared decoration is a `foliage-sprig`; no card, tile, node, badge,
   connector, field, container, media frame or chrome is counted as decoration.
1. Sprigs appear only on the page roles where the reference uses them, with no loss of
   text legibility. A sprig behind text is allowed and measured.
2. Every slide carries the items listed under `Required chrome`.
3. Every photograph follows the documented template treatment and illustrates
   a subject the material describes. Zero photographs is valid.
4. Every prohibition under `Never do this` was checked against the final HTML.
5. Exactly one `data-color-system` token is present and it is preferred.
6. The strict decoration profile was read only as a gross drift signal.

Visual reference: [example/reference.jpg](example/reference.jpg) —
the rendered proof of every rule above. [layouts/](layouts/)
is the same deck in code; open it when a snippet here needs more context.
