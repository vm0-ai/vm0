---
name: creative-agency
description: Create a standalone 16:9 HTML presentation deck with the Creative Agency visual identity and direct-HTML workflow. Use when the user selects the Creative Agency presentation template or explicitly names creative-agency as the deck style. Best suited to minimal modern portfolios, brand narratives, culture decks, and creative pitches.
---

# Creative Agency presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one standalone HTML file with one live `.deck`. Keep every `.slide` as a direct child, give it one 16:9 `.stage`, and include the deck CSS and keyboard-navigation script once.
- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Create one direct-child `.slide` per planned page and one 16:9 `.stage` inside each slide.

### Layout — start from a canonical layout

For each slide, pick the layout in [layouts/](layouts/) whose name matches what the
slide has to do, and adapt it. Read [layouts/README.md](layouts/README.md) for the
index and the sizing rule. The 36 files are text only, so what you copy is the
structure and nothing else.

| the slide is                               | use                                                                                         |
| ------------------------------------------ | ------------------------------------------------------------------------------------------- |
| a title, agenda, chapter break, or closing | `cover` `toc` `section-divider` `close`                                                     |
| prose                                      | `long-form` `two-column` `three-column` `color-cards` `bullets` `numbered-list` `big-quote` |
| two things compared                        | `comparison` quiet, ruled · `pros-cons` loud, filled                                        |
| numbers                                    | `stat-highlight` `kpi-row` `kpi-cards` `table` `chart-bar` `chart-line` `chart-pie`         |
| a sequence in time                         | `process-steps` `timeline` `roadmap` `gantt`                                                |
| a structure                                | `flow-diagram` `architecture` `mindmap`                                                     |
| people, work, offers                       | `case-study` `profile-grid` `quote-cards` `pricing` `feature-grid`                          |
| imagery the material actually supports     | `image-left` `image-right` `image-hero` `image-grid`                                        |

Rules that carry over from those files into anything you write:

- **Do not write a `width`, `max-width`, `min-width`, `height`, `left`, `top`, `right` or
  `bottom` in `cqw`, `cqh`, `px`, `vw` or `vh` on anything that holds text**, and
  that includes `flex:0 0 4cqw`. The safe area is set once, by the `.fit` padding
  `12cqh 7cqw 9cqh`. Peer columns are `flex:1`. A width written by hand is a
  measurement of the placeholder string, and it will clip or wrap your real text —
  especially in CJK, which is routinely wider than the Latin draft.
- Three allowed exceptions: `left/top/right/bottom` for placement on an
  out-of-flow `position:absolute` element; `em` for ornaments containing no prose; and
  `%` in a bar chart or gantt where the number is the datum.
- Any flex child holding an SVG or a percentage-height bar needs `min-height:0`.
- **A box with a visible fill is sized by its content, never by the stage — both
  dimensions.** Height: `flex:none` on the row, `flex:1` on each sibling so they
  equalise to the tallest one. Width: `align-self:flex-start;max-width:100%` on a
  single box, because `.fit` stretches every child to full width by default. A
  **row of peers** stays equal-width and divides the safe area: one box hugs, a row
  of boxes divides. Reserve a filling `flex:1` for an image frame or a chart area.
- Ground filled cards on `--g0 / --g2 / --g1`, cycling so neighbours differ, with the
  matching `--t?` text. **Never ground a card on `--g3`** — it is byte-identical to
  `--ink`, and a dark slab reads as a photo placeholder. Reserve it for the small
  content-marker roles documented in `design-system.md`.
- **Every rectangle is a true rectangle.** Each radius token is `0`. The only round
  things in this template are the `accent-dot` and the circular `process-node`.
- Titles are uppercase and left-aligned. Never centre a cover title.
- Use the classes, not new font sizes. If something needs to be bigger, move up a
  class.

### Recommended layout approach

- Recommended starting point: use a clear top-to-bottom or left-to-right flex relationship. Aim to balance the visual weight of its regions and place each primary content group near the optical center of its own region. A left-to-right composition can vertically center the groups on each side; a top-to-bottom composition can center groups within balanced bands. Adapt alignment and asymmetry to the content and the template's visual character.
- Use a `data-layout` flex container for the primary spatial relationship. Keep content groups in normal flow; reserve absolute positioning for chrome, the declared sprig layer, and demonstrated media/background layers, never for the main text layout.
- Preserve the template's original visual character from `design-system.md` and the examples. Compose content, structural treatments, chrome and strict decoration according to their documented roles.
- Review all regions and layers as one composition. Aim for readable balance, allowing intentional overlap and out-of-flow placement when they strengthen hierarchy, meaning, or the template's signature style.
- Treat every slide as a projected presentation canvas. Write concise visible copy for the audience and keep one clear hierarchy of title, supporting content, and evidence on each page.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep chrome, typography, colour rhythm, structural treatments and sprig geometry consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

### Composing the identity layer

- Build every slide in three layers: a **ground** layer (stage background, colour
  fields, panels), a **decoration** layer (only the foliage sprig from
  `design-system.md`, positioned absolutely but kept fully inside the stage), and a
  **content** layer (`.fit` and the main text). A sprig may pass behind text only
  when it does not reduce legibility.
  Give the decoration layer a `z-index` below the content layer unless the
  element is meant to sit on top.
- Compose decoration and content together so their placement remains intentional.
- Copy the `Deck shell` CSS from `design-system.md` verbatim into the single
  `<style>` block and build slides out of its class names. Do not invent a
  parallel set of utility classes.
- Vary the composition slide to slide, but keep the chrome, the radius scale, and
  the classified visual vocabulary constant. Variety belongs in the layout, never in the
  identity.
- Use the helper classes that the `Deck shell` CSS actually defines (`.photo`, `.mono`,
  `.dot`, `.tile`, `.badge`, `.card`, `.chrome-foot`) instead of
  repeating the same long inline style on every slide. They exist so the
  documented treatment is one class name, not a paragraph of CSS to remember, and
  a forgotten class is the usual reason a treatment goes missing.
- Whitespace is part of the composition. A deliberately quiet half-slide can be
  finished when the hierarchy is balanced. Add a signature element or colour field only when the
  documented page role supports that composition.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

- The photo treatments in `design-system.md` describe **how** a photograph looks
  in this template when there is one. They are not an instruction to produce
  that many photographs.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

- The `Visual vocabulary by role` section classifies each treatment before showing
  exact markup. The only strict decoration family is `foliage-sprig`; the accent dot
  is persistent chrome; tiles, nodes, badges and connectors are layout/content; and
  photographs are content. **Use demonstrated treatments only in their stated role.**
  Do not relabel structure as decoration or substitute generic geometry.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — visual vocabulary, background
     treatment, chrome;
  4. every declared decoration follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink copy,
  drop a point, or invent something to fill a slot. A deck that is accurate but
  visually anonymous also fails. Choose the sprig treatment documented for the
  slide's page role, and omit it when it competes with content.

- Optional: [example/reference.jpg](example/reference.jpg) for the visual identity
  and [layouts/](layouts/) for full-slide scale, rhythm,
  and composition. When the reference image and this document appear to disagree,
  follow `design-system.md`.
- A creative-agency slide is three independent layers, and this folder keeps them
  in three separate places. Build them in this order and they cannot fight each
  other:

  | z-index | layer                                                  | source                                                                                                       |
  | ------- | ------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------ |
  | 2       | strict decoration — foliage sprigs                     | [decoration/PLACEMENT.md](decoration/PLACEMENT.md), [decoration/decoration.html](decoration/decoration.html) |
  | 6       | persistent chrome — footer kicker, pagenum, accent dot | `PLACEMENT.md` section A, `layouts/_shell.html`                                                              |
  | 40      | main content, inside `.fit`                            | [layouts/](layouts/) — 36 naked layouts                                                                      |

  Note this template's persistent chrome is at the **bottom** of the stage, not the
  top.

  `layouts/` shows all three fused together at full scale. Use it to
  judge rhythm; take structure from `layouts/` and ornament placement from
  `PLACEMENT.md`.

- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. Its packets carry this template's semantic column and row behaviour; the corresponding production structures are `layouts/big-quote.html`, `layouts/comparison.html`, and `layouts/table.html`. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use the prompt's `color-system` when supplied, otherwise a preferred token from
  `design-system.md`. Inline that one `color-systems/<token>.css` in the final HTML.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Every `.slide` must be a direct child of `.deck`

The navigation runtime collects pages with
`[...deck.children].filter(n => n.classList.contains('slide'))`. A slide nested one
level deeper, or written after the deck's closing `</div>`, **renders perfectly and
is unreachable by keyboard**. The final QA hard gate verifies one deck, exact
direct-child reachability, and the live key state; do not repeat it in the console or
with a manual key walk.

#### Decoration and identity checks while authoring

While authoring, walk the `Self-check before delivery` list in
`design-system.md` as an identity audit:

- Confirm the content survived and every slide carries the required chrome.
- Verify every declared decoration is a `foliage-sprig`; never count a tile, node,
  badge, connector, card, colour field, media frame or chrome as decoration.
- Confirm each sprig is appropriate to that slide's page role. A geometric crossing is
  allowed and remains an optional-review candidate under `Automated QA` below.
- Search the finished HTML for each pattern named in `Never do this` and remove
  every hit.

The accent dot is persistent chrome, not optional decoration; there is no
item-attached optional motif.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
