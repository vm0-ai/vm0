# creative-agency — naked layouts

36 layouts, text only. No decoration, no colour decisions, no measured geometry.
Pair one of these with [`../decoration/PLACEMENT.md`](../decoration/PLACEMENT.md) to build
a slide.

A full-deck HTML example taught a generated deck the *measured geometry of one deck's text* —
`width:46cqw` is not a design decision, it is the observed width of one string at one font
size. These files carry structure instead, and structure is what survives.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 36: zero `width` / `max-width` / `min-width` / `height` / `left` /
`top` / `right` / `bottom` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex-basis`. `flex:0 0 4cqw` freezes a column exactly the way `width:4cqw`
does, and an audit that only greps `width` will miss it.

Four exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline rule.
- **`em`** on a textless mark — for example a legend swatch or the accent rule in
  `big-quote`. This sizing exemption does not reclassify data marks or rules as decoration;
  `em` scales with the type around it, so it cannot freeze a text box.
- **`%`** in `chart-bar`, `chart-pie` and `gantt` only, where the number *is* the datum. A
  bar that is 62 % tall is reporting 62.

Everything else stretches. Columns are `flex:1`. **The safe area is set once, by the padding
on `.fit`: `12cqh 7cqw 9cqh`.** 7 % is this template's constant — the reference's left inset
is 7.1 % on 15 of 15 pages. (bloom's is 6 %; if you point `audit.js` at this template, set
`SAFE = 0.07`.)

Any flex child holding an SVG or a percentage-height bar needs `min-height:0`, or the SVG's
intrinsic aspect ratio pushes it past the stage edge.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions. Not a slide.
It carries the **`design-system.md` shell verbatim**, which means every radius token is `0`.

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `long-form` `two-column` `three-column` `color-cards` `bullets`
`numbered-list` `big-quote`

**Numbers** · `stat-highlight` `kpi-row` `kpi-cards` `table` `chart-bar` `chart-line`
`chart-pie`

**Time and sequence** · `process-steps` `timeline` `roadmap` `gantt`

**Structure** · `flow-diagram` `architecture` `mindmap`

**Two things compared** · `comparison` `pros-cons`

**People and work** · `case-study` `profile-grid` `quote-cards` `pricing` `feature-grid`

**Imagery** · `image-left` `image-right` `image-hero` `image-grid` — all four delete
cleanly. When the source has no imagery, drop the `data-photocell` frame and use a prose
layout; do not leave an empty box.

## Where the list came from

**Thirteen are the reference deck's own pages**, one per composition it actually
demonstrates: `cover` `toc` `section-divider` (×3 in the reference) `image-right`
`numbered-list` `profile-grid` `feature-grid` `process-steps` `image-grid` `stat-highlight`
`quote-cards` `pricing` `close`. Those are non-negotiable — they are the compositions this
template knows.

**Three come from `composition-recipes.html`**: `big-quote`, `comparison`, `table`.

**Fifteen were added** because a real deck needs them and the template had none: `bullets`
`two-column` `three-column` `color-cards` `kpi-row` `kpi-cards` `timeline` `gantt`
`chart-bar` `chart-line` `chart-pie` `pros-cons` `flow-diagram` `image-left` `image-hero`.

**Five more layouts close distinct task gaps** found during the full coverage review: `long-form`
for sustained editorial prose; `roadmap` for forward-looking horizons across workstreams;
`architecture` for layered system relationships; `mindmap` for one need branching into
parallel directions; and `case-study` for a compact challenge-response-outcome narrative.
They do not duplicate `two-column`, `timeline`, `gantt`, `flow-diagram`, or `profile-grid`.

Deliberately **not** added, because this remains a brand-and-pitch template rather than an
engineering interface:

- `terminal`, `code`, `cta` — a large dark rounded rectangle reads as a photo placeholder,
  and a slide cannot be clicked.
- `todo-checklist` — `numbered-list` already carries an ordered set of actions.

36 is an outcome of task coverage, not a target filled with variants.

## Which content-bearing treatment belongs to which layout

The layouts are naked on purpose, but several describe a **set of peer items**. Tiles,
nodes, badges and connectors are layout/content structure, not decoration. Their production
markup lives in the corresponding layout files; there is no decoration `item-sets.html`.

| layout | use |
|---|---|
| `feature-grid` `three-column` `flow-diagram` | one `icon-tile` per item, ground cycling `--g0 --g2 --g1 --g3` |
| `process-steps` `timeline` | one `process-node` per stage + one `connector` |
| `numbered-list` `bullets` | one `number-badge` per point, ground cycling `--g0 --g2 --g1` |
| `architecture` | filled peer nodes arranged in explicit layers; nodes are structure, not decoration |
| `mindmap` | one content-bearing hub and four ruled branches; connectors are structure |
| `two-column` `long-form` `roadmap` `comparison` `table` `toc` | nothing — these hold prose; the hairline rules in them are the device |
| `color-cards` `kpi-cards` `quote-cards` `pricing` `pros-cons` `case-study` | nothing — the card *is* the colour |

Every layout also takes one or two declared foliage sprigs. The accent dot is persistent
chrome, not optional decoration. See `PLACEMENT.md`.

## Ruled or filled — every peer row has both

20 of the 36 layouts separate their items with a 1px rule. That is a skewed menu on its own:
an agent sampling it puts the same horizontal line on every slide. So each peer-row content
type has two treatments, and neither is more on-template than the other:

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `color-cards` (scales 2–4) |
| a row of numbers | `kpi-row` | `kpi-cards` |
| two things compared | `comparison` | `pros-cons` |
| ordered stages | `process-steps` | `flow-diagram` |
| a set of capabilities | `feature-grid` | `color-cards` |

The filled versions cycle `--g0 --g2 --g1` so neighbours never share a colour. Pick the
filled version when the items are short and parallel, when the ruled version reads thin, or
simply when the previous slide was ruled.

**`--g3` is not in that cycle.** It is byte-identical to `--ink` (`#3A2A26`), and a `--g3`
card is a dark slab that reads as a photo placeholder. The reference uses it twice, both
times on a content-bearing marker under 6cqw. It stays in those demonstrated marker roles
and out of the card cycle.

## A filled box is sized by its content, never by the stage

Both dimensions.

```
height   row     flex:none      height comes from the tallest child, not the stage
         child   flex:1         siblings equalise to that tallest child
         group   wrapped in flex:1;min-height:0;…;justify-content:center

width    box     align-self:flex-start; max-width:100%
```

`flex:1` on the **row** and `flex:1` on the **child** look like the same instruction and do
opposite things. On the row it fills the stage, the cards inherit the stage's height, and
you get a slab of colour that is half empty.

`.fit` is a column flex with `align-items:stretch`, so **every child is full-width by
default**. `align-self:flex-start; max-width:100%` opts one box out. The exception is a
**row of peers**, which stays equal-width and divides the safe area: one box hugs, a row of
boxes divides.

Stress-tested rather than trusted: an extra sentence was injected into the first child of
every repeated ruled or filled peer row across the 36-layout catalogue and sibling heights
compared. All peer rows equalise. Intentionally asymmetric role splits such as the
`long-form` lead/article pair and `roadmap` workstream cells are not peer cards and do not
equalise by design.
`numbered-list` did not on the first pass — its outer row carried `align-items:flex-start`,
which is invisible while the columns are plain text and instantly visible the moment
anything adds a background.

## Colour

Contrast measured against the `#FFF9F6` page. **Fill-only: `--accent` 2.62, `--s2` 2.49,
`--s1` 1.68, `--g1` 1.68, `--surface` 1.04.** Legible as type: `--ink` / `--ka` / `--s3` /
`--g3` 13.08, `--soft` 6.12, `--g2` 4.75, `--g0` 4.59.

Checked on all 36: zero text below 3.0:1.

For a small coloured label on the page ground, cycle `--g0 --g2 --g3`. On a `--g?` ground
use the matching `--t?`, never a scheme colour. `.card` is a square-corner helper with no
default fill; give it an explicit ground and matching text when a filled card is intended.

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` ·
structure `stage fit deck slide band card tile badge` ·
marks `dot tick soft dim mono photo pagenum chrome-foot`.

Sizes live in those classes. If something needs to be bigger, use the next class up — do not
write a `font-size`. Titles in this template are **uppercase and left-aligned**; never
centre a cover title.
