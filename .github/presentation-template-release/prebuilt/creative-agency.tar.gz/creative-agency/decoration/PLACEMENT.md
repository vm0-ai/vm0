# creative-agency — strict decoration classification and placement

Everything here is measured from the original reference deck (15 slides at 1600×900).
Decoration is classified before it is counted: it must be template-specific, textless,
and independent of layout, content, data, media and persistent chrome.

## Strict result

| diagnostic | reference |
|---|---:|
| strict decoration families | 1 — `foliage-sprig` |
| declared decoration elements | 25 sprigs |
| slides carrying decoration | 15 / 15 |
| slides carrying a pair | 10 / 15 |
| decorations crossing the stage edge | 0 / 25 |
| optional item-attached motifs | 0 |

The two stem directions are mirrored variants of the same `foliage-sprig`, not two
families. There is no optional per-item decoration and therefore no
`item-sets.html`. Tiles, nodes, badges and connectors remain layout structure.

Open `decoration.html` for the rendered classification ledger and placement examples.

## Layer model

| z-index | role | source |
|---|---|---|
| 2 | strict decoration — foliage sprigs | this file and `decoration.html` |
| 6 | persistent chrome — footer, page number, accent dot | section A and the shell |
| 40 | main content inside `.fit` | `../layouts/*.html` |

Decoration sits below text and never enters `.fit`.

## A · Persistent chrome is separate from decoration

All 15 reference slides carry these three items:

- `left:7cqw; bottom:3.4cqh` — footer kicker, `opacity:.65`, of the form
  `Studio · <section word>`;
- `right:3cqw; bottom:3.2cqh` — two-digit, zero-padded `.pagenum`;
- exactly one `accent-dot`, `1.2cqw` on content slides and `1.4cqw` on cover/close,
  in a free corner about `7cqw / 3–11cqh` from the stage edge.

The dot is 15/15 persistent chrome, so it is not included in optional-decoration counts.
There is no top chrome. The `11cqh` content start is a composition margin, not clearance
for a wordmark; reference in-flow text above that line is zero.

## B · Foliage-sprig pair

10 of 15 reference slides carry two sprigs. Nine of those pairs are diagonal:
top-right plus bottom-left. Across all ten pairs:

- the sizes differ 10/10; observed range `11–24cqw`, median `14cqw`;
- the left-leaning stem goes top-right and the right-leaning mirror goes bottom-left,
  so both lean toward the stage centre;
- both use `var(--accent)`, `z-index:2`, full opacity;
- neither is layout structure: both are declared
  `data-decoration="foliage-sprig"`.

The cover is the one composition exception: its photo occupies the right half, so both
sprigs retreat to the left.

## C · Nothing bleeds

Zero of 25 reference sprigs crosses the stage edge. Standard pages use positive corner
insets of `4–7cqw` horizontally and `3–10cqh` vertically. Never import bloom's negative
edge offsets; a cropped sprig is not this template's treatment.

## D · Sprigs may pass behind text

11 of 15 reference slides have a sprig geometrically behind body copy, 28 overlaps in
total. The sprig is at `z-index:2` and `.fit` at `z-index:40`, so text wins. Overlap cannot
gate because the reference does it. Move a sprig only when it actually harms legibility;
never move or shrink the copy to make room for decoration.

## E · What is not decoration

| element | actual role |
|---|---|
| `.dot` accent dot | persistent chrome, 15/15 |
| `data-tile` icon tile | content-bearing peer-item treatment |
| `data-node` process node | content-bearing sequence structure |
| `data-badge` number badge | content-bearing list marker |
| `data-connector` line | sequence/layout structure |
| `data-photocell` | media/content frame |
| cards, colour fields, rectangular backgrounds | layout or content container |
| footer kicker and `.pagenum` | persistent chrome |

Do not mark any of these with `data-decoration`, `data-deco`, or `data-ornament`, and do
not use them to satisfy a decoration frequency. They may still be essential to their
specific layout role.

## F · Colour and shape traps

Against the `coral_studio` page ground:

| token | ratio | use |
|---|---|---|
| `--ink`, `--ka`, `--k1..k3`, `--g0`, `--g2`, `--g3` | readable | text or matched fields |
| `--accent` 2.62, `--s2` 2.49, `--s1`/`--g1` 1.68 | fail as text | fill only |
| `--surface` 1.04, `--ph` 1.17 | not a visible panel | media placeholder only where applicable |

- Reference `--surface` uses are zero; `.card` has no default fill.
- Use matching `--t0..--t3` text on a `--g0..--g3` field.
- A kicker is plain text, never a chip.
- Every rectangular content or background element has square corners. A rectangle is
  still not decoration.

## G · Reference audit ledger

```
                                      reference
declared foliage sprigs                    25
sprigs per page                          1.67
pages with a pair                       10/15
sprigs bleeding past the stage           0/25
optional item-attached motifs                0
accent-dot chrome per page                1.00
--surface uses                               0
text under 3.0:1                             0
text above 11% stage height                  0
text outside the 7% safe area                0
```

Frequencies diagnose whole-deck drift; they are not quotas. Page-role fidelity and
legibility still decide whether a page uses one sprig or the unequal pair.
