# Landing Consulting

## Visual identity

Continuous scrolling like a website landing page: persistent navigation, dashed connectors, highlighted words, overlapping photos, and oversized numbers. The overall character is sharp, digital, and high-contrast.

## Color system tokens

Read the prompt's `color-system` before generating. If it supplies one of the valid tokens below, use that token exactly. If it does not, choose from the tokens below according to the content, audience, mood, information density, and readability. Use only one token throughout a deck.

The presentation category documented for this template is **V (multicolour)**, with `pop_art` as its example token. Determine the generated deck's token using the rule above.

Use only the following snake_case values as valid tokens:

- Single-primary M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`pop_art`, `prism`, `carnival`, `mint_tech`, `bauhaus_primary`

The default color system used in `example/reference.jpg` is `pop_art`.
Picking a token outside this list is how a deck ends up looking like a different
template: a finance source, for instance, pulls every template toward the same
muted corporate grey unless the list stops it.


After selecting a token, read `color-systems/<token>.css`, inline that file's single CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="pop_art">
```

- Use `--bg`, `--surface`, `--ink`, `--soft`, and `--ph` for the page, surfaces, body copy, secondary text, and image placeholders.
- `--accent`, `--s1`, `--s2`, and `--s3` are raw hues for non-text graphics and layout fields. `--oa`, `--o1`, `--o2`, and `--o3` are their non-text foreground colours; use them for large icons or symbols. A coloured rectangle remains layout or content structure, not decoration. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use the contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text. Use `--kad` for accent text on an `--ink` field. When a raw hue needs higher text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour fields containing text, use `--g0` through `--g3` and pair each with the matching `--t0` through `--t3`.
- HTML/CSS components must reference colours only through `var(--...)`; derive transparency, strokes, shadows, and gradients from defined tokens as well.

Use `--bg` as the primary field, `--g1` for marker highlights, and `--k3` / `--g3` for oversized numbers. Rotate `--accent` and `--s2` through supporting accents and section colour fields.

```css
.slide { background: var(--bg); color: var(--ink); }
.surface { background: var(--surface); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-graphic { color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Space Grotesk` as the display typeface and `Lexend` as the body typeface.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600&family=Lexend:wght@300;400;500;600&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Space Grotesk";
  --fb: "Lexend";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600; available body weights are 300 / 400 / 500 / 600. Use `--fd` for titles, hero numbers, and section numbers; use `--fb` for body copy, labels, chart annotations, and tables. For CJK content, preserve the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the template's own base stylesheet, used by `layouts/`.
Copy it verbatim into the single `<style>` block, immediately after the inlined
colour-system CSS, before writing any slide. It defines the 16:9 stage, the type
scale, and the chrome and content-treatment classes the rest of this document refers
to. A deck that invents its own class names instead of using these will not look
like this template.

```css
:root{
  --r-xs: .5cqw;
  --r-sm: .9cqw;
  --r-md: 1.7cqw;
  --r-lg: 3cqw;
  --r-xl: 5cqw;
--fd: "Space Grotesk";
  --fb: "Lexend";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;}
.stage[data-right-rail]{--rail-width:9cqw;--rail-gap:2cqw;}
.stage[data-right-rail]>.fit{padding-right:calc(var(--rail-width) + var(--rail-gap))!important;}
.stage[data-right-rail]>[data-background-field="right-rail"]{position:absolute;right:0;top:0;width:var(--rail-width);height:100cqh;z-index:1;}
[data-fit-frame],[data-fit-content]{min-width:0;min-height:0;}
[data-fit-content]{transform-origin:top center;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}
  

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:6;}

.tile{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.tile>span{font-size:40cqw;line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.badge>span{font-size:40cqw;line-height:1;}
.tick{position:absolute;}
.card{background:var(--surface);border-radius:var(--r-md);}
.dot{border-radius:50%;}.qcircle{border-radius:50% 0 0 0;}.semi{border-radius:999px 999px 0 0;}.tri{width:0;height:0;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}
.flow-stack{display:flex;flex-direction:column;gap:var(--flow-gap,4cqh);min-height:0;}
.flow-stack>*{flex:none;min-width:0;}
.brandline{display:inline-block;max-width:100%;white-space:nowrap;overflow-wrap:normal!important;word-break:normal!important;hyphens:none;}
.on-accent{color:var(--oa);}.on-g0{color:var(--t0);}.on-g1{color:var(--t1);}.on-g2{color:var(--t2);}.on-g3{color:var(--t3);}
```
The number inside a `badge` and any text inside a `tile` must be wrapped in a
`<span>`. The wrapper is what makes the text scale with the box: it is measured
against the badge's own width, so the figure stays in proportion at any size.
Text placed directly in the box only follows `--sz`, and a deck that sizes the
box with `width`/`height` instead will render a small number in a large frame.
Size these with `--sz`, not `width`/`height`.

Copy the local-fit and layout-audit `<script>` from
[`layouts/_shell.html`](layouts/_shell.html) verbatim into the final deck as well.
It scales only explicit `[data-fit-content]` regions, never the stage, title, or chrome;
the readability floor is `0.90`.


## Visual vocabulary by role

The reference is recognisable through three active roles and one deliberately empty
role. Keep these roles separate; geometry alone never determines classification.

| role | reference examples | decoration? |
|---|---|---|
| persistent chrome | brand mark, nav pills, dashed rule + terminal, page number | no |
| content treatment | title marker, process wire, photo, speech callout, big stat | no |
| layout/background | edge colour fields, panels, cards, grids and media reserves | no |
| optional decoration | template-specific, textless, non-layout visual motif | **none in the 15-slide reference** |

For branded chrome, retain the example's dimensions, margins and repeated positions,
then replace placeholder names with real brand assets. Visual reference:
[example/reference.jpg](example/reference.jpg).

### Content and layout components

The snippets below remain part of the template, but their count never satisfies a
decoration target.

#### Numbered badge — content label, used 3 times

```html
<div class="badge" data-badge="1" style="--sz:5cqw;background:var(--g0);color:var(--t0)"><span>01</span></div>
```

#### Rectangular background field — layout reserve, used 6 times

```html
<div data-background-field="1" style="position:absolute;right:0;bottom:14cqh;width:13cqw;height:22cqh;background:var(--g1);color:var(--t1);z-index:1"></div>
```

For a **full-height right rail**, use the rail-aware primitive instead of placing a
generic field beside a full-width `.fit`:

```html
<div class="stage" data-right-rail style="--rail-width:9cqw;--rail-gap:2cqw">
  <div data-background-field="right-rail" style="background:var(--g1);color:var(--t1)"></div>
  <div class="fit" style="display:flex;flex-direction:column;padding:13cqh 6cqw 8cqh">
    <!-- normal-flow content; the shell reserves rail width + gap automatically -->
  </div>
</div>
```

At 1600×900 the defaults are still expressed proportionally: the rail is `9cqw`,
the gap is `2cqw`, and the content edge is `11cqw` from the stage right. Override the
two variables on `.stage` when the actual rail differs; never hard-code a child width.

#### Title marker — content emphasis, used 12 times

```html
<span data-marker="1" data-mc-word="1" style="display:inline-block;background:var(--g1);color:var(--t1);border-radius:.85em .65em .8em .6em / .7em .85em .6em .8em;padding:0 .3em;margin:0 .02em;transform:rotate(-1.5deg)">Consulting</span>
```

#### Navigation pill — chrome/control, used 45 times; one CTA makes 46 total

```html
<div data-pill="1" style="display:inline-flex;align-items:center;justify-content:center;padding:1.05cqh 1.9cqw;background:var(--ink);border-radius:999px">
  <span class="kicker" style="font-size:1.2cqw;letter-spacing:.02em;text-transform:none;color:var(--bg)">About</span>
</div>
```

#### Icon tile — content cell, used 8 times

```html
<div class="tile" data-tile="1" style="--sz:5cqw;flex:none;background:var(--g0);color:var(--t0)">
  <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/></svg>
</div>
```

#### Metric disc — content carrier, used 2 times

A disc containing a figure and caption remains content. Mark it
`data-metric-disc`, never `data-decoration`.

### CSS signatures

These declarations are part of the template's look. Their role does not turn their
elements into decoration.

| property | values it actually uses | role |
|---|---|---|
| `box-shadow` | ground-coloured rings and one offset shadow | chrome terminal and content media |
| `border-radius` | capsules, irregular marker radius, content discs | chrome/content geometry |
| `transform` | `rotate(-1.5deg)` ×12 | title emphasis |

### Strict decoration reference profile

Measured from all 15 reference slides at 1600×900:

| diagnostic | reference |
|---|---:|
| explicitly declared, textless, non-layout decorations | 0 |
| slides carrying optional decoration | 0 / 15 |
| optional decoration per slide | 0.00 |
| paired decorations | 0 / 15 |

These readings are not an invitation to add an ornament. They establish that this
template's fidelity comes from composition, background treatment, content vocabulary
and chrome. Cards, squares, rectangular colour blocks, content containers, grid
cells, badges, tiles, nodes, connectors, image frames and content-carrying circles
are excluded from decoration coverage and quantity.

The six rectangular colour fields are layout decisions: three full-height right
fields, two partial right fields and one foot field. The two circles previously
grouped with them carry a KPI and caption and are content. The title marker contains
title text. The dashed rule and terminal repeat as chrome. None is decoration.

Use `data-decoration` only for a future element that is demonstrably
template-specific, contains no information, and performs no layout function. The
current reference contains no such element, so a generated deck normally contains
none. Never infer decoration from an empty SVG or from a geometric silhouette.

## Layer and safe-area rules

- The shared text safe area is set once on `.fit`: `13cqh 6cqw 8cqh`.
- A `.stage[data-right-rail]` replaces only the right inset with
  `calc(var(--rail-width) + var(--rail-gap))`; the other three safe-area values remain
  unchanged. The hard gate is `contentRight <= railLeft - gap`.
- Background fields and media reserves belong to the chosen layout and stay clear of
  its text flow.
- Chrome sits at z-index 5–7 and repeats consistently.
- Optional decoration has no required layer because the reference count is zero.
- Do not mark cards, colour blocks, rectangular backgrounds, content containers,
  grid cells, badges, tiles, media frames or connectors as decoration.

## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** A label positioned with `left:88cqw` will
overflow the moment its text is longer than the author guessed, and CJK copy is
routinely wider than the Latin draft it was written against. Anchor anything in
the right third with `right:` instead of `left:`, and anything in the bottom
third with `bottom:` instead of `top:`. A block anchored to the edge it is near
grows inward, where there is room, instead of outward into nothing. Give any
absolutely-positioned text an explicit `max-width` so it wraps rather than
extends.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a grid or a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

For a two-series bar chart, “one baseline” means both bars are siblings in the same
category cell with `align-items:flex-end`. Do not put the second bar below the first:
`47.9% + 70%` is not one stack and will grow upward into the title. Use
`data-chart-plot` on the plot and `data-plot-mark` on each pure graphic mark.

Both faults hide from a quick glance at the whole deck and are obvious on the
slide itself. Before delivering, look at every slide that carries a set of
things and check that the set is aligned and that nothing touches an edge it was
not meant to touch.

**A headline owns its rendered height.** Put the heading, optional lead, and
the content below them in one `.flow-stack` (or an equivalent Grid) so a wrapped
heading pushes later content down. Keep at least `3cqh` between the heading box
and the first card, row, or metric. Do not position content at a fixed `top`
chosen from the one-line draft; that is how a two-line title becomes a 40cqh
block on top of a card grid.

**Auto-fit is local and bounded.** A definite `[data-fit-frame]` may contain one
`[data-fit-content]` normal-flow region. The shell scales only that child and stops at
`0.90`; anything that remains too large is marked `data-overflow="fit-floor"` and must
be split or simplified. After fitting, `window.__landingConsultingAudit()` must report
zero rail, plot/text, and fit-floor failures.

**A short brand line never breaks inside the name.** Apply `.brandline` only to
an indivisible product or campaign name. If that line does not fit at the
reference display scale, move the product name into a kicker or split the
product and tagline into separate semantic lines. Do not shrink body-scale type
or enable mid-token wrapping to force the original line into place.

**A colour field owns its foreground token.** Anything inside `--accent` or
`--g0`–`--g3`, including citations and small captions, uses the paired `--oa`
or `--t0`–`--t3` token. The `.on-*` helpers encode those pairs. A low-emphasis
citation may use opacity on the paired foreground, but never `.soft`, default
`--ink`, or a token borrowed from another field.

## Never do this

- **Never use a disc-bulleted list.** Not one of the twenty-three V3 reference
  decks contains a single `<ul>` with default bullets, and a bulleted list is the
  fastest way to make a designed template look like a plain document. Structure a
  list as numbered rows with a hairline rule between them, as key–value rows, as
  a row of cards, or with the template's own content treatments — whatever the reference deck
  does for the same job.
- Never invent a colour outside the inlined colour-system tokens; every colour
  goes through `var(--...)`.
- Never leave a slide without the chrome named in `Required chrome`.
- Never let a background field or chrome sit on top of a title or paragraph.
- Never generate a photograph the supplied material does not call for.

## Required chrome

Chrome is the cheapest part of a template's identity and the most frequently
dropped: across the benchmark's baseline decks, four of six templates carried a
footer on 0-2 slides out of 17. This template's reference deck carries the
following, and the count is measured from that deck, not assumed.


### Repeats on every slide

The reference deck also repeats these edge-pinned elements on nearly every slide. Their opening tags are given as locators — find each one in [layouts/](layouts/) and carry it through your deck the same way.

```html
<div style="position:absolute;left:5cqw;top:3.4cqh;display:flex;align-items:center;gap:1cqw;z-index:7">
```
<sub>on 15 of 15 reference slides</sub>
**Persistent navigation bar** — present on 15 of the reference deck's 15 slides, unchanged from slide to slide. It is the template's most visible piece of identity and the first thing a generated deck drops.

```html
<div data-device="nav" style="position:absolute;right:5cqw;top:3.0cqh;display:flex;gap:1.1cqw;z-index:7"><div data-pill="1" style="display:inline-flex;align-items:center;justify-content:center;padding:1.05cqh 1.9cqw;background:var(--ink);border-radius:999px">
       <span class="kicker" style="font-size:1.2cqw;letter-spacing:.02em;text-transform:none;color:var(--bg)">About</span></div><div data-pill="1" style="display:inline-flex;align-items:center;justify-content:center;padding:1.05cqh 1.9cqw;background:var(--ink);border-radius:999px">
       <span class="kicker" style="font-size:1.2cqw;letter-spacing:.02em;text-transform:none;color:var(--bg)">Blog</span></div><div data-pill="1" style="display:inline-flex;align-items:center;justify-content:center;padding:1.05cqh 1.9cqw;background:var(--ink);border-radius:999px">
       <span class="kicker" style="font-size:1.2cqw;letter-spacing:.02em;text-transform:none;color:var(--bg)">Gallery</span></div></div>
```


**Page number** — on 15 of 15 slides:

```html
<div class="pagenum">page 01</div>
```

Carry page number on **every** slide, including the cover and the closing slide.
