# landing-consulting — naked layouts

28 layouts with content structure and any page-role background treatment. They contain
no optional decoration and no measured text geometry. Pair one with the persistent
chrome described in [../decoration/PLACEMENT.md](../decoration/PLACEMENT.md) to build a
slide.

The removed full-deck HTML example was produced by measuring a rendered deck and writing the numbers
back, so its widths are observations of one string at one font size, not design
decisions. Copying them reproduces that string. These carry none.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 28: zero `width` / `max-width` / `min-width` / `height` / `left` /
`top` / `right` / `bottom` / `flex` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex-basis`. `flex:0 0 4cqw` freezes exactly the way a `width` does.

Four exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline rule.
- **`em`** on compact content marks that hold no prose — a legend dot or an avatar
  disc. `em` scales with the type around it, so it cannot freeze a text box.
- **`--sz`** on `.tile` and `.badge`. This is the template's own documented sizing
  channel for those two content cells; `design-system.md` requires it and warns that
  `width`/`height` renders a small glyph in a large frame. They hold at most a
  two-character label and scale their glyph against the box via `container-type`.
- **`%`** in `chart-pie` only, where the number *is* the datum.

Everything else stretches. Columns are `flex:1`. The safe area is set once, by the
padding on `.fit` (`13cqh 6cqw 8cqh`).

`13cqh` at the top is not arbitrary: the persistent chrome's band bottom measures
**7.57%** of stage height and its dashed rule sits at 8.6%. Content starting above 11%
lands on the wordmark.

The **6cqw** side padding is the template's safe-area constant, measured off the
reference: 42 of its content elements start at exactly 6% and none starts left of it.

Any flex child that holds an SVG or a percentage-height bar needs `min-height:0`.

**A percentage height needs a definite parent.** Give the plot a `minmax(0,1fr)` row
and each category a definite bar well, with the series as siblings inside that well
aligned to one bottom baseline. Never stack series vertically: two percentages are
independent heights, not a sum. Mark pure bars or areas with
`data-plot-mark`; the template-local probe rejects any mark that intersects rendered text.

The chart title remains outside `[data-fit-frame]`. Lead, plot and legend form one
normal-flow `[data-fit-content]` region inside it. The shell scales only that region,
never below `0.90`; `data-overflow="fit-floor"` is a blocking signal to split the slide.

## The chrome is not in these files

The wordmark, nav pills, dashed rule with terminal and page number are a separate
chrome layer. They are documented in
[../decoration/PLACEMENT.md](../decoration/PLACEMENT.md) and added on top. They do not
count as decoration. The layouts leave the top `13cqh` clear for them.

## The right-hand reserve

Six reference background/content fields, and its cover and closing photographs, are
anchored flush to the **right** edge. `cover`, `close` and `section-divider` therefore
put their copy in a `flex:3` column beside an empty `flex:2` reserve, so the text never
runs under the field or media that will be placed there.

That reserve is a unitless flex ratio, never a `cqw` width — and it is why those three
layouts look empty on the right when rendered naked. **Do not "fix" that.** Add the
page-role background field or source-backed media before deciding a layout is
underfilled. The field is layout, not decoration.

A full-height colour rail uses `.stage[data-right-rail]` plus
`[data-background-field="right-rail"]`. The shared shell reserves
`--rail-width + --rail-gap` on `.fit` (defaults `9cqw + 2cqw`) and the probe enforces
`contentRight <= railLeft - gap`. Do not emulate the reserve with a child width.

## Files

`_shell.html` is the shared `<head>`, fonts, colour-system link, class definitions,
local-fit runtime and layout-safety audit. It is not a slide. `build.py` regenerates
every layout from it; `sheet.py` concatenates them all into one labelled contact sheet.

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `two-column` `three-column` `color-cards` `numbered-list` `big-quote`

**Numbers** · `kpi-grid` `stat-cells` `table` `chart-line` `chart-pie`

**Time and sequence** · `process` `timeline` `roadmap`

**Two things compared** · `comparison` `versus` `pros-cons`

**Imagery** · `image-left` `image-right` `image-grid` — all three delete cleanly. When
the source has no imagery, drop the `data-photocell` frame and use a prose layout; do
not leave an empty box.

**People and offer** · `team-grid` `quotes` `pricing` `icon-cells`

## Where the set came from

13 are the layouts the original reference deck already demonstrated, one per page role:
`cover` `toc` `section-divider` `close` `numbered-list` `team-grid` `icon-cells`
`process` `image-grid` `stat-cells` `quotes` `pricing` `image-right`.

3 are from `composition-recipes.html`, which carries treatments the example does not:
`big-quote` `comparison` `table`.

12 are genuine gaps a real deck needs, written in this template's own vocabulary:
`two-column` `three-column` `color-cards` `kpi-grid` `chart-line`
`chart-pie` `timeline` `roadmap` `versus` `pros-cons` `image-left`.

Nothing was imported wholesale from another template's list. `arch-diagram`, `mindmap`
and `flow-diagram` were considered and **dropped**: this template has no node-graph
vocabulary, and building one would mean borrowing another design language's
implementation rather than its purpose. `image-hero` was dropped as `image-right` with
different placeholder text.

## Ruled or filled — both, for every peer row

11 of the 28 layouts separate items with a hairline rule. That is a skewed menu: an
agent sampling it puts the same horizontal line on every slide. Each of these content
types therefore has two treatments, and neither is more on-template than the other:

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `color-cards` |
| a row of numbers | `kpi-grid` | `stat-cells` |
| two things compared | `comparison` | `versus` |
| a set of capabilities | `process` | `icon-cells` |

The filled versions cycle the grounds so neighbours never share a colour. Pick the
filled version when the items are short and parallel, when the ruled version reads thin,
or simply when the previous slide was ruled.

## A filled box is sized by its content, never by the stage

```
height   row     flex:none      height comes from the tallest child, not the stage
         child   flex:1         siblings equalise to that tallest child

width    box     align-self:flex-start; max-width:100%
```

`flex:1` on the **row** and `flex:1` on the **child** look like the same instruction and
do opposite things. On the row it fills the stage, and the cards inherit the stage's
height — a slab of colour that is half empty.

`.fit` is a column flex with `align-items:stretch`, so **every child is full-width by
default**. `align-self:flex-start` opts one box out. `roadmap`'s quarter labels needed
exactly this: without it each was a full-width colour bar with a two-character label in
the corner.

Exception: a **row of peers** stays equal-width and divides the safe area. One box hugs,
a row of boxes divides. Reserve a filling `flex:1` for an image frame or a chart plot.

**Peer columns must agree on their first line.** The trap is a filled panel beside plain
copy: the panel's padding pushes its first line down, so the headings miss even though
the boxes line up. `versus` matches its ruled side's `padding-top` to its filled side's;
`toc` matches its title column to its list rows. Both were caught by the probe, not by
eye.

**Attributions that follow unequal copy misalign.** `quotes` pushes its attribution with
`margin-top:auto` so all three sit on one line at the bottom of the equal-height row.

## Colour

The default token `pop_art` is **dark** — `--bg` `#111016`, `--ink` `#F4F2FA`. Most
advice written for a cream template inverts here.

- **Write text in `--ka` `--k1` `--k2` `--k3`, never `--s1` `--s2` `--s3` `--accent`.**
  On `pop_art` the two channels hold identical values so the mistake is invisible; on
  `prism`, `carnival`, `mint_tech` and `bauhaus_primary` they differ and contrast
  collapses to as low as 1.43:1.
- `--surface` is legitimate here — 1.10:1 against `--bg` reads as a subtle raised panel,
  and the reference uses it on `icon-cells`. Do not put it on the same page as a `--ph`
  photo frame; they measure 1.13:1 against each other.
- On a page whose `.stage` carries a `--g?` ground, a kicker uses `color:inherit`, never
  `--ka`.
- Rectangular background fields use `--g1` or `--g3` only. They are layout
  treatments, not decoration. Measured 6/6 on the reference (`--g1` ×4, `--g3` ×2).

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` · structure
`stage fit deck slide band card tile badge flow-stack` · marks
`dot tick soft dim pagenum mk rule brandline` · fields `on-accent on-g0 … on-g3`.

Sizes live in those classes. If something needs to be bigger, use the next class up —
do not write a `font-size`.
