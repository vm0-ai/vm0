#!/usr/bin/env python3
"""Concatenate every layout into one scrolling sheet, each stage labelled.

    python3 sheet.py            # writes /tmp/contact-sheet.html
"""
import pathlib, re, sys

HERE = pathlib.Path(__file__).parent
SHELL = (HERE / '_shell.html').read_text()
HEAD = SHELL[:SHELL.index('</style>')]

ORDER = [
    ('Opening & closing', ['cover', 'toc', 'section-divider', 'close']),
    ('Prose',             ['two-column', 'three-column', 'color-cards', 'numbered-list', 'big-quote']),
    ('Numbers',           ['kpi-grid', 'stat-cells', 'table', 'chart-bar', 'chart-line', 'chart-pie']),
    ('Time & sequence',   ['process', 'timeline', 'roadmap']),
    ('Two things compared', ['comparison', 'versus', 'pros-cons']),
    ('Imagery',           ['image-left', 'image-right', 'image-grid']),
    ('People & offer',    ['team-grid', 'quotes', 'pricing', 'icon-cells']),
]

SHEET_CSS = '''
.deck{scroll-snap-type:none;height:auto;overflow:visible;background:#000;}
.slide{width:auto;height:auto;display:block;background:transparent;}
.stage{width:1600px;height:900px;margin:0;}
.lbl{font:600 26px/1.5 ui-monospace,monospace;color:#fff;background:#000;padding:10px 18px;
     letter-spacing:.04em;border-top:2px solid #444;}
.grp{font:700 30px/1.5 ui-monospace,monospace;color:#000;background:#C6FF4A;padding:14px 18px;
     letter-spacing:.08em;}
</style>'''

parts = []
for group, names in ORDER:
    parts.append(f'<div class="grp">{group}</div>')
    for n in names:
        f = HERE / f'{n}.html'
        if not f.exists():
            print('missing', n, file=sys.stderr); continue
        h = f.read_text()
        m = re.search(r'(<div class="stage".*</div>)\s*</div></div>\s*</body>', h, re.S)
        stage = m.group(1)
        parts.append(f'<div class="lbl">{n}.html</div><div class="slide">{stage}</div>')

out = HEAD + SHEET_CSS + '\n</head>\n<body>\n<div class="deck">' + '\n'.join(parts) + '</div>\n</body></html>\n'
# the sheet lives in the layouts folder so ../color-systems/ still resolves
(HERE / '_sheet.html').write_text(out)
print('wrote', HERE / '_sheet.html', '—', sum(len(n) for _, n in ORDER), 'layouts')
