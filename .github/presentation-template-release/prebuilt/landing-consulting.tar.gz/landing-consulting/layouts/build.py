#!/usr/bin/env python3
"""Emit every naked layout from one shared shell.

The shell lives in _shell.html. Keeping it in one place is deliberate: the
colour-system link is relative, and a layout that carries its own copy is a
layout whose palette can silently stop resolving.

    python3 build.py        # rewrites every <name>.html in this folder
"""
import pathlib, re

HERE = pathlib.Path(__file__).parent
SHELL = (HERE / '_shell.html').read_text()
HEAD = SHELL[:SHELL.index('<body>') + len('<body>')]

FIT = 'justify-content:center;padding:13cqh 6cqw 8cqh'   # centred safe area
RULE = 'border-bottom:1px solid color-mix(in srgb, var(--ink) 14%, transparent)'
TOPRULE = 'border-top:1px solid color-mix(in srgb, var(--ink) 22%, transparent)'

# A right-hand reserve. The template's background fields and photos are anchored
# flush to the right edge on the measured page roles, so text keeps clear of them.
# Written as a unitless flex ratio, never a cqw width.
RESERVE = '<div style="flex:2" aria-hidden="true"></div>'

L = {}

# ---------------------------------------------------------------- opening ---
L['cover'] = ('cover', '', f'''
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;{FIT}">
  <div style="flex:1;display:flex;align-items:center">
    <div style="flex:3">
      <h1 class="display" style="font-size:calc((9cqw) * var(--fit, 1));line-height:.98">Strategic<br><span class="mk">Consulting</span></h1>
      <p class="lead" style="margin-top:4cqh;opacity:.85">One line naming who this is for and why now.</p>
    </div>
    {RESERVE}
  </div>
</div>''')

L['toc'] = ('toc', '', f'''
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;{FIT}">
  <div style="flex:none;display:flex;gap:3cqw;align-items:stretch">
    <div style="flex:2;display:flex;flex-direction:column;justify-content:center">
      <h1 class="h1">What's<br><span class="mk">inside</span></h1>
      <p class="body" style="margin-top:4cqh;opacity:.7">A quick map of the engagement, section by section.</p>
    </div>
    <div style="flex:3;display:flex;flex-direction:column">
      {''.join(f"""
      <div style="display:flex;align-items:baseline;gap:1.6cqw;padding:1.6cqh 0;{RULE}">
        <div style="flex:none;color:var(--{c});font-family:var(--fd);font-weight:600;font-size:calc((1.7cqw) * var(--fit, 1));letter-spacing:.04em;font-variant-numeric:tabular-nums">{i:02d}</div>
        <h3 class="h3" style="flex:1;font-size:calc((2.4cqw) * var(--fit, 1))">{t}</h3>
        <div style="flex:none;opacity:.55;font-family:var(--fd);font-weight:500;font-size:calc((1.4cqw) * var(--fit, 1));font-variant-numeric:tabular-nums">{p:02d}</div>
      </div>""" for i, c, t, p in [
        (1, 'k1', 'Who we are &amp; what we do', 4), (2, 'k3', 'Mission &amp; operating beliefs', 5),
        (3, 'k2', 'The team behind the work', 6), (4, 'k1', 'Services &amp; delivery process', 8),
        (5, 'k3', 'Impact in numbers', 12), (6, 'k2', 'Pricing &amp; next steps', 14)])}
    </div>
  </div>
</div>''')

L['section-divider'] = ('divider', 'background:var(--g1);color:var(--t1)', f'''
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;{FIT}">
  <div style="flex:1;display:flex;align-items:center">
    <div style="flex:3">
      <div style="font-family:var(--fd);font-weight:600;font-size:calc((3cqw) * var(--fit, 1));letter-spacing:-.01em;opacity:.7">01</div>
      <div class="kicker" style="margin-top:2cqh;color:inherit;opacity:.85">Section</div>
      <h1 class="display" style="margin-top:1.2cqh;font-size:calc((7.5cqw) * var(--fit, 1));line-height:.98">About us</h1>
    </div>
    {RESERVE}
  </div>
</div>''')

L['close'] = ('close', '', f'''
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;{FIT}">
  <div style="flex:1;display:flex;align-items:center">
    <div style="flex:3">
      <div class="kicker" style="color:var(--ka)">Next step</div>
      <h1 class="display" style="margin-top:1.4cqh;font-size:calc((7.5cqw) * var(--fit, 1));line-height:.98">Let's<br><span class="mk">connect</span></h1>
      <p class="lead" style="margin-top:4cqh;opacity:.85">One sentence on what happens after this deck.</p>
      <p class="body" style="margin-top:1.6cqh;opacity:.7">hello@yourcompany.com &middot; yourcompany.com</p>
    </div>
    {RESERVE}
  </div>
</div>''')

# ------------------------------------------------------------------ prose ---
def titled(kicker, title, mark, rest, kcol='var(--ka)'):
    return f'''
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;{FIT}">
  <div class="kicker" style="color:{kcol}">{kicker}</div>
  <h1 class="h1" style="margin-top:1.2cqh;font-size:calc((5cqw) * var(--fit, 1));line-height:1.04">{title} <span class="mk">{mark}</span></h1>
  {rest}
</div>'''

L['two-column'] = ('two-column', '', titled('Kicker', 'Concept beside its', 'example', f'''
  <div style="display:flex;gap:4cqw;margin-top:4cqh;align-items:center;flex:none">
    <div style="flex:1"><div class="h3">Left &middot; the idea</div><p class="body" style="margin-top:1cqh;opacity:.88">Two or three sentences. The column takes half the row because it is one of two, not because a width was written.</p></div>
    <div style="flex:1"><div class="h3">Right &middot; the instance</div><p class="body" style="margin-top:1cqh;opacity:.88">Remove one column and the other fills the row on its own.</p></div>
  </div>'''))

L['three-column'] = ('three-column', '', titled('Kicker', 'Three peer', 'columns', f'''
  <div style="display:flex;gap:3cqw;margin-top:4cqh;align-items:center;flex:none">
    {''.join(f'''<div style="flex:1;{TOPRULE};padding-top:1.8cqh"><div class="h3">{t}</div><p class="body" style="margin-top:1cqh;opacity:.88">{b}</p></div>''' for t, b in [
      ('Diagnose', 'What the evidence says is actually happening, before anyone proposes a fix.'),
      ('Decide', 'The one call that unblocks the rest, made with the people who own it.'),
      ('Deliver', 'A change that survives the engagement because the team runs it.')])}
  </div>'''))

L['color-cards'] = ('color-cards', '', titled('Kicker', 'Three filled', 'cards', f'''
  <div style="display:flex;gap:2.2cqw;margin-top:4cqh;align-items:stretch;flex:none">
    {''.join(f'''<div style="flex:1;background:var(--{g});color:var(--{t});border-radius:var(--r-md);padding:2.6cqh 1.8cqw"><div class="h3">{h}</div><p class="body" style="margin-top:1cqh;opacity:.92">{b}</p></div>''' for g, t, h, b in [
      ('g0', 't0', 'Clarity', 'A strong strategy sets one clear intention and holds it across every decision made after it.'),
      ('g2', 't2', 'Evidence', 'We move on data and field insight, not on the loudest opinion in the room that day.'),
      ('g3', 't3', 'Endurance', 'Solutions designed to outlive the engagement, owned by the team that runs them.')])}
  </div>'''))

L['numbered-list'] = ('numbered-list', '', titled('What we believe', 'Built to', 'drive agility', f'''
  <div style="display:flex;flex-direction:column;margin-top:4cqh;flex:none">
    {''.join(f'''<div style="display:flex;gap:2cqw;align-items:flex-start;margin-bottom:3.4cqh">
      <div class="badge" style="--sz:5cqw;flex:none;background:var(--{g});color:var(--{t})"><span>{i:02d}</span></div>
      <div style="flex:1;padding-top:.6cqh"><h3 class="h3">{h}</h3><p class="body" style="margin-top:.6cqh;opacity:.92">{b}</p></div>
    </div>''' for i, g, t, h, b in [
      (1, 'g0', 't0', 'Clarity before action', 'A strong strategy sets one clear intention and holds it across every decision.'),
      (2, 'g1', 't1', 'Evidence over instinct', 'We move on data and field insight, not the loudest opinion in the room.'),
      (3, 'g2', 't2', 'Built to last', 'Solutions designed to outlive the engagement, owned by the team that runs them.')])}
  </div>'''))

L['big-quote'] = ('big-quote', '', f'''
<div class="fit" style="display:flex;flex-direction:column;align-items:center;justify-content:center;{FIT}">
  <blockquote style="font-family:var(--fd),var(--cjk-display);font-size:calc((5.35cqw) * var(--fit, 1));font-weight:500;line-height:1.04;letter-spacing:-.035em;text-align:center">Clarity turns a complex decision into a <span class="mk">shared next move.</span></blockquote>
  <figcaption class="cap" style="margin-top:4cqh;color:var(--soft);text-align:center">Strategy partner &middot; Leadership session, 2026</figcaption>
</div>''')

# ---------------------------------------------------------------- numbers ---
L['kpi-grid'] = ('kpi-grid', '', titled('Kicker', 'The numbers', 'behind it', f'''
  <div style="display:flex;gap:2.6cqw;margin-top:4cqh;align-items:center;flex:none">
    {''.join(f'''<div style="flex:1;{TOPRULE};padding-top:1.8cqh"><div class="stat" style="font-size:calc((4.6cqw) * var(--fit, 1));color:var(--{c})">{n}</div><div class="kicker" style="margin-top:.8cqh;opacity:.85">{l}</div><p class="body" style="margin-top:.7cqh;opacity:.8">{d}</p></div>''' for n, c, l, d in [
      ('11', 'k1', 'Engagements', 'Delivered in the last four quarters.'),
      ('3.4k', 'k2', 'Hours saved', 'Measured against the pre-engagement baseline.'),
      ('98%', 'k3', 'Retention', 'Clients who renewed after the first phase.'),
      ('42', 'ka', 'Markets', 'Where the operating model now runs.')])}
  </div>'''))

L['stat-cells'] = ('stat-cells', '', titled('The proof', 'Results that', 'compound', f'''
  <div style="display:flex;gap:3cqw;margin-top:4cqh;align-items:center;flex:none">
    {''.join(f'''<div style="flex:1"><div class="stat" style="font-size:calc((7cqw) * var(--fit, 1));color:var(--{c})">{n}</div><div class="h3" style="margin-top:1cqh">{l}</div><p class="body" style="margin-top:.8cqh;opacity:.8">{d}</p></div>''' for n, c, l, d in [
      ('+38%', 'k1', 'Revenue per account', 'Two quarters after the operating model changed.'),
      ('−11d', 'k2', 'Decision latency', 'From first escalation to a signed-off call.'),
      ('4.6×', 'k3', 'Return on fees', 'Independently reviewed at the twelve-month mark.')])}
  </div>'''))

L['table'] = ('table', '', titled('Evidence', 'The underlying', 'rows', f'''
  <div style="margin-top:4cqh;flex:none">
    <div style="display:flex;align-items:baseline;justify-content:space-between;gap:2cqw;margin-bottom:1.6cqh">
      <strong style="font-family:var(--fd);font-size:calc((1.7cqw) * var(--fit, 1));font-weight:600">Section title from the material</strong>
      <span class="cap" style="opacity:.7">Scope or window &middot; source</span>
    </div>
    <table style="width:100%;border-collapse:collapse;table-layout:auto;font-size:calc((1.05cqw) * var(--fit, 1));font-variant-numeric:tabular-nums">
      <thead><tr>
        <th style="text-align:left;padding:1cqh 1.1cqw;font-family:var(--fd);font-size:calc((.85cqw) * var(--fit, 1));letter-spacing:.08em;text-transform:uppercase;opacity:.72;box-shadow:inset 0 -1px 0 currentColor;white-space:nowrap;width:1%">ID</th>
        <th style="text-align:left;padding:1cqh 1.1cqw;font-family:var(--fd);font-size:calc((.85cqw) * var(--fit, 1));letter-spacing:.08em;text-transform:uppercase;opacity:.72;box-shadow:inset 0 -1px 0 currentColor;width:auto">Item</th>
        <th style="text-align:right;padding:1cqh 1.1cqw;font-family:var(--fd);font-size:calc((.85cqw) * var(--fit, 1));letter-spacing:.08em;text-transform:uppercase;opacity:.72;box-shadow:inset 0 -1px 0 currentColor;white-space:nowrap;width:1%">Count</th>
        <th style="text-align:right;padding:1cqh 1.1cqw;font-family:var(--fd);font-size:calc((.85cqw) * var(--fit, 1));letter-spacing:.08em;text-transform:uppercase;opacity:.72;box-shadow:inset 0 -1px 0 currentColor;white-space:nowrap;width:1%">P95</th>
      </tr></thead>
      <tbody>
      {''.join(f'''<tr>
        <td style="padding:1cqh 1.1cqw;vertical-align:baseline;box-shadow:inset 0 -1px 0 color-mix(in srgb,currentColor 16%,transparent);font-family:var(--fd);opacity:.85;white-space:nowrap;width:1%">{i}</td>
        <td style="padding:1cqh 1.1cqw;vertical-align:baseline;box-shadow:inset 0 -1px 0 color-mix(in srgb,currentColor 16%,transparent);width:auto">{lab}</td>
        <td style="padding:1cqh 1.1cqw;vertical-align:baseline;box-shadow:inset 0 -1px 0 color-mix(in srgb,currentColor 16%,transparent);text-align:right;white-space:nowrap;width:1%">{a}</td>
        <td style="padding:1cqh 1.1cqw;vertical-align:baseline;box-shadow:inset 0 -1px 0 color-mix(in srgb,currentColor 16%,transparent);text-align:right;white-space:nowrap;width:1%">{b}</td>
      </tr>''' for i, lab, a, b in [
        ('#21934', 'One row of evidence, wrapping freely when it is long', '4,875', '1,419'),
        ('#21473', 'A second row drawn from the same material', '2,927', '1,364'),
        ('#15693', 'A third row', '4,687', '1,448'),
        ('#15321', 'A fourth row, shorter', '1,204', '968')])}
      </tbody>
    </table>
    <div class="cap" style="margin-top:1.4cqh;opacity:.7">One line of reading guidance, drawn from the material.</div>
  </div>'''))

BAR_GROUPS = [('Q1', 46, 58), ('Q2', 61, 68), ('Q3', 74, 81), ('Q4', 93, 96)]
L['chart-bar'] = ('chart-bar', '', f'''
<div class="fit" style="display:grid;grid-template-rows:auto 38cqh;align-content:center;align-items:stretch;{FIT}">
  <header class="flow-stack" style="--flow-gap:1.2cqh">
    <div class="kicker" style="color:var(--ka)">Kicker</div>
    <h1 class="h1" style="font-size:calc((5cqw) * var(--fit, 1));line-height:1.04">Growth by <span class="mk">quarter</span></h1>
  </header>
  <div data-fit-frame style="min-height:0;margin-top:4cqh">
    <div data-fit-content style="height:100%;display:grid;grid-template-rows:auto minmax(0,1fr) auto;gap:1.6cqh">
      <p class="body" style="opacity:.82">Current and target share one 0–100 baseline; compare the two bars inside each quarter.</p>
      <div data-chart-plot="grouped-bars" style="min-height:0;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:2.4cqw;{TOPRULE};padding-top:1.8cqh">
        {''.join(f'''<div style="min-width:0;min-height:0;display:grid;grid-template-rows:minmax(0,1fr) auto;gap:1cqh">
          <div style="min-height:0;display:flex;align-items:flex-end;gap:.7cqw">
            <div data-plot-mark data-series="current" aria-label="{lab} current {current}" style="--value:{current};height:calc(var(--value)*1%);flex:1;background:var(--g0);border-radius:var(--r-sm) var(--r-sm) 0 0"></div>
            <div data-plot-mark data-series="target" aria-label="{lab} target {target}" style="--value:{target};height:calc(var(--value)*1%);flex:1;background:var(--g2);border-radius:var(--r-sm) var(--r-sm) 0 0"></div>
          </div>
          <div class="cap" style="text-align:center;white-space:nowrap"><strong style="font-family:var(--fd);font-weight:600">{lab}</strong><br><span style="opacity:.72">{current} / {target}</span></div>
        </div>''' for lab, current, target in BAR_GROUPS)}
      </div>
      <div data-chart-legend style="display:flex;gap:2cqw;align-items:center;flex-wrap:wrap">
        <div style="display:flex;align-items:center;gap:.6cqw"><span aria-hidden="true" style="width:.9em;height:.9em;background:var(--g0);border-radius:var(--r-xs)"></span><span class="cap">Current</span></div>
        <div style="display:flex;align-items:center;gap:.6cqw"><span aria-hidden="true" style="width:.9em;height:.9em;background:var(--g2);border-radius:var(--r-xs)"></span><span class="cap">Target</span></div>
      </div>
    </div>
  </div>
</div>''')

L['chart-line'] = ('chart-line', '', titled('Kicker', 'The trend over', 'time', f'''
  <div style="flex:none;height:38cqh;min-height:0;display:flex;flex-direction:column;margin-top:4cqh">
    <div style="flex:1;min-height:0">
      <svg viewBox="0 0 100 40" preserveAspectRatio="none" style="width:100%;height:100%;display:block">
        <polyline points="0,34 20,29 40,31 60,18 80,13 100,5" fill="none" stroke="var(--s1)" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>
        <polyline points="0,37 20,35 40,33 60,30 80,28 100,24" fill="none" stroke="var(--s2)" stroke-width="1.1" stroke-dasharray="3 2" stroke-linecap="round" vector-effect="non-scaling-stroke"/>
      </svg>
    </div>
    <div style="display:flex;gap:3cqw;{TOPRULE};padding-top:1.2cqh;flex:none">
      {''.join(f'<div style="flex:1"><div class="cap" style="text-align:center;opacity:.8">{lab}</div></div>' for lab in ['Jan', 'Mar', 'May', 'Jul', 'Sep', 'Nov'])}
    </div>
    <div style="display:flex;gap:2cqw;margin-top:1.4cqh;flex:none">
      <div style="display:flex;align-items:center;gap:.6cqw"><div class="dot" style="width:.9em;height:.9em;background:var(--s1);flex:none"></div><span class="cap">This engagement</span></div>
      <div style="display:flex;align-items:center;gap:.6cqw"><div class="dot" style="width:.9em;height:.9em;background:var(--s2);flex:none"></div><span class="cap">Sector baseline</span></div>
    </div>
  </div>'''))

L['chart-pie'] = ('chart-pie', '', titled('Kicker', 'Where the effort', 'goes', f'''
  <div style="flex:none;height:38cqh;min-height:0;display:flex;gap:4cqw;align-items:center;margin-top:4cqh">
    <div style="flex:1;height:100%;min-height:0;display:flex;align-items:center;justify-content:center">
      <svg viewBox="0 0 42 42" style="width:auto;height:100%;max-width:100%;max-height:100%;aspect-ratio:1/1;display:block;flex:none">
        <circle cx="21" cy="21" r="15.9" fill="none" stroke="var(--g0)" stroke-width="8" stroke-dasharray="42 58" stroke-dashoffset="0"/>
        <circle cx="21" cy="21" r="15.9" fill="none" stroke="var(--g2)" stroke-width="8" stroke-dasharray="27 73" stroke-dashoffset="-42"/>
        <circle cx="21" cy="21" r="15.9" fill="none" stroke="var(--g3)" stroke-width="8" stroke-dasharray="19 81" stroke-dashoffset="-69"/>
        <circle cx="21" cy="21" r="15.9" fill="none" stroke="var(--s1)" stroke-width="8" stroke-dasharray="12 88" stroke-dashoffset="-88"/>
      </svg>
    </div>
    <div style="flex:1;display:flex;flex-direction:column">
      {''.join(f'''<div style="display:flex;align-items:baseline;gap:1.2cqw;padding:1.2cqh 0;{RULE}">
        <div class="dot" style="width:1em;height:1em;background:var(--{c});flex:none;align-self:center"></div>
        <div style="flex:1" class="h3">{lab}</div>
        <div style="flex:none;font-family:var(--fd);font-weight:600;font-size:calc((1.7cqw) * var(--fit, 1));font-variant-numeric:tabular-nums">{v}%</div>
      </div>''' for lab, v, c in [('Diagnostic', 42, 'g0'), ('Design', 27, 'g2'), ('Delivery', 19, 'g3'), ('Handover', 12, 's1')])}
    </div>
  </div>'''))

# --------------------------------------------------------------- sequence ---
STEPS = [('01', 'Diagnose', 'Interviews, data pulls, and a baseline everyone signs off.'),
         ('02', 'Frame', 'The decision written down in one page, with its evidence.'),
         ('03', 'Pilot', 'One team runs the change while the rest keep operating.'),
         ('04', 'Scale', 'The pilot becomes the standard, owned by the line.')]

L['process'] = ('process', '', titled('How we work', 'From symptom to', 'solution', f'''
  <div style="margin-top:4cqh;flex:none">
    <div style="display:flex;gap:2.4cqw;align-items:center;border-top:.3cqh dashed color-mix(in srgb, var(--ink) 45%, transparent);padding-top:2.6cqh">
      {''.join(f'''<div style="flex:1;display:flex;flex-direction:column">
        <div class="tile" style="--sz:5cqw;flex:none;background:var(--{g});color:var(--{t})"><span>{n}</span></div>
        <div class="h3" style="margin-top:1.4cqh">{h}</div>
        <p class="body" style="margin-top:.8cqh;opacity:.85">{b}</p>
      </div>''' for (n, h, b), (g, t) in zip(STEPS, [('g0', 't0'), ('g2', 't2'), ('g1', 't1'), ('g3', 't3')]))}
    </div>
  </div>'''))

L['timeline'] = ('timeline', '', titled('Kicker', 'The engagement', 'calendar', f'''
  <div style="display:flex;flex-direction:column;margin-top:4cqh;flex:none">
    {''.join(f'''<div style="display:flex;gap:2cqw;align-items:flex-start;padding:1.8cqh 0;{RULE}">
      <div style="flex:none;font-family:var(--fd);font-weight:600;font-size:calc((1.5cqw) * var(--fit, 1));color:var(--{c});letter-spacing:.04em;font-variant-numeric:tabular-nums">{d}</div>
      <div class="dot" style="width:.9em;height:.9em;background:var(--{c});flex:none;margin-top:.35em"></div>
      <div style="flex:1"><div class="h3">{h}</div><p class="body" style="margin-top:.5cqh;opacity:.85">{b}</p></div>
    </div>''' for d, c, h, b in [
      ('WEEK 01', 'k1', 'Baseline agreed', 'Data room open, interviews scheduled, success measures written down.'),
      ('WEEK 04', 'k2', 'Diagnosis delivered', 'One page on what is actually happening, with the evidence behind it.'),
      ('WEEK 09', 'k3', 'Pilot running', 'A single team operating the new model while the rest carry on.'),
      ('WEEK 16', 'ka', 'Handover complete', 'The line owns it; we are on call, not on site.')])}
  </div>'''))

L['roadmap'] = ('roadmap', '', titled('Kicker', 'The next four', 'quarters', f'''
  <div style="display:flex;gap:2.2cqw;margin-top:4cqh;align-items:center;flex:none">
    {''.join(f'''<div style="flex:1;display:flex;flex-direction:column">
      <div style="background:var(--{g});color:var(--{t});border-radius:999px;padding:.9cqh 1.4cqw;flex:none;align-self:flex-start;max-width:100%"><div class="kicker" style="color:inherit">{q}</div></div>
      <div style="margin-top:1.4cqh"><div class="h3">{h}</div><p class="body" style="margin-top:.8cqh;opacity:.85">{b}</p></div>
    </div>''' for q, g, t, h, b in [
      ('Q1', 'g0', 't0', 'Stabilise', 'Close the reporting gap and agree one set of numbers.'),
      ('Q2', 'g2', 't2', 'Pilot', 'One market runs the new operating model end to end.'),
      ('Q3', 'g1', 't1', 'Extend', 'Three more markets adopt what the pilot proved.'),
      ('Q4', 'g3', 't3', 'Embed', 'Governance, hiring, and incentives follow the model.')])}
  </div>'''))

# --------------------------------------------------------------- compared ---
L['comparison'] = ('comparison', '', titled('Kicker', 'Two operating', 'states', f'''
  <div style="display:flex;gap:4cqw;margin-top:4cqh;align-items:center;flex:none">
    {''.join(f'''<div style="flex:1;{TOPRULE};padding-top:1.8cqh">
      <div class="kicker" style="color:var(--{c})">{k}</div>
      <div class="h2" style="margin-top:1.2cqh;font-size:calc((2.6cqw) * var(--fit, 1))">{h}</div>
      <p class="body" style="margin-top:1cqh;opacity:.85">{b}</p>
      <div style="margin-top:1.6cqh;padding-top:1.4cqh;{TOPRULE};font-family:var(--fd);font-weight:500;font-size:calc((1.55cqw) * var(--fit, 1))">{o}</div>
    </div>''' for k, c, h, b, o in [
      ('Current state', 'k3', 'Insight stays scattered.', 'Research, priorities, and ownership live in three separate conversations.', 'Slow alignment'),
      ('Shared direction', 'k2', 'One frame moves the team.', 'The decision, its evidence, and the next action become visible in one place.', 'Faster action')])}
  </div>'''))

L['versus'] = ('versus', '', titled('Kicker', 'The case for', 'changing', f'''
  <div style="display:flex;gap:2.6cqw;margin-top:4cqh;align-items:stretch;flex:none">
    <div style="flex:1;{TOPRULE};padding-top:2.6cqh">
      <div class="kicker" style="opacity:.7">Without</div>
      <div class="h2" style="margin-top:1.2cqh;font-size:calc((2.6cqw) * var(--fit, 1))">Three versions of the truth</div>
      <p class="body" style="margin-top:1cqh;opacity:.85">Every function reports its own number and the meeting spends its first half reconciling them.</p>
    </div>
    <div style="flex:1;background:var(--g1);color:var(--t1);border-radius:var(--r-md);padding:2.6cqh 1.8cqw">
      <div class="kicker" style="color:inherit;opacity:.85">With</div>
      <div class="h2" style="margin-top:1.2cqh;font-size:calc((2.6cqw) * var(--fit, 1))">One number, owned</div>
      <p class="body" style="margin-top:1cqh;opacity:.92">The same figure appears in every deck because one team owns its definition and publishes it.</p>
    </div>
  </div>'''))

L['pros-cons'] = ('pros-cons', '', titled('Kicker', 'What it costs and', 'returns', f'''
  <div style="display:flex;gap:4cqw;margin-top:4cqh;align-items:center;flex:none">
    {''.join(f'''<div style="flex:1;{TOPRULE};padding-top:1.8cqh">
      <div class="kicker" style="color:var(--{c})">{k}</div>
      <div style="display:flex;flex-direction:column;margin-top:1.2cqh">
        {''.join(f"""<div style="display:flex;gap:1cqw;align-items:baseline;padding:1.1cqh 0;{RULE}">
          <div style="flex:none;color:var(--{c});font-family:var(--fd);font-weight:600;font-size:calc((1.5cqw) * var(--fit, 1))">{m}</div>
          <p class="body" style="flex:1;opacity:.88">{x}</p></div>""" for x in items)}
      </div>
    </div>''' for k, c, m, items in [
      ('Gains', 'k2', '+', ['Decisions land in one meeting instead of three.',
                            'The operating model outlives the engagement.',
                            'Reporting effort drops once definitions are shared.']),
      ('Costs', 'k3', '−', ['Two senior people are committed for a quarter.',
                                 'Some existing reports are retired, not merged.',
                                 'The first pilot market carries the disruption.'])])}
  </div>'''))

# --------------------------------------------------------------- imagery ----
def img_split(name, left_first):
    frame = '<div data-photocell="1" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-md)"></div>'
    copy = f'''<div style="flex:1.15;display:flex;flex-direction:column;justify-content:center">
      <div class="kicker" style="color:var(--ka)">Who we are</div>
      <h1 class="h1" style="margin-top:1.4cqh;font-size:calc((4.2cqw) * var(--fit, 1))">Seeing the whole <span class="mk">picture</span></h1>
      <p class="lead" style="margin-top:4cqh;opacity:.9">We give leaders an objective, expert view of their organization's health.</p>
      <p class="body" style="margin-top:1.6cqh;opacity:.78">By bringing in specialized knowledge, companies bridge capability gaps and turn diagnosis into momentum.</p>
    </div>'''
    a, b = (frame, copy) if left_first else (copy, frame)
    return (name, '', f'''
<div class="fit" style="display:flex;flex-direction:column;align-items:stretch;{FIT}">
  <div style="flex:1;min-height:0;display:flex;gap:4cqw;align-items:stretch">{a}{b}</div>
</div>''')

L['image-left'] = img_split('image-left', True)
L['image-right'] = img_split('image-right', False)

L['image-grid'] = ('image-grid', '', titled('Our work', "Where we've made", 'impact', f'''
  <div style="flex:none;height:42cqh;min-height:0;display:flex;gap:1.8cqw;margin-top:4cqh;align-items:stretch">
    {''.join(f'''<div style="flex:1;display:flex;flex-direction:column;min-height:0">
      <div data-photocell="1" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-md)"></div>
      <div style="margin-top:1.2cqh;flex:none"><div class="h3" style="font-size:calc((1.7cqw) * var(--fit, 1))">{h}</div><p class="cap" style="margin-top:.2cqh;opacity:.65">{b}</p></div>
    </div>''' for h, b in [('Retail', 'Network redesign'), ('Health', 'Access programme'),
                           ('Energy', 'Grid transition'), ('Public', 'Service reform')])}
  </div>'''))

# -------------------------------------------------------- people & offer ----
L['team-grid'] = ('team-grid', '', titled('The people', 'Industry', 'experts', f'''
  <div style="flex:none;height:42cqh;min-height:0;display:flex;gap:1.6cqw;margin-top:4cqh;align-items:stretch">
    {''.join(f'''<div style="flex:1;display:flex;flex-direction:column;min-height:0">
      <div data-photocell="1" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-md)"></div>
      <div style="margin-top:1.2cqh;flex:none"><h3 class="h3" style="font-size:calc((1.7cqw) * var(--fit, 1))">{n}</h3><p class="cap" style="margin-top:.2cqh;opacity:.65">{r}</p></div>
    </div>''' for n, r in [('A. Mercer', 'Managing Partner'), ('J. Okonkwo', 'Strategy Lead'),
                           ('L. Park', 'Operations Advisor'), ('S. Haddad', 'Insight Director')])}
  </div>'''))

L['quotes'] = ('quotes', '', titled('Testimonial', 'What clients', 'say', f'''
  <div style="display:flex;gap:2.6cqw;margin-top:4cqh;align-items:stretch;flex:none">
    {''.join(f'''<div style="flex:1;{TOPRULE};padding-top:1.8cqh;display:flex;flex-direction:column">
      <p class="body" style="font-size:calc((1.6cqw) * var(--fit, 1));opacity:.92">&ldquo;{q}&rdquo;</p>
      <div style="display:flex;align-items:center;gap:1cqw;margin-top:auto;padding-top:2cqh">
        <div data-photocell="1" class="dot" style="width:2.6em;height:2.6em;background:var(--ph);flex:none"></div>
        <div><div class="h3" style="font-size:calc((1.5cqw) * var(--fit, 1))">{n}</div><div class="cap" style="opacity:.65">{r}</div></div>
      </div>
    </div>''' for q, n, r in [
      ('They found the one decision we had been avoiding, and made it easy to take.', 'R. Alvarez', 'COO, Retail group'),
      ('The pilot paid for the whole engagement before we scaled it anywhere else.', 'M. Chen', 'CFO, Health network'),
      ('Six months on, the team still runs the model without calling us.', 'K. Obi', 'MD, Energy utility')])}
  </div>'''))

L['pricing'] = ('pricing', '', titled('Ways to partner', 'Choose the depth of', 'engagement', f'''
  <div style="display:flex;gap:2.2cqw;margin-top:4cqh;align-items:center;flex:none">
    {''.join(f'''<div style="flex:1;{style};display:flex;flex-direction:column">
      <div class="kicker" style="color:{kc}">{plan}</div>
      <div class="stat" style="margin-top:1cqh;font-size:calc((3.6cqw) * var(--fit, 1))">{price}</div>
      <div class="cap" style="margin-top:.4cqh;opacity:.7">{unit}</div>
      <div style="display:flex;flex-direction:column;margin-top:1.6cqh">
        {''.join(f'<div class="body" style="padding:.9cqh 0;{RULE};opacity:.88">{f}</div>' for f in feats)}
      </div>
    </div>''' for plan, price, unit, feats, style, kc in [
      ('Diagnostic', '4 weeks', 'fixed fee', ['Baseline and data room', 'Two workshops', 'One-page diagnosis'],
       TOPRULE + ';padding-top:1.8cqh', 'var(--ka)'),
      ('Programme', '16 weeks', 'phased fee', ['Everything in Diagnostic', 'Pilot in one market', 'Handover to the line'],
       'background:var(--g0);color:var(--t0);border-radius:var(--r-md);padding:2.2cqh 1.6cqw', 'inherit'),
      ('Retained', 'Ongoing', 'monthly', ['Quarterly review', 'On-call advisory', 'Annual reset'],
       TOPRULE + ';padding-top:1.8cqh', 'var(--ka)')])}
  </div>'''))

L['icon-cells'] = ('icon-cells', '', titled('Services', 'Integrating modern', 'software', f'''
  <div style="display:flex;gap:2cqw;margin-top:4cqh;align-items:stretch;flex:none">
    {''.join(f'''<div class="card" style="flex:1;padding:2.4cqh 1.6cqw;display:flex;flex-direction:column">
      <div class="tile" style="--sz:4.4cqw;flex:none;background:var(--{g});color:var(--{t})">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><polygon points="16 8 11 11 8 16 13 13"/></svg>
      </div>
      <div class="h3" style="margin-top:1.4cqh">{h}</div>
      <p class="body" style="margin-top:.8cqh;opacity:.85">{b}</p>
    </div>''' for g, t, h, b in [
      ('g0', 't0', 'Assessment', 'Where the current stack helps the operating model and where it fights it.'),
      ('g2', 't2', 'Selection', 'A shortlist scored against the decisions the business actually makes.'),
      ('g1', 't1', 'Migration', 'Sequenced so the business keeps running while the change lands.'),
      ('g3', 't3', 'Adoption', 'Training and incentives so the tool is used the way it was chosen.')])}
  </div>'''))

# ------------------------------------------------------------------ emit ----
for name, (slot, stagestyle, body) in L.items():
    st = f' style="{stagestyle}"' if stagestyle else ''
    html = (HEAD + f'\n<div class="deck"><div class="slide"><div class="stage" data-slot="{slot}"{st}>'
            + body.rstrip() + '\n</div></div></div>\n</body></html>\n')
    (HERE / f'{name}.html').write_text(html)
print(f'wrote {len(L)} layouts')
for n in sorted(L):
    print('  ', n)
