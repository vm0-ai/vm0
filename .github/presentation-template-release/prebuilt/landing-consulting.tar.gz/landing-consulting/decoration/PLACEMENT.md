# landing-consulting — strict decoration classification

This file is measured from the original reference deck (15 slides at 1600×900).
It uses a strict definition: decoration must be distinctive to this template,
must carry no text or data, and must perform no layout or content-container
function.

## Result: the reference has no optional decoration layer

| diagnostic | reference |
|---|---:|
| declared decoration elements | 0 |
| slides with optional decoration | 0 / 15 |
| decoration per slide | 0.00 |
| paired decorations | 0 / 15 |
| decoration bleeding past the stage | n/a |

This zero is intentional. Do not invent a shape, and do not turn a structural
rectangle into an ornament, merely to raise a decoration count or coverage rate.
The generated deck has no decoration quota.

The reference remains highly identifiable because its background treatment,
content vocabulary and persistent chrome are strong. Those are separate roles;
they are not decoration.

## Layer model

Build each slide in this order:

| z-index | role | source |
|---|---|---|
| 1–3 | background fields, photographs and other layout reserves | page layout |
| 5–7 | persistent chrome | this file, below |
| 40 | `.fit` content flow | `../layouts/*.html` |

There is no fourth quota-driven ornament layer in the reference. If a future,
source-backed motif is added, declare it explicitly with `data-decoration` and
keep it textless and outside the layout tree. Nothing in the current reference
qualifies.

## Required chrome — 15 of 15 slides

Chrome is repeated interface and brand identity, not decoration:

- `left:5cqw; top:3.4cqh` — brand mark and wordmark;
- `right:5cqw; top:3.0cqh` — three navigation pills;
- `left:0; top:8.6cqh` — a 45cqw dashed rule;
- `left:45cqw; top:8.6cqh` — the rule's circular terminal;
- bottom-right page number.

The rule and terminal form one distinctive chrome device. They occur on every
reference slide, but they do not count toward decoration coverage. The four-square
brand mark also remains chrome: being a logo does not turn its squares into
ornaments.

The chrome band ends at 7.57% of stage height; the dashed rule is at 8.6%.
Content therefore starts at 13cqh, and the template-local audit rejects in-flow text that
starts above 11%.

## Elements explicitly excluded from decoration

| element | measured role | reference count |
|---|---|---:|
| edge-flush rectangular colour field (`data-background-field`) | background/layout reserve | 6 |
| circular KPI/caption container (`data-metric-disc`) | content carrier | 2 |
| title marker (`data-marker`) | text emphasis; it contains the title | 12 |
| navigation or CTA pill (`data-pill`) | chrome/control/content | 46 |
| numbered badge (`data-badge`) | row label/content cell | 3 |
| icon or numbered tile (`data-tile`) | grid/process content cell | 8 |
| image frame (`data-photocell`) | media content | 17 |
| card, panel, grid cell or rectangular fill | content container/layout structure | varies |

These elements may still be used where the corresponding layout calls for them.
They simply do not satisfy any decoration requirement and must not be marked with
`data-decoration`, `data-deco`, or `data-ornament`.

## Background fields are layout decisions

The six rectangular fields previously called `bigcircle` are now labelled
`data-background-field`. They reserve or establish a page region; they are not
objects sprinkled on top of a composition.

Measured geometry:

| layout treatment | count | geometry |
|---|---:|---|
| full-height right field | 3 | `right:0; top:0; width:8–9cqw; height:100cqh` |
| partial right field | 2 | `right:0; width:12–13cqw; height:20–22cqh` |
| full-width foot field | 1 | `left:0; bottom:0; width:100cqw; height:7cqh` |

All six stop flush at the stage boundary; none bleeds past it. Their fills are
`--g1` ×4 and `--g3` ×2. Use them only with a layout that reserves that region.
This is layout fidelity, not decoration coverage.

A full-height right field uses the shared rail contract:

```html
<div class="stage" data-right-rail style="--rail-width:9cqw;--rail-gap:2cqw">
  <div data-background-field="right-rail" style="background:var(--g1)"></div>
  <div class="fit" style="padding:13cqh 6cqw 8cqh">…</div>
</div>
```

The shell changes `.fit`'s right inset to `rail width + gap`. The audit rejects the
slide when `contentRight > railLeft - gap`; putting the field behind the content with
z-index does not make an overlap valid.

## Content treatments retain their own semantics

- A marker highlights one word or one short phrase in a title. It is part of the
  title and uses an em-based irregular radius plus `rotate(-1.5deg)`.
- A badge or tile belongs to every member of its 3–4 item set. It labels or holds
  the peer item; it is not sprinkled visual noise.
- A circular KPI container carries both a figure and caption, so it remains
  content even though its silhouette is round.
- A photograph is used only when the source calls for the depicted subject.

## Audit contract

The template-local probe now counts only explicitly declared, textless decoration. It no
longer infers decoration from rectangles, tiles, nodes, connectors, image frames,
or empty SVG wrappers. On this reference, both `bigOrnaments` and
`smallOrnaments` must read 0.

The template-local probe also returns `railOverlaps`, `textGraphicOverlaps`, and their
sum `layoutSafetyFailures`. All three must be zero on the reference and generated deck.

Run this classification check in the browser when reviewing a generated deck:

```js
const declared = [...document.querySelectorAll(
  '[data-decoration],[data-deco],[data-ornament]'
)];
({
  declared: declared.length,
  carriesText: declared.filter(e => e.textContent.trim()).length,
  structural: declared.filter(e => e.matches(
    '[data-background-field],[data-metric-disc],[data-photocell],' +
    '[data-tile],[data-badge],[data-node],[data-connector]'
  ) || e.closest('.fit,[data-device]')).length
});
```

For the reference the result is `{declared:0, carriesText:0, structural:0}`.
Any non-zero generated reading requires human verification that the element is a
template-specific, non-content, non-layout visual motif. A count alone never proves
that it is valid decoration.
