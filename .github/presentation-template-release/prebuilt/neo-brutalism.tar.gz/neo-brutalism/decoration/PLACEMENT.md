# neo-brutalism — decoration classification and placement

Every number here was measured from the original reference deck at 1600×900, 15 pages.
This file applies the v3 definition strictly: an optional decoration must be
template-specific, carry no text or data, and perform no layout or content role.

## 1. Optional decoration count: zero

**Neo-brutalism has no optional decorations.** Do not invent empty squares, cards,
colour blocks, rectangles, grid cells, circles, arches, or generic geometry to make
the count non-zero. [decoration.html](decoration.html) renders the complete
classification and begins with the explicit statement `No optional decorations`.

The visible vocabulary in the reference is real, but every item belongs elsewhere:

| name | marker | reference count | classification |
|---|---|---:|---|
| labelled `bigcircle` | `[data-bigcircle]` | 8 | content motif: every circle carries a source-backed number |
| process nodes | `[data-node]` | 3 | layout structure: one node per process step |
| process connector | `[data-connector]` | 1 | layout structure: joins the step sequence |
| number badge | `.badge` | 3 | labelled content component |
| icon tile | `.tile` | 4 | content component inside a feature card |
| photo cell | `[data-photocell]` | 14 | source-media frame |
| nav / page number | `[data-device]`, `.pagenum` | persistent | fixed chrome |

Cards, panels, filled boxes, media frames, chart marks, nodes, connectors, and the
arch top of a stat/person card are layout or content. Fixed chrome is its own layer.
None enters the optional-decoration statistic, and there is intentionally no
`item-sets.html` in this directory.

Copy the non-decoration implementations from
[../layouts/_components.html](../layouts/_components.html). The naked layout files
omit them so their Flex structure remains visible and testable.

## 2. The numbered bigcircle is content, and it never bleeds

All 8 circles carry a meaningful number. A cropped circle loses its own label, so **0 of 8
bleed off the stage** (`bleedingPct = 0.000`). Keep the entire component visible.

The number must already exist in the outline or source as a section index, year, or
datum. Do not invent a sequence to justify the motif. Arrows, quotes, punctuation marks,
and generic symbols are not numbers and never use `[data-bigcircle]`.

```
inset from the nearer side         6–9 % of stage width
inset from the nearer top/bottom   6–20 % of stage height
diameter                           6–12 cqw equivalent
```

The implementation sizes the compact label-bearing component in `em` with an
explicit `cqw` font size. It does not freeze a prose box with viewport or container
dimensions.

Corners used by all 8:

```
top-left      4      top-right     1
bottom-left   0      bottom-right  3
```

Bottom-left is left empty — it is the template’s bottom air.

## 3. Bigcircle page roles and count

The corrected reference uses the motif only when the page has a real numeric label:

| page kind | pages | labelled circles each |
|---|---|---:|
| full-bleed (`.stage` carries a `--g?` ground) | 3, 7, 11, 15 | 1 |
| ordinary content page | 4 of 11 | 1 |
| ordinary content page without a sourced number | 7 of 11 | 0 |

On a full-bleed page add `data-fullbleed-number` to `.stage` and put the circle in
`data-motif-slot="fullbleed-number"`. The shell owns the top-left position and starts
copy at `42cqh`, below the slot. Never tune `top` or `padding-top` per page. A full-bleed
page without a sourced number carries no circle. On an ordinary content page use a
right-hand corner; top-left belongs to the title. The only measured content-page
exception is `arch-stats`, whose content is inset specifically to clear its sourced
number. Do not generalise that exception.

Whole-deck rate is 8 / 15 = 0.53 numbered content motifs per page. It is a drift
diagnostic, never a quota. Zero is correct when the material supplies no suitable number.

No labelled circle overlaps text in the reference (0 / 8), and every page keeps at
least one of the three used corners free (15 / 15).

## 4. Structural and content components attach by page role

These are not ornaments and are not sprinkled:

| layout | component |
|---|---|
| `process-steps` | one node per step plus one connector behind the row |
| `numbered-list` | one numbered badge per row; cycle `--g0 --g1 --g2` |
| `feature-grid` | one outlined icon tile per feature card |
| `team`, `quote-cards` | one photo cell per named person, only when source media exists |
| `bullets`, `toc`, `timeline`, `table`, `comparison` | none; hairline separation is layout |
| `color-cards`, `kpi-cards` | none; the card or number already carries the hierarchy |

Copy exact markup from [../layouts/_components.html](../layouts/_components.html).

## 5. The lower third is reserved for chrome

`.fit` reserves `10cqh` at the bottom. That space is not under-filled content area:
it carries the page number and the deck’s bottom air.

| chrome | pages | position |
|---|---:|---|
| nav bar | 15 / 15 | `top:0`, full width, measured footprint `0–8.5cqh` |
| page number | 15 / 15 | `right:3cqw; bottom:3.2cqh` |

The naked layouts encode clearance only; add chrome during final composition from
`layouts/_components.html`.

## 6. Labelled boxes are identity, not decoration

The reference paints 21 labelled boxes, 1.40 per slide: nav cells, number badges, and
icon tiles. (The count was 41 / 2.73 before the cta pair — two boxes on 10 of 15 pages
— was removed from the template.) This is a whole-deck identity diagnostic.

A kicker is never a chip. The kicker, page number, running head, and standfirst are
plain text in all 15 reference pages. Boxing a kicker adds one false chip per slide
and is the fastest way to drift from the reference.

## 7. Colour rules measured on preferred tokens

| token relationship | observed contrast | rule |
|---|---:|---|
| `--surface` vs `--bg` | 1.00–1.13 | never a bare fill; pair with `.box` border + shadow |
| `--s2` / `--g2` | 1.6–2.4 | fill only |
| `--accent` | 2.4–15.8 | fill only; unsafe as general text |
| `--ka --k1 --k2 --k3` | at least 5.2 | text on the page ground |

The reference agenda once used fill colours as text at 1.76–2.56:1. It now cycles
the contrast-safe `--ka --k1 --k2 --k3` tokens. A full-bleed kicker uses
`color:inherit`, not `--ka`.

`--surface` is visually indistinguishable from the page without the ink outline; the
border and hard offset shadow make it a box. Neo-brutalism also uses five dark panels
in 15 pages, always bordered and shadowed.

## 8. Off-vocabulary means absent

Do not add free-floating quarter-circles, capsules, diamonds, triangles, blobs,
starbursts, or unlabelled colour blocks. They are not in the measured reference and
cannot be used as synthetic optional decoration. If a slide needs more hierarchy,
change its layout, type scale, rule treatment, or content component instead.
