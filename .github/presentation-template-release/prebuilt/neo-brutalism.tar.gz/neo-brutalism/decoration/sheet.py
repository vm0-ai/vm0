#!/usr/bin/env python3
"""Build the labelled browser-renderable decoration-classification sheet."""

from pathlib import Path


HERE = Path(__file__).parent
SOURCE = (HERE / "decoration.html").read_text()
HEAD = SOURCE[: SOURCE.index("</style>")]

SHEET_CSS = """
.deck{scroll-snap-type:none;height:auto;overflow:visible;background:#000}
.slide{width:auto;height:auto;display:block;background:transparent}
.stage{width:1600px;height:900px;margin:0}
.preview-label{font:600 28px/1.4 ui-monospace,monospace;color:#fff;background:#000;
  padding:12px 20px;letter-spacing:.04em;border-top:2px solid #444}
.preview-group{font:700 32px/1.4 ui-monospace,monospace;color:#000;background:#ffdf45;
  padding:16px 20px;letter-spacing:.08em}
</style>
"""


def document(title, entries):
    parts = [f'<div class="preview-group">{title}</div>']
    for label, stage in entries:
        parts.append(f'<div class="preview-label">{label}</div>')
        parts.append(f'<div class="slide">{stage}</div>')
    return (
        HEAD
        + SHEET_CSS
        + '\n</head><body><div class="deck">\n'
        + "\n".join(parts)
        + "\n</div></body></html>\n"
    )


def rendered_stages(source):
    chunks = source.split('<div class="slide">')[1:]
    stages = []
    for chunk in chunks:
        stage = chunk.rsplit("</div></div>", 1)[0] + "</div>"
        if not stage.lstrip().startswith('<div class="stage"'):
            raise RuntimeError("could not extract decoration-classification stage")
        stages.append(stage)
    return stages


labels = ["No optional decorations · strict count = 0"]
stages = rendered_stages(SOURCE)
if len(stages) != len(labels):
    raise RuntimeError("classification slide count changed; update labels")

(HERE / "_decoration-sheet.html").write_text(
    document(
        "No optional decorations · classified visual vocabulary",
        list(zip(labels, stages)),
    )
)

print("wrote decoration-classification sheet (1); optional decoration count = 0")
