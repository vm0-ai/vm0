(async () => {
  const ordinary = [...document.querySelectorAll('.row')].map((element, index) => ({
    name: `row-${index + 1}`,
    peers: [...element.children],
  }));
  const special = [
    ['chart-pie', '[data-slot="chart-pie"] .fit > .grow'],
    ['flow-diagram', '[data-slot="flow-diagram"] .fit > .grow'],
    ['image-left', '[data-slot="image-left"] .fit > .grow'],
    ['image-right', '[data-slot="image-right"] .fit > .grow'],
    ['image-grid', '[data-slot="image-grid"] .fit > .grow'],
    ['chart-line-legend', '[data-slot="chart-line"] .fit > .grow > div:last-child'],
  ].map(([name, selector]) => {
    const element = document.querySelector(selector);
    let peers = [...element.children];
    if (name === 'flow-diagram') {
      peers = peers.filter(peer => peer.classList.contains('box'));
    }
    return {name, peers};
  });
  const groups = [...ordinary, ...special];
  const stress = ' Extra stress sentence makes one peer substantially taller while preserving the complete meaning of the original item.';

  for (const group of groups) {
    const target = group.peers.find(peer => peer.textContent.trim()) || group.peers[0];
    const leaf = target.querySelector('p,.body,.cap,h3') || target;
    const addition = document.createElement('span');
    addition.className = 'cap';
    addition.style.display = 'block';
    addition.textContent = stress;
    leaf.appendChild(addition);
  }

  await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  const results = groups.map(group => {
    const heights = group.peers.map(peer =>
      Math.round(peer.getBoundingClientRect().height * 100) / 100
    );
    return {
      name: group.name,
      count: heights.length,
      heights,
      spread: Math.round((Math.max(...heights) - Math.min(...heights)) * 100) / 100,
    };
  });
  return {
    groups: results.length,
    maxSpread: Math.max(...results.map(result => result.spread)),
    failures: results.filter(result => result.spread > 1),
  };
})()
