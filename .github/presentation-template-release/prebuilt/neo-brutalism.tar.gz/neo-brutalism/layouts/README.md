# neo-brutalism — naked layouts

42 layouts, text only. No content components, no chrome, no colour decisions, no
measured geometry. Pair one with the classified component rules in
[../decoration/PLACEMENT.md](../decoration/PLACEMENT.md) to build a slide. The strict
optional-decoration count is zero.

13 of them are distinct compositions the original reference deck already demonstrated,
3 come from `../composition-recipes.html`, and 26 are additions a real deck needs, written in this
template's own vocabulary.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 42: zero `width` / `max-width` / `min-width` / `height` / `left` /
`top` / `right` / `bottom` / `flex-basis` in `cqw`, `cqh`, `px`, `vw` or `vh`.

`flex-basis` counts. `flex:0 0 4cqw` freezes a column exactly the way `width` does.

This matters because the original reference deck was produced by measuring a rendered deck and
writing the numbers back. It carried 19 `min-height` values with two decimal places —
`min-height:41.43cqh`, `min-height:17.69cqh` — which are not design decisions, they are
observations of one string at one font size. Copying them reproduces that string. Those
are now removed from the example; none of them are in here.

Five exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline rule or connector.
- **`em` with an explicit `font-size` in `cqw`** on a compact component that holds no prose —
  a labelled big circle, a node, a badge, a bar's thickness, a photo frame. Written `width:3.6em;font-size:1.6cqw`,
  it still scales with the stage but cannot freeze a text box.
- **`%`** in `chart-bar`, `chart-line`, `chart-pie`, `chart-scatter`,
  `chart-waterfall` and `gantt` only, where the number
  *is* the datum. A bar at 78% is reporting 78.
- text that merely *displays* a CSS string. Strip text nodes before matching.

## The safe area is set once

`.fit` carries `padding:14cqh 7cqw 10cqh 6cqw` and nothing else sets one.

Every number is measured off the reference's 15 pages, not chosen:

| edge | value | why |
|---|---|---|
| top | `14cqh` | the nav bar occupies `0–8.5cqh`; content never starts above `14cqh` on any page |
| left | `6cqw` | the left margin on 14 of 15 pages. This is the template constant the `outsideSafeArea` probe measures against |
| right | `7cqw` | the tightest right margin observed |
| bottom | `10cqh` | **not slack.** The page number sits at `bottom:3.2cqh`; the rest is the deck’s bottom air. (Was `20cqh` while the `cta` pair lived at `bottom:7cqh`; the cta was removed, so the band was returned to the content.) |

The layouts contain no chrome. They encode it as reserved space. Add the nav and page
number from [_components.html](_components.html) when you compose the slide.

Tables and record lists are direct children of `.fit` and carry `.grow`. The shell
forces that direct child to stretch across the complete safe width, even if generated
markup changes `.fit` to `align-items:flex-start`. Do not put width, max-width, side
margins, or an extra wrapper around these structures; use `data-safe-width="records"`
for tables and `data-record-list` for record lists so the contract is reviewable.

`section-divider` is the one structural exception to the normal top padding: when the
source supplies a real section number, the stage carries `data-fullbleed-number`, the
circle carries `data-motif-slot="fullbleed-number"`, and the shell reserves the fixed
copy start below it. Do not hand-tune the circle or content `top` per page.

## An axis tick and a legend chip carry `.tick` / `.legend`

`.row > *` is `flex:1;min-width:0`, and `min-width:0` is what lets a cell go
narrower than the word inside it. A row of six month ticks gives each cell a sixth
of the plot; with a longer label than the reference's `Jan`, the cell keeps
shrinking and the label folds. Measured on the shipped `chart-line` tick row
squeezed to a 28px cell: `September` came back on **6 lines** without the rule and
**1 line** with it.

```css
.tick,.legend{white-space:nowrap;}
.legend{display:flex;align-items:center;gap:.6cqw;}
```

`.tick` on an axis tick, `.legend` on a legend chip — nothing else. An explicit
`<br/>` still breaks, which is how `chart-bar` and `chart-waterfall` stack a value
over its period. Applied in `chart-line`, `chart-bar`, `chart-waterfall`,
`chart-scatter` and `gantt`; prose is left alone, because prose is meant to wrap.

## A bar that starts late carries its own offset

`gantt` used to put a spacer `<div style="width:62%">` in front of the bar. It holds
no text, paints nothing and draws nothing, so on the page it is an empty column
26–68% of the safe area wide. The start belongs on the bar:
`width:30%;margin-left:62%` — same datum, one box fewer.

## Every `.slide` must be a direct child of `.deck`

The navigation runtime collects pages with
`[...deck.children].filter(n => n.classList.contains('slide'))`. A slide nested one level
deeper renders perfectly, scrolls perfectly, screenshots perfectly — and the arrow keys
cannot reach it. A slide written after the deck's closing `</div>` is unreachable the
same way.

One line, run it on the finished deck:

```js
document.querySelectorAll('.slide').length ===
[...document.querySelector('.deck').children].filter(n => n.classList.contains('slide')).length
```

Then **press an arrow key**. This defect is found by pressing, not by measuring.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions. Not a slide.

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `statement` `longform` `two-column` `three-column` `color-cards`
`bullets` `numbered-list` `big-quote`

**People and offers** · `feature-grid` `team` `quote-cards` `price-tiers`

**Proof and pitch** · `case-study` `problem-solution`

**Numbers** · `kpi-grid` `kpi-cards` `arch-stats` `stat-highlight` `table` `chart-bar`
`chart-line` `chart-pie` `chart-scatter` `chart-waterfall`

**Time and sequence** · `process-steps` `timeline` `roadmap` `gantt`

**Structure** · `flow-diagram` `arch-diagram` `mind-map`

**Two things compared** · `comparison` `versus` `pros-cons`

**Imagery** · `image-left` `image-right` `image-hero` `image-grid` — all four delete
cleanly. When the source has no imagery, drop the `data-photocell` frame and use a prose
layout; never leave an empty box.

## Coverage audit

| communication job | layouts |
|---|---|
| frame the deck | `cover` `toc` `section-divider` `close` |
| make a statement, sustain prose, or list points | `statement` `longform` `bullets` `numbered-list` `big-quote` |
| divide an argument into two or three peers | `two-column` `three-column` `color-cards` |
| combine supplied imagery with copy | `image-left` `image-right` `image-hero` `image-grid` |
| present testimony, people, an offer, or proof | `quote-cards` `team` `feature-grid` `price-tiers` `case-study` |
| show a headline number, records, or different chart relationships | `kpi-grid` `kpi-cards` `arch-stats` `stat-highlight` `table` `chart-bar` `chart-line` `chart-pie` `chart-scatter` `chart-waterfall` |
| show time, responsibility, or delivery sequence | `process-steps` `timeline` `roadmap` `gantt` |
| explain a linear flow, hierarchy, or associative system | `flow-diagram` `arch-diagram` `mind-map` |
| compare choices or trade-offs | `comparison` `versus` `pros-cons` |
| tell a startup or product-launch story | `problem-solution` `case-study` `feature-grid` `price-tiers` |

## A filled box is sized by its content, never by the stage

```
height   row     flex:none      height comes from the tallest child, not the stage
         child   flex:1         siblings equalise to that tallest child
         group   wrapped in .grow (flex:1;min-height:0) + justify-content:center

width    box     .hug  =  align-self:flex-start; max-width:100%
```

`.fit` is a column flex with `align-items:stretch`, so **every child is full-width by
default**. `.hug` opts one box out. A **row of peers** is the exception: cards and
columns stay equal width and divide the safe area. One box hugs, a row of boxes divides.

`.row` sets `flex:none` on itself and `flex:1` on its children. Those look like the same
instruction and do opposite things — `flex:1` on the *row* makes it fill the stage and
the cards inherit the stage's height, which is a slab of colour that is half empty.

**Stress-tested, not assumed.** An extra sentence was injected into the first item of
all 26 peer rows and sibling heights compared. The final spread is `0px` on all 26.
The reproducible browser probe is [probe-equal-height.js](probe-equal-height.js); run
`sheet.py`, open `_sheet.html` at 1600×900, then evaluate that file in the page.
Four rows failed in the draft and were fixed:

- `arch-stats` and `flow-diagram` carried `align-items:flex-end` / `center`, so a taller
  first card left the other two short — 312/231/231 and 211/130/130. Both now stretch.
- `image-left` and `image-right` were worse: `align-items:center` gives a contentless
  photo frame **zero cross-size**, so the frame rendered as an 8px sliver. It passed
  every probe, because an empty frame has no text to measure. Both rows now stretch and
  the frames read 594px.

The test includes `chart-pie`'s donut/legend row, the three flow-diagram cards (ignoring
the two arrow glyphs), both split-image rows and the four-cell image row; it does not
silently restrict itself to elements carrying the `.row` helper.

## Ruled or filled

Hairlines stay a minority treatment: they separate agenda/list/table records, provide
selected chart axes, and connect schedule or diagram nodes. The bordered, shadowed box
vocabulary creates the opposite risk — every slide becoming a row of cards — so ruled
and filled alternatives remain available instead of forcing one treatment everywhere.

So each peer-row content type has both treatments, and neither is more on-template:

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `color-cards` |
| a row of numbers | `kpi-grid` | `kpi-cards` / `arch-stats` |
| two things compared | `comparison` | `versus` |
| a list of points | `bullets` | `numbered-list` |

The filled versions cycle `--g0 --g2 --g1 --g3` so neighbours never share a ground.
Pick the ruled version when the previous slide was filled, and vice versa.

## Which content component attaches to which layout

The layout files are naked on purpose. Add these structural/content components only
when composing the finished slide; copy them from [_components.html](_components.html)
rather than drawing a local substitute inside the layout file. None is optional
decoration: each carries content, performs layout, or frames supplied media.

| layout | attach |
|---|---|
| `process-steps` | one `node` per step + one `connector` — and no other layout gets a node |
| `numbered-list` | one `badge` per row, grounds cycling |
| `feature-grid` | one outlined `tile` per card |
| `team` `quote-cards` | one `photocell` per person, only when the material names them |
| `bullets` `toc` `timeline` `table` `comparison` | nothing — these separate on a hairline |
| `color-cards` `kpi-cards` | nothing — the card is the colour; another component is noise |

Copyable markup, including labelled bigcircles and fixed chrome:
[_components.html](_components.html).

## Colour

- **`.box` is the template.** `border:.3cqw solid var(--ink)` + `box-shadow:.5cqw .65cqh
  0 0 var(--ink)`. Square corners: every radius token is forced to `0`, and the only
  curve in the set is `.arch` (`7cqw 7cqw 0 0`) on stat and person cards.
- **Never `background:var(--surface)` without `.box`.** `--surface` sits at 1.00–1.13:1
  against the page in all five preferred tokens. The border is what makes it a box.
- **`--accent` is not a text colour.** 4.2:1 in mono_ink, **2.4:1 in citrus_fresh**. Use
  `--ka --k1 --k2 --k3` for type on the page ground; they are contrast-safe in every
  preferred token. Checked across all 42: zero text below 3.0:1.
- **`--s2` / `--g2` are fill-only** — 1.6–1.8:1 everywhere.
- `section-divider`, `close` and `stat-highlight` are **full-bleed**: the ground goes on
  `.stage`, not on a box. 4 of 15 reference pages are full-bleed, about one in four.
  Nothing is boxed on top of one, and a kicker there uses `color:inherit`, never `--ka`.

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` ·
structure `stage fit deck slide row grow hug box box-sm arch rule card tile badge` ·
marks `dot soft dim pagenum`.

Sizes live in those classes. If something needs to be bigger, use the next class up —
do not write a `font-size`.
