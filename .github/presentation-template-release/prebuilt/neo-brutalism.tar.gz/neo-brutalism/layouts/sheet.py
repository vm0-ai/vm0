#!/usr/bin/env python3
"""Build a labelled scrolling deck from every neo-brutalism layout."""

from pathlib import Path
import re


HERE = Path(__file__).parent
SHELL = (HERE / "_shell.html").read_text()
HEAD = SHELL[: SHELL.index("</style>")]

GROUPS = [
    ("Opening and closing", ["cover", "toc", "section-divider", "close"]),
    ("Prose", ["statement", "longform", "two-column", "three-column", "color-cards", "bullets", "numbered-list", "big-quote"]),
    ("People and offers", ["team", "feature-grid", "quote-cards", "price-tiers"]),
    ("Proof and pitch", ["case-study", "problem-solution"]),
    ("Numbers", ["kpi-grid", "kpi-cards", "arch-stats", "stat-highlight", "table", "chart-bar", "chart-line", "chart-pie", "chart-scatter", "chart-waterfall"]),
    ("Time and sequence", ["process-steps", "timeline", "roadmap", "gantt"]),
    ("Structure", ["flow-diagram", "arch-diagram", "mind-map"]),
    ("Comparison", ["comparison", "versus", "pros-cons"]),
    ("Imagery", ["image-left", "image-right", "image-hero", "image-grid"]),
]

SHEET_CSS = """
.deck{scroll-snap-type:none;height:auto;overflow:visible;background:#000}
.slide{width:auto;height:auto;display:block;background:transparent}
.stage{width:1600px;height:900px;margin:0}
.layout-chunk{width:1600px;background:#000}
.layout-label{font:600 28px/1.4 ui-monospace,monospace;color:#fff;background:#000;
  padding:12px 20px;letter-spacing:.04em;border-top:2px solid #444}
.layout-group{font:700 32px/1.4 ui-monospace,monospace;color:#000;background:#ffdf45;
  padding:16px 20px;letter-spacing:.08em}
</style>
"""

entries = []
for group, names in GROUPS:
    for name in names:
        source = (HERE / f"{name}.html").read_text()
        match = re.search(
            r'(<div class="stage".*</div>)\s*</div></div>\s*</body>',
            source,
            re.S,
        )
        if not match:
            raise RuntimeError(f"could not extract stage from {name}.html")
        entries.append(
            (
                group,
                f'<div class="layout-label">{name}.html</div>'
                f'<div class="slide">{match.group(1)}</div>',
            )
        )

parts = []
for chunk_index in range(0, len(entries), 9):
    chunk = entries[chunk_index : chunk_index + 9]
    chunk_parts = []
    previous_group = None
    for group, markup in chunk:
        if group != previous_group:
            chunk_parts.append(f'<div class="layout-group">{group}</div>')
            previous_group = group
        chunk_parts.append(markup)
    parts.append(
        f'<section class="layout-chunk" id="chunk-{chunk_index // 9 + 1}">'
        + "\n".join(chunk_parts)
        + "</section>"
    )

def document(markup):
    return (
        HEAD
        + SHEET_CSS
        + "\n</head><body><div class=\"deck\">\n"
        + markup
        + "\n</div></body></html>\n"
    )


(HERE / "_sheet.html").write_text(document("\n".join(parts)))
for index, part in enumerate(parts, 1):
    (HERE / f"_sheet-{index}.html").write_text(document(part))

print(
    f"wrote master + {len(parts)} top-anchored sheets with "
    f"{sum(len(x) for _, x in GROUPS)} layouts"
)
