# Neo Brutalism

## Visual identity

Raw web brutalism: thick ink outlines, solid offset shadows, square corners, and persistent navigation. The voice is direct, the structure is overt, and the texture is deliberately unpolished.

## Color system tokens

Read the prompt's `color-system` before generating. If it provides one of the valid tokens below, use that token exactly. If it does not, the Agent selects a token based on the content, audience, mood, information density, and readability. Use only one token per deck.

The demonstration category documented for this template is **M (single dominant colour)** and its example token is `mono_ink`; select the generation token using the rule above.

Use only these exact snake_case token values:

- Single dominant colour M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`mono_ink`, `bauhaus_primary`, `citrus_fresh`, `berry_pop`, `midnight_mono`

The default color system used in `example/reference.jpg` is `mono_ink`.
Picking a token outside this list is how a deck ends up looking like a different
template: a finance source, for instance, pulls every template toward the same
muted corporate grey unless the list stops it.


After choosing a token, read `color-systems/<token>.css`, inline its single CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="mono_ink">
```

- Use `--bg`, `--surface`, `--ink`, `--soft`, and `--ph` for the page, surfaces, body text, secondary text, and image placeholders.
- `--accent`, `--s1`, `--s2`, and `--s3` are the source hues for non-text graphics and component fills. `--oa`, `--o1`, `--o2`, and `--o3` are foreground colours selected by v1 for those source hues; use them for large icons or non-text symbols. Use the contrast-safe text tokens below for normal text.
- For text on the standard `--bg`, use the contrast-safe `--ka`, `--k1`, `--k2`, and `--k3`. Use `--kad` for accent text on an `--ink` field. When a source hue needs stronger text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour fields containing text, use `--g0` through `--g3` and pair each with the matching `--t0` through `--t3`.
- HTML/CSS components reference only `var(--...)`; derive translucent layers, outlines, shadows, and gradients from defined tokens as well.

Use `--bg` and `--ink` to establish hard-edged structure, concentrate `--accent` on one action or focal point, and use `--g1` / `--g3` for chapter colour fields.

```css
.slide { background: var(--bg); color: var(--ink); }
.surface { background: var(--surface); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Space Grotesk` for display type and `Lexend` for body type.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600&family=Lexend:wght@300;400;500;600&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Space Grotesk";
  --fb: "Lexend";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600; available body weights are 300 / 400 / 500 / 600. Use `--fd` for titles, hero numbers, and chapter numbers; use `--fb` for body text, labels, chart annotations, and tables. CJK text preserves the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the audited base stylesheet used by [layouts/_shell.html](layouts/_shell.html).
Copy it verbatim into the single `<style>` block, immediately after the inlined
colour-system CSS, before writing any slide. It defines the 16:9 stage, the one safe
area, the type scale, and the content-component classes the rest of this document
refers to. A deck that invents its own shell will not look like this template.

```css
:root{
  --r-xs: .5cqw;
  --r-sm: .9cqw;
  --r-md: 1.7cqw;
  --r-lg: 3cqw;
  --r-xl: 5cqw;
--fd: "Space Grotesk";
  --fb: "Lexend";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);overflow-wrap:break-word;word-break:normal;}
.stage *{overflow-wrap:break-word !important;word-break:normal !important;}

/* THE SAFE AREA. Set once, here, and never again.
   top    14cqh — clears the 8.5cqh nav bar with air
   bottom 10cqh — the page number, plus the deck’s bottom air
   sides   6/7cqw — the measured envelope of all 15 reference pages           */
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;
  display:flex;flex-direction:column;padding:14cqh 7cqw 10cqh 6cqw;}

img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:6;}

.tile{container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;}
.tile>span{font-size:40cqw;line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;}
.badge>span{font-size:40cqw;line-height:1;}
.card{background:var(--surface);border-radius:var(--r-md);}
.dot{border-radius:50%;}
.dim{opacity:.84;}
.soft{color:var(--soft);}

:root{--r-xs:0!important;--r-sm:0!important;--r-md:0!important;--r-lg:0!important;--r-xl:0!important;}

.box{border:.3cqw solid var(--ink);box-shadow:.5cqw .65cqh 0 0 var(--ink);}
.box-sm{border:.26cqw solid var(--ink);box-shadow:.35cqw .45cqh 0 0 var(--ink);}
.arch{border-radius:7cqw 7cqw 0 0;}
.rule{border-bottom:.16cqw solid color-mix(in srgb,var(--ink) 22%,transparent);}
.row{display:flex;flex:none;gap:2.4cqw;align-items:stretch;}
.row>*{flex:1;min-width:0;}
.hug{align-self:flex-start;max-width:100%;}
.grow{flex:1;min-height:0;min-width:0;}
/* A direct-child grow is the safe-width contract for tables and record lists.
   It must not shrink when a generated page changes .fit's cross-axis alignment. */
.fit>.grow{align-self:stretch!important;width:auto!important;max-width:none!important;margin-left:0!important;margin-right:0!important;}
.fit:has(> .grow[data-record-list], > .grow[data-safe-width="records"], > .grow [data-safe-width="records"]){align-items:stretch!important;}
/* Full-bleed section numbers occupy one named slot. The shell owns both the
   circle position and the copy clearance, so pages never hand-tune top values. */
.stage[data-fullbleed-number]{--fullbleed-number-left:6cqw;--fullbleed-number-top:18cqh;--fullbleed-number-font:3cqw;--fullbleed-copy-top:42cqh;}
.stage[data-fullbleed-number]>[data-bigcircle][data-motif-slot="fullbleed-number"]{left:var(--fullbleed-number-left)!important;top:var(--fullbleed-number-top)!important;right:auto!important;bottom:auto!important;font-size:var(--fullbleed-number-font)!important;width:4em!important;height:4em!important;}
.stage[data-fullbleed-number]>.fit{justify-content:flex-start!important;padding-top:var(--fullbleed-copy-top)!important;}
```
The number inside a `badge` and any text inside a `tile` must be wrapped in a
`<span>`. The wrapper is what makes the text scale with the box: it is measured
against the component's own width, so the figure stays in proportion at any size.
Size a compact label-bearing component with an explicit `font-size` in `cqw` and
matching `width` / `height` in `em`; never put a `cqw`, `cqh`, `px`, `vw`, or `vh`
dimension on an element that holds text.


## Signature elements

Available signature elements: `nav-bar`, `hard-shadow`, `num-circle`, `arch-card`, `device-placeholder`.


Visual reference: [example/reference.jpg](example/reference.jpg)

## Motif library

Every motif below is copied out of this template's own reference deck. This is
the geometry that makes the template recognisable, and it is the part that goes
missing when a deck is authored from the prose alone — the shapes exist nowhere
else; it is reproduced here so generation never needs a full-deck HTML example.

**Copy these snippets. Do not paraphrase them, redraw them, or substitute a
shape that is easier to write.** Change only size, position, colour token, and
text content. The count beside each motif is how many times the reference deck
uses it across fifteen slides. It records prevalence; it is not a floor, quota,
or target to scale mechanically. Use a motif only where the closest reference
page role uses it and the composition benefits.


### `badge` — used 3× in the reference deck

```html
<div class="badge" data-badge="1" style="width:5em;height:5em;font-size:1cqw;background:var(--g0);color:var(--t0)"><span>01</span></div>
```

### `bigcircle` — used 8× in the reference deck

**Numbered content motif.** Use it only when the source or outline supplies the exact
section index, year, or datum shown inside it. Never invent a sequence and never put an
arrow, quote, punctuation mark, or generic symbol in it. All 8 corrected-reference
circles sit fully inside a measured corner and none overlaps type. Ordinary content uses
a right-hand corner. A full-bleed page uses the fixed `fullbleed-number` slot below; its
position is not free to improvise.

```html
<div data-bigcircle="1" style="position:absolute;right:7cqw;top:12cqh;width:4.286em;height:4.286em;border-radius:50%;background:var(--g0);color:var(--t0);border:.3cqw solid var(--ink);box-shadow:.5cqw .65cqh 0 0 var(--ink);display:flex;align-items:center;justify-content:center;font-family:var(--fd);font-weight:700;font-size:2.1cqw;line-height:1;z-index:5">2030</div>
```

For a full-bleed page add `data-fullbleed-number` to `.stage` and use:

```html
<div data-bigcircle="1" data-motif-slot="fullbleed-number" style="position:absolute;left:6cqw;top:18cqh;width:4em;height:4em;border-radius:50%;background:var(--g0);color:var(--t0);border:.3cqw solid var(--ink);box-shadow:.5cqw .65cqh 0 0 var(--ink);display:flex;align-items:center;justify-content:center;font-family:var(--fd);font-weight:700;font-size:3cqw;line-height:1;z-index:5">01</div>
```


### CSS signatures

These declarations are part of the template's look. The counts are from the reference deck.

| property | values it actually uses | why it matters |
| --- | --- | --- |
| `box-shadow` | `.5cqw .65cqh 0 0 var(--ink)` ×59<br>`.35cqw .45cqh 0 0 var(--ink)` ×2 | offset shadows are a signature, not a default |
| `border-radius` | `6cqw 6cqw 0 0` ×4<br>`7cqw 7cqw 0 0` ×3<br>`999px` ×1 | arch cards and one small status pill |


### Copy sources for the remaining signatures

Do not copy measured geometry from `layouts/`. `nav-bar`, `num-circle`
and the compact content components are copyable in
[layouts/_components.html](layouts/_components.html); `hard-shadow`, `arch-card` and
image-frame constructions are in [layouts/_shell.html](layouts/_shell.html) and the
named files under [layouts/](layouts/).

## Visual-component reference profile (diagnostic only)

Observed from this template's own reference deck, per slide, rendered at
1600×900. These averages combine unlike page roles: covers, section dividers,
dense content pages, comparisons, and closings.

**These figures are diagnostics, never quotas or per-slide instructions.**
First choose the closest page role in [layouts/](layouts/),
then use only the named signature elements and motifs demonstrated in that
composition. A utility class, empty colour field, outlined box, circle, pill,
arc, quarter-circle, or other shell geometry is not a motif by itself.

| per slide | vocabulary | reference total | interpretation |
| --- | --- | --- | --- |
| **0.53** | numbered `bigcircle` | 8 | content motif; zero or one, only where the material supplies the number |
| **0.267** | `node` + `connector` | 4 | layout structure; all four belong to the single process page |
| **0.93** | `photocell` | 14 | source-media frame; delete it when the source has no image |
| **1.40** | labelled boxes | 21 | content/chrome: nav cells, badges and tiles; a kicker is not one |
| **0** | optional decoration | 0 | strict v3 classification; do not invent geometry to raise it |


Read the figures only as a whole-deck drift signal. Around half the reference
rate can be appropriate when the material or page-role mix differs. Judge
fidelity by motif identity, placement, and composition rather than item count.
Sparse slides are intentionally sparse.

These are whole-deck diagnostics, not quotas. Every row except the last describes
content, layout, source media, or fixed chrome. None is optional decoration. A
text-only source should draw fewer photocells; an empty frame is worse than a lower
rate.

**A kicker is not a chip.** In this template's reference deck the `kicker`, the
page number, the running head and the standfirst are plain text — no background,
no border, no shadow, no rounded pill around them. Every one of the 15 reference
pages agrees on this, and giving them a box is the single most common way a
generated deck drifts: a kicker appears on every slide, so boxing it adds one
false chip per slide and doubles this template's labelled-box count on its own.

Only the elements the motif library actually draws as chips — `badge`, `tag`,
`pill`, and whatever else this file shows with a fill — carry a background.
Everything else that is text stays text.

**Before delivering, audit identity.** On three representative slides, verify that
every content motif maps to a named signature element or to a specific composition in
the reference. Verify separately that no optional decoration was invented. Use the
table above only to notice gross whole-deck drift.

Content still comes first. Never push text off the stage, cover it, or drop a point. Never add a photograph
the source material does not support. A slide carrying six bullets may correctly
carry no labelled content motif at all.


## Labelled-content-motif safe area

This template has no optional decoration. The rules below govern the labelled
`bigcircle` content motif; it never fights the prose content.

- Every slide has a **text safe area**: the region actually occupied by the
  title, body copy, figures, and labels. No labelled content motif may sit on top of it.
- The bigcircle belongs outside the prose region in the measured legal corners. It is
  never used as a generic background shape and never overlaps a photograph or text.
- **Every large circle in this template carries content, so none of them is
  cropped.** Measured on the corrected reference: 8 of 8 big circles sit fully inside the
  stage, 0 bleed off the edge. A circle pushed off the edge loses half of its own
  label. Put it in a corner — `6–9cqw` from the side, `6–20cqh` from top or
  bottom — never floated in the middle of the composition. Full placement rules,
  including which corner is legal on which page, are in
  [decoration/PLACEMENT.md](decoration/PLACEMENT.md).

## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** A label positioned with `left:88cqw` will
overflow the moment its text is longer than the author guessed, and CJK copy is
routinely wider than the Latin draft it was written against. Anchor anything in
the right third with `right:` instead of `left:`, and anything in the bottom
third with `bottom:` instead of `top:`. A block anchored to the edge it is near
grows inward, where there is room, instead of outward into nothing. Give any
absolutely-positioned text an explicit `max-width` so it wraps rather than
extends.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a grid or a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

Both faults hide from a quick glance at the whole deck and are obvious on the
slide itself. Before delivering, look at every slide that carries a set of
things and check that the set is aligned and that nothing touches an edge it was
not meant to touch.

## Never do this

- **Never use a disc-bulleted list.** No slide in this template's 15-page reference
  contains a `<ul>` with default bullets, and a bulleted list is the
  fastest way to make a designed template look like a plain document. Structure a
  list as numbered rows with a hairline rule between them, as key–value rows, as
  a row of cards, or with the template's own motifs — whatever the reference deck
  does for the same job.
- Never invent a colour outside the inlined colour-system tokens; every colour
  goes through `var(--...)`.
- Never leave a slide without the chrome named in `Required chrome`.
- Never let a labelled content motif sit on top of a title or a paragraph.
- Never generate a photograph the supplied material does not call for.

## Required chrome

Chrome is the cheapest part of a template's identity and the most frequently
dropped: across the benchmark's baseline decks, four of six templates carried a
footer on 0-2 slides out of 17. This template's reference deck carries the
following, and the count is measured from that deck, not assumed.

**Persistent navigation bar** — present on 15 of the reference deck's 15 slides, unchanged from slide to slide. It is the template's most visible piece of identity and the first thing a generated deck drops.

```html
<div data-device="nav" style="position:absolute;left:0;top:0;right:0;display:flex;align-items:stretch;background:var(--g2);color:var(--t2);border-bottom:.3cqw solid var(--ink);z-index:9;font-family:var(--fd);font-weight:500;font-size:1.45cqw;line-height:1;padding:2.52cqh 0">
    <div style="display:flex;align-items:center;padding:0 2.8cqw;border-right:.3cqw solid var(--ink)">Home</div><div style="display:flex;align-items:center;padding:0 2.8cqw;border-right:.3cqw solid var(--ink)">About</div><div style="display:flex;align-items:center;padding:0 2.8cqw;border-right:.3cqw solid var(--ink)">Contact</div>
    <div style="flex:1;display:flex;align-items:center;justify-content:center;border-right:.3cqw solid var(--ink);font-weight:600;letter-spacing:.01em">Your Company</div>
    <div style="display:flex;align-items:center;gap:.8cqw;padding:0 2.8cqw">Search<svg viewBox="0 0 24 24" style="width:1.7cqw;height:1.7cqw;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round"><circle cx="11" cy="11" r="7"/><line x1="20" y1="20" x2="16.5" y2="16.5"/></svg></div>
  </div>
```

The reference nav occupies `0–8.5cqh`; the copyable version reaches that measured
footprint through line-height and vertical padding instead of freezing a text-bearing
element with `height:8.5cqh`.


**Page number** — on 15 of 15 slides:

```html
<div class="pagenum">page 01</div>
```

Carry page number on **every** slide, including the cover and the closing slide.
