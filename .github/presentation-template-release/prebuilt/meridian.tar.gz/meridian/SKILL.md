---
name: meridian
description: Create a standalone 16:9 HTML presentation deck with the Meridian visual identity and direct-HTML workflow. Use when the user selects the Meridian presentation template or explicitly names meridian as the deck style. Best suited to rational, modular corporate-strategy and professional-services presentations.
---

# Meridian presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one standalone HTML file with one live `.deck`. Keep every `.slide` as a direct child, give it one 16:9 `.stage`, and include the deck CSS and keyboard-navigation script once.
- Translate the completed outline directly into HTML in the same order. Treat the examples as visual grammar and quality references, not as a fixed page catalogue, slot schema, or required slide count.
- Create one direct-child `.slide` per planned page and one 16:9 `.stage` inside each slide.

### Layout — start from a canonical layout

For every slide, copy the closest file in [layouts/](layouts/) and adapt its text. Use the
reference image only for scale and rhythm.

- **No container- or viewport-unit sizing on anything that holds text.** Do not write
  `width`, `max-width`, `min-width`, `height`, `left`, `top`, `right`, `bottom`,
  `flex-basis`, or a fixed `flex` basis in `cqw`, `cqh`, `px`, `vw`, or `vh` on a text
  element. The safe area is set once by `.fit` padding. Peer columns are `flex:1`; a
  single box that should hug its copy uses `align-self:flex-start;max-width:100%`.
- **A text box with nothing to its right runs the full row.** No measure cap — not
  `max-width` in `em` either — on a title, lead or paragraph unless a real neighbour
  (image, chart, second column) occupies the space beside it. A paragraph that wraps
  inside a box narrower than the safe area, with empty stage to its right, is the
  defect; it is measured, not judged. Half width is allowed only next to content.
- Everything that arranges content is Flexbox. Do not use Grid, floats, or absolute
  positioning for layout. Absolute positioning is reserved for `.fit`, persistent
  chrome, a field or badge whose role is explicitly out of flow, and decoration.
- The checkable exceptions are `height:1px` for a hairline, `em` for a mark that carries
  no prose, and `%` where the number is the datum in `chart-bar`, `chart-stacked`, or
  `roadmap`.
- **A visibly filled box is sized by its content in both dimensions.** Its peer row is
  `flex:none`; each peer is `flex:1` so siblings equalise to the tallest one. Centre that
  row under the title with an outer `flex:1;min-height:0;display:flex;
flex-direction:column;justify-content:center` group. Reserve a filling `flex:1` for an
  image frame or chart plot area.
- Any Flex child holding an SVG or a percentage-height bar needs `min-height:0`.
- If no image improves the slide, remove the image frame and choose a prose layout;
  never leave a decorative placeholder.
- Preserve the template's flat fields, sharp corners, hairline rules, uppercase display
  titles, and indexed item sets. Review content and decoration as separate layers; move
  decoration rather than copy when they collide.
- Treat every slide as a projected presentation canvas. Write concise visible copy for the audience and keep one clear hierarchy of title, supporting content, and evidence on each page.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

- Photographs and full-frame illustrations use `data-image-fit="cover"` so the media
  cell has no uncovered placeholder bands. Keep the focal subject in frame by adjusting
  its crop or position. Use `data-image-fit="contain"` only when every edge carries
  information — diagrams, screenshots, logos — and inspect the rendered cell; visible
  placeholder-grey letterboxing is a defect, so change the fit, crop, or layout.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

- Read [design-system.md](design-system.md) for the deck shell, motif library, and
  required chrome.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — motifs, background treatment, chrome;
  4. every optional motif follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is accurate but visually anonymous also fails.

#### Build from the canonical layouts

Use `layouts/` to understand rhythm and scale, not as reusable layout markup.

Build every slide from two files instead:

- **[layouts/](layouts/)** — 39 naked layouts, text only, one file each. No chrome, no
  ornament, no written geometry. `layouts/README.md` is the index and the sizing rule.
- **[decoration/](decoration/)** — the ornament vocabulary
  ([decoration.html](decoration/decoration.html)), the marks that attach to repeated items
  as copyable markup ([item-sets.html](decoration/item-sets.html)), and the documented
  placement rules ([PLACEMENT.md](decoration/PLACEMENT.md)).

Pick a layout, copy it, put the content in, then add the chrome and the decoration that
`PLACEMENT.md` assigns to that page role. Read `layouts/` for rhythm and scale
— not for numbers to copy.

| the slide's job                              | layout                                          |
| -------------------------------------------- | ----------------------------------------------- |
| open the deck                                | `cover`                                         |
| contents / agenda                            | `toc`                                           |
| start a section                              | `section-divider`                               |
| close                                        | `close`                                         |
| one declarative sentence without attribution | `statement`                                     |
| sustained prose with decision notes          | `longform`                                      |
| unordered findings or takeaways              | `key-points`                                    |
| a claim in two parts                         | `two-column`                                    |
| three parallel ideas                         | `three-column` (ruled) · `color-cards` (filled) |
| an ordered set of claims                     | `numbered-list`                                 |
| one sentence that is the point               | `big-quote`                                     |
| testimony from several people                | `quote-cards`                                   |
| a row of metrics                             | `kpi-grid` (outlined) · `kpi-cards` (filled)    |
| one number that is the headline              | `stat-highlight`                                |
| rows of records, IDs, counts                 | `table`                                         |
| a quantity over time                         | `chart-bar` · `chart-line`                      |
| part of a whole                              | `chart-stacked`                                 |
| a starting value bridged to an ending value  | `chart-waterfall`                               |
| several executive signals on one page        | `dashboard`                                     |
| a repeatable method                          | `process-steps`                                 |
| dated milestones                             | `timeline`                                      |
| phases across quarters                       | `roadmap`                                       |
| overlapping workstreams across weeks         | `gantt`                                         |
| a system in tiers                            | `arch-diagram`                                  |
| evidence branching into decisions            | `mindmap`                                       |
| options positioned by two criteria           | `strategy-matrix`                               |
| two options weighed                          | `comparison` (quiet) · `versus` (loud)          |
| what it costs and buys                       | `pros-cons`                                     |
| a picture and its argument                   | `image-left` · `image-right` · `image-hero`     |
| several pictures                             | `image-grid` · `team`                           |
| context, intervention and measured outcome   | `case-study`                                    |
| tiers of engagement                          | `pricing`                                       |

Never invent a layout when one of these does the job. If none does, compose from the
closest one rather than from another template's habits — no pie charts, no radial hubs, no
pill buttons, no terminal windows. Meridian is flat, rectangular and ruled.

- Optional: [example/reference.jpg](example/reference.jpg) for the visual identity and [layouts/](layouts/) for full-slide scale, rhythm, and composition.
- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. Use it to understand the column roles and row treatment, then start from the matching file in `layouts/` rather than copying fixed content-specific geometry. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use the prompt's `color-system` when supplied, otherwise a preferred token from
  `design-system.md`. Inline that one `color-systems/<token>.css` in the final HTML.

#### Decoration

Decoration is not bound by the safe area: an ornament may cross it and bleed off the
stage where `PLACEMENT.md` says so. The safe area binds type and content.

- Follow [decoration/PLACEMENT.md](decoration/PLACEMENT.md): Meridian's identity is the
  fixed top chrome, not a field of floating ornaments. Optional squares stay fully inside
  the right margin; the only large fields are flat rectangles flush with a stage edge.
  Do not crop optional squares.
- Decoration stays outside the region the content occupies. A title crossing a field or
  square is the most common way these decks lose legibility; move the decoration, never
  the copy.
- Never place body copy on top of a photograph unless the photograph is a
  full-bleed field and the copy sits on a text-safe treatment.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Identity checks while authoring

First confirm the content survived: every point is still on its slide and no
image or caption appears that the material does not support. Then audit
identity:

- every slide carries the chrome from `Required chrome`;
- every ornament maps to a named item and page role in `Motif library` or
  `decoration/PLACEMENT.md`;
- motifs appear on appropriate page roles, in their own geometry, without
  generic substitute circles, squares, arches, or colour blocks;
- exactly one `data-color-system` token, and it is one of the preferred tokens;
- keep authored ornaments clear of type; any reported geometric crossing remains an
  optional-review candidate under `Automated QA` below.

Resolve any failure before running Automated QA.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
