# Meridian opaque shell interface

`layouts/shared-shell.html` is runtime infrastructure. Copy it without opening or
reading it:

```sh
cp layouts/shared-shell.html <deck>.html
```

Only the following literal anchors are authoring interfaces. Edit them in the copied
deck and leave every other shell byte unchanged.

- Root metadata: `<html data-safe-area="0.056" lang="en" data-color-system="slate_corporate">`
- Document title: `<title>meridian — shell</title>`
- Colour-system import: `<link rel="stylesheet" href="../color-systems/slate_corporate.css" />`
- Deck opening: `<div class="deck" aria-label="Meridian presentation">`
- Slide insertion range:

```html
<!-- BEGIN SLIDES -->
<!-- For each selected fragment, insert one direct-child .slide wrapper here. -->
<!-- END SLIDES -->
```

Replace the colour-system import with the already-read selected CSS in one inline
`<style data-color-system="<token>">...</style>` block. Replace the content between
the slide markers with one direct-child `<div class="slide">...</div>` per page while
retaining both marker comments. No other shell CSS, JavaScript, or runtime markup is an
authoring surface.
