# meridian — naked layouts

39 layouts, text only. No chrome, no decoration, no colour decisions, no measured
geometry. Pair one of these with [`../decoration/PLACEMENT.md`](../decoration/PLACEMENT.md)
to build a slide.

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions — the same
block `design-system.md` tells you to copy verbatim. Not a slide.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 39: zero `width` / `max-width` / `min-width` / `height` / `left` /
`top` / `right` / `bottom` / `flex-basis` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This matters because the removed full-deck HTML example was produced by measuring a rendered deck and
writing the numbers back. `width:31cqw` on the cover rail and `width:5cqw` on the contents
numbers are observations of one string at one font size, not design decisions. Copying
them reproduces that string. These layouts carry none of them.

Exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline rule. A hairline is a hairline at any scale.
- **`em`** on a mark with no prose in it — a badge, an icon tile, a legend swatch. `em`
  scales with the type around it, so it cannot freeze a text box the way `cqw` can. Size
  `.badge` and `.tile` with `--sz` in `em`, and wrap their contents in a `<span>`; the
  span is measured against the box's own width, so the figure stays in proportion.
- **`max-width` in `em`** on a paragraph, as a *measure* limit. 34em of body copy is a
  line length; 52cqw is one sentence's observed width.
- **`%`** where the number is the datum — bar heights in `chart-bar`, bar widths in
  `chart-stacked`, and the offset and span of a phase in `roadmap`.

Everything is flex. No grid, no float, no absolute positioning for layout. The safe area
is set **once**, by the padding on `.fit`: `16cqh 6cqw 8cqh`.

Any flex child holding an SVG or a percentage-height bar needs `min-height:0`.

## The safe area is 16cqh at the top, not 12

Meridian's chrome band is deeper than bloom's. Measured on the reference: the nav ends at
6.47 % of stage height, the corner square at 6.78 %, the hairline rule at **8.36 %**. The
nearest the reference brings content to it is 16.37 %. So `.fit` starts at 16cqh, and
nothing may begin above 11 %.

The left and right inset is **6 cqw**, which renders as a 5.6 % modal left edge for text.
That 5.6 % is meridian's safe-area constant — pass it to the probe as `SAFE=0.056`.

## Files

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `statement` `longform` `key-points` `two-column` `three-column`
`color-cards` `numbered-list` `big-quote` `quote-cards`

**Numbers** · `kpi-grid` `kpi-cards` `stat-highlight` `table` `chart-bar` `chart-line`
`chart-stacked` `chart-waterfall` `dashboard`

**Time and sequence** · `process-steps` `timeline` `roadmap` `gantt`

**Structure** · `arch-diagram` `mindmap` `strategy-matrix`

**Two things compared** · `comparison` `versus` `pros-cons`

**Imagery** · `image-left` `image-right` `image-hero` `image-grid` `team` — all five delete
cleanly. When the source has no imagery, drop the `data-photocell` frame and use a prose
layout; do not leave an empty box. Their media cells default to
`data-image-fit="cover"` so a mismatched source ratio does not expose grey placeholder
bands. Switch a cell to `contain` only for a diagram, screenshot, or logo whose complete
edge is meaningful, then inspect its ground.

**Evidence and decisions** · `case-study`

**Meridian-specific** · `pricing` `dashboard` `strategy-matrix`

## Where the set came from

The reference deck's own 15 pages are the floor — those are the compositions this template
actually knows: `cover`, `toc`, `section-divider` (×3, in left / centred / bottom-anchored
variants — one layout), `chart-bar`, `numbered-list`, `team`, `color-cards`,
`process-steps`, `image-grid`, `kpi-grid`, `quote-cards`, `pricing`, `close`.

`composition-recipes.html` added three that the example does not carry: `big-quote`,
`comparison` and `table`.

The next fourteen are gaps a real deck hits and meridian had no answer for:
`two-column`, `three-column`, `kpi-cards`, `stat-highlight`, `chart-line`,
`chart-stacked`, `timeline`, `roadmap`, `arch-diagram`, `versus`, `pros-cons`,
`image-left`, `image-right`, and `image-hero`. Each is written in meridian's own
vocabulary — flat fields, sharp corners, hairline rules, uppercase display titles, an
index number on every item in a set.

A coverage review added nine more jobs that the first set still could not communicate
without overloading a neighbouring layout: a declaration (`statement`), sustained prose
(`longform`), unordered findings (`key-points`), a context–intervention–outcome proof
(`case-study`), a task schedule (`gantt`), a branching argument (`mindmap`), a 2×2
portfolio choice (`strategy-matrix`), a multi-signal executive readout (`dashboard`), and
a value bridge (`chart-waterfall`). They are not aliases: each has a different content
contract and a different reading order.

Three things were deliberately **not** built, because taking them would have imported
another template's language rather than the job it does:

- **`chart-pie` / `chart-radar` / a donut** — meridian's chart vocabulary is
  `two-tone-bar-chart` and its geometry is rectangular. Part-to-whole is served by
  `chart-stacked`, a proportion bar, which is in vocabulary. A pie is not.
- **`flow-diagram`** — it would have been `process-steps` with arrowheads. Meridian's only
  connector is a straight hairline; branching arrows are an invention.
- **radial mind maps / `terminal` / `cta`** — a radial hub, a skeuomorphic window and a
  pair of clickable buttons are all foreign to a flat modular corporate template.
  Meridian's `mindmap` is instead a ruled left-to-right logic map: evidence, synthesis,
  decisions. It adds the branching job without importing the radial visual language.

## Which ornament attaches to which layout

The layouts are naked on purpose, but several describe a **set of peer items**, and in
meridian every item in such a set carries the same mark. Copyable markup:
[../decoration/item-sets.html](../decoration/item-sets.html).

| layout | attach |
|---|---|
| `numbered-list` `kpi-grid` `kpi-cards` | one square `badge` or index per item, grounds cycling `--g0 --g2 --g1 --g3` |
| `process-steps` | one round `node` per step **plus** one `connector` hairline behind the row |
| `color-cards` | one icon `tile` per card, four different icons, index top-right |
| `team` `image-grid` `image-left` `image-right` `image-hero` | one `photocell` per item |
| `timeline` `roadmap` `gantt` `arch-diagram` `mindmap` `strategy-matrix` `three-column` `comparison` `pros-cons` `table` `longform` `key-points` `case-study` `dashboard` `chart-waterfall` | nothing — these already carry hairline rules, data marks, or filled evidence fields |
| `section-divider` | the square pair, large + small, in the right margin |
| `big-quote` `two-column` `stat-highlight` `close` | nothing. These are type. |

## Ruled or filled — every peer row has both

Many of the 39 layouts separate items with a hairline rule. That can become a skewed
menu: an agent
sampling it puts the same horizontal line on every slide. So each peer-row content type
has two treatments, and neither is more on-template than the other:

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `color-cards` |
| a row of numbers | `kpi-grid` (outlined) | `kpi-cards` (grounds) |
| two things compared | `comparison` | `versus` |
| a sequence | `timeline` | `roadmap` |

The filled versions cycle `--g0 --g2 --g1 --g3` so neighbours never share a colour. Pick
the filled version when the items are short and parallel, when the ruled version reads
thin, or simply when the previous slide was ruled.

`kpi-grid` uses meridian's own outlined cell —
`outline:.2cqh solid color-mix(in srgb,currentColor 26%,transparent); outline-offset:-.2cqh`
— which is the reference's treatment on its stat matrix, not a border.

## A filled box is sized by its content, never by the stage

```
height  row     flex:none        — from the tallest child, not the stage
        child   flex:1           — every sibling matches that tallest child
        group   wrapped in flex:1;min-height:0;…;justify-content:center

width   box     align-self:flex-start; max-width:100%
```

`.fit` is a column flex with `align-items:stretch`, so every child is full-width by
default; `align-self:flex-start` opts one box out. The exception is a **row of peers** —
cards, columns, steps — which stay equal width and divide the safe area. One box hugs, a
row of boxes divides.

`flex:1` on the **row** and `flex:1` on the **child** look like the same instruction and do
opposite things. On the row it fills the stage and the cards inherit the stage's height,
giving a slab of colour that is half empty.

Peer rows use `align-items:stretch` and content-led height, so siblings remain level when
one item carries longer copy. The cover's copy and full-height stat rail are different
regions, not peers, and are excluded from that rule.

## What the probe reads on these

`../tools/run.sh`, with `SAFE=0.056`. All 39 layouts and the reference read
**0** on every gate below.

| criterion | reference | 39 layouts | gates? |
|---|---|---|---|
| `overflow` | 0 | 0 | yes |
| `outsideSafeArea` | 0 | 0 | yes |
| `aboveChromeBand` | 0 | 0 | yes |
| `columnsMisaligned` | 0 | 0 | yes |
| `lowContrast` | 0 *(after fixing the contents numbers)* | 0 | yes |
| `boxesUnderfilledH` | 0 | 0 | yes |
| `boxesUnderfilledV` | **1** | 0 | report only |
| `orphanSlides` / `indirectSlides` | 0 / 0 | 0 / 0 | yes |
| `navigableSlides` | 15 of 15 | 1 of 1 each | yes |

The reference's single `boxesUnderfilledV` is the cover's stat rail — a colour field that
runs the full height of the stage with its two figures centred in it. That is the cover's
signature, not an underfilled card, so the criterion is reported rather than gated. Every
layout here reads 0 on it anyway.

`lowContrast` could only be made to gate by **fixing the reference**: its contents page set
the six row numbers in `--accent` / `--s2` / `--s3` as text on white, and `--s2` measures
2.14 : 1. They are now `--ka` / `--k2` / `--k3`, which is what `design-system.md` always
said to use.

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` · structure
`stage fit deck slide band card tile badge` · marks `dot tick soft dim pagenum`.

Sizes live in those classes. If something needs to be bigger, use the next class up — do
not write a `font-size`.
