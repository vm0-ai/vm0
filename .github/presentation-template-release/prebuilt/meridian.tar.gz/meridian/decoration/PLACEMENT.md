# meridian — where the decoration goes

Everything here was measured from the original reference deck at 1600×900, 15 pages.
Where a number is quoted, it is that measurement. Where bloom's answer was different,
that is said, because bloom is the worked example in the playbook and its decoration
rules **do not transfer to this template**.

## Meridian is a chrome template, not an ornament template

This is the single most important fact about decorating a meridian deck, and it is the
opposite of bloom.

| measured on the reference | meridian | bloom |
|---|---|---|
| large ornaments per page | **0.13** (2 in 15 pages) | 1.94 |
| pages carrying an ornament *pair* | **0 of 15** | 15 of 17 |
| ornaments hanging off the stage edge | **0 %** | 94 % (31 of 33) |
| persistent chrome elements per page | **3** (nav, rule, corner square) | 1 |

bloom's headline decoration rule — *two large ornaments per page, one of each shape,
bleeding off the edge* — is false here on all three counts. Meridian's identity is not
carried by ornaments floating in the composition. It is carried by a **fixed top band**
that repeats identically on every page, and by **flat rectangular colour fields** that are
flush with the stage edges rather than bleeding past them.

If you are porting habits from bloom: stop. Put the chrome on every page, keep the
ornaments sparse and square, and do not invent a pair.

## The chrome band — on all 15 of 15 pages

Three elements, always, unchanged from page to page. They are the template's most visible
identity and the first thing a generated deck drops.

```
nav          left:5cqw   top:3.8cqh    breadcrumb, 4 items separated by "/"
rule         left:5cqw right:5cqw  top:8.2cqh   height:.16cqh, opacity .28
corner square right:5cqw  top:3.4cqh    1.9cqw × 1.9cqw, solid
pagenum      right:3cqw  bottom:3.2cqh  "page 01"
```

Measured extent: the nav's baseline box ends at 6.47 % of stage height, the corner square
at 6.78 %, the rule at **8.36 %**. That is the band.

**Content starts at 16 cqh** — the `.fit` padding in `../layouts/`. The nearest the
reference ever brings content to the band is 16.37 %. Nothing in `.fit` may begin above
**11 %**; measured on the reference, content violations = 0 (all 60 raw `aboveChromeBand`
hits are the chrome itself, which is what the band is for).

On a full-bleed page the chrome switches to the ground's paired text token — `--t0` on a
`--g0` page — never to `--ink`, which vanishes.

## The ornament vocabulary — seven items, and only these

Meridian's shape language is **the square and the straight line**. There is not one
circle in the reference's decoration except the process node.

| name | marker | count | what it is |
|---|---|---|---|
| `rule` | `data-bigcircle` | 15 | the hairline under the nav. One per page. |
| `field` | `data-bigcircle` | 2 | a flat rectangular colour field, flush to an edge |
| `doodle` | `data-doodle` | 22 | a **sharp-cornered square**, solid fill, no radius |
| `badge` | `data-badge` | 3 | a square numbered chip, `--r-md` corner |
| `node` | `data-node` | 4 | a round tile — process pages only |
| `connector` | `data-connector` | 1 | a hairline joining nodes |
| `photocell` | `data-photocell` | 11 | an image placeholder on `--ph` |

**Do not invent circles, arches, quarter-circles, blobs, pills or gradients.** The
`.qcircle` / `.semi` / `.dot` helpers exist in the shared shell; meridian's reference uses
none of them except the round process node.

### The square is the motif

22 of the reference's 27 non-chrome ornaments are squares. They appear at exactly three
sizes and three roles:

- **1.9cqw at `right:5cqw; top:3.4cqh`** — the corner marker, on every page, part of the
  chrome.
- **10cqw and 4cqw on a section divider** — a large square at `right:10cqw;top:24cqh`
  (opacity .9) and a small one at `right:7cqw;bottom:20cqh` (opacity .5), both in
  `currentColor` on the full-bleed ground. This pair is the divider's whole decoration.
- **5cqw on the closing page** — one accent square at `right:7cqw;top:18cqh`.

All of them sit in the **right margin**, clear of the text, and all of them are fully
inside the stage. Nothing bleeds.

### The colour field is flush, not bleeding

The two large fields in the reference:

- a **right rail**, `right:0; top:0; width:7cqw; height:100cqh` — full stage height,
  flush to the right edge
- a **bottom band**, `left:0; bottom:0; width:100cqw; height:5cqh` — full stage width,
  flush to the bottom

Both are `z-index:1`, behind `.fit` (z-index 40). Mark a right rail with
`data-field="rail"`; the reference reserves room for it with
`.stage:has([data-field="rail"]) .fit{padding-right:7cqw}`. Do not select the generic
`data-bigcircle` marker — it also marks the hairline rule on every page and would shrink
the whole deck. The layouts in `../layouts/` do not carry a rail; if you add one, add the
marker and padding to that page only.

The cover's stat rail is the one field that carries content. In `../layouts/cover.html` it
cancels the safe-area padding with a negative margin so it runs the full height of the
stage, which is what the reference does.

## One page in four is a colour field

Measured: **4 of 15** full-bleed pages (27 %) — the three section dividers and the close.
`stat-highlight` is offered as a fifth candidate.

Unlike bloom, **meridian does put boxes on a full-bleed page**: the reference does it 5
times. A contact chip on the closing page and a numbered badge on a divider are both in
vocabulary. What is *not* in vocabulary is a `--surface` card there — see below.

## Colour traps, measured on this template's own tokens

Against `slate_corporate`'s `--bg` `#FFFFFF`:

| token | value | contrast on the page | use as |
|---|---|---|---|
| `--ink` / `--s3` / `--k1..--k3` | `#16243B` | 15.56 : 1 | pass | text or fill |
| `--accent` / `--ka` / `--g0` | `#2F5BD0` | 5.95 : 1 | pass | text or fill |
| `--soft` | `#5A6678` | 5.82 : 1 | pass | text or fill |
| `--s1` | `#6E8BB8` | 3.47 : 1 | marginal — fill, or a label at `.h3` and up |
| `--s2` | `#F0A03A` | **2.14 : 1** | **fill only** |
| `--surface` | `#F6F8FB` | 1.06 : 1 | a near-white field, not text |
| `--ph` | `#E9EDF3` | 1.17 : 1 | image placeholder only |

All four grounds carry `#FFFFFF` text safely: `--g0` 5.95, `--g1` 4.61, `--g2` 4.64,
`--g3` 15.56. Use the paired `--t0..--t3`, never a scheme colour, on a ground.

Note `--s3` equals `--ink` in `slate_corporate` but **not in every token** — that is
exactly why the rule is "use `--k1..--k3` for text", not "`--s3` looked fine here".

The reference deck broke this rule itself: its contents page set the row numbers in
`--accent`, `--s2` and `--s3` as *text* on white, and `--s2` measured 2.14 : 1. Those six
sites are now `--ka` / `--k2` / `--k3`, which is what `design-system.md` has always said to
use. After the fix the reference reads `lowContrast 0`, so the rule can gate.

`--surface` is `#F6F8FB` on a `#FFFFFF` page. The reference uses it **once** in 15 pages.
Do not reach for it as a panel colour; meridian's panels are `--g0..--g3` grounds, an
outline in `currentColor 26 %`, or no fill at all with a hairline rule.

## What is not stated, dies

The playbook's hardest-won finding: an ornament class with no stated frequency and no
stated attachment falls to near zero in generated decks. So, explicitly:

- the **corner square** goes on every page, as part of the chrome — 15 of 15
- the **rule** goes on every page — 15 of 15
- the **divider square pair** goes on every section divider — 3 of 3
- the **badge / node / tile** are not sprinkled. They belong to a *set of peer items*, and
  when they are used **every item in the set gets one**. Copyable markup is in
  [item-sets.html](item-sets.html), not described in a sentence.

## Do not bottom-anchor content to fill space

Meridian's lower third is not a decoration zone the way bloom's is — its ornaments live in
the right margin. But the closing page and the dividers do put large type low, and the
`pagenum` sits at `bottom:3.2cqh`. Leave the bottom 8 cqh alone; that is the `.fit`
padding, and a trailing line pushed into it with `margin-top:auto` collides with the page
number.
