# Meridian

## Visual identity

Clear, structured, and strongly modular. A persistent flat top bar, fine rules, sharp-cornered tickers, oversized indices, and a two-colour primary/supporting structure create the character of a professional data organisation.

## Color system tokens

Read the prompt's `color-system` before generating. If it supplies one of the valid tokens below, use that token exactly. If it does not, choose from the tokens below according to the content, audience, mood, information density, and readability. Use only one token throughout a deck.

The presentation category documented for this template is **M (single-primary)**, with `slate_corporate` as its example token. Determine the generated deck's token using the rule above.

Use only the following snake_case values as valid tokens:

- Single-primary M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`slate_corporate`, `midnight_mono`, `nordic_frost`, `mono_ink`, `ocean_deep`

The default color system used in `example/reference.jpg` is `slate_corporate`.
Picking a token outside this list is how a deck ends up looking like a different
template: a finance source, for instance, pulls every template toward the same
muted corporate grey unless the list stops it.


After selecting a token, read `color-systems/<token>.css`, inline that file's single CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="slate_corporate">
```

- Use `--bg`, `--surface`, `--ink`, `--soft`, and `--ph` for the page, surfaces, body copy, secondary text, and image placeholders.
- `--accent`, `--s1`, `--s2`, and `--s3` are raw hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected for those raw hues in v1; use them for large icons or decorative symbols. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use the contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text. Use `--kad` for accent text on an `--ink` field. When a raw hue needs higher text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour fields containing text, use `--g0` through `--g3` and pair each with the matching `--t0` through `--t3`.
- HTML/CSS components must reference colours only through `var(--...)`; derive transparency, strokes, shadows, and gradients from defined tokens as well.

Use `--bg` as the primary page field. `--surface` is a near-white field that the
reference uses once in 15 pages, so it is not a generic panel colour. Use `--accent` for
the main conclusion, `--s2` for supporting cues, and `--s3` for structure and dark
sections.

```css
.slide { background: var(--bg); color: var(--ink); }
.surface { background: var(--surface); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Sora` as the display typeface and `Inter` as the body typeface.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Sora";
  --fb: "Inter";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600; available body weights are 300 / 400 / 500 / 600. Use `--fd` for titles, hero numbers, and section numbers; use `--fb` for body copy, labels, chart annotations, and tables. For CJK content, preserve the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the template's own base stylesheet, used by `layouts/`.
Copy it verbatim into the single `<style>` block, immediately after the inlined
colour-system CSS, before writing any slide. It defines the 16:9 stage, the type
scale, and the chrome and decoration classes the rest of this document refers
to. A deck that invents its own class names instead of using these will not look
like this template.

```css
:root{
  --r-xs: .5cqw;
  --r-sm: .9cqw;
  --r-md: 1.7cqw;
  --r-lg: 3cqw;
  --r-xl: 5cqw;
--fd: "Sora";
  --fb: "Inter";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;object-fit:cover!important;}[data-photocell][data-image-fit="contain"] img,.photo[data-image-fit="contain"]{object-fit:contain!important;}
  

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:45;}

.tile{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.tile>span{font-size:40cqw;line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.badge>span{font-size:40cqw;line-height:1;}
.tick{position:absolute;}
.card{background:var(--surface);border-radius:var(--r-md);}
.dot{border-radius:50%;}.qcircle{border-radius:50% 0 0 0;}.semi{border-radius:999px 999px 0 0;}.tri{width:0;height:0;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}
```
The number inside a `badge` and any text inside a `tile` must be wrapped in a
`<span>`. The wrapper is what makes the text scale with the box: it is measured
against the badge's own width, so the figure stays in proportion at any size.
Text placed directly in the box only follows `--sz`, and a deck that sizes the
box with `width`/`height` instead will render a small number in a large frame.
Size these with `--sz`, not `width`/`height`.


## Signature elements

Available signature elements: `flat-topnav`, `hairline-rule`, `sharp-square-ticker`, `sharp-block`, `stat-matrix`, `two-tone-bar-chart`.


Visual reference: [example/reference.jpg](example/reference.jpg)

## Motif library

Every motif below is copied out of this template's own reference deck. This is
the geometry that makes the template recognisable, and it is the part that goes
missing when a deck is authored from the prose alone — the shapes exist nowhere
else; it is reproduced here so generation never needs a full-deck HTML example.

**Copy these snippets. Do not paraphrase them, redraw them, or substitute a
shape that is easier to write.** Change only size, position, colour token, and
text content. The count beside each motif is how many times the reference deck
uses it across fifteen slides. It records prevalence; it is not a floor, quota,
or target to scale mechanically. Use a motif only where the closest reference
page role uses it and the composition benefits.


### `badge` — used 3× in the reference deck

```html
<div class="badge" data-badge="1" style="--sz:3.2em;background:var(--g0);color:var(--t0)"><span>01</span></div>
```

### `bigcircle` — used 17× in the reference deck

```html
<div data-bigcircle="1" style="position:absolute;left:5cqw;right:5cqw;top:8.2cqh;height:.16cqh;background:var(--ink);opacity:.28;z-index:5"></div>
```

### `doodle` — used 22× in the reference deck

```html
<div data-doodle="1" style="position:absolute;right:5cqw;top:3.4cqh;width:1.9cqw;height:1.9cqw;background:var(--ink);z-index:7"></div>
```

### `slot` — used 15× in the reference deck

This motif is too long to inline without cutting it mid-tag, so it is not
reproduced here. Find it in [layouts/](layouts/) by
searching for the opening tag below, and copy the whole element from there.

```html
<div class="stage" data-slot="cover" style="">
```


### CSS signatures

These declarations are part of the template's look. The counts are from the reference deck.

| property | values it actually uses | why it matters |
| --- | --- | --- |
| `border-radius` | `50% 0 0 0` ×1<br>`999px 999px 0 0` ×1<br>`999px` ×1 | arches, capsules and part-round corners |


### Not captured above

These named signature elements have no extractable snippet in this library: `flat-topnav`, `hairline-rule`, `sharp-square-ticker`, `sharp-block`, `stat-matrix`, `two-tone-bar-chart`. Read [layouts/](layouts/) for them and copy the markup from the slide that uses them; do not improvise a substitute.

## Decoration reference profile (diagnostic only)

Observed from this template's own reference deck, per slide, rendered at
1600×900. These averages combine unlike page roles: covers, section dividers,
dense content pages, comparisons, and closings.

**These figures are diagnostics, never quotas or per-slide instructions.**
First choose the closest page role in [layouts/](layouts/),
then use only the named signature elements and motifs demonstrated in that
composition. A utility class, empty colour field, outlined box, circle, pill,
arc, quarter-circle, or other shell geometry is not a motif by itself.

| per slide | decoration | size |
| --- | --- | --- |
| **0.3** | solid colour field | 20cqw and wider |
| **0.3** | solid colour field | 7.5–20cqw |
| **0.3** | solid colour field | 2.5–7.5cqw |
| **0.3** | circle or pill | 2.5–7.5cqw |
| **0.3** | drawn shape | 2.5–7.5cqw |
| **1.0** | solid colour field | 0.8–2.5cqw |
| **0.3** | drawn shape | 0.8–2.5cqw |


Read the figures only as a whole-deck drift signal. Around half the reference
rate can be appropriate when the material or page-role mix differs. Judge
fidelity by motif identity, placement, and composition rather than item count.
Sparse slides are intentionally sparse.

The reference deck also fills **0.5 image placeholders per slide**. That is not a target: this template forbids inventing a photograph the source material does not support, so a deck built from a text-only source is right to draw fewer — and image placeholders are excluded from the counts above for the same reason.

The table counts only decoration with no text inside it. This template also paints **0.6 labelled boxes per slide** — nav cells, numbered badges, buttons, tags: a painted or bordered box with a word or two in it. They are counted separately, and this template barely uses them: 0.6 per slide is the whole budget. A deck that turns every label into a bordered chip is not this template — that is a different, busier design, and it is the most common way these decks drift away from their reference.

**A kicker is not a chip.** In this template's reference deck the `kicker`, the
page number, the running head and the standfirst are plain text — no background,
no border, no shadow, no rounded pill around them. Every one of the 23 reference
decks agrees on this, and giving them a box is the single most common way a
generated deck drifts: a kicker appears on every slide, so boxing it adds one
false chip per slide and doubles this template's labelled-box count on its own.

Only the elements the motif library actually draws as chips — `badge`, `tag`,
`pill`, and whatever else this file shows with a fill — carry a background.
Everything else that is text stays text.

**Before delivering, audit identity.** On three
representative slides, verify that every ornament maps to a named signature
element or to a specific composition in the reference. Use the table above only to notice gross whole-deck drift.

Content still comes first. Never push text off the stage, cover it, or drop a point. Never add a photograph
the source material does not support. A slide carrying six bullets may correctly
carry no optional ornament at all.


## Decoration safe area

Decoration is placed before content, but it never fights the content.

- Every slide has a **text safe area**: the region actually occupied by the
  title, body copy, figures, and labels. No decoration may sit on top of it.
- Decoration belongs in one of three places: outside the safe area entirely
  (edges, corners, the empty half of the stage); behind it at `z-index:0`–`1`
  **and** at a contrast low enough that the text stays fully legible; or
  deliberately overlapping a photograph or colour field where the reference
  shows exactly that.
- Meridian has no free-floating large ornament. Its optional squares stay fully inside
  the right margin, and its two large rectangular fields sit flush with a stage edge;
  measured ornament bleed in the reference is 0%. Do not crop or bleed a Bloom-style
  pair into this template.

## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** A label positioned with `left:88cqw` will
overflow the moment its text is longer than the author guessed, and CJK copy is
routinely wider than the Latin draft it was written against. Anchor anything in
the right third with `right:` instead of `left:`, and anything in the bottom
third with `bottom:` instead of `top:`. A block anchored to the edge it is near
grows inward, where there is room, instead of outward into nothing. Give any
absolutely-positioned text an explicit `max-width` so it wraps rather than
extends.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a Flex row or column so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

**Bounded Flex groups keep bounded children.** Put `min-height:0` on a Flex child
that holds an SVG, percentage-height bar, or media region. A visibly filled peer
row is `flex:none` and its children are `flex:1`, so they equalise to the tallest
copy rather than stretching to the stage. Reserve filling `flex:1` for an image
frame or chart plot area. Shorten or split content that still does not fit at
reference scale; never hide it with stage clipping.

A finished slide keeps repeated items on one structural alignment and keeps
content clear of every unintended stage edge.

## Never do this

- **Never use a disc-bulleted list.** Not one of the twenty-three V3 reference
  decks contains a single `<ul>` with default bullets, and a bulleted list is the
  fastest way to make a designed template look like a plain document. Structure a
  list as numbered rows with a hairline rule between them, as key–value rows, as
  a row of cards, or with the template's own motifs — whatever the reference deck
  does for the same job.
- Never invent a colour outside the inlined colour-system tokens; every colour
  goes through `var(--...)`.
- Never leave a slide without the chrome named in `Required chrome`.
- Never let an ornament sit on top of a title or a paragraph.
- Never generate a photograph the supplied material does not call for.

## Required chrome

Chrome is the cheapest part of a template's identity and the most frequently
dropped: across the benchmark's baseline decks, four of six templates carried a
footer on 0-2 slides out of 17. This template's reference deck carries the
following, and the count is measured from that deck, not assumed.


### Repeats on every slide

The reference deck also repeats these edge-pinned elements on nearly every slide. Their opening tags are given as locators — find each one in [layouts/](layouts/) and carry it through your deck the same way.

```html
<div data-doodle="1" style="position:absolute;right:5cqw;top:3.4cqh;width:1.9cqw;height:1.9cqw;background:var(--ink);z-index:7">
```
<sub>the `--ink` version is on 11 of 15 reference slides; the other four full-bleed
slides use the ground's paired `--t?` token. The corner square itself is on 15 of 15.</sub>
**Persistent navigation bar** — present on 15 of the reference deck's 15 slides, unchanged from slide to slide. It is the template's most visible piece of identity and the first thing a generated deck drops.

```html
<div data-device="nav" style="position:absolute;left:5cqw;top:3.8cqh;display:flex;align-items:center;gap:1.5cqw;z-index:7"><span style="font-family:var(--fb);font-weight:500;font-size:1.25cqw;letter-spacing:.02em;color:var(--ink);opacity:.9">Home</span><span style="color:var(--ink);opacity:.35;font-size:1.1cqw">/</span><span style="font-family:var(--fb);font-weight:500;font-size:1.25cqw;letter-spacing:.02em;color:var(--ink);opacity:.9">Discover</span><span style="color:var(--ink);opacity:.35;font-size:1.1cqw">/</span><span style="font-family:var(--fb);font-weight:500;font-size:1.25cqw;letter-spacing:.02em;color:var(--ink);opacity:.9">Services</span><span style="color:var(--ink);opacity:.35;font-size:1.1cqw">/</span><span style="font-family:var(--fb);font-weight:500;font-size:1.25cqw;letter-spacing:.02em;color:var(--ink);opacity:.9">About</span></div>
```


**Page number** — on 15 of 15 slides:

```html
<div class="pagenum">page 01</div>
```

Carry page number on **every** slide, including the cover and the closing slide.
