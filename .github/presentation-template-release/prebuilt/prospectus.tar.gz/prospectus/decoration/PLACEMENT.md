# prospectus — decoration placement

Everything here is measured from the original reference deck (15 pages), rendered at
1600×900. Numbers, not taste. Open `decoration.html` to see the one optional decoration
rendered separately from content devices and chrome.

**Do not carry bloom's numbers across.** They were measured on a different deck and every
one of them is wrong here. The two templates disagree on the central rule:

| | bloom | prospectus |
|---|---|---|
| ornaments per page | 1.94 | **1.00** |
| pages carrying a *pair* | 82 % | **0 %** |
| ornaments crossing the stage edge | 94 % | **0 %** |

## The layer model

| z-index | layer | where it comes from |
|---|---|---|
| 5 | decoration — the doodle | this folder |
| 40 | `.fit` — all text | `../layouts/*.html` |
| 45 | pagenum | the shell |
| 60 | persistent chrome — the navbar | fixed, see A below |

Decoration sits **below** text and is never inside `.fit`. If a layout and an ornament
collide, move the ornament — never the copy.

## A · Persistent chrome — on every slide without exception

Two items. The navbar is on **15 of 15** reference slides and the page number on **15 of
15**. Copy both onto every slide, including the cover and the closing page.

```html
<div data-chrome="nav" style="position:absolute;left:0;top:0;width:100%;height:8.4cqh;background:var(--ink);display:flex;align-items:center;padding:0 5cqw;z-index:60">
  <span class="kicker" style="font-size:1.45cqw;letter-spacing:.01em;text-transform:none;font-weight:600;color:var(--bg)">Your Company</span>
  <div data-device="nav" style="flex:1;display:flex;align-items:center;justify-content:center;gap:2.6cqw"><span class="kicker" style="font-size:1.15cqw;letter-spacing:.04em;text-transform:none;color:var(--bg);opacity:.92">Home</span><span class="kicker" style="font-size:1.15cqw;letter-spacing:.04em;text-transform:none;color:var(--bg);opacity:.92">About</span><span class="kicker" style="font-size:1.15cqw;letter-spacing:.04em;text-transform:none;color:var(--bg);opacity:.92">Contact</span></div>
  <div data-device="cta" style="display:flex;align-items:center"><span class="kicker" style="font-size:1.15cqw;letter-spacing:.04em;text-transform:none;color:var(--bg)">More Info</span></div>
</div>
<div class="pagenum">07</div>
```

On a full-bleed page the band **inverts**: `background:var(--t0)` with its type in
`var(--g0)`. It never disappears and never becomes transparent.

The navbar is a `--ink` band 8.4cqh tall whose text fills about two thirds of its height.
That is what a navbar is, and it is why `probes/run.sh` reports `boxesUnderfilledV 15` on
this reference — one per slide, all of them the band. **That reading is the chrome, not a
defect.** Every naked layout in `../layouts/` reads 0 because none of them carries chrome.

## B · The doodle — exactly one per page

This is the rule. It is not an average of a spread; the distribution is degenerate.

**15 of 15 reference pages carry exactly one doodle. None carries zero. None carries two.**

```html
<div data-doodle="1" data-decoration="doodle" style="position:absolute;right:6cqw;top:16cqh;width:6cqw;height:6cqw;z-index:5">
  <svg viewBox="0 0 100 100" style="width:100%;height:100%;display:block;overflow:visible">
    <line x1="18" y1="18" x2="82" y2="82" stroke="var(--ink)" stroke-width="5" stroke-linecap="round"/>
    <polyline points="82 50, 82 82, 50 82" fill="none" stroke="var(--ink)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
  </svg></div>
```

Copy it. Do not redraw it, do not substitute an arrow glyph, and do not rotate it.

**Size** — three values, nothing between them: `5cqw` ×2, `6cqw` ×8, `8cqw` ×5. Use 6cqw
on a content page, 8cqw on a cover, divider or closing page, 5cqw when the page is busy.

**Colour** — the stroke is the page's own text colour: `var(--ink)` on `--bg`,
`var(--t0)` on a `--g0` field, `var(--bg)` on an `--ink` field.

**Anchor** — always use the two edge coordinates of a corner, never the top-left, which
is where the wordmark sits:

| anchor | count |
|---|---|
| `right:` + `top:` | 9 / 15 |
| `right:` + `bottom:` | 4 / 15 |
| `left:` + `bottom:` | 2 / 15 |

So the right-hand side takes 13 of 15. Anchor to the edge it is near — `right:` not
`left:`, `bottom:` not `top:` — so that it grows inward if anything about it changes.

## C · It does **not** bleed — and `design-system.md` used to say the opposite

`design-system.md` carried this line:

> A large ornament must be cropped by the stage edge rather than floated in the middle of
> the composition, unless it carries content itself.

**Measured: 0 of 15 reference doodles cross the stage edge. All 15 sit fully inside it.**

The sentence is inherited boilerplate from a template whose ornaments are 20–30cqw blobs.
Prospectus's ornament is a 5–8cqw line drawing, and a line drawing cropped in half is not
a crop, it is a mistake. The rule as written told a generated deck to do the one thing the
reference never does, so it has been corrected in `design-system.md` rather than left to
contradict the deck it describes.

What is true instead: the doodle sits inside the stage, near a corner and clear of the
actual content footprint. It may touch the nominal 6% text inset; that constant is a gate
for text, not for decoration. `decoration.html` draws the inset as a dashed rectangle so
the distinction is visible.

## D · Optional decoration vocabulary — one item, nothing else

| name | marker | what it is | reference count |
|---|---|---|---|
| doodle | `data-doodle` `data-decoration="doodle"` | the textless diagonal elbow arrow, `line` + `polyline` | 15 |

This is the complete optional decoration vocabulary. **Do not invent loose circles,
arches, colour blocks, triangles or outlined boxes.** None appears as decoration in the
reference.

Classify before counting: the navbar and page number are chrome; `badge`, `tile`, the
eyebrow rule and CTA carry text or a content role; `photocell` is media; chart marks carry
data. Cards, squares, coloured panels, content containers and grid cells are layout.
They may be recognisable Prospectus devices, but they are not optional decoration and
must not enter ornament counts or the decoration preview.

## E · Optional item-set decoration — none

The reference has no textless motif attached to each member of a repeated item set, so
this folder deliberately has no `item-sets.html`. Ordered stages use numbered content
badges; capabilities use icon-bearing tiles; people and evidence use media frames. Those
elements belong to the corresponding naked layout and are not sprinkled onto another
layout as decoration.

Peer paragraphs use a hairline and filled cards use their own ground. Neither receives an
extra ornament.

## F · Photography

`photocell` is the frame itself. When the source material supports no image, **delete the
frame** — do not leave an empty `--ph` box and do not fill the hole with a grid of rounded
rectangles. The reference fills 0.73 frames per slide; a text-only source is right to draw
none.

## G · Colour, measured against this template's own page

`slate_corporate`, the token the reference was rendered with. Contrast against the
`#FFFFFF` page:

| token | on `--bg` | use as |
|---|---|---|
| `--ink` `--s3` `--g3` 15.56 · `--accent` `--ka` 5.95 · `--g2` 4.64 · `--g1` 4.61 · `--soft` 5.82 · `--s1` 3.47 | pass | text or fill |
| **`--s2` 2.14** | fail | **fill only** |

Only one token in this palette is fill-only, and the reference broke that rule once: its
agenda page numbered an item in `--s2` at 2.14:1. That has been changed to `--g2`, the
same hue's dark sibling, at 4.64:1. **Check this before colouring a small label.**

On a `--g0` field the arithmetic inverts and it is much less forgiving:

| token on `--g0` | ratio |
|---|---|
| `--t0` | 5.95 |
| `--ink` / `--s3` / `--g3` | 2.61 |
| **`--accent` / `--ka`** | **1.00 — invisible** |

So on a full-bleed page every piece of type is `var(--t0)` or `color:inherit`. A kicker in
`--ka` on a `--g0` field is the accent colour painted on itself and disappears completely.

**`--surface` is `#F6F8FB` on a `#FFFFFF` page — 1.06:1.** A `.card` panel is very nearly
invisible. The reference uses it once, on its features page. It is not forbidden, because
the reference does use it, but it is not the treatment that reads: prefer a `--g0..--g3`
ground with the matching `--t?`, or no fill and a hairline. `../layouts/feature-cards.html`
is the filled version; `three-column.html` is the ruled one.

## H · Colour fields

**6 of 15 reference pages are full-bleed** — 40 %, appreciably more than bloom's 29 %.
Every section divider, the cover, the closing page, and one content page. Put the ground
colour on `.stage` itself, not on a box inside it.

Nothing sits on a full-bleed page. Measured: the reference puts **zero** filled boxes on
its six full-bleed pages, chrome excluded. A white card on the blue field is a hole and a
black one is a blot.

## I · Two alignment rules that gate

Both read **0** on this reference, so both can block rather than advise.

- **Nothing starts above 11 % of the stage height.** The navbar occupies 0–8.4cqh and
  `.fit` starts its content at 13cqh. Reference: 0 pieces of content text above the line,
  chrome excluded.
- **Nothing starts left of 6 % or ends right of 94 %.** The safe area is a template
  constant, set once by the padding on `.fit`, and measured here: 60 of 131 text runs
  begin at exactly 6.0 %, the minimum is 6.0 %, the maximum right edge is 91.9 %. A page
  that sets less padding has not widened its safe area, it has broken it.

## J · When to place nothing

Never — not for the doodle. Zero of 15 reference pages go without it, which is the one
place this template is stricter than bloom. Everything else in section D is optional and
belongs only where its content shape appears.
