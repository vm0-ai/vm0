# Prospectus

## Visual identity

A fusion of corporate landing page and presentation: persistent full-width navigation, saturated colour fields, oversized light-weight titles, diagonal arrows, and frameless data graphics.

## Color system tokens

Read the prompt's `color-system` before generating. If it provides one of the valid tokens below, use that token exactly. If it does not, the Agent selects a token based on the content, audience, mood, information density, and readability. Use only one token per deck.

The demonstration category documented for this template is **M (single dominant colour)** and its example token is `slate_corporate`; select the generation token using the rule above.

Use only these exact snake_case token values:

- Single dominant colour M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`slate_corporate`, `nordic_frost`, `ocean_deep`, `midnight_mono`, `mono_ink`

The default color system used in `example/reference.jpg` is `slate_corporate`.
Picking a token outside this list is how a deck ends up looking like a different
template: a finance source, for instance, pulls every template toward the same
muted corporate grey unless the list stops it.


After choosing a token, read `color-systems/<token>.css`, inline its single CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="slate_corporate">
```

- Use `--bg`, `--surface`, `--ink`, `--soft`, and `--ph` for the page, surfaces, body text, secondary text, and image placeholders.
- `--accent`, `--s1`, `--s2`, and `--s3` are the source hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected by v1 for those source hues; use them for large icons or decorative symbols. Use the contrast-safe text tokens below for normal text.
- For text on the standard `--bg`, use the contrast-safe `--ka`, `--k1`, `--k2`, and `--k3`. Use `--kad` for accent text on an `--ink` field. When a source hue needs stronger text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour fields containing text, use `--g0` through `--g3` and pair each with the matching `--t0` through `--t3`.
- HTML/CSS components reference only `var(--...)`; derive translucent layers, outlines, shadows, and gradients from defined tokens as well.

Alternate narrative slides on `--bg` with showcase slides on `--g0`. Use the primary colour field for covers, chapters, closing slides, and hero data; use `--k3` for navigation and title text, and `--s3` for axes and blocks.

```css
.slide { background: var(--bg); color: var(--ink); }
.surface { background: var(--surface); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Archivo` for display type and `Manrope` for body type.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600&family=Manrope:wght@300;400;500;600&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Archivo";
  --fb: "Manrope";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600; available body weights are 300 / 400 / 500 / 600. Use `--fd` for titles, hero numbers, and chapter numbers; use `--fb` for body text, labels, chart annotations, and tables. CJK text preserves the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the template's own base stylesheet, used by `layouts/`.
Copy it verbatim into the single `<style>` block, immediately after the inlined
colour-system CSS, before writing any slide. It defines the 16:9 stage, the type
scale, and the chrome and decoration classes the rest of this document refers
to. A deck that invents its own class names instead of using these will not look
like this template.

```css
:root{
  --r-xs: .5cqw;
  --r-sm: .9cqw;
  --r-md: 1.7cqw;
  --r-lg: 3cqw;
  --r-xl: 5cqw;
--fd: "Archivo";
  --fb: "Manrope";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);overflow-wrap:break-word;word-break:normal;}
.stage *{overflow-wrap:break-word !important;word-break:normal !important;}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}
  

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:45;}

.tile{width:var(--sz,2.6em);height:var(--sz,2.6em);font-size:1.95cqw;container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;}
.tile>span{font-size:40cqw;line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{width:var(--sz,2.6em);height:var(--sz,2.6em);font-size:1.95cqw;container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;}
.badge>span{font-size:40cqw;line-height:1;}
.tick{position:absolute;}
.card{background:var(--surface);border-radius:var(--r-md);}
.dot{border-radius:50%;}.qcircle{border-radius:50% 0 0 0;}.semi{border-radius:999px 999px 0 0;}.tri{width:0;height:0;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}
```
The number inside a `badge` and any text inside a `tile` must be wrapped in a
`<span>`. The wrapper is what makes the text scale with the box: it is measured
against the badge's own width, so the figure stays in proportion at any size.
Text placed directly in the box only follows `--sz`, and a deck that sizes the
box with `width`/`height` instead will render a small number in a large frame.
Size these with `--sz`, not `width`/`height`. `--sz` defaults to `2.6em` against the
class's own `1.95cqw`, which renders at the reference's 5cqw — expressed so it follows
the type rather than freezing to one measured string.


## Signature elements

Available signature elements: `persistent-navbar`, `diagonal-arrow`, `explore-cta`, `oversized-thin-title`, `halffill-bars`, `gantt-timeline`.


For templates with branded chrome, preserve the example's scale, margins, and repeated positions, then replace the placeholder name with the actual brand asset.

Visual reference: [example/reference.jpg](example/reference.jpg)

## Motif library

Every motif below is copied out of this template's own reference deck. This is
the geometry that makes the template recognisable, and it is the part that goes
missing when a deck is authored from the prose alone — the shapes exist nowhere
else; it is reproduced here so generation never needs a full-deck HTML example.

**Copy these snippets. Do not paraphrase them, redraw them, or substitute a
shape that is easier to write.** Change only size, position, colour token, and
text content. The count beside each motif is how many times the reference deck
uses it across fifteen slides. It records prevalence; it is not a floor, quota,
or target to scale mechanically. Use a motif only where the closest reference
page role uses it and the composition benefits.

Classify these before counting them. The `doodle` is the only optional decoration.
`badge` and `tile` carry content, while `slot` is layout structure; the persistent
navbar and page number are chrome. Cards, squares, colour fields, media frames, chart
marks, nodes, connectors and grid cells never enter optional decoration counts.


### `badge` — content device, used 3× in the reference deck

```html
<div class="badge" data-badge="1" style="--sz:2.6em;background:var(--g0);color:var(--t0)"><span>01</span></div>
```

### `doodle` — the only optional decoration, used 15× in the reference deck

```html
<div data-doodle="1" data-decoration="doodle" style="position:absolute;right:9cqw;bottom:24cqh;width:8cqw;height:8cqw;z-index:5">
    <svg viewBox="0 0 100 100" style="width:100%;height:100%;display:block;overflow:visible">
      <line x1="18" y1="18" x2="82" y2="82" stroke="var(--t0)" stroke-width="5" stroke-linecap="round"/>
      <polyline points="82 50, 82 82, 50 82" fill="none" stroke="var(--t0)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg></div>
```

### `slot` — layout structure, used 15× in the reference deck

This motif is too long to inline without cutting it mid-tag, so it is not
reproduced here. Find it in [layouts/](layouts/) by
searching for the opening tag below, and copy the whole element from there.

```html
<div class="stage" data-slot="cover" style="background:var(--g0);color:var(--t0)">
```

### `tile` — content device, used 4× in the reference deck

```html
<div class="tile" data-tile="1" style="--sz:2.6em;flex:none;background:var(--g0);color:var(--t0)"><svg viewBox="0 0 24 24" style="width:52%;height:52%;stroke:currentColor;fill:none;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round"><polygon points="12 3 3 8 12 13 21 8 12 3"/><polyline points="3 14 12 19 21 14"/></svg></div>
```


### CSS signatures

These declarations are part of the template's look. The counts are from the reference deck.

| property | values it actually uses | why it matters |
| --- | --- | --- |
| `border-radius` | `999px` ×5<br>`50% 0 0 0` ×1<br>`999px 999px 0 0` ×1 | arches, capsules and part-round corners |


### Not captured above

These named signature elements have no extractable snippet in this library: `persistent-navbar`, `explore-cta`, `oversized-thin-title`, `halffill-bars`, `gantt-timeline`. Read [layouts/](layouts/) for them and copy the markup from the slide that uses them; do not improvise a substitute. The `diagonal-arrow` is the `doodle` documented above.

## Decoration reference profile (diagnostic only)

Measured at 1600×900 after classifying content, layout and chrome separately:

| metric | reference |
| --- | ---: |
| optional decoration classes | **1** (`doodle`) |
| doodles per page | **1.00** (15 on 15 pages) |
| pages with two optional ornaments | **0 / 15** |
| optional ornaments crossing the stage edge | **0 / 15** |
| optional item-set decorations | **0** |

This distribution is exact: every reference page carries one doodle. Copy its geometry;
do not substitute an arrow glyph, rotate it, crop it, or add a second ornament.

The persistent navbar and page number are chrome. Badges, icon tiles, cards, colour
fields, photo frames, chart marks, nodes, connectors and grid cells carry content, data
or layout. They are excluded from decoration counts even when they are colourful or
geometric. Prospectus has no `decoration/item-sets.html` because the reference has no
textless motif attached to repeated items.

Photographs remain content, never decoration. A text-only source is right to draw none.
A kicker is plain text, not a chip. Content still comes first: the doodle never covers
type or displaces a point.


## Decoration safe area

Decoration is placed before content, but it never fights the content.

- Every slide has a **text safe area**: the region actually occupied by the
  title, body copy, figures, and labels. No decoration may sit on top of it.
- Decoration belongs in one of three places: outside the safe area entirely
  (edges, corners, the empty half of the stage); behind it at `z-index:0`–`1`
  **and** at a contrast low enough that the text stays fully legible; or
  deliberately overlapping a photograph or colour field where the reference
  shows exactly that.
- This template's ornament is a small drawn mark (5-8cqw), not a large field. It sits
  fully **inside** the stage near a corner, clear of the actual content footprint. It may
  touch the nominal 6% text inset; that constant gates text, not decoration. Measured on
  `layouts/`: 0 of 15 doodles cross the stage edge, so do not crop it — a
  half-cropped line drawing reads as a mistake, not as a bleed. See
  `decoration/PLACEMENT.md` section C.

## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** A label positioned with `left:88cqw` will
overflow the moment its text is longer than the author guessed, and CJK copy is
routinely wider than the Latin draft it was written against. Anchor anything in
the right third with `right:` instead of `left:`, and anything in the bottom
third with `bottom:` instead of `top:`. A block anchored to the edge it is near
grows inward, where there is room, instead of outward into nothing. Give any
absolutely-positioned text an explicit `max-width` so it wraps rather than
extends.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a grid or a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

Both faults hide from a quick glance at the whole deck and are obvious on the
slide itself. Before delivering, look at every slide that carries a set of
things and check that the set is aligned and that nothing touches an edge it was
not meant to touch.

## Never do this

- **Never use a disc-bulleted list.** Not one of the twenty-three V3 reference
  decks contains a single `<ul>` with default bullets, and a bulleted list is the
  fastest way to make a designed template look like a plain document. Structure a
  list as numbered rows with a hairline rule between them, as key–value rows, as
  a row of cards, or with the template's own motifs — whatever the reference deck
  does for the same job.
- Never invent a colour outside the inlined colour-system tokens; every colour
  goes through `var(--...)`.
- Never leave a slide without the chrome named in `Required chrome`.
- Never let an ornament sit on top of a title or a paragraph.
- Never generate a photograph the supplied material does not call for.

## Required chrome

Chrome is the cheapest part of a template's identity and the most frequently
dropped: across the benchmark's baseline decks, four of six templates carried a
footer on 0-2 slides out of 17. This template's reference deck carries the
following, and the count is measured from that deck, not assumed.


### Repeats on every slide

The reference deck also repeats these edge-pinned elements on nearly every slide. Their opening tags are given as locators — find each one in [layouts/](layouts/) and carry it through your deck the same way.

```html
<div style="position:absolute;left:0;top:0;width:100%;height:8.4cqh;background:var(--ink);display:flex;align-items:center;padding:0 5cqw;z-index:7">
```
<sub>on 9 of 15 reference slides</sub>
**Persistent navigation bar** — present on 15 of the reference deck's 15 slides, unchanged from slide to slide. It is the template's most visible piece of identity and the first thing a generated deck drops.

```html
<div data-device="nav" style="flex:1;display:flex;align-items:center;justify-content:center;gap:2.6cqw"><span class="kicker" style="font-size:1.15cqw;letter-spacing:.04em;text-transform:none;color:var(--g0);opacity:.92">Home</span><span class="kicker" style="font-size:1.15cqw;letter-spacing:.04em;text-transform:none;color:var(--g0);opacity:.92">About</span><span class="kicker" style="font-size:1.15cqw;letter-spacing:.04em;text-transform:none;color:var(--g0);opacity:.92">Contact</span></div>
```


**Page number** — on 15 of 15 slides:

```html
<div class="pagenum">01</div>
```

Carry page number on **every** slide, including the cover and the closing slide.
