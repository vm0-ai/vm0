# prospectus — naked layouts

43 layouts. No decoration and no measured text geometry.
Pair one of these with `../decoration/PLACEMENT.md` to build a slide.

The number is an outcome, not a target: the original 26 compositions plus 17 review-led
additions that fill distinct communication jobs. The additions are not alternate skins
for existing pages: they cover sustained prose, executive takeaways, contained hero
media, two new chart grammars, roadmap and system mapping, decision evidence, and the
capital / risk / terms pages a prospectus repeatedly needs.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 43: zero non-exempt `width` / `max-width` / `min-width` / `height` / `left` /
`top` / `right` / `bottom` / `flex-basis` values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex` shorthand too — `flex:0 0 4cqw` freezes exactly the way a `width` does.

This matters because the removed full-deck HTML example was produced by measuring a rendered deck
and writing the numbers back. Its eyebrow rule was written four times at four different
widths — 28, 30, 32 and 34cqw — because that device was measured against four different
strings. `width:30cqw` is not a design decision; it is the observed width of the words
"Inside this plan". Copying it reproduces those words. These layouts carry none of that.

Four exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that is
  `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** for a hairline rule. A hairline is a hairline at any scale.
- **`em`** on a mark whose size should follow its type: `badge`, `tile`, the dial ring,
  the legend dot, the gantt bar's thickness. `em` scales with the type around it, so it
  cannot freeze a text box the way `cqw` can. `--sz: 2.6em` against the shell's `1.95cqw`
  renders at 5.07cqw — the reference's own 5cqw mark.
- **`%`** in chart marks (`chart-bar`, `chart-line`, `chart-waterfall`) and `gantt`, where
  the number *is* the datum.
  A bar whose height is 72 % is reporting 72, not making a layout choice.

No prose measure. An earlier revision carried `max-width:34em` on the lead paragraphs
(`.measure`). It passed the sizing audit, but it capped the body at **77.3 %** of the safe
area on five layouts while nothing sat to the right of it, and the reference deck uses no
`max-width` at all. The class is gone; prose runs the full safe area unless a second
column, a chart or a picture actually occupies the rest of the row.

Everything else stretches. Columns are `flex:1`. The safe area is set once, by the padding
on `.fit`: `13cqh 6cqw 8cqh`. The top value clears the 8.4cqh navbar.

Any flex child holding an SVG or a percentage-height bar needs `min-height:0`. Without it
the SVG's intrinsic ratio pushes the box past the stage edge.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions. Not a
slide.

**Opening and closing** · `cover` `toc` `section-divider` `close`

**Prose** · `statement` `long-form` `key-points` `two-column` `three-column`
`numbered-list` `big-quote`

**Filled peer sets** · `feature-cards` `quote-cards` `kpi-cards` `pricing`

**Numbers** · `stat-highlight` `kpi-row` `dial-metrics` `chart-bar` `chart-line`
`chart-donut` `chart-waterfall` `data-table` `financial-statement`

**Time and sequence** · `process-steps` `timeline` `roadmap` `gantt`

**Systems and relationships** · `architecture` `mind-map`

**Decisions and comparisons** · `comparison` `versus` `pros-cons`

`pricing` is the commercial-model page: three tiers as peer columns, one filled with `--g0`
as the adopted tier, each column carrying a price, a scope line, an inclusion list and a
footnote. It is the only layout whose peer columns are bottom-aligned (`margin-top:auto` on
the last line), so tiers with unequal inclusion lists still end on one line.

**Imagery** · `image-left` `image-right` `image-hero` `image-grid` `team-grid` — all five
delete cleanly. `image-left` / `image-right` are a split row: the frame is `flex:1`, the copy
`flex:1.15`, so the picture takes a little under half. When the source has no imagery,
drop the `data-photocell` frame and use a prose layout; do not leave an empty box.

`image-hero` is a large **contained** media field with its title and caption outside the
picture. It is not a full-bleed photo and never places body copy on an image.

**Evidence** · `case-study` `team-grid`

**Prospectus-specific** · `investment-thesis` `risk-matrix` `use-of-proceeds`
`deal-terms` `financial-statement`

`section-divider` covers both of the reference's divider treatments — the same layout on a
`--g0` field or on an `--ink` one. It is one file because it is one layout.

Badges, icon tiles, cards, colour fields, photo frames, chart marks and grid cells in
these files are content-bearing or structural devices, not optional decoration. The only
optional decoration is the textless `doodle` documented in
`../decoration/PLACEMENT.md`; Prospectus has no optional item-set ornament layer.

## Ruled or filled — every peer row has both

The reference separates items with a hairline on most of its content pages. That is a
skewed menu: an agent sampling it puts the same horizontal line on every slide. So each
peer-row content type has two treatments, and neither is more on-template than the other.

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `feature-cards` |
| a row of numbers | `kpi-row` | `kpi-cards` |
| two things compared | `comparison` | `versus` |
| a set of statements | `numbered-list` | `quote-cards` |

The filled versions cycle `--g0 --g2 --g1 --g3` so neighbours never share a colour. Pick
the filled version when the items are short and parallel, or simply when the previous
slide was ruled.

`kpi-cards` also carries the reference's "Primary" flag on its middle card. That flag
shares a line with the card's kicker rather than floating above it — as an absolutely
positioned corner chip it pushed that card's first line 9px out of step with its
neighbours, which is small enough to look like nothing and large enough to read as a
mistake.

## A filled box is sized by its content, never by the stage

Both dimensions.

```
height  row     flex:none      — height comes from the tallest child, not the stage
        child   flex:1         — siblings equalise to that tallest child
        group   wrapped in .mid (flex:1;min-height:0;justify-content:center)

width   box     align-self:flex-start; max-width:100%
```

`.fit` is a column flex with `align-items:stretch`, so **every child is full-width by
default**. `align-self:flex-start` opts one box out — that is what `.eyebrow` does, and it
is why the eyebrow rule hugs its own words instead of carrying a written width.

`flex:1` on the **row** and `flex:1` on the **child** look like the same instruction and
do opposite things. On the row it fills the stage and the cards inherit the stage's
height, giving a slab of colour that is half empty.

Exception: a **row of peers** stays equal-width and divides the safe area. One box hugs, a
row of boxes divides. Reserve a filling `flex:1` for an image frame or a chart plot area.

**Stress-tested, not assumed.** Injecting an extra sentence into the first item of every
peer row: `comparison` 232→272 both sides, `kpi-cards` 261→355 all three, `quote-cards`
297→873 all three, `two-column` 169→243 both. Siblings stay equal to each other and to
the tallest content, never to the slide.

## Boundaries that keep the additions on-template

The expanded set keeps three boundaries rather than importing a neighbouring template's
visual language:

- **No full-bleed photo hero.** `image-hero` keeps the media inside the safe area and its
  title and caption outside the picture, matching the rule against body copy on imagery.
- **a second card layout for allocations.** It was `kpi-cards` with a list inside it —
  two files, one layout. The list is now a note on `kpi-cards` instead.
- **No loose foreign node language.** `architecture` and `mind-map` use the template's
  existing hairlines, filled fields, badges, and direct typographic hierarchy. They do
  not add floating bubbles, ornamental connectors, or a second motif system.

## Colour, measured on `slate_corporate`

Against the `#FFFFFF` page: `--ink` `--s3` `--g3` 15.56, `--accent`/`--ka` 5.95, `--soft`
5.82, `--g2` 4.64, `--g1` 4.61, `--s1` 3.47 — all usable as text. **`--s2` reads 2.14 and
is fill-only.**

On a `--g0` field: `--t0` 5.95, but `--ka` reads **1.00** — the accent painted on itself.
Full-bleed pages take `var(--t0)` or `color:inherit` and nothing else.

`--surface` is 1.06:1 against the page: a `.card` is a nearly invisible panel. It is in the
reference once, so it is not banned here, but the treatments that read are a `--g?` ground
with the matching `--t?`, or no fill and a hairline.

Checked on all 43: zero text below 3.0:1.

## Classes available

Typography `display h1 h2 h3 stat kicker lead body cap` ·
structure `stage fit deck slide band card tile badge` ·
helpers `eyebrow mid row rule` · marks `dot tick soft dim pagenum`.

Sizes live in those classes. If something needs to be bigger, use the next class up — do
not write a `font-size`.
