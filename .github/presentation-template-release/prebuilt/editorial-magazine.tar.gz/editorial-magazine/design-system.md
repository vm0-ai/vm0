# Editorial Magazine

## Visual identity

Paper-like, restrained, and low in chroma. Serif titles, italic emphasis, issue markers, and a persistent footer create an editorial magazine system.

## Color system tokens

Read the prompt's `color-system` before generating. If it supplies one of the valid tokens below, use that token exactly. If it does not, choose from the tokens below according to the content, audience, mood, information density, and readability. Use only one token throughout a deck.

The presentation category documented for this template is **M (single-primary)**, with `warm_sand` as its example token. Determine the generated deck's token using the rule above.

Use only the following snake_case values as valid tokens:

- Single-primary M: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- Multicolour V: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`warm_sand`, `terracotta_clay`, `mono_ink`, `forest_editorial`, `gold_luxe`, `nordic_frost`

The default color system used in `example/reference.jpg` is `warm_sand`.
Picking a token outside this list is how a deck ends up looking like a different
template: a finance source, for instance, pulls every template toward the same
muted corporate grey unless the list stops it.


After selecting a token, read `color-systems/<token>.css`, inline that file's single CSS block in the final HTML, and write the same token on the root element. The canonical root value is:

```html
<html data-color-system="warm_sand">
```

- Use `--bg`, `--surface`, `--ink`, `--soft`, and `--ph` for the page, surfaces, body copy, secondary text, and image placeholders.
- `--accent`, `--s1`, `--s2`, and `--s3` are raw hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected for those raw hues in v1; use them for large icons or decorative symbols. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use the contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text. Use `--kad` for accent text on an `--ink` field. When a raw hue needs higher text contrast, these tokens fall back directly to the corresponding readable text colour.
- For large colour fields containing text, use `--g0` through `--g3` and pair each with the matching `--t0` through `--t3`.
- HTML/CSS components must reference colours only through `var(--...)`; derive transparency, strokes, shadows, and gradients from defined tokens as well.

Carry `--bg` throughout the deck. Use `--accent` and `--s3` for section blocks, statistic boxes, and table headers; reserve `--s1` and `--s2` for small decorations.

```css
.slide { background: var(--bg); color: var(--ink); }
.surface { background: var(--surface); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Fraunces` as the display typeface and `Work Sans` as the body typeface.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,400;0,500;0,600;1,400;1,500;1,600&family=Work+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Fraunces";
  --fb: "Work Sans";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "Songti SC", "STSong", "Noto Serif CJK SC", "Noto Serif SC", serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600; available body weights are 300 / 400 / 500 / 600. Use `--fd` for titles, hero numbers, and section numbers; use `--fb` for body copy, labels, chart annotations, and tables. For CJK content, preserve the display/body hierarchy through `--cjk-display` and `--cjk-body` respectively.

## Deck shell

This is the template's own base stylesheet, used by `layouts/`.
Copy it verbatim into the single `<style>` block, immediately after the inlined
colour-system CSS, before writing any slide. It defines the 16:9 stage, the type
scale, and the chrome and decoration classes the rest of this document refers
to. A deck that invents its own class names instead of using these will not look
like this template.

```css
:root{
  --r-xs: .5cqw;
  --r-sm: .9cqw;
  --r-md: 1.7cqw;
  --r-lg: 3cqw;
  --r-xl: 5cqw;
--fd: "Fraunces";
  --fb: "Work Sans";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "Songti SC", "STSong", "Noto Serif CJK SC", "Noto Serif SC", serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}
  

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65;z-index:6;}

.tile{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.tile>span{font-size:40cqw;line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{width:var(--sz,5cqw);height:var(--sz,5cqw);container-type:inline-size;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;font-size:calc(var(--sz,5cqw)*.4);}
.badge>span{font-size:40cqw;line-height:1;}
.tick{position:absolute;}
.card{background:var(--surface);border-radius:var(--r-md);}
.dot{border-radius:50%;}.qcircle{border-radius:50% 0 0 0;}.semi{border-radius:999px 999px 0 0;}.tri{width:0;height:0;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}
```
The number inside a `badge` and any text inside a `tile` must be wrapped in a
`<span>`. The wrapper is what makes the text scale with the box: it is measured
against the badge's own width, so the figure stays in proportion at any size.
Text placed directly in the box only follows `--sz`, and a deck that sizes the
box with `width`/`height` instead will render a small number in a large frame.
Size these with `--sz`, not `width`/`height`.


## Signature elements

Available signature elements: `running-footer`, `rotated-masthead`, `roman-italic-title`, `pentagon-step-node`, `sharp-stat-box`, `editorial-table`.


For templates with branded chrome, retain the example's dimensions, margins, and repeated positions, then replace placeholder names with real brand assets.

Visual reference: [example/reference.jpg](example/reference.jpg)

## Classified visual vocabulary

Every element below is copied out of this template's own reference deck. This is
the geometry that makes the template recognisable, and it is the part that goes
missing when a deck is authored from the prose alone — the shapes exist nowhere
else; it is reproduced here so generation never needs a full-deck HTML example.

**Copy these snippets. Do not paraphrase them, redraw them, or substitute a
shape that is easier to write.** Change only size, position, colour token, and
text content. The count beside each motif is how many times the reference deck
uses it across fifteen slides. It records prevalence; it is not a floor, quota,
or target to scale mechanically. Use a motif only where the closest reference
page role uses it and the composition benefits.


Only the textless **dot system** is optional decoration. Rails are background
structure; folio numerals, the rotated masthead and footer are chrome; badges,
tiles, pills, nodes, dot matrices and photocells carry content or data. Keep
those categories separate when reporting `decoration_count`.

### `badge` — repeated content component, used 3×

```html
<div class="badge" data-badge="1" style="--sz:5cqw;background:var(--g0);color:var(--t0)"><span>01</span></div>
```

### `rail` — background field, used on 10 of 15 pages

```html
<div data-background-field="rail" style="position:absolute;left:0;top:0;width:7cqw;height:100cqh;background:var(--g0);color:var(--t0);border-radius:0;z-index:1"></div>
```

### `dot-system` — optional decoration, one vocabulary class

```html
<div data-decoration="dot" style="position:absolute;right:6cqw;top:6cqh;width:1.3cqw;height:1.3cqw;background:var(--accent);border-radius:50%;z-index:3"></div>
<div data-decoration="dot" style="position:absolute;right:9.5cqw;top:5cqh;width:.65cqw;height:.65cqw;background:var(--accent);border-radius:50%;z-index:3"></div>
```

### `pill` — repeated content component, used 1×

```html
<div data-pill="1" style="display:inline-flex;align-items:center;justify-content:center;margin-top:5cqh;padding:1.2cqh 2.0cqw;background:var(--g0);color:var(--t0);border-radius:999px;font-family:var(--fd);font-weight:500;font-size:1.2cqw;letter-spacing:.04em">Read the catalogue</div>
```

### `tile` — repeated content component, used 4×

```html
<div class="tile" data-tile="1" style="--sz:5cqw;flex:none;background:var(--g0);color:var(--t0)"><svg viewBox="0 0 24 24" style="width:50%;height:50%;stroke:currentColor;fill:none;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round"><path d="M2 19V6a2 2 0 0 1 2-2h7v17H4a2 2 0 0 1-2-2zM22 19V6a2 2 0 0 0-2-2h-7v17h7a2 2 0 0 0 2-2z"/></svg></div>
```


### CSS signatures

These declarations are part of the template's look. The counts are from the reference deck.

| property | values it actually uses | why it matters |
| --- | --- | --- |
| `clip-path` | `polygon(0 0,100% 0,100% 60%,50% 100%,0 60%)` ×4 | angled and notched panels |
| `border-radius` | `50% 0 0 0` ×1<br>`999px 999px 0 0` ×1<br>`999px` ×1 | arches, capsules and part-round corners |
| `transform` | `rotate(-90deg) translate(-50%,0)` ×3 | deliberate tilt |


### Not captured above

These named signature elements have no extractable snippet in this library: `running-footer`, `rotated-masthead`, `roman-italic-title`, `pentagon-step-node`, `sharp-stat-box`, `editorial-table`. Read [layouts/](layouts/) for them and copy the markup from the slide that uses them; do not improvise a substitute.

## Decoration reference profile (diagnostic only)

The optional-decoration vocabulary count is **1**: `dot-system`. Its primary
treatment is the two-dot pair, present on 13 of 15 pages; three rail-less pages
also carry the conditional low anchor dot. These are reference frequencies, not
a quota. Rails, colour fields, cards, tiles, badges, nodes, connectors, media
frames, dot charts and fixed chrome are excluded from that count.

The reference also uses image frames, but that is not a target: never invent a
photograph the source material does not support. Sparse slides are intentionally
sparse.

**A kicker is not a chip.** In this template's reference deck the `kicker`, the
page number, the running head and the standfirst are plain text — no background,
no border, no shadow, no rounded pill around them. Every one of the 23 reference
decks agrees on this, and giving them a box is the single most common way a
generated deck drifts: a kicker appears on every slide, so boxing it adds one
false chip per slide and doubles this template's labelled-box count on its own.

Only the content components this library actually draws as chips — `badge`, `tag`,
`pill`, and whatever else this file shows with a fill — carry a background.
Everything else that is text stays text.

**Before delivering, audit identity.** On three
representative slides, verify that every visual element maps to a named class or
to a specific composition in the reference.

Content still comes first. Never push text off the stage, cover it, or drop a point. Never add a photograph
the source material does not support. A slide carrying six bullets may correctly
carry no optional decoration at all.


## Decoration safe area

Decoration is placed before content, but it never fights the content.

- Every slide has a **text safe area**: the region actually occupied by the
  title, body copy, figures, and labels. No decoration may sit on top of it.
- Decoration belongs in one of three places: outside the safe area entirely
  (edges, corners, the empty half of the stage); behind it at `z-index:0`–`1`
  **and** at a contrast low enough that the text stays fully legible; or
  deliberately overlapping a photograph or colour field where the reference
  shows exactly that.
- Nothing bleeds in this template. The dot system stays inside the stage; rails
  sit flush to one edge and stop exactly at the stage boundary.

## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** A label positioned with `left:88cqw` will
overflow the moment its text is longer than the author guessed, and CJK copy is
routinely wider than the Latin draft it was written against. Anchor anything in
the right third with `right:` instead of `left:`, and anything in the bottom
third with `bottom:` instead of `top:`. A block anchored to the edge it is near
grows inward, where there is room, instead of outward into nothing. Give any
absolutely-positioned text an explicit `max-width` so it wraps rather than
extends.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a grid or a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

Both faults hide from a quick glance at the whole deck and are obvious on the
slide itself. Before delivering, look at every slide that carries a set of
things and check that the set is aligned and that nothing touches an edge it was
not meant to touch.

## Never do this

- **Never use a disc-bulleted list.** Not one of the twenty-three V3 reference
  decks contains a single `<ul>` with default bullets, and a bulleted list is the
  fastest way to make a designed template look like a plain document. Structure a
  list as numbered rows with a hairline rule between them, as key–value rows, as
  a row of cards, or with the template's own motifs — whatever the reference deck
  does for the same job.
- Never invent a colour outside the inlined colour-system tokens; every colour
  goes through `var(--...)`.
- Never leave a slide without the chrome named in `Required chrome`.
- Never let an ornament sit on top of a title or a paragraph.
- Never generate a photograph the supplied material does not call for.

## Required chrome

Chrome is the cheapest part of a template's identity and the most frequently
dropped: across the benchmark's baseline decks, four of six templates carried a
footer on 0-2 slides out of 17. This template's reference deck carries the
following, and the count is measured from that deck, not assumed.


### Repeats on every slide

The reference deck also repeats these edge-pinned elements on nearly every slide. Their opening tags are given as locators — find each one in [layouts/](layouts/) and carry it through your deck the same way.

```html
<div class="kicker" style="position:absolute;left:5cqw;bottom:3.0cqh;font-size:1.0cqw;letter-spacing:.22em;color:var(--soft);z-index:5">
```
<sub>on 15 of 15 reference slides</sub>

```html
<div style="position:absolute;left:20cqw;right:9cqw;bottom:3.55cqh;height:1px;background:color-mix(in srgb,var(--ink) 24%,transparent);z-index:4">
```
<sub>on 15 of 15 reference slides</sub>

**Edge-pinned label** — on 15 of the reference deck's 15 slides. A wide-tracked uppercase `.kicker` carrying a stable word drawn from the deck's own subject:

```html
<div class="kicker" style="position:absolute;left:5cqw;bottom:3.0cqh;font-size:1.0cqw;letter-spacing:.22em;color:var(--soft);z-index:5">PUBLICATION NAME</div>
```

**Page number** — on 15 of 15 slides:

```html
<div class="pagenum">page 01</div>
```

Carry footer label and page number on **every** slide, including the cover and the closing slide.
