---
name: editorial-magazine
description: Create a standalone 16:9 HTML presentation deck with the Editorial Magazine visual identity and direct-HTML workflow. Use when the user selects the Editorial Magazine presentation template or explicitly names editorial-magazine as the deck style. Best suited to restrained, paper-like trend reports, culture stories, and brand magazines.
---

# Editorial Magazine presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one standalone HTML file with one live `.deck`. **Every `.slide` must be a
  direct child of `.deck`.** The navigation runtime collects pages with
  `[...deck.children].filter(n => n.classList.contains('slide'))`; a slide nested one
  level deeper renders perfectly, scrolls by drag, screenshots correctly — and the arrow
  keys cannot reach it. Give each slide one 16:9 `.stage` and include the deck CSS and
  keyboard-navigation script once.
- Translate the completed outline directly into HTML in the same order. Pick a layout per
  slide from the table above, then dress it per `decoration/PLACEMENT.md`.
- Treat the examples as visual grammar, not as a fixed page catalogue or required slide count.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

- Read [design-system.md](design-system.md) for the deck shell, motif library, and
  required chrome.
- Read [layouts/README.md](layouts/README.md) and [decoration/PLACEMENT.md](decoration/PLACEMENT.md) completely. Between them they carry the sizing rule, the safe area, the optional-decoration inventory, structural vocabulary and frequencies.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — motifs, background treatment, chrome;
  4. every optional motif follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is accurate but visually anonymous also fails.

- Optional: [example/reference.jpg](example/reference.jpg) and [layouts/](layouts/) for page-role rhythm and scale — not for widths.
- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use the prompt's `color-system` when supplied, otherwise a preferred token from
  `design-system.md`. Inline that one `color-systems/<token>.css` in the final HTML.

#### The sizing rule

**Nothing that holds text carries a size in `cqw`, `cqh`, `px`, `vw` or `vh`** — no
`width`, `max-width`, `min-width`, `height`, `max-height`, `min-height`, or frozen
`flex-basis`. Nor does in-flow content use those units for `left`, `top`, `right`, or
`bottom`; absolute ornament placement is the only placement exception. Columns are
`flex:1`. A box that should hug its content takes `align-self:flex-start;max-width:100%`.
The safe area is set once, by the padding on `.fit`:

```
padding: 12cqh 6cqw 9cqh
```

When a rail occupies an edge, add the class that clears it — `.fit.rail-l`,
`.fit.rail-r`, `.fit.field-l`, `.fit.field-r` — rather than editing the padding.

A filled box is sized by its content, never by the stage. On a peer row the **row** is
`flex:none` and each **child** is `flex:1`; those look like the same instruction and do
opposite things. `flex:1` on the row makes the cards inherit the stage's height and you
get a slab of colour that is half empty.

#### Decoration

Decoration is not bound by the safe area: an ornament may cross it and bleed off the
stage where `PLACEMENT.md` says so. The safe area binds type and content.

- Decoration goes outside the region the content occupies — the margins, the corners —
  or behind it at `z-index:0–1` at a contrast low enough that the text stays fully
  legible. It is always `position:absolute`. Never reserve a column in flow for it: a
  layout that leaves an empty box "for the rail" ships that box as blank paper whenever
  the rail is not used, and the rail does not need it in the first place.
- **Ornaments in this template do not bleed.** Keep them inside the stage; a cropped
  ornament is a different template's device.
- **No page is a full colour field.** The ground colour is never on `.stage`. Where
  another template turns a whole page one colour, this one runs a colour rail down one
  side and leaves the rest paper.
- Never place body copy on top of a photograph unless the photograph is a full-bleed
  field and the copy sits on a text-safe treatment.

### Build a slide from two layers

This template is split into a **layout** layer and a **decoration** layer. Take the
structure from one and the ornaments from the other.

1. **[`layouts/`](layouts/)** — 40 naked layouts, text only. Pick the one whose shape
   matches the slide's job. Read [`layouts/README.md`](layouts/README.md) first.
2. **[`decoration/PLACEMENT.md`](decoration/PLACEMENT.md)** — the optional dot system,
   structural fields and fixed chrome, explicitly classified with frequencies and placement.
3. **[`decoration/item-sets.html`](decoration/item-sets.html)** — repeated content
   components as copyable markup. They are not optional decorations.

Use `layouts/` for rhythm and page-role context; take reusable structure
from `layouts/` and do not copy content-specific fixed geometry.

#### Slide type → layout

| the slide's job                                              | layout                       |
| ------------------------------------------------------------ | ---------------------------- |
| open the deck                                                | `cover`                      |
| open a magazine issue with masthead, cycle and lead image    | `issue-opener`               |
| contents, agenda, or any key–value list                      | `toc`                        |
| address readers from the editor                              | `editors-note`               |
| start a section                                              | `section-divider`            |
| open a reported feature with headline, byline and hero image | `feature-opener`             |
| close the deck                                               | `close`                      |
| record publication credits and production details            | `credits-colophon`           |
| two blocks of prose                                          | `two-column`                 |
| three parallel points, ruled                                 | `three-column`               |
| carry continuous long-form copy in readable columns          | `longform-columns`           |
| three parallel points, filled                                | `card-grid`                  |
| an ordered list of principles or findings                    | `numbered-list`              |
| one observation as a full-page pull quote                    | `big-quote`                  |
| interrupt a feature with a quote between supporting copy     | `pull-quote`                 |
| several testimonials or voices                               | `quote-cards`                |
| upsides against downsides                                    | `pros-cons`                  |
| two options side by side, quiet                              | `comparison`                 |
| two options side by side, emphatic                           | `versus`                     |
| a row of headline numbers, filled                            | `stat-boxes`                 |
| a row of headline numbers, ruled                             | `kpi-grid`                   |
| one number that carries the slide                            | `stat-highlight`             |
| price tiers, plans or packages                               | `pricing`                    |
| hold compact contextual facts beside an article summary      | `fact-box`                   |
| rows of tabular evidence                                     | `table`                      |
| magnitudes across categories                                 | `chart-bar`                  |
| a trend over time                                            | `chart-line`                 |
| a share of a total                                           | `chart-dots`                 |
| a repeating process                                          | `process-steps`              |
| dated milestones                                             | `timeline`                   |
| phases across tracks                                         | `roadmap`                    |
| layered structure                                            | `arch-diagram`               |
| a picture beside copy                                        | `image-left` / `image-right` |
| a set of pictures                                            | `image-grid`                 |
| give one image the full page with a text-safe caption panel  | `full-bleed-image`           |
| show a sequence of individually captioned images             | `captioned-gallery`          |
| profile or interview one person through portrait and Q&A     | `profile-interview`          |
| index a dense catalogue of named objects or references       | `catalogue-index`            |
| people                                                       | `team`                       |

If two layouts fit, prefer the one whose treatment differs from the previous slide's —
ruled after filled, filled after ruled.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Identity checks while authoring

First confirm the content survived: every point is still on its slide and no
image or caption appears that the material does not support. Then audit
identity:

- every slide carries the chrome from `Required chrome` — footer kicker, hairline, page
  number, on all pages including the cover and the closing page;
- the only optional decoration is the **dot-system**: a 2:1 pair, with a conditional
  low anchor dot. Rails and photocells are structure; folio numeral, rotated masthead
  and footer are chrome; tiles, badges, nodes, pills and dot matrices carry content or
  data. No arches, quarter-circles, starbursts, blobs, gradients or outlined boxes;
- the dot pair is present on the pages that should carry it, at its 2:1 size ratio;
- roughly two thirds of pages carry exactly one rail — never two;
- a kicker is plain text, never a chip with a background;
- exactly one `data-color-system` token, and it is one of the preferred tokens;
- keep authored ornaments clear of type; any reported geometric crossing remains an
  optional-review candidate under `Automated QA` below; no fill-only token (`--accent`, `--s1`, `--s2`,
  `--g2`, `--surface`) is used as text.

Resolve any failure before running Automated QA.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
