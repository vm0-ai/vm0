---
name: editorial-magazine
description: Create, revise, or review standalone 16:9 HTML presentation decks with the Editorial Magazine visual identity and direct-HTML workflow. Use when the user selects the Editorial Magazine presentation template or explicitly names editorial-magazine as the deck style. Best suited to restrained, paper-like trend reports, culture stories, and brand magazines.
---

# Editorial Magazine presentation

Create one coherent, audience-facing 16:9 HTML slide deck with this folder's visual identity.

The default deliverable for this skill is a standalone HTML presentation. Here, standalone means one directly openable HTML artifact: documented web-font links may remain external with system fallbacks, while the selected colour-system CSS and all deck HTML, CSS, and JavaScript stay in the file. Create another presentation format only when the user explicitly requests it.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## Build a slide from two layers

This template is split into a **layout** layer and a **decoration** layer. Take the
structure from one and the ornaments from the other.

1. **[`layouts/`](layouts/)** — 40 naked layouts, text only. Pick the one whose shape
   matches the slide's job. Read [`layouts/README.md`](layouts/README.md) first.
2. **[`decoration/PLACEMENT.md`](decoration/PLACEMENT.md)** — the optional dot system,
   structural fields and fixed chrome, explicitly classified with frequencies and placement.
3. **[`decoration/item-sets.html`](decoration/item-sets.html)** — repeated content
   components as copyable markup. They are not optional decorations.

Use `layouts/` for rhythm and page-role context; take reusable structure
from `layouts/` and do not copy content-specific fixed geometry.

### Slide type → layout

| the slide's job                                              | layout                       |
| ------------------------------------------------------------ | ---------------------------- |
| open the deck                                                | `cover`                      |
| open a magazine issue with masthead, cycle and lead image    | `issue-opener`               |
| contents, agenda, or any key–value list                      | `toc`                        |
| address readers from the editor                              | `editors-note`               |
| start a section                                              | `section-divider`            |
| open a reported feature with headline, byline and hero image | `feature-opener`             |
| close the deck                                               | `close`                      |
| record publication credits and production details            | `credits-colophon`           |
| two blocks of prose                                          | `two-column`                 |
| three parallel points, ruled                                 | `three-column`               |
| carry continuous long-form copy in readable columns          | `longform-columns`           |
| three parallel points, filled                                | `card-grid`                  |
| an ordered list of principles or findings                    | `numbered-list`              |
| one observation as a full-page pull quote                    | `big-quote`                  |
| interrupt a feature with a quote between supporting copy     | `pull-quote`                 |
| several testimonials or voices                               | `quote-cards`                |
| upsides against downsides                                    | `pros-cons`                  |
| two options side by side, quiet                              | `comparison`                 |
| two options side by side, emphatic                           | `versus`                     |
| a row of headline numbers, filled                            | `stat-boxes`                 |
| a row of headline numbers, ruled                             | `kpi-grid`                   |
| one number that carries the slide                            | `stat-highlight`             |
| price tiers, plans or packages                               | `pricing`                    |
| hold compact contextual facts beside an article summary      | `fact-box`                   |
| rows of tabular evidence                                     | `table`                      |
| magnitudes across categories                                 | `chart-bar`                  |
| a trend over time                                            | `chart-line`                 |
| a share of a total                                           | `chart-dots`                 |
| a repeating process                                          | `process-steps`              |
| dated milestones                                             | `timeline`                   |
| phases across tracks                                         | `roadmap`                    |
| layered structure                                            | `arch-diagram`               |
| a picture beside copy                                        | `image-left` / `image-right` |
| a set of pictures                                            | `image-grid`                 |
| give one image the full page with a text-safe caption panel  | `full-bleed-image`           |
| show a sequence of individually captioned images             | `captioned-gallery`          |
| profile or interview one person through portrait and Q&A     | `profile-interview`          |
| index a dense catalogue of named objects or references       | `catalogue-index`            |
| people                                                       | `team`                       |

If two layouts fit, prefer the one whose treatment differs from the previous slide's —
ruled after filled, filled after ruled.

## Choose the task mode

- Create: use Sections 1–5 and complete Section 2 before writing any slide HTML.
- Revise: inspect the existing HTML, reconstruct or update the outline for the affected sequence, and complete Section 2 before editing slide HTML; then use Sections 3–5 as relevant while preserving valid shell, token, motif, and runtime implementation.
- Review: use Sections 1–3 for context and Section 5 as the checklist; infer the deck's throughline and slide-level content contract, skip Section 4, and do not edit. Report slide-specific findings in P1 / P2 / P3 order (blocking / material / polish), include evidence and a fix direction, or state explicitly that there are no actionable findings.

## 1. Define the communication job

- Read the prompt and all supplied source material before composing slides.
- Identify the audience, purpose, desired audience outcome, core takeaway, and required evidence.
- Express the communication job in one sentence: by the end, the audience should reach the desired outcome because of the core takeaway.
- Ground every factual claim and number in supplied or verified sources; label forecasts, targets, and assumptions explicitly.

## 2. Complete the slide outline before HTML

- Before creating or changing slide HTML, write a lightweight plain-text or Markdown outline. State the one-sentence throughline, then list the slides in order.
- For each slide, record its working takeaway title, the point it must establish, and the evidence or data that supports it with its supplied or verified source. Mark forecasts, targets, assumptions, and slides that need no evidence.
- Review the complete outline for narrative flow, duplicated claims, missing evidence, and a deliberate opening and ending. Choose the slide count from the content.
- Treat the completed outline as the content contract for implementation, not as a layout schema. Keep layouts and motifs out of it, keep it out of audience-facing HTML unless requested, and update it first when a slide's title, communication job, or evidence changes materially.

## 3. Load the local identity

- Read [design-system.md](design-system.md) completely for colour roles, typography, signature elements, and visual identity.
- Read [layouts/README.md](layouts/README.md) and [decoration/PLACEMENT.md](decoration/PLACEMENT.md) completely. Between them they carry the sizing rule, the safe area, the optional-decoration inventory, structural vocabulary and frequencies.
- **Order of priority when two of these pull against each other:**
  1. the content is accurate and complete against the supplied material;
  2. every slide is legible at presentation size;
  3. the template's identity is intact — motifs, background treatment, chrome;
  4. every optional motif follows its documented role and placement.

  Decoration never wins against 1 or 2. It must not displace content, shrink
  copy, drop a point from a slide, or invent something to fill a slot. A deck that is accurate but visually anonymous also fails.

- Use one of the **preferred tokens** named in `design-system.md` when the
  prompt does not supply a `color-system` — not an arbitrary token from the full
  list.
- Inspect [example/reference.jpg](example/reference.jpg) and [layouts/](layouts/) for page-role rhythm and scale — not for widths.
- Read [composition-recipes.html](composition-recipes.html) before laying out a slide whose content is a table, a list of records, or repeated rows. A column holding identifiers, codes, or numbers takes the width its content needs and never wraps; only the prose column absorbs the slack.
- Use a valid prompt `color-system` when supplied. Otherwise select a valid token from `design-system.md`. Load exactly one `color-systems/<token>.css` file and inline its CSS in the final HTML.

### The sizing rule

**Nothing that holds text carries a size in `cqw`, `cqh`, `px`, `vw` or `vh`** — no
`width`, `max-width`, `min-width`, `height`, `max-height`, `min-height`, or frozen
`flex-basis`. Nor does in-flow content use those units for `left`, `top`, `right`, or
`bottom`; absolute ornament placement is the only placement exception. Columns are
`flex:1`. A box that should hug its content takes `align-self:flex-start;max-width:100%`.
The safe area is set once, by the padding on `.fit`:

```
padding: 12cqh 6cqw 9cqh
```

When a rail occupies an edge, add the class that clears it — `.fit.rail-l`,
`.fit.rail-r`, `.fit.field-l`, `.fit.field-r` — rather than editing the padding.

A filled box is sized by its content, never by the stage. On a peer row the **row** is
`flex:none` and each **child** is `flex:1`; those look like the same instruction and do
opposite things. `flex:1` on the row makes the cards inherit the stage's height and you
get a slab of colour that is half empty.

### Images are content choices, not decoration

Use a photograph or other image whenever it communicates the slide more clearly,
credibly, or memorably than text alone. The supplied material does not have to
explicitly request an image; make that editorial choice from the content.

- Choose sources in this order: user-supplied images and visual materials first,
  including media embedded in or linked from the supplied material; then relevant
  imagery from the supplied references and related information; then an AI-generated
  image grounded in the slide's actual subject when it would work better or no suitable
  sourced image exists.
- Never add or generate an image merely to fill an empty region or make a slide look
  finished. When no image improves the slide, use the template's
  non-photographic treatments instead: a colour field, a panel, a large figure,
  a motif, or generous space.
- Every caption, alt text, and label beside an image must come from the
  material. Never invent a caption to justify a picture.

### Decoration safe area

- Decoration goes outside the region the content occupies — the margins, the corners —
  or behind it at `z-index:0–1` at a contrast low enough that the text stays fully
  legible. It is always `position:absolute`. Never reserve a column in flow for it: a
  layout that leaves an empty box "for the rail" ships that box as blank paper whenever
  the rail is not used, and the rail does not need it in the first place.
- **Ornaments in this template do not bleed.** Keep them inside the stage; a cropped
  ornament is a different template's device.
- **No page is a full colour field.** The ground colour is never on `.stage`. Where
  another template turns a whole page one colour, this one runs a colour rail down one
  side and leaves the rest paper.
- Never place body copy on top of a photograph unless the photograph is a full-bleed
  field and the copy sits on a text-safe treatment.

## 4. Build the deck

- Produce one standalone HTML file with one live `.deck`. **Every `.slide` must be a
  direct child of `.deck`.** The navigation runtime collects pages with
  `[...deck.children].filter(n => n.classList.contains('slide'))`; a slide nested one
  level deeper renders perfectly, scrolls by drag, screenshots correctly — and the arrow
  keys cannot reach it. Give each slide one 16:9 `.stage` and include the deck CSS and
  keyboard-navigation script once.
- Translate the completed outline directly into HTML in the same order. Pick a layout per
  slide from the table above, then dress it per `decoration/PLACEMENT.md`.
- Treat the examples as visual grammar, not as a fixed page catalogue or required slide count.
- Use the chosen colour-system variables for every colour relationship and the documented font tokens for display, body, labels, and data.
- Keep repeated chrome, typography, colour rhythm, and signature elements consistent across the deck while varying page composition with the story.
- Fit all audience-facing content inside the stage. Split dense material across slides and give meaningful visual assets useful alt text.
- Set `<html lang>`, `<title>`, `data-color-system`, and the live deck's `aria-label` from the actual presentation.

## Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Getting the container right

A percentage bar height resolves against its parent's **definite** height. Break
that chain and the bar computes to exactly `0` — it vanishes while the labels,
values and legend still render, so the page reads as merely empty. Measured on
generated decks: 52 of 558 percentage bars rendered at zero, and one deck spent
455s of gate repair on this alone.

`layouts/chart-*.html` already carries a structure that works. Copy it rather
than inventing lanes. Three rules make the chain definite:

1. **A bar is a direct child of the plot box.** Any level between them needs its
   own definite height, and one that lacks it zeroes everything below.
2. **All columns share one grid, so the label row is shared.** A label that wraps
   to two lines must cost every column the same height, or the bar above it is
   measured against a shorter ruler than its neighbours. Make the plot
   `display:grid; grid-auto-flow:column; grid-auto-columns:1fr` with
   `grid-template-rows:1fr auto …` (one row per item in a column, exactly — a
   spare row pulls the next column's first item into the previous column), and
   give each column wrapper `display:contents`. The markup grouping stays "one
   div per column"; only the rows become shared.

   Measured on the template's own `chart-bar.html`, changing nothing but one
   label to a wrapping name: baseline offset 0 → 19px, and the fourth bar 342 →
   324px — the value never changed, the bar just lost 5%. With the shared grid
   the same label costs all four bars the same 8%, and the ratios stay exact.

3. **Every level is either `flex:none` or `flex:1`** — sized by its content, or
   taking the remainder. There is no third kind.

4. **A value label never shares the lane with the bar it labels.** If it does,
   flex has to fit label + gap + bar into the lane, so it shrinks the bar — and
   only the bars tall enough to run out of room. The scale stops being linear at
   the top: measured on `bloom/chart-bar.html`, lane 336px, label 19px, gap 6px,
   every value above 92.5% rendered at the same 310px, so **96 and 100 drew
   identically**. Under the template's own "percentages of the tallest value"
   convention the tallest bar is always 100%, so this fires on every chart.
   Reserve the label row on the lane (`padding-top`, measured once per template)
   and set both children `flex:none`; the bar then resolves against the lane
   minus that reserve, the same reserve for every column.

Grouping two bars per category still obeys this, but the group wrapper needs
`align-self:stretch`, or it is sized by content and the lane inside it collapses.

Do not "fix" a flat chart by enlarging the numbers or switching to a table. The
values are right; the container chain is not.

## How full a page should be

Measured across all 902 layouts in the 23 shared templates, so this is what the
system already does — not a target invented for the occasion:

|                                                                                  | p25 |  median | p75 |
| -------------------------------------------------------------------------------- | --: | ------: | --: |
| vertical coverage (share of the stage height that carries ink or a filled block) | 33% | **43%** | 61% |
| ink area (share of the stage area)                                               |  9% | **12%** | 16% |
| lowest ink (how far down the page the content reaches)                           | 68% | **75%** | 90% |

**Aim for the middle column.** A content page that stops at 40% of the height and
leaves the rest blank reads as unfinished; one that runs past 25% ink area reads as
a wall. Both are allowed when the material calls for it — a statement page is one
huge line at 6% coverage, a table or a longform page is legitimately dense — but
neither is the default.

Two things that are **not** the same:

- **A void at the bottom.** Content stops early and nothing follows. This is the
  one to avoid; measured on the naked layouts, 73 of 902 pages do it.
- **Air between blocks.** A title, then a band of columns centred in the space
  below it. That is composition, not a defect — do not fill it just to fill it.

If the material genuinely does not fill the page, cut a column or merge the page
into its neighbour rather than padding sentences.

## 5. Verify before delivery

- Render and inspect every slide at full presentation size, then review the complete sequence for narrative flow and visual rhythm.
- **Check navigation structurally and by hand:**

  ```js
  document.querySelectorAll(".slide").length ===
    [...document.querySelector(".deck").children].filter((n) =>
      n.classList.contains("slide"),
    ).length;
  ```

  Then actually press `←/↑/→/↓` from the first slide to the last. This defect is found
  by pressing a key, not by looking at a screenshot.

- Confirm the colour-system CSS actually resolved — a wrong relative path renders every
  slide unstyled while every other check still passes. Verify a token computes:
  `getComputedStyle(document.querySelector('.stage')).backgroundColor` must not be white.
- Compare the rendered deck with the completed outline; confirm every title, communication job, evidence item, and source status remains aligned and no planning notes appear in audience-facing copy.
- Check title wrapping, body readability, data labels, contrast, clipping, overflow, unintended overlap, unresolved placeholders, and motif consistency.
- Run `tools/run.sh <deck>` at 1600×900 after fonts settle. Require `titleBodyOverlaps`, `bodyCtaOverlaps`, and `textBigcircleOverlaps` all equal 0; any non-zero result is blocking. These semantic intersections have no bypass.
- Inspect every `textVisualOverlapCandidates` sample in the rendered slide. This field is advisory: repair or move the motif when it obscures any glyph or reduces the text to doubtful readability; keep an intentional crossing only when every word remains immediately legible. Do not auto-fail a clear, harmless overlap.
- Confirm `outsideSafeArea` is zero against this template's fixed 6 % horizontal
  constant, and no text sits below the running footer. Report `aboveChromeBand` for
  review because the template permits intentional in-flow headings in the upper band.
- Confirm the prompt-selected colour-system is used exactly, or record the valid token chosen when the prompt omitted it.
- Test `Home` and `End`; confirm focused editable controls retain their normal key behaviour.

### Identity audit before delivery

First confirm the content survived: every point is still on its slide and no
image or caption appears that the material does not support. Then audit
identity:

- every slide carries the chrome from `Required chrome` — footer kicker, hairline, page
  number, on all pages including the cover and the closing page;
- the only optional decoration is the **dot-system**: a 2:1 pair, with a conditional
  low anchor dot. Rails and photocells are structure; folio numeral, rotated masthead
  and footer are chrome; tiles, badges, nodes, pills and dot matrices carry content or
  data. No arches, quarter-circles, starbursts, blobs, gradients or outlined boxes;
- the dot pair is present on the pages that should carry it, at its 2:1 size ratio;
- roughly two thirds of pages carry exactly one rail — never two;
- a kicker is plain text, never a chip with a background;
- exactly one `data-color-system` token, and it is one of the preferred tokens;
- no ornament sits on top of type, and no fill-only token (`--accent`, `--s1`, `--s2`,
  `--g2`, `--surface`) is used as text.

Fix the deck and re-render before delivering if any line fails.

## Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding. Run `tools/run.sh <deck>` and require `safeAreaShells`, `outsideSafeArea`, and `emptyPhotocells` all to equal `0`; any non-zero result blocks delivery.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
