/* Two geometric defects, measured — not judged. Run against the contact sheet.
 *
 * 1. empty wide column — a flow box with no text, no background, no border and no
 *    vector/image content, occupying >=8% of the safe-area width.
 * 2. narrow-box wrap — text wrapping to 2+ lines inside a box clearly narrower than
 *    the safe area while the space to its right, out to the safe-area edge, is empty.
 */
(() => {
  const SAFE = +(document.documentElement.dataset.safeArea || 0.06);
  // own text only, and blank text nodes dropped BEFORE the join — joining two
  // whitespace-only nodes yields ' ', which reads as one character of text and
  // let every wrapper div through as if it were a paragraph.
  const own = e => [...e.childNodes].filter(n => n.nodeType === 3)
    .map(n => n.textContent.trim()).filter(Boolean).join(' ');
  const painted = e => {
    const cs = getComputedStyle(e);
    if (e.textContent.trim().length) return true;
    if (e.hasAttribute('data-photocell')) return true;
    if (/^(svg|img|canvas|path|line|polyline|rect|circle)$/i.test(e.tagName)) return true;
    if (cs.backgroundColor && !/rgba?\(0, 0, 0, 0\)/.test(cs.backgroundColor)) return true;
    if (cs.backgroundImage && cs.backgroundImage !== 'none') return true;
    return parseFloat(cs.borderTopWidth) + parseFloat(cs.borderLeftWidth) +
           parseFloat(cs.borderRightWidth) + parseFloat(cs.borderBottomWidth) > 0;
  };
  const out = { emptyWideCols: [], narrowWraps: [] };

  document.querySelectorAll('.stage').forEach(st => {
    const sr = st.getBoundingClientRect();
    const safeW = sr.width * (1 - 2 * SAFE);
    const safeL = sr.left + sr.width * SAFE, safeR = sr.right - sr.width * SAFE;
    const label = (st.querySelector('div') || {}).textContent || '?';
    const name = label.trim().split('\n')[0].slice(0, 24);
    const fit = st.querySelector('.fit');
    if (!fit) return;

    const inFlow = e => {
      for (let n = e; n && n !== fit; n = n.parentElement)
        if (getComputedStyle(n).position === 'absolute') return false;
      return fit.contains(e);
    };

    // ---- 1. empty wide columns ----
    fit.querySelectorAll('div,span,section,aside').forEach(e => {
      if (!inFlow(e)) return;
      const cs = getComputedStyle(e);
      if (cs.position === 'absolute') return;
      if (painted(e)) return;
      // a box that only *contains* paint — a chart plot, a dot row — is not empty
      if ([...e.querySelectorAll('*')].some(painted)) return;
      const r = e.getBoundingClientRect();
      if (r.width / safeW < 0.08) return;
      if (r.height / sr.height < 0.02) return;
      out.emptyWideCols.push({
        page: name,
        widthPct: +(r.width / safeW * 100).toFixed(1),
        heightPct: +(r.height / sr.height * 100).toFixed(1)
      });
    });

    // ---- 2. narrow-box wrap with empty space to the right ----
    fit.querySelectorAll('*').forEach(e => {
      if (!inFlow(e)) return;
      if (!own(e).length) return;
      // an inline <em>/<span> has the width of its own glyphs, not of the box the
      // text is set in — measuring it reports a "narrow box" that does not exist
      if (getComputedStyle(e).display.startsWith('inline')) return;
      const rg = document.createRange(); rg.selectNodeContents(e);
      const runs = [...rg.getClientRects()].filter(x => x.width > 2 && x.height > 2);
      if (runs.length < 2) return;
      // count distinct baselines, not client rects (inline <em>/<br> split one line)
      const tops = [...new Set(runs.map(x => Math.round(x.top)))].sort((a, b) => a - b);
      const lines = tops.filter((t, i) => i === 0 || t - tops[i - 1] > 4).length;
      if (lines < 2) return;
      const r = e.getBoundingClientRect();
      if (r.width / safeW > 0.92) return;                  // already full width
      // is anything drawn to its right, inside the safe area?
      const gapL = r.right + 2, gapR = safeR;
      if (gapR - gapL < safeW * 0.06) return;
      let occupied = false;
      st.querySelectorAll('*').forEach(o => {
        if (occupied || o === e || e.contains(o) || o.contains(e)) return;
        const cs = getComputedStyle(o);
        const painted = o.textContent.trim().length || o.hasAttribute('data-photocell') ||
          /svg|img|canvas/i.test(o.tagName) ||
          (cs.backgroundColor && !/rgba?\(0, 0, 0, 0\)/.test(cs.backgroundColor));
        if (!painted) return;
        const rr = o.getBoundingClientRect();
        if (rr.width < 4 || rr.height < 4) return;
        if (rr.right > gapL + 4 && rr.left < gapR &&
            rr.bottom > r.top + 2 && rr.top < r.bottom - 2) occupied = true;
      });
      if (occupied) return;
      out.narrowWraps.push({
        page: name,
        text: (own(e) || e.textContent).trim().slice(0, 34),
        boxPct: +(r.width / safeW * 100).toFixed(1),
        emptyRightPct: +((gapR - r.right) / safeW * 100).toFixed(1),
        lines
      });
    });
  });
  out.emptyWideColsCount = out.emptyWideCols.length;
  out.narrowWrapsCount = out.narrowWraps.length;
  return JSON.stringify(out);
})()
