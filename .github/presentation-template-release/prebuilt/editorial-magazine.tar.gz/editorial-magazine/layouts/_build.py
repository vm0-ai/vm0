#!/usr/bin/env python3
"""Emit every naked layout from the shared shell in _shell.html.

Run from this directory:  python3 _build.py
Rebuilds every <name>.html so a fix to the shell lands in all of them at once.
"""
import re
import pathlib

HERE = pathlib.Path(__file__).parent
SHELL = (HERE / '_shell.html').read_text()
HEAD = SHELL.split('<body>')[0] + '<body>\n'

# ---------------------------------------------------------------- fragments
RULE = '<div class="rule"></div>'
K = 'class="kicker k3"'                              # contrast 6.62 on --bg
SOFTK = 'class="kicker soft"'


def head(kicker, title, stand=None):
    """The heading block every content page opens with. flex:none — it hugs.

    It is a plain full-width block. It used to be a two-cell row whose empty right
    cell was "reserved for the folio numeral", and measuring the naked layouts at
    1600x900 showed what that cost: an empty column 28.7% of the safe area wide on
    all twenty pages that call this helper, and a heading squeezed into the
    remaining 69% — which is what wrapped 'EDITORIAL & VISION' and the card-grid
    standfirst onto a second line with nothing to their right.

    Nothing needed reserving. The folio numeral is chrome: it is positioned
    absolutely, it is not in this flow, and it runs 5-12.8cqh while the content band
    starts at the 12cqh top padding with a short left-aligned kicker. A heading only
    reaches the right edge on its own line, well below the numeral.
    """
    s = '  <div style="flex:none">\n'
    s += f'    <div {K}>{kicker}</div>\n'
    s += f'    <h1 class="h1" style="margin-top:1.2cqh">{title}</h1>\n'
    if stand:
        s += f'    <p class="lead soft" style="margin-top:4cqh">{stand}</p>\n'
    s += '  </div>\n'
    return s


def photocell(seed):
    """An image frame. flex:1 is reserved for exactly this and for a chart plot."""
    return (f'<div data-photocell="1" data-photo-seed="{seed}" style="flex:1;min-height:0;'
            'background:var(--ph);border-radius:var(--r-md);overflow:hidden"></div>')


# Grounds cycle so neighbours never share a colour. Every pair is >=4.7:1.
GT = [('--g0', '--t0'), ('--g3', '--t3'), ('--g1', '--t1'), ('--g2', '--t2')]
# Text-safe scheme colours on --bg, measured: --s3 6.62, --g0 4.71, --g1 4.81.
NUMC = ['var(--s3)', 'var(--g0)', 'var(--g1)']

L = {}

# ------------------------------------------------------- opening and closing
L['cover'] = """
<div class="fit">
  <div {K}>Vol.1 · Issue kicker</div>
  <div class="grp">
    <h1 class="display">STRONG<br>EDITORIAL <em>VOICE</em></h1>
    <div class="kicker soft" style="margin-top:4cqh">yourmagazine.com</div>
  </div>
</div>
""".replace('{K}', K)

# Two facing columns, the way a magazine sets its contents page: the title stands
# alone on the left, the entries run down the right, and a hairline divides them.
# Both columns centre on the same optical axis, so neither leads the other. The
# split is by flex-grow only — the title column takes the narrower share because it
# holds two lines of display, the entry column the wider because it holds six rows
# of running text plus its folios.
L['toc'] = """
<div class="fit" style="flex-direction:row;gap:4.5cqw;align-items:stretch">
  <div style="flex:1;min-width:0;display:flex;flex-direction:column;justify-content:center">
    <h1 class="h1">TABLE OF<br><em>CONTENT</em></h1>
    <div class="kicker soft" style="margin-top:4cqh">What is inside this issue</div>
  </div>
  <div class="vrule"></div>
  <div style="flex:2.1;min-width:0;display:flex;flex-direction:column;justify-content:center">
    {ROWS}
  </div>
</div>
""".replace('{ROWS}', ''.join(
    f'''<div style="display:flex;align-items:baseline;gap:1.3cqw;padding:1.05cqh 0;border-bottom:1px solid color-mix(in srgb,var(--ink) 14%,transparent)">
      <div style="flex:none;color:{NUMC[i % 3]};font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((1.45cqw) * var(--fit, 1));letter-spacing:.04em;font-variant-numeric:tabular-nums">{i+1:02d}</div>
      <h3 class="h3" style="flex:1;min-width:0;font-size:calc((1.95cqw) * var(--fit, 1))">{t}</h3>
      <div style="flex:none;opacity:.55;font-family:var(--fd),var(--cjk-display);font-weight:500;font-size:calc((1.4cqw) * var(--fit, 1));font-variant-numeric:tabular-nums">{p:02d}</div>
    </div>
    ''' for i, (t, p) in enumerate([
        ('Who we are & what we do', 4), ('Editorial concept & vision', 6),
        ('Our gallery & catalogues', 10), ('Publication reach in numbers', 12),
        ('In their words', 13), ('See you next time', 15)])))

# A publication-front opener led by the issue identity rather than the story.
# This is deliberately not another cover: it carries cycle, masthead, date,
# editorial premise and a captioned lead image in one opening composition.
L['issue-opener'] = """
<div class="fit" style="flex-direction:row;gap:4cqw;align-items:stretch">
  <div style="flex:1.12;min-width:0;display:flex;flex-direction:column;justify-content:center">
    <div class="kicker k3">Issue 08 · Autumn 2026</div>
    <h1 class="display" style="font-size:calc((6.2cqw) * var(--fit, 1));margin-top:1.7cqh">THE<br><em>EDIT</em></h1>
    <p class="lead soft" style="margin-top:4cqh">A field guide to the people, objects and quiet decisions shaping independent publishing now.</p>
    <div class="rule" style="margin-top:3cqh"></div>
    <div style="display:flex;gap:2cqw;margin-top:1.4cqh">
      <div style="flex:1;min-width:0"><div class="kicker">Quarterly</div><p class="cap soft" style="margin-top:.5cqh">Volume 03</p></div>
      <div style="flex:1;min-width:0"><div class="kicker">Published</div><p class="cap soft" style="margin-top:.5cqh">September 2026</p></div>
    </div>
  </div>
  <figure style="flex:1;min-width:0;display:flex;flex-direction:column;margin:0">
    {PHOTO}
    <figcaption class="cap soft" style="flex:none;margin-top:1cqh">Cover story · Inside a studio built for slow publishing</figcaption>
  </figure>
</div>
""".replace('{PHOTO}', photocell('issue-opener'))

# The section number, the section title, and what the section actually contains.
# This page used to hold its copy in a left half and leave the right half as an
# empty flow column "for the broad rail" — measured, that was 50% of the safe area
# carrying nothing, and it forced the title to wrap inside it. A rail is a
# `position:absolute` background field: it goes *behind* this content at
# composition time (see ../decoration/PLACEMENT.md) and needs no column reserved
# for it in flow. The page therefore uses its full width, and the space that used
# to be empty now carries the section's own contents list.
L['section-divider'] = """
<div class="fit">
  <div style="flex:none;font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((3.2cqw) * var(--fit, 1));letter-spacing:-.01em;line-height:.9">/01</div>
  <div class="grp">
    <div class="kicker" style="opacity:.85">Section</div>
    <h1 class="display" style="font-size:calc((6.6cqw) * var(--fit, 1));margin-top:1.4cqh">THE <em>STUDIO</em></h1>
    <p class="lead soft" style="margin-top:4cqh">Where the issue is actually made — the room, the working method, and the people who keep the grid honest from first proof to press.</p>
    <div class="rule" style="margin-top:3.4cqh"></div>
    <div class="row" style="gap:3cqw;margin-top:1.6cqh">
      {ITEMS}
    </div>
  </div>
</div>
""".replace('{ITEMS}', ''.join(
    f'''<div>
        <div style="display:flex;align-items:baseline;gap:1cqw">
          <span class="kicker" style="flex:none;color:{NUMC[i % 3]}">{i+1:02d}</span>
          <h3 class="h3" style="flex:1;min-width:0">{t}</h3>
          <span class="cap soft" style="flex:none;font-variant-numeric:tabular-nums">{p}</span>
        </div>
        <p class="cap soft" style="margin-top:.6cqh">{d}</p>
      </div>
      ''' for i, (t, p, d) in enumerate([
        ('The room', '18', 'A north workroom built around one long table.'),
        ('The method', '24', 'One protected block of time, every morning.'),
        ('The people', '31', 'Seven editors and designers, one masthead.')])))

# The closing page carries the details a reader needs after the last story, so the
# half that used to be an empty flow column is now the contact block.
L['close'] = """
<div class="fit">
  <div class="grp" style="justify-content:center">
    <h1 class="display">SEE YOU<br><em>NEXT TIME</em></h1>
    <div class="rule" style="margin-top:4cqh"></div>
    <div class="row" style="gap:3cqw;margin-top:1.8cqh">
      <div>
        <div {K}>Write to us</div>
        <p class="body" style="margin-top:1.1cqh">hello@yourmagazine.com<br>letters@yourmagazine.com</p>
      </div>
      <div>
        <div {K}>Visit the studio</div>
        <p class="body" style="margin-top:1.1cqh">Keilestraat 9<br>3029 BP Rotterdam</p>
      </div>
      <div>
        <div {K}>Keep reading</div>
        <p class="body" style="margin-top:1.1cqh">yourmagazine.com<br>Issue 09 · December</p>
      </div>
    </div>
  </div>
</div>
""".replace('{K}', K)

L['credits-colophon'] = """
<div class="fit" style="flex-direction:row;gap:5cqw;align-items:stretch">
  <div style="flex:.9;min-width:0;display:flex;flex-direction:column;justify-content:center">
    <div>
      <div class="kicker k3">Back matter</div>
      <h1 class="h1" style="margin-top:1.2cqh">CREDITS &<br><em>COLOPHON</em></h1>
    </div>
    <div style="margin-top:4cqh">
      <div class="rule"></div>
      <p class="cap soft" style="margin-top:1.2cqh">Publication Name · Vol. 03, Issue 08<br>Printed in September 2026</p>
    </div>
  </div>
  <div style="flex:1.45;min-width:0;display:flex;flex-direction:column;justify-content:center">
    <div style="display:flex;gap:3cqw">
      <div style="flex:1;min-width:0">
        <div class="kicker">Editorial</div>
        <p class="body" style="margin-top:1.1cqh">Editor in chief<br>Managing editor<br>Features editor<br>Copy editor</p>
        <div class="kicker" style="margin-top:2.4cqh">Contributors</div>
        <p class="body" style="margin-top:1.1cqh">A. Reyes<br>S. Nawaz<br>H. Wynn<br>N. Ortiz</p>
      </div>
      <div style="flex:1;min-width:0">
        <div class="kicker">Creative</div>
        <p class="body" style="margin-top:1.1cqh">Art director<br>Design director<br>Photo editor<br>Production lead</p>
        <div class="kicker" style="margin-top:2.4cqh">Type & paper</div>
        <p class="body" style="margin-top:1.1cqh">Fraunces and Work Sans<br>Natural uncoated stock<br>Vegetable-based inks</p>
      </div>
    </div>
    <div class="rule" style="margin-top:2.8cqh"></div>
    <p class="cap soft" style="margin-top:1.2cqh">Published independently. No part of this issue may be reproduced without written permission. Every copy is numbered and made to be kept.</p>
  </div>
</div>
"""

# ------------------------------------------------------------------- prose
L['editors-note'] = """
<div class="fit" style="flex-direction:row;gap:4cqw;align-items:stretch">
  <figure style="flex:.72;min-width:0;display:flex;flex-direction:column;margin:0">
    <div data-photocell="1" data-photo-seed="editor-portrait" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-md);overflow:hidden"></div>
    <figcaption style="flex:none;margin-top:1.1cqh"><div class="kicker">A. Reyes</div><p class="cap soft" style="margin-top:.35cqh">Editor in chief</p></figcaption>
  </figure>
  <div style="flex:1.55;min-width:0;display:flex;flex-direction:column;justify-content:center">
    <div class="kicker k3">From the editor</div>
    <h1 class="h1" style="margin-top:1.1cqh">A NOTE ON<br><em>MAKING TIME</em></h1>
    <div style="display:flex;gap:2.4cqw;margin-top:4cqh">
      <p class="body" style="flex:1;min-width:0">This issue begins with a simple question: what changes when a publication chooses attention over speed? We visited studios where the calendar follows the work, not the other way around, and found a slower rhythm producing sharper ideas.</p>
      <div style="flex:1;min-width:0">
        <p class="body">Across these pages, editors, designers and makers describe the systems that protect concentration. Their methods differ, but each leaves room for revision, conversation and the useful pause before a page is final.</p>
        <p class="h3" style="margin-top:2cqh;font-style:italic">Read slowly,</p>
        <p class="cap soft" style="margin-top:.5cqh">Ariana Reyes</p>
      </div>
    </div>
  </div>
</div>
"""

L['feature-opener'] = """
<div class="fit" style="flex-direction:row;gap:4cqw;align-items:stretch">
  <div style="flex:1.05;min-width:0;display:flex;flex-direction:column;justify-content:center">
    <div class="kicker k3">Cover story · Field report</div>
    <h1 class="display" style="font-size:calc((5.7cqw) * var(--fit, 1));margin-top:1.5cqh">THE ROOM<br>WHERE IDEAS<br><em>GET QUIET</em></h1>
    <p class="body soft" style="margin-top:4cqh">Inside a small publishing studio designed around deep work, shared tables and the discipline of one finished page at a time.</p>
    <p class="cap" style="margin-top:1.5cqh">Words by S. Nawaz · Photographs by L. Brandt</p>
  </div>
  <figure style="flex:1.15;min-width:0;display:flex;flex-direction:column;margin:0">
    {PHOTO}
    <figcaption class="cap soft" style="flex:none;margin-top:1cqh">The north workroom at first light, before the day’s proofs arrive.</figcaption>
  </figure>
</div>
""".replace('{PHOTO}', photocell('feature-opener'))

L['longform-columns'] = """
<div class="fit">
  <div style="flex:none">
    <div class="kicker k3">Field notes</div>
    <h1 class="h1" style="margin-top:1cqh">THE PRACTICE OF <em>PAYING ATTENTION</em></h1>
  </div>
  <div style="flex:none;display:flex;gap:2.4cqw;margin-top:4cqh">
    <div style="flex:1;min-width:0"><p class="body">The first proof arrives before anyone speaks. It is placed at the centre of the table, where each mark can be seen in relation to the whole page. The ritual is practical, but it also makes the work communal: no single detail is considered in isolation.</p></div>
    <div style="flex:1;min-width:0"><p class="body">Edits begin with rhythm. A headline loses a word; a caption gains the place and date that make an image useful. Only then do margins move. The team treats white space as active material, giving a difficult passage enough room to become legible.</p></div>
    <div style="flex:1;min-width:0"><p class="body">By late afternoon the pages have changed almost invisibly. Nothing calls attention to the labour, yet the issue reads with greater ease. That quiet clarity is the point: an editorial system should make attention possible, then disappear behind the story.</p></div>
  </div>
</div>
"""

L['pull-quote'] = """
<div class="fit">
  <div class="kicker k3" style="flex:none">Feature · The working method</div>
  <div style="flex:none;min-height:0;display:flex;align-items:center;gap:3cqw;margin-top:4cqh">
    <div style="flex:1;min-width:0;display:flex;flex-direction:column;justify-content:center">
      <div class="rule"></div>
      <p class="body" style="margin-top:1.5cqh">The studio’s schedule is built around one protected block of time each morning. Meetings wait; messages collect. During those hours, every editor works on the same sequence of pages.</p>
      <p class="body soft" style="margin-top:1.5cqh">The rule is less about silence than continuity — enough uninterrupted time to see how one decision changes the next.</p>
    </div>
    <blockquote style="flex:1.25;min-width:0;display:flex;align-items:center;justify-content:center;font-family:var(--fd),var(--cjk-display);font-size:calc((3.5cqw) * var(--fit, 1));font-weight:500;font-style:italic;line-height:1.12;letter-spacing:-.012em;text-align:center">“Attention is not a mood. It is something a publication can design for.”</blockquote>
    <div style="flex:1;min-width:0;display:flex;flex-direction:column;justify-content:center">
      <div class="rule"></div>
      <p class="body" style="margin-top:1.5cqh">That continuity shows in the finished issue. Recurring sections keep their cadence, images hold a consistent scale and each caption answers the questions a reader is most likely to ask.</p>
      <p class="cap soft" style="margin-top:2cqh">Mara Okafor<br>Art director</p>
    </div>
  </div>
</div>
"""

L['two-column'] = head('Who we are', 'WHO <em>WE ARE</em>?') + """
  <div class="grp mid">
    <div class="row" style="gap:4cqw">
      <div><div {K}>The studio</div><p class="body" style="margin-top:1.4cqh">A small independent editorial studio making considered magazines, catalogues and brand stories — slow, typographic, and made by hand from a single desk. Six people, one long table, and a shelf of the things we have printed since 2014. We take on four projects a year so that each one gets the attention a printed object needs, and we stay with it from the first grid sketch to the press check.</p></div>
      <div><div {K}>The work</div><p class="body" style="margin-top:1.4cqh">We design the whole object: the grid, the voice, the cover and the last footer — so every margin, headline and image reads as one clear publication. That means the typeface pairing and the caption style are decided together, not bolted on, and the same rules carry from the flagship issue through the supplements, the invitations and the site that announces them.</p></div>
    </div>
  </div>
""".replace('{K}', K)

L['three-column'] = head('The argument', 'THREE <em>POSITIONS</em>') + """
  <div class="grp">
    <div class="row" style="gap:3cqw">
      {COLS}
    </div>
  </div>
""".replace('{COLS}', ''.join(
    f'''<div style="display:flex;flex-direction:column">
        <div class="rule"></div>
        <div {K} style="margin-top:1.4cqh">{n}</div>
        <h3 class="h3" style="margin-top:1cqh">{t}</h3>
        <p class="body soft" style="margin-top:1cqh">{b}</p>
      </div>
      ''' for n, t, b in [
        ('01', 'Voice before volume', 'A strong editorial voice does not shout — it sets one clear intention and holds it across every page.'),
        ('02', 'Type is the system', 'The grid, the serif headline and the running footer are the brand, repeated with discipline.'),
        ('03', 'Made to be kept', 'Printed objects designed to be re-read, not scrolled past and forgotten.')]).replace('{K}', K))

L['numbered-list'] = head('Editorial concept', 'EDITORIAL <em>CONCEPT</em><br>& VISION') + """
  <div class="grp">
    {ROWS}
  </div>
""".replace('{ROWS}', ''.join(
    f'''<div style="display:flex;gap:2cqw;align-items:baseline;padding:2.0cqh 0;border-bottom:1px solid color-mix(in srgb,var(--ink) 14%,transparent)">
      <div style="flex:none;font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((2.2cqw) * var(--fit, 1));color:{NUMC[i % 3]};font-variant-numeric:tabular-nums">{i+1:02d}</div>
      <div style="flex:1;min-width:0"><h3 class="h3">{t}</h3><p class="body soft" style="margin-top:.6cqh">{b}</p></div>
    </div>
    ''' for i, (t, b) in enumerate([
        ('Voice before volume', 'A strong editorial voice does not shout — it sets one clear intention and holds it across every page.'),
        ('Type is the system', 'The grid, the serif headline and the running footer are the brand, repeated with discipline.'),
        ('Made to be kept', 'Printed objects designed to be re-read, not scrolled past and forgotten.')])))

L['big-quote'] = """
<div class="fit">
  <div class="grp mid" style="align-items:center;text-align:center">
    <blockquote style="font-family:var(--fd),var(--cjk-display);font-size:calc((4.85cqw) * var(--fit, 1));font-weight:500;font-style:italic;line-height:1.08;letter-spacing:-.018em">A clear point of view turns every page into part of the same argument.</blockquote>
    <div class="cap soft" style="margin-top:4cqh">Editor in chief · Issue 08</div>
  </div>
</div>
"""

L['quote-cards'] = head('In their words', 'IN THEIR <em>WORDS</em>') + """
  <div class="grp">
    <div class="row" style="gap:2cqw">
      {CARDS}
    </div>
  </div>
""".replace('{CARDS}', ''.join(
    f'''<div style="background:var({g});color:var({t});border-radius:var(--r-lg);padding:3cqh 2cqw;display:flex;flex-direction:column">
        <div style="font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((5cqw) * var(--fit, 1));line-height:.6;opacity:.45">&ldquo;</div>
        <p class="body" style="margin-top:1.4cqh">{q}</p>
        <div style="margin-top:2cqh">
          <div style="font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((1.4cqw) * var(--fit, 1));line-height:1.1">{n}</div>
          <div class="cap" style="opacity:.85;font-size:calc((1.1cqw) * var(--fit, 1))">{r}</div>
        </div>
      </div>
      ''' for (g, t), q, n, r in zip(GT, [
        'The kind of publication you stop and actually read — every page feels considered.',
        'A catalogue that reads like a magazine. Our products have never looked so deliberate.',
        'Clarity with intention. They design the whole object, down to the last footer.'],
        ['H. Wynn', 'N. Ortiz', 'D. Cole'],
        ['Subscriber, London', 'Brand Lead, Lisbon', 'Art Buyer, Berlin'])))

L['card-grid'] = head('What we make', 'WHAT WE <em>MAKE</em>',
                      'Four editorial formats, one consistent voice across every object we publish.') + """
  <div class="grp" style="gap:2cqh">
    <div class="row" style="gap:2cqw">{A}</div>
    <div class="row" style="gap:2cqw">{B}</div>
  </div>
"""

_cards = [('Magazines', 'Issue-based editorial with a fixed grid and a running masthead footer.'),
          ('Catalogues', 'Product galleries that read like a publication, not a price sheet.'),
          ('Brand type', 'Serif-and-sans systems built to carry a voice across pages.'),
          ('Art direction', 'Covers, imagery and rhythm — every margin and headline considered.')]
_cell = ('<div style="background:var({g});color:var({t});border-radius:var(--r-md);padding:2.6cqh 1.8cqw;'
         'display:flex;flex-direction:column"><h3 class="h3">{ti}</h3>'
         '<p class="body" style="margin-top:.6cqh;opacity:.92">{b}</p></div>')
L['card-grid'] = (L['card-grid']
                  .replace('{A}', ''.join(_cell.format(g=GT[i][0], t=GT[i][1], ti=_cards[i][0], b=_cards[i][1]) for i in (0, 1)))
                  .replace('{B}', ''.join(_cell.format(g=GT[i][0], t=GT[i][1], ti=_cards[i][0], b=_cards[i][1]) for i in (2, 3))))

L['pros-cons'] = head('The trade', 'WHAT IT <em>COSTS</em>') + """
  <div class="grp">
    <div class="row" style="gap:4cqw">
      <div style="display:flex;flex-direction:column">
        <div class="rule"></div>
        <div {K} style="margin-top:1.4cqh">Arguments for</div>
        {P}
      </div>
      <div style="display:flex;flex-direction:column">
        <div class="rule"></div>
        <div {K} style="margin-top:1.4cqh">Arguments against</div>
        {C}
      </div>
    </div>
  </div>
""".replace('{K}', K)

_pc = ('<div style="display:flex;gap:1.2cqw;align-items:baseline;padding:1.4cqh 0;'
       'border-bottom:1px solid color-mix(in srgb,var(--ink) 14%,transparent)">'
       '<div style="flex:none;font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((1.6cqw) * var(--fit, 1));color:{c}">{m}</div>'
       '<p class="body" style="flex:1;min-width:0">{b}</p></div>')
L['pros-cons'] = (L['pros-cons']
                  .replace('{P}', ''.join(_pc.format(c='var(--s3)', m='+', b=b) for b in [
                      'One considered narrative gives every decision the same point of reference.',
                      'The grid absorbs new material without a redesign.',
                      'Readers recognise the object before they read a word.']))
                  .replace('{C}', ''.join(_pc.format(c='var(--g0)', m='—', b=b) for b in [
                      'A slower first issue while the system is set.',
                      'Every contributor has to learn the grid.',
                      'Discipline is harder to hold than to describe.'])))

# ------------------------------------------------------------------ numbers
L['fact-box'] = head('Feature companion', 'THE STORY <em>AT A GLANCE</em>') + """
  <div class="grp">
    <div class="row" style="gap:3.2cqw">
      <div style="flex:1.35;min-width:0">
        <div class="rule"></div>
        <p class="lead" style="margin-top:1.6cqh">A compact reading of the people, place and production choices behind this issue’s cover story.</p>
        <p class="body soft" style="margin-top:1.5cqh">Use this page beside a long feature when readers need the essential context without interrupting the narrative.</p>
      </div>
      <aside style="flex:1;min-width:0;background:var(--g2);color:var(--t2);padding:2.6cqh 2cqw">
        <div class="kicker">Fact file</div>
        <div style="margin-top:1.5cqh">
          <p class="cap" style="opacity:.78">Founded</p><p class="h3" style="margin-top:.25cqh">2018, Rotterdam</p>
          <p class="cap" style="opacity:.78;margin-top:1.5cqh">Team</p><p class="h3" style="margin-top:.25cqh">Seven editors and designers</p>
          <p class="cap" style="opacity:.78;margin-top:1.5cqh">Cadence</p><p class="h3" style="margin-top:.25cqh">Four issues each year</p>
          <p class="cap" style="opacity:.78;margin-top:1.5cqh">Print run</p><p class="h3" style="margin-top:.25cqh">6,500 numbered copies</p>
        </div>
      </aside>
    </div>
  </div>
"""

L['stat-boxes'] = head('Publication reach', 'PUBLICATION <em>REACH</em>',
                       'A strong editorial voice does not shout — but it does carry.') + """
  <div class="grp">
    <div class="row" style="gap:1.6cqw">
      {BOXES}
    </div>
  </div>
""".replace('{BOXES}', ''.join(
    f'''<div style="background:var({g});color:var({t});padding:3cqh 1.6cqw;display:flex;flex-direction:column;justify-content:flex-end">
        <div style="font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((4.4cqw) * var(--fit, 1));line-height:.95;letter-spacing:-.02em">{v}</div>
        <div class="cap" style="margin-top:1.2cqh;opacity:.92">{c}</div>
      </div>
      ''' for (g, t), v, c in zip(GT, ['+65,5B', '+85,5%', '+189%'],
                                  ['Impressions across channels', 'Reader retention per issue',
                                   'Year-over-year subscriber growth'])))

L['kpi-grid'] = head('The figures', 'THE <em>FIGURES</em>') + """
  <div class="grp">
    <div class="row" style="gap:2.4cqw">
      {COLS}
    </div>
  </div>
""".replace('{COLS}', ''.join(
    f'''<div style="display:flex;flex-direction:column">
        <div class="rule"></div>
        <div style="margin-top:1.6cqh;font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((4.2cqw) * var(--fit, 1));line-height:.95;letter-spacing:-.02em;color:{c}">{v}</div>
        <div class="kicker" style="margin-top:1.2cqh;color:var(--k3)">{lab}</div>
        <p class="cap soft" style="margin-top:.8cqh">{d}</p>
      </div>
      ''' for v, lab, d, c in zip(['+65,5B', '+85,5%', '+189%', '4.9'],
                                  ['Impressions', 'Retention', 'Growth', 'Rated'],
                                  ['Across every channel this year.', 'Readers who finish an issue.',
                                   'Year-over-year subscribers.', 'Out of five, by readers.'],
                                  ['var(--ink)', 'var(--s3)', 'var(--g0)', 'var(--g1)'])))

# Tiers. The missing core type: a page that prices something. Three peer cards on
# the template's own grounds, each one a price, a cycle and what the tier carries;
# the middle tier takes --g0 so the recommended one reads first without a badge
# or an outline the rest of the template never uses.
_price = [('Reader', '$18', 'each quarter',
           ['Four printed issues, posted', 'Full digital archive', 'Subscriber letters']),
          ('Studio', '$46', 'each quarter',
           ['Everything in Reader', 'Seasonal catalogue supplements', 'Two guest copies', 'Proofs before press']),
          ('Patron', '$120', 'each year',
           ['Everything in Studio', 'Numbered first editions', 'An invitation to the studio'])]
L['pricing'] = head('Subscriptions', 'THREE WAYS TO <em>SUBSCRIBE</em>',
                    'Every tier carries the same issue. What changes is how much of the archive, the catalogue and the studio comes with it.') + """
  <div class="grp">
    <div class="row" style="gap:2cqw">
      {TIERS}
    </div>
  </div>
""".replace('{TIERS}', ''.join(
    f'''<div style="background:var({g});color:var({t});border-radius:var(--r-md);padding:2.8cqh 1.8cqw;display:flex;flex-direction:column">
        <div class="kicker" style="opacity:.9">{name}</div>
        <div style="margin-top:1.4cqh;font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((4.4cqw) * var(--fit, 1));line-height:.95;letter-spacing:-.02em;font-variant-numeric:tabular-nums">{price}</div>
        <div class="cap" style="margin-top:.6cqh;opacity:.9">{cycle}</div>
        <div style="height:1px;background:currentColor;opacity:.28;margin-top:1.8cqh"></div>
        {lines}
      </div>
      ''' for (g, t), (name, price, cycle, items) in zip([GT[1], GT[0], GT[2]], _price)
    for lines in [''.join(
        f'<p class="cap" style="margin-top:1.2cqh;opacity:.92">{it}</p>' for it in items)]))

L['stat-highlight'] = """
<div class="fit mid">
  <div {K} style="flex:none">The one number</div>
  <div class="grp">
    <div style="font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((14cqw) * var(--fit, 1));line-height:.88;letter-spacing:-.03em">+189%</div>
    <div class="rule" style="margin-top:4cqh"></div>
    <p class="lead" style="margin-top:2cqh">Year-over-year subscriber growth across twelve issues, without a single paid placement.</p>
  </div>
</div>
""".replace('{K}', K)

_tbl_rows = [('Magazine — quarterly issue', 'Quarter', '$40'),
             ('Catalogue — seasonal', 'Season', '$32'),
             ('Brand type system', 'Once', '$67'),
             ('Art direction retainer', 'Monthly', '$24')]
L['table'] = head('The product', 'TABLE OF THE <em>PRODUCT</em>',
                  'Our four editorial formats and what each object costs to produce.') + """
  <div class="grp">
    <div style="display:flex;background:var(--g0);color:var(--t0);padding:1.6cqh 1.8cqw 1.1cqh;font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((1.4cqw) * var(--fit, 1));letter-spacing:.02em">
      <div style="flex:2;min-width:0">Format</div><div style="flex:1;min-width:0">Cycle</div><div style="flex:1;min-width:0;text-align:right">Price</div>
    </div>
    {ROWS}
  </div>
""".replace('{ROWS}', ''.join(
    f'''<div style="display:flex;padding:1.5cqh 1.8cqw;border-bottom:1px solid color-mix(in srgb,var(--ink) 12%,transparent)">
      <div class="body" style="flex:2;min-width:0">{a}</div>
      <div class="cap soft" style="flex:1;min-width:0">{b}</div>
      <div class="cap soft" style="flex:1;min-width:0;text-align:right;font-variant-numeric:tabular-nums">{c}</div>
    </div>
    ''' for a, b, c in _tbl_rows))

# ------------------------------------------------------------------- charts
# `%` appears here and in roadmap only, where the number IS the datum.
_bars = [('Q1', '4.2k', 46), ('Q2', '5.8k', 63), ('Q3', '7.1k', 78), ('Q4', '9.2k', 100)]
L['chart-bar'] = head('Reach by quarter', 'REACH BY <em>QUARTER</em>') + """
  <div class="grp" style="height:38cqh">
    <div style="flex:1;min-height:0;display:flex;align-items:flex-end;gap:3cqw">
      {BARS}
    </div>
    <div class="rule" style="margin-top:0"></div>
    <div class="row" style="gap:3cqw;margin-top:1.2cqh">
      {LABS}
    </div>
  </div>
""".replace('{BARS}', ''.join(
    # One quiet ground for the series, the last bar in --g0 to carry the point.
    # Cycling --g0..--g3 across bars puts the palest token (--g2, 1.73:1) on the
    # largest value, which reads as the least important quarter being the biggest.
    f'<div style="flex:1;height:{h}%;background:var({"--g0" if i == len(_bars)-1 else "--g3"})"></div>'
    for i, (_, _, h) in enumerate(_bars))).replace('{LABS}', ''.join(
        f'''<div><div class="kicker" style="color:var(--k3)">{lab}</div>
        <div style="margin-top:.6cqh;font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((2.2cqw) * var(--fit, 1));font-variant-numeric:tabular-nums">{v}</div></div>
        ''' for lab, v, _ in _bars))

L['chart-line'] = head('Twelve issues', 'THE <em>TREND</em>') + """
  <div class="grp" style="height:38cqh">
    <div style="flex:1;min-height:0;display:flex">
      <svg viewBox="0 0 100 46" preserveAspectRatio="none" style="width:100%;height:100%">
        <line x1="0" y1="45.5" x2="100" y2="45.5" stroke="var(--ink)" stroke-opacity=".18" stroke-width=".3"/>
        <line x1="0" y1="23" x2="100" y2="23" stroke="var(--ink)" stroke-opacity=".10" stroke-width=".3"/>
        <polyline points="2,40 16,35 30,36 44,27 58,22 72,14 86,11 98,4" fill="none" stroke="var(--g0)" stroke-width="1.1" vector-effect="non-scaling-stroke"/>
        <polyline points="2,43 16,41 30,38 44,37 58,32 72,30 86,25 98,21" fill="none" stroke="var(--g1)" stroke-width="1.1" stroke-dasharray="3 2" vector-effect="non-scaling-stroke"/>
      </svg>
    </div>
    <div class="row" style="gap:3cqw;margin-top:1.4cqh">
      <div><div class="kicker" style="color:var(--g0)">Subscribers</div><p class="cap soft" style="margin-top:.6cqh">Compounding since issue 04.</p></div>
      <div><div class="kicker" style="color:var(--g1)">Newsstand</div><p class="cap soft" style="margin-top:.6cqh">Steady, seasonal, unhurried.</p></div>
    </div>
  </div>
"""

# A share of a total, in this template's own device: the graded dot matrix from p12.
L['chart-dots'] = head('Where readers are', 'THE <em>SPLIT</em>') + """
  <div class="grp">
    <div class="row" style="gap:3cqw">
      {COLS}
    </div>
  </div>
""".replace('{COLS}', ''.join(
    f'''<div style="display:flex;flex-direction:column">
        <div style="display:flex;flex-wrap:wrap;gap:.5em;font-size:calc((1.6cqw) * var(--fit, 1))">{dots}</div>
        <div class="kicker" style="margin-top:1.8cqh;color:var(--k3)">{lab}</div>
        <div style="margin-top:.6cqh;font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((2.4cqw) * var(--fit, 1));font-variant-numeric:tabular-nums">{pctv}</div>
        <p class="cap soft" style="margin-top:.6cqh">{d}</p>
      </div>
      ''' for dots, lab, pctv, d in [
        (''.join(f'<span class="dot" style="width:1em;height:1em;background:var(--g0);opacity:{1 if i < 6 else .18}"></span>' for i in range(10)),
         'Subscription', '60%', 'Readers who never miss an issue.'),
        (''.join(f'<span class="dot" style="width:1em;height:1em;background:var(--g3);opacity:{1 if i < 3 else .18}"></span>' for i in range(10)),
         'Newsstand', '25%', 'Bought one issue at a time.'),
        (''.join(f'<span class="dot" style="width:1em;height:1em;background:var(--g1);opacity:{1 if i < 2 else .18}"></span>' for i in range(10)),
         'Gifted', '15%', 'Given, then kept.')]))

# --------------------------------------------------------- time and sequence
_steps = [('Commission', 'Brief the voice, set the grid and the issue theme.'),
          ('Compose', 'Headlines, body and imagery placed on one system.'),
          ('Refine', 'Margins, rhythm and the running footer locked.'),
          ('Publish', 'Print, distribute, measure the reach.')]
L['process-steps'] = head('How an issue is made', 'FOUR <em>TURNS</em>',
                          'How an issue moves from a blank grid to a printed object.') + """
  <div class="grp">
    <div class="row" style="gap:2.4cqw">
      {STEPS}
    </div>
  </div>
""".replace('{STEPS}', ''.join(
    f'''<div style="display:flex;flex-direction:column">
        <div class="rule"></div>
        <div style="margin-top:1.4cqh;font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((2.2cqw) * var(--fit, 1));color:{NUMC[i % 3]};font-variant-numeric:tabular-nums">{i+1:02d}</div>
        <h3 class="h3" style="margin-top:1cqh">{t}</h3>
        <p class="body soft" style="margin-top:.8cqh">{b}</p>
      </div>
      ''' for i, (t, b) in enumerate(_steps)))

_tl = [('2023', 'First issue', 'One desk, one grid, ninety-six pages.'),
       ('2024', 'The catalogue', 'The system proves it travels beyond the magazine.'),
       ('2025', 'Brand type', 'A serif-and-sans pairing drawn for the house.'),
       ('2026', 'Twelve issues', 'The footer has not moved once.')]
L['timeline'] = head('The record', 'TWELVE <em>ISSUES</em>') + """
  <div class="grp">
    <div class="rule"></div>
    <div class="row" style="gap:2.4cqw;margin-top:1.6cqh">
      {ITEMS}
    </div>
  </div>
""".replace('{ITEMS}', ''.join(
    f'''<div style="display:flex;flex-direction:column">
        <div style="font-family:var(--fd),var(--cjk-display);font-weight:600;font-size:calc((2.6cqw) * var(--fit, 1));letter-spacing:-.01em;color:{NUMC[i % 3]};font-variant-numeric:tabular-nums">{y}</div>
        <h3 class="h3" style="margin-top:1cqh">{t}</h3>
        <p class="body soft" style="margin-top:.8cqh">{b}</p>
      </div>
      ''' for i, (y, t, b) in enumerate(_tl)))

_road = [('Editorial', [('Issue 13', 0, 40, 0), ('Issue 14', 40, 35, 1), ('Issue 15', 75, 25, 2)]),
         ('Catalogue', [('Spring', 10, 30, 1), ('Autumn', 55, 40, 3)]),
         ('Type', [('Draw', 0, 55, 2), ('Ship', 60, 40, 0)])]
L['roadmap'] = head('The year ahead', 'THE <em>ROADMAP</em>') + """
  <div class="grp" style="gap:1.2cqh">
    <div class="row" style="gap:1.2cqw">
      <div style="flex:none"></div>{QS}
    </div>
    {TRACKS}
  </div>
""".replace('{QS}', ''.join(
    f'<div><div class="kicker soft">{q}</div></div>' for q in ['Q1', 'Q2', 'Q3', 'Q4'])).replace('{TRACKS}', ''.join(
        '''<div style="flex:none;display:flex;flex-direction:column;padding:1.2cqh 0;border-top:1px solid color-mix(in srgb,var(--ink) 14%,transparent)">
        <div class="kicker" style="color:var(--k3)">{name}</div>
        <div style="position:relative;display:flex;flex-direction:column;gap:.6cqh;margin-top:1cqh">
          {bars}
        </div>
      </div>
      '''.format(name=name, bars=''.join(
            # the offset is a margin, not an empty spacer div — an empty box wide
            # enough to matter is a defect even when something else explains it
            f'<div style="display:flex">'
            f'<div style="width:{ln}%;margin-left:{off}%;flex:none;background:var({GT[c][0]});color:var({GT[c][1]});'
            f'border-radius:var(--r-xs);padding:.5cqh .8cqw;font-size:calc((1.1cqw) * var(--fit, 1));white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{lab}</div></div>'
            for lab, off, ln, c in items))
        for name, items in _road))

# ---------------------------------------------------------------- structure
_tiers = [('Surface', ['Cover', 'Contents', 'Feature', 'Back matter']),
          ('System', ['Grid', 'Type scale', 'Colour', 'Footer']),
          ('Production', ['Copy edit', 'Layout', 'Proof', 'Print'])]
L['arch-diagram'] = head('How it is put together', 'THE <em>SYSTEM</em>') + """
  <div class="grp" style="gap:1.6cqh">
    {TIERS}
  </div>
""".replace('{TIERS}', ''.join(
    '''<div style="flex:none;display:flex;gap:2cqw;align-items:stretch;padding-top:1.4cqh;border-top:1px solid color-mix(in srgb,var(--ink) 14%,transparent)">
        <div style="flex:1;min-width:0;display:flex;align-items:center"><div class="kicker" style="color:var(--k3)">{name}</div></div>
        <div style="flex:4.2;min-width:0;display:flex;align-items:stretch;gap:1.2cqw">{cells}</div>
      </div>
      '''.format(name=name, cells=''.join(
            f'<div style="flex:1;min-width:0;background:var({GT[j][0]});color:var({GT[j][1]});'
            f'border-radius:var(--r-sm);padding:1.6cqh 1cqw;display:flex;align-items:center;'
            f'justify-content:center;text-align:center">'
            f'<div class="cap">{c}</div></div>' for j, c in enumerate(cells)))
    for name, cells in _tiers))

# ------------------------------------------------------------ two compared
L['comparison'] = head('Before and after', 'TWO <em>EDITIONS</em>') + """
  <div class="grp">
    <div class="row" style="gap:4cqw">
      <div style="display:flex;flex-direction:column">
        <div class="rule"></div>
        <div {K} style="margin-top:1.4cqh">Before · Issue 08</div>
        <h2 class="h2" style="margin-top:1.2cqh;font-style:italic">Scattered notes</h2>
        <p class="body soft" style="margin-top:1.2cqh">Ideas arrive in fragments, with every conversation restarting the story.</p>
      </div>
      <div style="display:flex;flex-direction:column">
        <div class="rule"></div>
        <div {K} style="margin-top:1.4cqh">After · Issue 09</div>
        <h2 class="h2" style="margin-top:1.2cqh;font-style:italic">A shared edition</h2>
        <p class="body soft" style="margin-top:1.2cqh">One considered narrative gives every decision the same point of reference.</p>
      </div>
    </div>
  </div>
""".replace('{K}', K)

# The loud register. The notch is a clip-path in percentages OF THE HALF, so it
# follows wherever flex puts the split — it is not pinned to the stage.
L['versus'] = head('The choice', 'ONE OR THE <em>OTHER</em>') + """
  <div class="grp">
    <div class="row" style="gap:2cqw">
      <div style="background:var(--g3);color:var(--t3);clip-path:polygon(0 0,100% 0,94% 100%,0 100%);padding:3cqh 3.4cqw 3cqh 2cqw;display:flex;flex-direction:column">
        <div class="kicker" style="opacity:.85">Option A</div>
        <h2 class="h2" style="margin-top:1.2cqh;font-style:italic">Publish faster</h2>
        <p class="body" style="margin-top:1.2cqh;opacity:.92">More issues, thinner each, and a grid that has to bend to whatever arrives.</p>
      </div>
      <div style="display:flex;flex-direction:column;padding:3cqh 0">
        <div {K}>Option B</div>
        <h2 class="h2" style="margin-top:1.2cqh;font-style:italic">Publish better</h2>
        <p class="body soft" style="margin-top:1.2cqh">Fewer issues, each one finished, and a system that survives its own success.</p>
      </div>
    </div>
  </div>
""".replace('{K}', K)

# ------------------------------------------------------------------ imagery
_img_copy = ('<div style="flex:1.15;min-width:0;display:flex;flex-direction:column;justify-content:center">'
             f'<div {K}>The object</div>'
             '<h1 class="h1" style="margin-top:1.2cqh">MADE TO BE <em>KEPT</em></h1>'
             '<p class="body soft" style="margin-top:4cqh">Printed objects designed to be re-read rather than scrolled past — the grid, the voice and the last footer all considered as one publication.</p>'
             '</div>')
L['image-left'] = ('<div class="fit" style="flex-direction:row;gap:4cqw;align-items:stretch">\n  '
                   + f'<div style="flex:1;min-width:0;display:flex">{photocell("feature")}</div>\n  '
                   + _img_copy + '\n</div>\n')
L['image-right'] = ('<div class="fit" style="flex-direction:row;gap:4cqw;align-items:stretch">\n  '
                    + _img_copy + '\n  '
                    + f'<div style="flex:1;min-width:0;display:flex">{photocell("feature")}</div>\n</div>\n')

L['image-grid'] = """
<div class="fit" style="flex-direction:row;gap:4cqw;align-items:stretch">
  <div style="flex:1;min-width:0;display:flex;flex-direction:column;justify-content:center">
    <h1 class="h1">OUR GALLERY<br><em>CATALOGUES</em></h1>
    <p class="body" style="margin-top:4cqh">Six recent objects — magazines, catalogues and brand books made this season.</p>
  </div>
  <div style="flex:1.4;min-width:0;display:flex;flex-direction:column;gap:1.2cqw">
    <div style="flex:1;min-height:0;display:flex;gap:1.2cqw">{A}{B}</div>
    <div style="flex:1;min-height:0;display:flex;gap:1.2cqw">{C}{D}</div>
  </div>
</div>
""".replace('{A}', photocell('gal-1')).replace('{B}', photocell('gal-2')) \
   .replace('{C}', photocell('gal-3')).replace('{D}', photocell('gal-4'))

L['full-bleed-image'] = """
<div data-photocell="1" data-photo-seed="full-bleed" style="position:absolute;inset:0;background:var(--ph);overflow:hidden"></div>
<div class="fit" style="justify-content:flex-end">
  <div style="flex:none;display:flex;gap:3cqw;background:var(--bg);padding:2.6cqh 2cqw">
    <div style="flex:1.5;min-width:0">
      <div class="kicker k3">Photo essay · Plate 04</div>
      <h1 class="h2" style="margin-top:.9cqh">THE LAST PROOF<br><em>BEFORE PRESS</em></h1>
    </div>
    <div style="flex:1;min-width:0">
      <p class="cap soft">A marked colour proof rests beside the finished issue in the production room.</p>
      <p class="cap" style="margin-top:.7cqh">Photograph by L. Brandt</p>
    </div>
  </div>
</div>
"""

L['captioned-gallery'] = """
<div class="fit">
  <div style="flex:none">
    <div class="kicker k3">Photo essay</div>
    <h1 class="h1" style="margin-top:1cqh">THREE VIEWS OF<br><em>THE MAKING TABLE</em></h1>
  </div>
  <div data-peer-center="1" style="flex:none;height:38cqh;min-height:0;display:flex;gap:1.8cqw;margin-top:4cqh">
    {FIGURES}
  </div>
</div>
""".replace('{FIGURES}', ''.join(
    f'''<figure style="flex:1;min-width:0;display:flex;flex-direction:column;margin:0">
      <div data-photocell="1" data-photo-seed="gallery-{i+1}" style="flex:none;aspect-ratio:4/3;background:var(--ph);border-radius:var(--r-md);overflow:hidden"></div>
      <figcaption class="cap soft" style="flex:none;margin-top:1cqh"><span style="color:var(--ink);font-weight:500">{i+1:02d}</span> · {caption}</figcaption>
    </figure>
    ''' for i, caption in enumerate([
        'Morning proofs arranged in reading order.',
        'Crop marks checked against the image sequence.',
        'The signed press sheet ready for production.'])))

L['profile-interview'] = """
<div class="fit" style="flex-direction:row;gap:4cqw;align-items:stretch">
  <figure style="flex:.85;min-width:0;display:flex;flex-direction:column;margin:0">
    <div data-photocell="1" data-photo-seed="profile-interview" style="flex:1;min-height:0;background:var(--ph);border-radius:var(--r-md);overflow:hidden"></div>
    <figcaption style="flex:none;margin-top:1.1cqh"><h2 class="h2">MARA <em>OKAFOR</em></h2><p class="cap soft" style="margin-top:.55cqh">Art director · Rotterdam</p></figcaption>
  </figure>
  <div style="flex:1.35;min-width:0;display:flex;flex-direction:column;justify-content:center">
    <div class="kicker k3">Studio conversation</div>
    <h1 class="h1" style="margin-top:1cqh">“THE GRID SHOULD<br><em>LEAVE ROOM TO LISTEN.”</em></h1>
    <div class="rule" style="margin-top:4cqh"></div>
    <div style="margin-top:1.5cqh">
      <div class="kicker">What does a good system protect?</div>
      <p class="body" style="margin-top:.7cqh">Continuity. It lets an editor follow a thought across several pages without redesigning the conditions each time.</p>
      <div class="kicker" style="margin-top:1.7cqh">When do you break the grid?</div>
      <p class="body" style="margin-top:.7cqh">Only when the story gains something specific — scale, pause or a useful change of pace.</p>
      <div class="kicker" style="margin-top:1.7cqh">What makes an issue feel finished?</div>
      <p class="body" style="margin-top:.7cqh">When every caption earns its place and no page asks the reader to work harder than the story requires.</p>
    </div>
  </div>
</div>
"""

L['catalogue-index'] = """
<div class="fit mid">
  <div style="flex:none;display:flex;align-items:flex-end;gap:3cqw">
    <div style="flex:1.6;min-width:0"><div class="kicker k3">Reference</div><h1 class="h1" style="margin-top:1cqh">CATALOGUE <em>INDEX</em></h1></div>
    <p class="cap soft" style="flex:1;min-width:0">Objects in this issue, listed by series and page. Codes stay fixed; descriptions absorb the available line.</p>
  </div>
  <div style="flex:none;display:flex;gap:2.8cqw;margin-top:4cqh">
    {COLS}
  </div>
</div>
""".replace('{COLS}', ''.join(
    '<div style="flex:1;min-width:0;display:flex;flex-direction:column">' + ''.join(
        f'''<div style="flex:none;padding:1.15cqh 0;border-top:1px solid color-mix(in srgb,var(--ink) 16%,transparent)">
          <div style="display:flex;gap:1cqw;align-items:baseline"><span class="kicker" style="flex:none;color:var(--k3)">{code}</span><h3 class="h3" style="flex:1;min-width:0;font-size:calc((1.65cqw) * var(--fit, 1))">{name}</h3><span class="cap soft" style="flex:none;font-variant-numeric:tabular-nums">{page}</span></div>
          <p class="cap soft" style="margin-top:.45cqh">{desc}</p>
        </div>'''
        for code, name, page, desc in group) + '</div>'
    for group in [
        [('A01', 'First proof', '18', 'Marked offset proof on uncoated stock.'),
         ('A02', 'Binding study', '24', 'Thread-sewn dummy with exposed spine.'),
         ('A03', 'Cover board', '31', 'Warm-grey board, blind embossed.')],
        [('B01', 'Issue archive', '42', 'Twelve numbered editions, 2023–26.'),
         ('B02', 'Type specimen', '48', 'House serif at text and display scales.'),
         ('B03', 'Image ledger', '55', 'Contact sheets from the cover session.')],
        [('C01', 'Press sheet', '64', 'Signed colour reference from production.'),
         ('C02', 'Reader letters', '70', 'Selected correspondence from Issue 07.'),
         ('C03', 'Colophon card', '78', 'Credits printed as a removable insert.')]]) )

L['team'] = head('The masthead', 'THE <em>MASTHEAD</em>', 'The hands behind the issue.') + """
  <div class="grp">
    <div class="row" style="gap:1.6cqw">
      {PEOPLE}
    </div>
  </div>
""".replace('{PEOPLE}', ''.join(
    f'''<div style="display:flex;flex-direction:column">
        <div data-photocell="1" data-photo-seed="team-{i+1}" style="aspect-ratio:3/2;background:var(--ph);border-radius:var(--r-md);overflow:hidden"></div>
        <h3 class="h3" style="margin-top:1.2cqh">{n}</h3>
        <p class="cap soft" style="margin-top:.2cqh">{r}</p>
      </div>
      ''' for i, (n, r) in enumerate([('A. Reyes', 'Editor-in-Chief'), ('M. Okafor', 'Art Director'),
                                      ('L. Brandt', 'Designer'), ('S. Nawaz', 'Writer')])))


# ------------------------------------------------------------------- emit
# Pages whose whole content block sits in the middle of the safe area rather than at
# the top of it. These carry a figure or a stat row under a short heading, so
# top-anchoring left the bottom half of the stage empty. `.grp.mid` centres the group
# under a heading; this centres everything, heading included.
CENTRED = {'chart-dots', 'arch-diagram', 'catalogue-index', 'stat-highlight', 'stat-boxes'}


def emit():
    for name, body in L.items():
        body = body.strip()
        # Every layout must sit inside .fit — that div is where the safe area lives.
        # The head()-built bodies are fragments, so wrap them here rather than
        # repeating the wrapper in twenty places.
        if 'class="fit' not in body:
            cls = 'fit mid' if name in CENTRED else 'fit'
            body = f'<div class="{cls}">\n' + body.rstrip() + '\n</div>'
        elif name in CENTRED:
            # catalogue-index and stat-highlight write their own .fit above; the
            # centring is inlined there. Anything else in CENTRED that grows its own
            # wrapper must do the same rather than silently losing the centring.
            assert 'class="fit mid"' in body, \
                f'{name} writes its own .fit — put the `mid` class there'
        assert 'class="fit' in body, name
        html = (HEAD
                + f'<div class="deck"><div class="slide"><div class="stage" data-slot="{name}">\n'
                + body + '\n'
                + '</div></div></div>\n</body></html>\n')
        html = '\n'.join(line.rstrip() for line in html.splitlines()) + '\n'
        (HERE / f'{name}.html').write_text(html)
    print(f'{len(L)} layouts written')
    for n in sorted(L):
        print(' ', n)


if __name__ == '__main__':
    emit()
