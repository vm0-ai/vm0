# editorial-magazine — naked layouts

40 layouts, text only. No decoration, no colour fields, no measured geometry.
Pair one of these with [`../decoration/PLACEMENT.md`](../decoration/PLACEMENT.md) to
build a slide.

The set is this template's own: **13 compositions lifted from the 15 pages of
`../layouts/`**, **2 from `../composition-recipes.html`**, **14 added**
for general presentation jobs absent from the reference, and **11 added for distinct
editorial-production jobs**. It is
not bloom's list — bloom's ornaments bleed off the stage and five of its seventeen
pages are full colour fields; neither is true here, and three of its layouts exist to
solve problems this template does not have.

## The one rule

**No sizing in container or viewport units on anything that holds text.**
Verified across all 40: zero `width` / `max-width` / `min-width` / `height` /
`max-height` / `min-height` / `left` / `top` / `right` / `bottom` / `flex` / `inset`
values in `cqw`, `cqh`, `px`, `vw` or `vh`.

This covers `flex-basis` — `flex:0 0 4cqw` freezes exactly the way a `width` does. It
also covers `min-height`, which the playbook's own regex misses: the reference's stat
boxes carry `min-height:23cqh`, and that is a frozen height with a different name.

Four exemptions, all checkable:

- **placement** of an out-of-flow element — `left/top/right/bottom` on something that
  is `position:absolute`. That is where it goes, not how big it is.
- **`height:1px`** / **`width:1px`** for a hairline. A hairline is a hairline at any
  scale, and the reference writes it the same way.
- **`em`** on ornaments that hold no prose — the proportion dots in `chart-dots`.
  `em` scales with the type around it, so it cannot freeze a text box.
- **`%`** in `chart-bar` and `roadmap` only, where the number *is* the datum. A bar
  whose height is 78 % is reporting 78, not making a layout choice.

Everything else stretches. Columns are `flex:1`. The safe area is set once, by the
padding on `.fit`.

## The safe area

```
padding: 12cqh 6cqw 9cqh
```

Every number measured on this template's own reference, not inherited:

| edge | value | why |
|---|---|---|
| left / right | `6cqw` | the reference's own left margin on 10 of its 15 pages; no page puts content nearer either edge, and the audit's `outsideSafeArea` constant is this number |
| top | `12cqh` | the top-corner folio numeral runs 5cqh → 12.8cqh, so full-width content starts below it |
| bottom | `9cqh` | clears the running footer — rule at 3.55cqh, page number at 3.2cqh, footer kicker at 3.0cqh |

**A rail changes it, and only through a class.** `.fit.rail-l` / `.fit.rail-r` indent
to `14cqw`; `.fit.field-l` / `.fit.field-r` clear a broad field at `52cqw`. On all four
narrow-rail pages the reference moves its margin from 6cqw to 13–14cqw, and a naked
layout dropped onto a rail without that class puts the first character of every line on
the stripe. Overlay it and you see it immediately; no probe reading changes.

## Top-anchored, not centred

The content group under the heading is `justify-content:flex-start` with `margin-top:8cqh`.

Measured on the reference: the gap from the heading block to the content is **14.2cqh
median** (n=6, range 10.8–15.9), and the bottom of the stage is left **empty — 29.6cqh
median, range 13–50.1**. That trailing whitespace is not slack; it is where the folio
numeral and the low-left dot sit. Centring the group both loses the rhythm and crowds
the decoration. `flex:1` still lets a dense page grow downward into it.

**Two pages are exceptions and carry `.grp.mid`**, which centres the group in the safe
area instead:

- `big-quote` — a standalone statement page. There is no heading above it, so there is
  no heading-to-content rhythm to keep, and top-anchoring left the quote in the upper
  third with the bottom half of the stage blank.
- `two-column` — a short body block under a heading. Its reference copy is now long
  enough to carry the band (roughly six lines a column, up from three); centring what is
  left removes the gap that opened between the copy and the footer.

The default stays top-anchored. `.mid` only has an effect when the content does not
already fill the band, so it is inert on a dense page.

## Files

`_shell.html` is the `<head>`, fonts, colour-system link and class definitions. Not a
slide. `_build.py` regenerates every layout from it, so a fix to the shell lands in all
40 at once — edit the builder, not the output. `_contact_sheet.py` concatenates them
into one navigable deck for review.

**Opening and closing** · `cover` `issue-opener` `toc` `section-divider` `close`
`credits-colophon`

**Editorial prose** · `editors-note` `feature-opener` `two-column` `three-column`
`longform-columns` `numbered-list` `big-quote` `pull-quote` `quote-cards` `card-grid`
`pros-cons`

**Numbers and reference** · `fact-box` `stat-boxes` `kpi-grid` `stat-highlight` `pricing`
`table` `catalogue-index`

**Charts** · `chart-bar` `chart-line` `chart-dots`

**Time and sequence** · `process-steps` `timeline` `roadmap`

**Structure** · `arch-diagram`

**Two things compared** · `comparison` `versus`

**Imagery** · `image-left` `image-right` `image-grid` `full-bleed-image`
`captioned-gallery` `profile-interview` `team`. Issue and feature openers, the editor's
note and these seven layouts use content image frames that delete cleanly. When the
source has no imagery, use a prose layout; do not leave an empty box.

`toc` is two facing columns: the title alone on the left, the six entries down the
right, a hairline between them, both columns centred on the same axis. Its row — a number, a label, a right-aligned figure, a
hairline under each — can also carry a compact key–value list. There is no separate
`spec-list`; it would be `toc` with different sample copy rather than a new composition.

### Why the original 13 general-purpose additions are here

These are the jobs genuinely absent after the 13 reference compositions and the two
recipes were accounted for. Each is expressed with this template's serif hierarchy,
paper ground, hairlines, and `--g0 --g3 --g1 --g2` rhythm; none imports bloom geometry.

| added layout | missing communication job |
|---|---|
| `three-column` | three quiet peer arguments; `card-grid` was the only three-up option and forced fills |
| `pros-cons` | advantages and trade-offs, which are not an option comparison |
| `versus` | one emphatic binary choice; `comparison` is intentionally neutral |
| `kpi-grid` | a ruled alternative to the reference's filled stat cards |
| `stat-highlight` | one number carrying the whole page |
| `chart-bar` | category magnitudes |
| `chart-line` | change over time |
| `chart-dots` | part-to-whole composition in the reference dot vocabulary |
| `pricing` | tiers with a price, a cycle and what each one carries; nothing else in the set prices anything |
| `timeline` | dated milestones |
| `roadmap` | phases across several tracks |
| `arch-diagram` | layered systems or operating-model structure |
| `image-left` | one supported image leading into prose |
| `image-right` | prose leading into one supported image |

### Why the 11 editorial additions are here

These are publication jobs, not mirrored or recoloured variants. Each changes the
content contract, reading order and proportions of the page.

| added layout | editorial job |
|---|---|
| `issue-opener` | masthead, issue cycle, premise and lead image before the feature sequence |
| `editors-note` | signed address from the editor, with portrait and letter-like reading order |
| `feature-opener` | reported-story headline, deck, byline, hero image and caption |
| `longform-columns` | continuous article copy in three readable columns |
| `pull-quote` | a central quotation interrupting supporting article copy |
| `full-bleed-image` | one full-page image with a text-safe title and caption treatment |
| `captioned-gallery` | several images whose captions remain individually attributable |
| `profile-interview` | portrait, identity and question-and-answer sequence |
| `fact-box` | compact contextual facts beside an article summary |
| `catalogue-index` | dense indexed objects with stable codes and page locators |
| `credits-colophon` | editorial credits, contributors and production specifications |

## Which repeated component attaches to which layout

The layouts are naked on purpose, but several describe a **set of peer items**, and in
this template every item in such a set carries the same content component. Copyable
markup is in [`../decoration/item-sets.html`](../decoration/item-sets.html). Tiles,
badges, nodes, dot matrices and photocells are content/data structure and are excluded
from the optional-decoration count.

| layout | attach |
|---|---|
| `card-grid` | one `tile` per card, ground cycling `--g0 --g3 --g1 --g2` |
| `numbered-list` | one `badge` per row, carrying that row's number |
| `process-steps` | one `node` per step — the notched pentagon `clip-path` |
| `chart-dots` | the graded dot matrix; it *is* the chart |
| `team` `image-*` `issue-opener` `editors-note` `feature-opener` `full-bleed-image` `captioned-gallery` `profile-interview` `section-divider` | one `photocell` per frame |
| `two-column` `three-column` `comparison` `pros-cons` `table` `toc` `timeline` | nothing — these hold prose, and they already carry the hairline rules |
| `quote-cards` `stat-boxes` `versus` | nothing — the card *is* the colour; a mark on top of it is noise |

## Ruled or filled — every peer row has both

The menu deliberately includes both ruled and filled treatments, so an agent does not
put the same horizontal line on every slide. Each of these content types has two
treatments, and neither is more on-template than the other:

| content | ruled | filled |
|---|---|---|
| three peer columns | `three-column` | `card-grid` |
| a row of numbers | `kpi-grid` | `stat-boxes` |
| two things compared | `comparison` | `versus` |
| a sequence | `process-steps` (naked) | `process-steps` + `node` |

The filled versions cycle `--g0 --g3 --g1 --g2` so neighbours never share a colour.
Pick the filled one when the items are short and parallel, when the ruled version reads
thin, or simply when the previous slide was ruled.

## Colour, measured on this template's paper

`--bg` is `#FFFDF8`.

| token | contrast on paper | use as |
|---|---|---|
| `--ink` 14.89 · `--ka` 14.89 · `--soft` 6.78 · `--s3` 6.62 · `--k3` 6.62 · `--g1` 4.81 · `--g0` 4.71 | pass | text or fill |
| `--accent` 2.18 · `--s1` 2.25 · `--s2` 1.73 · `--g2` 1.73 | fail | **fill only** |
| `--surface` 1.02 · `--ph` 1.16 | fail | **fill only, and all but invisible** |

Two of these differ from bloom and are worth stating:

- **`--s3` is a text colour here** (6.62:1) where bloom's equivalent fails at 2.5:1.
  For a coloured numeral on paper cycle **`--s3` `--g0` `--g1`** — all three pass.
  `--accent` and `--s1` do not: the reference's contents page set its numerals in them
  at 2.18 and 2.25, which were the deck's only four contrast failures. Fixed in the
  example as part of this split.
- **`--surface` is `#FFFFFF` on a `#FFFDF8` page — 1.02:1.** Not a panel colour.
  Panels here are no fill plus a hairline, or a `--g?` ground with the matching `--t?`.

On a `--g?` ground use the matching `--t?` (4.79 / 6.73 / 4.89 / 10.45). Never `--ka`
on a ground — it reads **2.25:1** on `--g3`.

`--ink` grounds nothing. There is no large dark panel in this reference, and one reads
as a photo placeholder.

## Verified

The reference probe baseline at 1600×900 is `pages 15`, `decks 1`,
`navigableSlides 15`, `orphanSlides 0`, `indirectSlides 0`, `overflow 0`,
`outsideSafeArea 0`, `aboveChromeBand 16`, `columnsMisaligned 0`, `lowContrast 0`,
`boxesUnderfilledV 6`, and `boxesUnderfilledH 5`. Therefore `aboveChromeBand` and the
two underfill counts are **report-only for generated decks**: the reference is not zero.
The safe-area and navigation readings are valid gates because the reference is zero.

All 40 naked layouts, at 1600×900, with the colour system resolved:

```
overflow 0 · outsideSafeArea 0 · aboveChromeBand 0 · columnsMisaligned 0
lowContrast 0 · boxesUnderfilledV 0 · boxesUnderfilledH 0
orphanSlides 0 · indirectSlides 0 · navigableSlides == pages
```

Plus the static sizing audit at zero, every peer row stressed with an injected sentence
and equalising, and every layout looked at rendered at full size.

Two further geometric checks, measured by [`_probe_gaps.js`](_probe_gaps.js) on the
contact sheet, both **0 across all 40**:

- **empty wide column** — a flow box holding no text, no ground, no border and nothing
  painted inside it, wider than 8 % of the safe area. There is no such thing as a
  structural placeholder here: if a column has no content, the content beside it uses
  the width.
- **narrow-box wrap** — text wrapping onto a second line inside a box narrower than the
  safe area while the space to its right, out to the safe-area edge, is empty. A
  heading is only allowed to stop short when something real sits beside it.

The same probe on the previous build reads `29` and `5`, so it is calibrated on both
sides rather than only on the fixed one. What it caught: `head()` reserved an empty
28.7 %-wide cell "for the folio numeral" on twenty pages and squeezed their headings
into the remaining 69 %; `close` and `section-divider` each left half the stage as an
empty flow column; `chart-bar` ended with a trailing spacer; `roadmap` drew its gantt
offsets as empty divs; `full-bleed-image` padded its caption with one.
