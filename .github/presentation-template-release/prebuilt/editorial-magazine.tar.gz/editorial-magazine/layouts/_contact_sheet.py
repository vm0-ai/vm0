#!/usr/bin/env python3
"""Concatenate every naked layout into one navigable deck, each slide labelled.

Not part of the delivered template — this is the review artefact for the contact
sheet, and the thing I look at to check every layout rendered.
"""
import pathlib
import re
import sys

HERE = pathlib.Path(__file__).parent
SHELL = (HERE / '_shell.html').read_text()
HEAD = SHELL.split('<body>')[0].replace('naked layout', 'contact sheet') + '<body>\n'

LABEL = ('<div style="position:absolute;left:0;top:0;background:var(--ink);color:var(--bg);'
         'font-family:var(--fb),monospace;font-size:calc((1.1cqw) * var(--fit, 1));font-weight:600;letter-spacing:.08em;'
         'padding:.7cqh 1.2cqw;z-index:90">{n}</div>')

names = sorted(p.stem for p in HERE.glob('*.html') if not p.stem.startswith('_'))
# Show them in reading order, not alphabetical.
ORDER = ['cover', 'issue-opener', 'toc', 'editors-note', 'section-divider',
         'feature-opener', 'close', 'credits-colophon',
         'two-column', 'three-column', 'longform-columns', 'numbered-list',
         'big-quote', 'pull-quote', 'quote-cards', 'card-grid', 'pros-cons',
         'comparison', 'versus', 'fact-box',
         'stat-boxes', 'kpi-grid', 'stat-highlight', 'pricing', 'table',
         'chart-bar', 'chart-line', 'chart-dots',
         'process-steps', 'timeline', 'roadmap', 'arch-diagram',
         'image-left', 'image-right', 'image-grid', 'full-bleed-image',
         'captioned-gallery', 'profile-interview', 'catalogue-index', 'team']
missing = set(names) - set(ORDER)
assert not missing, f'layout missing from ORDER: {missing}'
assert set(ORDER) <= set(names), f'ORDER names with no file: {set(ORDER) - set(names)}'

def extract_stage(html, name):
    """Pull out exactly the <div class="stage">...</div> subtree.

    A non-greedy regex stops at the first '</div></div></div>' it meets, which for a
    layout with three nested closers in the middle truncates the stage and leaves the
    markup unbalanced. The slides after it then nest one level deeper — they render
    perfectly and the arrow keys cannot reach them. Count the tags instead.
    """
    start = html.index('<div class="stage"')
    depth, i = 0, start
    for m in re.finditer(r'<(/?)div\b[^>]*>', html[start:]):
        depth += -1 if m.group(1) else 1
        if depth == 0:
            i = start + m.end()
            return html[start:i]
    raise AssertionError(f'unbalanced stage in {name}')


slides = []
for n in ORDER:
    stage = extract_stage((HERE / f'{n}.html').read_text(), n)
    # label goes inside the stage, above everything
    stage = stage.replace('>', '>' + LABEL.format(n=n), 1)
    slides.append(f'<div class="slide">{stage}</div>\n')

out = (HEAD + '<div class="deck">\n' + ''.join(slides) + '</div>\n'
       + '<script>\n'
       + 'document.addEventListener("keydown",e=>{\n'
       + '  const deck=document.querySelector(".deck");\n'
       + '  const slides=[...deck.children].filter(n=>n.classList.contains("slide"));\n'
       + '  const h=window.innerHeight; let i=Math.round(deck.scrollTop/h);\n'
       + '  if(e.key==="ArrowDown"||e.key==="ArrowRight")i=Math.min(i+1,slides.length-1);\n'
       + '  else if(e.key==="ArrowUp"||e.key==="ArrowLeft")i=Math.max(i-1,0); else return;\n'
       + '  e.preventDefault(); slides[i].scrollIntoView({behavior:"instant"});\n'
       + '});\n</script>\n</body></html>\n')
(HERE / '_contact-sheet.html').write_text(out)
print(f'{len(slides)} slides -> _contact-sheet.html')
