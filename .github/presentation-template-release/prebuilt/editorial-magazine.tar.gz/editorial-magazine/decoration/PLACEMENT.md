# editorial-magazine — where the decoration goes

Every number here is measured from the original reference deck at 1600×900, 15 pages.
The visual vocabulary is classified before it is counted: the **dot system is the
only optional decoration**; rails and photocells are layout structure; tiles, badges,
nodes, pills and dot matrices carry content or data; folio numerals, the rotated
masthead and the running footer are fixed chrome.

Pair these rules with a naked layout from `../layouts/`.

---

## Reference probe baseline

At 1600×900 the 15-page reference reads: `decks 1`, `navigableSlides 15`,
`orphanSlides 0`, `indirectSlides 0`, `overflow 0`, `outsideSafeArea 0`,
`aboveChromeBand 16`, `columnsMisaligned 0`, `lowContrast 0`, `surfaceUses 3`,
`boxesUnderfilledV 6`, `boxesUnderfilledH 5`, and `fullBleedPages 0`.

Only reference-zero or separated-distribution checks may gate generated decks.
`aboveChromeBand`, `surfaceUses`, and both underfill counts are report-only here; a
hard zero for any of them would reject this template's own reference. The fixed
horizontal safe-area constant is 6 %, declared as `data-safe-area="0.06"`; it is not
derived from each page's padding.

---

## 0. The two places bloom's rules do not transfer

| | bloom | editorial-magazine |
|---|---|---|
| graphic elements crossing the stage edge | **93.9 %** bleed outward | **0 %** in the reference |
| full-bleed colour pages | 5 of 17 (29 %) | **0 of 15** |

**Nothing bleeds.** No reference graphic crosses the stage boundary.
Ten of them sit *flush* to an edge — left edge at exactly 0, or right edge at exactly
100 % — and are cropped by nothing. If you carry bloom's "hang it off the edge,
0.27–0.83× its own width" rule into this template you will break its single most
recognisable device.

**No page is a full colour field.** The ground colour is never on `.stage`. Where
bloom turns a whole page one colour, this template runs a colour field down *one side*
and leaves the rest paper. That is the `rail`, below, and it does the job that
full-bleed does in bloom.

---

## 1. `rail` — signature background field, not decoration. One per page, on 10 of 15 pages.

A colour field pinned to one vertical edge, running the **full height** of the stage,
square corners, behind the content.

```html
<div data-background-field="rail" style="position:absolute;left:0;top:0;width:7cqw;height:100cqh;
     background:var(--g0);color:var(--t0);border-radius:0;z-index:1"></div>
```

Two registers, and the choice is not free — it follows the page's job:

| register | width | pages | what it is for |
|---|---|---|---|
| **narrow** | 7–8cqw | 4 — cover, toc, a prose page, the table | a margin stripe. Content clears it. |
| **broad** | 34–46cqw | 6 — the three section dividers, a numbered list, the process page, the closing page | a half-page field. Content sits **on** it, in `--t?`. |

Measured widths: narrow `7, 7, 7, 8`; broad `34, 38, 42, 46, 46, 46`.

Rules that hold across all ten:

- **Exactly one rail per page, or none.** Never two. Never a top or bottom band.
- `top:0; height:100cqh; border-radius:0` — always. A rail that stops short, or has a
  rounded corner, is not this motif.
- Flush to the edge, never past it.
- **A narrow rail pushes the content in.** On the four narrow-rail pages the content's
  left margin moves from the usual 6cqw to 13–14cqw. Do not hand-edit the padding —
  add the class the shell already defines:

  | rail | class on `.fit` | clears to |
  |---|---|---|
  | narrow, left | `rail-l` | 14cqw |
  | narrow, right | `rail-r` | 14cqw |
  | broad, left | `field-l` | 52cqw |
  | broad, right | `field-r` | 52cqw |

  A naked layout dropped onto a rail without its class puts the first character of
  every line on the stripe. It is obvious the moment you overlay it, and **not one
  probe reading changes** — which is the whole reason the class exists.
- **A broad rail carries the content of that half.** Put the copy inside the rail div
  and colour it with the matching `--t?`. The other half stays paper and takes the
  divider photocell, or stays empty.
- Grounds observed: `--g0` ×4, `--g3` ×4, `--g1` ×1. Cycle them; do not repeat the
  previous page's ground.

**On a rail, a kicker takes `color:inherit` or the matching `--t?`, never `--ka`.**
`--ka` is `#262626` and reads **2.25:1** on `--g3` — measured, illegible. This is the
one bloom trap that does transfer exactly.

---

## 2. `dot-system` — the only optional decoration. Pair on 13 of 15 pages.

Two flat circles set together near a top corner: one large, one small, the small one
up and to the left of the large one.

```html
<div data-decoration="dot" style="position:absolute;right:6cqw;top:6cqh;width:1.3cqw;height:1.3cqw;
     background:var(--accent);border-radius:50%;z-index:3"></div>
<div data-decoration="dot" style="position:absolute;right:9.5cqw;top:5cqh;width:0.65cqw;height:0.65cqw;
     background:var(--accent);border-radius:50%;z-index:3"></div>
```

The geometry is nearly invariant across the deck — this is worth copying literally:

- large dot **1.2–1.3cqw**, small dot **0.6–0.65cqw**. The ratio is **2:1**, every time.
- the small one sits **≈2.8cqw to the left** and **≈1cqh above** the large one.
- the pair sits in the **top-right** corner on 11 pages (large at `right:6cqw; top:6cqh`),
  **top-left** on the closing page, and drops to `top:33cqh` on the cover only.
- fills: `--accent` mostly, `--s3` and `--s1` occasionally. These are fill-only tokens
  (2.18:1, 6.62:1, 2.25:1 on paper) and a dot is a fill, so they are correct here and
  wrong as text.

Frequency: **31 loose dots over 15 pages — 18 large, 13 small.** Two pages (the numbered
list and the process page) carry a lone large dot with no partner; both are broad-rail
pages where the pair would land on the field.

bloom lost its small ornaments — 0.214 → 0.022 per page — because their frequency was
never stated. State this one: **every page gets the pair unless a broad rail occupies
that corner.**

### The third dot

Three pages (team, card grid, quotes) carry one extra `1cqw` dot at `left:6cqw;
bottom:16cqh` — low, on the left. All three are **rail-less** pages whose content stops
above 76 % of the stage. It is the device that keeps an unrailed page from looking
unanchored, and it only works where the lower-left is genuinely empty.

**Overlay before you use it.** Do not add the low dot to a layout whose content runs to
the bottom of the safe area — it will land on the text. This is the check bloom got
wrong twice in the opposite direction.

---

## 3. `folio-numeral` — fixed chrome, 15 of 15 pages. No exceptions.

A large serif number in the display face, set in a corner, `line-height:.9`.

```html
<div style="position:absolute;right:6cqw;top:8cqh;font-family:var(--fd);font-weight:600;
     font-size:3cqw;letter-spacing:-.01em;line-height:.9;color:var(--ka);z-index:3">/005</div>
```

Two forms, both present in the reference:

- **`/00N`** — the running section number, `3–3.2cqw`. Content pages and dividers.
- **`//20<br>//26`** — the year, two lines, `4–5cqw`. Cover, closing page, and two
  interior pages.

Placement: a corner, `6–11cqw` in from the side, either `top:8–9cqh` or `bottom:9cqh`.
It goes on the side the heading does **not** reach — on every reference page carrying a
top-corner numeral the heading stops short of it (headings run 48–64cqw inside an 88cqw
safe area). The naked layouts reserve that cell structurally, so drop the numeral into
the empty right cell of the heading row and it cannot collide.

On a broad rail the numeral goes **inside** the rail, in `--t?`, at `left:6cqw;top:8cqh`.

**The dot pair grazes the numeral, and that is correct.** Where both sit in the same
top corner their boxes overlap by 20.8 × 2.8px at 1600×900 — on 4 of the 12 reference
pages that carry a numeral, with identical geometry every time. The overlap is in the
numeral's ascender whitespace (`line-height:.9`), not on the glyph. Do not "fix" it by
moving either one; it is a deliberate tight setting and the reference commits it more
often than any generated deck will.

---

## 4. `rotated-masthead` — fixed chrome, 3 of 15 pages

The wordmark, turned on its side against the left edge. Cover, gallery, closing page.

```html
<div style="position:absolute;left:3.2cqw;top:70cqh;transform-origin:0 0;
     transform:rotate(-90deg) translate(-50%,0);font-family:var(--fd);font-weight:500;
     font-size:1.2cqw;letter-spacing:.30em;text-transform:uppercase;color:var(--soft);
     white-space:nowrap;z-index:3">Publication Name</div>
```

`top:66–70cqh` with the rotation origin at the top-left, so the text reads bottom-to-top
and ends near the vertical middle. On the cover it takes `--t0` because it lies on the
narrow rail; elsewhere `--soft`. Use it on opening and closing pages, not on dense ones.

---

## 5. Repeated content components, not optional decorations

Nothing here is sprinkled. Every component belongs to a specific page type, and where
it appears **every item in the set gets one**. Copyable content markup is in
[item-sets.html](item-sets.html). These items are shown for implementation fidelity but
are excluded from `decoration_count`.

| mark | count | attaches to | rule |
|---|---|---|---|
| `tile` | 4 | `card-grid` | one per card, `--g0→--g3` cycling, 5cqw square, 24-grid icon inside |
| `badge` | 3 | `numbered-list` | one per row, the row's number; reference 5cqw, copyable form `2.5em` at `2cqw` type |
| `node` | 4 | `process-steps` | one per step; reference 6.6cqw, copyable form `3.3em` at `2cqw` type, with the notched pentagon `clip-path` |
| `pill` | 1 | `image-grid` / gallery | at most one per deck, a capsule label |
| `dot-matrix` | 15 dots | `chart-dots` / stats | 5×3 grid, `2.4cqw` dots, opacity stepping `1 → .2` |
| `photocell` | 14 | dividers, `team`, `image-*` | the image frame, `--ph`, `var(--r-md)` corners |

The pentagon is this template's own shape and does not exist elsewhere:

```css
clip-path: polygon(0 0,100% 0,100% 60%,50% 100%,0 60%)
```

---

## 6. Do not invent

The classified vocabulary above is complete: optional decoration **dot-system**;
structure **rail, photocell**; chrome **folio-numeral, rotated-masthead, running footer**;
content/data components **tile, badge, node, pill, dot-matrix**. Do not promote a
rectangle, card, tile or grid cell into decoration merely to increase the count.

Do not add arches, quarter-circles, starbursts, blobs, waves, gradients, drop shadows,
outlined boxes, or a rounded rectangle behind a heading. `--r-lg` corners appear on
exactly one thing in this reference — the quote cards.

**A kicker is not a chip.** The kicker, the page number, the running head and the
standfirst are plain text on all 15 pages: no background, no border, no pill. A kicker
appears on every slide, so boxing it adds one false chip per slide and on its own
doubles this template's labelled-box count. Only `badge`, `tile`, `pill` and the rail
carry a fill.

---

## 7. Colour, measured against this template's paper

`--bg` is `#FFFDF8`. Contrast of every token against it:

| token | ratio | use as |
|---|---|---|
| `--ink` 14.89 · `--ka` 14.89 · `--soft` 6.78 · `--s3` 6.62 · `--k3` 6.62 · `--g1` 4.81 · `--g0` 4.71 | pass | text or fill |
| `--accent` 2.18 · `--s1` 2.25 · `--s2` 1.73 · `--g2` 1.73 | fail | **fill only** |
| `--surface` 1.02 · `--ph` 1.16 | fail | **fill only, and barely visible** |

Two consequences, both of which the reference deck itself got wrong before this split:

- **`--s3` is a text colour in this template** (6.62:1), unlike in bloom where its
  equivalent fails at 2.5:1. Use it for coloured numerals. `--accent` and `--s1` are
  not: the reference's contents page set its numerals in them at 2.18 and 2.25, and
  those four numerals were the deck's only contrast failures. They are now `--g0` and
  `--g1`. For a coloured numeral on paper, cycle **`--s3` `--g0` `--g1`**.
- **`--surface` is `#FFFFFF` on a `#FFFDF8` page — 1.02:1.** It is not a panel colour;
  it is invisible. The reference uses it three times, as a card fill and as table zebra,
  and in both places it does nothing you could see. Do not reach for it to make a panel
  read as a panel; use a `--g?` ground or no fill and a hairline.

On a `--g?` ground always use the matching `--t?` (4.79 / 4.89 / 10.45 / 6.73 — all pass).

`--ink` grounds nothing here. There is no large dark panel anywhere in this reference,
and a big dark rounded rectangle reads as a photo placeholder.

---

## 8. The safe area, and what may enter it

`.fit` carries `padding:12cqh 6cqw 9cqh` and that is the only place it is set.

- **6cqw left and right** is the template constant — the reference's own left margin on
  10 of its 15 pages, and no page puts content nearer either edge.
- **12cqh top** clears the folio numeral, which runs from 5cqh to 12.8cqh.
- **9cqh bottom** clears the running footer: the hairline at `bottom:3.55cqh`, the page
  number at `3.2cqh`, the footer kicker at `3.0cqh`.

Optional decoration may sit outside that box freely. Inside it, decoration may only sit *behind*
content at `z-index:0–1`, or in a region the content demonstrably does not occupy —
which you check by overlaying, not by eye.

## 9. Required chrome, on every page including cover and close

```html
<div class="kicker" style="position:absolute;left:8cqw;bottom:3.0cqh;font-size:1.0cqw;
     letter-spacing:.22em;color:var(--soft);z-index:5">PUBLICATION NAME</div>
<div style="position:absolute;left:20cqw;right:9cqw;bottom:3.55cqh;height:1px;
     background:color-mix(in srgb,var(--ink) 24%,transparent);z-index:4"></div>
<div class="pagenum">page 01</div>
```

15 of 15 reference pages carry all three. This is the cheapest part of the template's
identity and the most frequently dropped.
