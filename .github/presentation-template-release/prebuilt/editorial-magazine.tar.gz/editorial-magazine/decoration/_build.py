#!/usr/bin/env python3
"""Emit decoration.html and item-sets.html from the same shell the layouts use."""
import pathlib

HERE = pathlib.Path(__file__).parent
SHELL = (HERE.parent / 'layouts' / '_shell.html').read_text()
HEAD = SHELL.split('<body>')[0].replace('naked layout', 'decoration reference') + '<body>\n'

# ---- visual vocabulary, classified before it is counted. --------------------
# Rails, photocells and item marks perform layout/content functions; folios,
# mastheads and the footer are chrome. Only the textless dot system is optional
# decoration under the shared playbook definition.
RAIL_N = ('<div data-background-field="rail" style="position:absolute;{side}:0;top:0;width:{w}cqw;height:100cqh;'
          'background:var({g});color:var({t});border-radius:0;z-index:1"></div>')
DOT = ('<div data-decoration="dot" style="position:absolute;{pos};width:{w}cqw;height:{w}cqw;'
       'background:var({c});border-radius:50%;z-index:3"></div>')
FOLIO = ('<div style="position:absolute;{pos};font-family:var(--fd),var(--cjk-display);font-weight:600;'
         'font-size:{fs}cqw;letter-spacing:-.01em;line-height:.9;color:var({c});z-index:3">{n}</div>')
MAST = ('<div style="position:absolute;left:3.2cqw;top:70cqh;transform-origin:0 0;'
        'transform:rotate(-90deg) translate(-50%,0);font-family:var(--fd),var(--cjk-display);font-weight:500;'
        'font-size:calc((1.2cqw) * var(--fit, 1));letter-spacing:.30em;text-transform:uppercase;color:var({c});'
        'white-space:nowrap;z-index:3">Publication Name</div>')
PHOTO = ('<div data-photocell="1" style="position:absolute;right:9cqw;top:50cqh;transform:translateY(-50%);'
         'width:26cqw;height:52cqh;background:var(--ph);border-radius:var(--r-md);z-index:1"></div>')
CHROME = ('<div class="kicker" style="position:absolute;left:8cqw;bottom:3.0cqh;font-size:calc((1.0cqw) * var(--fit, 1));'
          'letter-spacing:.22em;color:var(--soft);z-index:5">PUBLICATION NAME</div>\n'
          '<div style="position:absolute;left:20cqw;right:9cqw;bottom:3.55cqh;height:1px;'
          'background:color-mix(in srgb,var(--ink) 24%,transparent);z-index:4"></div>\n'
          '<div class="pagenum">page 01</div>')

TILE_SVGS = [
    '<path d="M2 19V6a2 2 0 0 1 2-2h7v17H4a2 2 0 0 1-2-2zM22 19V6a2 2 0 0 0-2-2h-7v17h7a2 2 0 0 0 2-2z"/>',
    '<rect x="3" y="3" width="18" height="18" rx="1"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="9" x2="9" y2="21"/>',
    '<polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/>',
    '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',
]
GT = [('--g0', '--t0'), ('--g3', '--t3'), ('--g1', '--t1'), ('--g2', '--t2')]


def dot_pair(corner='right', top=6):
    """The pair: large dot, and a small one 2.8cqw to its left and 1cqh above.
    Measured on 13 of 15 reference pages; the 2:1 size ratio never varies."""
    if corner == 'right':
        a = DOT.format(pos=f'right:6cqw;top:{top}cqh', w='1.3', c='--accent')
        b = DOT.format(pos=f'right:9.5cqw;top:{top-1}cqh', w='0.65', c='--accent')
    else:
        a = DOT.format(pos=f'left:6cqw;top:{top}cqh', w='1.3', c='--accent')
        b = DOT.format(pos=f'left:9.5cqw;top:{top-1}cqh', w='0.65', c='--s3')
    return a + '\n' + b


def stage(slot, inner, chrome=True):
    label = (f'<div data-review-label="1" style="position:absolute;left:1.2cqw;top:1.4cqh;'
             'background:var(--ink);color:var(--bg);padding:.7cqh 1cqw;z-index:90;'
             'font-family:var(--fb),var(--cjk-body);font-size:calc((1cqw) * var(--fit, 1));font-weight:600;'
             f'letter-spacing:.08em;text-transform:uppercase">{slot}</div>')
    fixed = CHROME if chrome else ''
    return (f'<div class="slide"><div class="stage" data-slot="{slot}">\n{label}\n{inner}\n'
            f'{fixed}\n</div></div>\n')


# ------------------------------------------------------------ decoration.html
pages = []

# 1. narrow rail + pair + folio + masthead — the cover/prose register
pages.append(stage('rail-narrow', '\n'.join([
    RAIL_N.format(side='left', w='7', g='--g0', t='--t0'),
    MAST.format(c='--t0'),
    dot_pair('right', 6),
    FOLIO.format(pos='right:7cqw;top:9cqh', fs='5', c='--ka', n='//20<br>//26'),
])))

# 2. broad rail carrying its own content, plus the divider photocell
pages.append(stage('rail-broad', '\n'.join([
    PHOTO,
    dot_pair('right', 7),
    ('<div data-background-field="rail" style="position:absolute;left:0;top:0;width:46cqw;height:100cqh;'
     'background:var(--g3);color:var(--t3);border-radius:0;z-index:1">'
     '<div style="position:absolute;left:6cqw;top:8cqh;font-family:var(--fd),var(--cjk-display);'
     'font-weight:600;font-size:calc((3.2cqw) * var(--fit, 1));letter-spacing:-.01em;line-height:.9">/02</div></div>'),
])))

# 3. broad rail on the right, lone dot on the left — the two-page exception
pages.append(stage('rail-broad-right', '\n'.join([
    RAIL_N.format(side='right', w='34', g='--g1', t='--t1'),
    DOT.format(pos='left:6cqw;top:6cqh', w='1.3', c='--accent'),
    FOLIO.format(pos='right:6cqw;bottom:9cqh', fs='3', c='--t1', n='/005'),
])))

# 4. no rail: the pair, the low third dot, the numeral
pages.append(stage('rail-none', '\n'.join([
    dot_pair('right', 6),
    DOT.format(pos='left:6cqw;bottom:16cqh', w='1', c='--s3'),
    FOLIO.format(pos='right:6cqw;top:8cqh', fs='3', c='--ka', n='/004'),
])))

# 5. the only optional decoration class, isolated from structure and chrome.
pages.append(stage('optional-decoration-01 · dot-system', '\n'.join([
    '<div class="fit"><div style="flex:1;display:flex;flex-direction:column;justify-content:center">'
    '<div class="kicker k3">Optional decoration 01</div>'
    '<h1 class="h1" style="margin-top:1cqh">THE <em>DOT SYSTEM</em></h1>'
    '<p class="lead soft" style="margin-top:1.5cqh">Primary treatment: a 2:1 pair in a top corner. '
    'Conditional treatment: one low anchor dot on rail-less pages whose content ends early.</p>'
    '<div class="rule" style="margin-top:2.6cqh"></div>'
    '<p class="cap soft" style="margin-top:1.1cqh">One optional vocabulary class · no optional item-set decoration</p>'
    '</div></div>',
    dot_pair('right', 6),
    DOT.format(pos='left:6cqw;bottom:16cqh', w='1', c='--s3'),
]), chrome=False))

# 6. content and data components, shown for classification but excluded from
# optional-decoration counts.
marks = ['<div class="fit" style="justify-content:center;gap:4cqh">']
marks.append('<div><div class="kicker k3">Excluded from decoration count</div>'
             '<p class="lead soft" style="margin-top:1cqh">Tiles, badges, nodes, pills and dot charts carry content or data.</p></div>')
marks.append('<div style="display:flex;gap:2cqw;flex:none">' + ''.join(
    f'<div class="tile" data-tile="1" style="--sz:5cqw;width:5cqw;height:5cqw;flex:none;'
    f'background:var({GT[i][0]});color:var({GT[i][1]})">'
    f'<svg viewBox="0 0 24 24" style="width:50%;height:50%;stroke:currentColor;fill:none;stroke-width:1.6;'
    f'stroke-linecap:round;stroke-linejoin:round">{TILE_SVGS[i]}</svg></div>' for i in range(4)) + '</div>')
marks.append('<div style="display:flex;gap:2cqw;flex:none">' + ''.join(
    f'<div class="badge" data-badge="1" style="width:2.5em;height:2.5em;flex:none;'
    f'background:var({GT[i][0]});color:var({GT[i][1]});font-size:calc((2cqw) * var(--fit, 1))">{i+1:02d}</div>' for i in range(4)) + '</div>')
marks.append('<div style="display:flex;gap:2cqw;flex:none">' + ''.join(
    f'<div data-node="1" style="flex:none;width:3.3em;height:3.3em;background:var({GT[i][0]});'
    f'color:var({GT[i][1]});clip-path:polygon(0 0,100% 0,100% 60%,50% 100%,0 60%);display:flex;'
    f'align-items:flex-start;justify-content:center;padding-top:1.0cqh;font-family:var(--fd),var(--cjk-display);'
    f'font-weight:600;font-size:calc((2.0cqw) * var(--fit, 1))">{i+1:02d}</div>' for i in range(4)) + '</div>')
marks.append('<div style="display:flex;gap:2cqw;align-items:center;flex:none">'
             '<div data-pill="1" style="display:inline-flex;align-items:center;justify-content:center;'
             'padding:1.2cqh 2.0cqw;background:var(--g0);color:var(--t0);border-radius:999px;'
             'font-family:var(--fd),var(--cjk-display);font-weight:500;font-size:calc((1.2cqw) * var(--fit, 1));'
             'letter-spacing:.04em">Read the catalogue</div>'
             '<div style="display:grid;grid-template-columns:repeat(5,2.4cqw);gap:.75cqw">' + ''.join(
                 f'<div class="dot" style="width:2.4cqw;height:2.4cqw;background:var(--accent);'
                 f'opacity:{1 - .2 * (i % 5):.1f}"></div>' for i in range(15)) + '</div></div>')
marks.append('</div>')
pages.append(stage('content-vocabulary · excluded', '\n'.join(marks)))

deco = (HEAD + '<!--\n  editorial-magazine — classified visual vocabulary.\n'
        '  Optional decoration: dot-system only. Rails and photocells are structure;\n'
        '  tiles, badges, nodes, pills and dot matrices carry content/data; folio, masthead\n'
        '  and footer are fixed chrome. See PLACEMENT.md for frequency and attachment.\n-->\n'
        '<div class="deck">\n' + ''.join(pages) + '</div>\n</body></html>\n')
deco = '\n'.join(line.rstrip() for line in deco.splitlines()) + '\n'
(HERE / 'decoration.html').write_text(deco)

# -------------------------------------------------------------- item-sets.html
# Content components attached to repeated items. They are not optional decoration.
sets = []

cards = [('Magazines', 'Issue-based editorial with a fixed grid and a running masthead footer.'),
         ('Catalogues', 'Product galleries that read like a publication, not a price sheet.'),
         ('Brand type', 'Serif-and-sans systems built to carry a voice across pages.'),
         ('Art direction', 'Covers, imagery and rhythm — every margin and headline considered.')]
rows = []
for i in range(0, 4, 2):
    cells = ''.join(
        f'<div style="flex:1;min-width:0;background:var({GT[j][0]});color:var({GT[j][1]});'
        f'border-radius:var(--r-md);padding:2.6cqh 1.8cqw;display:flex;gap:1.4cqw;align-items:flex-start">'
        f'<div class="tile" data-tile="1" style="width:5cqw;height:5cqw;flex:none;background:var({GT[j][1]});'
        f'color:var({GT[j][0]})"><svg viewBox="0 0 24 24" style="width:50%;height:50%;stroke:currentColor;'
        f'fill:none;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round">{TILE_SVGS[j]}</svg></div>'
        f'<div style="min-width:0"><h3 class="h3">{cards[j][0]}</h3>'
        f'<p class="body" style="margin-top:.6cqh;opacity:.92">{cards[j][1]}</p></div></div>'
        for j in (i, i + 1))
    rows.append(f'<div class="row" style="gap:2cqw">{cells}</div>')
sets.append(stage('content set · card-grid + tile', '<div class="fit"><div class="grp" style="gap:2cqh">'
                  + ''.join(rows) + '</div></div>'))

nrows = ''.join(
    f'<div style="display:flex;gap:2cqw;align-items:flex-start;margin-bottom:3.4cqh">'
    f'<div style="flex:none"><div class="badge" data-badge="1" style="width:2.5em;height:2.5em;'
    f'background:var({GT[i][0]});color:var({GT[i][1]});font-size:calc((2cqw) * var(--fit, 1))">{i+1:02d}</div></div>'
    f'<div style="flex:1;min-width:0;padding-top:.6cqh"><h3 class="h3">{t}</h3>'
    f'<p class="body soft" style="margin-top:.6cqh">{b}</p></div></div>'
    for i, (t, b) in enumerate([
        ('Voice before volume', 'A strong editorial voice does not shout — it sets one clear intention.'),
        ('Type is the system', 'The grid, the serif headline and the running footer are the brand.'),
        ('Made to be kept', 'Printed objects designed to be re-read, not scrolled past.')]))
sets.append(stage('content set · numbered-list + badge', f'<div class="fit"><div class="grp">{nrows}</div></div>'))

srows = ''.join(
    f'<div style="display:flex;align-items:center;gap:1.8cqw;margin-bottom:2cqh">'
    f'<div data-node="1" style="flex:none;width:3.3em;height:3.3em;background:var({GT[i][0]});'
    f'color:var({GT[i][1]});clip-path:polygon(0 0,100% 0,100% 60%,50% 100%,0 60%);display:flex;'
    f'align-items:flex-start;justify-content:center;padding-top:1.0cqh;font-family:var(--fd),var(--cjk-display);'
    f'font-weight:600;font-size:calc((2.0cqw) * var(--fit, 1))">{i+1:02d}</div>'
    f'<div style="flex:1;min-width:0"><h3 class="h3">{t}</h3>'
    f'<p class="body soft" style="margin-top:.4cqh">{b}</p></div></div>'
    for i, (t, b) in enumerate([
        ('Commission', 'Brief the voice, set the grid and the issue theme.'),
        ('Compose', 'Headlines, body and imagery placed on one system.'),
        ('Refine', 'Margins, rhythm and the running footer locked.'),
        ('Publish', 'Print, distribute, measure the reach.')]))
sets.append(stage('content set · process-steps + node', f'<div class="fit"><div class="grp">{srows}</div></div>'))

people = ''.join(
    f'<div style="flex:1;min-width:0;display:flex;flex-direction:column">'
    f'<div data-photocell="1" data-photo-seed="team-{i+1}" style="aspect-ratio:3/2;background:var(--ph);'
    f'border-radius:var(--r-md)"></div>'
    f'<h3 class="h3" style="margin-top:1.2cqh">{n}</h3>'
    f'<p class="cap soft" style="margin-top:.2cqh">{r}</p></div>'
    for i, (n, r) in enumerate([('A. Reyes', 'Editor-in-Chief'), ('M. Okafor', 'Art Director'),
                                ('L. Brandt', 'Designer'), ('S. Nawaz', 'Writer')]))
sets.append(stage('content set · team + photocell',
                  f'<div class="fit"><div class="grp"><div class="row" style="gap:1.6cqw">{people}</div></div></div>'))

items = (HEAD + '<!--\n  Repeated content components, excluded from optional-decoration counts.\n'
         '  Where a set carries them, EVERY item in the set gets one, and the ground cycles\n'
         '  --g0 --g3 --g1 --g2 so neighbours never match. Copy this markup exactly.\n-->\n'
         '<div class="deck">\n' + ''.join(sets) + '</div>\n</body></html>\n')
items = '\n'.join(line.rstrip() for line in items.splitlines()) + '\n'
(HERE / 'item-sets.html').write_text(items)

print('decoration.html:', deco.count('<div class="slide">'), 'pages')
print('item-sets.html :', items.count('<div class="slide">'), 'pages')
