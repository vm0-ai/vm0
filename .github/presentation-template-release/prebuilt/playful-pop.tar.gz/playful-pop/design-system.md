# Playful Pop design system

## Visual identity

Playful Pop is a dark, high-saturation presentation system: Space Grotesk
display type, Lexend body type, hard-offset colour relationships, edge-cropped
organic forms, corner dot grids, burst rosettes, and strong but sparse colour
fields. It is playful without becoming a collage of generic shapes.

This file defines identity and shell. Content geometry lives in
`layouts/README.md`; optional motif rules live in `decoration/PLACEMENT.md`.

## Colour system

Use the prompt's valid `color-system` exactly. Valid tokens are:

- single-colour: `warm_sand`, `bauhaus_primary`, `nordic_frost`,
  `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`,
  `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`,
  `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`;
- multicolour: `prism`, `carnival`, `pop_art`.

If none is supplied, choose exactly one of `pop_art`, `carnival`, `prism`,
`citrus_fresh`, or `berry_pop`; the reference default is `pop_art`. Inline that
one atomic CSS block in the deliverable and set the same token on
`<html data-color-system="...">`.

Roles:

- `--bg`: stage ground; `--surface`: subtle cards; `--ink`: primary text;
  `--soft`: secondary text; `--ph`: supported image placeholder while loading.
- `--accent`, `--s1`, `--s2`, `--s3`: source hues for decoration and graphics.
- `--ka`, `--k1`, `--k2`, `--k3`: contrast-safe emphasis text.
- `--g0..--g3`: large text-bearing colour fields; always use their matching
  `--t0..--t3` text token.

All CSS colours reference tokens. Derive transparency, borders, and shadows
with `color-mix` rather than introducing literals.

Measured for the reference `pop_art` token on `--bg #111016`:

| Text/graphic token | Contrast |
| --- | ---: |
| `--ink` | 17.06:1 |
| `--soft` | 7.10:1 |
| `--accent` | 4.94:1 |
| `--s1` | 5.76:1 |
| `--s2` | 16.05:1 |
| `--s3` | 7.26:1 |

Field pairs are `--g0/--t0` 4.72:1, `--g1/--t1` 4.77:1,
`--g2/--t2` 15.59:1, and `--g3/--t3` 4.60:1. `--surface #1B1A22`
is intentional on the dark page and is not forbidden.

## Typography

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600&family=Lexend:wght@300;400;500;600&display=swap" rel="stylesheet">
```

```css
:root{
  --fd:"Space Grotesk";
  --fb:"Lexend";
  --fw-display:600;
  --fw-label:500;
  --fw-body:400;
  --cjk-display:"PingFang SC","Microsoft YaHei","Noto Sans CJK SC","Noto Sans SC",sans-serif;
  --cjk-body:"PingFang SC","Microsoft YaHei","Noto Sans CJK SC","Noto Sans SC",sans-serif;
}
```

Use display type for titles, chapter numbers, and hero figures; body type for
paragraphs, labels, annotations, and tables. Available weights are 400/500/600
for Space Grotesk and 300/400/500/600 for Lexend.

Reference scale:

```css
.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1;letter-spacing:-.02em}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.2em;text-transform:uppercase}
.lead{font-size:2cqw;font-weight:300;line-height:1.5}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4}
```

## Deck shell

```css
:root{--r-xs:.5cqw;--r-sm:.9cqw;--r-md:1.7cqw;--r-lg:3cqw;--r-xl:5cqw}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink)}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;background:var(--bg);color:var(--ink);border:1px solid color-mix(in srgb,var(--ink) 12%,transparent);overflow-wrap:break-word;word-break:normal}
.stage *{overflow-wrap:break-word!important;word-break:normal!important}
.fit{position:absolute;inset:0;z-index:40;transform-origin:top center;display:flex;flex-direction:column;align-items:stretch;padding:12cqh 7cqw 8cqh}
img{max-width:100%;object-fit:contain!important}
.photo,[data-photocell] img{width:100%;height:100%;display:block}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;z-index:45;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.65}
.card{background:var(--surface);border-radius:var(--r-md)}
.dot{border-radius:50%}.soft{color:var(--soft)}
```

Set `<html data-safe-area="0.07">`. The 7% safe area is measured from the
reference's modal text margin. Do not reduce it on an individual page.

Every `.slide` is a direct child of `.deck`. Include one keyboard runtime that
collects slides from `deck.children`, not from a descendant query that silently
accepts nested pages.

## Universal content sizing

Nothing containing text uses `cqw`, `cqh`, `px`, `vw`, or `vh` for width,
height, positional sizing, or flex-basis. The only exceptions are absolute
placement of a small out-of-flow badge, a 1px hairline, data percentages in
charts/Gantt, pure decoration, image cells, SVG plot areas, and the stage shell.

Use Flexbox for content relationships. A filled peer row sizes from its tallest
child; a single box hugs its content. See `layouts/README.md` for exact patterns.

## Optional motif vocabulary

The optional vocabulary is intentionally finite: organic blob, corner dot
grid, and isolated dot.

Cards, square/rectangular colour blocks, content containers, grid cells, hard
offset structural grounds, image frames, labelled pills, `bbadge`, icon `tile`,
process `node`, connector, and persistent chrome carry content or structure.
They are not optional decorations and are excluded from decoration counts.
Exact copyable geometry, frequencies, and positions are in
`decoration/PLACEMENT.md` and `decoration/decoration.html`. Playful Pop has no
genuine textless item-attached motif, so it has no `item-sets.html`. Do not
substitute generic circles, squares, arches, gradients, or colour blocks.

## Photography

Use a `photocell` only for a subject established by the source. Supplied assets
come first. Never generate an image to fill whitespace, never invent a caption,
and never leave an empty image-shaped rectangle when the subject is absent.

## Required chrome

Carry both on every slide:

```html
<div class="kicker" style="position:absolute;left:7cqw;bottom:3.4cqh;z-index:45;opacity:.75">Stable subject label</div>
<div class="pagenum">01</div>
```

The footer is plain text, never a pill. Chrome is persistent structure and is
not included in optional decoration statistics.

## Never do this

- Never invent claims, figures, images, captions, colours, motifs, buttons, or
  interface chrome to fill space.
- Never overlap an ornament and text or place prose directly on an unprotected
  photograph.
- Never freeze a text container to the dimensions of placeholder copy.
- Never put a `.slide` outside or below another `.slide`; direct-child count
  must equal total slide count.
- Never deliver before rendering every page, verifying resources, running the
  probes, and pressing an arrow key.
