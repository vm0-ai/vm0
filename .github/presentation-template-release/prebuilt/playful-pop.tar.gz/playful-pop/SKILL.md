---
name: playful-pop
description: Create a standalone 16:9 HTML presentation deck with the Playful Pop visual identity and direct-HTML workflow. Use when the user selects playful-pop for dark-neon entertainment, social products, youth culture, or trend-driven consumer stories.
---

# Playful Pop presentation

Create one coherent audience-facing 16:9 HTML deck. The default deliverable is
one directly openable HTML file: inline the selected colour-system CSS and all
deck CSS/JS; web-font links may remain external with system fallbacks.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

- Produce one live `.deck` and one navigation runtime. Every `.slide` is a
  direct child of that deck and contains one 16:9 `.stage`.
- Put audience text in `.fit`, a column flex with
  `padding:12cqh 7cqw 8cqh`. The 7% horizontal safe area is a template constant,
  not a per-slide choice. The top 11% belongs to chrome.
- Use Flexbox for primary relationships. Keep prose in normal flow; absolute
  positioning is for optional decoration, a small corner badge, plot marks,
  and the shell—not page layout.
- Nothing containing text may use `cqw`, `cqh`, `px`, `vw`, or `vh` for
  `width`, `max-width`, `min-width`, `height`, `left`, `top`, `right`, `bottom`,
  or `flex-basis`. `flex:0 0 ...` counts. Use `flex:1`, intrinsic size, padding,
  `em`, and normal flow. Fixed viewport sizing is allowed on pure decoration,
  image cells, SVG plots, and the stage.
- A single filled box hugs its content. A row of filled peers divides the safe
  area, sizes from its tallest child, and remains equal height under longer
  copy: wrapper `flex:1; justify-content:center`, row
  `flex:none; display:flex; align-items:stretch`, children `flex:1`.
- Use concise projected copy with one hierarchy of title, support, and evidence.
  Split dense material; never solve overflow by hiding content or shrinking
  below the documented type scale.
- Numeric/code identifier columns take intrinsic width and never wrap; only the
  prose column absorbs slack.

The full 31-layout inventory and role matrix are in `layouts/README.md`.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

1. Read `design-system.md` completely for colour, type, shell, chrome, and
   source-fidelity rules.
2. Read `layouts/README.md`, then select the closest layout file for each
   communication job. Adapt content; do not invent a parallel layout system.
3. Read `decoration/PLACEMENT.md`, then apply optional decoration only after the
   content layer fits. Copy its three textless motifs from
   `decoration/decoration.html`.
4. Inspect `example/reference.jpg` and render `layouts/` to verify
   scale and rhythm. Read `composition-recipes.html` for record/list/table
   details.

Priority when constraints compete: source accuracy, presentation legibility,
template identity, then documented decoration roles. Decoration never removes
content, shrinks type, invents evidence, or creates an unsupported image.

### Colour

Use the prompt's valid `color-system` exactly. Otherwise choose only one of:
`pop_art`, `carnival`, `prism`, `citrus_fresh`, or `berry_pop`; default to
`pop_art`. Inline the matching `color-systems/<token>.css` block once and put
the same token on the root element.

Use only token-derived colours. On a large `--g0..--g3` field, pair the matching
`--t0..--t3`. On the standard dark ground, `--ink`, `--soft`, `--ka`, `--k1`,
`--k2`, and `--k3` are text roles. In `pop_art`, all four source hues also pass
normal-text contrast on `--bg`; `--surface` is a valid subtle card ground. Do
not import bloom's cream-page colour restrictions.

### Apply the decoration layer

Choose a role recipe from `decoration/PLACEMENT.md`. Cover, section divider, close,
image-left, numbered split, and ordinary content pages have distinct compositions;
do not generalize a structural colour ground to every slide.

Only three optional motifs are vocabulary: organic blob, corner dot grid, and
isolated dot. Cards, square/rectangular colour blocks, content containers, grid
cells, photo frames, labelled pills, `bbadge`, icon `tile`, process `node`,
connector, and persistent chrome carry content or structure. They belong in
layouts and never enter optional-decoration counts. This template has no
genuine textless item-attached motif, so it has no `item-sets.html`.

No ornament overlaps text. Crop organic blobs according to the selected page role in
`PLACEMENT.md`.

### Persistent chrome

Carry a stable subject footer as plain `.kicker` text and a page number on every
slide, including cover and close. Default positions are footer at the 7% safe
edge and `bottom:3.4cqh`; page number at `right:3cqw; bottom:3.2cqh`. Chrome is
not optional decoration and must not be counted as such.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

Use computed styles to confirm that the colour CSS and fonts loaded; relative-path
failure can make an unstyled deck pass geometry probes.

The root `data-safe-area="0.07"` supplies this template's safe-area constant to the
single final report. Recommended diagnostics:

- `decks=1`, `navigableSlides=pages`, `orphanSlides=0`, `indirectSlides=0`;
- `overflow=0`, `outsideSafeArea=0`, `aboveChromeBand=0`;
- `lowContrast=0`;
- `titleBodyOverlaps=0`, `bodyCtaOverlaps=0`, `textBigcircleOverlaps=0`;
- `boxesUnderfilledV=0`, `boxesUnderfilledH=0` for new layouts.

Treat underfill diagnostics according to the layout's semantic role instead of as an
unconditional gate. Stress-test every peer row by injecting an extra
sentence into its first item and comparing sibling heights.

`keyboardNavigationFailures` dispatches arrows, Home, and End and verifies the live
slide state. Focused editable controls retain normal key behaviour; do not add a manual
navigation pass.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
