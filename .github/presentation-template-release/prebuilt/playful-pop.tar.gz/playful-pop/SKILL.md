---
name: playful-pop
description: Create, revise, or review standalone 16:9 HTML presentation decks with the Playful Pop visual identity and direct-HTML workflow. Use when the user selects playful-pop for dark-neon entertainment, social products, youth culture, or trend-driven consumer stories.
---

# Playful Pop presentation

Create one coherent audience-facing 16:9 HTML deck. The default deliverable is
one directly openable HTML file: inline the selected colour-system CSS and all
deck CSS/JS; web-font links may remain external with system fallbacks.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Establish the communication job

Read the prompt and all source material before composing. Identify audience,
purpose, desired outcome, core takeaway, and required evidence. Ground every
claim and number in supplied or verified sources; explicitly label forecasts,
targets, and assumptions.

Before HTML, write a lightweight outline with one throughline and one row per
slide: takeaway title, point, evidence/source, and status. Review the sequence
for missing evidence, repetition, opening, and ending. The outline is the
content contract, not a layout schema, and never appears in audience copy.

For revision, update this contract before making material slide changes. For
review, infer it and report findings P1/P2/P3 without editing.

## 2. Load the identity in this order

1. Read `design-system.md` completely for colour, type, shell, chrome, and
   source-fidelity rules.
2. Read `layouts/README.md`, then select the closest layout file for each
   communication job. Adapt content; do not invent a parallel layout system.
3. Read `decoration/PLACEMENT.md`, then apply optional decoration only after the
   content layer fits. Copy its three textless motifs from
   `decoration/decoration.html`.
4. Inspect `example/reference.jpg` and render `layouts/` to verify
   scale and rhythm. Read `composition-recipes.html` for record/list/table
   details.

Priority when constraints compete: source accuracy, presentation legibility,
template identity, then documented decoration roles. Decoration never removes
content, shrinks type, invents evidence, or creates an unsupported image.

## 3. Colour and photography

Use the prompt's valid `color-system` exactly. Otherwise choose only one of:
`pop_art`, `carnival`, `prism`, `citrus_fresh`, or `berry_pop`; default to
`pop_art`. Inline the matching `color-systems/<token>.css` block once and put
the same token on the root element.

Use only token-derived colours. On a large `--g0..--g3` field, pair the matching
`--t0..--t3`. On the standard dark ground, `--ink`, `--soft`, `--ka`, `--k1`,
`--k2`, and `--k3` are text roles. In `pop_art`, all four source hues also pass
normal-text contrast on `--bg`; `--surface` is a valid subtle card ground. Do
not import bloom's cream-page colour restrictions.

Use a photograph or other image whenever it communicates the slide more clearly,
credibly, or memorably than text alone. The source does not have to request one
explicitly; make that editorial choice from the content. Choose sources in this
order: user-supplied images and visual materials first, including media embedded
in or linked from the supplied material; then relevant imagery from the supplied
references and related information; then an AI-generated image grounded in the
slide's actual subject when it would work better or no suitable sourced image
exists. Never add or generate an image merely to fill an empty frame. Captions,
alt text, and adjacent labels remain factual and grounded in the source.

## 4. Build the content layer

- Produce one live `.deck` and one navigation runtime. Every `.slide` is a
  direct child of that deck and contains one 16:9 `.stage`.
- Put audience text in `.fit`, a column flex with
  `padding:12cqh 7cqw 8cqh`. The 7% horizontal safe area is a template constant,
  not a per-slide choice. The top 11% belongs to chrome.
- Use Flexbox for primary relationships. Keep prose in normal flow; absolute
  positioning is for optional decoration, a small corner badge, plot marks,
  and the shell—not page layout.
- Nothing containing text may use `cqw`, `cqh`, `px`, `vw`, or `vh` for
  `width`, `max-width`, `min-width`, `height`, `left`, `top`, `right`, `bottom`,
  or `flex-basis`. `flex:0 0 ...` counts. Use `flex:1`, intrinsic size, padding,
  `em`, and normal flow. Fixed viewport sizing is allowed on pure decoration,
  image cells, SVG plots, and the stage.
- A single filled box hugs its content. A row of filled peers divides the safe
  area, sizes from its tallest child, and remains equal height under longer
  copy: wrapper `flex:1; justify-content:center`, row
  `flex:none; display:flex; align-items:stretch`, children `flex:1`.
- Use concise projected copy with one hierarchy of title, support, and evidence.
  Split dense material; never solve overflow by hiding content or shrinking
  below the documented type scale.
- Numeric/code identifier columns take intrinsic width and never wrap; only the
  prose column absorbs slack.

The full 31-layout inventory and role matrix are in `layouts/README.md`.

## 5. Apply the decoration layer

Choose a role recipe from `decoration/PLACEMENT.md`. Cover, section divider, close,
image-left, numbered split, and ordinary content pages have distinct compositions;
do not generalize a structural colour ground to every slide.

Only three optional motifs are vocabulary: organic blob, corner dot grid, and
isolated dot. Cards, square/rectangular colour blocks, content containers, grid
cells, photo frames, labelled pills, `bbadge`, icon `tile`, process `node`,
connector, and persistent chrome carry content or structure. They belong in
layouts and never enter optional-decoration counts. This template has no
genuine textless item-attached motif, so it has no `item-sets.html`.

No ornament overlaps text. Crop organic blobs according to the selected page role in
`PLACEMENT.md`.

## 6. Persistent chrome

Carry a stable subject footer as plain `.kicker` text and a page number on every
slide, including cover and close. Default positions are footer at the 7% safe
edge and `bottom:3.4cqh`; page number at `right:3cqw; bottom:3.2cqh`. Chrome is
not optional decoration and must not be counted as such.

## Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Getting the container right

A percentage bar height resolves against its parent's **definite** height. Break
that chain and the bar computes to exactly `0` — it vanishes while the labels,
values and legend still render, so the page reads as merely empty. Measured on
generated decks: 52 of 558 percentage bars rendered at zero, and one deck spent
455s of gate repair on this alone.

`layouts/chart-*.html` already carries a structure that works. Copy it rather
than inventing lanes. Three rules make the chain definite:

1. **A bar is a direct child of the plot box.** Any level between them needs its
   own definite height, and one that lacks it zeroes everything below.
2. **All columns share one grid, so the label row is shared.** A label that wraps
   to two lines must cost every column the same height, or the bar above it is
   measured against a shorter ruler than its neighbours. Make the plot
   `display:grid; grid-auto-flow:column; grid-auto-columns:1fr` with
   `grid-template-rows:1fr auto …` (one row per item in a column, exactly — a
   spare row pulls the next column's first item into the previous column), and
   give each column wrapper `display:contents`. The markup grouping stays "one
   div per column"; only the rows become shared.

   Measured on the template's own `chart-bar.html`, changing nothing but one
   label to a wrapping name: baseline offset 0 → 19px, and the fourth bar 342 →
   324px — the value never changed, the bar just lost 5%. With the shared grid
   the same label costs all four bars the same 8%, and the ratios stay exact.

3. **Every level is either `flex:none` or `flex:1`** — sized by its content, or
   taking the remainder. There is no third kind.

4. **A value label never shares the lane with the bar it labels.** If it does,
   flex has to fit label + gap + bar into the lane, so it shrinks the bar — and
   only the bars tall enough to run out of room. The scale stops being linear at
   the top: measured on `bloom/chart-bar.html`, lane 336px, label 19px, gap 6px,
   every value above 92.5% rendered at the same 310px, so **96 and 100 drew
   identically**. Under the template's own "percentages of the tallest value"
   convention the tallest bar is always 100%, so this fires on every chart.
   Reserve the label row on the lane (`padding-top`, measured once per template)
   and set both children `flex:none`; the bar then resolves against the lane
   minus that reserve, the same reserve for every column.

Grouping two bars per category still obeys this, but the group wrapper needs
`align-self:stretch`, or it is sized by content and the lane inside it collapses.

Do not "fix" a flat chart by enlarging the numbers or switching to a table. The
values are right; the container chain is not.

## How full a page should be

Measured across all 902 layouts in the 23 shared templates, so this is what the
system already does — not a target invented for the occasion:

|                                                                                  | p25 |  median | p75 |
| -------------------------------------------------------------------------------- | --: | ------: | --: |
| vertical coverage (share of the stage height that carries ink or a filled block) | 33% | **43%** | 61% |
| ink area (share of the stage area)                                               |  9% | **12%** | 16% |
| lowest ink (how far down the page the content reaches)                           | 68% | **75%** | 90% |

**Aim for the middle column.** A content page that stops at 40% of the height and
leaves the rest blank reads as unfinished; one that runs past 25% ink area reads as
a wall. Both are allowed when the material calls for it — a statement page is one
huge line at 6% coverage, a table or a longform page is legitimately dense — but
neither is the default.

Two things that are **not** the same:

- **A void at the bottom.** Content stops early and nothing follows. This is the
  one to avoid; measured on the naked layouts, 73 of 902 pages do it.
- **Air between blocks.** A title, then a band of columns centred in the space
  below it. That is composition, not a defect — do not fill it just to fill it.

If the material genuinely does not fill the page, cut a column or merge the page
into its neighbour rather than padding sentences.

## 7. Verify before delivery

Render every page at full presentation size and inspect the complete sequence.
Confirm colour CSS and fonts really loaded; relative-path failure can make an
unstyled deck pass geometry probes.

Run the playbook static sizing audit and the template-local browser probe with
`SAFE=.07 tools/run.sh layouts/`.
Every authored layout and delivered deck must read:

- `decks=1`, `navigableSlides=pages`, `orphanSlides=0`, `indirectSlides=0`;
- `overflow=0`, `outsideSafeArea=0`, `aboveChromeBand=0`;
- `columnsMisaligned=0`, `lowContrast=0`;
- `titleBodyOverlaps=0`, `bodyCtaOverlaps=0`, `textBigcircleOverlaps=0`;
- inspect every `textVisualOverlapCandidates` sample; repair a motif that obscures or
  weakens text, but do not auto-fail an intentional crossing whose words remain
  immediately legible;
- `boxesUnderfilledV=0`, `boxesUnderfilledH=0` for new layouts.

Any non-zero semantic-collision reading is blocking; these semantic intersections have
no bypass.

Treat underfill diagnostics according to the layout's semantic role instead of as an
unconditional gate. Stress-test every peer row by injecting an extra
sentence into its first item and comparing sibling heights.

Press an arrow key in the actual deck, then test arrows, Page Up/Down, Home,
and End. Focused editable controls retain normal key behaviour. Machine-check:

```js
document.querySelectorAll(".slide").length ===
  [...document.querySelector(".deck").children].filter((n) =>
    n.classList.contains("slide"),
  ).length;
```

Finally compare the rendered deck with its outline and source. Confirm no point
was dropped, no unsupported image or caption was added, every ornament maps to
the vocabulary and role recipes, and exactly one valid colour-system is used.

## Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding. Run `tools/run.sh <deck>` and require `safeAreaShells`, `outsideSafeArea`, and `emptyPhotocells` all to equal `0`; any non-zero result blocks delivery.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
