# Playful Pop optional decoration placement

This layer contains only template-specific elements that carry no text or data
and perform no layout function. measured from the original reference deck, the
reference has three optional decoration classes across 15 pages.

Cards, square tiles, coloured or rectangular backgrounds, content containers,
grid cells, media frames, numbered rosettes, icon tiles, process nodes,
connectors, and persistent chrome are content or layout structure. They are not
decoration and never enter the counts below.

## Three-class vocabulary

| Optional decoration | Reference count | Attachment and position |
| --- | ---: | --- |
| Organic blob | 11 total, 0.73/page | One irregular 26–42cqw form on a normal dark content page. Ten of eleven are cropped by a stage edge; the numbered split page is the one inside-field exception. |
| Corner dot grid | 10 total, 0.67/page | One 3×3, 4×3, or 4×4 grid in open corner space, usually opposite the blob. Dot diameter 0.6–0.8cqw; gap 1.3–1.5cqw. Count the whole grid once, never each dot. |
| Isolated dot | 2 total, 0.13/page | One 1.8cqw dot in an otherwise open corner on team/testimonial roles; never scatter generic circles. |

Total optional-decoration instances in the reference: 23, or 1.53/page. These
are whole-deck diagnostics, not quotas. Dense pages may carry none.

## Organic geometry

Use one of the four exact radii demonstrated by Playful Pop:

```css
border-radius:63% 37% 44% 56% / 38% 62% 38% 62%;
border-radius:58% 42% 38% 62% / 55% 45% 55% 45%;
border-radius:40% 60% 55% 45% / 52% 38% 62% 48%;
border-radius:42% 58% 63% 37% / 45% 38% 62% 55%;
```

On a normal dark page, push the blob past one top, bottom, left, or right edge.
It belongs in the empty half or corner and never overlaps the text silhouette.
The numbered split composition may place one 26cqw blob inside its right colour
field, matching the reference; do not generalize that exception.

## Corner dot grid

Use Flexbox, not CSS Grid, so the copyable decoration follows the universal
layout rule. Mark the group once:

```html
<div data-decoration="corner-dot-grid" data-decoration-size="small"
     style="position:absolute;right:7cqw;top:8cqh;display:flex;flex-direction:column;gap:1.3cqw">
  <!-- three or four flex rows, each with three or four textless .dot elements -->
</div>
```

The entire group is one optional ornament. Its individual dots are not grid
cells, metrics, or separately counted decorations.

## Isolated dot

Use only where the reference page role does: one 1.8cqw source-hue dot in open
corner space. Mark it `data-decoration="isolated-dot"` and
`data-decoration-size="small"`.

## Structural compositions are not decorations

Cover card stacks, section/close full-page grounds, the image-left offset
rectangle, and the numbered-list right field still belong to Playful Pop's
layout vocabulary. Keep them in the relevant layout when needed, mark them
`data-background-field`, and exclude them from optional-decoration statistics.

Likewise, `bbadge`, `tile`, `node`, and `connector` carry a number, icon, stage,
or relationship. They live directly in `numbered-list`, `kpi-rosettes`,
`icon-cards`, and `process-steps` layouts. This template has no genuine
textless item-attached motif, so there is no `item-sets.html`.

## Layer and safe area

Optional decoration sits at stage default `z-index:0`; `.fit` content sits at
`z-index:40`; footer and page number sit at `z-index:45` or above. Nothing
decorative may cover text.

The template constant is a 7% horizontal safe area with an 11% top chrome band:
`.fit { padding:12cqh 7cqw 8cqh; }`. Decoration may occupy the outer margin but
not the text silhouette.

## Colour

For `pop_art` on `--bg #111016`, source-hue contrast is `--accent` 4.94:1,
`--s1` 5.76:1, `--s2` 16.05:1, and `--s3` 7.26:1. These tokens may colour the
three textless decorations. Text uses role tokens; large text-bearing fields
use paired `--g0..--g3` / `--t0..--t3`. `--surface` is a valid dark card ground.

## Persistent chrome

Page number appears on 15/15 reference pages at `right:3cqw;
bottom:3.2cqh`. The stable footer label appears on 11/15, usually at the 7%
safe edge and `bottom:3.4cqh`. Generated decks carry both on every page. Chrome
is plain text and is counted separately, never as optional decoration.

## Verification

Declare genuine decoration with `data-decoration`; use
`data-decoration-size="small"` for the dot grid and isolated dot. Do not mark
background fields, content geometry, nodes, connectors, badges, or media.

At `SAFE=.07`, the reference must read zero on `overflow`, `outsideSafeArea`,
`aboveChromeBand`, `columnsMisaligned`, `lowContrast`, `orphanSlides`, and
`indirectSlides`; `navigableSlides` must equal 15. Underfill is nonzero on the
reference and therefore report-only there.

Before delivery, inspect every slide, verify the colour CSS loaded, run the
probe, and press an arrow key.
