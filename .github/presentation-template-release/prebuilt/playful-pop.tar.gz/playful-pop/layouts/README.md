# Playful Pop layout library

These 31 files are the content layer. They deliberately contain no optional
background motif. Add decoration only after the content fits and the closest
page role has been selected from `../decoration/PLACEMENT.md`.

Every file is a standalone 16:9 HTML page linked to `pop_art.css` for review.
When building a deliverable, inline the selected colour system and shell once,
then copy the `.slide` into one live `.deck` as a **direct child**.

## Provenance

The library starts with the layouts already demonstrated by this template,
then adds the three explicit composition recipes, then fills only real content
gaps in Playful Pop's own language.

- Reference-derived: `cover`, `toc`, `section-divider`, `image-left`,
  `numbered-list`, `team-grid`, `icon-cards`, `process-steps`, `image-grid`,
  `kpi-rosettes`, `testimonial-cards`, `pricing-cards`, `close`.
- `composition-recipes.html`: `big-quote`, `comparison`, `table`.
- Genuine supplements: `image-right`, `image-hero`, `two-column`,
  `three-column`, `pros-cons`, `stat-highlight`, `kpi-grid`, `chart-bar`,
  `chart-line`, `chart-donut`, `timeline`, `roadmap`, `gantt`, `flow-diagram`,
  `arch-diagram`.

This is not bloom's catalogue and it is not an Open Design dump. Layouts with
no demonstrated or recurring communication job were not added.

## Choose by communication job

| Job | Layouts |
| --- | --- |
| Open, orient, divide, close | `cover`, `toc`, `section-divider`, `close` |
| Explain with imagery | `image-left`, `image-right`, `image-hero`, `image-grid` |
| Present prose or a claim | `big-quote`, `numbered-list`, `two-column`, `three-column`, `pros-cons`, `comparison` |
| Present people, capabilities, proof, or offers | `team-grid`, `icon-cards`, `testimonial-cards`, `pricing-cards` |
| Present numbers | `stat-highlight`, `kpi-grid`, `kpi-rosettes`, `chart-bar`, `chart-line`, `chart-donut`, `table` |
| Present sequence or system | `process-steps`, `timeline`, `roadmap`, `gantt`, `flow-diagram`, `arch-diagram` |

Use the narrowest layout that expresses the evidence. Do not turn prose into a
chart, invent an image, or force the source into a fixed slide count.

## Universal geometry

- The stage constant is a 7% horizontal safe area. Set it once on `.fit` with
  `padding:12cqh 7cqw 8cqh`; do not redefine the safe area per slide.
- The top 11% belongs to chrome. All flow content begins at or below 12%.
- Use Flexbox for every primary relationship. Text stays in normal flow.
- An element that contains text must not use `cqw`, `cqh`, `px`, `vw`, or `vh`
  for `width`, `height`, positional sizing, or `flex-basis`. `flex:0 0 ...`
  counts as `flex-basis`. Use `flex`, intrinsic size, padding, `em`, and normal
  flow instead.
- Fixed viewport sizing is allowed only on pure decoration, image cells, SVG
  plots, and the 16:9 stage shell.
- Never absolutely position body copy to make it fit. Split the content or
  choose another layout.
- Every `.slide` must be a direct child of the one `.deck`; direct-child slide
  count must equal total slide count.

## Peer rows and filled boxes

Peer rows use `display:flex`, `align-items:stretch`, and `flex:1` children. A
filled card row must size from content, not from an arbitrary stage-height box:
put the row in a `flex:1` wrapper that centers it, give the row `flex:none`, and
let its tallest card determine the shared height. Uneven copy must not create
uneven card bottoms.

Use these as deliberate pairs, not interchangeable skins:

- `three-column` is ruled and supports paragraph-length prose;
  `icon-cards` is filled and supports two to four short capabilities.
- `kpi-grid` is ruled and text-led; `kpi-rosettes` is for three figures that
  deserve burst emphasis.
- `pros-cons` is two plain evidence columns; `comparison` is a stronger,
  coloured A/B decision page.

## Decoration hand-off

Content geometry does not reserve anonymous decoration slots. `tile` icons,
process `node`/connector structure, and numbered `bbadge` rosettes already live
inside their relevant layouts because they carry meaning or data; they are not
optional decoration. Image `photocell` frames are likewise content and appear
only when the source supports their subject.

After the layout passes, choose at most the role-matched organic blob, corner
dot grid, or isolated dot from `../decoration/decoration.html`. Paragraph-heavy
peer rows use hairlines, not an invented small ornament beside every paragraph.

## Verification

For every layout, render at 1600×900, inspect the result, load the colour CSS
successfully, inject longer copy into one peer, and run the playbook probe with
`SAFE=.07`. The required readings are:

`decks=1`, `navigableSlides=pages`, `orphanSlides=0`, `indirectSlides=0`,
`overflow=0`, `outsideSafeArea=0`, `aboveChromeBand=0`,
`lowContrast=0`, `boxesUnderfilledV=0`, and
`boxesUnderfilledH=0`.

The reference itself reads nonzero on `boxesUnderfilledV/H`; those are
descriptive for the reference, never claims that the reference "never does"
something. New layouts still have to read zero.
