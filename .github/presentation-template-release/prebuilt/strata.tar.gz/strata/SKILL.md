---
name: strata
description: Create, revise, or review standalone 16:9 HTML presentation decks with the Strata visual identity and direct-HTML workflow. Use when the user selects the Strata presentation template or explicitly names strata as the deck style. Best suited to Swiss-minimal brand strategy, architecture, and design-opinion presentations.
---

# Strata presentation

Create one coherent, audience-facing 16:9 HTML deck with Strata's black/white
rhythm, giant all-caps hierarchy, signal accent, asterisk spark, and stepped
brick staircase.

The default deliverable is one directly openable HTML file. Web-font links may
remain external with system fallbacks; the chosen colour-system CSS and all
deck HTML, CSS, and JavaScript belong in that file.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## Choose the task mode

- **Create:** complete Sections 1–3 before writing slide HTML, then use Sections
  4–6.
- **Revise:** reconstruct the affected outline first, preserve valid shell and
  runtime code, then use Sections 3–6.
- **Review:** use Sections 1–3 for context and Section 6 as the checklist. Do not
  edit; report slide-specific P1 / P2 / P3 findings or say there are none.

## 1. Define the communication job

- Read all supplied material before composing.
- Identify audience, purpose, desired outcome, core takeaway, and required
  evidence.
- Express the job in one sentence: by the end, the audience should reach the
  desired outcome because of the core takeaway.
- Ground every fact and number in supplied or verified sources. Label forecasts,
  targets, and assumptions.

## 2. Complete the outline before HTML

Write a lightweight outline with the throughline and ordered slides. For each
slide record its takeaway title, job, evidence, and source status. Remove
duplicate claims and repair missing evidence before choosing layouts. The
outline is the content contract, not a slot schema, and never appears in the
audience-facing deck unless requested.

## 3. Load the identity as independent layers

Read [design-system.md](design-system.md) completely. Inspect
[example/reference.jpg](example/reference.jpg) and
[layouts/](layouts/) for full-slide scale and rhythm.
Then load the split sources:

| layer                     | source                                                                                                          | purpose                                                                                         |
| ------------------------- | --------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| optional decoration, z1–7 | [decoration/PLACEMENT.md](decoration/PLACEMENT.md) and [decoration/decoration.html](decoration/decoration.html) | staircase and asterisk placement by page role                                                   |
| content, z40              | [layouts/](layouts/)                                                                                            | 38 naked flex layouts, including editorial, schedule, system, decision, and evidence structures |
| persistent chrome         | `layouts/_shell.html`                                                                                           | wordmark, running head, hairline, page number                                                   |

Build content from `layouts/`, then add decoration from `PLACEMENT.md`. Use the
reference image for rhythm, not as the source of content geometry.

Priority when constraints compete:

1. source accuracy and completeness;
2. legibility at presentation size;
3. Strata identity and chrome;
4. documented decoration roles and placement.

Decoration never displaces copy, shrinks it, or invents content.

### Colour system

Use the prompt's valid `color-system` exactly. If absent, choose only one of the
preferred tokens in `design-system.md`: `mono_ink`, `slate_corporate`,
`midnight_mono`, `nordic_frost`, or `warm_sand`. Inline exactly one atomic
colour-system CSS block and put the same token on `<html data-color-system>`.

Raw `--accent`, `--s1`, `--s2`, and `--s3` are fills, not ordinary text. Use
`--ka`, `--k1`, `--k2`, and `--k3` for coloured text on `--bg`, and matched
`--g0..--g3` / `--t0..--t3` pairs for colour fields. On a colour field a kicker
inherits the page colour with opacity.

Alternate light and colour-field pages when the page-role mix supports it.

### Images are content choices, not decoration

Use a photograph or other image whenever it communicates the slide more clearly,
credibly, or memorably than text alone. The source does not have to request one
explicitly; make that editorial choice from the content. Choose sources in this
order: user-supplied images and visual materials first, including media embedded
in or linked from the supplied material; then relevant imagery from the supplied
references and related information; then an AI-generated image grounded in the
slide's actual subject when it would work better or no suitable sourced image
exists. Never add or generate an image merely to fill a hole. Captions, alt text,
and adjacent labels remain factual and grounded in the source. When no image
improves the slide, use colour fields, figures, rules, and Strata decoration.

## 4. Choose a naked layout

Read [layouts/README.md](layouts/README.md). Start each slide from the closest
file below, adapting copy and item count without importing measured geometry
from the reference image.

| the slide is                      | use                                                                                             |
| --------------------------------- | ----------------------------------------------------------------------------------------------- |
| opening, agenda, chapter, closing | `cover` `toc` `section-divider` `close`                                                         |
| prose or quotation                | `statement` `longform` `big-quote` `bullets` `numbered-list` `two-column` `three-column`        |
| comparison or decision            | `comparison` quiet · `versus` loud · `pros-cons` with recommendation · `matrix-2x2` positioning |
| capability or sequence            | `icon-cards` `process-steps` `timeline`                                                         |
| future plan or schedule           | `roadmap` `gantt`                                                                               |
| system or idea structure          | `flow-diagram` `architecture-diagram` `mind-map`                                                |
| testimonial, tier, table, case    | `testimonials` `tier-cards` `table` `case-study`                                                |
| people and accountability         | `team`                                                                                          |
| numbers                           | `stat-highlight` `kpi-grid` `kpi-cards`                                                         |
| charts                            | `chart-bar` `chart-line` `chart-donut`                                                          |
| source-supported imagery          | `image-left` `image-right` `image-hero` `image-grid`                                            |

Choose by communication job, not visual resemblance: `timeline` is historical,
`roadmap` is outcome-led and forward-looking, and `gantt` shows scheduling.
`image-grid` is a gallery; use `team` only when roles or decision ownership are
part of the message. Do not create a duplicate file or structure under a new name.

### Universal sizing rule

No element containing text may use `cqw`, `cqh`, `px`, `vw`, or `vh` for
`width`, `max-width`, `min-width`, `height`, `left`, `top`, `right`, `bottom`,
`flex`, or `flex-basis`.

- The text safe area is 5% on each side and is set once by `.fit` padding.
- Peer columns are `flex:1;min-width:0`.
- A single filled box hugs its content with `align-self:flex-start;max-width:100%`.
- A numbered badge uses `em`, not a fixed stage unit.
- `%` is allowed only where the length is data, such as a chart bar.
- `height:1px` is allowed for a hairline.
- Absolute offsets belong to chrome or decoration, never content layout.

Primary spatial layout is flex. Preserve semantic `<table>` markup for tabular
evidence; identifiers and numbers take content width and never wrap, while the
prose column absorbs the slack.

### Filled boxes and equal height

A row of cards is `flex:none`; each card is `flex:1`, and `align-items:stretch`
equalises the row to its tallest child. Never make the card row `flex:1`, which
stretches it to the stage and leaves empty slabs. Use a surrounding `.grow` to
centre the content-sized row beneath its title. Stress-test by adding a sentence
to the first peer and confirm every sibling still has the same rendered height.

Quiet / loud pairs are:

- `three-column` / `icon-cards`;
- `kpi-grid` / `kpi-cards`;
- `comparison` / `versus`.

Use the filled sibling when the previous page already relies on hairline rules.
Light cards on a `--g3` page are valid. A `--surface` panel on `--bg` disappears
and is not valid.

## 5. Add decoration by page role

Read [decoration/PLACEMENT.md](decoration/PLACEMENT.md) before adding any
ornament. There are two optional decoration families only: the grouped
`strata-grid` staircase and the free asterisk. Individual bricks, icon tiles,
numbered badges, nodes, connectors, cards, colour fields, and grid cells are
layout structure, not decoration. The wordmark and header hairline are fixed
chrome and are excluded from optional-decoration counts. Do not invent circles,
arches, dots, gradient fields, or generic blocks.

### Staircase

- Every block is a right-aligned staircase, not a rectangle: the bottom row is
  longest and all rows end on the same right column.
- Keep every brick fully inside the stage; never crop or bleed the block.
- Use staircase blocks only for the page roles in `PLACEMENT.md` and retain the
  documented lower-third placement where applicable.

### Asterisk and structural item devices

- Place a free asterisk only where the selected page role in `PLACEMENT.md` calls for
  one, using the documented empty quadrant.
- Tiles, numbered badges, nodes, and connectors are structural devices already
  present in `icon-cards` and `process-steps`; they are not optional decoration
  and never enter decoration counts. Keep the device complete across every peer
  in its set.
- Review every decoration/text intersection. Move the ornament, never the copy, when it
  obscures a glyph or weakens immediate readability; an intentional crossing that leaves
  every word fully legible is allowed.

## How full a page should be

Measured across all 902 layouts in the 23 shared templates, so this is what the
system already does — not a target invented for the occasion:

|                                                                                  | p25 |  median | p75 |
| -------------------------------------------------------------------------------- | --: | ------: | --: |
| vertical coverage (share of the stage height that carries ink or a filled block) | 33% | **43%** | 61% |
| ink area (share of the stage area)                                               |  9% | **12%** | 16% |
| lowest ink (how far down the page the content reaches)                           | 68% | **75%** | 90% |

**Aim for the middle column.** A content page that stops at 40% of the height and
leaves the rest blank reads as unfinished; one that runs past 25% ink area reads as
a wall. Both are allowed when the material calls for it — a statement page is one
huge line at 6% coverage, a table or a longform page is legitimately dense — but
neither is the default.

Two things that are **not** the same:

- **A void at the bottom.** Content stops early and nothing follows. This is the
  one to avoid; measured on the naked layouts, 73 of 902 pages do it.
- **Air between blocks.** A title, then a band of columns centred in the space
  below it. That is composition, not a defect — do not fill it just to fill it.

If the material genuinely does not fill the page, cut a column or merge the page
into its neighbour rather than padding sentences.

## 6. Build and verify the deck

Produce one standalone HTML file with one live `.deck`. Every `.slide` must be a
**direct child** of that deck. The runtime collects slides with:

```js
[...deck.children].filter((n) => n.classList.contains("slide"));
```

A nested or orphan slide can render and screenshot normally while remaining
unreachable by keyboard. Before delivery require:

```js
document.querySelectorAll(".slide").length ===
  [...document.querySelector(".deck").children].filter((n) =>
    n.classList.contains("slide"),
  ).length;
```

Then press an arrow key yourself and test `← / ↑ / → / ↓`, `Home`, and `End`.

### Automated advisory check

- After fonts and images settle, run `tools/run.sh` once at 1600×900; rerun only when
  the HTML changes.
- The report is the visual review, so there is no need to take screenshots, create
  contact sheets, run image recognition, or visually review slides unless the user
  explicitly asks. It measures overflow, safe area, chrome band, column alignment,
  contrast, underfill, ornament vocabulary, empty photocells, text collisions, and deck
  navigation.
- Every reported item is a recommendation, never a blocker: fix the ones worth fixing
  from the slide, element, and DOM values it names; a zero report is not required.

### Mechanical checks

For the single report above, use `SAFE=0.05`.

Interpret `boxesOnFullBleed`, `darkPanels`, and a token declaration that does not paint
a visible element by page role.

Run `decoration/probe-ornaments.js` to verify complete chrome, documented asterisk and
staircase roles, structural-set completeness, stage containment, no ornament/text
overlap, and valid navigation.

### Check what the report cannot see

Confirm from computed styles that the colour-system CSS loaded, and compare the content
with the outline.

Identity audit:

- every page has wordmark, running head, hairline, and page number;
- every free asterisk follows `PLACEMENT.md`;
- each staircase is one of the documented right-aligned forms and stays wholly
  inside the stage;
- every structural tile or numbered-stage device is complete across its peer set;
- raw fill tokens are not used as ordinary text;
- `--surface` is not used as a visible panel on `--bg`;
- every decoration/type crossing remains immediately legible;
- exactly one valid colour-system token is active;
- every slide is a direct deck child and the arrow keys work.

Fix and re-render if any check fails.

## Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.

## Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Getting the container right

A percentage bar height resolves against its parent's **definite** height. Break
that chain and the bar computes to exactly `0` — it vanishes while the labels,
values and legend still render, so the page reads as merely empty. Measured on
generated decks: 52 of 558 percentage bars rendered at zero, and one deck spent
455s of gate repair on this alone.

`layouts/chart-*.html` already carries a structure that works. Copy it rather
than inventing lanes. Three rules make the chain definite:

1. **A bar is a direct child of the plot box.** Any level between them needs its
   own definite height, and one that lacks it zeroes everything below.
2. **All columns share one grid, so the label row is shared.** A label that wraps
   to two lines must cost every column the same height, or the bar above it is
   measured against a shorter ruler than its neighbours. Make the plot
   `display:grid; grid-auto-flow:column; grid-auto-columns:1fr` with
   `grid-template-rows:1fr auto …` (one row per item in a column, exactly — a
   spare row pulls the next column's first item into the previous column), and
   give each column wrapper `display:contents`. The markup grouping stays "one
   div per column"; only the rows become shared.

   Measured on the template's own `chart-bar.html`, changing nothing but one
   label to a wrapping name: baseline offset 0 → 19px, and the fourth bar 342 →
   324px — the value never changed, the bar just lost 5%. With the shared grid
   the same label costs all four bars the same 8%, and the ratios stay exact.

3. **Every level is either `flex:none` or `flex:1`** — sized by its content, or
   taking the remainder. There is no third kind.

4. **A value label never shares the lane with the bar it labels.** If it does,
   flex has to fit label + gap + bar into the lane, so it shrinks the bar — and
   only the bars tall enough to run out of room. The scale stops being linear at
   the top: measured on `bloom/chart-bar.html`, lane 336px, label 19px, gap 6px,
   every value above 92.5% rendered at the same 310px, so **96 and 100 drew
   identically**. Under the template's own "percentages of the tallest value"
   convention the tallest bar is always 100%, so this fires on every chart.
   Reserve the label row on the lane (`padding-top`, measured once per template)
   and set both children `flex:none`; the bar then resolves against the lane
   minus that reserve, the same reserve for every column.

Grouping two bars per category still obeys this, but the group wrapper needs
`align-self:stretch`, or it is sized by content and the lane inside it collapses.

Do not "fix" a flat chart by enlarging the numbers or switching to a table. The
values are right; the container chain is not.
