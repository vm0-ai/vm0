---
name: strata
description: Create a standalone 16:9 HTML presentation deck with the Strata visual identity and direct-HTML workflow. Use when the user selects the Strata presentation template or explicitly names strata as the deck style. Best suited to Swiss-minimal brand strategy, architecture, and design-opinion presentations.
---

# Strata presentation

Create one coherent, audience-facing 16:9 HTML deck with Strata's black/white
rhythm, giant all-caps hierarchy, signal accent, asterisk spark, and stepped
brick staircase.

The default deliverable is one directly openable HTML file. Web-font links may
remain external with system fallbacks; the chosen colour-system CSS and all
deck HTML, CSS, and JavaScript belong in that file.

Batch-read each step's required local files and any chosen layouts; do not reread unchanged files.

## Shared layout geometry

- Center the slide's narrative content as one group inside the `.fit` safe area. The
  safe area is defined by that template's padding; do not center against the full
  canvas.
- In a side-by-side composition, vertically center each peer inside its own column. In
  a stacked composition, center the complete stack as one group.
- For any horizontal group of peer cards, tiles, quote boxes, pricing tiers, flow
  nodes, or similar content containers, make the row content-sized and use
  `align-items: stretch`. Do not give the cards a shared fixed height: the peer
  with the most content sets that row's height and every sibling stretches to match.
  Apply this independently to each row in a wrapped or grid group; `center`,
  `flex-start`, and `flex-end` are invalid cross-axis values for such a peer row.
- Keep `4cqh` between the primary slide title and the next narrative block. Persistent
  mastheads, page numbers, required footnotes, and other mandated top/bottom chrome stay
  fixed and are excluded from the centered group.
- Keep `object-fit: contain` media whole: fixed-ratio cells may shrink and center in
  their lane, while a no-aspect growing media cell may adopt the loaded image's natural
  ratio. Cover and full-bleed compositions keep their authored sizing.

## 1. Plan the deck

- Read the prompt and every supplied material first. Name the audience, the outcome you
  want from them, and the one takeaway that gets them there.
- Write a short outline before any HTML: the throughline, then one line per slide with
  its takeaway title, the point it makes, and the evidence behind it. Let the content
  decide the slide count.
- Ground every number in supplied or verified sources, and label forecasts, targets, and
  assumptions as such.
- The outline is a content contract, not a layout plan. Keep it out of the deck.

## 2. Build the deck

Produce one standalone HTML file with one live `.deck`. Every `.slide` must be a
**direct child** of that deck. The runtime collects slides with:

```js
[...deck.children].filter((n) => n.classList.contains("slide"));
```

A nested or orphan slide can render and screenshot normally while remaining
unreachable by keyboard. Keep this structural invariant:

```js
document.querySelectorAll(".slide").length ===
  [...document.querySelector(".deck").children].filter((n) =>
    n.classList.contains("slide"),
  ).length;
```

The final QA dispatches arrows, Home, and End and verifies the live state; do not add a
manual key pass.

### Choose a naked layout

Read [layouts/README.md](layouts/README.md). Start each slide from the closest
file below, adapting copy and item count without importing measured geometry
from the reference image.

| the slide is                      | use                                                                                             |
| --------------------------------- | ----------------------------------------------------------------------------------------------- |
| opening, agenda, chapter, closing | `cover` `toc` `section-divider` `close`                                                         |
| prose or quotation                | `statement` `longform` `big-quote` `bullets` `numbered-list` `two-column` `three-column`        |
| comparison or decision            | `comparison` quiet · `versus` loud · `pros-cons` with recommendation · `matrix-2x2` positioning |
| capability or sequence            | `icon-cards` `process-steps` `timeline`                                                         |
| future plan or schedule           | `roadmap` `gantt`                                                                               |
| system or idea structure          | `flow-diagram` `architecture-diagram` `mind-map`                                                |
| testimonial, tier, table, case    | `testimonials` `tier-cards` `table` `case-study`                                                |
| people and accountability         | `team`                                                                                          |
| numbers                           | `stat-highlight` `kpi-grid` `kpi-cards`                                                         |
| charts                            | `chart-bar` `chart-line` `chart-donut`                                                          |
| source-supported imagery          | `image-left` `image-right` `image-hero` `image-grid`                                            |

Choose by communication job, not visual resemblance: `timeline` is historical,
`roadmap` is outcome-led and forward-looking, and `gantt` shows scheduling.
`image-grid` is a gallery; use `team` only when roles or decision ownership are
part of the message. Do not create a duplicate file or structure under a new name.

#### Universal sizing rule

No element containing text may use `cqw`, `cqh`, `px`, `vw`, or `vh` for
`width`, `max-width`, `min-width`, `height`, `left`, `top`, `right`, `bottom`,
`flex`, or `flex-basis`.

- The text safe area is 5% on each side and is set once by `.fit` padding.
- Peer columns are `flex:1;min-width:0`.
- A single filled box hugs its content with `align-self:flex-start;max-width:100%`.
- A numbered badge uses `em`, not a fixed stage unit.
- `%` is allowed only where the length is data, such as a chart bar.
- `height:1px` is allowed for a hairline.
- Absolute offsets belong to chrome or decoration, never content layout.

Primary spatial layout is flex. Preserve semantic `<table>` markup for tabular
evidence; identifiers and numbers take content width and never wrap, while the
prose column absorbs the slack.

#### Filled boxes and equal height

A row of cards is `flex:none`; each card is `flex:1`, and `align-items:stretch`
equalises the row to its tallest child. Never make the card row `flex:1`, which
stretches it to the stage and leaves empty slabs. Use a surrounding `.grow` to
centre the content-sized row beneath its title. Stress-test by adding a sentence
to the first peer and confirm every sibling still has the same rendered height.

Quiet / loud pairs are:

- `three-column` / `icon-cards`;
- `kpi-grid` / `kpi-cards`;
- `comparison` / `versus`.

Use the filled sibling when the previous page already relies on hairline rules.
Light cards on a `--g3` page are valid. A `--surface` panel on `--bg` disappears
and is not valid.

### Load the identity

Read `tools/qa-config.json` before writing chrome. On each applicable
`.stage`, put every required item on one visible wrapper with the exact
`data-chrome="<role>"` name from `requiredChrome`, and preserve any `min`, `max`,
and `when` rule.

Read [design-system.md](design-system.md) completely. Inspect
[example/reference.jpg](example/reference.jpg) and
[layouts/](layouts/) for full-slide scale and rhythm.
Then load the split sources:

| layer                     | source                                                                                                          | purpose                                                                                         |
| ------------------------- | --------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| optional decoration, z1–7 | [decoration/PLACEMENT.md](decoration/PLACEMENT.md) and [decoration/decoration.html](decoration/decoration.html) | staircase and asterisk placement by page role                                                   |
| content, z40              | [layouts/](layouts/)                                                                                            | 38 naked flex layouts, including editorial, schedule, system, decision, and evidence structures |
| persistent chrome         | `layouts/_shell.html`                                                                                           | wordmark, running head, hairline, page number                                                   |

Build content from `layouts/`, then add decoration from `PLACEMENT.md`. Use the
reference image for rhythm, not as the source of content geometry.

Priority when constraints compete:

1. source accuracy and completeness;
2. legibility at presentation size;
3. Strata identity and chrome;
4. documented decoration roles and placement.

Decoration never displaces copy, shrinks it, or invents content.

#### Colour system

Use the prompt's valid `color-system` exactly. If absent, choose only one of the
preferred tokens in `design-system.md`: `mono_ink`, `slate_corporate`,
`midnight_mono`, `nordic_frost`, or `warm_sand`. Inline exactly one atomic
colour-system CSS block and put the same token on `<html data-color-system>`.

Raw `--accent`, `--s1`, `--s2`, and `--s3` are fills, not ordinary text. Use
`--ka`, `--k1`, `--k2`, and `--k3` for coloured text on `--bg`, and matched
`--g0..--g3` / `--t0..--t3` pairs for colour fields. On a colour field a kicker
inherits the page colour with opacity.

Alternate light and colour-field pages when the page-role mix supports it.

- An image is a content choice, not decoration: use one when it carries the slide
  better than text can. Take it from the supplied material first, then the supplied
  references, then generate one grounded in that slide's actual subject. Never add an
  image to fill space, and never write a caption the material does not support.
  improves the slide, use colour fields, figures, rules, and Strata decoration.

### Add decoration by page role

Read [decoration/PLACEMENT.md](decoration/PLACEMENT.md) before adding any
ornament. There are two optional decoration families only: the grouped
`strata-grid` staircase and the free asterisk. Individual bricks, icon tiles,
numbered badges, nodes, connectors, cards, colour fields, and grid cells are
layout structure, not decoration. The wordmark and header hairline are fixed
chrome and are excluded from optional-decoration counts. Do not invent circles,
arches, dots, gradient fields, or generic blocks.

#### Staircase

- Every block is a right-aligned staircase, not a rectangle: the bottom row is
  longest and all rows end on the same right column.
- Keep every brick fully inside the stage; never crop or bleed the block.
- Use staircase blocks only for the page roles in `PLACEMENT.md` and retain the
  documented lower-third placement where applicable.

#### Asterisk and structural item devices

- Place a free asterisk only where the selected page role in `PLACEMENT.md` calls for
  one, using the documented empty quadrant.
- Tiles, numbered badges, nodes, and connectors are structural devices already
  present in `icon-cards` and `process-steps`; they are not optional decoration
  and never enter decoration counts. Keep the device complete across every peer
  in its set.
- Review every decoration/text intersection. Move the ornament, never the copy, when it
  obscures a glyph or weakens immediate readability; an intentional crossing that leaves
  every word fully legible is allowed.

### Charts

Decide the form before anything else — and first ask whether it should be a chart
at all.

| The data is                                   | Use                 | Not                 |
| --------------------------------------------- | ------------------- | ------------------- |
| One number, maybe with a change               | a stat tile         | a one-bar chart     |
| A handful of headline numbers                 | a row of stat tiles | a grouped bar chart |
| One ratio against a limit                     | a meter             | a two-slice pie     |
| More than about seven classes that all matter | a table             | more colours        |

If a chart is right, the reader's job picks the type:

| The reader must                      | Form                                           |
| ------------------------------------ | ---------------------------------------------- |
| compare magnitudes                   | bar or column                                  |
| follow a trend over time             | line; area for a single series                 |
| tell distinct series apart           | grouped/stacked bar, multi-line                |
| **see that one series is the point** | **emphasis — colour that one, grey the rest**  |
| judge above/below a baseline         | diverging bar                                  |
| read part-to-whole                   | stacked bar; go horizontal when names are long |

Emphasis is the most underused of these. When the story is "this one moved,"
that is emphasis, not a palette.

**Colour carries a job, not decoration.** One hue light-to-dark for magnitude;
distinct hues only when the series themselves are the subject; two hues with a
neutral midpoint for polarity. Never a rainbow ramp, never a hue at the midpoint
of a diverging scale. Colour follows the entity — drop a series and the survivors
keep their hues.

**Never put two y-scales on one plot.** Aligning them is arbitrary, so the chart
invents a correlation the data does not contain. Two measures of different
magnitude become two charts, or both indexed to a common base.

**Labelling.** Two or more series always carry a legend; a single series needs
none — the title already names it. Direct-label selectively: the endpoint, the
extreme, the series that matters. Never a number on every point. Values and
labels wear the template's ink colours, never the series colour — the swatch
beside them already carries identity. A label that does not fit inside its mark
goes outside it; never let one be clipped.

**Geometry.** Bars grow from one shared baseline and stay thinner than their
slot — the leftover space is part of the composition. Separate touching marks
with a gap in the surface colour rather than a border. Size the container to
include the axis labels, not just the plot.

### Authoring checklist and final QA

Complete the following checks while authoring, before Automated QA. They protect
content and template identity; they do not create a second phase after the gate is green.

#### Mechanical authoring checks

The root `data-safe-area="0.05"` supplies the template constant to the single report.

Interpret `boxesOnFullBleed`, `darkPanels`, and a token declaration that does not paint
a visible element by page role.

Run `decoration/probe-ornaments.js` to verify complete chrome, documented asterisk and
staircase roles, structural-set completeness, stage containment, no ornament/text
overlap, and valid navigation.

#### Identity checks while authoring

- every page has wordmark, running head, hairline, and page number;
- every free asterisk follows `PLACEMENT.md`;
- each staircase is one of the documented right-aligned forms and stays wholly
  inside the stage;
- every structural tile or numbered-stage device is complete across its peer set;
- raw fill tokens are not used as ordinary text;
- `--surface` is not used as a visible panel on `--bg`;
- every decoration/type crossing remains immediately legible;
- exactly one valid colour-system token is active;
- every slide is a direct deck child and the arrow keys work.

Resolve any failure before running Automated QA.

#### Final delivery contracts

- Build reusable structure only from `layouts/`; use `example/reference.jpg` only for visual identity. No full-deck example is part of this template package.
- Preserve the selected layout root `data-safe-area` value and its `.fit` padding.
- Every `[data-photocell]` must contain a successfully loaded `<img>` or a CSS `url(...)`. A solid fill or gradient is not an image. When no suitable image is used, remove the media cell and select a non-media layout.
- `tools/pdf_figures.sh <paper.pdf> <out-dir> [figure numbers]` writes one tight crop per figure of a source PDF in a single pass. Called with no arguments it prints its own contract.

#### Automated QA

- After fonts and images settle, run `tools/run.sh --final <deck>` once at 1600×900.
- The JSON report is primary, and it reports only what is non-zero. A counter that is
  absent read zero; there is nothing behind it to look up or look at.
- A passing report is `status: READY_TO_PUBLISH`, `hardGateFailures: 0`, `next: publish`,
  and no findings at all. That is the whole verdict. Publish.
- A blocked report carries a `blocking` object. Fix every finding in it, then run the
  command again. Anything under `advisory` does not block: you do not have to fix it, and
  you do not have to explain why you are not fixing it.
- A finding states its own measurement — how far past, which element, what to drop. That
  measurement is the answer. Do not go and take it again with a browser of your own.
- The same command returns `qaImage`. It exists so a failing gate can be looked at, and
  for nothing else. When `hardGateFailures` is `0` you are done: do not open it, crop it,
  zoom it, or run recognition on it. The JSON verdict is the whole answer.
- `ornamentContrastCandidates`, `surfaceVisibilityCandidates`, and every other
  non-gate finding remain advisory. `targetedReviewPages` identifies potentially useful
  pages but does not require a visual review.
- If an optional review leads to an HTML change, rerun the same QA command to receive a
  fresh JSON report and `qaImage`. If the HTML did not change, do not rerun QA.
- Do not capture screenshots separately or build another screenshot/contact-sheet
  pipeline. Do not re-audit the hosted URL after publishing.
- Treat `tools/run.sh` and `tools/audit.js` as opaque executables. The command above
  and the thirteen gate counters listed here are the complete contract, so there is
  nothing left to look up. Do not open, read, grep or reason about the implementation
  of either file — not to reverse-engineer a finding, not to discover which counters
  gate, not before authoring. Reading them cannot change how you call the gate; it
  only adds measured time. Use the named page and rendered DOM details in the report.
- When `hardGateFailures` is `0` and `status` is `READY_TO_PUBLISH`, output
  exactly `没监测到问题，可以交付。`, publish the deck, and stop.
