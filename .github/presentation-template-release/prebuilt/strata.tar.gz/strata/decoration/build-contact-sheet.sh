#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-/tmp/strata-decoration-contact.html}"
COLOR_FILE="$HERE/../color-systems/mono_ink.css"

COLOR_FILE="$COLOR_FILE" perl -0ne '
  if (/(.*?<body>)/s) {
    $h=$1;
    open my $cf,"<",$ENV{COLOR_FILE} or die $!;
    local $/; $css=<$cf>;
    $h=~s{<link rel="stylesheet" href="../color-systems/mono_ink.css">}{};
    $h=~s{</head>}{<style>$css</style><style>
      .deck{height:auto;overflow:visible}
      .stage::before{content:"OPTIONAL MOTIFS · GRID GROUP COUNTS ONCE · FIXED CHROME OMITTED";
        position:absolute;left:1.2cqw;top:1.2cqh;z-index:80;
        background:var(--ink);color:var(--bg);padding:.55cqh .7cqw;
        font:600 .72cqw/1 var(--fd),sans-serif;letter-spacing:.08em}
      .stage::after{content:attr(data-preview-name);position:absolute;
        left:1.2cqw;bottom:1.2cqh;z-index:80;background:var(--accent);
        color:var(--oa);padding:.55cqh .7cqw;
        font:600 .78cqw/1 var(--fd),sans-serif;letter-spacing:.06em;
        text-transform:uppercase}
    </style></head>};
    $h=~s{<title>.*?</title>}{<title>strata — optional decoration contact sheet</title>}s;
    print $h,"\n<div class=\"deck\" aria-label=\"Strata optional decoration contact sheet\">\n";
  }
' "$HERE/decoration.html" > "$OUT"

perl -0ne '
  if (m{<div class="deck"[^>]*>(.*)</div>\s*<script data-deck-navigation>}s) {
    $s=$1;
    $s=~s{<div class="wordmark" data-chrome=.*?</div>}{}gs;
    $s=~s{<div class="(?:running-head|hairline|pagenum)" data-chrome=.*?</div>}{}gs;
    print $s,"\n";
  }
' "$HERE/decoration.html" >> "$OUT"

printf '%s\n' '</div>' >> "$OUT"
printf '%s\n' '<script data-deck-navigation>' >> "$OUT"
printf '%s\n' '(() => { const d=document.querySelector(".deck"),s=[...d.children].filter(n=>n.classList.contains("slide"));let i=0;document.addEventListener("keydown",e=>{let n;if(["ArrowRight","ArrowDown"].includes(e.key))n=i+1;else if(["ArrowLeft","ArrowUp"].includes(e.key))n=i-1;else if(e.key==="Home")n=0;else if(e.key==="End")n=s.length-1;else return;e.preventDefault();i=Math.max(0,Math.min(s.length-1,n));s[i].scrollIntoView({block:"start"});});})();' >> "$OUT"
printf '%s\n' '</script></body></html>' >> "$OUT"

printf '%s\n' "$OUT"
