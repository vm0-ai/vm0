# strata — where the decoration goes

Every number here was measured from the original reference deck at 1600×900, 15 pages.
Where a figure contradicts the prose that used to be in `design-system.md`, the
measurement wins and the contradiction is called out.

After fonts settle, run `probe-ornaments.js` in the page. The reference reads:

```text
chrome 15/15 complete · asterisks 15 · grid blocks 8 · bricks 120
bricks outside stage 0 · structural-set pages 2/2 complete · partial sets 0
ornament/text overlaps 0 · navigation 1 / 15 / 0 / 0
```

The optional decoration vocabulary has **two items only**: the grouped
`strata-grid` staircase and the free `asterisk`. A whole staircase counts once;
its square bricks are internal grid units and do not count separately. Fixed
chrome is required on every page but is excluded from optional-decoration
counts and from the decoration preview. Do not invent circles, arches, colour
blocks, dots, or gradient fields — strata has none of them.

| optional decoration | uses | pages | marker |
|---|---|---|---|
| `strata-grid` — the grouped brick staircase | 8 groups (120 internal bricks) | 8 of 15 | `data-decoration="strata-grid"` / `data-gridblock` |
| `asterisk` — the signal spark | 15 | 15 of 15 | `data-decoration="asterisk"` / `data-asterisk` |

The wordmark, running head, hairline, and page number are fixed chrome. Icon
tiles, numbered badges, nodes, connectors, cards, colour fields, content
containers, rectangles, and individual grid cells are layout/content. None of
those enter the optional-decoration count.

Image placeholders (`data-photocell`, 13 across 5 pages) are **content**, not
decoration. Never add one to fill space.

---

## 1. The staircase is never cropped by the stage edge

This is the one that would have been guessed wrong. Before the split, the
generic guidance said *"a large ornament must be cropped by the stage edge rather
than floated in the middle of the composition."* The split sources now correct
that statement.

**The reference does that zero times out of 120 bricks.** Every block sits whole,
inside the stage:

```
block bounding boxes, % of stage      bricks  shape
cover        ( 5.0, 74.8) – (29.6, 92.9)   13   7 cols × 3 rows
divider ×3   (70.0, 70.7) – (93.4, 90.9)   12   6 × 3   <- all three identical
content/stat (32.4, 48.2) – (69.3, 88.8)   23   8 × 5
content/lead (73.0, 20.0) – (92.4, 47.4)   12   5 × 4
content/kpi  (59.6, 18.0) – (93.3, 55.0)   23   8 × 5
close        (67.4, 71.7) – (93.4, 90.9)   13   7 × 3

left edge   min 5.0    right edge  max 93.4
top edge    min 18.0   bottom edge max 92.9
bleeding    0 / 120 bricks
```

So: **place the block wholly inside the safe area.** It may sit flush against the
5% margin (the cover does) but nothing hangs off. The prose rule has been
corrected in `SKILL.md`.

## 2. The block is a right-aligned staircase, not a rectangle

Bottom row is the longest; each row above is shorter, and they all end on the
same right-hand column. Measured shapes, `#` = a brick:

```
 3 rows / 7 cols        3 rows / 6 cols        5 rows / 8 cols       4 rows / 5 cols
   .....##                 ....##                .......#              ....#
   ...####                 ..####                .....###              ...##
   #######                 ######                ...#####              .####
                                                 ..######              #####
                                                 ########
```

Brick side is **3–4cqw**, pitch is brick **+ .6–.75cqw**, corner radius is a
literal `.7cqw` — the one rounded thing in a template whose `--r-*` tokens are all
forced to `0`.

The ramp is a function of the **column**, not of the brick index: the same column
carries the same colour in every row. It runs `color-mix(in srgb, var(--accent)
X%, var(--g3))` with X spread evenly from **16% at the left to 100% at the right**.
For 7 columns that is 16 / 30 / 44 / 58 / 72 / 86 / 100.

## 3. One block per page, on half the pages, and only these page roles

8 of 15 pages carry a staircase. Every one of those carries **exactly one**;
never two.

| carries a staircase (8/8) | carries none (7/7) |
|---|---|
| cover, all three section dividers, close | toc |
| the statement page, the hero-stat page, the KPI page | the pages with a set: photo grid, cards, process steps, testimonials, pricing |

The rule that produces this split: **the staircase fills a region the content has
left empty.** A page that already carries a row of cards, photos or steps is
full, and gets none. Do not add one to a busy page to hit a count.

## 4. The asterisk is on every page, exactly once

15 pages, 15 asterisks, in addition to the one in the wordmark. Width 5–7cqw.

Position is the empty quadrant, and in practice that is the right edge: **13 of
15 sit at x = 85–88%**, the other two at x = 5%. Vertical position ranges 15–81%
— it follows the hole in the composition, not a fixed slot.

It is `--accent` on a light page and on `--g3`; on the `--g0` divider it is
`--t0`. It is drawn behind content (`z-index:7`, under `.fit` at 40).

## 5. Structural item devices come as a complete set

Tiles, badges, nodes, and connectors are not decoration. They are structural
devices inside two naked layouts, and the completeness check is reported
separately from optional-decoration counts. Both reference pages give every
peer the same device, with grounds cycling `--g0 → --g1 → --g2 → --g3`:

- services page: 4 cards, 4 tiles, `--sz:5cqw`
- process page: 4 steps, 4 numbered discs, `--sz:6cqw`

Copyable markup is already in `../layouts/icon-cards.html` and
`../layouts/process-steps.html`. Use the complete row; do not put a device on
only one peer.

## 6. Nothing sits on top of type

Measured on the reference: **0 overlaps** between any painted brick, asterisk or
rule and any text run (≥2% of the text's box). This reads zero, so it gates.

Watch the measurement, not the wrapper: a staircase's bounding box is mostly
empty air, because the block is a triangle. Judging the wrapper reports two false
overlaps on the hero-stat page where the bricks themselves are nowhere near the
paragraph.

## 7. The lower third is the decoration zone

The staircase lives low on 6 of its 8 pages (bottom edge 71–93%). Do not
bottom-anchor content to "fill" a page that looks empty — overlay the block
first and check what lands where. A naked layout with an empty lower half is
usually correct.

## 8. Colour facts specific to strata

Measured on `mono_ink`, and re-checked across all five preferred tokens.

- **`--surface` is invisible on `--bg`.** `#FAFAFA` on `#FFFFFF` is **1.02:1**.
  The reference never writes `var(--surface)` inline; the only occurrence is the
  `.card` class definition. All 4 cards in the reference sit on a **dark**
  page, where the same fill reads clearly. So: `.card` belongs on a colour
  field, never on the white page.
- **Boxes on a full-bleed page are correct here.** The reference does it 5 times
  — this is the opposite of bloom, whose reference has none. strata's services
  page is four white cards on `--g3`, and that composition is the template.
- **8 of 15 pages are colour fields** (`fullBleedPct 0.53`), not one in four.
  Light and dark pages alternate; all three dividers, the cover and the close
  are dark.
- **Fill-only tokens.** Contrast as text on `--bg`, per token:

  | token | mono_ink | slate_corporate | midnight_mono | nordic_frost | warm_sand |
  |---|---|---|---|---|---|
  | `--accent` | 4.24 | 5.95 | 15.75 | 3.34 | **2.18** |
  | `--s1` | 19.80 | 3.47 | 3.84 | **1.90** | **2.25** |
  | `--s2` | **1.84** | **2.14** | **1.71** | **1.73** | **1.73** |
  | `--ka` | 19.80 | 5.95 | 15.75 | 14.36 | 14.89 |
  | `--k1` | 19.80 | 15.56 | 16.57 | 14.36 | 14.89 |

  `--s2` fails everywhere; `--accent` and `--s1` fail under some tokens. Use
  `--ka` / `--k1` for coloured text and keep `--accent`, `--s1`, `--s2`, `--s3`
  for fills. The reference's own agenda numerals used `--accent` and `--s1` and
  have been corrected — legible in `mono_ink`, invisible in `warm_sand`.
- On a full-bleed page a kicker uses `color:inherit;opacity:.72`, never `--ka`,
  which resolves to the ink colour and disappears.
- The page number needs `opacity:.8`, not `.65`. At `.65` it reads **2.84:1** on
  the `--g0` divider ground; at `.8` it reads 3.61 and clears 3.0 on every
  preferred token.
