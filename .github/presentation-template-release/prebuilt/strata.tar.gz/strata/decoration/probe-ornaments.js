// Run after fonts settle. Supports both the legacy reference markup and the
// explicit data-* markers used by the split decoration layer.
(() => {
  const stages = [...document.querySelectorAll('.slide .stage, .stage')];
  const ownText = e => [...e.childNodes].filter(n => n.nodeType === 3)
    .map(n => n.textContent.trim()).join('').trim();
  const directSvg = e => [...e.children].some(c => c.matches('svg'));
  const legacyGrid = e => e.matches('[data-doodle]') && !directSvg(e) &&
    [...e.children].filter(c => c.matches('div') && !c.textContent.trim()).length >= 8;
  const isWordmark = e => e.matches('[data-chrome="wordmark"]') ||
    (e.matches('[data-doodle]') && directSvg(e) && e.textContent.trim().length > 0);
  const isAsterisk = e => e.matches('[data-asterisk]') ||
    (e.matches('[data-doodle]') && directSvg(e) && !e.textContent.trim());
  const isGrid = e => e.matches('[data-gridblock]') || legacyGrid(e);
  const intersects = (a,b) => {
    const w = Math.max(0, Math.min(a.right,b.right)-Math.max(a.left,b.left));
    const h = Math.max(0, Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top));
    return w*h;
  };

  const out = {
    pages: stages.length,
    wordmarks: 0, hairlines: 0, pageNumbers: 0, runningHeads: 0,
    pagesWithCompleteChrome: 0,
    asterisks: 0, pagesWithOneAsterisk: 0,
    gridBlocks: 0, gridPages: 0, pagesWithExactlyOneGrid: 0,
    bricks: 0, bricksOutsideStage: 0, lowerThirdGridBlocks: 0,
    declaredDecorationGroups: 0,
    structuralTiles: 0, structuralNodes: 0, structuralConnectors: 0,
    structuralSetPages: 0, completeStructuralSetPages: 0, partialStructuralSetPages: 0,
    ornamentTextOverlaps: 0,
    decks: document.querySelectorAll('.deck').length,
    navigableSlides: 0, orphanSlides: 0, indirectSlides: 0,
    samples: []
  };
  const decorationFamilies = new Set();

  stages.forEach((st, pi) => {
    const sr = st.getBoundingClientRect();
    const doodles = [...st.querySelectorAll('[data-doodle],[data-chrome="wordmark"],[data-asterisk]')];
    const wordmarks = doodles.filter(isWordmark);
    const asterisks = doodles.filter(isAsterisk);
    const gridBlocks = [...st.querySelectorAll('[data-gridblock],[data-doodle]')]
      .filter(isGrid).filter((x,i,a) => a.indexOf(x) === i);
    const declared = [...st.querySelectorAll('[data-decoration]')];
    out.declaredDecorationGroups += declared.length;
    declared.forEach(d => decorationFamilies.add(d.dataset.decoration));
    const hairlines = [...st.querySelectorAll('[data-bigcircle],[data-chrome="hairline"]')]
      .filter((x,i,a) => a.indexOf(x) === i);
    const pageNums = [...st.querySelectorAll('.pagenum,[data-chrome="page-number"]')]
      .filter((x,i,a) => a.indexOf(x) === i);
    const running = [...st.querySelectorAll('[data-chrome="running-head"]')];
    if (!running.length) {
      [...st.children].forEach(e => {
        if (e.matches('.fit,.pagenum,[data-doodle],[data-bigcircle],[data-photocell]')) return;
        const s = e.getAttribute('style') || '';
        if (/right:\s*5cqw/.test(s) && /top:\s*5cqh/.test(s) && ownText(e)) running.push(e);
      });
    }

    out.wordmarks += wordmarks.length;
    out.asterisks += asterisks.length;
    out.hairlines += hairlines.length;
    out.pageNumbers += pageNums.length;
    out.runningHeads += running.length;
    if (wordmarks.length === 1 && hairlines.length === 1 && pageNums.length === 1 && running.length === 1)
      out.pagesWithCompleteChrome++;
    if (asterisks.length === 1) out.pagesWithOneAsterisk++;

    out.gridBlocks += gridBlocks.length;
    if (gridBlocks.length) out.gridPages++;
    if (gridBlocks.length === 1) out.pagesWithExactlyOneGrid++;
    gridBlocks.forEach(g => {
      const bricks = [...g.querySelectorAll('[data-brick]')];
      if (!bricks.length) bricks.push(...[...g.children].filter(c => c.matches('div') && !c.textContent.trim()));
      out.bricks += bricks.length;
      bricks.forEach(b => {
        const r=b.getBoundingClientRect();
        if (r.left < sr.left-1 || r.right > sr.right+1 || r.top < sr.top-1 || r.bottom > sr.bottom+1)
          out.bricksOutsideStage++;
      });
      const r=g.getBoundingClientRect();
      if ((r.bottom-sr.top)/sr.height >= .70) out.lowerThirdGridBlocks++;
    });

    const tiles = [...st.querySelectorAll('[data-tile]')];
    const nodes = [...st.querySelectorAll('[data-node]')];
    out.structuralTiles += tiles.length; out.structuralNodes += nodes.length;
    out.structuralConnectors += st.querySelectorAll('[data-connector]').length;

    const decoratedItems = [...tiles,...nodes];
    if (decoratedItems.length) {
      out.structuralSetPages++;
      let complete=false, n=decoratedItems[0].parentElement;
      while (n && n !== st) {
        const peers=[...n.children].filter(k => k.textContent.trim() || k.querySelector('[data-tile],[data-node]'));
        if (peers.length >= 3 && decoratedItems.every(d => n.contains(d))) {
          const covered=peers.filter(k => k.querySelector('[data-tile],[data-node]')).length;
          complete=covered === peers.length;
          break;
        }
        n=n.parentElement;
      }
      complete ? out.completeStructuralSetPages++ : out.partialStructuralSetPages++;
    }

    const ornamentRects=[...asterisks];
    gridBlocks.forEach(g => {
      let b=[...g.querySelectorAll('[data-brick]')];
      if (!b.length) b=[...g.children].filter(c => c.matches('div') && !c.textContent.trim());
      ornamentRects.push(...b);
    });
    const fit=st.querySelector('.fit');
    if (fit && ornamentRects.length) {
      fit.querySelectorAll('*').forEach(e => {
        const t=ownText(e); if (t.length < 2) return;
        const rg=document.createRange(); rg.selectNodeContents(e);
        const runs=[...rg.getClientRects()].filter(r => r.width>2 && r.height>2);
        const hit=runs.some(tr => ornamentRects.some(o => {
          const area=intersects(tr,o.getBoundingClientRect());
          return area/(tr.width*tr.height) >= .02;
        }));
        if (hit) {
          out.ornamentTextOverlaps++;
          if (out.samples.length < 8) out.samples.push(`p${pi+1} ornament/text "${t.slice(0,24)}"`);
        }
      });
    }
  });

  const decks=[...document.querySelectorAll('.deck')];
  const slides=[...document.querySelectorAll('.slide')];
  out.navigableSlides=decks.reduce((n,d)=>n+[...d.children].filter(c=>c.classList.contains('slide')).length,0);
  out.orphanSlides=slides.filter(s=>!s.closest('.deck')).length;
  out.indirectSlides=slides.filter(s=>s.closest('.deck') && s.parentElement!==s.closest('.deck')).length;
  out.gridBlocksPerPage=+(out.gridBlocks/(out.pages||1)).toFixed(3);
  out.bricksPerPage=+(out.bricks/(out.pages||1)).toFixed(3);
  out.asterisksPerPage=+(out.asterisks/(out.pages||1)).toFixed(3);
  out.completeChromePct=+(out.pagesWithCompleteChrome/(out.pages||1)).toFixed(3);
  out.optionalDecorationFamilies=[...decorationFamilies].sort();
  return JSON.stringify(out,null,1);
})()
