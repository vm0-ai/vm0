# Strata

## Visual identity

Swiss minimalism: predominantly black and white with a signal-red accent, giant all-caps titles, a single asterisk, and stepped rounded bricks in tonal progression. Restrained and powerful.

## Color system tokens

Read `color-system` from the prompt before generation. If the prompt supplies one of the valid tokens below, use it exactly. If it omits the token, let the Agent choose from the list based on content, audience, mood, information density, and readability. Use one token for the entire deck.

The demonstration category documented for this template is **M (single-primary)**, with example token `mono_ink`; generation still follows the rule above.

Use only the following snake_case token values:

- M, single-primary: `warm_sand`, `bauhaus_primary`, `nordic_frost`, `forest_editorial`, `coral_studio`, `slate_corporate`, `terracotta_clay`, `berry_pop`, `citrus_fresh`, `mauve_dusk`, `mono_ink`, `sunset_maroon`, `mint_tech`, `midnight_mono`, `ocean_deep`, `gold_luxe`.
- V, multicolour: `prism`, `carnival`, `pop_art`.

**Preferred tokens for this template.** When `prompt.md` does not name a
`color-system`, choose one of these and nothing else:

`mono_ink`, `slate_corporate`, `midnight_mono`, `nordic_frost`, `warm_sand`

The default color system used in `example/reference.jpg` is `mono_ink`.
Picking a token outside this list is how a deck ends up looking like a different
template: a finance source, for instance, pulls every template toward the same
muted corporate grey unless the list stops it.


After choosing a token, read `color-systems/<token>.css`, inline its only CSS block in the final HTML, and write the same token on the document root. The canonical root value is:

```html
<html data-color-system="mono_ink">
```

- Use `--bg`, `--surface`, `--ink`, `--soft`, and `--ph` for the page, surfaces, primary text, secondary text, and image placeholders.
- `--accent`, `--s1`, `--s2`, and `--s3` are raw hues for decoration and non-text graphics. `--oa`, `--o1`, `--o2`, and `--o3` are the decorative foreground colours selected for those hues in v1, for large icons or decorative symbols. Use the contrast-safe text tokens below for ordinary text.
- On the standard `--bg`, use the contrast-safe `--ka`, `--k1`, `--k2`, and `--k3` for text; use `--kad` for accent text on an `--ink` colour field. When a raw hue needs more text contrast, these tokens fall back to the corresponding readable text colour.
- For large colour fields containing text, use `--g0` through `--g3` and pair each with its matching `--t0` through `--t3`.
- HTML/CSS components reference colours only through `var(--...)`; derive transparency, outlines, shadows, and gradients from defined tokens as well.

Alternate light and dark pages using `--bg` and `--g3` to establish the main rhythm. Let `--accent` carry only one signal focus, while `--soft` and `--s2` build the tonal hierarchy.

```css
.slide { background: var(--bg); color: var(--ink); }
.surface { background: var(--surface); }
.muted { color: var(--soft); }
.safe-emphasis { color: var(--ka); }
.accent-shape { background: var(--accent); color: var(--oa); }
.accent-field { background: var(--g0); color: var(--t0); }
```

## Typography tokens

Use `Archivo` as the display face and `Manrope` as the body face.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600&family=Manrope:wght@300;400;500;600&display=swap" rel="stylesheet">
```

```css
:root {
  --fd: "Archivo";
  --fb: "Manrope";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}

h1, h2, h3, .display, .kpi { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-display); }
.kicker, .label { font-family: var(--fd), var(--cjk-display); font-weight: var(--fw-label); }
body, p, li, table { font-family: var(--fb), var(--cjk-body); font-weight: var(--fw-body); }
```

Available display weights are 400 / 500 / 600, and body weights are 300 / 400 / 500 / 600. Use `--fd` for headings, hero numerals, and section indices; use `--fb` for body copy, labels, chart annotations, and tables. Chinese text uses `--cjk-display` and `--cjk-body` to preserve the display/body hierarchy.

## Deck shell

This is the template's own base stylesheet, used by `layouts/`.
Copy it verbatim into the single `<style>` block, immediately after the inlined
colour-system CSS, before writing any slide. It defines the 16:9 stage, the type
scale, and the chrome and decoration classes the rest of this document refers
to. A deck that invents its own class names instead of using these will not look
like this template.

```css
:root{
  --r-xs: .5cqw;
  --r-sm: .9cqw;
  --r-md: 1.7cqw;
  --r-lg: 3cqw;
  --r-xl: 5cqw;
--fd: "Archivo";
  --fb: "Manrope";
  --fw-display: 600;
  --fw-label: 500;
  --fw-body: 400;
  --cjk-display: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
  --cjk-body: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--ink);color:var(--ink);font-family:var(--fb),var(--cjk-body),sans-serif;}
.deck{scroll-snap-type:y mandatory;height:100vh;overflow-y:scroll;}
.slide{width:100vw;height:100vh;scroll-snap-align:start;display:flex;background:var(--ink);}
.stage{position:relative;width:min(100vw,177.7778vh);height:min(56.25vw,100vh);margin:auto;overflow:hidden;container-type:size;
  background:var(--bg);color:var(--ink);}
.fit{position:absolute;inset:0;transform-origin:top center;z-index:40;}
img{max-width:100%;object-fit:contain!important;}.photo,[data-photocell] img{width:100%;height:100%;display:block;}
  

.display{font-family:var(--fd),var(--cjk-display);font-size:7cqw;font-weight:600;line-height:1.0;letter-spacing:-.02em;}
.h1{font-family:var(--fd),var(--cjk-display);font-size:4.6cqw;font-weight:500;line-height:1.04;letter-spacing:-.01em;}
.h2{font-family:var(--fd),var(--cjk-display);font-size:3.2cqw;font-weight:500;line-height:1.08;letter-spacing:-.01em;}
.h3{font-family:var(--fd),var(--cjk-display);font-size:1.95cqw;font-weight:500;line-height:1.18;}
.stat{font-family:var(--fd),var(--cjk-display);font-size:5.2cqw;font-weight:600;line-height:1;letter-spacing:-.01em;}
.kicker{font-family:var(--fd),var(--cjk-display);font-size:1.15cqw;font-weight:500;letter-spacing:.20em;text-transform:uppercase;}
.lead{font-size:2cqw;font-weight:300;line-height:1.5;}
.body{font-size:1.5cqw;font-weight:400;line-height:1.5;}
.cap{font-size:1.2cqw;font-weight:400;line-height:1.4;letter-spacing:.02em;}
.pagenum{position:absolute;right:3cqw;bottom:3.2cqh;font-family:var(--fd),var(--cjk-display);font-size:1cqw;font-weight:500;letter-spacing:.06em;opacity:.8;z-index:45;}

.tile{width:var(--sz,5cqw);height:var(--sz,5cqw);display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);line-height:1;}
.tile svg{width:55%;height:55%;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.badge{width:2.2em;height:2.2em;display:flex;align-items:center;justify-content:center;border-radius:var(--r-md);font-family:var(--fd),var(--cjk-display);font-weight:600;line-height:1;font-size:2cqw;}
.badge>span{font-size:1em;line-height:1;}
.tick{position:absolute;}
.card{background:var(--surface);border-radius:var(--r-md);}
.dot{border-radius:50%;}.qcircle{border-radius:50% 0 0 0;}.semi{border-radius:999px 999px 0 0;}.tri{width:0;height:0;}
.dim{opacity:.84;}
.soft{color:var(--soft);}
.band{position:absolute;display:flex;flex-direction:column;align-items:center;gap:1.6cqh;}
.band>*{flex:none;}

:root{--r-xs:0!important;--r-sm:0!important;--r-md:0!important;--r-lg:0!important;--r-xl:0!important;}
.display{font-weight:800!important;letter-spacing:-.025em;}
.h1{font-weight:800!important;}
.kicker{font-weight:600;letter-spacing:.18em;}
[data-device]{border-radius:0!important;}
[data-photocell]{border-radius:0!important;}
```
An icon `tile` contains SVG only and may use `--sz` in container units. A
numbered `badge` contains text, so its box is `2.2em` square and the number is a
`<span>` at `1em`; never size a text-bearing badge with `cqw`, `cqh`, `px`,
`vw`, or `vh`.


## Signature elements

Available signature elements: `asterisk-spark`, `tile-ramp`, `corner-chrome`, `mono-photo-grid`, and `giant-caps-display`.


For templates with branded chrome, preserve the sample's size, margins, and repeated positions, then replace the placeholder name with real brand assets.

Visual reference: [example/reference.jpg](example/reference.jpg)

## Identity vocabulary

Every identity element below is copied out of this template's own reference deck. This is
the geometry that makes the template recognisable, and it is the part that goes
missing when a deck is authored from the prose alone — the shapes exist nowhere
else; it is reproduced here so generation never needs a full-deck HTML example.

**Copy these snippets. Do not paraphrase them, redraw them, or substitute a
shape that is easier to write.** Change only size, position, colour token, and
text content. The count beside each motif is how many times the reference deck
uses it across fifteen slides. It records prevalence; it is not a floor, quota,
or target to scale mechanically. Use a motif only where the closest reference
page role uses it and the composition benefits.

For optional decoration construction, use the measured and copyable split sources:
[decoration/PLACEMENT.md](decoration/PLACEMENT.md),
[decoration/decoration.html](decoration/decoration.html). Structural tiles and
numbered stages are already in `layouts/icon-cards.html` and
`layouts/process-steps.html`; they are not decoration. The split sources
supersede any generic placement sentence in this legacy inventory.


### `strata-grid` — 8 optional decoration groups on 8 of 15 slides

The template's namesake is a grouped motif: a
block of equal squares on a constant pitch, each one a step further along a
`color-mix` ramp from `--accent` 16% up to 100%. One block is 12–23 squares.
The whole staircase counts once. Its 120 square bricks are internal grid units,
not 120 separate decorations.

Squares are `3–4cqw`, pitch is square width `+ .6cqw`, and the ramp divides
`16%…100%` evenly over however many squares the block holds:

```html
<div style="position:absolute;left:0cqw;top:7.2cqw;width:3cqw;height:3cqw;background:color-mix(in srgb, var(--accent) 16%, var(--g3));border-radius:.7cqw"></div>
<div style="position:absolute;left:3.6cqw;top:7.2cqw;width:3cqw;height:3cqw;background:color-mix(in srgb, var(--accent) 30%, var(--g3));border-radius:.7cqw"></div>
<div style="position:absolute;left:7.2cqw;top:7.2cqw;width:3cqw;height:3cqw;background:color-mix(in srgb, var(--accent) 44%, var(--g3));border-radius:.7cqw"></div>
<div style="position:absolute;left:10.8cqw;top:7.2cqw;width:3cqw;height:3cqw;background:color-mix(in srgb, var(--accent) 58%, var(--g3));border-radius:.7cqw"></div>
```

### `bigcircle` — fixed header hairline, not optional decoration

```html
<div data-bigcircle="1" style="position:absolute;left:5cqw;right:5cqw;top:9.4cqh;height:.14cqh;background:currentColor;opacity:.16;z-index:1"></div>
```

### `doodle` — legacy marker shared by fixed wordmark and optional asterisk

```html
<div data-doodle="1" style="position:absolute;left:5cqw;top:5cqh;display:flex;align-items:center;gap:.7cqw;z-index:7">
      <svg viewBox="0 0 100 100" style="width:1.7cqw;height:1.7cqw"><g stroke="var(--accent)" stroke-width="14" stroke-linecap="round"><line x1="50" y1="9" x2="50" y2="91"/><line x1="15" y1="29" x2="85" y2="71"/><line x1="15" y1="71" x2="85" y2="29"/></g></svg>
      <span style="font-family:var(--fd);font-weight:700;font-size:1.2cqw;letter-spacing:.02em">Studio</span>
    </div>
```

### `slot` — page-role marker, not decoration

This motif is too long to inline without cutting it mid-tag, so it is not
reproduced here. Find it in [layouts/](layouts/) by
searching for the opening tag below, and copy the whole element from there.

```html
<div class="stage" data-slot="cover" style="background:var(--g3);color:var(--t3)">
```

### `tile` — structural item device, not optional decoration

```html
<div class="tile" data-tile="1" style="--sz:5cqw;flex:none;background:var(--g0);color:var(--t0)"><svg viewBox="0 0 24 24" style="width:54%;height:54%;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round"><circle cx="12" cy="12" r="9"/><path d="M12 3v18M3 12h18"/></svg></div>
```


### CSS signatures

These declarations are part of the template's look. The counts are from the reference deck.

| property | values it actually uses | why it matters |
| --- | --- | --- |
| `border-radius` | `.7cqw` ×120<br>`0!important` ×2<br>`50% 0 0 0` ×1<br>`999px 999px 0 0` ×1 | arches, capsules and part-round corners |
| `transform` | `rotate(0deg)` ×15 | deliberate tilt |


### Authoritative split sources

The asterisk and staircase variants have copyable markup in `decoration/`.
Chrome lives in `layouts/_shell.html`; item devices live in their naked layouts.
Read the example only for fused full-slide rhythm; do not improvise a substitute
or copy its measured content geometry.

## Optional decoration reference profile

At 1600×900 the reference has exactly two optional decoration families: 15 free
asterisks and 8 grouped `strata-grid` staircases. Count each staircase once; its
120 bricks are internal geometry. The wordmark, running head, hairline, and page
number are fixed chrome. Cards, squares, colour fields, rectangular backgrounds,
content containers, image frames, tiles, badges, nodes, connectors, and grid
cells are layout/content and do not enter decoration counts.

These figures describe the reference page-role mix, not a mechanical quota.
Content still comes first: never push text off the stage, cover it, drop a point,
or add a photograph the source material does not support.


## Decoration safe area

Decoration is placed before content, but it never fights the content.

- Every slide has a **text safe area**: the region actually occupied by the
  title, body copy, figures, and labels. No decoration may sit on top of it.
- Decoration belongs in one of three places: outside the safe area entirely
  (edges, corners, the empty half of the stage); behind it at `z-index:0`–`1`
  **and** at a contrast low enough that the text stays fully legible; or
  deliberately overlapping a photograph or colour field where the reference
  shows exactly that.
- The strata staircase stays wholly inside the stage. The reference has zero
  cropped bricks out of 120; place the block inside the 5% safe area as measured
  in `decoration/PLACEMENT.md`.

## Nothing leaves the stage

Two faults show up in generated decks that the reference deck never commits.
Both are cheap to avoid and both are immediately visible.

**Text must not run off the stage.** Keep content in the flex flow inside `.fit`
and let it divide the 5% safe area with `flex:1;min-width:0`. Chrome is the only
absolutely positioned text; anchor its short running head from `right:5cqw` so
it grows inward. Never guess a content label's position from the width of its
Latin placeholder.

**Repeated things line up.** Timeline steps, KPI columns, agenda rows, cards in
a comparison — anything the slide presents as a set — share one baseline, one
width and one gap. Lay them out with a flex row so the alignment is
structural, not three separate absolute positions that happen to be close. A set
whose members sit at three different heights reads as a mistake even when every
individual piece is correct.

Both faults hide from a quick glance at the whole deck and are obvious on the
slide itself. Before delivering, look at every slide that carries a set of
things and check that the set is aligned and that nothing touches an edge it was
not meant to touch.

## Never do this

- **Never use a disc-bulleted list.** Not one of the twenty-three V3 reference
  decks contains a single `<ul>` with default bullets, and a bulleted list is the
  fastest way to make a designed template look like a plain document. Structure a
  list as numbered rows with a hairline rule between them, as key–value rows, as
  a row of cards, or with the template's own motifs — whatever the reference deck
  does for the same job.
- Never invent a colour outside the inlined colour-system tokens; every colour
  goes through `var(--...)`.
- Never leave a slide without the chrome named in `Required chrome`.
- Never let an ornament sit on top of a title or a paragraph.
- Never generate a photograph the supplied material does not call for.

## Required chrome

Chrome is the cheapest part of a template's identity and the most frequently
dropped: across the benchmark's baseline decks, four of six templates carried a
footer on 0-2 slides out of 17. This template's reference deck carries the
following, and the count is measured from that deck, not assumed.


### Repeats on every slide

The reference deck also repeats these edge-pinned elements on nearly every slide. Their opening tags are given as locators — find each one in [layouts/](layouts/) and carry it through your deck the same way.

```html
<div style="position:absolute;right:5cqw;top:5cqh;font-family:var(--fb);font-weight:500;font-size:1.1cqw;letter-spacing:.14em;text-transform:uppercase;color:currentColor;opacity:.62;z-index:7">
```
<sub>on 15 of 15 reference slides</sub>

```html
<div data-doodle="1" style="position:absolute;left:5cqw;top:5cqh;display:flex;align-items:center;gap:.7cqw;z-index:7">
```
<sub>on 15 of 15 reference slides</sub>

**Page number** — on 15 of 15 slides:

```html
<div class="pagenum">page 01</div>
```

Carry page number on **every** slide, including the cover and the closing slide.
