# strata — naked layouts

38 layouts, each as one standalone, navigable HTML page. They contain only
content structure and the four persistent chrome elements; optional decoration
is deliberately absent. Pair a layout with `../decoration/PLACEMENT.md` and the
copyable ornament markup in `../decoration/`.

The count comes from Strata's demonstrated vocabulary plus independently useful
communication jobs, not from another template:

- 12 structures already demonstrated by `../layouts/`;
- 3 additional structures in `../composition-recipes.html`;
- 12 original missing jobs needed by normal decks;
- 10 additional jobs found in the first coverage audit: long-form argument,
  mirrored image evidence, future roadmap, Gantt schedule, layered architecture,
  mind map, decision trade-offs, case study, accountable team, and 2×2
  positioning;
- 1 job found in the geometry audit: a ranked, ordered list, which `bullets` no
  longer carries.

Each addition has a different evidence shape. `timeline` records dated events;
`roadmap` groups future horizons around outcomes; `gantt` exposes workstream
overlap. `image-grid` is a gallery of work, while `team` communicates roles and
decision ownership. `bullets` carries points that do not compete for rank;
`numbered-list` carries points whose order is the argument, and `process-steps`
carries stages that happen in time. `flow-diagram`, `architecture-diagram`, and `mind-map` respectively
show direction, layers, and branches.

## The sizing rule

No element containing text may use `cqw`, `cqh`, `px`, `vw`, or `vh` for
`width`, `max-width`, `min-width`, `height`, `left`, `top`, `right`, `bottom`,
`flex`, or `flex-basis`.

- Set the 5% safe area once: `.fit { padding:13cqh 5cqw 6cqh }`.
- Divide peer columns with `flex:1;min-width:0`.
- Make a single filled box hug content with `.hug`.
- Use `em` for a numbered badge (`.badge` is `2.2em` square).
- Use `%` only when it is data, such as a bar length.
- Use `height:1px` only for a hairline.
- Absolute offsets belong only to chrome or decoration, never content layout.

Everything inside `.fit` is flex. No grid, float, or absolutely positioned
content is used in these files.

## Filled boxes

A row of peer cards divides the safe area and equalises to the tallest card:

```css
.row  { display:flex; flex:none; align-items:stretch }
.peer { flex:1; min-width:0; display:flex; flex-direction:column }
```

A single filled box uses `.hug` so `.fit` does not stretch it across the page.
Reserve a filling `flex:1` for an image frame or chart plot area.

## Layout index

### Opening, navigation, and ending

| file | use |
|---|---|
| `cover` | giant all-caps opening with a compact standfirst |
| `toc` | numbered agenda rows |
| `section-divider` | full-bleed chapter marker |
| `close` | giant closing statement plus contact lines |

### Prose and comparison

| file | use |
|---|---|
| `statement` | one decisive statement with support copy |
| `longform` | sustained executive or editorial argument with hierarchy and a reading rail |
| `big-quote` | sourced quotation with a strong index rail |
| `bullets` | unranked key points on ruled rows, marked with a drawn square; never browser disc bullets |
| `numbered-list` | a ranked sequence where the order is itself the recommendation |
| `two-column` | two parallel prose arguments |
| `three-column` | three quiet, ruled peer columns |
| `comparison` | restrained side-by-side comparison |
| `versus` | louder filled comparison |
| `pros-cons` | explicit upside/trade-off ledger ending in a recommendation |

### Repeated items and structures

| file | use |
|---|---|
| `icon-cards` | four capabilities; every item gets a tile |
| `process-steps` | four ordered stages; every item gets a numbered badge |
| `timeline` | dated chronology of events or milestones |
| `roadmap` | future outcome horizons from now through scale |
| `gantt` | workstream schedule with overlap and handoffs |
| `flow-diagram` | a directional three-node system |
| `architecture-diagram` | layered experience, orchestration, and foundation system |
| `mind-map` | central question with grouped conceptual branches |
| `testimonials` | three attributed quotations |
| `tier-cards` | three commercial or service tiers |
| `table` | identifiers, prose labels, and numeric evidence |
| `case-study` | challenge, intervention, outcome, and measured impact |
| `team` | named roles, domains, and decision ownership |
| `matrix-2x2` | portfolio or positioning choices across two axes |

### Numbers and charts

| file | use |
|---|---|
| `stat-highlight` | one primary number with one secondary measure |
| `kpi-grid` | ruled row of three metrics |
| `kpi-cards` | filled row of three metrics |
| `chart-bar` | categorical comparison |
| `chart-line` | change over time |
| `chart-donut` | part-to-whole share |

### Supported imagery

| file | use |
|---|---|
| `image-right` | argument on the left, one supported image on the right |
| `image-left` | one supported image as evidence on the left, annotated argument on the right |
| `image-hero` | one supported image as the main evidence |
| `image-grid` | four supported images, with optional names/captions |

Do not add an image when the source does not call for a real subject. An empty
image frame is not decoration.

## Quiet / loud pairs

Use the filled sibling when the ruled version feels too thin or the previous
slide already uses rules:

| job | quiet / ruled | loud / filled |
|---|---|---|
| three peer ideas | `three-column` | `icon-cards` |
| a row of numbers | `kpi-grid` | `kpi-cards` |
| two sides | `comparison` | `versus` |

On a full-bleed page, strata may place light cards directly on `--g3`; this is a
measured reference behaviour, not a hole in the page. `--surface` remains
invisible on `--bg` and must not be used there.

## Verification baseline

With `SAFE=0.05`, the reference has 15 slides and reads:

- `decks / navigableSlides / orphanSlides / indirectSlides = 1 / 15 / 0 / 0`;
- `overflow / outsideSafeArea / aboveChromeBand = 0`;
- `lowContrast / boxesUnderfilledV / boxesUnderfilledH = 0`.

Every file in this directory must preserve the same zero readings and must have
one `.deck` whose single `.slide` is a direct child. The selected colour-system
CSS must resolve before a visual review.
