// Inject one extra sentence into the first flexible peer of every `.row`, then
// verify that all flexible siblings still share one rendered height.
(() => {
  const out={rowsTested:0,failures:0,worstSpreadPx:0,samples:[]};
  [...document.querySelectorAll('.row')].forEach((row,ri) => {
    const peers=[...row.children].filter(k => getComputedStyle(k).flexGrow !== '0');
    if (peers.length < 2) return;
    if (peers.filter(k => k.textContent.trim().length >= 2).length < 2) return;
    const extra=document.createElement('p');
    extra.textContent='Stress sentence: this first item now wraps onto an additional line to test equal-height behaviour.';
    extra.style.cssText='font:400 1.2cqw/1.4 var(--fb),sans-serif;margin-top:.6cqh';
    peers[0].appendChild(extra);
    const heights=peers.map(k=>k.getBoundingClientRect().height);
    extra.remove();
    const spread=Math.max(...heights)-Math.min(...heights);
    out.rowsTested++;
    out.worstSpreadPx=Math.max(out.worstSpreadPx,+spread.toFixed(2));
    if (spread > 1) {
      out.failures++;
      if (out.samples.length < 6) out.samples.push(`row ${ri+1}: ${heights.map(x=>x.toFixed(1)).join('/')}`);
    }
  });
  return JSON.stringify(out,null,1);
})()
