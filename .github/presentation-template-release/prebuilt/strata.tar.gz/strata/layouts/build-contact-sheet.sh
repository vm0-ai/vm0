#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-/tmp/strata-layout-contact.html}"
COLOR_FILE="$HERE/../color-systems/mono_ink.css"
LAYOUT_COUNT="$(find "$HERE" -maxdepth 1 -type f -name '*.html' ! -name '_shell.html' | wc -l | tr -d ' ')"

COLOR_FILE="$COLOR_FILE" LAYOUT_COUNT="$LAYOUT_COUNT" perl -0ne '
  if (/(.*?<body>)/s) {
    $h=$1;
    open my $cf,"<",$ENV{COLOR_FILE} or die $!;
    local $/; $css=<$cf>;
    $h=~s{<link rel="stylesheet" href="../color-systems/mono_ink.css">}{};
    $h=~s{</head>}{<style>$css</style><style>
      .deck{height:auto;overflow:visible}
      .layout-label{position:absolute;left:1.2cqw;bottom:1.2cqh;z-index:70;
        background:var(--accent);color:var(--oa);padding:.55cqh .7cqw;
        font:600 .78cqw/1 var(--fd),sans-serif;letter-spacing:.08em;
        text-transform:uppercase}
    </style></head>};
    $h=~s{<title>.*?</title>}{<title>strata — all $ENV{LAYOUT_COUNT} layouts</title>}s;
    print $h,"\n<div class=\"deck\" aria-label=\"Strata layout contact sheet\">\n";
  }
' "$HERE/_shell.html" > "$OUT"

for FILE in "$HERE"/*.html; do
  [ "$(basename "$FILE")" = "_shell.html" ] && continue
  NAME="$(basename "$FILE" .html)"
  LAYOUT_NAME="$NAME" perl -0ne '
    if (m{<div class="deck">(.*)</div>\s*</body>}s) {
      $s=$1;
      $label=$ENV{LAYOUT_NAME};
      $s=~s{(<div class="stage"[^>]*>)}{$1<div class="layout-label">$label</div>}s;
      print $s,"\n";
    }
  ' "$FILE" >> "$OUT"
done

printf '%s\n' '</div>' >> "$OUT"
printf '%s\n' '<script data-deck-navigation>' >> "$OUT"
printf '%s\n' '(() => { const d=document.querySelector(".deck"),s=[...d.children].filter(n=>n.classList.contains("slide"));let i=0;document.addEventListener("keydown",e=>{let n;if(["ArrowRight","ArrowDown"].includes(e.key))n=i+1;else if(["ArrowLeft","ArrowUp"].includes(e.key))n=i-1;else if(e.key==="Home")n=0;else if(e.key==="End")n=s.length-1;else return;e.preventDefault();i=Math.max(0,Math.min(s.length-1,n));s[i].scrollIntoView({block:"start"});});})();' >> "$OUT"
printf '%s\n' '</script></body></html>' >> "$OUT"

printf '%s\n' "$OUT"
