
(function(){try{var t=localStorage.getItem('theme');if(t)document.documentElement.setAttribute('data-theme',t)}catch(e){}})();
(function(){var root=document.documentElement;function apply(){var d=root.getAttribute('data-theme')||'light';
    document.querySelectorAll('[data-theme-toggle]').forEach(function(b){b.setAttribute('aria-checked',String(d==='dark'));
      b.setAttribute('aria-label',d==='dark'?'Switch to light theme':'Switch to dark theme');
      var l=b.querySelector('.theme-toggle__label');if(l)l.textContent=d==='dark'?'Light mode':'Dark mode';});}
    document.querySelectorAll('[data-theme-toggle]').forEach(function(b){b.addEventListener('click',function(){
      var d=(root.getAttribute('data-theme')||'light')==='dark'?'light':'dark';root.setAttribute('data-theme',d);
      try{localStorage.setItem('theme',d)}catch(e){}apply();});});apply();})();
document.querySelectorAll('[data-burger]').forEach(function(b){b.addEventListener('click',function(){
      var n=b.closest('[data-nav]');var o=n.getAttribute('data-open')==='true';n.setAttribute('data-open',String(!o));
      b.setAttribute('aria-expanded',String(!o));});});
    document.querySelectorAll('[data-nav] a').forEach(function(a){a.addEventListener('click',function(){
      var n=a.closest('[data-nav]');if(n){n.setAttribute('data-open','false');var b=n.querySelector('[data-burger]');if(b)b.setAttribute('aria-expanded','false');}});});
document.querySelectorAll('form[data-contact]').forEach(function(f){f.addEventListener('submit',function(e){
      e.preventDefault();if(!f.checkValidity()){f.reportValidity();return;}var ok=f.querySelector('[data-ok]');if(ok)ok.hidden=false;f.reset();});});
(function(){if(!('IntersectionObserver' in window)){document.querySelectorAll('[data-motion="word-reveal"]').forEach(function(h){h.classList.add('is-in')});return;}
    var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('is-in');io.unobserve(e.target);}});},{threshold:.3});
    document.querySelectorAll('[data-motion="word-reveal"]').forEach(function(h){io.observe(h);});})();
(function(){var RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
    document.querySelectorAll('details').forEach(function(d){var sum=d.querySelector('summary'),body=d.querySelector('[data-acc-body],.faq__a');var anim=null;if(!sum||!body)return;
      sum.addEventListener('click',function(e){if(RM)return;e.preventDefault();if(anim){anim.cancel();anim=null;}
        var pb=getComputedStyle(body).paddingBottom||'0px';
        if(!d.open){d.open=true;var h=body.offsetHeight;anim=body.animate([{height:'0px',opacity:0,paddingBottom:'0px'},{height:h+'px',opacity:1,paddingBottom:pb}],{duration:280,easing:'cubic-bezier(.2,.8,.2,1)'});anim.onfinish=function(){if(anim){anim.cancel();anim=null;}body.style.height='';};}
        else{var start=body.offsetHeight;d.setAttribute('data-closing','');anim=body.animate([{height:start+'px',opacity:1,paddingBottom:pb},{height:'0px',opacity:0,paddingBottom:'0px'}],{duration:240,easing:'cubic-bezier(.4,0,.2,1)',fill:'forwards'});anim.onfinish=function(){d.open=false;d.removeAttribute('data-closing');if(anim){anim.cancel();anim=null;}body.style.height='';};}
      });});})();
document.querySelectorAll('[data-rail]').forEach(function(r){var down=false,sx=0,sl=0,moved=0;
    r.addEventListener('pointerdown',function(e){if(e.pointerType==='mouse'&&e.button!==0)return;down=true;moved=0;sx=e.clientX;sl=r.scrollLeft;r.setPointerCapture(e.pointerId);});
    r.addEventListener('pointermove',function(e){if(!down)return;var dx=e.clientX-sx;if(Math.abs(dx)>4){r.classList.add('is-drag');moved+=Math.abs(dx);}r.scrollLeft=sl-dx;});
    function up(e){if(!down)return;down=false;setTimeout(function(){r.classList.remove('is-drag');},0);try{r.releasePointerCapture(e.pointerId);}catch(_){}}
    r.addEventListener('pointerup',up);r.addEventListener('pointercancel',up);r.addEventListener('pointerleave',up);
    r.addEventListener('click',function(e){if(moved>6){e.preventDefault();e.stopPropagation();}},true);});
document.querySelectorAll('[data-rail-nav]').forEach(function(btn){var sec=btn.closest('section');var rail=sec&&sec.querySelector('[data-rail]');if(!rail)return;function step(){var card=rail.querySelector('*');var gap=parseFloat(getComputedStyle(rail).columnGap||getComputedStyle(rail).gap)||24;return(card?card.getBoundingClientRect().width:300)+gap;}btn.addEventListener('click',function(){rail.scrollBy({left:(+btn.getAttribute('data-rail-nav'))*step(),behavior:'smooth'});});});document.querySelectorAll('[data-rail]').forEach(function(rail){var sec=rail.closest('section');if(!sec)return;var navs=[].slice.call(sec.querySelectorAll('[data-rail-nav]'));if(!navs.length)return;function upd(){var max=rail.scrollWidth-rail.clientWidth-1;navs.forEach(function(b){var d=+b.getAttribute('data-rail-nav');b.disabled=(d<0&&rail.scrollLeft<=0)||(d>0&&rail.scrollLeft>=max);});}rail.addEventListener('scroll',upd,{passive:true});window.addEventListener('resize',upd);upd();});

(function(){
  var root=document.documentElement;
  var RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
  var HOVER=matchMedia('(hover:hover)').matches;
  var num=function(v,d){v=parseFloat(v);return isNaN(v)?d:v;};

  // text-split: wrap each word in <span class=mo-line><span class=mo-w --i></span></span>
  document.querySelectorAll('[data-motion="text-split"]').forEach(function(el){
    var words=el.textContent.trim().split(/\s+/); el.textContent='';
    words.forEach(function(w,i){ var line=document.createElement('span'); line.className='mo-line';
      var s=document.createElement('span'); s.className='mo-w'; s.style.setProperty('--i',i); s.textContent=w;
      line.appendChild(s); el.appendChild(line); if(i<words.length-1) el.appendChild(document.createTextNode(' ')); });
  });
  // stagger: index children
  document.querySelectorAll('[data-motion="stagger"]').forEach(function(el){
    [].forEach.call(el.children,function(c,i){c.style.setProperty('--i',i);}); });

  if(RM){ document.querySelectorAll('[data-motion^="reveal"],[data-motion="stagger"],[data-motion="text-split"],[data-motion="count-up"]').forEach(function(e){e.classList.add('mo-in');}); return; }

  // marquee: clone the track once for a seamless -50% loop. Idempotent — skip if already wrapped
  // (a page whose DOM was serialized AFTER this ran, e.g. apply-photos output, won't double-wrap).
  document.querySelectorAll('[data-motion="marquee"]').forEach(function(el){
    if(el.querySelector('.mo-track')) return;
    var t=document.createElement('div'); t.className='mo-track'; while(el.firstChild)t.appendChild(el.firstChild);
    el.appendChild(t);
    // A SHORT list makes the track narrower than the viewport → the -50% loop leaves an empty gap
    // on the right (uneven distribution). Repeat the base items until one track comfortably exceeds
    // a wide viewport, THEN clone it for the seamless loop. So a few logos still fill the row.
    var base=t.innerHTML, guard=0;
    while(t.scrollWidth < 2200 && guard++ < 24){ t.insertAdjacentHTML('beforeend', base); }
    var c=t.cloneNode(true); el.appendChild(c); });

  // count-up tween
  function countUp(el){ var to=num(el.getAttribute('data-to'),num(el.textContent,0)); var suf=el.getAttribute('data-suffix')||'';
    var dur=1400, t0=null; function step(t){ if(!t0)t0=t; var k=Math.min(1,(t-t0)/dur); var e=1-Math.pow(1-k,3);
      el.textContent=Math.round(to*e)+suf; if(k<1)requestAnimationFrame(step); } requestAnimationFrame(step); }

  // IntersectionObserver: reveal family + count-up
  if('IntersectionObserver' in window){
    var io=new IntersectionObserver(function(es){es.forEach(function(e){ if(!e.isIntersecting)return;
      var el=e.target; el.classList.add('mo-in');
      if(el.getAttribute('data-motion')==='count-up') countUp(el);
      io.unobserve(el); });},{threshold:.16,rootMargin:'0px 0px -8% 0px'});
    document.querySelectorAll('[data-motion^="reveal"],[data-motion="stagger"],[data-motion="text-split"],[data-motion="count-up"]').forEach(function(e){io.observe(e);});
  } else { document.querySelectorAll('[data-motion]').forEach(function(e){e.classList.add('mo-in');}); }

  // rAF: parallax + image-parallax + scroll-progress
  var paras=[].slice.call(document.querySelectorAll('[data-motion="parallax"]'));
  var imgs=[].slice.call(document.querySelectorAll('[data-motion="image-parallax"] > *'));
  var bars=[].slice.call(document.querySelectorAll('[data-motion="scroll-progress"]'));
  var ills=[].slice.call(document.querySelectorAll('[data-motion="text-illuminate"]'));   // scroll-linked line brighten
  var ticking=false;
  function frame(){ var vh=innerHeight, mid=vh/2;
    paras.forEach(function(el){ var sp=num(el.getAttribute('data-speed'),.18); var r=el.getBoundingClientRect();
      var off=((r.top+r.height/2)-mid)*-sp; el.style.transform='translate3d(0,'+off.toFixed(1)+'px,0)'; });
    imgs.forEach(function(el){ var p=el.parentElement; var sp=num(p.getAttribute('data-speed'),.06); var sc=num(p.getAttribute('data-pscale'),1.18);
      var r=p.getBoundingClientRect(); var off=((r.top+r.height/2)-mid)*sp;   /* +sp: scroll DOWN → image drifts UP (conventional parallax) */
      var hw=(sc-1)/2*r.height*.92; if(off>hw)off=hw; else if(off<-hw)off=-hw;   /* CLAMP to the scale headroom so the image always covers — never a gap at the frame edge */
      el.style.transform='scale('+sc+') translate3d(0,'+off.toFixed(1)+'px,0)'; });
    if(bars.length){ var h=document.documentElement.scrollHeight-innerHeight; var k=h>0?Math.min(1,scrollY/h):0;
      bars.forEach(function(b){b.style.transform='scaleX('+k.toFixed(4)+')';}); }
    // text-illuminate: light the statement LINE BY LINE as the block scrolls up through the viewport
    ills.forEach(function(el){ var lines=el.querySelectorAll('.mo-ill'); var m=lines.length; if(!m)return;
      var r=el.getBoundingClientRect(); var p=(vh-r.top)/(vh+r.height); if(p<0)p=0; else if(p>1)p=1;
      var lit=p*(m+1);
      for(var i=0;i<m;i++){ var t=lit-i; if(t<0)t=0; else if(t>1)t=1; lines[i].style.opacity=(0.28+0.72*t).toFixed(3); } });
    ticking=false; }
  function onScroll(){ if(!ticking){ticking=true; requestAnimationFrame(frame);} }
  if(paras.length||imgs.length||bars.length||ills.length){ addEventListener('scroll',onScroll,{passive:true}); addEventListener('resize',onScroll); frame(); }

  if(!HOVER) return;
  // custom cursor — the understated dot (grows on interactive, difference blend). The ONE cursor.
  var cur=document.createElement('div'); cur.className='mo-cursor'; cur.style.opacity='0'; document.body.appendChild(cur);
  document.documentElement.classList.add('mo-cursor-on');   // → hide the native pointer (CSS, pointer devices only)
  addEventListener('pointermove',function(e){ cur.style.opacity='1'; cur.style.left=e.clientX+'px'; cur.style.top=e.clientY+'px'; });
  document.querySelectorAll('a,button,[data-magnetic],[data-motion="hover-tilt"],[data-motion="magnetic"]').forEach(function(el){
    el.addEventListener('pointerenter',function(){cur.classList.add('mo-big');});
    el.addEventListener('pointerleave',function(){cur.classList.remove('mo-big');}); });

  // hover-tilt (rotateX/Y toward cursor)
  document.querySelectorAll('[data-motion="hover-tilt"]').forEach(function(el){
    el.addEventListener('pointermove',function(e){ var t=num(getComputedStyle(root).getPropertyValue('--mo-tilt'),6);
      var r=el.getBoundingClientRect(); var px=(e.clientX-r.left)/r.width-.5, py=(e.clientY-r.top)/r.height-.5;
      el.style.transform='perspective(800px) rotateY('+(px*t).toFixed(2)+'deg) rotateX('+(-py*t).toFixed(2)+'deg)'; });
    el.addEventListener('pointerleave',function(){el.style.transform='';}); });

  // magnetic (translate toward cursor)
  document.querySelectorAll('[data-motion="magnetic"]').forEach(function(el){
    el.addEventListener('pointermove',function(e){ var m=num(getComputedStyle(root).getPropertyValue('--mo-mag'),.3);
      var r=el.getBoundingClientRect(); var dx=(e.clientX-(r.left+r.width/2))*m, dy=(e.clientY-(r.top+r.height/2))*m;
      el.style.transform='translate('+dx.toFixed(1)+'px,'+dy.toFixed(1)+'px)'; });
    el.addEventListener('pointerleave',function(){el.style.transform='';}); });

  // spotlight (move the radial light)
  document.querySelectorAll('[data-motion="spotlight"]').forEach(function(el){
    el.addEventListener('pointermove',function(e){ var r=el.getBoundingClientRect();
      el.style.setProperty('--mx',(e.clientX-r.left)+'px'); el.style.setProperty('--my',(e.clientY-r.top)+'px'); }); });
})();

