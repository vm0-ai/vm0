#!/usr/bin/env bash
# verify-published.sh — run the gate against the page that actually shipped.
#
#   bash checks/verify-published.sh https://your-slug.sites.vm0.io
#
# `verify.sh` measures the working copy. That is the right thing to repair against, and it is not
# evidence about the deployment: a run can gate a good local directory and publish a different one.
# Two of the eleven yoga sites did exactly that — one shipped a line-numbered file dump in place of
# `template.css` and served an unstyled page while reporting 28/29, and one published without ever
# reading a score at all and shipped at 21/29. Both were caught by mirroring the live URL and running
# this same gate against it, and neither was visible from inside the run.
#
# Mirrors same-origin assets only. Anything absolute is the browser's problem, not the mirror's.
set -uo pipefail
URL="${1:-}"
[ -n "$URL" ] || { echo "usage: bash checks/verify-published.sh <published-url>"; exit 2; }

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG="$(dirname "$HERE")"
DIR="$(mktemp -d)"
trap 'rm -rf "$DIR"' EXIT

[ -f "$PKG/template.json" ] && cp "$PKG/template.json" "$DIR/"
curl -sf "$URL" -o "$DIR/index.html" || { echo "could not fetch $URL"; exit 1; }

grep -oE '(href|src)="[^"#?:]+\.(css|js|png|jpg|jpeg|webp|svg|woff2?)"' "$DIR/index.html" \
  | sed -E 's/^(href|src)="//; s/"$//' | sort -u > "$DIR/.assets"
while read -r a; do
  [ -z "$a" ] && continue
  mkdir -p "$DIR/$(dirname "$a")"
  curl -sf "${URL%/}/$a" -o "$DIR/$a" || echo "missing on the host: $a"
done < "$DIR/.assets"

# A stylesheet that opens with anything but CSS is the failure mode that reads as a styling bug
# everywhere except where it is.
for css in "$DIR"/*.css; do
  [ -f "$css" ] || continue
  # Skip leading blank lines: a stylesheet may legitimately open with one, and reading byte 0 turned
  # that into a warning on a perfectly good file. Do it in ONE process, not `sed | head | grep`:
  # this script runs under `pipefail`, and on a real 100KB stylesheet `head -c 1` closes the pipe
  # while sed is still writing, so sed dies of SIGPIPE and the pipeline reports failure no matter
  # what grep found — the warning then fires on every run. It cost one run six minutes to find, and
  # it survived calibration because that was done in a bare shell on a two-line file: neither the
  # shell options nor the input size this actually runs against.
  first=$(awk 'NF { print substr($0, 1, 1); exit }' "$css")
  case "$first" in
    [/@.:*a-zA-Z-]) ;;
    *) echo "warning: $(basename "$css") does not start like CSS — check what was published" ;;
  esac
  head -1 "$css" | grep -qE '^[0-9]+:' \
    && echo "warning: $(basename "$css") is line-numbered — a file dump was published in its place"
done

# Run from the package, not the mirror: the gate resolves `puppeteer-core` upward from where it
# lives, and a temp directory has no node_modules above it. Relative assets still resolve, because
# the page is loaded as `file://$DIR/index.html` and they sit beside it.
exec bash "$HERE/verify.sh" "$DIR/index.html" "$DIR/qa"
