#!/usr/bin/env node
/* verify.mjs — run every gate against one page and write the optional review image.
 *
 *   node checks/verify.mjs index.html qa
 *   bash checks/verify.sh index.html qa          # same thing, the form SKILL.md quotes
 *
 * Prints one line per gate. Failures are `QA_FAIL <name> actual=<...> required=<...>`; read those
 * before opening any check implementation — they carry the numbers you need to repair from.
 *
 * A clean blocking result, including the motion contracts, is ready to stage and publish. The gate
 * also leaves `qa/review-atlas.png` behind for an optional visual check. It is overview evidence,
 * not another required gate and not evidence about viewport-relative motion.
 */

import { existsSync, mkdirSync, readFileSync, writeFileSync } from "fs";
import { dirname, join, resolve } from "path";
import { fileURLToPath } from "url";
import { driver } from "../tools/driver.mjs";
import { captureScreenshot } from "../tools/screenshot.mjs";
import { READ, RECHECK, evaluate } from "./gates.mjs";
import { probeMotionStates, summarizeMotionReports } from "./motion.mjs";
import { settle, settleStyles, confirmContrast } from "./settle.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const CHROME =
  process.env.CHROME_PATH ||
  [
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/google-chrome",
  ].find(existsSync);

const pageArg = process.argv[2] || "index.html";
const outDir = resolve(process.argv[3] || "qa");
const page = resolve(pageArg);
if (!existsSync(page)) {
  console.error(`verify: no ${page}`);
  process.exit(2);
}
if (!CHROME) {
  console.error("verify: no Chromium found; set CHROME_PATH");
  process.exit(2);
}
mkdirSync(outDir, { recursive: true });

const metaPath = join(dirname(page), "template.json");
const dna = existsSync(metaPath)
  ? JSON.parse(readFileSync(metaPath, "utf8")).styleDNA || {}
  : {};

const VIEWPORTS = { desktop: [1440, 900], mobile: [390, 844] };

const puppeteer = await driver();
const browser = await puppeteer.launch({
  executablePath: CHROME,
  args: [
    "--no-sandbox",
    "--disable-dev-shm-usage",
    "--font-render-hinting=none",
  ],
});
const readings = {};
const shots = {};
const motionReports = {};
const consoleErrors = [];
try {
  for (const [name, [width, height]] of Object.entries(VIEWPORTS)) {
    const p = await browser.newPage();
    await p.setViewport({ width, height });
    p.on("pageerror", (e) =>
      consoleErrors.push(`${name}: ${String(e).split("\n")[0]}`),
    );
    p.on("requestfailed", (rq) => {
      if (!/^data:/.test(rq.url()))
        consoleErrors.push(`${name}: requestfailed ${rq.url().slice(0, 100)}`);
    });
    await p.goto(`file://${page}`, { waitUntil: "load", timeout: 90000 });
    await settle(p);
    readings[name] = await p.evaluate(READ);
    motionReports[name] = await probeMotionStates(p, {
      viewport: name,
      outDir,
      captureFailures: true,
    });
    // JPEG, not PNG. These are full-page captures of a 16,000px document and nobody reads them at
    // 1:1 — the atlas shows desktop at 960px and mobile at 280px. Measured on frame-stack: 5.3s and
    // 6.1MB as PNG, 1.2s and 1.6MB at quality 80, with no difference anyone can see at review size.
    shots[name] = join(outDir, `${name}.jpg`);
    await p.screenshot({
      path: shots[name],
      fullPage: true,
      type: "jpeg",
      quality: 80,
    });
    if (name === "desktop") {
      await confirmContrast(p, readings[name], RECHECK);
      // The dark theme is a second page, not a variation: its colours are resolved from a separate
      // block and nothing about the light reading predicts them. Both themes get measured, always.
      await p.evaluate(() =>
        document.documentElement.setAttribute("data-theme", "dark"),
      );
      await settleStyles(p);
      await p.evaluate(() => window.scrollTo(0, 0));
      readings.desktopDark = await p.evaluate(READ);
      await confirmContrast(p, readings.desktopDark, RECHECK);
      await p.evaluate(() => window.scrollTo(0, 0));
      await settleStyles(p);
      await p.screenshot({
        path: join(outDir, "desktop-dark.jpg"),
        fullPage: true,
        type: "jpeg",
        quality: 80,
      });
      await p.evaluate(() =>
        document.documentElement.setAttribute("data-theme", "light"),
      );
    }
    await p.close();
  }
} catch (e) {
  await browser.close();
  throw e;
}

const results = evaluate(readings, dna);
const motionPass = Object.values(motionReports).every((report) => report.pass);
results.push({
  name: "scroll_motion_contracts",
  pass: motionPass,
  actual: summarizeMotionReports(Object.values(motionReports)),
  required:
    "every desktop state works and every mobile fallback remains readable",
});
const failed = results.filter((r) => !r.pass && !r.advisory);
const advisory = results.filter((r) => !r.pass && r.advisory);
const blocking = results.filter((r) => !r.advisory);
const blockingPassed = blocking.filter((r) => r.pass).length;

for (const r of results) {
  if (r.pass) console.log(`QA_PASS ${r.name}`);
  else if (r.advisory)
    console.log(`QA_NOTE ${r.name} actual=${r.actual} required=${r.required}`);
  else
    console.log(
      `QA_FAIL ${r.name} actual=${r.actual} required=${r.required}${r.note ? ` note=${r.note}` : ""}`,
    );
}
console.log(
  `${motionPass ? "QA_MOTION_PASS" : "QA_MOTION_FAIL"} motion_states actual=${summarizeMotionReports(Object.values(motionReports))} required=desktop-live-states-and-mobile-static-fallbacks`,
);
if (consoleErrors.length)
  for (const e of [...new Set(consoleErrors)].slice(0, 8))
    console.log(`QA_NOTE runtime ${e}`);

/* ── review atlas: the two viewports side by side, for the human/visual pass ── */
const atlas = `<!doctype html><meta charset="utf-8"><style>
  body{margin:0;background:#15161a;color:#e8e9ee;font:13px/1.5 ui-monospace,monospace;padding:20px}
  h1{font-size:15px;margin:0 0 14px;font-weight:600}
  .row{display:flex;gap:20px;align-items:flex-start}
  figure{margin:0}figcaption{margin:0 0 6px;opacity:.72}
  img{display:block;border:1px solid #33343c;background:#fff}
  .d img{width:960px}.m img{width:280px}
  ul{margin:14px 0 0;padding-left:18px}li.f{color:#ff8f8f}li.n{color:#ffd08a}li.p{color:#8fdca0}
</style>
<h1>${pageArg} — ${failed.length ? "NOT READY" : "READY TO DELIVER"} · ${blockingPassed}/${blocking.length} blocking gates pass · ${advisory.length} advisory note(s)</h1>
<div class="row">
  <figure class="d"><figcaption>1440x900</figcaption><img src="desktop.jpg"></figure>
  <figure class="m"><figcaption>390x844</figcaption><img src="mobile.jpg"></figure>
</div>
<ul>${results.map((r) => `<li class="${r.pass ? "p" : r.advisory ? "n" : "f"}">${r.name} — ${r.pass ? "pass" : `actual ${r.actual} / required ${r.required}`}</li>`).join("")}</ul>`;
writeFileSync(join(outDir, "review-atlas.html"), atlas);
writeFileSync(
  join(outDir, "readings.json"),
  JSON.stringify({ readings, dna, results }, null, 2),
);
writeFileSync(
  join(outDir, "motion-states.json"),
  JSON.stringify({ viewports: motionReports }, null, 2),
);

let reviewImage;
try {
  reviewImage = await captureScreenshot({
    browser,
    input: join(outDir, "review-atlas.html"),
    output: join(outDir, "review-atlas.png"),
  });
} catch (error) {
  console.log(
    `QA_NOTE review_screenshot ${error instanceof Error ? error.message : String(error)}`,
  );
}
await browser.close();

if (!failed.length) {
  console.log(
    `\nQA_READY ${blockingPassed}/${blocking.length} blocking gates pass; stage and publish.${reviewImage ? ` Optional visual review only if needed: ${reviewImage}` : ""}`,
  );
} else {
  console.log(
    `\nQA_NOT_READY ${blockingPassed}/${blocking.length} blocking gates pass; repair ${failed.length} failure(s).`,
  );
}
process.exit(failed.length ? 1 : 0);
