#!/usr/bin/env bash
# verify.sh — the form SKILL.md quotes. Thin wrapper over checks/verify.mjs.
#
#   bash checks/verify.sh index.html qa      # prints to the terminal AND writes qa/gate.log
set -uo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAGE="${1:-index.html}"
OUT="${2:-qa}"

# The SKILL used to quote this with the output redirected — `... > qa/gate.log` — for two reasons:
# piping through `tail` buffers until the process exits, so you sit there guessing whether it is
# alive, and you want the readings in a file afterwards. But the shell opens that redirect before
# this script runs, so `qa/` did not exist yet and five of eleven runs lost a round discovering it.
# Creating the directory here is too late for the same reason. So do the whole job here: make the
# directory, run the gate, stream to the terminal and to the log at once. The caller redirects
# nothing.
mkdir -p "$OUT"
node "$DIR/verify.mjs" "$PAGE" "$OUT" 2>&1 | tee "$OUT/gate.log"
exit "${PIPESTATUS[0]}"
