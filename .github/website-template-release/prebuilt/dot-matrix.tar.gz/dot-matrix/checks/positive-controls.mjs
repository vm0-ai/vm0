#!/usr/bin/env node
/* positive-controls.mjs — calibrate both sides of every threshold.
 *
 *   node checks/positive-controls.mjs
 *
 * A gate that nothing can trip is not a gate; a gate that the reference trips is not usable. So this
 * runs both sides:
 *
 *   reference side — the package's own `index.html` must pass every blocking gate;
 *   control side   — a synthetic page reproducing the defects these gates were written for must
 *                    trip each one, by name.
 *
 * Each control below reproduces something that actually shipped, not an invented failure. If a
 * control stops tripping its gate, the gate has stopped measuring and the fix is the gate, not the
 * control.
 */

import { existsSync, mkdirSync, writeFileSync, readFileSync } from 'fs';
import { dirname, join, resolve } from 'path';
import { fileURLToPath } from 'url';
import puppeteer from 'puppeteer-core';
import { READ, RECHECK, evaluate } from './gates.mjs';
import { probeMotionStates } from './motion.mjs';
import { settle, settleStyles, confirmContrast } from './settle.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const pkg = resolve(here, '..');
const CHROME = process.env.CHROME_PATH
  || ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome'].find(existsSync);
if (!CHROME) { console.error('positive-controls: no Chromium; set CHROME_PATH'); process.exit(2); }

const tmp = join(pkg, 'qa', 'controls');
mkdirSync(tmp, { recursive: true });

/* ── the controls ─────────────────────────────────────────────────────────── */

const shell = (bodyHtml, headExtra = '') => `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>control</title>
<style>
  *{margin:0;box-sizing:border-box}
  body{font:16px/1.5 system-ui,sans-serif;color:#111;background:#fff}
  .container{max-width:1180px;margin-inline:auto;padding-inline:24px}
  .section{padding:64px 0}
  .sec-head{text-align:center;max-width:60ch;margin:0 auto 32px}
  .btn{display:inline-flex;align-items:center;justify-content:center;padding:12px 20px;background:#111;color:#fff;text-decoration:none}
  .h2{font-size:34px}
  h1{font-size:44px}
</style>${headExtra}</head><body><main>${bodyHtml}</main></body></html>`;

const LOREM = 'Operations teams carry procedures that never fit a rules engine, and the cost of that '
  + 'mismatch is paid every single day in rework, handoffs and exceptions that nobody has time to '
  + 'trace back to their cause. That is the gap this page exists to describe in full sentences.';

const controls = [
  {
    // The shipped defect: no reading device in the stylesheet, so two <p> went straight into a
    // .container — zero paragraph gap, 68ch column left-hugging under a centred head.
    name: 'bare-paragraphs',
    trips: ['prose_paragraphs_are_separated', 'prose_columns_follow_their_heading_alignment'],
    html: shell(`<section class="section" data-section="statement"><div class="container">
      <div class="sec-head"><h2 class="h2">A centred heading</h2></div>
      <div style="max-width:40ch"><p>${LOREM}</p><p>${LOREM}</p></div>
      </div></section>`),
  },
  {
    // The shipped defect: `class="btn btn-primary hero__cta"` where .hero__cta is the button ROW,
    // so the pill rendered as a 960px coloured bar.
    name: 'cta-bar',
    trips: ['actions_are_not_full_width_bars'],
    html: shell(`<section class="section" data-section="hero"><div class="container">
      <h1>A promise</h1><a class="btn btn-primary" href="#x" style="display:flex;width:100%">Book a demo</a>
      </div></section>`),
  },
  {
    name: 'no-social-card',
    trips: ['social_preview_declared'],
    html: shell('<section class="section" data-section="hero"><div class="container"><h1>A promise</h1></div></section>'),
  },
  {
    // The shipped defect: a product screenshot shrunk to a third of natural width, its UI type noise.
    name: 'shrunk-screenshot',
    trips: ['text_bearing_images_stay_legible', 'screenshots_are_not_cropped'],
    html: shell(`<section class="section" data-section="feature"><div class="container">
      <div data-image-crop-safety="text-bearing">
        <img src="data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900"><rect width="1600" height="900" fill="#345"/></svg>')}"
             alt="dashboard" style="width:200px;height:120px;object-fit:cover">
      </div></div></section>`),
  },
  {
    name: 'broken-image',
    trips: ['images_load', 'images_have_alt_text'],
    html: shell('<section class="section" data-section="feature"><div class="container">'
      + '<img src="does-not-exist.png" style="width:400px;height:200px"></div></section>'),
  },
  {
    // The shipped defect: a whole section left behind an IntersectionObserver that never fired.
    name: 'section-hidden-by-motion',
    trips: ['no_section_hidden_by_motion'],
    html: shell(`<section class="section" data-section="hero"><div class="container"><h1>A promise</h1></div></section>
      <section class="section" data-section="steps" style="opacity:0"><div class="container">
      <h2 class="h2">Never revealed</h2><p>${LOREM}</p></div></section>`),
  },
  {
    name: 'overflow-and-a11y',
    trips: ['no_horizontal_overflow', 'one_h1', 'headings_are_ordered', 'ids_are_unique', 'anchors_resolve'],
    html: shell(`<section class="section" data-section="hero" id="dup"><div class="container">
      <h1>One</h1><h1>Two</h1><h4>Jumped a level</h4>
      <a href="#nowhere">dead anchor</a>
      <div style="width:2400px;height:20px;background:#eee"></div></div></section>
      <section class="section" data-section="cta" id="dup"><div class="container"><h2 class="h2">Close</h2></div></section>`),
  },
  {
    // A single testimonial is not three independent kinds of proof.
    name: 'proof-stacked-not-layered',
    trips: ['narrative_has_three_proof_kinds'],
    html: shell(`<section class="section" data-section="hero"><div class="container"><h1>A promise</h1></div></section>
      <section class="section" data-section="feature-grid"><div class="container"><h2 class="h2">What it does</h2><p>${LOREM}</p></div></section>
      <section class="section" data-section="steps"><div class="container"><h2 class="h2">How</h2><p>${LOREM}</p></div></section>
      <section class="section" data-section="testimonial"><div class="container"><h2 class="h2">One quote, and nothing else</h2><p>${LOREM}</p></div></section>
      <section class="section" data-section="cta"><div class="container"><h2 class="h2">Close</h2></div></section>`),
  },
  {
    name: 'inverted-order',
    trips: ['narrative_order_is_not_inverted'],
    html: shell(`<section class="section" data-section="hero"><div class="container"><h1>A promise</h1></div></section>
      <section class="section" data-section="pricing"><div class="container"><h2 class="h2">Price first</h2></div></section>
      <section class="section" data-section="steps"><div class="container"><h2 class="h2">Mechanism after</h2></div></section>`),
  },
];

/* Motion controls are deliberately separate from the content controls above. They reproduce the
 * four ways a sticky device can look plausible in a full-page capture while being broken in the
 * viewport: an empty selected layer, two selected layers, a lost pin, and state logic that never
 * follows the trigger. */
const motionShell = (defect = '') => `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>motion control</title><style>
  *{box-sizing:border-box}html{scroll-behavior:auto}body{margin:0;font:16px/1.5 system-ui;background:#fff;color:#111}
  .before,.after{height:55vh;display:grid;place-items:center}.ss{padding:48px 24px}.ss__grid{display:grid;gap:32px}
  .ss__gallery{display:flex;flex-direction:column;gap:48px}.ss__item{min-height:88vh;background:#eef2f5;padding:24px}
  .ss__media{height:70vh;background:#b9cad6}.ss__title{font-size:30px}.ss__panel{padding:24px}
  @media(min-width:880px){
    .ss__grid{grid-template-columns:.9fr 1.1fr;gap:64px;align-items:start}.ss__pin{position:sticky;top:88px;height:560px}
    .ss__panels{position:relative;height:100%}.ss__panel{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:center;opacity:0;pointer-events:none}
    .ss__panel.is-active{opacity:1;pointer-events:auto}
  }
  @media(max-width:879px){
    .ss__grid{display:grid;grid-template-columns:1fr}.ss__pin,.ss__panels,.ss__gallery{display:contents}
    .ss__panel,.ss__item{position:static;opacity:1;transform:none;min-height:0;margin-bottom:24px}
    .ss__panel:nth-child(1){order:1}.ss__item:nth-child(1){order:2}
    .ss__panel:nth-child(2){order:3}.ss__item:nth-child(2){order:4}
    .ss__panel:nth-child(3){order:5}.ss__item:nth-child(3){order:6}
  }
  ${defect === 'unpinned' ? '@media(min-width:880px){.ss__pin{position:static!important}}' : ''}
</style></head><body><div class="before">before</div>
<section class="ss" data-sticky-scroll><div class="ss__grid"><div class="ss__pin"><div class="ss__panels">
  <article class="ss__panel is-active" data-i="0"><h2 class="ss__title">First state</h2><p>State one copy.</p></article>
  <article class="ss__panel" data-i="1"><h2 class="ss__title">Second state</h2><p>State two copy.</p></article>
  <article class="ss__panel" data-i="2"><h2 class="ss__title">Third state</h2><p>State three copy.</p></article>
</div></div><div class="ss__gallery">
  <figure class="ss__item" data-i="0"><div class="ss__media"></div><figcaption>First image</figcaption></figure>
  <figure class="ss__item" data-i="1"><div class="ss__media"></div><figcaption>Second image</figcaption></figure>
  <figure class="ss__item" data-i="2"><div class="ss__media"></div><figcaption>Third image</figcaption></figure>
</div></div></section><div class="after">after</div><script>
  const defect=${JSON.stringify(defect)};
  const section=document.querySelector('[data-sticky-scroll]');
  const panels=[...section.querySelectorAll('.ss__panel')];
  const items=[...section.querySelectorAll('.ss__item')];
  function activate(requested){
    let selected=defect==='state-mismatch'?0:requested;
    panels.forEach((panel,index)=>{
      panel.style.removeProperty('opacity');
      panel.classList.toggle('is-active',defect==='duplicate'||index===selected);
    });
    if(defect==='blank') panels[selected].style.setProperty('opacity','0','important');
  }
  function update(){
    let best=Infinity,index=0;
    items.forEach((item,i)=>{const rect=item.getBoundingClientRect();const distance=Math.abs(rect.top+rect.height/2-innerHeight/2);if(distance<best){best=distance;index=i;}});
    activate(index);
  }
  addEventListener('scroll',()=>requestAnimationFrame(update),{passive:true});addEventListener('resize',update);activate(0);
</script></body></html>`;

const motionControls = [
  { name: 'blank-active-layer', defect: 'blank' },
  { name: 'duplicate-active-layers', defect: 'duplicate' },
  { name: 'unpinned-container', defect: 'unpinned' },
  { name: 'state-does-not-follow-trigger', defect: 'state-mismatch' },
];

/* ── run ──────────────────────────────────────────────────────────────────── */

async function read(browser, file, { withMotion = false } = {}) {
  const out = {};
  const motion = {};
  for (const [name, [w, h]] of Object.entries({ desktop: [1440, 900], mobile: [390, 844] })) {
    const p = await browser.newPage();
    await p.setViewport({ width: w, height: h });
    await p.goto(`file://${file}`, { waitUntil: 'load', timeout: 60000 });
    await settle(p);
    out[name] = await p.evaluate(READ);
    if (withMotion) {
      motion[name] = await probeMotionStates(p, {
        viewport: name,
        captureFailures: false,
      });
    }
    if (name === 'desktop') {
      await confirmContrast(p, out[name], RECHECK);
      await p.evaluate(() => document.documentElement.setAttribute('data-theme', 'dark'));
      await settleStyles(p);
      await p.evaluate(() => window.scrollTo(0, 0));
      out.desktopDark = await p.evaluate(READ);
      await confirmContrast(p, out.desktopDark, RECHECK);
      await p.evaluate(() => document.documentElement.setAttribute('data-theme', 'light'));
    }
    await p.close();
  }
  return withMotion ? { readings: out, motion } : out;
}

async function readMotionControl(browser, file) {
  const p = await browser.newPage();
  await p.setViewport({ width: 1440, height: 900 });
  await p.goto(`file://${file}`, { waitUntil: 'load', timeout: 60000 });
  await settle(p);
  const report = await probeMotionStates(p, {
    viewport: 'desktop',
    captureFailures: false,
  });
  await p.close();
  return report;
}

const dnaPath = join(pkg, 'template.json');
const dna = existsSync(dnaPath) ? (JSON.parse(readFileSync(dnaPath, 'utf8')).styleDNA || {}) : {};

const browser = await puppeteer.launch({ executablePath: CHROME, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
let failures = 0;
try {
  console.log('control side — each defect must trip its gate by name\n');
  for (const c of controls) {
    const file = join(tmp, `${c.name}.html`);
    writeFileSync(file, c.html);
    const results = evaluate(await read(browser, file), {});   // no DNA: identity gates are off here
    const tripped = new Set(results.filter((r) => !r.pass).map((r) => r.name));
    for (const gate of c.trips) {
      const ok = tripped.has(gate);
      if (!ok) failures++;
      console.log(`  ${ok ? 'ok  ' : 'FAIL'} ${c.name} -> ${gate}${ok ? '' : '   (the control passed, so this gate measures nothing)'}`);
    }
  }

  console.log('\nmotion control side — each viewport defect must fail the live-state contract\n');
  for (const c of motionControls) {
    const file = join(tmp, `motion-${c.name}.html`);
    writeFileSync(file, motionShell(c.defect));
    const report = await readMotionControl(browser, file);
    const ok = !report.pass;
    if (!ok) failures++;
    console.log(
      `  ${ok ? 'ok  ' : 'FAIL'} ${c.name} -> scroll_motion_contracts${ok ? '' : '   (the control passed, so this gate measures nothing)'}`,
    );
  }

  const motionReference = join(tmp, 'motion-reference.html');
  writeFileSync(motionReference, motionShell());
  const referenceMotion = await readMotionControl(browser, motionReference);
  if (!referenceMotion.pass) {
    failures++;
    console.log('  FAIL motion reference -> scroll_motion_contracts');
  } else {
    console.log('  ok   motion reference -> scroll_motion_contracts');
  }

  const ref = join(pkg, 'index.html');
  if (existsSync(ref)) {
    console.log('\nreference side — the package example must pass every blocking gate\n');
    const reference = await read(browser, ref, { withMotion: true });
    const results = evaluate(reference.readings, dna);
    const bad = results.filter((r) => !r.pass && !r.advisory);
    for (const r of bad) { failures++; console.log(`  FAIL reference -> ${r.name} actual=${r.actual} required=${r.required}`); }
    if (!bad.length) console.log(`  ok   reference passes ${results.filter((r) => r.pass).length}/${results.length}`);
    const badMotion = Object.values(reference.motion).filter((report) => !report.pass);
    if (badMotion.length) {
      failures++;
      console.log('  FAIL reference -> scroll_motion_contracts');
    } else {
      console.log('  ok   reference -> scroll_motion_contracts');
    }
  }
} finally { await browser.close(); }

console.log(failures ? `\n${failures} calibration failure(s)` : '\nboth sides calibrated');
process.exit(failures ? 1 : 0);
