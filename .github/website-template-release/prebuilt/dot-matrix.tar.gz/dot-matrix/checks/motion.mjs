/* motion.mjs — behavioural evidence for scroll-driven sections.
 *
 * Full-page screenshots are useful page overviews, but they cannot prove viewport-relative
 * behaviour: Chromium may tile a sticky layer, leave its runway blank, or capture only one state.
 * These probes move a normal viewport through every authored state and inspect the live DOM.
 */

import { join } from 'path';

const LAYER_DEVICES = [
  {
    kind: 'sticky-scroll',
    root: '[data-sticky-scroll]',
    triggers: '.ss__item',
    layers: '.ss__panel',
    pin: '.ss__pin',
    mobilePairOrder: true,
  },
  {
    kind: 'pinned-split',
    root: '[data-pinned-split]',
    triggers: '.pin__panel',
    layers: '.pin__frame',
    pin: '.pin__stage',
    mobilePairOrder: true,
  },
  {
    kind: 'fixed-showcase',
    root: '[data-fixed-showcase]',
    triggers: '.fx__spacer',
    layers: '.fx__card',
    pin: '.fx__pin',
    mobilePairOrder: false,
  },
];

const wait = (ms) => new Promise((resolveWait) => setTimeout(resolveWait, ms));

async function twoFrames(page) {
  await page.evaluate(
    () => new Promise((resolveFrame) =>
      requestAnimationFrame(() => requestAnimationFrame(resolveFrame))),
  );
}

async function poll(page, read, input, accepts, timeout = 900) {
  const started = Date.now();
  let value;
  do {
    value = await page.evaluate(read, input);
    if (accepts(value)) return value;
    await wait(30);
  } while (Date.now() - started < timeout);
  return value;
}

async function finishFiniteAnimations(page, selector, sectionIndex, children) {
  await page.evaluate(
    ({ selector: rootSelector, sectionIndex: index, children: childSelector }) => {
      const section = document.querySelectorAll(rootSelector)[index];
      for (const child of section?.querySelectorAll(childSelector) || []) {
        for (const animation of child.getAnimations()) {
          try {
            animation.finish();
          } catch {
            // An ambient infinite animation is not part of the state transition.
          }
        }
      }
    },
    { selector, sectionIndex, children },
  );
  await twoFrames(page);
}

async function captureFailure(page, outDir, viewport, id, state, captureFailures) {
  if (!captureFailures || !outDir) return null;
  const screenshot = `motion-failure-${viewport}-${id}-${state}.jpg`;
  await page.screenshot({ path: join(outDir, screenshot), type: 'jpeg', quality: 80 });
  return screenshot;
}

async function discover(page) {
  return page.evaluate((layerDevices) => {
    const found = [];
    for (const spec of layerDevices) {
      [...document.querySelectorAll(spec.root)].forEach((section, sectionIndex) => {
        found.push({
          ...spec,
          sectionIndex,
          id: `${spec.kind}-${sectionIndex + 1}`,
          triggerCount: section.querySelectorAll(spec.triggers).length,
          layerCount: section.querySelectorAll(spec.layers).length,
        });
      });
    }
    [...document.querySelectorAll('[data-sticky-h]')].forEach((section, sectionIndex) => {
      found.push({
        kind: 'sticky-h',
        root: '[data-sticky-h]',
        sectionIndex,
        id: `sticky-h-${sectionIndex + 1}`,
        cardCount: section.querySelectorAll('.ssh__card').length,
      });
    });
    [...document.querySelectorAll('[data-pin-slide]')].forEach((section, sectionIndex) => {
      found.push({
        kind: 'pin-slide',
        root: '[data-pin-slide]',
        sectionIndex,
        id: `pin-slide-${sectionIndex + 1}`,
        shotCount: section.querySelectorAll('.pins__shot').length,
        leftCount: section.querySelectorAll('.pins__text').length,
        rightCount: section.querySelectorAll('.pins__desc').length,
      });
    });
    [...document.querySelectorAll('[data-section="cover-stack"]')].forEach(
      (section, sectionIndex) => {
        found.push({
          kind: 'cover-stack',
          root: '[data-section="cover-stack"]',
          sectionIndex,
          id: `cover-stack-${sectionIndex + 1}`,
          panelCount: section.querySelectorAll('.cst__panel').length,
        });
      },
    );
    return found;
  }, LAYER_DEVICES);
}

async function probeLayerDesktop(page, device, options) {
  const countMatches =
    device.triggerCount >= 2 && device.triggerCount === device.layerCount;
  const states = [];
  const count = Math.min(device.triggerCount, device.layerCount);

  for (let stateIndex = 0; stateIndex < count; stateIndex++) {
    await page.evaluate(
      ({ root, sectionIndex, triggers, stateIndex: wanted }) => {
        const section = document.querySelectorAll(root)[sectionIndex];
        const trigger = section?.querySelectorAll(triggers)[wanted];
        if (!trigger) return;
        const rect = trigger.getBoundingClientRect();
        document.documentElement.style.setProperty('scroll-behavior', 'auto', 'important');
        document.body.style.setProperty('scroll-behavior', 'auto', 'important');
        scrollTo(0, scrollY + rect.top + rect.height / 2 - innerHeight / 2);
      },
      { ...device, stateIndex },
    );

    const active = await poll(
      page,
      ({ root, sectionIndex, layers }) => {
        const section = document.querySelectorAll(root)[sectionIndex];
        return [...(section?.querySelectorAll(layers) || [])]
          .map((layer, index) => ({ layer, index }))
          .filter(({ layer }) => layer.classList.contains('is-active'))
          .map(({ layer, index }) => layer.getAttribute('data-i') ?? String(index));
      },
      device,
      (value) => value.length === 1 && value[0] === String(stateIndex),
    );
    await finishFiniteAnimations(page, device.root, device.sectionIndex, device.layers);

    const reading = await page.evaluate(
      ({ root, sectionIndex, triggers, layers, pin, stateIndex: wanted }) => {
        const section = document.querySelectorAll(root)[sectionIndex];
        const trigger = section?.querySelectorAll(triggers)[wanted];
        const layerEls = [...(section?.querySelectorAll(layers) || [])];
        const pinEl = section?.querySelector(pin);
        const inViewport = (element, opacityFloor = 0.5) => {
          if (!element) return false;
          const style = getComputedStyle(element);
          const rect = element.getBoundingClientRect();
          return (
            style.display !== 'none' &&
            style.visibility !== 'hidden' &&
            Number.parseFloat(style.opacity || '1') >= opacityFloor &&
            rect.width > 0 &&
            rect.height > 0 &&
            rect.right > 0 &&
            rect.left < innerWidth &&
            rect.bottom > 0 &&
            rect.top < innerHeight
          );
        };
        const indexOf = (element, fallback) =>
          element?.getAttribute('data-i') ?? String(fallback);
        return {
          expected: indexOf(trigger, wanted),
          active: layerEls
            .map((element, index) => ({ element, index }))
            .filter(({ element }) => element.classList.contains('is-active'))
            .map(({ element, index }) => indexOf(element, index)),
          visible: layerEls
            .map((element, index) => ({ element, index }))
            .filter(({ element }) => inViewport(element))
            .map(({ element, index }) => indexOf(element, index)),
          pinPosition: pinEl ? getComputedStyle(pinEl).position : 'missing',
          pinVisible: inViewport(pinEl, 0.01),
        };
      },
      { ...device, stateIndex },
    );
    reading.activeBeforeSettle = active;
    const pass =
      reading.active.length === 1 &&
      reading.active[0] === reading.expected &&
      reading.visible.length === 1 &&
      reading.visible[0] === reading.expected &&
      reading.pinPosition === 'sticky' &&
      reading.pinVisible;
    const state = { stateIndex, ...reading, pass };
    if (!pass) {
      state.screenshot = await captureFailure(
        page,
        options.outDir,
        options.viewport,
        device.id,
        stateIndex + 1,
        options.captureFailures,
      );
    }
    states.push(state);
  }

  return {
    ...device,
    mode: 'scroll-states',
    countMatches,
    states,
    pass: countMatches && states.length > 0 && states.every((state) => state.pass),
  };
}

async function probeLayerMobile(page, device, options) {
  const reading = await page.evaluate((input) => {
    const section = document.querySelectorAll(input.root)[input.sectionIndex];
    const layers = [...(section?.querySelectorAll(input.layers) || [])];
    const triggers = [...(section?.querySelectorAll(input.triggers) || [])];
    const pin = section?.querySelector(input.pin);
    const rendered = (element) => {
      if (!element) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return (
        style.display !== 'none' &&
        style.visibility !== 'hidden' &&
        Number.parseFloat(style.opacity || '1') >= 0.95 &&
        rect.width > 0 &&
        rect.height > 0
      );
    };
    const layerRects = layers.map((element) => element.getBoundingClientRect());
    const triggerRects = triggers.map((element) => element.getBoundingClientRect());
    const pairsOrdered = input.mobilePairOrder
      ? layers.every((_, index) => {
          const layer = layerRects[index];
          const trigger = triggerRects[index];
          const next = layerRects[index + 1];
          return (
            layer &&
            trigger &&
            layer.top <= trigger.top + 2 &&
            layer.bottom <= trigger.top + 8 &&
            (!next || trigger.bottom <= next.top + 8)
          );
        })
      : true;
    return {
      layerCount: layers.length,
      triggerCount: triggers.length,
      visibleLayers: layers.filter(rendered).length,
      visibleTriggers: triggers.filter(rendered).length,
      pinPosition: pin ? getComputedStyle(pin).position : 'missing',
      pairsOrdered,
    };
  }, device);
  const countMatches =
    reading.layerCount >= 2 && reading.layerCount === reading.triggerCount;
  const triggersExpected = device.mobilePairOrder
    ? reading.visibleTriggers === reading.triggerCount
    : true;
  const pass =
    countMatches &&
    reading.visibleLayers === reading.layerCount &&
    triggersExpected &&
    !['sticky', 'fixed'].includes(reading.pinPosition) &&
    reading.pairsOrdered;
  const report = { ...device, mode: 'static-fallback', ...reading, countMatches, pass };
  if (!pass) {
    report.screenshot = await captureFailure(
      page,
      options.outDir,
      options.viewport,
      device.id,
      'fallback',
      options.captureFailures,
    );
  }
  return report;
}

async function probeStickyHorizontal(page, device, options) {
  if (options.viewport === 'mobile') {
    const reading = await page.evaluate((input) => {
      const section = document.querySelectorAll(input.root)[input.sectionIndex];
      const grid = section?.querySelector('.ssh__grid');
      const viewport = section?.querySelector('.ssh__viewport');
      const track = section?.querySelector('.ssh__track');
      const cards = [...(section?.querySelectorAll('.ssh__card') || [])];
      const matrix = track
        ? new DOMMatrixReadOnly(getComputedStyle(track).transform)
        : new DOMMatrixReadOnly();
      const rendered = (element) => {
        if (!element) return false;
        const style = getComputedStyle(element);
        const rect = element.getBoundingClientRect();
        return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
      };
      return {
        cardCount: cards.length,
        visibleCards: cards.filter(rendered).length,
        gridPosition: grid ? getComputedStyle(grid).position : 'missing',
        overflowX: viewport ? getComputedStyle(viewport).overflowX : 'missing',
        scrollWidth: viewport?.scrollWidth || 0,
        clientWidth: viewport?.clientWidth || 0,
        translateX: matrix.m41,
      };
    }, device);
    const pass =
      reading.cardCount >= 2 &&
      reading.visibleCards === reading.cardCount &&
      !['sticky', 'fixed'].includes(reading.gridPosition) &&
      ['auto', 'scroll'].includes(reading.overflowX) &&
      reading.scrollWidth > reading.clientWidth + 8 &&
      Math.abs(reading.translateX) < 1;
    const report = { ...device, mode: 'manual-rail', ...reading, pass };
    if (!pass) {
      report.screenshot = await captureFailure(
        page,
        options.outDir,
        options.viewport,
        device.id,
        'fallback',
        options.captureFailures,
      );
    }
    return report;
  }

  const targets = Array.from({ length: device.cardCount }, (_, index) =>
    index === device.cardCount - 1 ? 0.95 : index / Math.max(1, device.cardCount - 1),
  );
  const states = [];
  for (let stateIndex = 0; stateIndex < targets.length; stateIndex++) {
    const target = targets[stateIndex];
    await page.evaluate(
      ({ root, sectionIndex, target: progress }) => {
        const section = document.querySelectorAll(root)[sectionIndex];
        if (!section) return;
        const top = scrollY + section.getBoundingClientRect().top;
        const total = Math.max(0, section.offsetHeight - innerHeight);
        document.documentElement.style.setProperty('scroll-behavior', 'auto', 'important');
        document.body.style.setProperty('scroll-behavior', 'auto', 'important');
        scrollTo(0, top + total * progress);
      },
      { ...device, target },
    );
    await twoFrames(page);
    const reading = await poll(
      page,
      ({ root, sectionIndex }) => {
        const section = document.querySelectorAll(root)[sectionIndex];
        const grid = section?.querySelector('.ssh__grid');
        const viewport = section?.querySelector('.ssh__viewport');
        const track = section?.querySelector('.ssh__track');
        const current = section?.querySelector('.ssh__cur');
        const total = Math.max(0, (section?.offsetHeight || 0) - innerHeight);
        const progress = total > 0 ? Math.min(1, Math.max(0, -section.getBoundingClientRect().top / total)) : 0;
        const maxX = viewport && track ? Math.max(0, track.scrollWidth - viewport.clientWidth) : 0;
        const matrix = track
          ? new DOMMatrixReadOnly(getComputedStyle(track).transform)
          : new DOMMatrixReadOnly();
        const rect = grid?.getBoundingClientRect();
        return {
          progress,
          maxX,
          translateX: matrix.m41,
          expectedX: -progress * maxX,
          current: Number.parseInt(current?.textContent || '', 10) || null,
          gridPosition: grid ? getComputedStyle(grid).position : 'missing',
          pinVisible: Boolean(
            rect && rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.top < innerHeight,
          ),
        };
      },
      device,
      (value) => Math.abs(value.translateX - value.expectedX) <= Math.max(3, value.maxX * 0.02),
    );
    const expectedCurrent = Math.min(
      device.cardCount,
      Math.round(reading.progress * (device.cardCount - 1)) + 1,
    );
    const pass =
      reading.maxX > 8 &&
      Math.abs(reading.translateX - reading.expectedX) <= Math.max(3, reading.maxX * 0.03) &&
      reading.current === expectedCurrent &&
      reading.gridPosition === 'sticky' &&
      reading.pinVisible &&
      Math.abs(reading.progress - target) <= 0.04;
    const state = { stateIndex, target, expectedCurrent, ...reading, pass };
    if (!pass) {
      state.screenshot = await captureFailure(
        page,
        options.outDir,
        options.viewport,
        device.id,
        stateIndex + 1,
        options.captureFailures,
      );
    }
    states.push(state);
  }
  return {
    ...device,
    mode: 'scroll-progress',
    states,
    pass: device.cardCount >= 2 && states.length > 0 && states.every((state) => state.pass),
  };
}

async function probePinSlide(page, device, options) {
  const countMatches =
    device.shotCount >= 2 &&
    device.shotCount === device.leftCount &&
    device.shotCount === device.rightCount;
  if (options.viewport === 'mobile') {
    const reading = await page.evaluate((input) => {
      const section = document.querySelectorAll(input.root)[input.sectionIndex];
      const stage = section?.querySelector('.pins__stage');
      const shots = [...(section?.querySelectorAll('.pins__shot') || [])];
      const lefts = [...(section?.querySelectorAll('.pins__text') || [])];
      const rights = [...(section?.querySelectorAll('.pins__desc') || [])];
      const rendered = (element) => {
        if (!element) return false;
        const style = getComputedStyle(element);
        const rect = element.getBoundingClientRect();
        return (
          style.display !== 'none' &&
          style.visibility !== 'hidden' &&
          Number.parseFloat(style.opacity || '1') >= 0.95 &&
          rect.width > 0 &&
          rect.height > 0
        );
      };
      const ordered = shots.every((shot, index) => {
        const left = lefts[index]?.getBoundingClientRect();
        const image = shot.getBoundingClientRect();
        const right = rights[index]?.getBoundingClientRect();
        const next = lefts[index + 1]?.getBoundingClientRect();
        return (
          left &&
          right &&
          left.top <= image.top + 2 &&
          left.bottom <= image.top + 8 &&
          image.bottom <= right.top + 8 &&
          (!next || right.bottom <= next.top + 8)
        );
      });
      return {
        stagePosition: stage ? getComputedStyle(stage).position : 'missing',
        visibleShots: shots.filter(rendered).length,
        visibleLefts: lefts.filter(rendered).length,
        visibleRights: rights.filter(rendered).length,
        ordered,
      };
    }, device);
    const pass =
      countMatches &&
      !['sticky', 'fixed'].includes(reading.stagePosition) &&
      reading.visibleShots === device.shotCount &&
      reading.visibleLefts === device.leftCount &&
      reading.visibleRights === device.rightCount &&
      reading.ordered;
    const report = { ...device, mode: 'static-fallback', countMatches, ...reading, pass };
    if (!pass) {
      report.screenshot = await captureFailure(
        page,
        options.outDir,
        options.viewport,
        device.id,
        'fallback',
        options.captureFailures,
      );
    }
    return report;
  }

  const states = [];
  for (let stateIndex = 0; stateIndex < device.shotCount; stateIndex++) {
    const target = stateIndex / device.shotCount;
    await page.evaluate(
      ({ root, sectionIndex, target: progress }) => {
        const section = document.querySelectorAll(root)[sectionIndex];
        const track = section?.querySelector('.pins__track');
        if (!track) return;
        const top = scrollY + track.getBoundingClientRect().top;
        const total = Math.max(0, track.offsetHeight - innerHeight);
        document.documentElement.style.setProperty('scroll-behavior', 'auto', 'important');
        document.body.style.setProperty('scroll-behavior', 'auto', 'important');
        scrollTo(0, top + total * progress);
      },
      { ...device, target },
    );
    await twoFrames(page);
    const reading = await poll(
      page,
      ({ root, sectionIndex, stateIndex: wanted }) => {
        const section = document.querySelectorAll(root)[sectionIndex];
        const track = section?.querySelector('.pins__track');
        const stage = section?.querySelector('.pins__stage');
        const shots = [...(section?.querySelectorAll('.pins__shot') || [])];
        const lefts = [...(section?.querySelectorAll('.pins__text') || [])];
        const rights = [...(section?.querySelectorAll('.pins__desc') || [])];
        const rect = stage?.getBoundingClientRect();
        const opacities = shots.map((shot) => Number.parseFloat(getComputedStyle(shot).opacity || '0'));
        return {
          shotOpacities: opacities,
          visibleShots: opacities
            .map((opacity, index) => ({ opacity, index }))
            .filter(({ opacity }) => opacity >= 0.5)
            .map(({ index }) => index),
          activeLefts: lefts
            .map((element, index) => ({ element, index }))
            .filter(({ element }) => element.classList.contains('is-on'))
            .map(({ index }) => index),
          activeRights: rights
            .map((element, index) => ({ element, index }))
            .filter(({ element }) => element.classList.contains('is-on'))
            .map(({ index }) => index),
          stagePosition: stage ? getComputedStyle(stage).position : 'missing',
          stageVisible: Boolean(
            rect && rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.top < innerHeight,
          ),
          expected: wanted,
          trackTop: track?.getBoundingClientRect().top ?? null,
        };
      },
      { ...device, stateIndex },
      (value) =>
        value.visibleShots.length === 1 &&
        value.visibleShots[0] === stateIndex &&
        value.activeLefts.length === 1 &&
        value.activeLefts[0] === stateIndex &&
        value.activeRights.length === 1 &&
        value.activeRights[0] === stateIndex,
    );
    await finishFiniteAnimations(page, device.root, device.sectionIndex, '.pins__shot,.pins__text,.pins__desc');
    const pass =
      reading.visibleShots.length === 1 &&
      reading.visibleShots[0] === stateIndex &&
      reading.activeLefts.length === 1 &&
      reading.activeLefts[0] === stateIndex &&
      reading.activeRights.length === 1 &&
      reading.activeRights[0] === stateIndex &&
      reading.stagePosition === 'sticky' &&
      reading.stageVisible;
    const state = { stateIndex, target, ...reading, pass };
    if (!pass) {
      state.screenshot = await captureFailure(
        page,
        options.outDir,
        options.viewport,
        device.id,
        stateIndex + 1,
        options.captureFailures,
      );
    }
    states.push(state);
  }
  return {
    ...device,
    mode: 'scroll-progress',
    countMatches,
    states,
    pass: countMatches && states.length > 0 && states.every((state) => state.pass),
  };
}

async function probeCoverStack(page, device, options) {
  if (options.viewport === 'mobile') {
    const reading = await page.evaluate((input) => {
      const section = document.querySelectorAll(input.root)[input.sectionIndex];
      const panels = [...(section?.querySelectorAll('.cst__panel') || [])];
      const positions = panels.map((panel) => getComputedStyle(panel).position);
      const visiblePanels = panels.filter((panel) => {
        const style = getComputedStyle(panel);
        const rect = panel.getBoundingClientRect();
        return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
      }).length;
      const ordered = panels.every((panel, index) => {
        if (!panels[index + 1]) return true;
        return panel.getBoundingClientRect().bottom <= panels[index + 1].getBoundingClientRect().top + 8;
      });
      return { positions, visiblePanels, ordered };
    }, device);
    const pass =
      device.panelCount >= 2 &&
      reading.visiblePanels === device.panelCount &&
      reading.positions.every((position) => !['sticky', 'fixed'].includes(position)) &&
      reading.ordered;
    const report = { ...device, mode: 'static-fallback', ...reading, pass };
    if (!pass) {
      report.screenshot = await captureFailure(
        page,
        options.outDir,
        options.viewport,
        device.id,
        'fallback',
        options.captureFailures,
      );
    }
    return report;
  }

  const states = [];
  for (let stateIndex = 0; stateIndex < device.panelCount; stateIndex++) {
    await page.evaluate(
      ({ root, sectionIndex, stateIndex: wanted }) => {
        const section = document.querySelectorAll(root)[sectionIndex];
        const panel = section?.querySelectorAll('.cst__panel')[wanted];
        if (!panel) return;
        const style = getComputedStyle(panel);
        const stickyTop = Number.parseFloat(style.top || '0') || 0;
        const top = scrollY + panel.getBoundingClientRect().top;
        document.documentElement.style.setProperty('scroll-behavior', 'auto', 'important');
        document.body.style.setProperty('scroll-behavior', 'auto', 'important');
        scrollTo(0, Math.max(0, top - stickyTop));
      },
      { ...device, stateIndex },
    );
    await twoFrames(page);
    const reading = await page.evaluate(
      ({ root, sectionIndex, stateIndex: wanted }) => {
        const section = document.querySelectorAll(root)[sectionIndex];
        const panel = section?.querySelectorAll('.cst__panel')[wanted];
        if (!panel) return { position: 'missing', top: null, expectedTop: null, visible: false };
        const style = getComputedStyle(panel);
        const rect = panel.getBoundingClientRect();
        return {
          position: style.position,
          top: rect.top,
          expectedTop: Number.parseFloat(style.top || '0') || 0,
          visible: rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.top < innerHeight,
        };
      },
      { ...device, stateIndex },
    );
    const pass =
      reading.position === 'sticky' &&
      reading.visible &&
      Math.abs(reading.top - reading.expectedTop) <= 4;
    const state = { stateIndex, ...reading, pass };
    if (!pass) {
      state.screenshot = await captureFailure(
        page,
        options.outDir,
        options.viewport,
        device.id,
        stateIndex + 1,
        options.captureFailures,
      );
    }
    states.push(state);
  }
  return {
    ...device,
    mode: 'sticky-stack',
    states,
    pass: device.panelCount >= 2 && states.length > 0 && states.every((state) => state.pass),
  };
}

export async function probeMotionStates(page, rawOptions = {}) {
  const options = {
    viewport: rawOptions.viewport || 'desktop',
    outDir: rawOptions.outDir || null,
    captureFailures: rawOptions.captureFailures !== false,
  };
  await page.evaluate(() => {
    document.documentElement.style.setProperty('scroll-behavior', 'auto', 'important');
    document.body.style.setProperty('scroll-behavior', 'auto', 'important');
    scrollTo(0, 0);
  });
  await twoFrames(page);

  const devices = await discover(page);
  const reports = [];
  for (const device of devices) {
    if (LAYER_DEVICES.some(({ kind }) => kind === device.kind)) {
      reports.push(
        options.viewport === 'mobile'
          ? await probeLayerMobile(page, device, options)
          : await probeLayerDesktop(page, device, options),
      );
    } else if (device.kind === 'sticky-h') {
      reports.push(await probeStickyHorizontal(page, device, options));
    } else if (device.kind === 'pin-slide') {
      reports.push(await probePinSlide(page, device, options));
    } else if (device.kind === 'cover-stack') {
      reports.push(await probeCoverStack(page, device, options));
    }
  }

  await page.evaluate(() => scrollTo(0, 0));
  await twoFrames(page);
  return {
    viewport: options.viewport,
    deviceCount: reports.length,
    devices: reports,
    pass: reports.every((device) => device.pass),
  };
}

export function summarizeMotionReports(reports) {
  const devices = reports.flatMap((report) => report.devices || []);
  if (!devices.length) return 'none-present';
  const failed = devices.filter((device) => !device.pass);
  if (!failed.length) return `${devices.length}/${devices.length}-devices`;
  return failed
    .map((device) => `${device.id}@${reports.find((report) => report.devices?.includes(device))?.viewport || 'unknown'}`)
    .join(',');
}
