/* settle.mjs — bring a page to the state a reader actually sees, then stop.
 *
 * Shared by `verify.mjs` and `positive-controls.mjs` so the two can never drift: a control calibrated
 * against a different settle than the gate it calibrates is calibrating nothing.
 *
 * The sweep is driven from Node, one `evaluate()` per step. Scrolling inside a single `evaluate()`
 * runs the whole loop in one task, so IntersectionObserver callbacks never get a turn and every
 * reveal stays unfired — which reports ten perfectly good sections as "hidden by motion". Measured
 * on the same page: in-task sweep reveals 0 of 11 sections, stepped sweep reveals 11 of 11.
 */

export async function settle(p) {
  const height = await p.evaluate(() => document.body.scrollHeight);
  for (let y = 0; y < height; y += 300) {
    await p.evaluate((to) => window.scrollTo(0, to), y);
    await new Promise((r) => setTimeout(r, 60));
  }
  await p.evaluate(async () => {
    window.scrollTo(0, 0);
    // Wait for the things that actually change the reading, rather than sleeping a fixed amount:
    // fonts decide type metrics, images decide geometry, animations decide opacity.
    await document.fonts.ready;
    await Promise.all([...document.images].filter((i) => !i.complete).map((i) => new Promise((r) => {
      i.addEventListener('load', r, { once: true });
      i.addEventListener('error', r, { once: true });
      setTimeout(r, 4000);
    })));
    await Promise.race([
      Promise.allSettled(document.getAnimations().map((a) => a.finished)),
      new Promise((r) => setTimeout(r, 3000)),
    ]);
    // Whatever is still running after that wait is an infinite animation — a marquee track, a
    // rotating badge — and it will keep moving between the two contrast passes. The candidate is
    // then found over one ground and re-measured over another: warm-cards' testimonial marquee
    // reported the same #605146 on #E7BBA2 pair as both 4.34:1 and 1.16:1 in one reading. Freeze
    // them, so both passes see the frame the screenshot shows.
    for (const a of document.getAnimations()) { try { a.pause(); } catch { /* already finished */ } }
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  });
}

/** Wait for whatever is currently in flight to finish. Used after a theme switch: the templates put
 * `transition: color .15s` on controls, so two frames after flipping `data-theme` every reading is a
 * point one-third of the way through the transition — the light colour on the dark ground. Every
 * dark-theme "failure" measured that way is an artefact. */
export async function settleStyles(p) {
  await p.evaluate(async () => {
    await Promise.race([
      Promise.allSettled(document.getAnimations().map((a) => a.finished)),
      new Promise((r) => setTimeout(r, 2000)),
    ]);
    await new Promise((r) => setTimeout(r, 250));
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  });
}

/** Phase two of the contrast gate: judge each candidate where the reader meets it. */
export async function confirmContrast(p, reading, RECHECK) {
  const candidates = reading?.contrast?.candidates || [];
  const confirmed = [];
  for (const c of candidates) {
    await p.evaluate((tag) => {
      const el = document.querySelector(`[data-qa-contrast="${tag}"]`);
      if (el) el.scrollIntoView({ block: 'center' });
    }, c.tag);
    await settleStyles(p);
    const m = await p.evaluate(RECHECK, c.tag);
    // The re-measured pair travels with the re-measured ratio. Keeping phase one's `fg`/`ground`
    // next to phase two's `got` hands the repair tool a ratio and a pair that never met, and it
    // solves the wrong colour against the wrong ground.
    if (m && !m.skip && m.got < m.need) confirmed.push({ ...c, ...m });
  }
  if (reading?.contrast) reading.contrast.confirmed = confirmed;
  return confirmed;
}
