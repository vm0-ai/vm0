/* gates.mjs — every gate, as a pure function of one browser reading.
 *
 * One implementation, eleven templates. What differs per template is not the rule but its floor,
 * and every floor comes from `template.json#styleDNA`, which `tools/stamp-identity.mjs` measured off
 * that template's own reference page. Nothing here is hand-tuned per template.
 *
 * Design rules these gates follow, each of which exists because breaking it produced a real defect
 * that shipped:
 *
 *   - Measure the object, not its wrapper. A prose-width gate that reads the container passes at
 *     1180px while the paragraph box is 686px and left-anchored.
 *   - Measure the object, not a declaration about it. "Palette provenance is declared" was satisfied
 *     by any well-written sentence, and an invented mustard became the brand mark.
 *   - Cover the whole object. Hero contrast measured kicker, headline and lead — each of which sets
 *     its own colour — so a ghost button inherited a stale white and shipped at 1.1:1.
 *   - Judge state when you observe it. Read a class after it settles; re-decide "is this meaningful"
 *     at sample time, because a lazy image below the fold is not complete when the scan starts.
 *   - A false failure costs a repair round in every run, so a rule that cannot distinguish a real
 *     defect from a legitimate composition does not ship.
 *   - Calibrate both sides. `checks/positive-controls.mjs` feeds this a page carrying each defect
 *     these gates exist to catch; a threshold nothing can trip is not a threshold, and one
 *     everything trips is not one either.
 *
 * Three gates were removed after the first eleven generated sites were measured, because each cost
 * more repair time than the defects it caught:
 *
 *   - `page_carries_substantive_copy` required the reference page's own word count. One site spent
 *     about fifteen minutes padding 680 words to 1140 with filler written to clear a number.
 *   - `page_has_a_reading_block` required a block of two or more real paragraphs. With the word
 *     floor it drove every page toward a wall of prose, and the prose came back padded.
 *   - `narrative_trust_is_layered` reported `3 proof sections across 1 third(s)` without saying
 *     which sections it counted, so a run had to guess the rule before it could satisfy it.
 *   - `identity_corner_radius` demanded an exact modal radius that a new palette and composition
 *     legitimately shift; its only firing was collateral from a page whose stylesheet had not
 *     loaded at all.
 */

/* Injected into the page. Returns raw readings only — no judgements — so the thresholds all live
 * here in Node where they can be read and calibrated. */
export const READ = () => {
  const px = (v) => parseFloat(v) || 0;
  const vis = (el) => {
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return (
      r.width > 1 &&
      r.height > 1 &&
      s.visibility !== "hidden" &&
      s.display !== "none" &&
      Number(s.opacity) > 0.05
    );
  };
  const fam = (el) =>
    getComputedStyle(el).fontFamily.split(",")[0].replace(/["']/g, "").trim();
  const rect = (el) => {
    const r = el.getBoundingClientRect();
    return {
      w: Math.round(r.width),
      h: Math.round(r.height),
      x: Math.round(r.left + scrollX),
      y: Math.round(r.top + scrollY),
    };
  };

  const main = document.querySelector("main") || document.body;
  const all = [...document.querySelectorAll("*")];

  /* ── copy ─────────────────────────────────────────────────────────────── */
  const words = (main.innerText || "").split(/\s+/).filter(Boolean).length;

  const paras = [...document.querySelectorAll("p")].filter(vis);
  const substantive = paras.filter(
    (p) => p.textContent.trim().split(/\s+/).length >= 20,
  );
  const widestParagraph = substantive.reduce(
    (m, p) => Math.max(m, p.getBoundingClientRect().width),
    0,
  );

  // A reading block is a visible element with >=2 visible paragraph children carrying real sentences.
  const readingBlocks = all
    .filter(vis)
    .filter((el) => {
      const kids = [...el.children].filter(
        (c) =>
          c.tagName === "P" &&
          vis(c) &&
          c.textContent.trim().split(/\s+/).length >= 15,
      );
      return kids.length >= 2;
    })
    .map((el) => {
      const kids = [...el.children].filter((c) => c.tagName === "P" && vis(c));
      const gaps = [];
      for (let i = 1; i < kids.length; i++) {
        const prev = kids[i - 1].getBoundingClientRect();
        const cur = kids[i].getBoundingClientRect();
        gaps.push(Math.round(cur.top - prev.bottom));
      }
      const head = el.previousElementSibling?.classList?.contains("sec-head")
        ? el.previousElementSibling
        : null;
      const headCentred = head
        ? getComputedStyle(head).textAlign === "center"
        : null;
      const parent = el.parentElement?.getBoundingClientRect();
      const own = el.getBoundingClientRect();
      const leftGap = parent ? own.left - parent.left : 0;
      const rightGap = parent ? parent.right - own.right : 0;
      return {
        cls: el.className || el.tagName,
        paras: kids.length,
        minGap: gaps.length ? Math.min(...gaps) : null,
        width: Math.round(own.width),
        headCentred,
        centred: Math.abs(leftGap - rightGap) <= Math.max(4, own.width * 0.04),
      };
    });

  /* ── actions ──────────────────────────────────────────────────────────── */
  const actions = [...document.querySelectorAll("a.btn, button.btn, .btn")]
    .filter(vis)
    .map((el) => {
      const parent = el.parentElement;
      const pw = parent ? parent.getBoundingClientRect().width : 0;
      return {
        label: el.textContent.trim().slice(0, 40),
        href: el.getAttribute("href") || null,
        primary: /btn-primary|btn--primary|is-primary/.test(el.className),
        w: Math.round(el.getBoundingClientRect().width),
        parentW: Math.round(pw),
        display: getComputedStyle(el).display,
        submit:
          el.tagName === "BUTTON" &&
          (el.type === "submit" || !el.type) &&
          !!el.closest("form"),
      };
    });

  /* ── metadata ─────────────────────────────────────────────────────────── */
  const meta = (sel, attr = "content") =>
    document.querySelector(sel)?.getAttribute(attr) || null;
  const ogImage = meta('meta[property="og:image"]');
  const iconHref =
    document.querySelector('link[rel~="icon"]')?.getAttribute("href") || null;

  /* ── images ───────────────────────────────────────────────────────────── */
  const images = [...document.images].map((img) => ({
    src: (img.currentSrc || img.src || "").slice(-90),
    complete: img.complete,
    natural: img.naturalWidth,
    rendered: Math.round(img.getBoundingClientRect().width),
    visible: vis(img),
    fit: getComputedStyle(img).objectFit,
    cropSafety:
      img
        .closest("[data-image-crop-safety]")
        ?.getAttribute("data-image-crop-safety") || null,
    alt: img.getAttribute("alt"),
  }));

  /* ── contrast ─────────────────────────────────────────────────────────────
   * Measure the object: every visible run of text against the ground it actually lands on, with
   * alpha and inherited opacity composited up the ancestor chain. Sampling three fixed pairs is how
   * a ghost button inherits a stale white and ships at 1.1:1 while the palette gate reports green —
   * the button was never one of the three pairs.
   *
   * This is phase one. It only nominates candidates; `RECHECK` judges them after scrolling each into
   * view, because a scroll-linked recolour legitimately sits at 0.32 opacity until it is reached.
   */
  const MEDIA_TAGS = new Set([
    "IMG",
    "VIDEO",
    "CANVAS",
    "SVG",
    "PICTURE",
    "IFRAME",
  ]);
  const parseColour = (v) => {
    if (!v || v === "transparent") return { r: 0, g: 0, b: 0, a: 0 };
    // Chrome serialises some values as `color(srgb 0.98 0.98 0.97 / 0.88)`, where the channels are
    // 0-1, not 0-255. Reading those as bytes turns a near-white nav into a near-black ground and
    // reports the brand wordmark at 1.08:1 — a probe bug that looks exactly like a page defect.
    const srgb =
      /^color\(srgb\s+([\d.eE+-]+)\s+([\d.eE+-]+)\s+([\d.eE+-]+)(?:\s*\/\s*([\d.eE+-]+))?\)/.exec(
        v,
      );
    if (srgb)
      return {
        r: +srgb[1] * 255,
        g: +srgb[2] * 255,
        b: +srgb[3] * 255,
        a: srgb[4] == null ? 1 : +srgb[4],
      };
    const n = (v.match(/[\d.eE+-]+/g) || []).map(Number);
    if (/^rgba?\(/.test(v) && n.length >= 3)
      return { r: n[0], g: n[1], b: n[2], a: n.length > 3 ? n[3] : 1 };
    return null; // unknown notation: counted, never silently passed
  };
  const over = (fg, bg) => ({
    r: fg.r * fg.a + bg.r * (1 - fg.a),
    g: fg.g * fg.a + bg.g * (1 - fg.a),
    b: fg.b * fg.a + bg.b * (1 - fg.a),
    a: 1,
  });
  const lum = ({ r, g, b }) => {
    const c = [r, g, b].map((v) => {
      const s = v / 255;
      return s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
    });
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
  };
  const ratio = (a, b) => {
    const la = lum(a),
      lb = lum(b);
    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
  };

  /** Composite backgrounds upward. Returns null once an image/gradient makes the ground unknowable.
   * Cheap and conservative: it only sees ANCESTORS. A caption laid over a photo with a scrim has
   * transparent ancestors up to the page, so this reports the page colour and calls white text a
   * 1.16:1 failure — which it is not. Phase one may over-nominate; phase two decides. */
  const groundByAncestors = (el) => {
    const stack = [];
    for (let n = el; n; n = n.parentElement) {
      const cs = getComputedStyle(n);
      if (cs.backgroundImage && cs.backgroundImage !== "none") return null;
      if (MEDIA_TAGS.has(n.tagName)) return null;
      const c = parseColour(cs.backgroundColor);
      if (!c) return null;
      if (c.a > 0) {
        stack.push(c);
        if (c.a >= 0.999) break;
      }
    }
    let ground = { r: 255, g: 255, b: 255, a: 1 };
    for (let i = stack.length - 1; i >= 0; i--) ground = over(stack[i], ground);
    return ground;
  };

  /** What is actually painted under this text, siblings and overlays included. Needs the element to
   * be in the viewport, which is why it belongs to phase two. */
  const groundByPaint = (el) => {
    const r = el.getBoundingClientRect();
    const x = Math.min(innerWidth - 2, Math.max(2, r.left + r.width / 2));
    const y = Math.min(innerHeight - 2, Math.max(2, r.top + r.height / 2));
    const stack = document.elementsFromPoint(x, y);
    const from = stack.indexOf(el);
    // If the element is not under the point we sampled, we did not measure the element. Falling back
    // to the whole stack reads whatever happens to sit there instead: frosted-scatter's mosaic
    // captions live in a horizontal drag track that `scrollIntoView` cannot reach, so their centre
    // was 9,500px above the viewport, the point clamped to y=2, and twenty white captions were
    // reported at 1.16:1 against the page header's white background.
    if (from < 0) return null;
    // `elementsFromPoint` is hit-testing, and hit-testing omits anything with `pointer-events:none`.
    // Templates put that on decorative photography — which is exactly the photography that sits
    // under a caption. frosted-scatter's mosaic images are `pointer-events:none` so the drag gesture
    // passes through them; the walk stepped straight over the photo, found the placeholder tint
    // behind it, and reported twenty legible white captions at 1.16:1. Hit-testing cannot answer
    // "what is painted here", so ask geometry directly.
    for (const m of document.querySelectorAll("img,video,canvas,svg,picture")) {
      if (el.contains(m)) continue;
      const mb = m.getBoundingClientRect();
      if (
        mb.width > 1 &&
        mb.height > 1 &&
        x >= mb.left &&
        x <= mb.right &&
        y >= mb.top &&
        y <= mb.bottom
      )
        return null;
    }
    const below = stack.slice(from);
    const layers = [];
    for (const n of below) {
      const cs = getComputedStyle(n);
      if (cs.backgroundImage && cs.backgroundImage !== "none") return null;
      // A bitmap is a paint layer with no `background-image`: an <img> under a caption makes the
      // ground unknowable exactly as a CSS background does. Missing this reported white captions
      // over photos as 1.22:1 and "repaired" legible white text into unreadable grey.
      if (MEDIA_TAGS.has(n.tagName)) return null;
      const c = parseColour(cs.backgroundColor);
      if (!c) return null;
      if (c.a > 0) {
        layers.push(c);
        if (c.a >= 0.999) break;
      }
    }
    let ground = { r: 255, g: 255, b: 255, a: 1 };
    for (let i = layers.length - 1; i >= 0; i--)
      ground = over(layers[i], ground);
    return ground;
  };

  /** Opacity is inherited multiplicatively and is not part of `color`. A 0.32 run really is faint. */
  const alphaOf = (el) => {
    let a = 1;
    for (let n = el; n; n = n.parentElement)
      a *= Number(getComputedStyle(n).opacity) || 1;
    return a;
  };

  const measureText = (el, precise) => {
    const cs = getComputedStyle(el);
    const ground = precise ? groundByPaint(el) : groundByAncestors(el);
    if (!ground) return { skip: "over-media" };
    const fill =
      cs.webkitTextFillColor && cs.webkitTextFillColor !== cs.color
        ? cs.webkitTextFillColor
        : cs.color;
    const raw = parseColour(fill);
    if (!raw) return { skip: "unknown-colour" };
    // Gradient / clipped text paints through a transparent fill; there is no colour to measure.
    if (raw.a === 0) return { skip: "clipped-fill" };
    const fg = over({ ...raw, a: raw.a * alphaOf(el) }, ground);
    const size = px(cs.fontSize);
    const weight = Number(cs.fontWeight) || 400;
    const large = size >= 24 || (size >= 18.66 && weight >= 700);
    const hex = (c) =>
      `#${[c.r, c.g, c.b]
        .map((v) =>
          Math.round(Math.min(255, Math.max(0, v)))
            .toString(16)
            .padStart(2, "0"),
        )
        .join("")}`.toUpperCase();
    return {
      got: +ratio(fg, ground).toFixed(2),
      need: large ? 3 : 4.5,
      size: Math.round(size),
      // The repair tool needs the pair as measured, not as declared: an inherited opacity or a
      // translucent card is part of what the reader sees and part of what has to be solved against.
      fg: hex(fg),
      ground: hex(ground),
      alpha: +alphaOf(el).toFixed(3),
    };
  };

  // This string is not a description, it is the selector the repair tool writes an override against,
  // so it has to select the element that was measured and nothing else. A classless element labelled
  // by its tag alone does not: solving the nav's bare `a` against the accent band emits `:where(a)`,
  // which repaints every link on the page — measured here at 1.07:1 on a ghost button that had been
  // passing. Anchor those to the nearest classed ancestor instead; `.nav__links a` is a real device.
  const classesOf = (el) =>
    typeof el.className === "string" && el.className.trim()
      ? el.className.trim().split(/\s+/)
      : [];
  const label = (el) => {
    const own = classesOf(el);
    const tag = el.tagName.toLowerCase();
    if (own.length) return `${tag}.${own.slice(0, 2).join(".")}`;
    for (
      let a = el.parentElement;
      a && a !== document.body;
      a = a.parentElement
    ) {
      const [first] = classesOf(a);
      if (first) return `.${first} ${tag}`;
    }
    return tag;
  };

  const hasOwnText = (el) =>
    [...el.childNodes].some(
      (n) => n.nodeType === 3 && n.textContent.trim().length >= 2,
    );
  const reallyVisible = (el) =>
    el.checkVisibility
      ? el.checkVisibility({
          opacityProperty: false,
          visibilityProperty: true,
          contentVisibilityAuto: true,
        })
      : vis(el);

  window.__qaMeasureText = measureText;
  const contrast = {
    checked: 0,
    skipped: {},
    candidates: [],
    groundsBySel: {},
  };
  // Tags are how phase two finds a candidate again, and both themes number from zero on the same
  // DOM. Leaving the light pass's tags in place makes `[data-qa-contrast="0"]` resolve to a light
  // element during the dark confirm, so the dark reading gets re-measured in the wrong place and its
  // real failures are dropped — frame-stack's hero coordinates, sticker-pop's badge, warm-cards'
  // testimonial roles, all invisible to the repair tool and all caught by the gate.
  for (const el of document.querySelectorAll("[data-qa-contrast]"))
    el.removeAttribute("data-qa-contrast");
  let tag = 0;
  for (const el of all) {
    if (!hasOwnText(el) || !reallyVisible(el)) continue;
    // `aria-hidden="true"` says this is decoration, not something anyone reads, and WCAG exempts it
    // from contrast for exactly that reason. Measuring it anyway invents failures a template cannot
    // honestly fix: sticker-pop's hero watermark is 12%-opacity type by design and reads 1.22:1, and
    // the duplicated half of dot-matrix's logo marquee — a copy that exists only so the loop is
    // seamless — accounted for eight of its twelve failures.
    if (el.closest('[aria-hidden="true"]')) {
      contrast.skipped.decorative = (contrast.skipped.decorative || 0) + 1;
      continue;
    }
    const r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) continue;
    if (r.right + scrollX < -200) continue; // off-canvas skip links
    const m = measureText(el);
    if (m.skip) {
      contrast.skipped[m.skip] = (contrast.skipped[m.skip] || 0) + 1;
      continue;
    }
    contrast.checked++;
    // Every ground this selector lands on, passing instances included. One override serves them all,
    // so a repair solved against only the failing instance is free to push a passing one under the
    // floor — `.cg__meta` on glass-bloom's dark card, solved to 4.59:1 there and 3.5:1 back on the
    // light card it also styles.
    const key = label(el);
    const grounds = (contrast.groundsBySel[key] ||= []);
    if (!grounds.some((p) => p.ground === m.ground && p.need === m.need)) {
      grounds.push({ ground: m.ground, need: m.need });
    }
    if (m.got < m.need) {
      el.setAttribute("data-qa-contrast", String(tag));
      contrast.candidates.push({
        tag: tag++,
        sel: label(el),
        text: el.textContent.trim().slice(0, 28),
        ...m,
      });
    }
  }

  /* ── type identity ────────────────────────────────────────────────────── */
  const heads = [...document.querySelectorAll("h1,h2")].filter(vis);
  const headFamilies = {};
  for (const h of heads) headFamilies[fam(h)] = (headFamilies[fam(h)] || 0) + 1;
  const bodyPx = px(getComputedStyle(document.body).fontSize);
  const h1 = [...document.querySelectorAll("h1")].filter(vis)[0];
  const h2 = heads.find((h) => h.tagName === "H2");

  const radii = {};
  for (const el of all.filter(vis)) {
    const r = getComputedStyle(el).borderTopLeftRadius;
    if (px(r) > 0) radii[r] = (radii[r] || 0) + 1;
  }

  /* ── structure ────────────────────────────────────────────────────────── */
  const sections = [...document.querySelectorAll("[data-section]")].map(
    (s) => ({
      kind: s.getAttribute("data-section"),
      ...rect(s),
      opacity: Number(getComputedStyle(s).opacity),
      hidden: !vis(s),
    }),
  );

  const headings = [...document.querySelectorAll("h1,h2,h3,h4,h5,h6")]
    .filter(vis)
    .map((h) => Number(h.tagName[1]));

  const ids = [...document.querySelectorAll("[id]")].map((e) => e.id);
  const dupIds = ids.filter((v, i) => ids.indexOf(v) !== i);
  const anchors = [...document.querySelectorAll('a[href^="#"]')]
    .map((a) => a.getAttribute("href"))
    .filter((h) => h && h !== "#");
  const deadAnchors = anchors.filter((h) => {
    try {
      return !document.querySelector(h);
    } catch {
      return true;
    }
  });

  return {
    vw: innerWidth,
    words,
    widestParagraph: Math.round(widestParagraph),
    substantiveParagraphs: substantive.length,
    readingBlocks,
    actions,
    og: {
      title: meta('meta[property="og:title"]'),
      desc: meta('meta[property="og:description"]'),
      image: ogImage,
    },
    icon: iconHref,
    contrast,
    images,
    type: {
      headFamilies,
      bodyPx,
      heroRatio: h1
        ? +(px(getComputedStyle(h1).fontSize) / bodyPx).toFixed(2)
        : null,
      h2Ratio: h2
        ? +(px(getComputedStyle(h2).fontSize) / bodyPx).toFixed(2)
        : null,
    },
    radius: Object.entries(radii).sort((a, b) => b[1] - a[1]),
    sections,
    headings,
    h1Count: [...document.querySelectorAll("h1")].filter(vis).length,
    dupIds: [...new Set(dupIds)],
    deadAnchors: [...new Set(deadAnchors)],
    overflowX: Math.max(0, document.documentElement.scrollWidth - innerWidth),
    paletteSource: document.documentElement.getAttribute("data-palette-source"),
    paletteReason: document.documentElement.getAttribute("data-palette-reason"),
  };
};

/** Phase two of the contrast gate: re-measure one candidate after it has been scrolled into view.
 * Injected separately so the scroll and the settle can be driven from Node, which is the only way a
 * scroll-linked recolour gets to run before it is judged. */
export const RECHECK = (tag) => {
  const el = document.querySelector(`[data-qa-contrast="${tag}"]`);
  if (!el) return null;
  // precise: read the paint stack under the text now that it is on screen.
  return window.__qaMeasureText(el, true);
};

/* Which narrative beat each section kind serves — the same table the layout maps are built from. */
// Exported so `tools/list-gates.mjs` can print it. A run cannot satisfy the narrative gates without
// knowing which section kind counts as which beat, and it is not derivable from the markup. Told to
// read GATES.md instead of this file, one run spent seven minutes — a quarter of its total — deleting
// sections from the reference page one at a time and re-running the gate to work the mapping out by
// bisection: "Variant B (logos + card-grid removed) fails exactly like my page — so the logos device
// is what supplies proof". A threshold without its vocabulary is not a published rule.
export const BEAT = {
  hero: "promise",
  logos: "proof-scale",
  statement: "tension",
  "grid-editorial": "tension",
  "scroll-statement": "tension",
  narrative: "tension",
  feature: "mechanism",
  "feature-grid": "capability",
  "feature-split": "capability",
  "showcase-panels": "capability",
  "fixed-showcase": "capability",
  "pinned-split": "mechanism",
  "sticky-scroll": "mechanism",
  "mosaic-scroll": "capability",
  "arc-showcase": "capability",
  gallery: "capability",
  steps: "mechanism",
  stats: "proof-data",
  "stats-band": "proof-data",
  "stat-cards": "proof-data",
  testimonial: "proof-people",
  "spotlight-show": "proof-people",
  team: "proof-people",
  "card-grid": "proof-cases",
  "cover-stack": "proof-cases",
  "photo-scatter": "proof-cases",
  "index-tiles": "fit",
  index: "fit",
  pricing: "offer",
  faq: "objections",
  contact: "conversion",
  cta: "close",
};
export const PROOF_BEATS = new Set([
  "proof-scale",
  "proof-data",
  "proof-people",
  "proof-cases",
]);

const g = (name, pass, actual, required, note) => ({
  name,
  pass: !!pass,
  actual,
  required,
  note,
});

/**
 * @param {{desktop:object, mobile:object}} r  readings
 * @param {object} dna  template.json#styleDNA
 */
export function evaluate(r, dna = {}) {
  const d = r.desktop,
    m = r.mobile;
  const out = [];

  /* ── copy and reading ─────────────────────────────────────────────────── */
  const blocks = d.readingBlocks.filter((b) => b.paras >= 2);

  // Measure the PARAGRAPH box, not its wrapper. A wrapper can be 1180px while the text is 686px.
  out.push(
    g(
      "substantive_prose_has_reading_width",
      d.widestParagraph >= 480,
      `${d.widestParagraph}px widest paragraph`,
      ">= 480px on desktop",
    ),
  );

  const tight = blocks.filter((b) => b.minGap != null && b.minGap < 8);
  out.push(
    g(
      "prose_paragraphs_are_separated",
      tight.length === 0,
      tight.length
        ? `${tight.length} block(s), smallest gap ${Math.min(...tight.map((t) => t.minGap))}px`
        : "all blocks separated",
      "adjacent paragraphs >= 8px apart",
      tight.map((t) => t.cls).join(", "),
    ),
  );

  const misaligned = blocks.filter((b) => b.headCentred === true && !b.centred);
  out.push(
    g(
      "prose_columns_follow_their_heading_alignment",
      misaligned.length === 0,
      misaligned.length
        ? `${misaligned.length} column(s) left-hugging under a centred head`
        : "aligned",
      "a column under a centred head is centred",
      misaligned.map((b) => b.cls).join(", "),
    ),
  );

  /* ── actions ──────────────────────────────────────────────────────────── */
  // Two calibrated exemptions, both because the rule has legitimate exceptions at those sizes and a
  // rule with legitimate exceptions cannot be a blocking gate:
  //   - containers under 600px — a 258px card CTA fills its card by design;
  //   - a form's submit button — matching the field column is the standard idiom, and it is what
  //     five of the eleven references ship (measured 634-796px, all deliberate).
  // What the rule still catches is the real defect it was written for: a link styled as a pill that
  // inherits a flex row's class and renders as a 960px coloured bar.
  const bars = d.actions.filter(
    (a) => !a.submit && a.parentW >= 600 && a.w > a.parentW * 0.9,
  );
  out.push(
    g(
      "actions_are_not_full_width_bars",
      bars.length === 0,
      bars.length
        ? `${bars.length} full-width action(s): ${bars.map((b) => `"${b.label}" ${b.w}/${b.parentW}px`).join("; ")}`
        : "none",
      "desktop action < 90% of a container >= 600px",
    ),
  );

  const primaries = d.actions.filter((a) => a.primary && a.href);
  const byHref = primaries.reduce(
    (acc, a) => ((acc[a.href] = (acc[a.href] || 0) + 1), acc),
    {},
  );
  const top = Object.entries(byHref).sort((a, b) => b[1] - a[1])[0];
  out.push(
    g(
      "one_primary_action_repeated",
      !!top && top[1] >= 2,
      top
        ? `"${top[0]}" appears ${top[1]}x of ${primaries.length} primary actions`
        : "no primary action found",
      "the primary action appears at least twice (opening and close)",
    ),
  );

  /* ── shareability ─────────────────────────────────────────────────────── */
  const iconOk = !!d.icon;
  const ogImg = d.images.find(
    (i) => d.og.image && i.src.endsWith(d.og.image.split("/").pop()),
  );
  const ogLoads = d.og.image
    ? ogImg
      ? ogImg.natural > 0
      : "not-inlined"
    : false;
  out.push(
    g(
      "social_preview_declared",
      !!(d.og.title && d.og.desc && d.og.image && iconOk),
      `og:title=${!!d.og.title} og:description=${!!d.og.desc} og:image=${d.og.image || "none"} icon=${d.icon || "none"}`,
      "og:title, og:description, a loading og:image, and a favicon",
      ogLoads === "not-inlined"
        ? "og:image is declared but not embedded in the page; verify it 200s on the publish origin"
        : "",
    ),
  );

  /* ── images ───────────────────────────────────────────────────────────── */
  const broken = d.images.filter((i) => i.complete && i.natural === 0);
  out.push(
    g(
      "images_load",
      broken.length === 0,
      broken.length
        ? `${broken.length} broken: ${broken
            .map((b) => b.src)
            .slice(0, 3)
            .join(", ")}`
        : "all load",
      "no broken images",
    ),
  );

  const textBearing = d.images.filter(
    (i) => i.visible && i.cropSafety === "text-bearing" && i.natural > 0,
  );
  const illegible = textBearing.filter((i) => i.rendered / i.natural < 0.5);
  out.push(
    g(
      "text_bearing_images_stay_legible",
      illegible.length === 0,
      illegible.length
        ? illegible
            .map((i) => `${i.src} at ${(i.rendered / i.natural).toFixed(2)}x`)
            .join("; ")
        : `${textBearing.length} checked`,
      "text-bearing media renders at >= 0.5 of natural width",
    ),
  );

  const coveredText = d.images.filter(
    (i) => i.visible && i.cropSafety === "text-bearing" && i.fit === "cover",
  );
  out.push(
    g(
      "screenshots_are_not_cropped",
      coveredText.length === 0,
      coveredText.length
        ? `${coveredText.length} text-bearing image(s) use object-fit:cover`
        : "none",
      "text-bearing media must not use cover",
    ),
  );

  const noAlt = d.images.filter((i) => i.visible && i.alt == null);
  out.push(
    g(
      "images_have_alt_text",
      noAlt.length === 0,
      `${noAlt.length} missing alt`,
      "every visible image has an alt attribute",
    ),
  );

  /* ── contrast ─────────────────────────────────────────────────────────── */
  // Both themes, every run of text, not a sample of three pairs. A colour that clears 4.5 on paper
  // routinely fails on the dark ground, and the theme nobody looked at is the one that ships broken.
  // `confirmed` comes from phase two: each candidate re-measured after being scrolled into view, so
  // a scroll-linked recolour is judged where the reader meets it, not at scroll 0.
  for (const [theme, reading] of [
    ["light", d],
    ["dark", r.desktopDark],
  ]) {
    if (!reading?.contrast) continue;
    const c = reading.contrast;
    const bad = c.confirmed || c.candidates || [];
    out.push(
      g(
        `text_contrast_${theme}`,
        bad.length === 0,
        bad.length
          ? `${bad.length} of ${c.checked} runs below floor — ` +
              bad
                .slice(0, 4)
                .map((w) => `${w.sel} "${w.text}" ${w.got}:1 (needs ${w.need})`)
                .join("; ")
          : `${c.checked} text runs clear`,
        "4.5:1 for body text, 3:1 for large text (>=24px, or >=18.66px bold)",
      ),
    );
  }
  // Text on an image has no measurable ground, so it is reported rather than judged. A clean
  // blocking result is still ready to ship; the single generated atlas is available if someone has
  // a concrete reason to make the scrim/card judgment visually.
  const onMedia = d.contrast?.skipped?.["over-media"] || 0;
  out.push({
    ...g(
      "text_over_media_needs_a_scrim",
      onMedia === 0,
      `${onMedia} run(s) sit on an image or gradient`,
      "optional visual review: qa/review-atlas.png; text on uncontrolled imagery needs a scrim or a solid card",
    ),
    advisory: true,
  });
  // A notation the probe cannot parse must not read as a pass.
  const unknown =
    (d.contrast?.skipped?.["unknown-colour"] || 0) +
    (r.desktopDark?.contrast?.skipped?.["unknown-colour"] || 0);
  out.push(
    g(
      "contrast_is_fully_measured",
      unknown === 0,
      `${unknown} run(s) in a colour notation the probe cannot read`,
      "0 — an unmeasurable colour is not a passing colour",
    ),
  );

  /* ── template identity ────────────────────────────────────────────────── */
  if (dna.displayFace) {
    const total =
      Object.values(d.type.headFamilies).reduce((a, b) => a + b, 0) || 1;
    const share = (d.type.headFamilies[dna.displayFace] || 0) / total;
    const need = parseFloat(dna.displayFaceShare) / 100 || 0.7;
    out.push(
      g(
        "identity_display_face",
        share >= need,
        `${Math.round(share * 100)}% of h1/h2 in ${dna.displayFace}`,
        `>= ${Math.round(need * 100)}%`,
      ),
    );
  }
  // REMOVED: identity_type_scale. It claimed to check that a page uses the template's heading scale
  // and actually checked which section the page happens to open with.
  //
  // It sampled the FIRST h2 in document order (`heads.find(h => h.tagName === 'H2')`) and compared it
  // against a floor measured the same way on the reference page. But the same `.h2` class renders at
  // different sizes depending on the section that contains it — on dot-matrix it is 2.82x inside
  // `steps`, 2.64x inside `gallery`, and 2.12x inside `statement`, `pricing` or `index`. The floor,
  // 2.43x, was derived from the reference page, whose first h2 sits in `steps`. So the reference
  // always passed and any composed page opening with a `statement` did not.
  //
  // Demonstrated: the same six sections with the same content, composed in two orders — `steps`
  // before `statement` passes, `statement` before `steps` fails. Not one character of the page
  // differs. Four of eleven templates carry a spread wide enough to trip it, worst on
  // blueprint-grid, where 11 of the 12 h2s on its own reference page fall below its own 4.45x floor.
  //
  // Both recorded failures across two full rounds were this artefact and neither was a real defect;
  // one run diagnosed it correctly and unaided ("if the gate measures the FIRST h2 element: mine =
  // index h2 (36px, 2.12x); reference = steps h2 (48px, 2.82x)") and paid 3.5 minutes to do so.
  // Ranking every h2 and taking a median would be order-independent, but nobody has shown that the
  // resulting number measures anything a reader would notice, so this stays deleted rather than
  // becoming a differently-shaped guess. `identity_display_face` still checks that headings use the
  // template's display family.
  /* ── narrative ────────────────────────────────────────────────────────── */
  const beats = d.sections
    .map((s) => ({ ...s, beat: BEAT[s.kind] }))
    .filter((s) => s.beat);
  const proof = beats.filter((s) => PROOF_BEATS.has(s.beat));
  const kinds = new Set(proof.map((s) => s.beat));
  out.push(
    g(
      "narrative_has_three_proof_kinds",
      kinds.size >= 3,
      `${kinds.size} kinds: ${[...kinds].join(", ") || "none"}`,
      ">= 3 of proof-scale / proof-data / proof-people / proof-cases",
    ),
  );

  const order = beats.map((b) => b.beat);
  const idx = (b) => order.indexOf(b);
  const inverted = [];
  if (
    idx("offer") >= 0 &&
    idx("mechanism") >= 0 &&
    idx("offer") < idx("mechanism")
  )
    inverted.push("offer before mechanism");
  if (idx("close") >= 0 && idx("promise") >= 0 && idx("close") < idx("promise"))
    inverted.push("close before promise");
  if (
    idx("objections") >= 0 &&
    idx("capability") >= 0 &&
    idx("objections") < idx("capability")
  )
    inverted.push("objections before capability");
  out.push(
    g(
      "narrative_order_is_not_inverted",
      inverted.length === 0,
      inverted.join("; ") || "ordered",
      "promise -> capability -> mechanism -> offer -> objections -> close",
    ),
  );

  /* ── frame and motion ─────────────────────────────────────────────────── */
  const stuck = d.sections.filter((s) => s.hidden && s.h > 40);
  out.push(
    g(
      "no_section_hidden_by_motion",
      stuck.length === 0,
      stuck.length
        ? stuck.map((s) => `${s.kind} (opacity ${s.opacity})`).join(", ")
        : "all sections visible",
      "no whole section left invisible after the page settles",
    ),
  );

  out.push(
    g(
      "no_horizontal_overflow",
      d.overflowX === 0 && m.overflowX === 0,
      `desktop +${d.overflowX}px · mobile +${m.overflowX}px`,
      "0px at 1440 and 390",
    ),
  );

  /* ── accessibility basics ─────────────────────────────────────────────── */
  out.push(
    g("one_h1", d.h1Count === 1, `${d.h1Count} visible h1`, "exactly 1"),
  );
  let jumps = 0;
  for (let i = 1; i < d.headings.length; i++)
    if (d.headings[i] - d.headings[i - 1] > 1) jumps++;
  out.push(
    g(
      "headings_are_ordered",
      jumps === 0,
      `${jumps} level jump(s)`,
      "no heading level skipped",
    ),
  );
  out.push(
    g(
      "ids_are_unique",
      d.dupIds.length === 0,
      d.dupIds.join(", ") || "unique",
      "no duplicate id",
    ),
  );
  out.push(
    g(
      "anchors_resolve",
      d.deadAnchors.length === 0,
      d.deadAnchors.join(", ") || "all resolve",
      "every #anchor has a target",
    ),
  );

  /* ── palette provenance ───────────────────────────────────────────────── */
  // Declared-only gates get satisfied by any well-written sentence, so this one stays ADVISORY:
  // it reports, it does not block. The structural default (roles resolve from the palette surface)
  // is what actually prevents an unsourced colour becoming the brand mark.
  out.push({
    ...g(
      "palette_provenance_declared",
      !!(d.paletteSource && d.paletteReason),
      `source=${d.paletteSource || "none"} reason=${d.paletteReason ? "present" : "none"}`,
      "data-palette-source and data-palette-reason on <html>",
    ),
    advisory: true,
  });

  return out;
}
