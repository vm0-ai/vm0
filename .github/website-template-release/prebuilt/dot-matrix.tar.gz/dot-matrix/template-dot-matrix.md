# dot-matrix — template spec

Learned from **kerna.studio** (onchain brand studio). This is a **different kind of template**: it consumes only the
pure CONTENT CONTRACTS (`System Code/sections.mjs`) and owns 100% of every section's structure + style
via `System Code/compose.mjs`.

## Essence
LED **dot-matrix** numerals + hero accent, an organic heavy **wordmark that bleeds** off the edges,
**full-bleed benefit rows** and a big **numbered service card** (number+text horizontal, image right),
a **work rail** that bleeds to the screen edges (draggable **and** with prev/next **arrow buttons** in
the head — `data-rail-nav="-1|1"`, wired by the shared `rail` behavior; the old "drag →" hint is gone),
**blur-in word-reveal** statements, real
photos in every image slot, and a big **contact-in-footer** close. Palette = catalogue `midnight`
(dark-first vivid indigo). Default theme dark.

## Files in this folder
- `template-dot-matrix.mjs` — the template (own `render[section]` for all 16 content roles + its CSS).
- `template-dot-matrix.md` — this spec.
- `build-page-dot-matrix.mjs` — builds the real single-page site → `page-dot-matrix.html`.
- `build-contractsheet-dot-matrix.mjs` — builds the all-16-sections proof → `contractsheet-dot-matrix.html`.
- `page-dot-matrix.html` — the built real page **with real images baked in** (the deliverable).
- `contractsheet-dot-matrix.html` — the built catalog proof **with real images**.

## Build (pull this folder + System Code into one flat dir)
```
node build-page-dot-matrix.mjs         # → page-dot-matrix.html
node build-contractsheet-dot-matrix.mjs # → contractsheet-dot-matrix.html
node apply-photos.mjs <file> --out <file> --topic "brand design studio"   # fill real photos
node qa-site.mjs <file> --site          # 4 bp × 2 themes + signature/motion/layout-variety + GRID/MARQUEE/AVATAR/FAQ
```

## Uses shared engine (System Code) — never re-hand-written
`sections.mjs` (16 content contracts + validate), `compose.mjs`, `kit.mjs` (themeToggle · dmBoard ·
dmNumeral · `avatar()` · `marquee()`+MARQUEE_CSS seamless · `RAIL_CSS` full-bleed rail · `BEHAVIORS`
theme/nav/form/word-reveal/faq/rail), `qa-site.mjs`.

## Gate status — PASS `--site` (both pages, all breakpoints/themes + the codified quality rules).

## Live
- Contract sheet: https://dot-matrix-contractsheet-715f6d07-2de0b040.sites.vm0.io
