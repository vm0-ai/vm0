/* compose.mjs — contract-driven page renderer. It knows the CONTENT CONTRACTS (sections.mjs) and
 * assembles the page shell; it does NOT know any section's structure. For each planned section it calls
 * the TEMPLATE's own render(content, ctx) -> HTML, validates that output against the contract
 * (structure-agnostic), and places nav in <header>, footer in <footer>, everything else in <main>.
 *
 * A TEMPLATE = {
 *   id, brand, theme:'light'|'dark', fontLink, signature, motionPersonality?,
 *   css,                         // the WHOLE look: token overrides + ALL section structure & style
 *   behaviors:['theme','nav',…], // which kit BEHAVIORS to bundle
 *   render:{ [sectionId]: (content, ctx) => html }   // template OWNS structure per section
 * }
 * A PLAN = { title, desc, sections:[ {id, content, ground?, anchor?} ] }
 */
import { readFileSync } from 'fs';
import { validateSection } from './validate-section.mjs';
import { BEHAVIORS } from './kit.mjs';
import { MOTION_JS } from './motion.mjs';

export function composePage(template, plan){
  const problems = [];
  const seen = {};
  const htmlFor = (s) => {
    const render = template.render[s.id];
    if(!render){ problems.push(`template "${template.id}" has no render for section "${s.id}"`); return ''; }
    seen[s.id] = (seen[s.id]||0)+1;
    let html = render(s.content||{}, { ground:s.ground, brand:template.brand, plan });
    // nav/footer landmarks are provided by the shell wrappers (<header>/<footer>); validate against them
    const forCheck = s.id==='footer' ? '<footer>'+html : s.id==='nav' ? '<header>'+html : html;
    problems.push(...validateSection(s.id, s.content||{}, forCheck));
    // in-page anchor target for a nav/footer link — plan shape: { id, content, ground?, anchor? }
    return s.anchor ? `<a id="${s.anchor}"></a>` + html : html;
  };
  const navSpec  = plan.sections.find(s=>s.id==='nav');
  const footSpec = plan.sections.find(s=>s.id==='footer');
  const bodySpecs= plan.sections.filter(s=>s.id!=='nav'&&s.id!=='footer');

  const NAV  = navSpec  ? htmlFor(navSpec)  : '';
  const MAIN = bodySpecs.map(htmlFor).join('\n');
  const FOOT = footSpec ? htmlFor(footSpec) : '';

  // page-level invariant checks the contract layer can't see (cross-section)
  const h1s = (MAIN.match(/<h1[\s>]/gi)||[]).length + (NAV.match(/<h1[\s>]/gi)||[]).length;
  if(h1s !== 1) problems.push(`page: exactly one <h1> required, found ${h1s}`);

  const foundation = readFileSync('foundation.css','utf8');
  const motion = readFileSync('motion.css','utf8');
  const behaviorJS = (template.behaviors||[]).map(b=>BEHAVIORS[b]||'').join('\n');
  const usesMotion = /data-motion=/.test(MAIN+NAV);

  const html = `<!doctype html>
<html lang="en" data-theme="${template.theme||'light'}"${template.motionPersonality?` data-motion-personality="${template.motionPersonality}"`:''} data-signature="${template.signature||''}">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${plan.title||template.brand}</title><meta name="description" content="${plan.desc||''}">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
${template.fontLink||''}
<style>
/* foundation = tokens + reset + a11y ONLY (no section skeletons) */
${foundation}
${usesMotion?motion:''}
/* ===== template-owned look (structure + style) ===== */
${template.css}
</style></head>
<body>
<a class="skip" href="#main">Skip to content</a>
<header id="top">${NAV}</header>
<main id="main">${MAIN}</main>
<footer data-section="footer">${FOOT}</footer>
<script>
(function(){try{var t=localStorage.getItem('theme');if(t)document.documentElement.setAttribute('data-theme',t)}catch(e){}})();
${behaviorJS}
${usesMotion?MOTION_JS:''}
</script></body></html>`;

  return { html, problems };
}
