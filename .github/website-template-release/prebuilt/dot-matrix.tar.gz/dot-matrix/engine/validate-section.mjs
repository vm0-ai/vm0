/* validate-section.mjs — the CONTENT CONTRACTS + their validator.
 *
 * ⚠ RECONSTRUCTED FOR THE ARCHIVE BUILD. `compose.mjs` and `build-*-dot-matrix.mjs` both import
 * `validateSection` / `CONTRACTS` from `./sections.mjs`, but no file in `source-do-not-change/`
 * defines either symbol — the render path was un-runnable as shipped (`node build-page-dot-matrix.mjs`
 * dies on the import). This module restores exactly that missing piece so the dot-matrix bundle renders.
 * It was calibrated against the real `page-dot-matrix.html` to report ZERO problems, per the source
 * doctrine "calibrate every assertion to 0 false positives" (System MD/qa-site.md).
 *
 * The idea: a CONTRACT fixes a section's CONTENT (which fields it needs) and its SEMANTICS (an
 * ordered list of steps must be an <ol>) — never its STRUCTURE or style, which the template owns.
 * So every assertion here is either "content field present" or "semantic HTML element used".
 * A structural assertion (class names, grids) would be a bug: it would defeat the point.
 *
 *   validateSection(id, content, html) -> string[]   // [] means the render honours its contract
 *   CONTRACTS                                         // the 16 content roles, for the contract sheet
 */

const isArr = (v) => Array.isArray(v) && v.length > 0;
const isStr = (v) => typeof v === 'string' && v.trim() !== '';

/* Each contract: what the CONTENT must carry, and what the rendered HTML must be semantically.
 * `requires`  — content fields that must be present and non-empty.
 * `items`     — the array field + the per-item fields each entry must carry.
 * `semantics` — [regex, why] pairs the rendered HTML must satisfy. Semantic tags only. */
export const CONTRACTS = {
  nav: {
    requires: { brand: isStr },
    semantics: [[/<nav[\s>]/i, 'nav must render a <nav> landmark']],
  },
  hero: {
    requires: { title: isStr },
    semantics: [[/<h1[\s>]/i, 'hero must render the page <h1>']],
  },
  statement: {
    items: { field: 'segments', of: {} },
  },
  logos: {
    items: { field: 'items', of: {} },
  },
  steps: {
    items: { field: 'items', of: { title: isStr } },
    // the one invariant the source's own negative test asserts: steps are ORDERED, so <ol> is required
    // regardless of markup ("NEGATIVE TEST (steps not an <ol>)" in build-page-dot-matrix.mjs).
    semantics: [[/<ol[\s>]/i, 'steps are ordered — the render must use a semantic <ol>']],
  },
  narrative: {
    items: { field: 'items', of: { title: isStr } },
    semantics: [[/<ol[\s>]/i, 'narrative is an ordered sequence — the render must use a semantic <ol>']],
  },
  feature: {
    items: { field: 'items', of: { title: isStr } },
  },
  stats: {
    items: { field: 'items', of: { value: isStr, label: isStr } },
  },
  testimonial: {
    items: { field: 'quotes', of: { text: isStr, name: isStr } },
    semantics: [
      [/<blockquote[\s>]/i, 'a testimonial quote must render as a semantic <blockquote>'],
      [/<img[\s>]/i, 'every testimonial needs a face (qa-site TESTIMONIAL-AVATAR)'],
    ],
  },
  pricing: {
    items: { field: 'plans', of: { tier: isStr, price: isStr } },
  },
  faq: {
    items: { field: 'items', of: { q: isStr, a: isStr } },
  },
  gallery: {
    items: { field: 'items', of: { title: isStr } },
  },
  index: {
    items: { field: 'items', of: { title: isStr } },
  },
  contact: {
    semantics: [[/<form[\s>]/i, 'contact must render a real <form>']],
  },
  cta: {
    requires: { title: isStr },
  },
  footer: {
    requires: { brand: isStr },
  },
};

/* Validate one rendered section against its content contract.
 * Returns [] when the render honours the contract; otherwise one string per problem. */
export function validateSection(id, content = {}, html = '') {
  const c = CONTRACTS[id];
  if (!c) return [`unknown section role "${id}" — not one of: ${Object.keys(CONTRACTS).join(', ')}`];
  const problems = [];

  for (const [field, ok] of Object.entries(c.requires || {}))
    if (!ok(content[field])) problems.push(`${id}: missing required field "${field}"`);

  if (c.items) {
    const arr = content[c.items.field];
    if (!isArr(arr)) {
      problems.push(`${id}: missing required field "${c.items.field}" (a non-empty array)`);
    } else {
      arr.forEach((it, i) => {
        for (const [field, ok] of Object.entries(c.items.of))
          if (!ok(it?.[field])) problems.push(`${id}: ${c.items.field}[${i}] missing required field "${field}"`);
      });
    }
  }

  // Semantic checks only run once the content is valid — an empty render is already reported above,
  // and cascading both would double-report the same root cause.
  if (!problems.length)
    for (const [re, why] of c.semantics || []) if (!re.test(html)) problems.push(`${id}: ${why}`);

  return problems;
}
