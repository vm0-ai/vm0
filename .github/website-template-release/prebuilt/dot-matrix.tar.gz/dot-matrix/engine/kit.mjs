/* kit.mjs — the OPTIONAL toolbox for templates. Behaviors + reusable generators a template may pull
 * from by choice (never imposed). None of this defines a section's structure — templates own that. */
import { icon } from './icons.mjs';

/* theme toggle control (markup) — a template drops it wherever it wants; wired by THEME_JS. */
const _SUN='<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
const _MOON='<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';
export function themeToggle(where='nav'){
  return `<button class="theme-toggle theme-toggle--${where}" type="button" role="switch" aria-checked="false" aria-label="Switch to dark theme" data-theme-toggle>
    <span class="theme-toggle__icon theme-toggle__sun" aria-hidden="true">${_SUN}</span>
    <span class="theme-toggle__icon theme-toggle__moon" aria-hidden="true">${_MOON}</span>
    <span class="theme-toggle__label"></span></button>`;
}
export function burger(){ return icon('<path d="M3 6h18M3 12h18M3 18h18"/>'); }

/* dot-matrix ENGINE — a grid of rounded "pixels" lit per a deterministic figure. A template uses it
 * as media anywhere; each call with a different `fig` renders a DIFFERENT image. */
function litFig(fig, r, c, R, C){
  const cx=(C-1)/2, cy=(R-1)/2;
  switch(fig){
    case 'bars':{ const h=Math.max(1,Math.round((c+1)/C*R)); return r>=R-h ? (c%3===0?2:1) : 0; }
    case 'rise':{ const line=Math.round(R-1-(c/(C-1))*(R-1)); return Math.abs(r-line)<=1 ? (c%3===0?2:1) : 0; }
    case 'arrow':{ const half=Math.floor(R/2); if(r<=half) return Math.abs(c-cx)<=r ? (r===half?2:1) : 0; return Math.abs(c-cx)<=1?1:0; }
    case 'block':{ return (c>=1&&c<C-1&&r>=1&&r<R-1) ? ((r+c)%5===0?2:1) : 0; }
    case 'wave':{ const y=Math.round(cy+Math.sin((c/C)*Math.PI*2)*(R/2-1)); if(r===y) return c%4===0?2:1; return Math.abs(r-y)===1?1:0; }
    case 'ring':{ const d=Math.hypot((c-cx)/(C/2),(r-cy)/(R/2)); return (d>0.68&&d<1.04)?(c%5===0?2:1):0; }
    default: return 0;
  }
}
export function dmBoard(fig='bars', C=17, R=9){
  let cells=''; for(let r=0;r<R;r++) for(let c=0;c<C;c++){ const v=litFig(fig,r,c,R,C); cells+=`<i class="dmb__c${v===1?' on':v===2?' on on2':''}"></i>`; }
  return `<div class="dmb" data-fig="${fig}" style="--c:${C};--r:${R}" role="img" aria-hidden="true">${cells}</div>`;
}
const FONT={'0':["01110","10001","10011","10101","11001","10001","01110"],'1':["00100","01100","00100","00100","00100","00100","01110"],
 '2':["01110","10001","00001","00110","01000","10000","11111"],'3':["11110","00001","00001","01110","00001","00001","11110"],
 '4':["00010","00110","01010","10010","11111","00010","00010"],'5':["11111","10000","11110","00001","00001","10001","01110"],
 '6':["00110","01000","10000","11110","10001","10001","01110"],'7':["11111","00001","00010","00100","01000","01000","01000"],
 '8':["01110","10001","10001","01110","10001","10001","01110"],'9':["01110","10001","10001","01111","00001","00010","01100"]};
export function dmNumeral(n){ const g=FONT[String(n)]||FONT['0']; let cells='';
  for(let r=0;r<7;r++) for(let c=0;c<5;c++) cells+=`<i class="num__c${g[r][c]==='1'?' on':''}"></i>`;
  return `<div class="num" aria-hidden="true">${cells}</div>`; }

/* AVATAR — deterministic initial avatar (testimonials/team must show a face; never a bare quote). */
export function avatar(name='', i=0){
  const ch=((name||'').trim()[0]||'?').toUpperCase();
  const cl=['#3B3BE0','#5F60AF','#2D2EA6','#6E6EF6','#8C8CFF','#454699'][i%6];
  const sv=`<svg xmlns='http://www.w3.org/2000/svg' width='96' height='96'><rect width='96' height='96' fill='${cl}'/><text x='48' y='64' font-family='Instrument Sans,Arial,sans-serif' font-weight='700' font-size='44' fill='#fff' text-anchor='middle'>${ch}</text></svg>`;
  return `data:image/svg+xml,${encodeURIComponent(sv)}`;
}

/* MARQUEE — the ONE canonical SEAMLESS infinite marquee (two identical groups, translateX -100%).
 * Hand-writing marquees is the bug source (the -50% version jumps). Templates MUST use this. */
export function marquee(inner, {reverse=false}={}){
  return `<div class="marq"${reverse?' data-reverse':''} data-marquee><div class="marq__g">${inner}</div><div class="marq__g" aria-hidden="true">${inner}</div></div>`;
}
export const MARQUEE_CSS = `
.marq{display:flex;overflow:hidden;-webkit-mask-image:linear-gradient(90deg,transparent,#000 6%,#000 94%,transparent);mask-image:linear-gradient(90deg,transparent,#000 6%,#000 94%,transparent)}
.marq__g{display:flex;gap:var(--marq-gap,3rem);padding-right:var(--marq-gap,3rem);flex:0 0 auto;min-width:100%;justify-content:space-around;align-items:center;animation:kit-marq var(--marq-dur,34s) linear infinite;will-change:transform}
.marq[data-reverse] .marq__g{animation-direction:reverse}.marq:hover .marq__g{animation-play-state:paused}
@keyframes kit-marq{from{transform:translateX(0)}to{transform:translateX(-100%)}}
@media(prefers-reduced-motion:reduce){.marq__g{animation:none;justify-content:flex-start}}
`;

/* RAIL — the ONE canonical horizontal card rail: aligns the first card to the page gutter AND bleeds
 * cards off both screen edges (no white gap, no hard cut). Must live inside a .container. Do NOT
 * re-hand-write the geometry per template (skin-contract §4). */
export const RAIL_CSS = `
/* full-viewport-width rail: first card aligns to the .container edge, cards BLEED off both SCREEN
 * edges with a soft fade (no hard cut). Place .rail as a direct child of a full-width section. */
.rail{--rail-pad:max(var(--gutter),calc(50vw - var(--container,1200px)/2 + var(--gutter)));
  display:flex;gap:var(--rail-gap,1.5rem);overflow-x:auto;scroll-snap-type:x mandatory;padding-block:6px;
  padding-inline:var(--rail-pad);scroll-padding-inline:var(--rail-pad);scrollbar-width:none;cursor:grab;
  -webkit-mask-image:linear-gradient(90deg,transparent 0,#000 clamp(16px,4vw,64px),#000 calc(100% - clamp(16px,4vw,64px)),transparent 100%);
          mask-image:linear-gradient(90deg,transparent 0,#000 clamp(16px,4vw,64px),#000 calc(100% - clamp(16px,4vw,64px)),transparent 100%)}
.rail::-webkit-scrollbar{display:none}
.rail.is-drag{cursor:grabbing;scroll-snap-type:none;scroll-behavior:auto}
.rail.is-drag *{pointer-events:none}
.rail>*{scroll-snap-align:start;flex:0 0 var(--rail-card,clamp(300px,78vw,440px))}
`;

/* behavior JS the template opts into (compose bundles the ones a template lists in `behaviors`). */
export const BEHAVIORS = {
  /* RAIL — pointer drag-to-scroll for [data-rail] (the "drag →" hint must actually work). Native
     touch/trackpad scroll still works; this adds click-drag on desktop. */
  rail:`document.querySelectorAll('[data-rail]').forEach(function(r){var down=false,sx=0,sl=0,moved=0;
    r.addEventListener('pointerdown',function(e){if(e.pointerType==='mouse'&&e.button!==0)return;down=true;moved=0;sx=e.clientX;sl=r.scrollLeft;r.setPointerCapture(e.pointerId);});
    r.addEventListener('pointermove',function(e){if(!down)return;var dx=e.clientX-sx;if(Math.abs(dx)>4){r.classList.add('is-drag');moved+=Math.abs(dx);}r.scrollLeft=sl-dx;});
    function up(e){if(!down)return;down=false;setTimeout(function(){r.classList.remove('is-drag');},0);try{r.releasePointerCapture(e.pointerId);}catch(_){}}
    r.addEventListener('pointerup',up);r.addEventListener('pointercancel',up);r.addEventListener('pointerleave',up);
    r.addEventListener('click',function(e){if(moved>6){e.preventDefault();e.stopPropagation();}},true);});
  /* OPTIONAL prev/next arrows: a rail's section may hold [data-rail-nav="-1"|"1"] buttons — click scrolls
     one card; ends auto-disable. Backward-compatible (does nothing when no arrow buttons are present). */
  document.querySelectorAll('[data-rail-nav]').forEach(function(btn){var sec=btn.closest('section');var rail=sec&&sec.querySelector('[data-rail]');if(!rail)return;
    function step(){var card=rail.querySelector('*');var gap=parseFloat(getComputedStyle(rail).columnGap||getComputedStyle(rail).gap)||24;return(card?card.getBoundingClientRect().width:300)+gap;}
    btn.addEventListener('click',function(){rail.scrollBy({left:(+btn.getAttribute('data-rail-nav'))*step(),behavior:'smooth'});});});
  document.querySelectorAll('[data-rail]').forEach(function(rail){var sec=rail.closest('section');if(!sec)return;var navs=[].slice.call(sec.querySelectorAll('[data-rail-nav]'));if(!navs.length)return;
    function upd(){var max=rail.scrollWidth-rail.clientWidth-1;navs.forEach(function(b){var d=+b.getAttribute('data-rail-nav');b.disabled=(d<0&&rail.scrollLeft<=0)||(d>0&&rail.scrollLeft>=max);});}
    rail.addEventListener('scroll',upd,{passive:true});window.addEventListener('resize',upd);upd();});`,
  /* FAQ — animated open/close for native <details> (keeps semantics + keyboard; honours reduced-motion) */
  faq:`(function(){var RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
    document.querySelectorAll('details').forEach(function(d){var sum=d.querySelector('summary'),body=d.querySelector('[data-acc-body],.faq__a');var anim=null;if(!sum||!body)return;
      sum.addEventListener('click',function(e){if(RM)return;e.preventDefault();if(anim){anim.cancel();anim=null;}
        var pb=getComputedStyle(body).paddingBottom||'0px';
        if(!d.open){d.open=true;var h=body.offsetHeight;anim=body.animate([{height:'0px',opacity:0,paddingBottom:'0px'},{height:h+'px',opacity:1,paddingBottom:pb}],{duration:280,easing:'cubic-bezier(.2,.8,.2,1)'});anim.onfinish=function(){if(anim){anim.cancel();anim=null;}body.style.height='';};}
        else{var start=body.offsetHeight;d.setAttribute('data-closing','');anim=body.animate([{height:start+'px',opacity:1,paddingBottom:pb},{height:'0px',opacity:0,paddingBottom:'0px'}],{duration:240,easing:'cubic-bezier(.4,0,.2,1)',fill:'forwards'});anim.onfinish=function(){d.open=false;d.removeAttribute('data-closing');if(anim){anim.cancel();anim=null;}body.style.height='';};}
      });});})();`,
  theme:`(function(){var root=document.documentElement;function apply(){var d=root.getAttribute('data-theme')||'light';
    document.querySelectorAll('[data-theme-toggle]').forEach(function(b){b.setAttribute('aria-checked',String(d==='dark'));
      b.setAttribute('aria-label',d==='dark'?'Switch to light theme':'Switch to dark theme');
      var l=b.querySelector('.theme-toggle__label');if(l)l.textContent=d==='dark'?'Light mode':'Dark mode';});}
    document.querySelectorAll('[data-theme-toggle]').forEach(function(b){b.addEventListener('click',function(){
      var d=(root.getAttribute('data-theme')||'light')==='dark'?'light':'dark';root.setAttribute('data-theme',d);
      try{localStorage.setItem('theme',d)}catch(e){}apply();});});apply();})();`,
  nav:`document.querySelectorAll('[data-burger]').forEach(function(b){b.addEventListener('click',function(){
      var n=b.closest('[data-nav]');var o=n.getAttribute('data-open')==='true';n.setAttribute('data-open',String(!o));
      b.setAttribute('aria-expanded',String(!o));});});
    document.querySelectorAll('[data-nav] a').forEach(function(a){a.addEventListener('click',function(){
      var n=a.closest('[data-nav]');if(n){n.setAttribute('data-open','false');var b=n.querySelector('[data-burger]');if(b)b.setAttribute('aria-expanded','false');}});});`,
  form:`document.querySelectorAll('form[data-contact]').forEach(function(f){f.addEventListener('submit',function(e){
      e.preventDefault();if(!f.checkValidity()){f.reportValidity();return;}var ok=f.querySelector('[data-ok]');if(ok)ok.hidden=false;f.reset();});});`,
  'word-reveal':`(function(){if(!('IntersectionObserver' in window)){document.querySelectorAll('[data-motion="word-reveal"]').forEach(function(h){h.classList.add('is-in')});return;}
    var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('is-in');io.unobserve(e.target);}});},{threshold:.3});
    document.querySelectorAll('[data-motion="word-reveal"]').forEach(function(h){io.observe(h);});})();`,
};
