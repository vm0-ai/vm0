# Section library — dot-matrix

Cut from the reference page by `tools/split-sections.mjs`. Pick the sections the brief supports,
in the order `NARRATIVE.md` gives, and assemble with `tools/compose.mjs`. A section you do not
pick is not in the page, so it cannot be left half-edited.

`_foundation.css` and `_shell.part` are always included. `css −` means the section reuses a skin
block an earlier section already brought. `geometry` is measured off the reference page at 1440 and
390 — column counts, the first media box's aspect ratio and its share of the section width, and the
section's own height. Read it here rather than opening the stylesheet.

| section | kind | html | skin | words | imgs | geometry |
|---|---|---|---|---|---|---|
| `01-nav` | nav | 1.7KB | — | 10 | 0 | 65px |
| `02-hero` | hero | 1.5KB | — | 38 | 0 | 873px |
| `03-statement` | statement | 1.0KB | — | 19 | 0 | 529px |
| `04-logos` | logos | 0.9KB | — | 16 | 0 | 262px |
| `05-steps` | steps | 7.2KB | — | 84 | 4 | 5col · media 1.33 · 28%w · 1888px |
| `06-feature` | feature | 2.8KB | — | 64 | 3 | 2col · →1col · media 1.25 · 34%w · 1889px |
| `07-gallery` | gallery | 4.0KB | — | 89 | 5 | media 1.33 · 30%w · 813px |
| `08-index` | index | 2.4KB | — | 43 | 4 | 4col · →1col · media 0.75 · 18%w · 701px |
| `09-narrative` | narrative | 2.0KB | — | 47 | 3 | 2col · →1col · media 1.25 · 34%w · 1889px |
| `10-testimonial` | testimonial | 2.5KB | — | 56 | 3 | 3col · →1col · media 1 · 3%w · 574px |
| `11-statement` | statement | 1.9KB | — | 240 | 0 | 749px |
| `12-pricing` | pricing | 1.5KB | — | 56 | 0 | 3col · →1col · 764px |
| `13-faq` | faq | 1.3KB | — | 92 | 0 | 573px |
| `14-stats` | stats | 0.6KB | — | 13 | 0 | 5col · →2col · 316px |
| `15-cta` | cta | 0.4KB | — | 17 | 0 | 417px |
| `16-footer` | footer | 2.3KB | — | 42 | 0 | 4col · →2col · 912px |

```json
{}
```

Whole reference page: 36.2KB · foundation 37.6KB.

## What each section is made of

Derived by `tools/describe-sections.mjs` — selectors matched in a browser, knobs read out of
`template.js`, hexes counted in the skin block. Read this instead of opening `template.js` or the
stylesheet: the four things below are what eleven runs went hunting for after composing, and they
are the ones the markup you composed does not tell you.

A **knob** changes what ships. `[data-cardgrid]` hides every card past `data-batch`, so a grid you
filled with six cards renders three until you raise it or drop the control. **Hardcoded** tints are
fixed hexes in the skin; the palette does not reach them, so a colour system you picked will not
recolour those parts.

Every section is also touched by `[data-rail-nav]`, `[data-motion="text-split"]` — the shared
motion/reveal runner, which reads data-rail-nav, data-to, data-suffix, data-motion, data-speed, data-pscale.
Listed once here; the lines below name only what is specific to one section.

### `01-nav`
- driven by: `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label · `[data-burger]` — reads data-open; queries [data-nav] a

### `02-hero`
- repeats: .mo-line ×10, .mo-w ×10, .mo-in ×3
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `03-statement`
- repeats: .xseg ×16, .pix ×3
- driven by: `[data-motion="word-reveal"]` —
- behaviour attributes present: data-motion

### `04-logos`
- repeats: .lg__item ×16
- driven by: nothing of its own

### `05-steps`
- repeats: .num__c ×140, .on ×54, .st__tag ×18
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `06-feature`
- repeats: .container ×4, .h2 ×4, .lx__row ×3
- one repeat holds: h2×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `07-gallery`
- repeats: .mono ×10, .muted ×10, .gl__card ×5
- driven by: `[data-rail]` —
- behaviour attributes present: data-rail-nav

### `08-index`
- repeats: .ix__tile ×4, .media ×4, .ix__media ×4
- one repeat holds: img×1, h3×1, p×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `09-narrative`
- repeats: .container ×4, .h2 ×4, .nr__step ×3
- one repeat holds: h2×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `10-testimonial`
- repeats: .tmc ×3, .tmc__q ×3, .tmc__by ×3
- one repeat holds: img×1
- driven by: nothing of its own

### `11-statement`
- driven by: nothing of its own

### `12-pricing`
- repeats: .pr__card ×3, .h3 ×3, .pr__tier ×3
- one repeat holds: h3×1, li×3, a×1
- driven by: nothing of its own

### `13-faq`
- repeats: .faq__item ×4, .faq__q ×4, .faq__ic ×4
- one repeat holds: p×1
- driven by: `details` — queries summary, [data-acc-body],.faq__a

### `14-stats`
- repeats: .stats__cell ×4, .stats__num ×4, .small ×4
- one repeat holds: p×1
- driven by: nothing of its own

### `15-cta`
- driven by: nothing of its own

### `16-footer`
- repeats: .small ×6, .ft__c ×4, .ft__ch ×4
- driven by: `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label
- behaviour attributes present: data-motion
