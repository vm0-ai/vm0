# The narrative contract

This file decides the page's narrative sequence: which reader questions must be answered and in what
order. It does not decide visual style, section names or section count. Keep only the beats the brief
supports, then use `layout-map.md` and `sections/_index.md` to choose how this template carries them.

A landing page is not a stack of modules. It is a chain of answers to the questions a reader asks in
order, and the order is not yours to choose — it is theirs. Compose from the beats below.

## The twelve beats

| # | beat | the reader's question | what the beat must actually do |
|---|---|---|---|
| 1 | **promise** | What is this, and what's in it for me? | One claim about the reader's outcome, not about your category. A subhead saying who it's for and how. One primary action. |
| 2 | **credentials** | Is this safe to keep reading? | Certifications, compliance, guarantees, scale — placed *inside or immediately under* the opening claim. |
| 3 | **proof-scale** | Who else already decided yes? | Named customers, user counts, ratings, press. Recognition, not argument. |
| 4 | **tension** | Why is this a problem worth solving now? | Name the cost of the status quo in the reader's own terms. This is the beat weak pages skip, and skipping it leaves everything after it floating. |
| 5 | **capability** | What does it actually do? | The two or three things it does, each stated as a reader outcome. |
| 6 | **mechanism** | How does it work? | The sequence, honestly. Steps, architecture, method. Earns the right to talk about benefits. |
| 7 | **proof-data** | Does it really deliver? | Numbers with units and scope. A number without a denominator is decoration. |
| 8 | **proof-people** | Would a person vouch for this? | A named human, their role, their organisation, in their words. |
| 9 | **proof-cases** | Has it worked for someone like me? | Concrete situations a reader can match themselves against. |
| 10 | **fit** | Does it cover *my* case? | The surfaces, segments, or scenarios it applies to. |
| 11 | **offer** | What does it cost, and what's the risk? | Price or "how pricing works", plus the risk reducer — trial, guarantee, no card, pilot scope. |
| 12 | **objections** | What's the catch? | Answer the real reasons people leave: data, lock-in, migration effort, learning curve, who it is *not* for. |
| 13 | **conversion** | How do I start? | The action, with as little friction as the offer allows. |
| 14 | **close** | *(restates 1)* | Repeat the promise and the single action for the reader who scrolled past everything. |

(Twelve content beats plus **conversion** and **close**, which are the same commitment made twice —
once as a form, once as a final band. Plus **wayfinding**: the nav and footer, which are not beats.)

## Rule 1 — trust is layered, not stacked

This is the rule that most distinguishes a page that converts from a page that merely lists sections.
There are five *kinds* of trust, and they are not interchangeable:

| kind | device | what it answers |
|---|---|---|
| credentials | compliance line, badge row, guarantee | "You won't hurt me." |
| scale | logo wall, user count, rating | "I'm not the first." |
| data | metric band, stat cards | "It measurably works." |
| people | named testimonial with role and company | "A person like me vouched." |
| cases | case cards, customer stories | "It worked in my situation." |

**Place each kind immediately after a moment that asks the reader to invest.** Credentials go in the
hero, because the first claim is the first thing doubted. Scale goes right under the opening, because
that's when "is this real?" peaks. Data goes after the capability argument, because that's when the
claim becomes checkable. People go before the price. Cases go before the close.

A page that collects all its proof into one testimonial section leaves every other claim unsupported.
**Ship at least three of the five kinds, at three separated points in the page.**

## Rule 2 — one page, one action

Decide the single conversion goal before writing anything. The same action appears in the hero, once
mid-page (usually at the offer), and in the close. Secondary actions are allowed and must look
secondary. Two competing primary actions halve both.

## Rule 3 — the order is fixed, the beats are not

Drop any beat the brief cannot support honestly. A page with no customers yet has no `proof-scale` and
no `proof-cases`; it leans harder on `mechanism` and `credentials`. That is a good page. A page that
*invents* a logo wall is not.

Merge beats when the evidence merges — a case study that carries a number and a quote is
`proof-cases` + `proof-data` + `proof-people` in one section. Repeat a beat when the content genuinely
has two of them.

What you may not do is reorder. Proof before the claim it supports reads as noise; price before
mechanism reads as expensive; objections before benefits reads as defensive.

## Rule 4 — depth is part of the structure

A beat with a heading and four words under it has not happened. Every beat carries at least a
supporting sentence; at least one beat — usually `tension`, `mechanism`, or the objection answers —
carries a multi-paragraph reading block inside `.prose`.

`main` must reach 650 visible words, and the reference `index.html` in each package is the density to
match, not a ceiling to approach. Depth comes from specifics in the brief: real constraints, real
sequences, real numbers. Never from restating the heading in the body.

## Rule 5 — the reference page is a layout reference, not a script

Each package's `index.html` exists to show you every device the stylesheet supports and the density to
aim for. Its copy is a stand-in.

Do not copy its argument. A demo's rhetorical skeleton reproduced into a product it doesn't fit is a
measured failure mode, not a hypothetical one: an example's "why now" beat has come back nearly
move-for-move in unrelated pages. Take **structure** from this file and the brief. Take **spacing,
density and device usage** from the example.

## Working checklist

Before writing HTML, answer these from the brief. If you cannot answer one, that beat is a candidate
to drop, not to invent:

1. What is the single action? Where does it appear three times?
2. What is the one-sentence promise, stated as the reader's outcome?
3. Which three of the five trust kinds do we have evidence for, and where does each land?
4. What does the status quo cost the reader? (If you cannot say, `tension` is missing and the page
   will read as a feature list.)
5. What is the mechanism, in the fewest honest steps?
6. Which three objections actually lose this sale?
7. Which beat carries the long-form argument?
