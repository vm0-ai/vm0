/* template-dot-matrix.mjs — EXAMPLE template in the template architecture (learned from kerna.studio).
 *
 * PROOF of the refactor: this template consumes ONLY the pure content contracts (sections.mjs) and
 * owns 100% of each section's STRUCTURE + STYLE. The SAME `feature` / `steps` / `contact` content
 * that the base system used to force into a centred 3-col grid is here rendered as kerna's real
 * FULL-BLEED rows, a numbered service index with a central spine + tag marquees, and a booking
 * calendar — because structure is no longer fixed by the system. Palette = catalogue `midnight`. */
import { themeToggle, burger, dmBoard, dmNumeral, avatar, marquee, MARQUEE_CSS, RAIL_CSS } from './engine/kit.mjs';

const btns = (ctas=[]) => ctas.map((c,i)=>`<a class="btn ${i===0?'btn-primary':'btn-ghost'}" href="${c.href}">${c.label}</a>`).join('');
const seg = (s,i=0) => `<span class="xseg${s.emphasis?' pix':''}" style="--i:${i}">${s.text}</span>`;

export const template = {
  id:'dot-matrix', brand:'ONMARK', theme:'dark', motionPersonality:'kinetic',
  fontLink:'<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700;12..96,800&family=Instrument+Sans:wght@400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">',
  signature:'LED dot-matrix boards (distinct figures) · organic wordmark bleed · numbered service index w/ central spine + tag marquees',
  behaviors:['theme','nav','form','word-reveal','faq','rail'],

  render:{
    /* NAV — template owns the bar + mobile drawer entirely */
    nav(c){ const links=(c.links||[]).map(l=>`<li><a href="${l.href}">${l.label}</a></li>`).join('');
      return `<nav class="nav" data-nav data-section="nav" aria-label="Primary"><div class="container nav__bar">
        <a class="nav__brand" href="#top">${c.brand}</a>
        <button class="nav__burger" data-burger aria-expanded="false" aria-label="Menu">${burger()}</button>
        <div class="nav__menu">
          <ul class="nav__links">${links}</ul>
          ${c.cta?`<a class="btn btn-primary nav__cta" href="${c.cta.href}">${c.cta.label}</a>`:''}
          ${themeToggle('nav')}
        </div></div></nav>`; },

    /* HERO — giant organic wordmark bleed + headline w/ machine-emphasis + LED board */
    hero(c){ return `<section class="section hero" data-section="hero" data-variant="wordmark" data-signature="dm-hero">
      <div class="hero__wm" data-bleed aria-hidden="true">${c.brand||'ONMARK'}</div>
      <div class="container">
        ${c.eyebrow?`<p class="eyebrow" data-motion="reveal-fade">${c.eyebrow}</p>`:''}
        <h1 class="display hero__title" data-motion="text-split">${c.title}</h1>
        ${c.lead?`<p class="lead hero__lead" data-motion="reveal-up">${c.lead}</p>`:''}
        ${c.ctas?.length?`<div class="hero__cta" data-motion="reveal-up">${btns(c.ctas)}</div>`:''}
      </div></section>`; },

    /* STATEMENT — giant word-by-word reveal; emphasis words in mono */
    statement(c){ return `<section class="section bs" data-section="statement" data-variant="reveal">
      <div class="container">${c.eyebrow?`<p class="eyebrow bs__eb">${c.eyebrow}</p>`:''}
        <p class="bs__text" data-motion="word-reveal">${(c.segments||[]).map(seg).join(' ')}</p></div></section>`; },

    /* FEATURE — benefit rows: text ⇄ a real image. Row BACKGROUND is full-bleed (alternating band),
       but its CONTENT sits in .container so it aligns to the SAME grid as every other section. */
    feature(c){
      const rows=(c.items||[]).map((it,i)=>`<div class="lx__row${i%2?' lx--dark':''}" data-variant="${i%2?'media-left':'media-right'}">
        <div class="container lx__inner">
          <div class="lx__text">${it.eyebrow?`<p class="eyebrow">${it.eyebrow}</p>`:''}
            <h3 class="h2 lx__title" data-motion="reveal-up">${it.title}</h3>
            ${it.body?`<p class="lead" data-motion="reveal-up">${it.body}</p>`:''}</div>
          <div class="media lx__media" data-photo="${it.media||it.title}" role="img" aria-label="${it.title}"></div></div></div>`).join('');
      return `<section class="section lx" data-section="feature" data-variant="rows">
        ${c.heading?`<div class="container"><h2 class="h2 lx__heading" data-motion="reveal-up">${c.heading}</h2></div>`:''}
        <div class="lx__rows">${rows}</div></section>`; },

    /* STEPS — one card per step on a single background: dot-matrix number + text HORIZONTAL, real
       image on the right. tags are compact chips under the body. */
    steps(c){ const rows=(c.items||[]).map((it,i)=>{
        const tags=(it.tags||[]).map((t,j)=>`<span class="st__tag v${j%4}">${t}</span>`).join('');
        return `<li class="st__card" data-motion="reveal-up">
          <span class="st__num${i%2?' alt':''}" aria-hidden="true">${dmNumeral(i+1)}</span>
          <div class="st__text"><h3 class="h3 st__title">${it.title}</h3>
            ${it.body?`<p class="st__body muted">${it.body}</p>`:''}
            ${tags?`<div class="st__tags">${tags}</div>`:''}</div>
          <div class="media st__img" data-photo="${it.media||it.title}" role="img" aria-label="${it.title}"></div></li>`; }).join('');
      return `<section class="section st" data-section="steps" data-variant="cards">
        <div class="container">
          <div class="st__head">${c.eyebrow?`<p class="eyebrow">${c.eyebrow}</p>`:''}
            ${c.heading?`<h2 class="h2" data-motion="reveal-up">${c.heading}</h2>`:''}
            ${c.sub?`<p class="lead st__sub">${c.sub}</p>`:''}</div>
          <ol class="st__list">${rows}</ol></div></section>`; },

    /* STATS — big indigo numerals on a solid ground */
    stats(c){ return `<section class="section stats" data-section="stats" data-variant="band" data-motion="reveal-up">
      <div class="container stats__grid">${(c.items||[]).map(s=>`<div class="stats__cell">
        <div class="stats__num">${s.value}</div><p class="small mono">${s.label}</p></div>`).join('')}</div></section>`; },

    /* CONTACT — clean split: heading + contact lines + a working form (no fake calendar) */
    contact(c){ const cols=(c.lines||[]).map(l=>`<div class="cf__c"><p class="cf__ch small mono">${l.h}</p><p class="cf__cv">${l.v}</p></div>`).join('');
      return `<section class="section cf" data-section="contact" data-variant="split" id="contact" data-motion="reveal-up">
        <div class="container cf__grid">
          <div><h2 class="h2 cf__title" data-motion="reveal-up">${c.title||'Get in touch'}</h2>
            ${cols?`<div class="cf__cols">${cols}</div>`:''}</div>
          <form class="cf__form" data-contact novalidate>
            <label class="cf__field"><span>Name</span><input name="name" type="text" required autocomplete="name"></label>
            <label class="cf__field"><span>Email</span><input name="email" type="email" required autocomplete="email"></label>
            <label class="cf__field"><span>Message</span><textarea name="message" rows="4" required></textarea></label>
            <button class="btn btn-primary" type="submit">Send message</button>
            <p class="cf__ok small" data-ok role="status" hidden>Thanks — we'll be in touch.</p>
          </form></div></section>`; },

    /* LOGOS — full-bleed dim mono wall; a WALL carries no title (label is a11y-only) + SEAMLESS marquee */
    logos(c){ const row=(c.items||[]).map(n=>`<span class="lg__item">${n}</span>`).join('');
      return `<section class="section lg" data-section="logos" data-variant="wall" data-width="full" aria-label="${c.label||'Trusted by'}" style="--marq-gap:clamp(2.5rem,6vw,5rem)">
        ${marquee(row)}</section>`; },

    /* TESTIMONIAL — quote cards; every quote carries a face (avatar) */
    testimonial(c){ const cards=(c.quotes||[]).map((q,i)=>`<figure class="tmc">
        <blockquote class="tmc__q">${q.text}</blockquote>
        <figcaption class="tmc__by"><img class="tmc__av" src="${avatar(q.name,i)}" alt="" width="44" height="44" loading="lazy" decoding="async"><span class="tmc__meta"><span class="tmc__name">${q.name}</span>${q.role?`<span class="small muted">${q.role}</span>`:''}</span></figcaption></figure>`).join('');
      return `<section class="section tm" data-section="testimonial" data-variant="cards" data-motion="reveal-up">
        <div class="container">${c.heading?`<h2 class="h2 sec-h">${c.heading}</h2>`:''}<div class="tm__grid">${cards}</div></div></section>`; },

    /* PRICING — plan cards, popular flooded indigo */
    pricing(c){ const cards=(c.plans||[]).map(p=>`<div class="pr__card${p.popular?' pop':''}">
        ${p.popular?`<span class="pr__badge mono">Popular</span>`:''}
        <h3 class="h3 pr__tier">${p.tier}</h3>
        <div class="pr__price"><span class="pr__amt">${p.price}</span>${p.unit?`<span class="small">${p.unit}</span>`:''}</div>
        <ul class="pr__feats">${(p.features||[]).map(f=>`<li>${f}</li>`).join('')}</ul>
        <a class="btn ${p.popular?'btn-primary':'btn-ghost'} pr__cta" href="#contact">Choose ${p.tier}</a></div>`).join('');
      return `<section class="section pr" data-section="pricing" data-variant="cards" data-motion="reveal-up">
        <div class="container">${c.heading?`<div class="sec-h"><h2 class="h2">${c.heading}</h2>${c.sub?`<p class="lead">${c.sub}</p>`:''}</div>`:''}<div class="pr__grid">${cards}</div></div></section>`; },

    /* FAQ — native <details> accordion (keyboard a11y for free) */
    faq(c){ const items=(c.items||[]).map(it=>`<details class="faq__item"><summary class="faq__q">${it.q}<span class="faq__ic" aria-hidden="true">+</span></summary><div class="faq__a"><p class="muted">${it.a}</p></div></details>`).join('');
      return `<section class="section faq" data-section="faq" data-variant="list" data-motion="reveal-up">
        <div class="container faq__wrap">${c.heading?`<h2 class="h2 faq__h">${c.heading}</h2>`:''}<div class="faq__list">${items}</div></div></section>`; },

    /* GALLERY — a horizontal RAIL (canonical .rail geometry) of large cards; each card carries a
       2-line subtitle for more context. */
    gallery(c){ const cards=(c.items||[]).map(it=>`<article class="gl__card">
        <div class="media gl__media" data-photo="${it.media||it.title}" role="img" aria-label="${it.title}"></div>
        <div class="gl__body"><div class="gl__top">${it.tag?`<span class="gl__tag mono">${it.tag}</span>`:''}${it.meta?`<span class="small mono muted">${it.meta}</span>`:''}</div>
          <h3 class="h3 gl__title">${it.title}</h3>
          ${it.desc?`<p class="gl__desc muted">${it.desc}</p>`:''}</div></article>`).join('');
      return `<section class="section gl" data-section="gallery" data-variant="rail" data-motion="reveal-up">
        <div class="container gl__head">${c.heading?`<h2 class="h2">${c.heading}</h2>`:''}<div class="gl__nav"><button class="gl__arrow" type="button" data-rail-nav="-1" aria-label="Previous">←</button><button class="gl__arrow" type="button" data-rail-nav="1" aria-label="Next">→</button></div></div>
        <div class="rail gl__rail" data-rail>${cards}</div></section>`; },

    /* INDEX — numbered directory tiles (running number + caption over a real image) */
    index(c){ const tiles=(c.items||[]).map((it,i)=>`<article class="ix__tile" data-motion="reveal-up">
        <div class="media ix__media" data-photo="${it.media||it.title}" role="img" aria-label="${it.title}"></div>
        <div class="ix__body"><span class="ix__n mono">${String(i+1).padStart(2,'0')}</span>
          <h3 class="h3 ix__title">${it.title}</h3>${it.caption?`<p class="small ix__cap">${it.caption}</p>`:''}</div></article>`).join('');
      return `<section class="section ix" data-section="index" data-variant="tiles" data-motion="reveal-up">
        <div class="container">${c.heading?`<div class="sec-h"><h2 class="h2">${c.heading}</h2>${c.sub?`<p class="lead">${c.sub}</p>`:''}</div>`:''}<div class="ix__grid">${tiles}</div></div></section>`; },

    /* NARRATIVE — an ordered scrollytelling sequence; content aligns to .container (same grid). */
    narrative(c){ const rows=(c.items||[]).map((it,i)=>`<li class="nr__step${i%2?' alt':''}">
        <div class="container nr__inner">
          <div class="media nr__media" data-photo="${it.media||it.title}" role="img" aria-label="${it.title}"></div>
          <div class="nr__text">${it.eyebrow?`<p class="eyebrow">${it.eyebrow}</p>`:''}<h3 class="h2 nr__title" data-motion="reveal-up">${it.title}</h3>
            ${it.body?`<p class="lead">${it.body}</p>`:''}${it.caption?`<p class="small mono muted">${it.caption}</p>`:''}</div></div></li>`).join('');
      return `<section class="section nr" data-section="narrative" data-variant="story">
        ${c.heading?`<div class="container"><h2 class="h2 nr__h" data-motion="reveal-up">${c.heading}</h2></div>`:''}
        <ol class="nr__rows">${rows}</ol></section>`; },

    /* CTA — indigo flooded panel + cream pill */
    cta(c){ return `<section class="section cta" data-section="cta" data-variant="panel" data-motion="reveal-up">
      <div class="container cta__panel"><div><h2 class="h2 cta__title">${c.title}</h2>
        ${c.sub?`<p class="cta__sub">${c.sub}</p>`:''}</div>
        ${c.cta?`<a class="btn cta__btn" href="${c.cta.href}">${c.cta.label}</a>`:''}</div></section>`; },

    /* FOOTER — BIG closing: giant wordmark bleed + "Get in touch" heading + contact columns
       (absorbed from the contact section) + nav columns + copyright. */
    footer(c){ const cols=(c.columns||[]).map(col=>`<div class="ft__col"><h3 class="ft__h">${col.title}</h3><ul>${
        (col.links||[]).map(l=>`<li><a href="${l.href}">${l.label}</a></li>`).join('')}</ul></div>`).join('');
      const lines=(c.lines||[]).map(l=>`<div class="ft__c"><p class="ft__ch small mono">${l.h}</p><p class="ft__cv">${l.v}</p></div>`).join('');
      return `<div class="ft">
        <div class="ft__wm" data-bleed aria-hidden="true">${c.brand}</div>
        <div class="container ft__top" id="contact">
          ${c.title?`<h2 class="h2 ft__title" data-motion="reveal-up">${c.title}</h2>`:''}
          ${lines?`<div class="ft__contact">${lines}</div>`:''}
        </div>
        <div class="container ft__grid"><div class="ft__brand"><div class="ft__name">${c.brand}</div>
          <p class="small">${c.tagline||''}</p></div>${cols}</div>
        <div class="container ft__bottom"><span class="small">© 2026 ${c.brand}.</span>${themeToggle('footer')}</div></div>`; },
  },

  css:`
/* palette — catalogue midnight (dual-mode, vivid indigo, dark-first) */
:root{--bg:#FFFFFF;--ink:#0B1020;--ink-soft:#566075;--accent:#3B3BE0;--accent-ink:#FFFFFF;--surface:#F4F4F5;--surface-2:#EAEBEC;--border:#DADBDE;--ring:#3B3BE0;--slab:#05070E;
  --fd:'Bricolage Grotesque';--fb:'Instrument Sans';--fm:'Space Mono';--radius:16px;
  --grid-line:color-mix(in srgb,var(--ink) 12%,transparent);
  --board-bg:#090C16;--dm-off:rgba(232,235,255,.09);--dm-lit:#ECEDFF;--dm-lit2:#6E6EF6}
html[data-theme="dark"]{--bg:#070A14;--ink:#E8EBF5;--ink-soft:#969FB5;--accent:#8C8CFF;--accent-ink:#06060F;--surface:#151822;--surface-2:#20232D;--border:#343741;--ring:#8C8CFF;--slab:#040404;--grid-line:color-mix(in srgb,var(--ink) 9%,transparent)}
.lx--dark{--bg:#0A0E1A;--surface:#151A2A;--ink:#E8EBF5;--ink-soft:#9AA3BC;--accent:#8C8CFF;--border:#2A3145;--grid-line:color-mix(in srgb,#E8EBF5 9%,transparent);background:#0A0E1A;color:#E8EBF5}
body{font-family:var(--fb),system-ui,sans-serif;background:var(--bg);color:var(--ink)}
.display,h1,.h1,h2,.h2,h3,.h3{font-family:var(--fd);letter-spacing:-.02em}
.display{font-weight:800;letter-spacing:-.04em;line-height:.98}.h2,h2{font-weight:700}
.eyebrow{font-family:var(--fm);font-weight:700;letter-spacing:.2em;color:var(--accent);text-transform:uppercase}
.mono{font-family:var(--fm)}.pix{font-family:var(--fm);font-weight:700;text-transform:uppercase;font-size:.86em;color:var(--accent);padding:0 .05em}
.btn{border-radius:var(--r-pill);font-family:var(--fb);font-weight:600}
.btn-primary{background:var(--accent);color:var(--accent-ink)}
.btn-ghost{background:transparent;color:var(--ink);border-color:var(--ink)}.btn-ghost:hover{background:var(--ink);color:var(--bg)}
/* theme toggle + nav (template-owned; foundation no longer ships nav) */
.theme-toggle{display:inline-flex;align-items:center;gap:.45rem;min-height:44px;min-width:44px;justify-content:center;padding:.4rem .7rem;border-radius:var(--r-pill);border:1px solid var(--border);background:var(--surface);color:var(--ink);font:600 .82rem var(--fb);cursor:pointer}
.theme-toggle svg{width:18px;height:18px}.theme-toggle__icon{display:none;align-items:center}
html[data-theme="light"] .theme-toggle__moon{display:inline-flex}html[data-theme="dark"] .theme-toggle__sun{display:inline-flex}
.theme-toggle__label{display:none}.theme-toggle--footer .theme-toggle__label{display:inline}
.nav{position:sticky;top:0;z-index:100;background:color-mix(in srgb,var(--bg) 86%,transparent);backdrop-filter:blur(8px);border-bottom:1px solid var(--border)}
.nav__bar{display:flex;align-items:center;justify-content:space-between;min-height:64px;gap:var(--space-5)}
.nav__brand{font-family:var(--fd);font-weight:800;letter-spacing:-.04em;font-size:1.4rem;text-decoration:none}
.nav__menu{display:flex;align-items:center;gap:var(--space-6)}
.nav__links{display:flex;gap:var(--space-5);list-style:none;margin:0;padding:0}
.nav__links a{font-family:var(--fm);font-size:.82rem;letter-spacing:.04em;text-transform:uppercase;color:var(--ink-soft);text-decoration:none}
.nav__links a:hover{color:var(--accent)}.nav__cta{text-decoration:none}
.nav__burger{display:none;align-items:center;justify-content:center;width:44px;height:44px;background:transparent;border:1px solid var(--border);border-radius:var(--r-sm);color:var(--ink);cursor:pointer}
@media(max-width:767px){.nav__burger{display:inline-flex}
  .nav__menu{position:absolute;left:0;right:0;top:100%;flex-direction:column;align-items:stretch;gap:var(--space-4);background:var(--bg);border-bottom:1px solid var(--border);padding:var(--space-5);transform:translateY(-8px);opacity:0;visibility:hidden;transition:opacity .18s,transform .18s,visibility .18s}
  .nav[data-open="true"] .nav__menu{transform:none;opacity:1;visibility:visible}
  .nav__links{flex-direction:column;gap:var(--space-2)}.nav__cta{width:100%}}
/* dot-matrix screens */
.dmb-screen{background:var(--board-bg);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden}
.dmb{display:grid;grid-template-columns:repeat(var(--c),1fr);grid-template-rows:repeat(var(--r),1fr);gap:clamp(4px,.7vw,10px);padding:clamp(10px,1.6vw,22px);aspect-ratio:var(--c)/var(--r);width:100%}
.dmb__c{border-radius:999px;background:var(--dm-off)}.dmb__c.on{background:var(--dm-lit)}.dmb__c.on2{background:var(--dm-lit2)}
.num{display:grid;grid-template-columns:repeat(5,1fr);gap:clamp(3px,.5vw,6px);width:clamp(64px,6vw,104px)}
.num__c{aspect-ratio:1;border-radius:999px;background:transparent}.num__c.on{background:var(--num-lit,var(--accent))}
/* real images — apply-photos fills .media with an <img>; hover-zoom for life */
.media{overflow:hidden;background:var(--surface-2)}
.media>img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .7s cubic-bezier(.2,.7,.2,1)}
.gl__card:hover .media>img,.st__card:hover .media>img,.ix__tile:hover .media>img,.lx__row:hover .media>img,.nr__step:hover .media>img{transform:scale(1.05)}
${MARQUEE_CSS}${RAIL_CSS}
/* hero */
.hero{position:relative;padding-top:0;overflow:hidden}
.hero__wm{font-family:var(--fd);font-weight:800;letter-spacing:-.06em;line-height:.72;color:var(--accent);font-size:clamp(5rem,27vw,24rem);white-space:nowrap;overflow:hidden;padding-top:.04em;margin:0 0 clamp(1rem,3vw,2.2rem);user-select:none}
.hero__title{font-size:clamp(2.4rem,6vw,4.6rem);max-width:16ch;overflow-wrap:anywhere;margin-top:var(--space-4)}
.hero__lead{max-width:52ch;margin-top:var(--space-5)}.hero__cta{display:flex;flex-wrap:wrap;gap:var(--space-3);margin-top:var(--space-6)}
.hero__board{height:clamp(120px,20vw,190px);margin-top:clamp(2rem,5vw,3.5rem);background-image:radial-gradient(circle,var(--dm-lit2) 0 26%,transparent 30%),radial-gradient(circle,var(--dm-off) 0 34%,transparent 38%);background-size:64px 64px,19px 19px;background-position:12px 10px,0 0}
/* statement */
.bs__eb{margin-bottom:clamp(1.2rem,3vw,2rem)}
.bs__text{font-family:var(--fd);font-weight:700;letter-spacing:-.02em;line-height:1.16;font-size:clamp(1.7rem,4.4vw,3.4rem);max-width:24ch;color:var(--ink)}
/* WORD-REVEAL — words cascade in with a BLUR-in as the line scrolls into view (staggered per word) */
.xseg{display:inline-block;filter:blur(9px);opacity:0;transform:translateY(.28em);
  transition:filter .6s cubic-bezier(.2,.7,.2,1),opacity .6s ease,transform .6s cubic-bezier(.2,.7,.2,1);transition-delay:calc(var(--i,0)*45ms)}
.xseg.pix{transform:translateY(.28em)}
[data-motion="word-reveal"].is-in .xseg{filter:none;opacity:1;transform:none}
@media(prefers-reduced-motion:reduce){.xseg{filter:none;opacity:1;transform:none;transition:none}}
/* feature = full-bleed BAND (row bg) + grid-aligned CONTENT (.container) — unified grid */
.lx__heading{font-size:clamp(1.6rem,4vw,2.6rem);margin-bottom:clamp(1.5rem,4vw,2.5rem)}
.lx__rows{display:flex;flex-direction:column}
.lx__row{border-top:1px solid var(--border)}
.lx__inner{display:grid;grid-template-columns:1fr;gap:var(--space-6);align-items:center;padding-block:clamp(2rem,5vw,4rem)}
@media(min-width:900px){.lx__inner{grid-template-columns:1fr 1fr;gap:clamp(2rem,6vw,5rem)}
  .lx__row[data-variant="media-left"] .lx__text{order:2}.lx__row[data-variant="media-left"] .lx__media{order:1}}
.lx__title{font-size:clamp(1.5rem,3vw,2.4rem);max-width:16ch}.lx__text .lead{max-width:42ch;margin-top:var(--space-3)}
.lx__media{aspect-ratio:5/4;border-radius:var(--radius);border:1px solid var(--border)}
/* steps = horizontal cards on one background (number + text left, image right) */
.st__head{margin-bottom:clamp(1.8rem,4vw,2.8rem)}.st__head h2{font-size:clamp(1.9rem,4.5vw,3rem)}.st__sub{max-width:52ch;margin-top:var(--space-3)}
.st__list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:var(--space-5)}
.st__card{display:grid;grid-template-columns:1fr;gap:var(--space-5);align-items:center;
  background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:clamp(1.4rem,2.5vw,2rem);overflow:hidden}
.st__num{display:inline-flex;flex:none;align-self:center}.st__num .num{width:clamp(56px,5vw,88px);--num-lit:var(--accent)}
.st__num.alt .num{--num-lit:var(--support-2,#7e7eeb)}
.st__title{font-size:clamp(1.3rem,2.4vw,1.9rem)}.st__body{margin-top:var(--space-2);max-width:52ch}
.st__tags{display:flex;flex-wrap:wrap;gap:.4rem;margin-top:var(--space-4)}
.st__tag{font-family:var(--fm);font-size:.74rem;padding:.35rem .7rem;border-radius:999px;border:1px solid var(--border);color:var(--ink-soft)}
.st__tag.v0{background:color-mix(in srgb,var(--accent) 16%,var(--bg));color:var(--ink);border-color:transparent}
.st__img{aspect-ratio:16/11;border-radius:calc(var(--radius) - 4px);border:1px solid var(--border)}
@media(min-width:860px){.st__card{grid-template-columns:auto minmax(0,1fr) clamp(320px,40%,540px);gap:clamp(1.6rem,3.2vw,3rem)}
  .st__num{align-self:center}.st__text{align-self:center}.st__img{aspect-ratio:4/3;height:100%;align-self:stretch}}
/* stats */
.stats__grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:var(--space-7);text-align:center}
.stats__num{font-family:var(--fd);font-weight:800;letter-spacing:-.04em;color:var(--accent);font-size:clamp(2.6rem,6vw,4rem);line-height:1}
.stats__cell .small{margin-top:var(--space-2);text-transform:uppercase;letter-spacing:.06em;font-size:.78rem}
/* contact = split (heading + lines + form; no calendar) */
.cf__grid{display:grid;gap:clamp(2rem,5vw,3.5rem)}@media(min-width:860px){.cf__grid{grid-template-columns:1fr 1fr;align-items:start}}
.cf__title{font-size:clamp(1.9rem,4vw,2.8rem);max-width:14ch;font-weight:800}
.cf__cols{display:grid;grid-template-columns:repeat(2,1fr);gap:var(--space-5);margin-top:clamp(1.5rem,4vw,2.5rem)}
.cf__ch{text-transform:uppercase;letter-spacing:.06em;color:var(--accent)}.cf__cv{font-family:var(--fd);font-weight:600;margin-top:.2rem}
.cf__form{display:flex;flex-direction:column;gap:var(--space-4)}
.cf__field{display:flex;flex-direction:column;gap:var(--space-2)}.cf__field span{font-family:var(--fm);text-transform:uppercase;letter-spacing:.06em;font-size:.72rem;color:var(--ink-soft)}
.cf__field input,.cf__field textarea{font:inherit;color:var(--ink);background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:.75rem .9rem}
.cf__field input:focus,.cf__field textarea:focus{outline:none;border-color:var(--ring);box-shadow:0 0 0 3px color-mix(in srgb,var(--ring) 26%,transparent)}
.cf__ok{color:var(--accent);font-weight:600}
/* cta */
.cta{padding-inline:var(--gutter)}
.cta__panel{background:var(--accent);color:var(--accent-ink);border-radius:var(--r-xl);padding:clamp(2rem,5vw,3.5rem);display:flex;flex-wrap:wrap;gap:var(--space-5);align-items:center;justify-content:space-between}
.cta__title{font-weight:800;letter-spacing:-.03em;color:var(--accent-ink);max-width:24ch}.cta__sub{color:var(--accent-ink);opacity:.92;margin-top:var(--space-3)}
.cta__btn{background:var(--accent-ink);color:var(--accent);font-weight:600}
/* footer — BIG closing block; dark flood in both themes for drama (absorbs the contact section) */
footer{--bg:#0A0E1A;--surface:#151A2A;--ink:#E8EBF5;--ink-soft:#9AA3BC;--accent:#8C8CFF;--border:#252C40;
  background:#0A0E1A;color:#E8EBF5;border-top:1px solid #252C40;padding-block:clamp(2.5rem,6vw,4.5rem) var(--space-6);margin-top:var(--space-2);overflow:hidden}
.ft__wm{font-family:var(--fd);font-weight:800;letter-spacing:-.05em;line-height:.72;color:var(--accent);
  font-size:clamp(4.5rem,23vw,21rem);white-space:nowrap;overflow:hidden;padding-inline:var(--gutter);user-select:none;margin-bottom:clamp(1.5rem,4vw,3rem)}
.ft__title{font-size:clamp(2rem,5vw,3.4rem);font-weight:800;max-width:16ch;letter-spacing:-.03em}
.ft__contact{display:grid;grid-template-columns:repeat(2,1fr);gap:var(--space-5) var(--space-6);margin-top:clamp(2rem,5vw,3rem)}
@media(min-width:760px){.ft__contact{grid-template-columns:repeat(4,1fr)}}
.ft__ch{text-transform:uppercase;letter-spacing:.06em;color:var(--accent)}.ft__cv{font-family:var(--fd);font-weight:600;margin-top:.2rem}
.ft__grid{display:grid;gap:var(--space-6);margin-top:clamp(2.5rem,6vw,4rem);padding-top:var(--space-7);border-top:1px solid var(--border)}@media(min-width:680px){.ft__grid{grid-template-columns:1.6fr 1fr 1fr 1fr}}
.ft__name{font-family:var(--fd);font-weight:800;letter-spacing:-.04em;font-size:1.7rem}.ft__brand .small{color:var(--ink-soft);margin-top:var(--space-2);max-width:34ch}
.ft__h{font-family:var(--fm);text-transform:uppercase;letter-spacing:.12em;font-size:.78rem;color:var(--ink-soft);margin-bottom:var(--space-3)}
.ft__col ul{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:var(--space-2)}.ft__col a{color:var(--ink-soft);text-decoration:none}.ft__col a:hover{color:var(--ink)}
.ft__bottom{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--space-3);margin-top:var(--space-7);color:var(--ink-soft)}
/* shared section head + muted */
.muted{color:var(--ink-soft)}
.sec-h{max-width:60ch;margin:0 auto var(--space-7);text-align:center}.sec-h .lead{margin-top:var(--space-3)}
/* logos wall — a WALL, no title; uses the canonical seamless .marq (kit MARQUEE_CSS) */
.lg__item{font-family:var(--fd);font-weight:800;letter-spacing:-.02em;font-size:1.5rem;color:var(--ink-soft);opacity:.55;white-space:nowrap}
/* testimonial */
.tm__grid{display:grid;gap:var(--space-5);grid-template-columns:1fr}@media(min-width:760px){.tm__grid{grid-template-columns:repeat(3,1fr)}}
.tmc{margin:0;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:var(--space-6);display:flex;flex-direction:column;gap:var(--space-4)}
.tmc::before{content:"//";font-family:var(--fm);font-weight:700;color:var(--accent);font-size:1.4rem}
.tmc__q{margin:0;font-family:var(--fd);font-weight:600;letter-spacing:-.01em;font-size:1.15rem;line-height:1.4}
.tmc__by{display:flex;align-items:center;gap:var(--space-3);margin-top:auto}
.tmc__av{width:44px;height:44px;border-radius:50%;object-fit:cover;flex:none}
.tmc__meta{display:flex;flex-direction:column}.tmc__name{font-family:var(--fd);font-weight:700}
/* pricing */
.pr__grid{display:grid;gap:var(--space-5);grid-template-columns:1fr}@media(min-width:820px){.pr__grid{grid-template-columns:repeat(3,1fr);align-items:stretch}}
.pr__card{position:relative;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:var(--space-6);display:flex;flex-direction:column;gap:var(--space-4)}
.pr__card.pop{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
.pr__card.pop .pr__tier,.pr__card.pop .pr__amt,.pr__card.pop .pr__feats li{color:var(--accent-ink)}
.pr__card.pop .pr__feats li::before{background:var(--accent-ink)}.pr__card.pop .small{color:color-mix(in srgb,var(--accent-ink) 82%,transparent)}
.pr__badge{position:absolute;top:0;right:var(--space-5);transform:translateY(-50%);background:var(--accent-ink);color:var(--accent);font-size:.7rem;text-transform:uppercase;letter-spacing:.06em;padding:.3rem .7rem;border-radius:999px}
.pr__tier{font-family:var(--fd);font-weight:700}.pr__price{display:flex;align-items:baseline;gap:.4rem}
.pr__amt{font-family:var(--fd);font-weight:800;letter-spacing:-.03em;font-size:clamp(2rem,4vw,2.8rem)}
.pr__feats{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:var(--space-2);flex:1}
.pr__feats li{padding-left:1.5rem;position:relative;color:var(--ink-soft)}.pr__feats li::before{content:"";position:absolute;left:0;top:.55em;width:8px;height:8px;border-radius:50%;background:var(--accent)}
.pr__cta{margin-top:var(--space-3)}.pr__card.pop .pr__cta{background:var(--accent-ink);color:var(--accent);border-color:transparent}
/* faq */
.faq__h,.faq__list{max-width:760px;margin-inline:auto}.faq__h{margin-bottom:var(--space-6);text-align:center}
.faq__item{border-bottom:1px solid var(--border)}
.faq__q{display:flex;align-items:center;justify-content:space-between;gap:var(--space-4);cursor:pointer;list-style:none;padding:var(--space-4) 0;font-family:var(--fd);font-weight:700;font-size:clamp(1.05rem,2vw,1.3rem);min-height:44px}
.faq__q::-webkit-details-marker{display:none}
.faq__ic{flex:none;color:var(--accent);font-size:1.4rem;transition:transform .2s}.faq__item[open] .faq__ic{transform:rotate(45deg)}
.faq__a{padding-bottom:var(--space-4);overflow:hidden}.faq__a .muted{margin:0}
/* gallery = horizontal rail of large cards */
.gl__head{display:flex;align-items:center;justify-content:space-between;gap:var(--space-4);margin-bottom:var(--space-6)}
.gl__head h2{font-size:clamp(1.8rem,4vw,2.8rem)}
/* prev/next arrows replace the old "drag →" hint — click to scroll one card (drag still works too) */
.gl__nav{display:flex;gap:var(--space-3);flex:none}
.gl__arrow{width:46px;height:46px;display:inline-flex;align-items:center;justify-content:center;border:1px solid var(--border);border-radius:var(--r-pill);background:transparent;color:var(--ink);cursor:pointer;font-size:1.2rem;line-height:1;transition:border-color .15s,background .15s,color .15s}
.gl__arrow:hover:not(:disabled){border-color:var(--accent);color:var(--accent)}
.gl__arrow:disabled{opacity:.32;cursor:default}
.gl__rail{--rail-card:clamp(300px,80vw,440px);--rail-gap:var(--space-5)}   /* geometry from canonical .rail */
.gl__card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;display:flex;flex-direction:column;transition:border-color .18s,transform .18s}
.gl__card:hover{border-color:var(--accent);transform:translateY(-4px)}
.gl__media{aspect-ratio:4/3;border-radius:0;border:0;border-bottom:1px solid var(--border)}
.gl__body{padding:var(--space-5);display:flex;flex-direction:column;gap:var(--space-2)}
.gl__top{display:flex;align-items:center;justify-content:space-between;gap:var(--space-3)}
.gl__tag{color:var(--accent);border:1px solid var(--accent);border-radius:999px;padding:.15rem .55rem;font-size:.7rem;text-transform:uppercase;letter-spacing:.06em}
.gl__title{font-family:var(--fd);font-weight:700;font-size:1.3rem}
.gl__desc{font-size:1rem;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
/* index tiles (real image + scrim) */
.ix__grid{display:grid;gap:var(--space-4);grid-template-columns:1fr}@media(min-width:560px){.ix__grid{grid-template-columns:repeat(2,1fr)}}@media(min-width:960px){.ix__grid{grid-template-columns:repeat(4,1fr)}}
.ix__tile{position:relative;border-radius:var(--radius);overflow:hidden;background:#090C16;aspect-ratio:3/4;display:flex}
.ix__media{position:absolute;inset:0;border:0;border-radius:0;aspect-ratio:auto}
.ix__tile::after{content:"";position:absolute;inset:0;background:linear-gradient(to top,rgba(5,7,14,.92),rgba(5,7,14,.1) 62%);z-index:1}
.ix__body{position:relative;z-index:2;margin-top:auto;padding:var(--space-5);color:#ECEDFF}
.ix__n{display:block;font-size:1.6rem;font-weight:700;opacity:.85;margin-bottom:var(--space-2);color:#ECEDFF}
.ix__title{color:#ECEDFF}.ix__cap{color:rgba(236,237,255,.8)}
/* narrative = ordered full-bleed story */
.nr__h{font-size:clamp(1.6rem,4vw,2.6rem);margin-bottom:clamp(1.5rem,4vw,2.5rem)}
.nr__rows{list-style:none;margin:0;padding:0;display:flex;flex-direction:column}
.nr__step{border-top:1px solid var(--border)}
.nr__inner{display:grid;grid-template-columns:1fr;gap:var(--space-6);align-items:center;padding-block:clamp(2rem,5vw,4rem)}
@media(min-width:900px){.nr__inner{grid-template-columns:1fr 1fr;gap:clamp(2rem,6vw,5rem)}.nr__step.alt .nr__text{order:2}.nr__step.alt .nr__media{order:1}}
.nr__title{font-size:clamp(1.5rem,3vw,2.2rem);max-width:16ch}.nr__text .lead{max-width:42ch;margin-top:var(--space-3)}.nr__text .small{margin-top:var(--space-3)}
.nr__media{aspect-ratio:5/4;border-radius:var(--radius);border:1px solid var(--border)}
@media(max-width:767px){.hero__wm,.ft__wm{font-size:clamp(4rem,26vw,7rem)}}
`
};
/* small helper so contact can echo the brand wordmark from the plan */
function ctx_brand(c){ return c.brand || 'ONMARK'; }
