# Dot Matrix — layout map

The order below is what `index.html` actually ships, read off the DOM. It is the layout reference:
it shows which device this template uses for each narrative beat, at what ground and what width.

**It is not a section plan.** Compose the page from the brief using `NARRATIVE.md`, then reach into
this table for the device this template uses to carry each beat you decided to keep.

| # | section | narrative beat | classes | ground | width |
|---|---|---|---|---|---|
| 01 | `hero` | promise | `.hero` | — | default |
| 02 | `statement` | tension | `.bs` | — | default |
| 03 | `logos` | proof-scale | `.lg` | — | full |
| 04 | `steps` | mechanism | `.st` | — | default |
| 05 | `feature` | mechanism | `.lx` | — | default |
| 06 | `gallery` | capability | `.gl` | — | default |
| 07 | `index` | fit | `.ix` | — | default |
| 08 | `narrative` | tension | `.nr` | — | default |
| 09 | `testimonial` | proof-people | `.tm` | — | default |
| 10 | `statement` | tension | `.section` only | — | default |
| 11 | `pricing` | offer | `.pr` | — | default |
| 12 | `faq` | objections | `.faq` | — | default |
| 13 | `stats` | proof-data | `.stats` | — | default |
| 14 | `cta` | close | `.cta` | — | default |

## Beats this reference demonstrates

`promise` · `tension` · `proof-scale` · `mechanism` · `capability` · `fit` · `proof-people` · `offer` · `objections` · `proof-data` · `close`

## Beats with no device in this reference

`proof-cases` · `conversion`

When the brief needs one of these, build it from the general primitives (`.container`, `.section`,
`.sec-head`, `.prose`, `.media`, `.btn`) plus local CSS in `style[data-brand-theme]`. Do not
import a device from another template's stylesheet — it will not carry this template's identity.

## Credentials live inside the hero

The one beat with no section of its own. `credentials` — compliance marks, guarantees, certifications
— belongs in the hero's own trust line, immediately under the opening claim, because the first claim
is the first thing doubted. Every hero in this set has a meta/badge slot for exactly this; use it
rather than adding a separate trust section below the fold.

## Trust is layered, not stacked

The one ordering rule this template inherits from the narrative contract: proof arrives in more than
one form, and each form lands immediately after a moment that asks the reader to invest attention —
credentials in the hero's own trust line, scale right under the opening claim, numbers after the
capability argument, a named person before the price, cases before the close. Collapsing all proof
into one testimonial block leaves the rest of the page unsupported.
