#!/usr/bin/env node
/* fix-contrast.mjs — propose a colour for every contrast pair this page fails, per theme.
 *
 *   node tools/fix-contrast.mjs            # measure index.html, print candidates
 *   node tools/fix-contrast.mjs --json     # same, as JSON
 *
 * It prints candidates. It does not edit the stylesheet, and it should not: every colour it computes
 * is solved against the palette in front of it, and a template exists to be re-skinned. An earlier
 * version appended its results to `template.css` as `!important` rules, so eleven templates shipped
 * with colours baked for their own reference palette — wrong for every site generated from them, and
 * unbeatable because of the `!important`. One run spent eight minutes discovering why its own colour
 * would not take effect.
 *
 * Apply the candidates yourself, in the palette surface, where they belong to the page you are
 * writing. If the reference page itself fails, fix it in the template's own CSS as a design change —
 * that is a real defect, not something to paper over with a generated block.
 *
 * The eleven v1 palettes predate any contrast measurement, and the failures they carry are of three
 * mechanical kinds, none of which `tools/palette.mjs` can produce:
 *
 *   1. a decorative `opacity` stacked on a token that was already solved to 4.5:1 — the token is
 *      fine, the dimming is what breaks it (`.fx__ixn{opacity:.5}`, and the inline `opacity:.7`
 *      that shipped on the stock-photo credit line);
 *   2. a support colour used as body or label text, having only ever been checked as a fill
 *      (`.ft__h{color:var(--support-2)}`);
 *   3. an on-accent ink that clears in light and fails in dark, because the two themes were never
 *      solved separately (`.pr__badge` at 2.24:1 on the dark accent).
 *
 * So this does not hand-pick replacements. It reads the pair as rendered — foreground composited
 * with every inherited opacity, ground composited up the ancestor chain — and walks lightness in
 * OKLCH, keeping hue and as much chroma as the ground allows, until the pair clears its floor. The
 * result is the nearest colour to the designer's intent that a reader can actually read.
 *
 * Overrides land in a marked block at the end of `template.css` and are rewritten, not appended to,
 * on every run. Re-run after any palette change.
 */

import { existsSync } from 'fs';
import { dirname, join, resolve } from 'path';
import { fileURLToPath } from 'url';
import puppeteer from 'puppeteer-core';
import { READ, RECHECK } from '../checks/gates.mjs';
import { settle, settleStyles, confirmContrast } from '../checks/settle.mjs';
import { hexToOklch, oklchToHex, maxChroma, contrast } from './color.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const asJson = process.argv.includes('--json');
const page = resolve(process.argv.find((a) => a.endsWith('.html')) || 'index.html');
const dir = dirname(page);
const CHROME = process.env.CHROME_PATH
  || ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome'].find(existsSync);
if (!existsSync(page) || !CHROME) { console.error('fix-contrast: need index.html and a Chromium'); process.exit(2); }


/** Walk lightness until the pair clears, keeping hue and as much chroma as fits.
 *
 * Which way to walk cannot be read off the ground's OKLCH lightness. OKLCH L is perceptual and WCAG
 * contrast is photometric, and around mid-tone they disagree: `#0C7C6C` has L .52 — "light" by that
 * test — while its relative luminance is .18, as dark a ground as most navy. Walking light text
 * darker onto it never reaches 4.5, and the pair is reported unsolvable.
 *
 * So walk both ways and keep whichever solution moves the colour least. That is also the better
 * answer on a genuinely mid-tone ground, where both directions clear and only one stays near the
 * designer's intent. */
function solve(fgHex, pairs) {
  const [fl, C, h] = hexToOklch(fgHex);
  // One override serves every instance of the selector, so it has to clear the worst floor on every
  // ground the selector lands on. `.cg__meta` sits on a dark card and a light one; solving only the
  // darker instance produced a colour that read 3.5:1 back on the light card.
  const clears = (hex) => pairs.every((p) => contrast(hex, p.ground) >= p.need + 0.08);
  let best = null;
  for (const dir of [+1, -1]) {
    for (let L = fl; L >= 0 && L <= 1; L += dir * 0.004) {
      const hex = oklchToHex(L, Math.min(C, maxChroma(L, h) * 0.92), h);
      if (clears(hex)) {
        const moved = Math.abs(L - fl);
        if (!best || moved < best.moved) best = { hex, moved };
        break;
      }
    }
  }
  return best?.hex || null;
}

async function read() {
  const browser = await puppeteer.launch({ executablePath: CHROME, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  try {
    const p = await browser.newPage();
    await p.setViewport({ width: 1440, height: 900 });
    await p.goto(`file://${page}`, { waitUntil: 'load', timeout: 90000 });
    await settle(p);
    const light = await p.evaluate(READ);
    await confirmContrast(p, light, RECHECK);
    await p.evaluate(() => document.documentElement.setAttribute('data-theme', 'dark'));
    await settleStyles(p);
    await p.evaluate(() => window.scrollTo(0, 0));
    const dark = await p.evaluate(READ);
    await confirmContrast(p, dark, RECHECK);
    return { light, dark };
  } finally { await browser.close(); }
}


const { light, dark } = await read();

/** One rule per distinct selector per theme, solved against every ground that selector was seen on. */
function rulesFor(reading) {
  const inventory = reading?.contrast?.groundsBySel || {};
  const bySelector = new Map();
  for (const c of reading?.contrast?.confirmed || []) {
    if (!c.fg || !c.ground) continue;
    const seen = bySelector.get(c.sel) || { worst: c, pairs: inventory[c.sel] || [{ ground: c.ground, need: c.need }] };
    if (c.got < seen.worst.got) seen.worst = c;
    bySelector.set(c.sel, seen);
  }
  return [...bySelector.values()].map(({ worst, pairs }) => {
    const solved = solve(worst.fg, pairs);
    return {
      ...worst, solved, grounds: pairs.length,
      after: solved ? +Math.min(...pairs.map((p) => contrast(solved, p.ground))).toFixed(2) : 0,
    };
  }).filter((r) => r.solved && r.after >= r.need);
}

const lightRules = rulesFor(light);
const darkRules = rulesFor(dark);

const candidates = [
  ...lightRules.map((r) => ({ theme: 'light', ...r })),
  ...darkRules.map((r) => ({ theme: 'dark', ...r })),
].map((r) => ({
  theme: r.theme,
  selector: r.sel,
  text: r.text,
  from: r.fg,
  ground: r.grounds > 1 ? `${r.grounds} grounds` : r.ground,
  measured: r.got,
  candidate: r.solved,
  reaches: r.after,
  needs: r.need,
  // A dimmed token is not a colour problem: the token was solved, the decoration undid it. Say so,
  // because the fix is to drop the opacity, not to darken the colour a second time.
  note: r.alpha < 1 ? `inherited opacity ${r.alpha} — folding it into the colour, or dropping it, both work` : null,
}));

if (asJson) {
  console.log(JSON.stringify(candidates, null, 2));
  process.exit(0);
}

if (!candidates.length) {
  console.log('no contrast failures on this page');
  process.exit(0);
}

console.log(`\n${candidates.length} pair(s) below the floor. Candidates — apply them yourself, in the`);
console.log('palette surface of the page you are writing. Nothing has been changed on disk.\n');
for (const c of candidates) {
  console.log(`  ${c.theme.padEnd(5)} ${c.selector}`);
  console.log(`        "${(c.text || '').slice(0, 40)}"`);
  console.log(`        ${c.from} on ${c.ground} measures ${c.measured}:1, needs ${c.needs}:1`);
  console.log(`        try ${c.candidate} — reaches ${c.reaches}:1`);
  if (c.note) console.log(`        ${c.note}`);
  console.log('');
}
