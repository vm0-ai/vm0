#!/usr/bin/env node
/* generate-images.mjs — start every page image through one measured, resumable path.
 *
 *   node tools/generate-images.mjs image-jobs.json
 *   node tools/generate-images.mjs image-jobs.json --model seedream4 --concurrency 3
 *
 * Manifest:
 *   [
 *     {
 *       "id": "hero",
 *       "output": "assets/hero.png",
 *       "size": "1440x900",
 *       "prompt": "subject, setting, light, mood"
 *     }
 *   ]
 *
 * Why this exists: eleven measured website runs each rebuilt the same shell around `okou generate
 * image`. The direct CLI returns a CDN URL, not a local file; invalid Seedream sizes and formats
 * were rediscovered in six runs; and a fourth concurrent call is rejected with HTTP 429. This
 * wrapper normalises the request, keeps at most three calls in flight, retries only 429s, downloads
 * each billed result atomically, and records the raster's actual size for data-generation-size.
 */

import { spawn } from "node:child_process";
import {
  mkdir,
  readFile,
  rename,
  stat,
  unlink,
  writeFile,
} from "node:fs/promises";
import { dirname, extname, isAbsolute, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export const DEFAULT_CONCURRENCY = 3;
export const MAX_CONCURRENCY = 3;
export const MIN_PIXELS = 655_360;
export const MAX_PIXELS = 8_294_400;
export const MAX_EDGE = 3_840;
export const MAX_RATIO = 3;

const ROUNDING = 16;
const DEFAULT_RETRIES = 4;
const DEFAULT_RETRY_MS = 30_000;
const URL_KEYS = new Set([
  "url",
  "href",
  "image_url",
  "imageUrl",
  "file_url",
  "fileUrl",
  "output_url",
  "outputUrl",
]);

const sleep = (ms) => new Promise((done) => setTimeout(done, ms));
const roundUp = (n, step = ROUNDING) => Math.ceil(n / step) * step;
const roundDown = (n, step = ROUNDING) => Math.floor(n / step) * step;

/**
 * Seedream accepts custom sizes only when both edges are multiples of 16, neither edge exceeds
 * 3840px, the ratio is at most 3:1, and the total is within the measured provider pixel range.
 * Preserve the requested ratio as closely as possible and grow an undersized request rather than
 * cropping it.
 */
export function normalizeSize(value) {
  const match = /^(\d+)x(\d+)$/i.exec(String(value).trim());
  if (!match) throw new Error(`size must be WIDTHxHEIGHT, got "${value}"`);

  let width = Number(match[1]);
  let height = Number(match[2]);
  if (
    !Number.isSafeInteger(width) ||
    !Number.isSafeInteger(height) ||
    width <= 0 ||
    height <= 0
  ) {
    throw new Error(`size must contain two positive integers, got "${value}"`);
  }

  const requested = { width, height };
  const long = Math.max(width, height);
  const short = Math.min(width, height);
  if (long / short > MAX_RATIO) {
    if (width > height) height = Math.ceil(width / MAX_RATIO);
    else width = Math.ceil(height / MAX_RATIO);
  }

  if (Math.max(width, height) > MAX_EDGE) {
    const scale = MAX_EDGE / Math.max(width, height);
    width *= scale;
    height *= scale;
  }

  if (width * height < MIN_PIXELS) {
    const scale = Math.sqrt(MIN_PIXELS / (width * height));
    width *= scale;
    height *= scale;
  } else if (width * height > MAX_PIXELS) {
    const scale = Math.sqrt(MAX_PIXELS / (width * height));
    width *= scale;
    height *= scale;
  }

  width = roundUp(width);
  height = roundUp(height);

  if (width > MAX_EDGE || height > MAX_EDGE) {
    const scale = MAX_EDGE / Math.max(width, height);
    width = Math.max(ROUNDING, roundDown(width * scale));
    height = Math.max(ROUNDING, roundDown(height * scale));
  }

  while (width * height > MAX_PIXELS) {
    if (width >= height) width -= ROUNDING;
    else height -= ROUNDING;
  }

  if (width * height < MIN_PIXELS) {
    if (width >= height) width += ROUNDING;
    else height += ROUNDING;
  }

  return {
    requested: `${requested.width}x${requested.height}`,
    normalized: `${width}x${height}`,
    width,
    height,
    changed: width !== requested.width || height !== requested.height,
  };
}

function collectUrls(value, key = "", out = []) {
  if (typeof value === "string" && /^https?:\/\//i.test(value)) {
    out.push({ url: value, preferred: URL_KEYS.has(key) });
  } else if (Array.isArray(value)) {
    for (const item of value) collectUrls(item, key, out);
  } else if (value && typeof value === "object") {
    for (const [childKey, child] of Object.entries(value))
      collectUrls(child, childKey, out);
  }
  return out;
}

/** Find the generated file URL without depending on one CLI response nesting shape. */
export function extractImageUrl(value) {
  const urls = collectUrls(value);
  if (!urls.length) return null;
  return (
    urls.find(({ url, preferred }) => preferred && /\/f\//.test(url)) ??
    urls.find(({ preferred }) => preferred) ??
    urls.find(({ url }) => /\/f\//.test(url)) ??
    urls[0]
  ).url;
}

export function parseGenerationJson(stdout) {
  const text = String(stdout).trim();
  const candidates = [text];
  const first = text.indexOf("{");
  const last = text.lastIndexOf("}");
  if (first >= 0 && last > first) candidates.push(text.slice(first, last + 1));
  for (const candidate of candidates) {
    try {
      return JSON.parse(candidate);
    } catch {
      // Try the next candidate; the final error below carries the useful context.
    }
  }
  throw new Error(`image generator did not return JSON: ${text.slice(0, 240)}`);
}

function pngDimensions(buffer) {
  if (buffer.length < 24 || buffer.toString("hex", 0, 8) !== "89504e470d0a1a0a")
    return null;
  return { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
}

function jpegDimensions(buffer) {
  if (buffer.length < 4 || buffer[0] !== 0xff || buffer[1] !== 0xd8)
    return null;
  let offset = 2;
  while (offset + 9 < buffer.length) {
    if (buffer[offset] !== 0xff) {
      offset += 1;
      continue;
    }
    const marker = buffer[offset + 1];
    if (marker === 0xd8 || marker === 0xd9) {
      offset += 2;
      continue;
    }
    const length = buffer.readUInt16BE(offset + 2);
    if (length < 2) return null;
    if (marker >= 0xc0 && marker <= 0xc3) {
      return {
        width: buffer.readUInt16BE(offset + 7),
        height: buffer.readUInt16BE(offset + 5),
      };
    }
    offset += length + 2;
  }
  return null;
}

function webpDimensions(buffer) {
  if (
    buffer.length < 30 ||
    buffer.toString("ascii", 0, 4) !== "RIFF" ||
    buffer.toString("ascii", 8, 12) !== "WEBP"
  ) {
    return null;
  }
  const kind = buffer.toString("ascii", 12, 16);
  if (kind === "VP8X") {
    return {
      width: 1 + buffer.readUIntLE(24, 3),
      height: 1 + buffer.readUIntLE(27, 3),
    };
  }
  if (kind === "VP8L" && buffer.length >= 25) {
    const bits = buffer.readUInt32LE(21);
    return {
      width: 1 + (bits & 0x3fff),
      height: 1 + ((bits >> 14) & 0x3fff),
    };
  }
  return null;
}

export function readImageDimensions(buffer) {
  return (
    pngDimensions(buffer) ?? jpegDimensions(buffer) ?? webpDimensions(buffer)
  );
}

function runProcess(command, args) {
  return new Promise((done, fail) => {
    const child = spawn(command, args, { stdio: ["ignore", "pipe", "pipe"] });
    const stdout = [];
    const stderr = [];
    child.stdout.on("data", (chunk) => stdout.push(chunk));
    child.stderr.on("data", (chunk) => stderr.push(chunk));
    child.on("error", fail);
    child.on("close", (code) => {
      const result = {
        code: code ?? 1,
        stdout: Buffer.concat(stdout).toString("utf8"),
        stderr: Buffer.concat(stderr).toString("utf8"),
      };
      if (result.code === 0) done(result);
      else {
        const error = new Error(
          `okou generate image exited ${result.code}: ${(result.stderr || result.stdout).trim().slice(0, 500)}`,
        );
        Object.assign(error, result);
        fail(error);
      }
    });
  });
}

/** Resolve the Okou CLI exactly as this workspace exposes it, while keeping a test/local override. */
export function resolveOkouCommand(env = process.env) {
  if (env.OKOU_BIN) return { command: env.OKOU_BIN, prefix: [] };
  if (env.CLI_PKG_URL) {
    return {
      command: "npx",
      prefix: ["--yes", `--package=${env.CLI_PKG_URL}`, "okou"],
    };
  }
  throw new Error(
    "CLI_PKG_URL is missing; set it to the Okou CLI package URL, or set OKOU_BIN to an installed executable",
  );
}

async function generateUrl(job, options) {
  const args = [
    "generate",
    "image",
    "--provider",
    "built-in",
    "--model",
    options.model,
    "--json",
    "--raw-prompt",
    job.prompt,
    "--size",
    job.size.normalized,
    "--format",
    "png",
  ];

  for (let attempt = 0; attempt <= options.retries; attempt += 1) {
    try {
      const result = await runProcess(options.okou.command, [
        ...options.okou.prefix,
        ...args,
      ]);
      const payload = parseGenerationJson(result.stdout);
      const url = extractImageUrl(payload);
      if (!url)
        throw new Error("image generator JSON contains no downloadable URL");
      return { url, payload, attempts: attempt + 1 };
    } catch (error) {
      const response = `${error.stderr ?? ""}\n${error.stdout ?? ""}\n${error.message}`;
      const rateLimited = /(?:\b429\b|too many requests|rate.?limit)/i.test(
        response,
      );
      if (!rateLimited || attempt >= options.retries) throw error;
      console.error(
        `[${job.id}] shared image limit returned 429; retry ${attempt + 1}/${options.retries} in ${Math.round(options.retryMs / 1000)}s`,
      );
      await sleep(options.retryMs);
    }
  }
  throw new Error("unreachable image retry state");
}

async function download(url, output, options) {
  const partial = `${output}.part-${process.pid}`;
  await mkdir(dirname(output), { recursive: true });
  try {
    for (let attempt = 0; attempt <= options.retries; attempt += 1) {
      const response = await fetch(url);
      if (response.ok) {
        const buffer = Buffer.from(await response.arrayBuffer());
        const dimensions = readImageDimensions(buffer);
        if (!dimensions)
          throw new Error(
            `downloaded result is not a supported raster image: ${url}`,
          );
        await writeFile(partial, buffer);
        await rename(partial, output);
        return { bytes: buffer.length, ...dimensions };
      }
      if (
        (response.status === 429 || response.status >= 500) &&
        attempt < options.retries
      ) {
        await sleep(options.retryMs);
        continue;
      }
      throw new Error(`image download failed HTTP ${response.status}: ${url}`);
    }
  } finally {
    await unlink(partial).catch(() => {});
  }
  throw new Error("unreachable download retry state");
}

async function existingDimensions(output) {
  try {
    const info = await stat(output);
    if (!info.isFile() || info.size === 0) return null;
    const dimensions = readImageDimensions(await readFile(output));
    return dimensions ? { bytes: info.size, ...dimensions } : null;
  } catch (error) {
    if (error.code === "ENOENT") return null;
    throw error;
  }
}

function safeOutput(value, cwd) {
  if (!value || isAbsolute(value))
    throw new Error(`output must be a relative .png path: ${value}`);
  const output = resolve(cwd, value);
  const rel = relative(cwd, output);
  if (rel.startsWith("..") || isAbsolute(rel)) {
    throw new Error(`output escapes the site directory: ${value}`);
  }
  if (extname(output).toLowerCase() !== ".png") {
    throw new Error(
      `output must end in .png; Seedream's reliable output format is png: ${value}`,
    );
  }
  return { output, relativeOutput: rel };
}

export function validateJobs(value, cwd = process.cwd()) {
  const list = Array.isArray(value) ? value : value?.images;
  if (!Array.isArray(list) || !list.length) {
    throw new Error(
      "image manifest must be a non-empty array, or an object with an images array",
    );
  }
  const ids = new Set();
  const outputs = new Set();
  return list.map((raw, index) => {
    if (!raw || typeof raw !== "object")
      throw new Error(`job ${index + 1} must be an object`);
    const id = String(raw.id ?? `image-${index + 1}`);
    if (ids.has(id)) throw new Error(`duplicate image id: ${id}`);
    ids.add(id);
    const prompt = String(raw.prompt ?? "").trim();
    if (!prompt) throw new Error(`${id}: prompt is required`);
    const path = safeOutput(String(raw.output ?? ""), cwd);
    if (outputs.has(path.output))
      throw new Error(`duplicate image output: ${path.relativeOutput}`);
    outputs.add(path.output);
    return {
      id,
      prompt,
      ...path,
      size: normalizeSize(raw.size ?? "1024x1024"),
    };
  });
}

async function mapLimit(items, limit, fn) {
  const results = Array(items.length);
  let cursor = 0;
  const workers = Array.from(
    { length: Math.min(limit, items.length) },
    async () => {
      while (cursor < items.length) {
        const index = cursor;
        cursor += 1;
        results[index] = await fn(items[index], index);
      }
    },
  );
  await Promise.all(workers);
  return results;
}

async function runJob(job, index, total, options) {
  const prefix = `[${index + 1}/${total} ${job.id}]`;
  if (!options.force) {
    const found = await existingDimensions(job.output);
    if (found) {
      const actualSize = `${found.width}x${found.height}`;
      console.log(`${prefix} reuse ${job.relativeOutput} · ${actualSize}`);
      return {
        id: job.id,
        status: "reused",
        output: job.relativeOutput,
        requestedSize: job.size.requested,
        normalizedSize: job.size.normalized,
        dataGenerationSize: actualSize,
        bytes: found.bytes,
        attempts: 0,
      };
    }
  }

  console.log(
    `${prefix} generate ${job.relativeOutput} · ${job.size.requested}${job.size.changed ? ` -> ${job.size.normalized}` : ""}`,
  );
  const generated = await generateUrl(job, options);
  const file = await download(generated.url, job.output, options);
  const actualSize = `${file.width}x${file.height}`;
  console.log(
    `${prefix} saved ${job.relativeOutput} · data-generation-size="${actualSize}"`,
  );
  return {
    id: job.id,
    status: "generated",
    output: job.relativeOutput,
    requestedSize: job.size.requested,
    normalizedSize: job.size.normalized,
    dataGenerationSize: actualSize,
    bytes: file.bytes,
    attempts: generated.attempts,
  };
}

function argsOf(argv) {
  const value = (name, fallback) => {
    const index = argv.indexOf(name);
    return index >= 0 ? (argv[index + 1] ?? true) : fallback;
  };
  const manifest = argv.find((arg) => !arg.startsWith("--"));
  const concurrency = Number(value("--concurrency", DEFAULT_CONCURRENCY));
  if (
    !Number.isInteger(concurrency) ||
    concurrency < 1 ||
    concurrency > MAX_CONCURRENCY
  ) {
    throw new Error(
      `--concurrency must be 1-${MAX_CONCURRENCY}; built-in generations share a three-slot per-run limit`,
    );
  }
  const retries = Number(value("--retries", DEFAULT_RETRIES));
  if (!Number.isInteger(retries) || retries < 0 || retries > 10) {
    throw new Error("--retries must be an integer from 0 to 10");
  }
  return {
    manifest,
    model: String(value("--model", "seedream4")),
    concurrency,
    retries,
    retryMs: Number(value("--retry-ms", DEFAULT_RETRY_MS)),
    report: String(value("--report", "image-generation.json")),
    force: argv.includes("--force"),
    dryRun: argv.includes("--dry-run"),
    okou: null,
  };
}

export async function main(argv = process.argv.slice(2)) {
  const options = argsOf(argv);
  if (!options.manifest || argv.includes("--help") || argv.includes("-h")) {
    console.log(
      "usage: node tools/generate-images.mjs <image-jobs.json> [--model seedream4] [--concurrency 1|2|3] [--force] [--dry-run]",
    );
    return options.manifest ? 0 : 2;
  }
  if (!Number.isFinite(options.retryMs) || options.retryMs < 0) {
    throw new Error("--retry-ms must be a non-negative number");
  }

  const cwd = process.cwd();
  const manifest = JSON.parse(
    await readFile(resolve(cwd, options.manifest), "utf8"),
  );
  const jobs = validateJobs(manifest, cwd);
  if (options.dryRun) {
    console.log(
      JSON.stringify(
        jobs.map((job) => ({
          id: job.id,
          output: job.relativeOutput,
          requestedSize: job.size.requested,
          normalizedSize: job.size.normalized,
        })),
        null,
        2,
      ),
    );
    return 0;
  }

  options.okou = resolveOkouCommand();

  const startedAt = Date.now();
  const results = await mapLimit(
    jobs,
    options.concurrency,
    async (job, index) => {
      try {
        return await runJob(job, index, jobs.length, options);
      } catch (error) {
        console.error(
          `[${index + 1}/${jobs.length} ${job.id}] FAILED ${error.message}`,
        );
        return {
          id: job.id,
          status: "failed",
          output: job.relativeOutput,
          requestedSize: job.size.requested,
          normalizedSize: job.size.normalized,
          error: error.message,
        };
      }
    },
  );
  const report = {
    model: options.model,
    concurrency: options.concurrency,
    startedAt,
    finishedAt: Date.now(),
    results,
  };
  await writeFile(
    resolve(cwd, options.report),
    `${JSON.stringify(report, null, 2)}\n`,
  );
  const failed = results.filter((result) => result.status === "failed");
  console.log(
    `${results.length - failed.length}/${results.length} images ready · actual sizes in ${options.report}`,
  );
  return failed.length ? 1 : 0;
}

if (fileURLToPath(import.meta.url) === resolve(process.argv[1] ?? "")) {
  main()
    .then((code) => {
      process.exitCode = code;
    })
    .catch((error) => {
      console.error(`generate-images: ${error.message}`);
      process.exitCode = 1;
    });
}
