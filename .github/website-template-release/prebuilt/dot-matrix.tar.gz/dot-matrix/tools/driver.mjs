/* driver.mjs — hand back a working `puppeteer-core`, installing it if this package does not have one.
 *
 * The package deliberately does not vendor the driver: it is 300KB of dependency that most readers
 * of this repo never run. But leaving the install to the caller was worse than it looked. Measured
 * across eleven runs, "install puppeteer" itself was only 3.3 minutes; the detour around it was ten
 * more. Every run installed it somewhere, discovered that `checks/verify.mjs` could not resolve it —
 * ESM does not honour `NODE_PATH`, which is the trap, because the same install works fine for a
 * `require` — and then went hunting: symlink `node_modules` into the package, re-export it, set
 * `NODE_PATH` again, try `--experimental-*`. One run wrote "the reference calibration failed because
 * ESM imports don't honor NODE_PATH. Simpler: symlink node_modules".
 *
 * So install it where the importer will actually look: this package's own `node_modules`. Node
 * resolves a bare specifier by walking parent directories, so a driver at `<pkg>/node_modules`
 * serves `<pkg>/checks/*.mjs` and `<pkg>/tools/*.mjs` alike, and a driver that some ancestor already
 * provides is used as-is without installing anything.
 */

import { execFileSync } from "child_process";
import { createRequire } from "module";
import { dirname, join } from "path";
import { fileURLToPath, pathToFileURL } from "url";

const PKG = dirname(dirname(fileURLToPath(import.meta.url)));

/** @returns {Promise<import('puppeteer-core')>} the module's default export, ready to `.launch()`. */
export async function driver() {
  try {
    return (await import("puppeteer-core")).default;
  } catch (first) {
    if (first?.code !== "ERR_MODULE_NOT_FOUND") throw first;
    process.stderr.write(
      "driver: installing puppeteer-core into the package (one time)\n",
    );
    try {
      execFileSync(
        "npm",
        [
          "install",
          "--prefix",
          PKG,
          "--no-save",
          "--no-audit",
          "--no-fund",
          "--loglevel",
          "error",
          "puppeteer-core",
        ],
        { stdio: ["ignore", "ignore", "inherit"] },
      );
    } catch {
      console.error(
        "driver: could not install puppeteer-core — is the network reachable?",
      );
      process.exit(2);
    }
    // Import by resolved path, not by bare specifier — this process already failed to resolve that
    // one. Do not hand-write the entry file either: `lib/esm/puppeteer-core.js` was a good guess and
    // the installed 25.x puts it at `lib/puppeteer/puppeteer-core.js`. Ask the resolver.
    const require = createRequire(join(PKG, "package.json"));
    return (await import(pathToFileURL(require.resolve("puppeteer-core")).href))
      .default;
  }
}
