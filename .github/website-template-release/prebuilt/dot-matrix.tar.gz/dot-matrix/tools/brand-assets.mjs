#!/usr/bin/env node
/* brand-assets.mjs — produce the two files a shareable page needs but nobody remembers to make.
 *
 *   node tools/brand-assets.mjs                                  # read brand + palette from index.html
 *   node tools/brand-assets.mjs --brand "ATLAS" --title "..." --sub "..."
 *
 * Writes `favicon.svg` and `social-card.png` next to `index.html`, using the page's own resolved
 * `--accent`, `--bg`, `--ink` and display face — so re-running after a palette change regenerates
 * assets that still match. `social_preview_declared` fails on a declared-but-404 og:image, which is
 * the state every converted page starts in.
 *
 * Needs a Chromium (CHROME_PATH, or /usr/bin/chromium) for the PNG. The favicon is pure SVG and is
 * written even when no browser is available.
 */

import { readFileSync, writeFileSync, existsSync } from 'fs';
import { resolve, dirname, join } from 'path';

import { driver } from './driver.mjs';

const argv = process.argv.slice(2);
const flag = (n, d) => { const i = argv.indexOf(n); return i >= 0 ? argv[i + 1] : d; };
const page = resolve(flag('--page', 'index.html'));
const dir = dirname(page);
if (!existsSync(page)) { console.error(`brand-assets.mjs: no ${page}`); process.exit(2); }

const CHROME = process.env.CHROME_PATH
  || ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome'].find(existsSync);

const html = readFileSync(page, 'utf8');
// Text pulled out of the page is already HTML-encoded; decode before re-encoding, or a brand with
// an ampersand ships as "Court &amp;amp; culture" on the card.
const dec = (s) => String(s).replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
  .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&nbsp;/g, ' ').replace(/&mdash;/g, '—');
const esc = (s) => dec(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

/* Read the palette off the page source: the brand-theme block wins, template.css is the fallback. */
function token(name) {
  const themed = /<style data-brand-theme>([\s\S]*?)<\/style>/.exec(html)?.[1] || '';
  const css = existsSync(join(dir, 'template.css')) ? readFileSync(join(dir, 'template.css'), 'utf8') : '';
  const find = (src) => {
    const root = [...src.matchAll(/:root\s*\{([\s\S]*?)\}/g)].map((m) => m[1]).reverse();
    for (const block of root) {
      const m = new RegExp(`${name}\\s*:\\s*([^;]+)`).exec(block);
      if (m) return m[1].trim();
    }
    return null;
  };
  return find(themed) || find(css);
}

const brand = flag('--brand',
  /<a[^>]*class="[^"]*nav__brand[^"]*"[^>]*>([\s\S]*?)<\/a>/.exec(html)?.[1].replace(/<[^>]+>/g, '').trim()
  || /<title>([^<|—-]+)/.exec(html)?.[1].trim() || 'Brand');
const title = flag('--title', /<h1[^>]*>([\s\S]*?)<\/h1>/.exec(html)?.[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() || brand);
const sub = flag('--sub', /<meta property="og:description" content="([^"]*)"/.exec(html)?.[1]
  || /<meta name="description" content="([^"]*)"/.exec(html)?.[1] || '');

const accent = token('--accent') || '#111111';
const bg = token('--bg') || '#FFFFFF';
const ink = token('--ink') || '#111111';
const accentInk = token('--accent-ink') || '#FFFFFF';
const display = (token('--fd') || 'system-ui').replace(/['"]/g, '');
const mark = brand.trim()[0]?.toUpperCase() || 'B';

/* ── favicon: the brand initial on the accent, at the template's own radius ── */
const radius = parseFloat(token('--radius') || '6') || 6;
const favicon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" role="img" aria-label="${esc(brand)}">
  <rect width="64" height="64" rx="${Math.min(32, Math.max(0, radius * 64 / 20)).toFixed(1)}" fill="${accent}"/>
  <text x="32" y="45" text-anchor="middle" font-family="${esc(display)}, system-ui, sans-serif"
        font-size="40" font-weight="700" fill="${accentInk}">${esc(mark)}</text>
</svg>
`;
writeFileSync(join(dir, 'favicon.svg'), favicon);
console.log(`favicon.svg    ${mark} on ${accent}`);

/* ── social card: 1200x630, the same type and palette as the page ─────────── */
const fontLink = /<link[^>]*fonts\.googleapis\.com[^>]*>/.exec(html)?.[0] || '';
const card = `<!doctype html><meta charset="utf-8">
${fontLink}
<style>
  *{margin:0;box-sizing:border-box}
  body{width:1200px;height:630px;background:${bg};color:${ink};
       font-family:${display}, system-ui, sans-serif; display:flex; flex-direction:column;
       justify-content:space-between; padding:76px 84px; overflow:hidden}
  .brand{display:flex;align-items:center;gap:18px;font-size:26px;font-weight:700;letter-spacing:.02em}
  .chip{width:44px;height:44px;border-radius:${radius}px;background:${accent};color:${accentInk};
        display:grid;place-items:center;font-size:26px;font-weight:800}
  h1{font-size:74px;line-height:1.03;letter-spacing:-.03em;font-weight:800;max-width:16ch}
  p{font-size:27px;line-height:1.4;color:${ink};opacity:.72;max-width:52ch}
  .rule{height:8px;width:132px;background:${accent};border-radius:99px}
</style>
<div class="brand"><span class="chip">${esc(mark)}</span>${esc(brand)}</div>
<div><div class="rule" style="margin-bottom:34px"></div><h1>${esc(title)}</h1></div>
<p>${esc(sub.slice(0, 150))}</p>`;

if (!CHROME) {
  console.error('social-card.png    skipped — no Chromium found (set CHROME_PATH). favicon.svg was still written.');
  process.exit(0);
}
const puppeteer = await driver();
const browser = await puppeteer.launch({ executablePath: CHROME, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
try {
  const p = await browser.newPage();
  await p.setViewport({ width: 1200, height: 630, deviceScaleFactor: 1 });
  await p.setContent(card, { waitUntil: 'networkidle0', timeout: 45000 });
  await p.evaluate(() => document.fonts.ready);
  await p.screenshot({ path: join(dir, 'social-card.png') });
  console.log(`social-card.png 1200x630 · ${dec(title).slice(0, 48)}`);
} finally { await browser.close(); }
