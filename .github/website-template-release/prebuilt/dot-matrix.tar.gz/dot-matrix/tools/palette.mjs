#!/usr/bin/env node
/* palette.mjs — pick a palette, print the CSS to paste.
 *
 *   node tools/palette.mjs --list                       # the catalogue, with when-to-use
 *   node tools/palette.mjs --pick sand                  # prints the CSS
 *   node tools/palette.mjs --pick sand --seed "#E4002B" # brand colour wins over the accent
 *   node tools/palette.mjs --check <6 hex values>       # audit a palette you wrote yourself
 *
 * A palette is SIX decisions per mode: bg · ink · accent · accent-ink · support-1 · support-2.
 * Everything else derives:
 *
 *   --surface   = 4%  ink into bg      raised card, just separated from the page
 *   --surface-2 = 8%  ink into bg      nested card
 *   --ink-soft  = 70% ink into bg      secondary text
 *   --border    = 13% ink into bg      hairline
 *   --ring      = the accent
 *   --support-1-ink = whichever of black / white clears best on support-1
 *
 * Mixing *toward the background* is what lets one formula serve light and dark alike: 4% ink into
 * white lifts a card slightly darker, 4% ink into near-black lifts it slightly lighter. The earlier
 * tool derived every role from the seed hue instead, and every background, border and text token
 * came out tinted at near-zero chroma — a grey design with a filter over it.
 *
 * The catalogue is fourteen curated palettes, each authored in one mode by a designer and given its
 * counterpart here — same hues, rebuilt lightness, never a flip, because carrying paper chroma onto
 * a dark ground is what makes generated dark themes muddy. `tools/palette.test.mjs` computes AA for
 * all twenty-eight modes; none of it is eyeballed.
 *
 * You are not required to use the catalogue. `--check` audits six values of your own against the
 * same rules, so a bespoke palette can be held to the same standard as a catalogue one.
 */

import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { hexToOklch, oklchToHex, maxChroma, contrast, bestInk } from './color.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const CAT = JSON.parse(readFileSync(join(here, 'color-systems.json'), 'utf8'));
export const CATALOGUE = CAT.systems;
export const DERIVATION = CAT.derivation;

/** The six declared roles, in the order they are emitted. */
export const DECLARED = ['bg', 'ink', 'accent', 'accentInk', 'support1', 'support2'];
const CSS_NAME = { bg: '--bg', ink: '--ink', accent: '--accent', accentInk: '--accent-ink', support1: '--support-1', support2: '--support-2' };

const hex = (s) => [1, 3, 5].map((i) => parseInt(s.slice(i, i + 2), 16));
/** The same mix the CSS does, so the audit measures what the browser will paint. */
export const mix = (a, b, t) => '#' + [0, 1, 2].map((i) =>
  Math.round(hex(a)[i] * t + hex(b)[i] * (1 - t)).toString(16).padStart(2, '0')).join('').toUpperCase();

export const derive = (r) => ({
  surface: mix(r.ink, r.bg, 0.04),
  surface2: mix(r.ink, r.bg, 0.08),
  inkSoft: mix(r.ink, r.bg, 0.70),
  border: mix(r.ink, r.bg, 0.13),
  ring: r.accent,
  support1Ink: bestInk(r.support1),
});

/** Walk lightness until the pair clears, keeping hue. Both directions; the nearer solution wins. */
export function solve(fg, ground, need) {
  const [fl, C, h] = hexToOklch(fg);
  let best = null;
  for (const dir of [+1, -1]) {
    for (let L = fl; L >= 0 && L <= 1; L += dir * 0.004) {
      const cand = oklchToHex(L, Math.min(C, maxChroma(L, h) * 0.92), h);
      if (contrast(cand, ground) >= need + 0.1) {
        const moved = Math.abs(L - fl);
        if (!best || moved < best.moved) best = { hex: cand, moved };
        break;
      }
    }
  }
  return best?.hex || null;
}

/* ── the deep band ────────────────────────────────────────────────────────
 * Six templates ship a full-bleed dark band. It is not one of the six declared roles because it is
 * not a mix of them: reusing the ink as a ground gives a flat near-black, and an accent that clears
 * 4.5:1 on paper routinely fails on it. So the band is built here and its own ink and accent are
 * solved against it. */
export function slabFor(r, mode) {
  const [, C, h] = hexToOklch(r.ink);
  const slab = mode === 'light'
    ? oklchToHex(0.235, Math.min(C * 0.8, maxChroma(0.235, h) * 0.9), h)
    : oklchToHex(0.145, Math.min(C * 0.8, maxChroma(0.145, h) * 0.9), h);
  // The band is dark in BOTH modes, so its ink is light in both. Mixing toward `--bg` is right
  // everywhere else and wrong here: in dark mode it walked the ink toward the near-black page and
  // produced 1.04:1. Take whichever of the palette's own two ends is light, then confirm.
  const pale = contrast('#FFFFFF', slab) >= contrast(r.ink, slab) ? '#FFFFFF' : r.ink;
  const slabInk = contrast(pale, slab) >= 7 ? mix(pale, slab, 0.94) : (solve(pale, slab, 7) || '#FFFFFF');
  return { slab, slabInk, slabAccent: solve(r.accent, slab, 4.5) || r.accent };
}

/* ── audit ────────────────────────────────────────────────────────────────
 * Every check is a measurement of a pair that actually appears on the page. A rule nothing can trip
 * is not a rule, so `palette.test.mjs` also feeds this a deliberately broken palette. */
export function audit(mode, r) {
  const d = derive(r);
  const s = slabFor(r, mode);
  const rows = [
    ['ink on bg', contrast(r.ink, r.bg), 4.5],
    ['ink-soft on bg', contrast(d.inkSoft, r.bg), 4.5],
    ['ink on surface', contrast(r.ink, d.surface), 4.5],
    ['ink-soft on surface', contrast(d.inkSoft, d.surface), 4.5],
    ['accent-ink on accent', contrast(r.accentInk, r.accent), 4.5],
    ['accent on bg', contrast(r.accent, r.bg), 3.0],
    ['support-1-ink on support-1', contrast(d.support1Ink, r.support1), 4.5],
    ['slab-ink on slab', contrast(s.slabInk, s.slab), 7.0],
    ['slab-accent on slab', contrast(s.slabAccent, s.slab), 4.5],
  ].map(([name, got, need]) => ({ mode, name, got: +got.toFixed(2), need, pass: got >= need }));
  // Separation is a difference, not a ratio: a card has to be visible against the page without
  // being a second ground. Direction is handled by mixing toward bg, so only the size is checked.
  const sep = Math.abs(contrast(d.surface, r.bg) - 1) * 100;
  rows.push({ mode, name: 'surface separates from bg', got: +sep.toFixed(1), need: 1.0, pass: sep >= 1.0 });
  return rows;
}

/* ── output ──────────────────────────────────────────────────────────────── */

function toCss(sys, light, dark, seed) {
  const block = (r) => DECLARED.map((k) => `  ${CSS_NAME[k]}: ${r[k]};`).join('\n')
    + `\n  --support-1-ink: ${derive(r).support1Ink};`;
  const band = (r, mode) => {
    const s = slabFor(r, mode);
    return `  --slab: ${s.slab};\n  --slab-ink: ${s.slabInk};\n  --slab-accent: ${s.slabAccent};`;
  };
  return `/* palette: ${sys.name}${seed ? ` · accent overridden with ${seed}` : ''}
   Six declared values per mode; support-1-ink is solved per mode and the remaining roles derive below.
   Generated by tools/palette.mjs — do not hand-edit the derived block. */
:root {
${block(light)}
${band(light, 'light')}
}
[data-theme="dark"] {
${block(dark)}
${band(dark, 'dark')}
}
:root, [data-theme="dark"] {
  --surface:   ${DERIVATION.surface};
  --surface-2: ${DERIVATION['surface-2']};
  --ink-soft:  ${DERIVATION['ink-soft']};
  --border:    ${DERIVATION.border};
  --ring:      ${DERIVATION.ring};
}`;
}

/** A brand colour replaces the accent; its ink is re-solved rather than carried over. */
function reseed(r, seed) {
  const accent = seed;
  const onWhite = contrast('#FFFFFF', accent), onBg = contrast(r.bg, accent);
  let accentInk = onWhite >= onBg ? '#FFFFFF' : r.bg;
  if (contrast(accentInk, accent) < 4.6) accentInk = solve(accentInk, accent, 4.5) || accentInk;
  return { ...r, accent, accentInk };
}

function main() {
  const argv = process.argv.slice(2);
  const flag = (n, d) => { const i = argv.indexOf(n); return i >= 0 ? (argv[i + 1] ?? true) : d; };
  const has = (n) => argv.includes(n);

  if (has('--list') || argv.length === 0) {
    console.log('Fourteen palettes. Pick the one whose use-when matches the brief, then rerun with');
    console.log('--pick <id>. Nothing forces you to use one: six values of your own, audited with');
    console.log('--check, are equally welcome — but say why in data-palette-reason.\n');
    for (const s of CATALOGUE) {
      console.log(`  ${s.id.padEnd(10)} ${s.mood}`);
      console.log(`  ${' '.repeat(10)} use when: ${s.useWhen}\n`);
    }
    console.log('  --seed "#RRGGBB"  the brief pins a brand colour: it replaces the accent.');
    return;
  }

  if (has('--check')) {
    const vals = argv.slice(argv.indexOf('--check') + 1).filter((a) => /^#[0-9a-fA-F]{6}$/.test(a));
    if (vals.length !== 6) {
      console.error('--check wants six hex values: bg ink accent accent-ink support-1 support-2');
      process.exit(2);
    }
    const r = Object.fromEntries(DECLARED.map((k, i) => [k, vals[i].toUpperCase()]));
    const mode = contrast(r.ink, '#FFFFFF') > contrast(r.ink, '#000000') ? 'dark' : 'light';
    const rows = audit(mode, r);
    const bad = rows.filter((x) => !x.pass);
    for (const x of rows) console.log(`  ${x.pass ? 'ok  ' : 'FAIL'} ${x.name.padEnd(26)} ${x.got} (need ${x.need})`);
    console.log(bad.length ? `\n${bad.length} check(s) fail` : '\nall checks pass — this palette is as safe as a catalogue one');
    process.exitCode = bad.length ? 1 : 0;
    return;
  }

  const id = flag('--pick', CATALOGUE[0].id);
  const sys = CATALOGUE.find((s) => s.id === id || s.name.toLowerCase() === String(id).toLowerCase());
  if (!sys) { console.error(`palette.mjs: no palette "${id}". Run --list.`); process.exit(2); }
  const seed = flag('--seed', null);
  const light = seed ? reseed(sys.light, seed) : sys.light;
  const dark = seed ? reseed(sys.dark, seed) : sys.dark;

  const report = [...audit('light', light), ...audit('dark', dark)];
  const failed = report.filter((r) => !r.pass);

  if (has('--json')) {
    console.log(JSON.stringify({ id: sys.id, name: sys.name, seed, light, dark,
      derived: { light: derive(light), dark: derive(dark) }, audit: report }, null, 2));
  } else {
    console.log(toCss(sys, light, dark, seed));
    console.error(`\n${report.length - failed.length}/${report.length} checks pass`);
    for (const r of failed) console.error(`  FAIL ${r.mode} ${r.name} — ${r.got} (need ${r.need})`);
  }
  process.exitCode = failed.length ? 1 : 0;
}

if (import.meta.url === `file://${process.argv[1]}`) main();
