#!/usr/bin/env node
/* compose.mjs — assemble a page from the sections you picked.
 *
 *   node tools/compose.mjs 01-nav 02-hero 04-feature-grid 18-pricing 21-cta 22-footer
 *   node tools/compose.mjs --all                # every section, i.e. the reference page again
 *
 * Writes `index.html` and `template.css` in the current directory from `sections/`. The foundation
 * and the shell are always included; each picked section brings its own markup and, when it has one,
 * its own skin block. Sections that share a skin block only bring it once.
 *
 * The order you list them in is the order they appear. `NARRATIVE.md` decides that order, not the
 * numbering — the numbers are only where each section sat in the reference page.
 */

import { readFileSync, writeFileSync, existsSync, readdirSync } from "fs";
import { join, resolve } from "path";

const dir = resolve(".");
const src = join(dir, "sections");
const stateFile = join(dir, ".compose-once.json");
if (!existsSync(src)) {
  console.error(
    "compose: no sections/ here. Run tools/split-sections.mjs first.",
  );
  process.exit(2);
}

// Composition is deliberately destructive: it replaces both the HTML and the stylesheet. The
// direct-HTML contract allows one assembly pass in a fresh site directory, then authoring happens
// in index.html. A second pass is not a harmless retry; it discards authored work and was the single
// largest avoidable delay in the measured runs. Make the contract mechanical instead of hoping the
// caller remembers it.
if (existsSync(stateFile)) {
  let previous = "unknown";
  try {
    previous = JSON.parse(readFileSync(stateFile, "utf8")).sections.join(" ");
  } catch {
    // The marker's existence is the invariant; a damaged marker must not silently unlock compose.
  }
  console.error(`compose: already assembled once (${previous}).`);
  console.error(
    "Start from a fresh template copy if the section selection was wrong; do not overwrite authored HTML.",
  );
  process.exit(2);
}

const available = readdirSync(src)
  .filter((f) => f.endsWith(".html") && !f.startsWith("_"))
  .map((f) => f.replace(/\.html$/, ""))
  .sort();

let picked = process.argv.slice(2).filter((a) => !a.startsWith("--"));
if (process.argv.includes("--all")) picked = available;
if (!picked.length) {
  console.error("compose: name the sections to include, in page order.\n");
  console.error(`  available: ${available.join(" ")}`);
  console.error(
    "\n  see sections/_index.md for what each one is, and what it costs in images.",
  );
  process.exit(2);
}

const missing = picked.filter((p) => !available.includes(p));
if (missing.length) {
  console.error(`compose: no such section(s): ${missing.join(", ")}`);
  process.exit(2);
}

const shell = readFileSync(join(src, "_shell.part"), "utf8");
const body = picked
  .map((p) => readFileSync(join(src, `${p}.html`), "utf8").trimEnd())
  .join("\n\n");
writeFileSync(
  join(dir, "index.html"),
  shell.replace("<!-- SECTIONS -->", body),
);

// Skin blocks keep the order they had in the reference stylesheet, NOT the order the sections were
// picked in. CSS is order-sensitive at equal specificity, so emitting them in page order silently
// rewrites the cascade — the feature-split block moved three places and changed which rule won.
// Deduplicated too: two testimonials share one block, and emitting it twice would make a later
// hand-edit apply to only one of them.
const map = JSON.parse(
  readFileSync(join(src, "_index.md"), "utf8").match(
    /```json\n([\s\S]*?)\n```/,
  )[1],
);
const want = new Set(picked.map((p) => map[p]).filter(Boolean));
// `.always.css` blocks style a device this reference page does not use. They ship regardless —
// you may add that device — and they keep their place in the cascade because the sort is by number.
const skins = readdirSync(src)
  .filter(
    (f) => f.startsWith("skin-") && (want.has(f) || f.endsWith(".always.css")),
  )
  .sort()
  .map((f) => readFileSync(join(src, f), "utf8"));
// The base layer goes last and goes in unconditionally: its rules are weak on purpose and several
// win ties only by coming after the skin. See tools/split-sections.mjs for why it is a file of its own.
const baseFile = join(src, "_baselayer.css");
const baseLayer = existsSync(baseFile) ? readFileSync(baseFile, "utf8") : "";
writeFileSync(
  join(dir, "template.css"),
  readFileSync(join(src, "_foundation.css"), "utf8") +
    skins.join("") +
    baseLayer,
);
writeFileSync(
  stateFile,
  `${JSON.stringify({ version: 1, sections: picked }, null, 2)}\n`,
);

const imgs = picked.reduce(
  (n, p) =>
    n +
    (readFileSync(join(src, `${p}.html`), "utf8").match(/<img\b/g) || [])
      .length,
  0,
);
console.log(
  `${picked.length} sections · ${imgs} image slots · index.html ${(readFileSync(join(dir, "index.html"), "utf8").length / 1024).toFixed(1)}KB`,
);
console.log(
  `left out: ${available.filter((a) => !picked.includes(a)).join(" ") || "nothing"}`,
);
console.log(
  "next: author index.html now; do not run compose again or poll VM0 image work while authoring.",
);
