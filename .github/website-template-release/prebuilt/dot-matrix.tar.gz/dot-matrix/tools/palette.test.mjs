#!/usr/bin/env node
/* palette.test.mjs — calibrate the colour rules from both sides.
 *
 *   node tools/palette.test.mjs
 *
 * Two halves, and both matter. Every catalogue palette must come out clean in both modes, and a
 * palette carrying the defects seen in review must trip the rule that exists to catch it. A
 * threshold nothing can trip is not a threshold; a threshold everything trips is not one either.
 *
 * The derived roles are computed with the same mix the CSS performs, so what is audited here is
 * what the browser paints — not an approximation of it.
 */

import { CATALOGUE, audit, derive, slabFor, mix } from './palette.mjs';

let failures = 0;
const say = (ok, line) => { if (!ok) failures++; console.log(`  ${ok ? 'ok  ' : 'FAIL'} ${line}`); };

/* ── half one: the catalogue is clean ─────────────────────────────────────── */
console.log('catalogue — every palette, both modes\n');
for (const sys of CATALOGUE) {
  const rows = [...audit('light', sys.light), ...audit('dark', sys.dark)];
  const bad = rows.filter((r) => !r.pass);
  say(bad.length === 0, `${sys.id.padEnd(10)} ${rows.length - bad.length}/${rows.length}`
    + (bad.length ? ` — ${bad.map((b) => `${b.mode} ${b.name} ${b.got}`).join('; ')}` : ''));
}

/* ── half two: the derivation is what it claims to be ─────────────────────── */
console.log('\nderivation — the mix percentages, checked against the values they produce\n');
{
  const r = CATALOGUE[0].light;
  const d = derive(r);
  say(d.ring === r.accent, 'ring is the accent, not a mix of it');
  say(d.surface !== r.bg, 'surface is not identical to bg');
  say(d.inkSoft !== r.ink, 'ink-soft is not identical to ink');
  // Mixing toward bg is the whole trick: it moves the derived value the right way in both modes.
  const lightSurface = mix(CATALOGUE[0].light.ink, CATALOGUE[0].light.bg, 0.04);
  const darkSurface = mix(CATALOGUE[10].dark.ink, CATALOGUE[10].dark.bg, 0.04);
  const lum = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16)).reduce((a, b) => a + b, 0);
  say(lum(lightSurface) < lum(CATALOGUE[0].light.bg), 'on paper the card sits darker than the page');
  say(lum(darkSurface) > lum(CATALOGUE[10].dark.bg), 'on a dark ground the card sits lighter than the page');
}

/* ── half three: broken palettes must trip ────────────────────────────────
 * Each of these is a defect seen in an actual review, not an invented one. */
console.log('\npositive controls — a broken palette has to fail\n');
const CONTROLS = [
  ['body text set in the accent',
    { bg: '#FFFFFF', ink: '#7C9AD6', accent: '#7C9AD6', accentInk: '#FFFFFF', support1: '#888', support2: '#999' },
    'ink on bg'],
  ['white ink on a pale accent',
    { bg: '#FFFFFF', ink: '#111111', accent: '#F2C94C', accentInk: '#FFFFFF', support1: '#888', support2: '#999' },
    'accent-ink on accent'],
  ['card indistinguishable from the page',
    { bg: '#FFFFFF', ink: '#FFFFFF', accent: '#2F5BD0', accentInk: '#FFFFFF', support1: '#888', support2: '#999' },
    'surface separates from bg'],
  ['accent too pale to see against the page',
    { bg: '#FFFFFF', ink: '#111111', accent: '#F7F3EA', accentInk: '#111111', support1: '#888', support2: '#999' },
    'accent on bg'],
];
for (const [label, palette, expect] of CONTROLS) {
  const rows = audit('light', palette);
  const tripped = rows.filter((r) => !r.pass).map((r) => r.name);
  say(tripped.includes(expect), `${label} → trips "${expect}"`
    + (tripped.includes(expect) ? '' : ` (tripped: ${tripped.join(', ') || 'nothing'})`));
}

/* ── half four: the deep band ─────────────────────────────────────────────── */
console.log('\ndeep band — dark in both modes, so its ink is light in both\n');
for (const sys of [CATALOGUE[0], CATALOGUE[10]]) {
  for (const mode of ['light', 'dark']) {
    const s = slabFor(sys[mode], mode);
    const lum = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16)).reduce((a, b) => a + b, 0);
    say(lum(s.slabInk) > lum(s.slab), `${sys.id} ${mode}: band ink is lighter than the band`);
  }
}

console.log(failures ? `\n${failures} failure(s)` : '\nall calibrated');
process.exit(failures ? 1 : 0);
