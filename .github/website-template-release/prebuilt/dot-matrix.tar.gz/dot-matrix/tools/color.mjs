/* color.mjs — sRGB / OKLab / OKLCH conversion and WCAG contrast.
 *
 * No dependencies. Every function here is pure. `palette.mjs` is the only intended consumer,
 * but the checks import `contrast()` too, so keep this file free of CLI code.
 */

/* ── sRGB ───────────────────────────────────────────────────────────────── */

export function hexToRgb(hex) {
  let h = String(hex).trim().replace(/^#/, '');
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  if (!/^[0-9a-fA-F]{6}$/.test(h)) throw new Error(`not a hex colour: ${hex}`);
  return [parseInt(h.slice(0, 2), 16) / 255, parseInt(h.slice(2, 4), 16) / 255, parseInt(h.slice(4, 6), 16) / 255];
}

export function rgbToHex([r, g, b]) {
  const c = (v) => Math.round(Math.min(1, Math.max(0, v)) * 255).toString(16).padStart(2, '0');
  return `#${c(r)}${c(g)}${c(b)}`.toUpperCase();
}

const toLinear = (c) => (c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4);
const toGamma = (c) => (c <= 0.0031308 ? c * 12.92 : 1.055 * c ** (1 / 2.4) - 0.055);

/* ── OKLab / OKLCH (Björn Ottosson) ─────────────────────────────────────── */

export function rgbToOklab([r, g, b]) {
  const R = toLinear(r), G = toLinear(g), B = toLinear(b);
  const l = Math.cbrt(0.4122214708 * R + 0.5363325363 * G + 0.0514459929 * B);
  const m = Math.cbrt(0.2119034982 * R + 0.6806995451 * G + 0.1073969566 * B);
  const s = Math.cbrt(0.0883024619 * R + 0.2817188376 * G + 0.6299787005 * B);
  return [
    0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s,
    1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s,
    0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s,
  ];
}

export function oklabToRgb([L, a, bb]) {
  const l = (L + 0.3963377774 * a + 0.2158037573 * bb) ** 3;
  const m = (L - 0.1055613458 * a - 0.0638541728 * bb) ** 3;
  const s = (L - 0.0894841775 * a - 1.291485548 * bb) ** 3;
  return [
    toGamma(4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s),
    toGamma(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s),
    toGamma(-0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s),
  ];
}

export function oklchToOklab([L, C, h]) {
  const r = (h * Math.PI) / 180;
  return [L, C * Math.cos(r), C * Math.sin(r)];
}

export function oklabToOklch([L, a, b]) {
  const C = Math.hypot(a, b);
  let h = (Math.atan2(b, a) * 180) / Math.PI;
  if (h < 0) h += 360;
  return [L, C, h];
}

export const hexToOklch = (hex) => oklabToOklch(rgbToOklab(hexToRgb(hex)));

const inGamut = ([r, g, b]) => r >= -1e-4 && r <= 1 + 1e-4 && g >= -1e-4 && g <= 1 + 1e-4 && b >= -1e-4 && b <= 1 + 1e-4;

/** OKLCH -> hex, reducing chroma (never lightness) until the colour fits sRGB. */
export function oklchToHex(L, C, h) {
  const Lc = Math.min(1, Math.max(0, L));
  if (inGamut(oklabToRgb(oklchToOklab([Lc, C, h])))) return rgbToHex(oklabToRgb(oklchToOklab([Lc, C, h])));
  let lo = 0, hi = C;
  for (let i = 0; i < 24; i++) {
    const mid = (lo + hi) / 2;
    if (inGamut(oklabToRgb(oklchToOklab([Lc, mid, h])))) lo = mid; else hi = mid;
  }
  return rgbToHex(oklabToRgb(oklchToOklab([Lc, lo, h])));
}

/** The largest chroma that stays inside sRGB at this lightness and hue. */
export function maxChroma(L, h) {
  let lo = 0, hi = 0.45;
  for (let i = 0; i < 24; i++) {
    const mid = (lo + hi) / 2;
    if (inGamut(oklabToRgb(oklchToOklab([L, mid, h])))) lo = mid; else hi = mid;
  }
  return lo;
}

/* ── WCAG ───────────────────────────────────────────────────────────────── */

export function luminance(hex) {
  const [r, g, b] = hexToRgb(hex);
  return 0.2126 * toLinear(r) + 0.7152 * toLinear(g) + 0.0722 * toLinear(b);
}

export function contrast(a, b) {
  const la = luminance(a), lb = luminance(b);
  return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
}

/** Whichever of the two candidates reads better on `bg`. */
export function bestInk(bg, candidates = ['#FFFFFF', '#0B0B0C']) {
  return candidates.slice(1).reduce((best, c) => (contrast(c, bg) > contrast(best, bg) ? c : best), candidates[0]);
}
