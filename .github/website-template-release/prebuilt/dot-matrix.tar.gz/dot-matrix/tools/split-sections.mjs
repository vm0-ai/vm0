#!/usr/bin/env node
/* split-sections.mjs — cut a package's reference page into a section library.
 *
 *   node tools/split-sections.mjs            # writes sections/ next to index.html
 *
 * Why: the SKILL tells a run to read `index.html` before it can write anything, and on this package
 * that file alone is 88KB of a 128KB reading load. Everything a run then does — replacing demo
 * facts, keeping devices it did not choose, hunting a hardcoded colour — happens on a page that is
 * already full. The defects that came back read that way: a card grid left carrying `Paul Klee` and
 * `1911`, a stylesheet published as a line-numbered dump, eight minutes spent finding an
 * `!important` in a 59KB file.
 *
 * A section you did not pick cannot be left half-edited. That is the whole argument.
 *
 * The cut is mechanical, never a rewrite:
 *   index.html   → sections/<n>-<kind>.html   one fragment per `data-section`
 *   template.css → sections/<n>-<kind>.css    the numbered skin block that names it, when there is one
 *                → sections/_foundation.css   everything before the skin blocks, always included
 *                → sections/_baselayer.css    the trailing v2 base layer, when present, included last
 *                → sections/_shell.part       <head>, the palette surface, and the closing tags
 *   → sections/_index.md                      the manifest a run reads INSTEAD of the whole page
 */

import { readFileSync, writeFileSync, mkdirSync, existsSync } from "fs";
import { dirname, join, resolve } from "path";
import { fileURLToPath } from "url";

const dir = resolve(process.argv[2] || ".");
const html = readFileSync(join(dir, "index.html"), "utf8");
const css = readFileSync(join(dir, "template.css"), "utf8");
const out = join(dir, "sections");
mkdirSync(out, { recursive: true });

/* ── HTML: one fragment per top-level element carrying data-section ───────── */

const OPEN =
  /<(section|nav|footer|header)\b[^>]*\bdata-section="([a-z-]+)"[^>]*>/g;
const frags = [];
let m;
while ((m = OPEN.exec(html))) {
  const tag = m[1];
  // Walk forward counting same-tag opens and closes, so a nested <section> does not end the outer.
  const re = new RegExp(`<${tag}\\b|</${tag}>`, "g");
  re.lastIndex = m.index;
  let depth = 0,
    end = -1,
    t;
  while ((t = re.exec(html))) {
    depth += t[0][1] === "/" ? -1 : 1;
    if (depth === 0) {
      end = t.index + t[0].length;
      break;
    }
  }
  if (end < 0) {
    console.error(`unterminated <${tag}> for ${m[2]}`);
    continue;
  }
  frags.push({ kind: m[2], tag, start: m.index, end });
  OPEN.lastIndex = end;
}

// Whatever sits BETWEEN two sections belongs to the one that follows: the reference pages put the
// scroll anchors there as empty `<a id="work">` elements, and `<main id="main">` opens before the
// first section. Cutting only the sections themselves dropped five ids and the gate said so —
// `anchors_resolve` failed on #main, #features, #work, #pricing and #faq.
frags.forEach((f, i) => {
  const from = i === 0 ? f.start : frags[i - 1].end;
  f.lead = html.slice(from, f.start);
  f.body = f.lead + html.slice(f.start, f.end);
});

/* ── CSS: the numbered skin blocks, plus everything before them ───────────── */

const marks = [...css.matchAll(/^\/\* *(\d+) *· *([A-Z-]+)[^\n]*/gm)].map(
  (x) => ({ n: +x[1], name: x[2].toLowerCase(), at: x.index }),
);
// When the v2 base layer sits AFTER the last numbered block, a naive "everything before the first
// block is foundation" split files it under the last skin — and a page
// that did not pick that section lost it. serif-stack's heading-alignment rule landed inside
// `skin-15-footer.css`: drop the footer and the reading columns went back to being centred under a
// left-aligned head, silently. It has to travel with every page.
//
// It also has to keep its place in the cascade. Its rules are deliberately weak (`:where()`, new
// classes) and several of them win ties only by coming last, so hoisting it into the foundation
// would hand those ties to the skin. Hence: where it already precedes the blocks it is foundation
// as-is; where it follows them it becomes `_baselayer.css`, which compose appends last, always.
const BASE_MARK = "══ v2 base layer";
const baseHit = css.indexOf(BASE_MARK);
const baseAt = baseHit >= 0 ? css.lastIndexOf("/*", baseHit) : css.length;
// When there are no numbered blocks, the whole stylesheet is foundation and there is nothing for
// the base layer to lose a tie to.
const skinStart = marks.length ? marks[0].at : css.length;
const trailingBase = marks.length > 0 && baseAt > skinStart;
const cssEnd = trailingBase ? baseAt : css.length;
const foundation = css.slice(0, skinStart);
const baseLayer = trailingBase ? css.slice(baseAt) : "";
const blocks = marks.map((mk, i) => ({
  ...mk,
  css: css.slice(mk.at, i + 1 < marks.length ? marks[i + 1].at : cssEnd),
}));

/** A section kind and a skin block name agree loosely: `feature-grid` ↔ `FEATURE-GRID`,
 *  `sticky-scroll` ↔ nothing, `contact` ↔ `CONTACT-FORM`. Match on the longest shared prefix. */
const blockFor = (kind) =>
  blocks.find((b) => b.name === kind) ||
  blocks.find((b) => b.name.startsWith(kind) || kind.startsWith(b.name));

/* ── write ───────────────────────────────────────────────────────────────── */

const head = html.slice(0, frags[0].start - frags[0].lead.length);
const foot = html.slice(frags[frags.length - 1].end);
// Not `.html`. `okou host` scans every HTML file in the directory for asset references, and the
// shell's `template.css` / `favicon.svg` paths are written relative to the package root, not to
// `sections/` — so a published package was refused because of a file that is not part of the page
// at all. The extension keeps it out of that scan.
writeFileSync(join(out, "_shell.part"), `${head}\n<!-- SECTIONS -->\n${foot}`);
writeFileSync(join(out, "_foundation.css"), foundation);
if (baseLayer) writeFileSync(join(out, "_baselayer.css"), baseLayer);

const rows = [];
const used = new Set();
frags.forEach((f, i) => {
  const id = `${String(i + 1).padStart(2, "0")}-${f.kind}`;
  writeFileSync(join(out, `${id}.html`), f.body + "\n");
  const b = blockFor(f.kind);
  // Skin files are named by the block's OWN number, not the section's. CSS is order-sensitive at
  // equal specificity, and two sections can share one block, so the stylesheet has to be rebuilt in
  // the order it was written — the feature-split block is #3 but first appears at section 06.
  let cssBytes = 0,
    skin = null;
  if (b) {
    skin = `skin-${String(b.n).padStart(2, "0")}-${b.name}.css`;
    if (!used.has(b.n)) {
      writeFileSync(join(out, skin), b.css);
      cssBytes = b.css.length;
      used.add(b.n);
    } else cssBytes = -1; // second instance: shares the first one's skin
  }
  rows.push({
    id,
    kind: f.kind,
    skin,
    html: f.body.length,
    css: cssBytes,
    words: (f.body.replace(/<[^>]*>/g, " ").match(/\S+/g) || []).length,
    imgs: (f.body.match(/<img\b/g) || []).length,
  });
});

const alwaysIncluded = [
  "_foundation.css",
  ...(baseLayer ? ["_baselayer.css"] : []),
  "_shell.part",
]
  .map((file) => `\`${file}\``)
  .join(", ");

const manifest = `# Section library — ${dir.split("/").pop()}

Cut from the reference page by \`tools/split-sections.mjs\`. Pick the sections the brief supports,
in the order \`NARRATIVE.md\` gives, and assemble with \`tools/compose.mjs\`. A section you do not
pick is not in the page, so it cannot be left half-edited.

${alwaysIncluded} are always included. \`css −\` means the section reuses a skin
block an earlier section already brought.

| section | kind | html | skin | words | imgs |
|---|---|---|---|---|---|
${rows.map((r) => `| \`${r.id}\` | ${r.kind} | ${(r.html / 1024).toFixed(1)}KB | ${!r.skin ? "—" : r.css < 0 ? `${r.skin} (shared)` : r.skin} | ${r.words} | ${r.imgs} |`).join("\n")}

\`\`\`json
${JSON.stringify(Object.fromEntries(rows.filter((r) => r.skin).map((r) => [r.id, r.skin])), null, 0)}
\`\`\`

Whole reference page: ${(html.length / 1024).toFixed(1)}KB · foundation ${(foundation.length / 1024).toFixed(1)}KB.
`;
writeFileSync(join(out, "_index.md"), manifest);

// A skin block whose section is not in this reference page still has to ship: black-slabs styles a
// feature-grid its own example never uses, and dropping it silently deleted 27 lines from the
// stylesheet. Orphans are written as `.always.css` and compose includes them unconditionally, in
// their original place in the cascade.
const orphanBlocks = blocks.filter((b) => !used.has(b.n));
for (const b of orphanBlocks)
  writeFileSync(
    join(out, `skin-${String(b.n).padStart(2, "0")}-${b.name}.always.css`),
    b.css,
  );

console.log(
  `${frags.length} sections · ${blocks.length} skin blocks (${orphanBlocks.length} unused by this page) · foundation ${(foundation.length / 1024).toFixed(1)}KB`,
);
console.log(
  `manifest ${(manifest.length / 1024).toFixed(1)}KB vs whole page ${(html.length / 1024).toFixed(1)}KB`,
);
const orphan = frags.filter((f) => !blockFor(f.kind)).map((f) => f.kind);
if (orphan.length)
  console.log(
    `no skin block found for: ${[...new Set(orphan)].join(", ")} (they use foundation rules only)`,
  );
