#!/usr/bin/env node
/* stage.mjs — copy just the files a reader needs into a clean directory, ready to publish.
 *
 *   node tools/stage.mjs publish            # then: okou host publish --site <slug>
 *
 * `okou host <dir>` uploads everything in the directory. By the time a page is finished the working
 * directory also holds `node_modules` from installing the gate's Chromium driver, the full-page
 * screenshots the gate wrote into `qa/`, and whatever the image generator dropped in the cwd. One
 * run measured its own: 4.5MB of site inside 35MB of directory. It noticed and staged a clean copy
 * by hand, which is exactly the kind of thing that should not depend on noticing.
 *
 * The rule is an allowlist, not a blocklist. A blocklist ships whatever it did not think of.
 */

import {
  readdirSync,
  statSync,
  mkdirSync,
  copyFileSync,
  rmSync,
  existsSync,
} from "fs";
import { join, extname, resolve } from "path";

const out = resolve(process.argv[2] || "publish");
const src = resolve(".");

/** What a browser asks for. Everything else is workshop. */
const KEEP_EXT = new Set([
  ".html",
  ".css",
  ".js",
  ".svg",
  ".png",
  ".jpg",
  ".jpeg",
  ".webp",
  ".avif",
  ".gif",
  ".ico",
  ".woff",
  ".woff2",
  ".txt",
  ".json",
  ".xml",
  ".mp4",
  ".webm",
]);
const SKIP_DIR = new Set([
  "node_modules",
  "qa",
  "sections",
  "tools",
  "checks",
  ".git",
]);
// `_shell.part` is already excluded by extension; these are the ones that share a real extension
// with a real asset but are authoring inputs, not page assets.
const SKIP_FILE = new Set([
  "package.json",
  "package-lock.json",
  "template.json",
  "image-jobs.json",
  "image-generation.json",
]);

if (existsSync(out)) rmSync(out, { recursive: true });
let files = 0,
  bytes = 0,
  skipped = 0,
  skippedBytes = 0;

const walk = (from, to, depth = 0) => {
  mkdirSync(to, { recursive: true });
  for (const name of readdirSync(from)) {
    const s = join(from, name),
      d = join(to, name);
    const st = statSync(s);
    if (st.isDirectory()) {
      // The output directory defaults to `publish` INSIDE the site, so the walk met the directory
      // it had just created and copied it into itself, forever: seven of eleven runs ended up with
      // `publish/publish/publish/...` and an ENAMETOOLONG. Never descend into the destination.
      if (s === out) {
        continue;
      }
      if (SKIP_DIR.has(name) || name.startsWith(".")) {
        skipped++;
        continue;
      }
      walk(s, d, depth + 1);
      continue;
    }
    if (
      SKIP_FILE.has(name) ||
      !KEEP_EXT.has(extname(name).toLowerCase()) ||
      name.startsWith(".")
    ) {
      skipped++;
      skippedBytes += st.size;
      continue;
    }
    copyFileSync(s, d);
    files++;
    bytes += st.size;
  }
};
walk(src, out);

if (!existsSync(join(out, "index.html"))) {
  console.error(
    "stage: no index.html in the staged directory — nothing would be served",
  );
  process.exit(1);
}
const mb = (n) => (n / 1024 / 1024).toFixed(1);
console.log(`${files} files · ${mb(bytes)}MB → ${out}`);
console.log(
  `left behind: ${skipped} entries, ${mb(skippedBytes)}MB of loose files plus node_modules, qa, sections, tools, checks`,
);
console.log(`\n  okou host ${process.argv[2] || "publish"} --site <slug>`);
