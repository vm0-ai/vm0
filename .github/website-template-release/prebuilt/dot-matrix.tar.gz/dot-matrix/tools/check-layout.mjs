#!/usr/bin/env node
/* check-layout.mjs — does the reading block sit where the rest of the page sits?
 *
 *   node tools/check-layout.mjs .                      # one package's reference page
 *   node tools/check-layout.mjs https://a-site/        # or a published URL
 *
 * A section that is only a heading and a reading column has no grid to hold its shape, so it drifts.
 * Three ways it drifts, all of them reported here, all measured in a browser:
 *
 *   1  it starts somewhere the rest of the page does not
 *   2  a short heading wraps because the head is capped far narrower than what it introduces
 *   3  it is left-aligned but stops halfway, leaving one margin several times the other
 *
 * MEASURE INK, NOT BOXES. A block-level `<p>` fills its container, so a column visibly hugging the
 * left reads as "symmetric" if you take element rectangles. Every number here comes from Range
 * client rects — the actual glyphs.
 *
 * The spine — what "where the rest of the page sits" means — is the MEDIAN ink-left across sections,
 * dropping anything off-canvas. That definition survived four earlier ones that did not:
 *   · the ink of card-bearing sections — card padding pushed the spine 33px right, and dot-matrix's
 *     statement, sitting exactly where steps/gallery/feature sit, was called 33px off
 *   · the ink of other section heads — a flush hero and a full-bleed marquee dragged it to 0
 *   · each container's own content edge — frame-stack's containers are full-bleed with the inset
 *     applied elsewhere, so it read 0 there too
 *   · the template's majority alignment, for deciding centred vs left — blueprint-grid left-aligns
 *     most heads and centres this one; classified by majority it put a left-hugging column under a
 *     centred head, which `prose_columns_follow_their_heading_alignment` then failed on
 * A median ignores a few odd sections by construction, which is what all four of those needed.
 *
 * Alignment is read off THAT PAIR's own heading, never off the template as a whole.
 */

import { existsSync } from "fs";
import { resolve } from "path";
import { driver } from "./driver.mjs";

const targets = process.argv.slice(2);
if (!targets.length) targets.push(".");

const browser = await (
  await driver()
).launch({
  executablePath: [
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/google-chrome",
  ].find(existsSync),
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});

const measure = async (url) => {
  const p = await browser.newPage();
  await p.setViewport({ width: 1600, height: 900 });
  await p.goto(url, { waitUntil: "load", timeout: 120000 });
  // The reveal animations gate visibility; without a scroll pass a section reads as zero-sized.
  const H = await p.evaluate(() => document.body.scrollHeight);
  for (let y = 0; y < H; y += 700) {
    await p.evaluate((t) => scrollTo(0, t), y);
    await new Promise((r) => setTimeout(r, 35));
  }
  await p.evaluate(async () => {
    scrollTo(0, 0);
    await document.fonts.ready;
  });
  await new Promise((r) => setTimeout(r, 600));

  const out = await p.evaluate(() => {
    const ink = (el) => {
      let L = Infinity,
        R = -Infinity;
      const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
      let n;
      while ((n = w.nextNode())) {
        if (!n.textContent.trim()) continue;
        const rg = document.createRange();
        rg.selectNodeContents(n);
        for (const rc of rg.getClientRects()) {
          if (rc.width < 2 || rc.height < 2) continue;
          L = Math.min(L, rc.left);
          R = Math.max(R, rc.right);
        }
      }
      return L === Infinity ? null : { L, R };
    };
    const med = (a) =>
      a.length ? [...a].sort((x, y) => x - y)[Math.floor(a.length / 2)] : null;

    const pairHead = [...document.querySelectorAll(".sec-head")].find((h) =>
      h.nextElementSibling?.classList?.contains("prose"),
    );
    const centred = pairHead
      ? getComputedStyle(pairHead).textAlign === "center"
      : false;

    const targets = [],
      spineL = [],
      spineR = [];
    for (const s of document.querySelectorAll("[data-section]")) {
      const sr = s.getBoundingClientRect();
      const pr = s.querySelector(".prose");
      const proseOnly =
        pr &&
        !s.querySelectorAll("img,figure").length &&
        [...pr.querySelectorAll("p")].filter(
          (x) => x.textContent.trim().split(/\s+/).length >= 12,
        ).length >= 2;
      const i = ink(s);
      if (!i) continue;
      const L = i.L - sr.left,
        R = sr.right - i.R;
      if (!proseOnly) {
        if (L >= 0 && L <= innerWidth / 3) spineL.push(L);
        if (R >= 0 && R <= innerWidth / 3) spineR.push(R);
      } else {
        const c = s.querySelector(".container");
        const cb = c ? c.getBoundingClientRect() : sr;
        targets.push({
          sec: s.dataset.section,
          L,
          R,
          C: (i.L + i.R) / 2 - (cb.left + cb.right) / 2,
        });
      }
    }
    const refL = med(spineL),
      refR = med(spineR);

    const bad = [];
    for (const t of targets) {
      if (centred) {
        if (Math.abs(t.C) > 60)
          bad.push(`[起点] ${t.sec} 中轴偏 ${Math.round(t.C)}`);
      } else {
        if (Math.abs(t.L - (refL ?? 0)) > 8)
          bad.push(
            `[起点] ${t.sec} 左${Math.round(t.L)} vs 骨架${Math.round(refL ?? 0)}`,
          );
        if (t.R - (refR ?? 0) > 120)
          bad.push(
            `[宽度] ${t.sec} 右留白${Math.round(t.R)} vs 骨架${Math.round(refR ?? 0)}`,
          );
      }
    }

    // A narrow head is a real device — most of this family uses one — so "narrower than its sibling"
    // is the wrong question; it flagged nine of eleven templates. The defect is a head capped so far
    // below the content it introduces that a SHORT heading cannot fit on one line.
    for (const head of document.querySelectorAll(".sec-head")) {
      const next = head.nextElementSibling;
      const h = head.querySelector("h1,h2,h3,.h1,.h2,.h3");
      if (!next || !h) continue;
      const hb = h.getBoundingClientRect(),
        nb = next.getBoundingClientRect();
      if (hb.width < 4 || nb.width < 4) continue;
      if (
        Math.round(hb.height / parseFloat(getComputedStyle(h).lineHeight)) < 2
      )
        continue;
      // frame-stack's heading needed 698px in a 694px box — 4px over, and the box is 88% of its
      // sibling. Nothing is squeezing it; the sentence is simply long. Require both.
      if (hb.width > nb.width * 0.7) continue;
      const probe = h.cloneNode(true);
      probe.style.cssText =
        "position:absolute;visibility:hidden;white-space:nowrap;width:auto;max-width:none;left:-9999px";
      h.parentElement.appendChild(probe);
      const need = probe.getBoundingClientRect().width;
      probe.remove();
      if (need <= nb.width) {
        bad.push(
          `[折行] "${h.textContent.trim().slice(0, 24)}" 盒${Math.round(hb.width)}/兄弟${Math.round(nb.width)}，一行需${Math.round(need)}`,
        );
      }
    }
    return {
      centred,
      refL: Math.round(refL ?? 0),
      refR: Math.round(refR ?? 0),
      bad,
    };
  });
  await p.close();
  return out;
};

let failed = 0;
for (const t of targets) {
  const url = t.startsWith("http") ? t : `file://${resolve(t)}/index.html`;
  const name = t.startsWith("http")
    ? url.replace("https://", "").split(".")[0]
    : resolve(t).split("/").pop();
  const r = await measure(url);
  if (r.bad.length) failed++;
  console.log(
    `${name.padEnd(24)}${(r.centred ? "居中" : "左对齐").padEnd(7)}` +
      (r.bad.length
        ? `✗ ${r.bad.join(" · ")}`
        : `✓ 骨架 左${r.refL}/右${r.refR}`),
  );
}
console.log(`\n${targets.length - failed}/${targets.length} 通过`);
await browser.close();
process.exit(failed ? 1 : 0);
