#!/usr/bin/env node
/* measure-sections.mjs — put each section's geometry into the manifest, measured in a browser.
 *
 *   node tools/measure-sections.mjs            # updates sections/_index.md in place
 *
 * A run picks sections from the manifest and then has to know how they lay out: how wide the media
 * column is, what aspect ratio it wants, how many columns the grid has, what happens on a phone. All
 * of that lives in a 35–97KB foundation stylesheet the SKILL tells it not to open, so it opens it
 * anyway — one run spent 69 seconds in there working out that `.fs .media` is 5/4 and the media
 * column is about half the container.
 *
 * Nobody should read a stylesheet to learn a number a browser can report. These are measured off the
 * reference page at both viewports, the same way the identity constants are, and for the same
 * reason: every earlier attempt at writing such numbers by hand was wrong in a way reading could not
 * catch.
 */

import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join, resolve } from 'path';
import puppeteer from 'puppeteer-core';

const dir = resolve(process.argv[2] || '.');
const man = join(dir, 'sections', '_index.md');
if (!existsSync(man)) { console.error('no sections/_index.md — run tools/split-sections.mjs first'); process.exit(2); }

const CHROME = ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome']
  .find((p) => existsSync(p));
const browser = await puppeteer.launch({ executablePath: CHROME, args: ['--no-sandbox', '--disable-dev-shm-usage'] });

async function read(width, height) {
  const p = await browser.newPage();
  await p.setViewport({ width, height });
  await p.goto(`file://${join(dir, 'index.html')}`, { waitUntil: 'load', timeout: 90000 });
  // The reveal animations gate visibility; without a scroll pass every section reads as 0 tall.
  const H = await p.evaluate(() => document.body.scrollHeight);
  for (let y = 0; y < H; y += Math.round(height * 0.8)) {
    await p.evaluate((to) => window.scrollTo(0, to), y);
    await new Promise((r) => setTimeout(r, 50));
  }
  await p.evaluate(async () => { window.scrollTo(0, 0); await document.fonts.ready; });
  const out = await p.evaluate(() => {
    const round = (v) => Math.round(v);
    return [...document.querySelectorAll('[data-section]')].map((el) => {
      const r = el.getBoundingClientRect();
      const media = [...el.querySelectorAll('.media, img, picture, video')].filter((m) => m.getBoundingClientRect().width > 4);
      const first = media[0]?.getBoundingClientRect();
      // Column count from the widest grid inside the section, read off the computed template.
      const grids = [...el.querySelectorAll('*')].filter((n) => getComputedStyle(n).display.includes('grid'));
      const cols = grids.map((g) => getComputedStyle(g).gridTemplateColumns.split(' ').filter(Boolean).length)
        .filter((n) => n > 1);
      return {
        kind: el.dataset.section,
        h: round(r.height),
        media: media.length,
        ratio: first && first.height > 4 ? +(first.width / first.height).toFixed(2) : null,
        mediaShare: first ? Math.round((first.width / Math.max(r.width, 1)) * 100) : null,
        cols: cols.length ? Math.max(...cols) : 1,
      };
    });
  });
  await p.close();
  return out;
}

const desktop = await read(1440, 900);
const mobile = await read(390, 844);
await browser.close();

// The manifest lists sections in page order and so does the reading, so they line up by index.
let md = readFileSync(man, 'utf8');
const rows = md.split('\n');
let i = -1;
const updated = rows.map((line) => {
  if (!line.startsWith('| `')) return line;
  i++;
  const d = desktop[i], m = mobile[i];
  if (!d) return line;
  const geo = [
    d.cols > 1 ? `${d.cols}col` : null,
    m && m.cols !== d.cols ? `→${m.cols > 1 ? `${m.cols}col` : '1col'}` : null,
    d.ratio ? `media ${d.ratio}` : null,
    d.mediaShare != null && d.mediaShare < 98 ? `${d.mediaShare}%w` : null,
    `${d.h}px`,
  ].filter(Boolean).join(' · ');
  return line.replace(/\s*\|\s*$/, ` | ${geo} |`);
});
const head = updated.findIndex((l) => l.startsWith('| section |'));
if (head >= 0) {
  updated[head] = updated[head].replace(/\s*\|\s*$/, ' | geometry |');
  updated[head + 1] = updated[head + 1].replace(/\s*\|\s*$/, '|---|');
}
md = updated.join('\n').replace('`css −` means the section reuses a skin\nblock an earlier section already brought.',
  '`css −` means the section reuses a skin\nblock an earlier section already brought. `geometry` is measured off the reference page at 1440 and\n390 — column counts, the first media box\'s aspect ratio and its share of the section width, and the\nsection\'s own height. Read it here rather than opening the stylesheet.');
writeFileSync(man, md);
console.log(`measured ${desktop.length} sections at 1440 and 390 → ${man}`);
