#!/usr/bin/env node
/* screenshot.mjs — turn one local review page into one stable image.
 *
 *   node tools/screenshot.mjs qa/review-atlas.html qa/review-atlas.png
 *
 * `checks/verify.mjs` calls `captureScreenshot` with its existing browser, so every gate run leaves
 * one ready-made image behind without launching Chromium twice. The CLI form is only for rebuilding
 * that image after editing the review HTML; it is not a second QA workflow.
 */

import { existsSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { driver } from "./driver.mjs";

const DEFAULT_VIEWPORT = { width: 1360, height: 1200 };
const CHROME =
  process.env.CHROME_PATH ||
  [
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/google-chrome",
  ].find(existsSync);

export async function captureScreenshot({
  browser,
  input = "qa/review-atlas.html",
  output = "qa/review-atlas.png",
  viewport = DEFAULT_VIEWPORT,
} = {}) {
  const source = resolve(input);
  const target = resolve(output);
  if (!existsSync(source)) throw new Error(`screenshot: no ${source}`);
  mkdirSync(dirname(target), { recursive: true });

  let ownedBrowser;
  if (!browser) {
    if (!CHROME)
      throw new Error("screenshot: no Chromium found; set CHROME_PATH");
    const puppeteer = await driver();
    ownedBrowser = await puppeteer.launch({
      executablePath: CHROME,
      args: [
        "--no-sandbox",
        "--disable-dev-shm-usage",
        "--font-render-hinting=none",
      ],
    });
    browser = ownedBrowser;
  }

  const page = await browser.newPage();
  try {
    await page.setViewport(viewport);
    await page.goto(pathToFileURL(source).href, {
      waitUntil: "load",
      timeout: 90_000,
    });
    await page.waitForFunction(
      () => [...document.images].every((image) => image.complete),
      { timeout: 90_000 },
    );
    await page.screenshot({ path: target, fullPage: true, type: "png" });
  } finally {
    await page.close();
    if (ownedBrowser) await ownedBrowser.close();
  }
  return target;
}

async function main() {
  if (process.argv.includes("--help") || process.argv.includes("-h")) {
    console.log("usage: node tools/screenshot.mjs [review-html] [output-png]");
    return;
  }
  const output = await captureScreenshot({
    input: process.argv[2] || "qa/review-atlas.html",
    output: process.argv[3] || "qa/review-atlas.png",
  });
  console.log(`review screenshot: ${output}`);
}

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(resolve(process.argv[1])).href
) {
  main().catch((error) => {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  });
}
