#!/usr/bin/env node
/* measure.mjs — read a rendered page and report what it actually is.
 *
 *   node tools/measure.mjs index.html                 # measure one page
 *   node tools/measure.mjs index.html --json
 *   node tools/measure.mjs a.html b.html              # compare two pages (conversion fidelity)
 *
 * Identity constants are measured here and nowhere else. Every constant that was ever typed by hand
 * into a template document turned out to be wrong in a way reading could not catch — a radius
 * documented as fully rounded that was square, an accent described by its intended name rather than
 * its shipped value. So: open the page, ask the browser, write down the answer.
 *
 * Needs a Chromium. Set CHROME_PATH if it is not at /usr/bin/chromium.
 */

import { existsSync } from 'fs';
import { resolve } from 'path';
import puppeteer from 'puppeteer-core';

const CHROME = process.env.CHROME_PATH
  || ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome'].find(existsSync);

const VIEWPORTS = { desktop: { width: 1440, height: 900 }, mobile: { width: 390, height: 844 } };

const PROBE = () => {
  const vis = (el) => {
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 1 && r.height > 1 && s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity) > 0.05;
  };
  const px = (v) => parseFloat(v) || 0;
  const fam = (el) => getComputedStyle(el).fontFamily.split(',')[0].replace(/["']/g, '').trim();

  const body = document.body;
  const bodySize = px(getComputedStyle(body).fontSize);

  const heads = [...document.querySelectorAll('h1,h2')].filter(vis);
  const famCount = {};
  for (const h of heads) famCount[fam(h)] = (famCount[fam(h)] || 0) + 1;

  const h1 = [...document.querySelectorAll('h1')].filter(vis)[0];
  const h2 = [...document.querySelectorAll('h2')].filter(vis)[0];
  const para = [...document.querySelectorAll('p')].filter(vis)
    .find((p) => p.textContent.trim().split(/\s+/).length > 12);

  // Radius character: the modal radius across visible boxes that have one.
  const radii = {};
  for (const el of [...document.querySelectorAll('*')].filter(vis)) {
    const r = getComputedStyle(el).borderTopLeftRadius;
    if (px(r) > 0) radii[r] = (radii[r] || 0) + 1;
  }

  const cs = getComputedStyle(document.documentElement);
  const token = (n) => cs.getPropertyValue(n).trim() || null;

  // Only real page sections: nav and footer also carry data-section, and counting them makes the
  // stamped section count disagree with the layout map for no reason.
  const sections = [...document.querySelectorAll('section[data-section]')].map((s) => s.getAttribute('data-section'));

  const main = document.querySelector('main') || body;
  const words = (main.innerText || '').split(/\s+/).filter(Boolean).length;

  // Widest visible paragraph box — the reading-measure gate measures the paragraph, not its wrapper.
  const widestPara = [...document.querySelectorAll('p')].filter(vis)
    .reduce((m, p) => Math.max(m, p.getBoundingClientRect().width), 0);

  const proseBlocks = [...document.querySelectorAll('.prose, [data-prose]')].filter(vis).length;
  const multiParaBlocks = [...document.querySelectorAll('div,section,article')].filter(vis)
    .filter((el) => [...el.children].filter((c) => c.tagName === 'P' && vis(c)).length >= 2).length;

  return {
    viewport: { w: innerWidth, h: innerHeight },
    docHeight: document.documentElement.scrollHeight,
    type: {
      bodyPx: bodySize,
      bodyFamily: fam(para || body),
      headFamilies: famCount,
      h1Px: h1 ? px(getComputedStyle(h1).fontSize) : null,
      h2Px: h2 ? px(getComputedStyle(h2).fontSize) : null,
      heroRatio: h1 ? +(px(getComputedStyle(h1).fontSize) / bodySize).toFixed(2) : null,
      h2Ratio: h2 ? +(px(getComputedStyle(h2).fontSize) / bodySize).toFixed(2) : null,
      h1Tracking: h1 ? getComputedStyle(h1).letterSpacing : null,
      h1Leading: h1 ? getComputedStyle(h1).lineHeight : null,
      h1Weight: h1 ? getComputedStyle(h1).fontWeight : null,
    },
    radius: Object.entries(radii).sort((a, b) => b[1] - a[1]).slice(0, 4),
    tokens: Object.fromEntries(['--bg', '--ink', '--ink-soft', '--accent', '--accent-ink', '--surface',
      '--surface-2', '--border', '--support-1', '--support-2', '--ring', '--slab', '--radius',
      '--container', '--fd', '--fb'].map((n) => [n, token(n)])),
    computed: {
      bodyBg: getComputedStyle(body).backgroundColor,
      bodyColor: getComputedStyle(body).color,
    },
    sections,
    counts: {
      words,
      images: [...document.images].filter(vis).length,
      brokenImages: [...document.images].filter((i) => i.complete && i.naturalWidth === 0).length,
      buttons: [...document.querySelectorAll('.btn, button, [role=button]')].filter(vis).length,
      proseBlocks,
      multiParaBlocks,
      widestPara: Math.round(widestPara),
      h1: [...document.querySelectorAll('h1')].filter(vis).length,
    },
    overflowX: document.documentElement.scrollWidth > innerWidth + 1,
  };
};

async function measure(file) {
  const browser = await puppeteer.launch({ executablePath: CHROME, args: ['--no-sandbox', '--disable-dev-shm-usage', '--font-render-hinting=none'] });
  const out = {};
  try {
    for (const [name, vp] of Object.entries(VIEWPORTS)) {
      const page = await browser.newPage();
      await page.setViewport(vp);
      // Reveal animations are mid-flight when the probe runs, so an opacity-gated visibility test
      // returns a different count on every pass. Reduced motion settles the page and makes the
      // reading exact — a ruler that reports a different number each time cannot support a claim.
      await page.emulateMediaFeatures([{ name: 'prefers-reduced-motion', value: 'reduce' }]);
      const errors = [];
      page.on('pageerror', (e) => errors.push(String(e).split('\n')[0]));
      page.on('requestfailed', (r) => { if (!/^data:/.test(r.url())) errors.push(`requestfailed ${r.url().slice(0, 90)}`); });
      await page.goto(`file://${resolve(file)}`, { waitUntil: 'load', timeout: 60000 });
      await page.evaluate(async () => {
        window.scrollTo(0, document.body.scrollHeight);
        await new Promise((r) => setTimeout(r, 350));
        window.scrollTo(0, 0);
        await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      });
      out[name] = await page.evaluate(PROBE);
      out[name].errors = [...new Set(errors)].slice(0, 6);
      await page.close();
    }
  } finally { await browser.close(); }
  return out;
}

function flat(o, prefix = '') {
  const rows = {};
  for (const [k, v] of Object.entries(o)) {
    const key = prefix ? `${prefix}.${k}` : k;
    if (v && typeof v === 'object' && !Array.isArray(v)) Object.assign(rows, flat(v, key));
    else rows[key] = Array.isArray(v) ? JSON.stringify(v) : String(v);
  }
  return rows;
}

const files = process.argv.slice(2).filter((a) => !a.startsWith('--'));
const asJson = process.argv.includes('--json');

if (!files.length) { console.error('usage: measure.mjs <page.html> [other.html] [--json]'); process.exit(2); }
if (!CHROME) { console.error('measure.mjs: no Chromium found; set CHROME_PATH'); process.exit(2); }

const results = [];
for (const f of files) results.push({ file: f, data: await measure(f) });

if (asJson) {
  console.log(JSON.stringify(results.length === 1 ? results[0].data : results, null, 2));
} else if (results.length === 1) {
  console.log(JSON.stringify(results[0].data, null, 2));
} else {
  // Comparison mode: what conversion changed. Anything listed here is a regression to explain.
  const a = flat(results[0].data), b = flat(results[1].data);
  const keys = [...new Set([...Object.keys(a), ...Object.keys(b)])].sort();
  const diffs = keys.filter((k) => a[k] !== b[k]);
  console.log(`${results[0].file}\n${results[1].file}\n`);
  if (!diffs.length) console.log('identical on every measured axis');
  for (const k of diffs) console.log(`  ${k}\n    a: ${a[k]}\n    b: ${b[k]}`);
  process.exitCode = diffs.length ? 1 : 0;
}
