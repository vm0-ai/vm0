#!/usr/bin/env node
/* stamp-identity.mjs — measure this template's identity constants and write them into SKILL.md
 * and template.json.
 *
 *   node tools/stamp-identity.mjs                # measures ./index.html
 *   node tools/stamp-identity.mjs --page other.html
 *
 * Identity constants are what makes a generated page recognisably THIS template rather than a
 * generic one: which face carries the headings, how far display type sits above body type, what the
 * corner radius actually is, whether the accent is a colour or effectively black.
 *
 * They are measured here and nowhere else. Every constant that has been typed by hand into a
 * template document was eventually found to be wrong in a way reading could not catch — a radius
 * documented as fully rounded that rendered square, an accent named for its intention rather than
 * its shipped value. So the rule is: open the page, ask the browser, write down the answer.
 *
 * The stamped numbers are a floor with slack, not the reference's exact reading, so a legitimately
 * different composition still satisfies them.
 */

import { readFileSync, writeFileSync, existsSync } from 'fs';
import { execFileSync } from 'child_process';
import { dirname, join, resolve } from 'path';
import { fileURLToPath } from 'url';

const here = dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const flag = (n, d) => { const i = argv.indexOf(n); return i >= 0 ? argv[i + 1] : d; };
const page = resolve(flag('--page', 'index.html'));
const dir = dirname(page);

if (!existsSync(page)) { console.error(`stamp-identity.mjs: no ${page}`); process.exit(2); }

const raw = execFileSync(process.execPath, [join(here, 'measure.mjs'), page, '--json'],
  { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
const m = JSON.parse(raw);

/** Floors with slack: a different composition must still be able to pass. */
const floor = (v, slack = 0.86) => (v == null ? null : Math.round(v * slack * 100) / 100);

const dominantFace = (fams) => Object.entries(fams || {}).sort((a, b) => b[1] - a[1])[0] || [null, 0];
const [dFace, dCount] = dominantFace(m.desktop.type.headFamilies);
const totalHeads = Object.values(m.desktop.type.headFamilies || {}).reduce((a, b) => a + b, 0) || 1;
const share = Math.floor((dCount / totalHeads) * 100 * 0.9);

const modalRadius = m.desktop.radius?.[0]?.[0] || '0px';
const constants = {
  displayFace: dFace,
  displayFaceShare: `${Math.min(share, 95)}%`,
  bodyFace: m.desktop.type.bodyFamily,
  bodyPx: m.desktop.type.bodyPx,
  heroRatioDesktop: floor(m.desktop.type.heroRatio),
  h2RatioDesktop: floor(m.desktop.type.h2Ratio),
  heroRatioMobile: floor(m.mobile.type.heroRatio),
  h2RatioMobile: floor(m.mobile.type.h2Ratio),
  // Report tracking and leading relative to the headline's own size. The raw px values are correct
  // and unusable: -4.752px means nothing until you know the headline is 90.8px.
  headingPx: m.desktop.type.h1Px,
  headingTracking: m.desktop.type.h1Tracking,
  headingTrackingEm: m.desktop.type.h1Px ? `${(parseFloat(m.desktop.type.h1Tracking) / m.desktop.type.h1Px).toFixed(3)}em` : null,
  headingLeading: m.desktop.type.h1Leading,
  headingLeadingRatio: m.desktop.type.h1Px ? +(parseFloat(m.desktop.type.h1Leading) / m.desktop.type.h1Px).toFixed(2) : null,
  headingWeight: m.desktop.type.h1Weight,
  modalRadius,
  radiusProfile: m.desktop.radius,
  accent: m.desktop.tokens['--accent'],
  slab: m.desktop.tokens['--slab'],
  container: m.desktop.tokens['--container'],
  referenceWords: m.desktop.counts.words,
  widestParagraphPx: m.desktop.counts.widestPara,
  sections: m.desktop.sections.length,
  proseBlocks: m.desktop.counts.proseBlocks,
  multiParagraphBlocks: m.desktop.counts.multiParaBlocks,
  desktopHeight: m.desktop.docHeight,
  mobileOverflow: m.mobile.overflowX,
};

const block = `### Measured identity constants

Measured off this package's \`index.html\` by \`tools/stamp-identity.mjs\` at 1440×900 and 390×844.
Stated as floors with slack, so a different composition can still satisfy them.

- **Type.** Headings are set in \`${constants.displayFace}\` on at least ${constants.displayFaceShare} of visible
  \`h1\`/\`h2\`; body is \`${constants.bodyFace}\` at ${constants.bodyPx}px. Display sits at least
  **${constants.heroRatioDesktop}×** body for the hero and **${constants.h2RatioDesktop}×** for \`h2\` on desktop;
  **${constants.heroRatioMobile}×** and **${constants.h2RatioMobile}×** on mobile. At a ${constants.headingPx}px
  headline that is tracking \`${constants.headingTrackingEm}\`, leading \`${constants.headingLeadingRatio}\`, weight
  \`${constants.headingWeight}\`.
  Collapsing to one generic sans, or flattening the display/body ratio, removes the template.
- **Corner.** The modal radius across visible boxes is **\`${constants.modalRadius}\`**
  (profile: ${constants.radiusProfile.map(([r, n]) => `\`${r}\`×${n}`).join(' · ')}). Do not round or
  square boxes against this — the corner is identity, not taste.
- **Colour.** The reference accent is \`${constants.accent}\`${constants.slab ? `, on a \`${constants.slab}\` deep band` : ''}.
  Replace the palette with \`node tools/palette.mjs\`; keep the *allocation* — how much of the page the
  accent touches, and whether the template uses a deep band at all.
- **Density.** ${constants.referenceWords} visible words in \`main\` across ${constants.sections} marked sections,
  ${constants.proseBlocks} \`.prose\` block(s) and ${constants.multiParagraphBlocks} multi-paragraph
  block(s); widest paragraph box ${constants.widestParagraphPx}px. These describe the reference, not a
  target — say what the brief supports and stop. A page padded to hit a word count reads like one.
- **Frame.** No horizontal overflow at 390px (reference: ${constants.mobileOverflow ? 'FAILS — fix before shipping' : 'clean'}).`;

const skillPath = join(dir, 'SKILL.md');
if (existsSync(skillPath)) {
  const skill = readFileSync(skillPath, 'utf8');
  const next = skill.replace(/<!-- MEASURED:BEGIN -->[\s\S]*?<!-- MEASURED:END -->/,
    `<!-- MEASURED:BEGIN -->\n${block}\n<!-- MEASURED:END -->`);
  writeFileSync(skillPath, next);
}

const metaPath = join(dir, 'template.json');
if (existsSync(metaPath)) {
  const meta = JSON.parse(readFileSync(metaPath, 'utf8'));
  meta.styleDNA = constants;
  writeFileSync(metaPath, JSON.stringify(meta, null, 2) + '\n');
}

console.log(`${constants.displayFace} / ${constants.bodyFace} · hero ${constants.heroRatioDesktop}x · ` +
  `radius ${constants.modalRadius} · accent ${constants.accent} · ${constants.referenceWords} words`);
