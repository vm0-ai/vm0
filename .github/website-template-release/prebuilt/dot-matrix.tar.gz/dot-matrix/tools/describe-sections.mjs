#!/usr/bin/env node
/* describe-sections.mjs — say what each section is made of, so nobody has to go and look.
 *
 *   node tools/describe-sections.mjs            # appends a detail block to sections/_index.md
 *
 * The manifest already carries size, word count, image count and geometry, and a run still spent
 * 41.5 minutes across eleven sites looking things up AFTER composing. Sorted by cost, what it went
 * looking for was:
 *
 *   what the JS does to this section   150 rounds  14.3 min  11/11 sites
 *   what slots the section has          43 rounds   5.4 min  10/11
 *   grid columns, spans, breakpoints    30 rounds   3.3 min   9/11
 *   which colours the skin hardcodes    14 rounds   1.8 min   6/11
 *
 * That is the list this file answers. Not "roughly what the section is for" — the run can read the
 * markup for that — but the facts that are NOT in the markup it composed: that `[data-cardgrid]`
 * hides every card past `data-batch` so a six-card grid ships showing three, that the marquee wraps
 * its own children in a track if you did not, that a tile's tint is a fixed hex the palette will not
 * reach. Every one of those was discovered mid-edit by at least one run.
 *
 * Everything here is derived — selectors matched in a real browser, attributes read out of the
 * script, hexes counted in the skin block. Nothing is described by hand. The one earlier attempt to
 * write such notes by hand went stale within two commits.
 */

import { readFileSync, writeFileSync, existsSync, readdirSync } from "fs";
import { join, resolve } from "path";
import { driver } from "./driver.mjs";

const dir = resolve(process.argv[2] || ".");
const man = join(dir, "sections", "_index.md");
if (!existsSync(man)) {
  console.error("no sections/_index.md — run tools/split-sections.mjs first");
  process.exit(2);
}

const js = existsSync(join(dir, "template.js"))
  ? readFileSync(join(dir, "template.js"), "utf8")
  : "";

/* ── the script, as blocks ────────────────────────────────────────────────
 * Each top-level `document.querySelectorAll('root')` starts a block that owns one device. Take the
 * root selector, the child selectors it queries, and the attributes it reads — those attributes are
 * the knobs, and they are exactly what a run cannot infer from the markup. */
// Two top-level shapes in these files: a bare `document.querySelectorAll('root').forEach(...)`, and
// an IIFE that does its own querying inside. Taking only the first shape found four blocks in
// warm-cards and missed the marquee, the sticky-scroll and the FAQ — the three that actually
// surprise a run. Split on either, then let the block's own first selector be its root.
const blocks = [];
const STARTS = /^(?:document\.querySelectorAll\(|\(function\s*\(\)\s*\{)/gm;
const at = [...js.matchAll(STARTS)].map((m) => m.index);
at.forEach((from, i) => {
  const body = js.slice(from, i + 1 < at.length ? at[i + 1] : js.length);
  const sels = [
    ...new Set(
      [...body.matchAll(/querySelector(?:All)?\('([^']+)'\)/g)].map(
        (m) => m[1],
      ),
    ),
  ];
  if (!sels.length) return;
  const knobs = [
    ...new Set(
      [...body.matchAll(/getAttribute\('(data-[^']+)'\)/g)].map((m) => m[1]),
    ),
  ];
  blocks.push({
    sel: sels[0],
    sels,
    knobs,
    reads: sels.slice(1),
    lines: body.split("\n").length,
  });
});

/* ── the skin blocks, for colours the palette will not reach ───────────── */
const skinFor = (file) => {
  if (!file || file === "—") return "";
  const f = join(dir, "sections", file.replace(/ \(shared\)$/, ""));
  return existsSync(f) ? readFileSync(f, "utf8") : "";
};
const hardHexes = (css) => {
  // A hex inside a `--token:` declaration is the template defining its own palette-independent tint;
  // that is the thing worth naming. A hex anywhere else is usually a shadow or a scrim.
  const out = new Set();
  for (const m of css.matchAll(/(--[\w-]+)\s*:\s*(#[0-9a-fA-F]{3,8})/g))
    out.add(`${m[1]}:${m[2]}`);
  return [...out];
};

const browser = await (
  await driver()
).launch({
  executablePath: [
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/google-chrome",
  ].find(existsSync),
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const page = await browser.newPage();
await page.setViewport({ width: 1440, height: 900 });
await page.goto(`file://${join(dir, "index.html")}`, {
  waitUntil: "load",
  timeout: 90000,
});

const facts = await page.evaluate(
  (blockSels) => {
    const out = [];
    for (const el of document.querySelectorAll("[data-section]")) {
      // The repeating unit: the child class that occurs most often at one level. A card grid is six
      // `.cg__card`; a marquee is twelve `.mo__item`. That count is the slot budget.
      const counts = {};
      for (const n of el.querySelectorAll("[class]")) {
        for (const c of n.classList) counts[c] = (counts[c] || 0) + 1;
      }
      const repeats = Object.entries(counts)
        .filter(([, n]) => n >= 3)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .map(([c, n]) => `.${c} ×${n}`);

      // One repeat's inner shape, so a run knows what it is filling in.
      const top = Object.entries(counts)
        .filter(([, n]) => n >= 3)
        .sort((a, b) => b[1] - a[1])[0];
      let shape = [];
      if (top) {
        const one = el.querySelector(`.${CSS.escape(top[0])}`);
        if (one) {
          const seen = [];
          for (const n of one.querySelectorAll("*")) {
            const t = n.tagName.toLowerCase();
            if (
              ["h1", "h2", "h3", "h4", "p", "img", "a", "li", "svg"].includes(t)
            )
              seen.push(t);
          }
          shape = [...new Set(seen)].map(
            (t) => `${t}×${seen.filter((x) => x === t).length}`,
          );
        }
      }

      const drivers = blockSels
        .filter((group) =>
          group.some((s) => {
            try {
              return el.querySelectorAll(s).length > 0 || el.matches(s);
            } catch {
              return false;
            }
          }),
        )
        .map((group) => group[0]);
      const knobsPresent = [
        ...new Set(
          [...el.querySelectorAll("*")]
            .flatMap((n) => [...n.attributes].map((a) => a.name))
            .filter((a) => a.startsWith("data-") && a !== "data-section"),
        ),
      ];

      out.push({
        kind: el.dataset.section,
        repeats,
        shape,
        drivers,
        knobsPresent,
      });
    }
    return out;
  },
  blocks.map((b) => b.sels),
);

await browser.close();

/* ── write ───────────────────────────────────────────────────────────────── */
let md = readFileSync(man, "utf8");
md = md.split("\n## What each section is made of")[0].trimEnd();

const rowFiles = [
  ...md.matchAll(/^\| `([^`]+)` \| ([^|]*)\|[^|]*\|([^|]*)\|/gm),
].map((m) => ({ id: m[1], skin: m[3].trim() }));

// A block that drives almost every section is not news about any one of them — the shared motion
// runner matched 20 of 21 sections and buried the card-grid's `data-batch` under nine selectors of
// its own. State it once, above the list; leave the per-section lines for what is specific.
const GLOBAL_AT = Math.max(3, Math.floor(facts.length * 0.7));
const driveCount = {};
for (const f of facts)
  for (const d of f.drivers) driveCount[d] = (driveCount[d] || 0) + 1;
const global = Object.entries(driveCount)
  .filter(([, n]) => n >= GLOBAL_AT)
  .map(([sel]) => sel);

const detail = facts
  .map((f, i) => {
    const row = rowFiles[i];
    const drives = f.drivers
      .filter((d) => !global.includes(d))
      .map((sel) => {
        const b = blocks.find((x) => x.sel === sel);
        const knobs = b.knobs.length ? ` reads ${b.knobs.join(", ")};` : "";
        const reads = b.reads.length
          ? ` queries ${b.reads.slice(0, 5).join(", ")}`
          : "";
        return `\`${sel}\` —${knobs}${reads}`;
      });
    const hard = hardHexes(skinFor(row?.skin));
    const lines = [`### \`${row?.id || f.kind}\``];
    if (f.repeats.length) lines.push(`- repeats: ${f.repeats.join(", ")}`);
    if (f.shape.length) lines.push(`- one repeat holds: ${f.shape.join(", ")}`);
    if (drives.length) lines.push(`- driven by: ${drives.join(" · ")}`);
    else lines.push("- driven by: nothing of its own");
    if (hard.length)
      lines.push(
        `- skin hardcodes: ${hard.slice(0, 8).join(", ")} (the palette will not reach these)`,
      );
    const knobs = f.knobsPresent.filter((k) =>
      blocks.some((b) => b.knobs.includes(k)),
    );
    if (knobs.length)
      lines.push(`- behaviour attributes present: ${knobs.join(", ")}`);
    return lines.join("\n");
  })
  .join("\n\n");

md += `

## What each section is made of

Derived by \`tools/describe-sections.mjs\` — selectors matched in a browser, knobs read out of
\`template.js\`, hexes counted in the skin block. Read this instead of opening \`template.js\` or the
stylesheet: the four things below are what eleven runs went hunting for after composing, and they
are the ones the markup you composed does not tell you.

A **knob** changes what ships. \`[data-cardgrid]\` hides every card past \`data-batch\`, so a grid you
filled with six cards renders three until you raise it or drop the control. **Hardcoded** tints are
fixed hexes in the skin; the palette does not reach them, so a colour system you picked will not
recolour those parts.

${
  global.length
    ? `Every section is also touched by ${global.map((x) => `\`${x}\``).join(", ")} — the shared
motion/reveal runner, which reads ${[...new Set(global.flatMap((x) => blocks.find((b) => b.sel === x)?.knobs || []))].join(", ") || "no attributes"}.
Listed once here; the lines below name only what is specific to one section.

`
    : ""
}${detail}
`;
writeFileSync(man, md);
console.log(
  `described ${facts.length} sections · ${blocks.length} script blocks → ${man}`,
);
