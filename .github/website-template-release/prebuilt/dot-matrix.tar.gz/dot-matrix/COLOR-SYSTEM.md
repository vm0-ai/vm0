# Colour

A palette is **six decisions per mode** — `bg · ink · accent · accent-ink · support-1 · support-2`.
Everything else derives from them, so a palette stays six values wide instead of fifteen.

```bash
node tools/palette.mjs --list                        # fourteen palettes, with when-to-use
node tools/palette.mjs --pick sand                   # prints the CSS to paste
node tools/palette.mjs --pick sand --seed "#E4002B"  # a brand colour replaces the accent
node tools/palette.mjs --check <six hex values>      # audit a palette you wrote yourself
```

Paste the printed blocks into `index.html`'s `<style data-brand-theme>`. That block is the only
place colour is decided; `template.css` reads colour exclusively through these roles, so rebinding
them restyles the whole page.

## The six derived roles

| role | how it is derived | what it is |
|---|---|---|
| `--surface` | 4% ink into bg | a raised card, just separated from the page |
| `--surface-2` | 8% ink into bg | a nested card |
| `--ink-soft` | 70% ink into bg | secondary text, captions, meta |
| `--border` | 13% ink into bg | hairlines and dividers |
| `--ring` | the accent | focus ring |
| `--support-1-ink` | whichever of black / white has higher contrast on support-1 | text on a support-1 chip or field |

Mixing **toward the background** is what lets one formula serve light and dark alike: 4% ink into
white lifts a card slightly darker than the page, and 4% ink into near-black lifts it slightly
lighter. No second set of rules for the dark theme, and no flip — a flip carries paper chroma onto a
dark ground, which is precisely why machine-generated dark themes look muddy.

An earlier tool derived *every* role from the seed hue instead. Every background, border and text
token came out tinted at near-zero chroma, and the result read as a grey design with a filter over
it. Six declared values and five mixes is both simpler and better.

## The deep band

`--slab`, `--slab-ink` and `--slab-accent` are not part of the six, because the band is not a mix of
them. Reusing the ink as a ground gives a flat near-black, and an accent that clears 4.5:1 on paper
routinely fails on it. The tool builds the band from the palette's own hue and then **solves** its
ink and accent against it. The band is dark in both modes, so its ink is light in both — mixing
toward `--bg` is right everywhere else and wrong here.

## The catalogue, and not using it

Fourteen curated palettes, ten authored light and four authored dark. Each one's counterpart mode is
built here — same hues, rebuilt lightness — and every one of the twenty-eight modes is checked by
`tools/palette.test.mjs`, never by eye.

**You are not required to use one.** Six values of your own, audited with `--check` against the same
rules, are equally welcome. Say why in `data-palette-reason`; a bespoke palette that earns its place
is a candidate for the catalogue.

## How to pick

1. **The brief pins a colour** → use it: `--pick <nearest palette> --seed "<the colour>"`. The seed replaces
   the accent and its ink is re-solved; the palette supplies the ground, the ink and the supports.
2. **Official brand evidence exists** (site, logo, product UI) → same, seeded from the evidence.
3. **Neither** → pick the catalogue entry whose `useWhen` matches the subject. Do not default to the
   first one.

Then declare the decision in the page so it can be checked:

```html
<html data-palette-source="prompt|brand-evidence|agent"
      data-palette-system="mint"
      data-palette-reason="A teaching studio whose subject is attention, not intensity; one green that stays quiet.">
```

## Three checks a contrast table cannot see

`palette.mjs` runs these itself and prints failures:

- **The card must separate from the page.** Direction is handled by mixing toward `--bg`; only the
  size of the difference is checked.
- **The band's own ink must clear 7:1 on the band**, and its accent 4.5:1. A light-mode accent that
  clears on paper routinely fails on a near-black band.
- **`--ink-soft` must clear 4.5:1 on both `--bg` and `--surface`.** 70% is a good default, not a
  guarantee: it is checked against the grounds it actually lands on, in both modes.
- **`--support-1-ink` must clear 4.5:1 on `--support-1`.** Support colours were originally treated
  as decoration only; Sticker Pop uses one as a real text ground, so the paired ink is solved rather
  than borrowed from the page or accent.

`node tools/palette.test.mjs` calibrates from both sides — all fourteen palettes come out clean in
both modes, and four palettes carrying defects seen in review each trip the specific rule that
exists to catch them. A threshold nothing can trip is not a threshold.

A ratio is still only a property of two colours. It says nothing about how much ink is on the page,
so a hairline serif at 5.2:1 can read washed out while a grotesk at 4.6:1 reads fine. The gate
cannot see that; a person can.

## The role vocabulary

Used throughout this template:

| role | what it is |
|---|---|
| `--bg` | page ground |
| `--ink` | body and heading text |
| `--ink-soft` | secondary text, captions, meta |
| `--accent` | the brand mark: links, primary buttons, indices, rules |
| `--accent-ink` | text that sits *on* `--accent` |
| `--support-1`, `--support-2` | second and third hues for charts, tags, tonal fields |
| `--support-1-ink` | contrast-solved text on a `--support-1` field |
| `--surface`, `--surface-2` | raised cards and nested cards |
| `--border` | hairlines and dividers |
| `--ring` | focus ring |
| `--slab` | the deep full-bleed band, when this template uses it |
| `--slab-ink`, `--slab-accent` | text and accent *on* the band |

## This is a reference, not a gate

Nothing reads `palette.mjs` output automatically. A palette pinned by the brief always wins, and a
designer's set always wins. What the tool buys you is a starting set that is internally consistent and
whose text roles have been solved rather than eyeballed — plus a report telling you which pair fails
if you deviate.

Two things it does *not* decide: `.soft`-style secondary text should be `color: inherit; opacity: .78`
rather than a hard-coded grey, so it survives on a coloured ground; and a colour that carries text at
4.5:1 in one theme has to be re-checked in the other.
