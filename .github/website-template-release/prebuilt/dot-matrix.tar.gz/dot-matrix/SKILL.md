# Dot Matrix — website template (agent operating guide)

> LED dot-matrix boards (distinct figures) · organic wordmark bleed · numbered service index w/ central spine + tag marquees

⚠ **This template does not work like the other ten.** Dot Matrix is a **different kind of template**: it owns 100% of
every section's structure *and* style, and it consumes a **different plan shape**. Read the plan shape
below carefully — a standard (`fn`/`args`) plan will not render here.

- **Motion personality:** kinetic · **Default theme:** dark
- **Full palette + per-section treatment:** read `template-dot-matrix.md`.
- **The designer's worked example:** open `example.html` — this is the look you are reproducing.

## Workflow

1. **Read the brief** and gather the real content.
2. **Compose the section list to fit the content** — choose which roles, in what order, and repeat any
   when it helps. Each role's `content` shape and the template's look are fixed; which roles and their
   order are yours. No specific direction from the user → use each role below at least once.
   `sample-plan.json` (every role once, in the example's order) is a starting point, not a cage.
3. **Render:** `node render.mjs plan.json out.html` — renders without any network image lookup and
   prints any **contract problems**. Media slots retain semantic metadata for you, the authoring AI,
   to select and insert the image.
4. **Choose and insert every visible image yourself.** For each slot, select the most suitable source
   among user-supplied images, relevant images in the user's source or reference material, and
   AI-generated images. There is no fixed source order. User-supplied assets are recommended when
   they fit, but they are not mandatory. Insert the final asset directly into the rendered `.media`
   element. Do not use stock-photo or image-search APIs.
5. **Revise by editing `out.html` directly.** `render.mjs` is for the initial HTML generation only.
   After the first render, never rerun it for revisions. Rerendering replaces the generated HTML and
   removes images you already inserted. Make every later content, layout, styling, and image change
   in `out.html` itself.
6. **Ship `out.html`.**

## Plan shape

Every section is `{ "id": "<role>", "content": { ... } }`. There is **no `fn`, no `args`, no
`sections` vs top-level split** — `nav` and `footer` are entries in `sections[]` like everything else.

```jsonc
{
  "title": "...", "desc": "...",
  "sections": [
    { "id": "nav",    "content": { "brand": "...", "links": [{"label":"...","href":"#why"}], "cta": {"label":"...","href":"#contact"} } },
    { "id": "hero",   "content": { "brand": "...", "eyebrow": "...", "title": "...", "lead": "...", "ctas": [{"label":"...","href":"#contact"}] } },
    { "id": "footer", "content": { "brand": "...", "title": "...", "tagline": "...", "lines": [{"h":"...","v":"..."}], "columns": [] } }
  ]
}
```

Note the hero takes **`brand` and `eyebrow`** — not the `wordmark`/`dots` the other skins use.
Image fields are named **`media`** here (not `photo`), and they are semantic image briefs just the same.

## The 16 content roles

`nav` · `hero` · `statement` · `feature` · `steps` · `stats` · `contact` · `logos` · `testimonial` · `pricing` · `faq` · `gallery` · `index` · `narrative` · `cta` · `footer`

| role | content |
|------|---------|
| `nav` | `brand`, `links[]: {label, href}`, `cta: {label, href}` |
| `hero` | `brand`, `(eyebrow)`, `title`, `(lead)`, `(ctas[])` — `title` may contain `<span class="pix">…</span>` for machine-emphasis |
| `statement` | `(eyebrow)`, `segments[]: {text, (emphasis)}` — word-by-word blur reveal; `emphasis` sets a word in mono |
| `logos` | `(label)`, `items[]: plain strings` |
| `steps` | `(heading)`, `(eyebrow)`, `(sub)`, `items[]: {title, body, media, tags[]}` — numbered automatically |
| `feature` | `(heading)`, `items[]: {eyebrow, title, body, media}` — full-bleed alternating rows |
| `stats` | `items[]: {value, label}` |
| `gallery` | `(heading)`, `items[]: {tag, meta, title, desc, media}` — a draggable rail |
| `index` | `(heading)`, `(sub)`, `items[]: {title, caption, media}` — numbered automatically |
| `narrative` | `(heading)`, `items[]: {eyebrow, title, body, caption, media}` |
| `testimonial` | `(heading)`, `quotes[]: {text, name, (role)}` — avatars are generated |
| `pricing` | `(heading)`, `(sub)`, `plans[]: {tier, price, unit, features[], popular}` |
| `faq` | `(heading)`, `items[]: {q, a}` |
| `contact` | `(title)`, `lines[]: {h, v}` — the form is built in |
| `cta` | `title`, `(sub)`, `cta: {label, href}` |
| `footer` | `brand`, `(title)`, `(tagline)`, `lines[]: {h, v}`, `columns[]: {title, links[]}` — this template closes with contact IN the footer |

`render.mjs` validates every section against its content contract and prints any problem it finds —
a missing required field is reported, not silently rendered empty. Fix reported problems before shipping.

## Rules — do not break these

- **Do not hand-author the initial layout HTML or CSS.** Use the template and `render.mjs` for the
  first render. After that, make every revision directly in `out.html`; never rerun the renderer.
- **`media` fields take a SEMANTIC IMAGE BRIEF**, such as `"designer laptop screens interface"`,
  not a URL, image bytes, provider, or model name. Use concrete nouns: subject + setting + light +
  mood. Use the brief yourself to choose or generate and insert the final asset.
- **Exactly one `<h1>`** — it comes from `hero`. Keep the hero in the plan.
- **Write real, specific copy — never lorem ipsum.**

## Images

`render.mjs` is intentionally model-agnostic and performs no image lookup, image generation,
network, or provider calls. You, the authoring AI, must choose the most suitable asset for each
`.media` element from user-supplied images, relevant images in the user's source or reference
material, or AI-generated images, then insert it directly yourself. There is no fixed source order;
user-supplied assets are recommended when they fit, but they are not mandatory. Preserve the slot's
classes, metadata, accessible label, and any nested controls when inserting the final image.
Image-generation model and provider instructions come from the prompt you receive and must never be
hard-coded in this bundle.

## What's in this bundle

```
SKILL.md            this file
template.json       machine-readable metadata
sample-plan.json    the starting plan — mirrors example.html
example.html        the designer's worked example (copied from source, never regenerated)
template-dot-matrix.mjsthe template: its own render() for every role, plus all its CSS
template-dot-matrix.mdthe template spec, in prose
render.mjs          the network-free entry point: plan.json -> out.html
engine/             compose.mjs (the renderer), the content contracts, and shared layers
```
