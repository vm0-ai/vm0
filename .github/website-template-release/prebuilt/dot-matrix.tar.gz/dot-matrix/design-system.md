# Dot Matrix — design system

Measured from the local `template.css` and `index.html`. These are facts about
the shipped stylesheet, not intentions. Where a value here disagrees with prose anywhere else, this
file is right.

## Character

> LED dot-matrix boards (distinct figures) · organic wordmark bleed · numbered service index w/ central spine + tag marquees



## Type

| | |
|---|---|
| Families loaded | `Bricolage Grotesque` · `Instrument Sans` · `Space Mono` |
| Display face | `'Bricolage Grotesque'` |
| Body face | `'Instrument Sans'` |
| Font personality flag | `data-fonts="dot-matrix"` |

Both faces are declared as tokens, so a brand type change is a two-line edit in
`style[data-brand-theme]` — not a find-and-replace through the stylesheet.

## Colour roles

The stylesheet reads colour only through these roles. Rebinding them in `style[data-brand-theme]`
restyles the whole page; writing a literal colour anywhere else forks it.

| role | light | dark |
|---|---|---|
| `--bg` | #FFFFFF | #070A14 |
| `--ink` | #0B1020 | #E8EBF5 |
| `--ink-soft` | #566075 | #969FB5 |
| `--accent` | #3B3BE0 | #8C8CFF |
| `--accent-ink` | #FFFFFF | #06060F |
| `--support-1` | — | #2DD4BF |
| `--support-2` | — | #FF8A4C |
| `--surface` | #F4F4F5 | #151822 |
| `--surface-2` | #EAEBEC | #20232D |
| `--border` | #DADBDE | #343741 |
| `--ring` | #3B3BE0 | #8C8CFF |
| `--slab` | #05070E | #040404 |

Generate a replacement set with `node tools/palette.mjs --pick <system>`; use `--list` to choose and `--check` to audit bespoke values.
The values above are the reference page's own palette; they are a demonstration, not a requirement.

## Structural tokens

| token | value |
|---|---|
| `--board-bg` | #090C16 |
| `--dm-lit` | #ECEDFF |
| `--dm-lit2` | #6E6EF6 |
| `--dm-off` | rgba(232,235,255,.09) |
| `--fb` | 'Instrument Sans' |
| `--fd` | 'Bricolage Grotesque' |
| `--fm` | 'Space Mono' |
| `--grid-line` | color-mix(in srgb,var(--ink) 12%,transparent) |
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |
| `--radius` | 16px |

**Spacing scale** — `--space-2`=.5rem · `--space-3`=.75rem · `--space-4`=1rem · `--space-5`=1.5rem · `--space-6`=2rem · `--space-7`=3rem · `--space-8`=4rem · `--space-9`=6rem · `--space-10`=8rem



## Motion

| token | value |
|---|---|
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |

Motion personality: `kinetic`. `template.js` binds the reveals, the marquee, the
disclosure widgets, the theme toggle and the mobile nav. Reveals must degrade to visible content —
never hide a whole section behind an IntersectionObserver.

## Device vocabulary

Class prefixes that carry layout in the reference page, by frequency. Compose from these; a class
that is not here has no stylesheet behind it, and inventing one produces an unstyled bare tag.

`.on`×54 · `.small`×28 · `.mono`×26 · `.muted`×24 · `.container`×23 · `.media`×19 · `.h2`×17 · `.xseg`×16 · `.h3`×16 · `.section`×14 · `.eyebrow`×10 · `.lead`×10 · `.btn`×7 · `.v0`×6 · `.num`×4 · `.v1`×4 · `.v2`×4 · `.v3`×4 · `.btn-primary`×3 · `.btn-ghost`×3 · `.pix`×3 · `.alt`×3 · `.sec-h`×3 · `.tmc`×3 · `.theme-toggle`×2 · `.skip`×1 · `.nav`×1 · `.theme-toggle--nav`×1 · `.hero`×1 · `.display`×1 · `.bs`×1 · `.lg`×1 · `.marq`×1 · `.st`×1

## Reference density

The reference page carries **924 visible words** across its sections. That is a description
of this example, not a target. Say what the brief supports and stop — a page padded to reach a
word count reads like one, and the reader can tell.
