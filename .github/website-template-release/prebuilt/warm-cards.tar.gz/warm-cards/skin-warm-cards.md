# Skin: `warm-cards` — warm co-living, a soft card mosaic

Learned the LANGUAGE of a young co-living site (left numbered colour-block sidebar, content packed
into rounded CARDS that fill the screen, amenity tickers, a horizontal card rail, a giant wordmark
footer) and re-expressed it in our own, gentler terms. Source discarded; everything concrete is
ORIGINAL (palette, brand `COMMONS`, all copy). Fonts: Archivo + Hanken Grotesk.

## Palette — hand-tuned HARMONIOUS (no catalogue, no saturated primaries, **no AI-yellow**)
Warm greige ground `#EBE6DD`; paper cards `#FAF6EF`; ink `#2C2822` / soft `#5E554A`; terracotta
accent `#A85A38`. Card tints (dark ink): periwinkle `#C7D2E0` · apricot `#E7BBA2` · blush `#EBCBC2`
· rose `#DCB4AE` · sage `#C6D2B9` · teal `#B6CFC9` · lavender `#D6CBE0`. Deep grounds (cream text):
espresso `#2E2A24` · pine `#31463C`. Dual-mode: warm near-black ground, tint cards keep light
grounds + dark ink.

## Layout system (Tong taste passes)
- **Flat** — NO card shadows; paper cards carry a hairline `--u-line`, tint cards pop by colour.
- **Tight, equal spacing** — one token `--u-gut clamp(.75–1.05rem)` is BOTH the page side-padding
  AND every card gap. Radii pulled in to `clamp(12–16px)`.
- **Everything in cards, filling the width, no full-bleed bands** — amenity strip, stats and CTA
  are inset cards; feature rows, steps, FAQ and contact are paper cards. FAQ/contact use
  `max-width:calc(100% - 2*gut)` so their left/right padding matches every other section.
- **Image hero** — a big photo card with a soft diagonal dark wash; headline **top-left**, lead +
  CTAs **bottom-right**. Stage carries a solid espresso ground (legible + gate-safe pre-image).
- **Card rail** (card-grid) — **full-bleed to the screen edge** (`margin-inline:-gut`), scrollbar
  hidden, filter tabs and ‹ › arrows matched at 44px with centred glyphs.
- **Footer** — plain: giant wordmark + columns, no grid lines / colour cells.

## Gate — PASS
`skinsheet-units.html` and `demo-commons.html` both pass full (4 bp × 2 themes · contrast ·
type-floor · dual-mode) **and** `--site`.

## Reusable gotchas
- Fixed left rail narrows `main` → pin plain `repeat(n,1fr)` grids to `minmax(0,1fr)`.
- Inset a `width:100%` `.container`/marquee with `max-width:calc(100% - 2*gut)`, NOT `margin-inline`.
- Hero over a photo → give the stage a solid dark ground (the gate drops the scrim's alpha).
- Soft palette → darken `--ink-soft`/`--accent` until `.lead`/skip clear 4.5:1 on the pale ground.
- `.cf__ok` shows only on submit → add `.cf__ok[hidden]{display:none}` (a `display` rule otherwise
  overrides the `hidden` attribute).

## Build
`node build-demo-units.mjs` → `demo-commons.html` (original COMMONS content) — file kept in this folder.

## Live
_Skinsheet is a SELF-CONTAINED file (images + webfonts inlined; renders correctly offline / in Drive preview)._

- COMMONS demo (original content): https://commons-coliving-715f6d07-a861dfb8.sites.vm0.io
- Skinsheet (all-15 gate proof): https://warm-cards-sheet-715f6d07-cb27508c.sites.vm0.io
