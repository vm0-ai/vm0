/* skin-units.mjs — A skin. We LEARNED THE LANGUAGE of a young co-living site (left numbered
 * colour-block sidebar as the header, content packed into big rounded CARDS that fill the screen,
 * amenity tickers, a horizontal card rail, a giant wordmark footer) and RE-EXPRESSED it in our own,
 * gentler terms. Everything concrete is ORIGINAL: a HARMONIOUS hand-tuned warm palette (dusty
 * tonal pastels + two deep grounds — NOT a saturated primary set, NOT the catalogue system), our
 * own warm ground, our licensed fonts (Archivo / Hanken Grotesk), and 100% original demo copy/brand.
 * Design notes (Tong, 2026-07-01): smaller radii · softer, coordinated colour · a big IMAGE hero
 * with a light dark wash and text in the top-left + bottom-right corners · CONTENT LIVES IN CARDS
 * that fill the browser width — no full-bleed bands (the amenity strip is a card too).
 * Prove: build-skinsheet → full + --site. */
export const skin = {
  id:'warm-cards',
  fontsAttr:'warm-cards', motionAttr:'playful',
  fontLink:'<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800;900&family=Hanken+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">',
  contactBg:'sunlit modern co-living lounge with plants and people',
  cardLayout:'rail',        // inherit the canonical rail geometry from base .cg--rail (never hand-write it)
  signature:'left numbered colour-block sidebar · content packed into soft rounded cards filling the screen · image hero with corner-set text · amenity ticker card · giant wordmark footer',
  css:`
/* ① COLOURS — a HARMONIOUS hand-tuned warm palette (dusty tonal pastels that coordinate, plus two
   deep grounds), not a saturated primary set. Tints are light → dark ink clears AA on all of them;
   deep grounds carry cream text. Ground is a soft warm greige so the pale cards separate. Dual-mode. */
:root{
  --bg:#EBE6DD; --surface:#FAF6EF; --surface-2:#EFE9DE;
  --ink:#2C2822; --ink-soft:#5E554A;
  --accent:#A85A38; --accent-ink:#FFFFFF;                  /* warm terracotta — links/focus only */
  --support-1:#31463C; --support-2:#B4623F;
  --border:#E1D8C7; --ring:#B4623F;
  /* the card palette — dusty, coordinated (a warm tonal family + soft cool counterpoints) */
  --u-sky:#C7D2E0; --u-apricot:#E7BBA2; --u-blush:#EBCBC2; --u-rose:#DCB4AE;
  --u-sage:#C6D2B9; --u-teal:#B6CFC9; --u-lavender:#D6CBE0;
  --u-espresso:#2E2A24; --u-pine:#31463C; --u-cream:#F6F0E4;   /* deep grounds + their text */
  --u-dark-ink:#2C2822;                                        /* fixed dark ink for tint cards (theme-independent) */
  /* ② fonts + personality levers (radii pulled IN — corners are tighter now) */
  --fd:'Archivo'; --fb:'Hanken Grotesk'; --radius:14px; --container:var(--w-full);
  --u-round:clamp(12px,1.1vw,16px);        /* card corner radius (smaller) */
  --u-rail:clamp(208px,17vw,264px);         /* left sidebar width (desktop) */
  --u-line:1px solid var(--border);         /* soft hairline */
  --u-shadow:none;/* flat — no card shadows */
  --u-grid:rgba(44,40,34,.09);
  --u-gut:clamp(0.75rem,1.4vw,1.05rem);     /* page padding == card gap (tight, equal) */
  --cg-pad:clamp(1.1rem,2vw,1.4rem);        /* uniform card inner padding */
}
html[data-theme="dark"]{
  --bg:#191510; --surface:#231E16; --surface-2:#2B2419;
  --ink:#F1E7D6; --ink-soft:#B3A794;
  --accent:#E0895F; --accent-ink:#160E08;
  --support-1:#7FB59A; --support-2:#E0895F;
  --border:#39311F; --ring:#E0895F;
  --u-shadow:none;
  --u-grid:rgba(241,231,214,.10);
  /* tint cards keep their light grounds + fixed dark ink on both themes (they pop on dark too) */
}

/* ── shared chrome ─────────────────────────────────────────────────────────── */
html{overflow-x:clip}                       /* clip sub-pixel spill w/o breaking the sticky pin */
body{font-family:var(--fb),system-ui,sans-serif}
.display,h1,.h1,h2,.h2,h3,.h3,.ft__name,.steps__num,.stats__num,.pr__amt{
  font-family:var(--fd);font-weight:800;letter-spacing:-.02em}
.display{font-weight:900;font-size:clamp(2.4rem,5.6vw,4.6rem);line-height:.98;letter-spacing:-.03em}
h2,.h2{font-weight:800;letter-spacing:-.025em}
.lead{color:var(--ink-soft)}
/* a wider, comfortable gutter so cards never touch the screen edge (fills, but never "通栏") */
:root{--gutter:var(--u-gut)}
/* eyebrow → a soft tinted pill (own solid ground → always legible, even over an image) */
.eyebrow{display:inline-block;align-self:flex-start;width:fit-content;background:var(--surface-2);color:var(--ink);border:var(--u-line);
  border-radius:var(--r-pill);padding:.4rem .9rem;font-family:var(--fd);font-weight:700;font-size:.8rem;
  letter-spacing:.02em;text-transform:none;line-height:1.1}
.section{padding-block:clamp(1.4rem,3vw,2.6rem)}   /* compact vertical rhythm */
.sec-head{text-align:left;margin-inline:0;max-width:34ch}
.sec-head .lead{margin-top:var(--space-3)}
/* the left rail narrows main → pin every plain repeat(n,1fr) grid to minmax(0,1fr) */
@media(min-width:640px){.fg__grid:not(.fg--bento){grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(min-width:760px){.tm--cards .tm__grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media(min-width:820px){.pr__grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media(min-width:960px){.fg__grid:not(.fg--bento){grid-template-columns:repeat(var(--fg-cols,3),minmax(0,1fr))}}
/* buttons → pill, softened; primary = soft ink, ghost = hairline */
.btn{border-radius:var(--r-pill);font-family:var(--fd);font-weight:700;font-size:1rem;padding:.8rem 1.4rem;border-width:1.5px}
.btn-primary{background:var(--ink);color:var(--bg);border-color:var(--ink)}
.btn-ghost{background:transparent;color:var(--ink);border-color:var(--ink)}
.btn:hover{transform:translateY(-2px)}
/* a shared SOFT CARD look (rounded, hairline, gentle shadow) — the whole page is built from these */
.fg__card,.tm__card,.cg__card,.pr__card,.it__tile,.fs__row,.steps__item,.faq__wrap,.cf__wrap,.stats__grid,.cta__panel,.logos__marquee{
  border-radius:var(--u-round)}

/* generic flooded-dark ground remap */
[data-ground="dark"]{--bg:#191510;--ink:#F1E7D6;--ink-soft:#B3A794;--surface:#231E16;
  --surface-2:#2B2419;--border:#39311F}

/* ③ FULL RESTYLE — the 15 sections, now as a soft CARD MOSAIC ═════════════════════════════════ */

/* 1 · NAV — left numbered colour-block sidebar (softer tints; smaller radius). */
.nav{background:transparent;border:0}
.nav__bar{gap:var(--space-4)}
.nav__brand{font-family:var(--fd);font-weight:900;font-size:1.8rem;letter-spacing:-.045em;line-height:.9}
.nav__brand::after{content:".";color:var(--accent)}
.nav__links{counter-reset:u-nav}
.nav__links a{position:relative;display:flex;flex-direction:column;justify-content:flex-end;
  min-height:88px;padding:.8rem .95rem;border-radius:var(--u-round);color:var(--u-dark-ink);font-family:var(--fd);
  font-weight:700;font-size:1rem;line-height:1.12;text-decoration:none;box-shadow:var(--u-shadow)}
.nav__links a::before{counter-increment:u-nav;content:"0" counter(u-nav);font-size:.9rem;font-weight:700;opacity:.7;margin-bottom:auto}
.nav__links a::after{content:"↗";position:absolute;top:.65rem;right:.85rem;font-size:1.05rem;opacity:.8}
.nav__links li:nth-child(4n+1) a{background:var(--u-espresso);color:var(--u-cream)}
.nav__links li:nth-child(4n+2) a{background:var(--u-sky)}
.nav__links li:nth-child(4n+3) a{background:var(--u-apricot)}
.nav__links li:nth-child(4n+4) a{background:var(--u-sage)}
.nav__links a:hover{transform:translateY(-2px)}
.nav__cta{background:var(--u-espresso);color:var(--u-cream);border-color:var(--u-espresso)}
.nav__cta:hover{transform:translateY(-2px)}
@media(min-width:768px){
  body>header#top{position:fixed;inset:0 auto 0 0;width:var(--u-rail);z-index:100;
    background:var(--bg);border-right:var(--u-line);overflow-y:auto}
  main#main,body>footer{margin-left:var(--u-rail)}
  .nav__bar{flex-direction:column;align-items:stretch;justify-content:flex-start;min-height:100vh;padding:var(--space-5) var(--space-4)}
  .nav__burger{display:none!important}
  .nav__menu{flex:1;flex-direction:column;align-items:stretch;gap:var(--space-3);margin-top:var(--space-5)}
  .nav__links{flex-direction:column;gap:var(--space-3)}
  .nav__cta{margin-top:auto}
}

/* 2 · HERO — see heroHTML(). A big IMAGE card with a soft dark wash; text sits in the TOP-LEFT and
   BOTTOM-RIGHT corners (a diagonal composition). The stage carries a solid espresso ground so the
   cream text is legible + gate-safe even before the photo loads. */
.hero{padding-block:clamp(1.2rem,2.4vw,2rem)}
.hero__stage{position:relative;border-radius:var(--u-round);overflow:hidden;background:var(--u-espresso);
  min-height:clamp(440px,74vh,720px);display:flex;box-shadow:var(--u-shadow)}
.hero__media{position:absolute;inset:0;width:100%;height:100%;border:0;border-radius:0;aspect-ratio:auto;margin:0}
.hero__media>img{width:100%;height:100%;object-fit:cover}
.hero__scrim{position:absolute;inset:0;pointer-events:none;
  background:linear-gradient(135deg,rgba(22,17,12,.62) 0%,rgba(22,17,12,.14) 38%,rgba(22,17,12,.08) 60%,rgba(22,17,12,.66) 100%)}
.hero__tl,.hero__br{position:relative;z-index:2;max-width:min(60ch,42%)}
.hero__grid{position:relative;z-index:2;width:100%;padding:clamp(1.4rem,3vw,2.6rem);display:flex;flex-direction:column;justify-content:space-between;gap:var(--space-6)}
.hero__tl{align-self:flex-start}
.hero__br{align-self:flex-end;text-align:right;margin-left:auto}
.hero .display{color:var(--u-cream);margin-top:var(--space-3)}
.hero__br .lead{color:rgba(246,240,228,.92)}
.hero__cta{display:flex;flex-wrap:wrap;gap:var(--space-3);margin-top:var(--space-4);justify-content:flex-end}
.hero__cta .btn-primary{background:var(--u-cream);color:var(--u-espresso);border-color:var(--u-cream)}
.hero__cta .btn-ghost{color:var(--u-cream);border-color:rgba(246,240,228,.7)}
@media(max-width:720px){
  .hero__tl,.hero__br{max-width:100%}
  .hero__br{text-align:left;margin-left:0}
  .hero__cta{justify-content:flex-start}
}

/* 3 · FEATURE-SPLIT — each row is now a big PAPER CARD (text + image inside). */
.fs__heading{font-size:clamp(1.7rem,3.4vw,2.6rem);max-width:24ch}
.fs__rows{gap:var(--u-gut)}
.fs__row{background:var(--surface);border:var(--u-line);padding:clamp(1.4rem,3vw,2.4rem);align-items:center}
.fs__text{display:flex;flex-direction:column}
.fs__icon{width:54px;height:54px;border:0;border-radius:12px;background:var(--u-sky);color:var(--u-dark-ink);margin-bottom:var(--space-4)}
.fs__row:nth-child(4n+2) .fs__icon{background:var(--u-lavender)}
.fs__row:nth-child(4n+3) .fs__icon{background:var(--u-sage)}
.fs__row:nth-child(4n+4) .fs__icon{background:var(--u-apricot)}
.fs .media{border:0;border-radius:var(--u-round);aspect-ratio:5/4}
.fs__text .lead{color:var(--ink-soft)}

/* 4 · FEATURE-GRID — the core card mosaic: soft dusty tints, dark ink, small radius. */
.fg__grid{gap:var(--u-gut)}
.fg__card{border:0;box-shadow:var(--u-shadow);padding:clamp(1.3rem,2.2vw,1.9rem);color:var(--u-dark-ink);
  display:flex;flex-direction:column;gap:.7rem;min-height:190px;overflow-wrap:anywhere}
.fg__card:nth-child(6n+1){background:var(--u-sky)}
.fg__card:nth-child(6n+2){background:var(--u-sage)}
.fg__card:nth-child(6n+3){background:var(--u-lavender)}
.fg__card:nth-child(6n+4){background:var(--u-apricot)}
.fg__card:nth-child(6n+5){background:var(--u-teal)}
.fg__card:nth-child(6n+6){background:var(--u-blush)}
.fg__card .h3{color:inherit;font-size:1.3rem}
.fg__card p,.fg__card .muted{color:inherit;opacity:.86}
.fg__icon{border:0;background:rgba(44,40,34,.12);color:var(--u-dark-ink);border-radius:11px;width:50px;height:50px}
.fg--bento .fg__card{justify-content:space-between}
@media(min-width:760px){.fg__grid.fg--bento{grid-template-columns:repeat(4,minmax(0,1fr))}}

/* 5 · LOGOS → the amenity ticker, now an INSET CARD (not a full-bleed band). */
.logos{padding-block:clamp(1rem,2.4vw,1.8rem)}
.logos--wall{--w:var(--w-full)}
.logos__marquee{max-width:calc(100% - 2*var(--u-gut));margin-inline:auto;background:var(--u-espresso);color:var(--u-cream);
  padding:1rem 1.4rem;overflow:clip;box-shadow:var(--u-shadow)}
.logos__item{font-family:var(--fd);font-weight:700;font-size:1.15rem;color:var(--u-cream);opacity:1;
  letter-spacing:0;display:inline-flex;align-items:center}
.logos__item::after{content:"◆";margin-inline:1.3rem;font-size:.6rem;opacity:.6}
.tm--marquee{overflow:clip}
.tm__marquee{padding-block:2px}

/* 6 · STATS → an INSET dark CARD (espresso), cream numbers — not a full-bleed band. */
.stats{padding-block:clamp(1rem,2.4vw,1.8rem)}
.stats__grid{max-width:calc(100% - 2*var(--u-gut));background:var(--u-pine);color:var(--u-cream);
  padding:clamp(1.8rem,4vw,3rem);box-shadow:var(--u-shadow);gap:var(--space-6)}
.stats__num{color:var(--u-cream);font-size:clamp(2.2rem,5vw,3.4rem)}
.stats__cell .small,.stats__cell .muted{color:rgba(246,240,228,.86)}

/* 7 · STEPS — a row of soft numbered CARDS. */
.steps__list{gap:var(--u-gut);grid-template-columns:1fr}
@media(min-width:760px){.steps__list{grid-template-columns:repeat(3,minmax(0,1fr))}}
.steps__item{flex-direction:column;align-items:flex-start;background:var(--surface);border:var(--u-line);
  padding:clamp(1.3rem,2.4vw,2rem);gap:var(--space-4)}
.steps__num{width:50px;height:50px;border-radius:12px;font-size:1.1rem;color:var(--u-dark-ink);background:var(--u-sky)}
.steps__item:nth-child(3n+2) .steps__num{background:var(--u-sage)}
.steps__item:nth-child(3n+3) .steps__num{background:var(--u-lavender)}
.steps__item .muted{color:var(--ink-soft)}

/* 8 · TESTIMONIAL — soft tinted quote cards + a scrolling wall. */
.tm__grid{gap:var(--u-gut)}
.tm__card{border:0;box-shadow:var(--u-shadow);color:var(--u-dark-ink);padding:clamp(1.4rem,2.4vw,2rem)}
.tm--cards .tm__card:nth-child(3n+1){background:var(--u-blush)}
.tm--cards .tm__card:nth-child(3n+2){background:var(--u-sky)}
.tm--cards .tm__card:nth-child(3n+3){background:var(--u-sage)}
.tm--marquee .tm__card:nth-child(4n+1){background:var(--u-apricot)}
.tm--marquee .tm__card:nth-child(4n+2){background:var(--u-lavender)}
.tm--marquee .tm__card:nth-child(4n+3){background:var(--u-teal)}
.tm--marquee .tm__card:nth-child(4n+4){background:var(--u-sage)}
.tm__quote{font-family:var(--fd);font-weight:700;font-size:1.15rem;line-height:1.32}
.tm__name{color:var(--u-dark-ink)}
.tm__card .muted,.tm__card .small{color:var(--u-dark-ink);opacity:.72}
.tm__avatar{border:0}

/* 9 · PRICING — soft paper plan cards, ruled feature rows, an accent "pop" plan. */
.pr__grid{gap:var(--u-gut)}
.pr__card{border:var(--u-line);box-shadow:var(--u-shadow);background:var(--surface);gap:var(--space-3)}
.pr__card--pop{background:var(--u-sky);border-color:transparent;color:var(--u-dark-ink)}
.pr__card--pop *{color:var(--u-dark-ink)}
.pr__badge{background:var(--u-espresso);color:var(--u-cream);border-radius:var(--r-pill)}
.pr__amt{font-size:clamp(2rem,3.6vw,2.7rem)}
.pr__feats{gap:0}
.pr__feats li{padding:.65rem 0;border-bottom:var(--u-line);color:var(--ink-soft)}
.pr__card--pop .pr__feats li{color:var(--u-dark-ink);opacity:.9;border-color:rgba(44,40,34,.18)}
.pr__feats li::before{display:none}
.pr__card--pop .pr__cta{background:var(--u-espresso);color:var(--u-cream);border-color:var(--u-espresso)}

/* 10 · FAQ — the whole accordion in ONE paper card; ruled rows inside. */
.faq__h{text-align:left;font-size:clamp(1.7rem,3.4vw,2.6rem)}
.faq__wrap{max-width:calc(100% - 2*var(--u-gut));background:var(--surface);border:var(--u-line);padding:clamp(1.4rem,3vw,2.4rem)}
.faq__item{border-bottom:var(--u-line)}
.faq__item:last-of-type{border-bottom:0}
.faq__q{font-family:var(--fd);font-weight:800;font-size:clamp(1.05rem,1.8vw,1.3rem);padding:var(--space-4) 0}
.faq__item[open] .faq__icon{color:var(--accent)}
.faq__a .muted{color:var(--ink-soft)}

/* 11 · CONTACT-FORM — the form in a paper card; soft rounded fields. */
.cf{padding:0;margin-inline:var(--u-gut);margin-block:clamp(1.2rem,2.6vw,2.2rem);background:var(--surface);border:var(--u-line);border-radius:var(--u-round);overflow:hidden;display:grid;grid-template-columns:1.12fr .88fr;align-items:stretch}
.cf__wrap{max-width:none;margin:0;background:transparent;border:0;border-radius:0;padding:clamp(1.6rem,3vw,2.6rem);grid-column:1;grid-row:1}
.cf__bg{grid-column:2;grid-row:1;align-self:stretch;width:100%;height:100%;min-height:100%;aspect-ratio:auto;border:0;border-radius:0;margin:0;background:var(--surface-2)}
.cf__bg img{width:100%;height:100%;object-fit:cover}
@media(max-width:760px){.cf{grid-template-columns:1fr}.cf__wrap{grid-row:1;grid-column:1}.cf__bg{grid-row:2;grid-column:1;min-height:200px}}
.cf .sec-head{text-align:left;margin-inline:0}
.cf__form{max-width:680px}
.cf__field input,.cf__field textarea{border:var(--u-line);border-radius:12px;background:var(--bg);padding:.9rem 1rem;font-size:1rem}
.cf__field span{font-family:var(--fd);font-weight:700}
.cf__form>.btn{align-self:flex-start;background:var(--u-espresso);color:var(--u-cream);border-color:var(--u-espresso)}
.cf__ok{color:var(--u-dark-ink);background:var(--u-sage);display:inline-block;padding:.4rem .8rem;border-radius:var(--r-pill)}
.cf__ok[hidden]{display:none}

/* 12 · CARD-GRID — horizontal scroll-snap rail of soft cards; round controls. */
.cg .sec-head{text-align:left;margin-inline:0}
.cg__tabs{justify-content:flex-start}
.cg__tab{border:var(--u-line);border-radius:var(--r-pill);color:var(--ink);background:var(--surface);font-family:var(--fd);font-weight:700;min-height:44px;display:inline-flex;align-items:center}
.cg__tab[aria-pressed="true"]{background:var(--ink);color:var(--bg);border-color:var(--ink)}
.cg__grid.cg--rail{gap:var(--u-gut)}   /* rail geometry comes from base .cg--rail; skin only sets the gap + card colour */
.cg__card{border:0;box-shadow:var(--u-shadow);
  color:var(--u-dark-ink);padding:var(--cg-pad);overflow:hidden;display:flex;flex-direction:column;gap:.5rem;transition:transform .18s ease}
.cg__card:nth-child(6n+1){background:var(--u-apricot)}
.cg__card:nth-child(6n+2){background:var(--u-lavender)}
.cg__card:nth-child(6n+3){background:var(--u-teal)}
.cg__card:nth-child(6n+4){background:var(--u-sage)}
.cg__card:nth-child(6n+5){background:var(--u-sky)}
.cg__card:nth-child(6n+6){background:var(--u-blush)}
.cg__card:hover{transform:translateY(-3px)}
/* media bleeds to card edges. Card is a flex COLUMN → a flex item stretch caps width at the
   CONTENT box and a negative right margin will NOT widen it (white gap on the right). Give it an
   explicit full-card width so it truly fills edge-to-edge. */
.cg__media{aspect-ratio:16/11;border-radius:0;border:0;width:calc(100% + 2*var(--cg-pad));max-width:none;
  margin:calc(-1*var(--cg-pad)) calc(-1*var(--cg-pad)) var(--cg-pad)}
.cg__top,.cg__title,.cg__role,.cg__link{padding-inline:0}
.cg__top{margin-top:0}
.cg__title{margin-top:.35rem;color:var(--u-dark-ink)}
.cg__tag{background:var(--u-espresso);color:var(--u-cream);border:0;border-radius:var(--r-pill);padding:.25rem .7rem}
.cg__meta,.cg__role{color:var(--u-dark-ink);opacity:.72}
.cg__link{color:var(--u-dark-ink);font-weight:700;padding-bottom:0;margin-top:auto}
.cg__nav{display:inline-flex;align-items:center;justify-content:center;position:absolute;top:-60px;width:44px;height:44px;padding:0;
  border-radius:var(--r-pill);background:var(--ink);color:var(--bg);border:0;cursor:pointer;font-size:1.25rem;line-height:1;z-index:2}
.cg__nav--prev{right:52px}.cg__nav--next{right:0}
.cg__railwrap{position:relative;padding-top:8px}
.cg__more{border:var(--u-line);color:var(--ink);background:var(--surface)}

/* 13 · INDEX-TILES — photo tiles, softened (hairline, small radius, honey index). */
.it__grid{gap:var(--u-gut)}
.it__tile{border-radius:var(--u-round);border:0;box-shadow:var(--u-shadow)}
.it__num{color:var(--u-sky)}
.it__tile:nth-child(4n+2) .it__num{color:var(--u-sage)}
.it__tile:nth-child(4n+3) .it__num{color:var(--u-apricot)}
.it__tile:nth-child(4n+4) .it__num{color:var(--u-lavender)}

/* 14 · CTA — an inset deep PINE card, cream text, round arrow. */
.cta__panel{background:var(--u-pine);color:var(--u-cream);border:0;box-shadow:var(--u-shadow);max-width:calc(100% - 2*var(--u-gut))}
.cta__title,.cta__sub{color:var(--u-cream)}
.cta__sub{opacity:.9}
.cta__btn{background:var(--u-cream);color:var(--u-pine);border-color:var(--u-cream)}

/* 15 · FOOTER — the giant wordmark on a soft graph-paper grid with dusty colour cells. */
body>footer{background:var(--bg);border-top:var(--u-line);position:relative;overflow:hidden}
body>footer::before{content:none}
body>footer>*{position:relative;z-index:1}
.ft__grid{grid-template-columns:1.2fr 1fr 1fr 1fr}
.ft__brand{grid-column:1/-1;margin-bottom:var(--space-4)}
.ft__name{font-family:var(--fd);font-weight:900;font-size:clamp(2.6rem,10vw,6.6rem);line-height:.84;letter-spacing:-.045em;overflow-wrap:anywhere}
.ft__name::after{content:".";color:var(--accent)}
.ft__brand .small{color:var(--ink-soft)}
.ft__h{font-family:var(--fd);font-weight:800}
.ft__col a{color:var(--ink-soft)}.ft__col a:hover{color:var(--ink)}
.ft__bottom{border-top:var(--u-line);padding-top:var(--space-4)}

/* ── sticky-scroll (skinsheet): pinned panels + gallery, skin-dressed ── */
.ss__heading{font-size:clamp(1.7rem,3.4vw,2.6rem)}
.ss__media{border:0;border-radius:var(--u-round);box-shadow:var(--u-shadow)}
.ss__eyebrow{display:none}
.ss__panel .lead{color:var(--ink-soft)}

/* ── theme toggle + misc chrome ── */
.theme-toggle{border:var(--u-line);border-radius:var(--r-pill);background:var(--surface);color:var(--ink);font-family:var(--fd);font-weight:700}
.theme-toggle:hover{background:var(--surface-2)}
.card{border-radius:var(--u-round);box-shadow:var(--u-shadow)}
`,
  /* 2 · HERO — the SIGNATURE. A big IMAGE card with a soft dark wash; text set into the TOP-LEFT
     (eyebrow + headline) and BOTTOM-RIGHT (lead + CTA) corners. Tagged data-signature. */
  heroHTML({wordmark, title, lead, dots=[], ctas=[], photo}={}){
    const btns = (ctas||[]).map((c,i)=>`<a class="btn ${i===0?'btn-primary':'btn-ghost'}" href="${c.href}">${c.label}</a>`).join('');
    const tag = (dots&&dots.length? dots.slice(0,2).join(' · ') : 'Co-living, done warmly');
    const ph = photo || 'bright airy co-living lounge with warm light and people';
    return `<section class="section hero" data-section="hero" data-variant="split" data-signature="units-hero">
      <div class="container">
        <div class="hero__stage">
          <div class="media hero__media" data-photo="${ph}" role="img" aria-label="${title||wordmark}"></div>
          <div class="hero__scrim" aria-hidden="true"></div>
          <div class="hero__grid">
            <div class="hero__tl">
              <p class="eyebrow" data-motion="reveal-fade">${tag}</p>
              <h1 class="display" data-motion="reveal-up">${title||wordmark}</h1>
            </div>
            <div class="hero__br">
              ${lead?`<p class="lead" data-motion="reveal-up">${lead}</p>`:''}
              ${btns?`<div class="hero__cta" data-motion="reveal-up">${btns}</div>`:''}
            </div>
          </div>
        </div>
      </div></section>`;
  }
};
