# Sticker Pop — design system

Measured from the local `template.css` and `index.html`. These are facts about
the shipped stylesheet, not intentions. Where a value here disagrees with prose anywhere else, this
file is right.

## Character

> warm cream + pine-teal/honey/coral pop · fat outlined display serif · coral handwritten-script accents · STICKER cards (hard ink border + offset shadow) · circle photos always above cards · pinned cross-fading story panels beside a scrolling gallery (sticky-scroll)



## Type

| | |
|---|---|
| Families loaded | `Fraunces` · `Figtree` · `Caveat` |
| Display face | `'Fraunces'` |
| Body face | `'Figtree'` |
| Font personality flag | `data-fonts="pantry"` |

Both faces are declared as tokens, so a brand type change is a two-line edit in
`style[data-brand-theme]` — not a find-and-replace through the stylesheet.

## Colour roles

The stylesheet reads colour only through these roles. Rebinding them in `style[data-brand-theme]`
restyles the whole page; writing a literal colour anywhere else forks it.

| role | light | dark |
|---|---|---|
| `--bg` | #F8F8F5 | #0E1A18 |
| `--ink` | #1E2620 | #F1E8D4 |
| `--ink-soft` | #57605A | #BFB29A |
| `--accent` | #0E7C6B | #2FC4AC |
| `--accent-ink` | #F8F8F5 | #0E1A18 |
| `--support-1` | #EFA12E | #FFC24D |
| `--support-2` | #E2533B | #FF7E63 |
| `--surface` | #FFFFFF | #15211F |
| `--surface-2` | #ECEFEA | #1C2A27 |
| `--border` | #DDE2DC | #2C3A37 |
| `--ring` | #0E7C6B | #2FC4AC |

Generate a replacement set with `node tools/palette.mjs --pick <system>`; use `--list` to choose and `--check` to audit bespoke values.
The values above are the reference page's own palette; they are a demonstration, not a requirement.

## Structural tokens

| token | value |
|---|---|
| `--container` | var(--w-wide) |
| `--dz-line` | #1E2620 |
| `--dz-script` | #E2533B |
| `--fb` | 'Figtree' |
| `--fd` | 'Fraunces' |
| `--fx-aurora-1` | 12s |
| `--fx-aurora-2` | 14s |
| `--fx-aurora-3` | 16s |
| `--fx-aurora-blur` | 90px |
| `--fx-aurora-opacity` | .5 |
| `--fx-grain-opacity` | .05 |
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |
| `--radius` | 8px |

**Spacing scale** — `--space-2`=.5rem · `--space-3`=.75rem · `--space-4`=1rem · `--space-5`=1.5rem · `--space-6`=2rem · `--space-7`=3rem · `--space-8`=4rem · `--space-9`=6rem · `--space-10`=8rem



## Motion

| token | value |
|---|---|
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |

Motion personality: `playful`. `template.js` binds the reveals, the marquee, the
disclosure widgets, the theme toggle and the mobile nav. Reveals must degrade to visible content —
never hide a whole section behind an IntersectionObserver.

## Device vocabulary

Class prefixes that carry layout in the reference page, by frequency. Compose from these; a class
that is not here has no stylesheet behind it, and inventing one produces an unstyled bare tag.

`.muted`×47 · `.small`×35 · `.h3`×28 · `.h2`×25 · `.mono`×22 · `.media`×21 · `.container`×20 · `.section`×19 · `.body`×19 · `.lead`×16 · `.eyebrow`×11 · `.btn`×10 · `.sec-head`×10 · `.btn-primary`×5 · `.btn-ghost`×4 · `.theme-toggle`×2 · `.fg`×2 · `.fs`×2 · `.fs--rev`×2 · `.ss`×2 · `.tm`×2 · `.skip`×1 · `.nav`×1 · `.theme-toggle--nav`×1 · `.dz-hero`×1 · `.dz-outline`×1 · `.logos`×1 · `.logos--wall`×1 · `.fg--cards`×1 · `.fg--bento`×1 · `.fs--even`×1 · `.fs--media-wide`×1 · `.stats`×1 · `.steps`×1

## Reference density

The reference page carries **1229 visible words** across its sections. That is a description
of this example, not a target. Say what the brief supports and stop — a page padded to reach a
word count reads like one, and the reader can tell.
