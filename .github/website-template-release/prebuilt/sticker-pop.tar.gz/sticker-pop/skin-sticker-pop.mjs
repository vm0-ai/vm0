/* skin-drizzle.mjs — learned from a bold American CPG / food-brand site.: the *essence* is the STRUCTURE, not the paint — so the source's pinned-narrative
 * (left content cross-fades in place while a right gallery scrolls) is captured as the real
 * `stickyScroll` section (promoted into sections.mjs), and the palette is re-mapped to a
 * DISTINCT, same-character set (we learn the language, not the brand's exact red+yellow).
 *
 * Register: PLAYFUL PANTRY-POP — warm cream grounds, a **pine-teal** brand colour with
 * **honey + coral** pops (NOT the source's red/amber), a fat characterful DISPLAY SERIF with
 * OUTLINED (stroke) hero/cta headlines, a friendly grotesque body, coral HANDWRITTEN-SCRIPT
 * accents, and the unifying STICKER look (hard 2px ink border + offset drop-shadow, pop-on-hover),
 * with CIRCLE photos that sit ALWAYS above a card's top edge. Motion = playful. (skin-contract.md)
 */
export const skin = {
  id:'sticker-pop',
  fontsAttr:'pantry', motionAttr:'playful',
  fontLink:'<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;0,9..144,900;1,9..144,600&family=Figtree:wght@400;500;600;700&family=Caveat:wght@600;700&display=swap" rel="stylesheet">',
  signature:'warm cream + pine-teal/honey/coral pop · fat outlined display serif · coral handwritten-script accents · STICKER cards (hard ink border + offset shadow) · circle photos always above cards · pinned cross-fading story panels beside a scrolling gallery (sticky-scroll)',
  /* no parallax: this template's images are STATIC by design (opt-in lever, intentionally omitted) */
  contactBg:'fresh ingredients flat lay on a warm wooden table',
  css:`
/* ① COLOURS — warm cream · pine-teal brand · honey + coral pops (re-mapped, NOT the source's red/amber) */
:root{--bg:#F8F8F5;--ink:#1E2620;--ink-soft:#57605A;--accent:#0E7C6B;--accent-ink:#F8F8F5;
  --support-1:#EFA12E;--support-2:#E2533B;--surface:#FFFFFF;--surface-2:#ECEFEA;
  --border:#DDE2DC;--ring:#0E7C6B;--radius:8px;--container:var(--w-wide);
  --fd:'Fraunces';--fb:'Figtree';
  --dz-line:#1E2620;            /* sticker border/shadow ink (light) */
  --dz-bubble:#EFA12E;          /* speech-bubble fill (honey) */
  --dz-bubble-ink:#1E2620;
  --dz-script:#E2533B;          /* coral handwritten-script accent */
  --dz-brand:#0E7C6B;           /* FIXED deep-teal flood ground (cream text = AA in BOTH themes;
                                   the --accent ROLE flips for small accents/buttons, the grounds don't) */
  --dz-sticker:4px 4px 0 var(--dz-line);
  --fx-grain-opacity:.05}
html[data-theme="dark"]{--bg:#0E1A18;--ink:#F1E8D4;--ink-soft:#BFB29A;--accent:#2FC4AC;
  --accent-ink:#0E1A18;--support-1:#FFC24D;--support-2:#FF7E63;--surface:#15211F;
  --surface-2:#1C2A27;--border:#2C3A37;--ring:#2FC4AC;
  --dz-line:#070D0C;--dz-bubble:#FFC24D;--dz-bubble-ink:#1E2620;--dz-script:#FF8A6E;--dz-brand:#0C6B5C}

/* ② TYPE — fat soft serif display · friendly grotesque body · coral script accents ----------- */
body{font-family:var(--fb);letter-spacing:.005em}
.display,h1,.h1,h2,.h2,h3,.h3{font-family:var(--fd);font-weight:900;letter-spacing:-.015em;font-optical-sizing:auto}
h2,.h2{font-size:clamp(2.1rem,5vw,3.6rem);line-height:1.03}
h3,.h3{font-weight:600;font-size:clamp(1.2rem,1.8vw,1.55rem)}
.lead{font-family:var(--fb);font-size:clamp(1.05rem,1.4vw,1.28rem);line-height:1.6;color:var(--ink-soft);text-wrap:balance}
.eyebrow{font-family:'Caveat',cursive;text-transform:none;letter-spacing:0;font-weight:700;
  font-size:clamp(1.3rem,2vw,1.7rem);color:var(--dz-script);line-height:1}
.small,.muted,.mono{font-family:var(--fb)}
.mono{letter-spacing:.04em}

/* outlined display (cream fill + ink stroke) — hero & cta only; fill is FIXED-light so it clears
   AA on its dark/colour backing in BOTH themes (the gate reads fill, not stroke) */
.dz-outline{color:#FBFBF7;-webkit-text-stroke:2.5px var(--dz-line);paint-order:stroke fill;
  text-shadow:var(--dz-sticker)}

/* buttons → solid sticker "tags": ink border + hard offset shadow, pill, pop on press ---------- */
.btn{font-family:var(--fb);font-weight:700;letter-spacing:.01em;border-radius:999px;
  border:2px solid var(--dz-line);box-shadow:var(--dz-sticker);transition:transform .12s ease,box-shadow .12s ease}
.btn:hover{transform:translate(2px,2px);box-shadow:2px 2px 0 var(--dz-line)}
.btn-primary{background:var(--accent);color:var(--accent-ink)}
.btn-ghost{background:var(--support-1);color:var(--dz-bubble-ink)}

/* shared sticker card */
.fg__card,.tm__card,.pr__card,.cg__card{background:var(--surface);border:2px solid var(--dz-line);
  border-radius:var(--radius);box-shadow:var(--dz-sticker);
  transition:transform .14s ease,box-shadow .14s ease}
.fg__card:hover,.cg__card:hover,.pr__card:hover{transform:translate(-2px,-2px);box-shadow:6px 6px 0 var(--dz-line)}
/* all media images fill their box via object-fit (so STATIC, non-parallax images still cover cleanly) */
.media>img{width:100%;height:100%;object-fit:cover;display:block}

/* custom grounds */
[data-ground="dark"]{--bg:#0E1A18;--ink:#F1E8D4;--ink-soft:#D2C6AE;--surface:#15211F;
  --surface-2:#1C2A27;--border:#2C3A37;--dz-line:#000;background:#0E1A18;color:#F1E8D4;position:relative}
[data-ground="dark"] .stats__num{color:var(--support-1)}

/* ③ per-section restyle --------------------------------------------------------------------- */
/* 1 nav */
.nav{background:color-mix(in srgb,var(--bg) 92%,transparent);backdrop-filter:blur(8px);border-bottom:2px solid var(--dz-line)}
.nav__brand{font-family:var(--fd);font-weight:900;font-size:1.5rem;letter-spacing:-.02em}
.nav__links a{font-family:var(--fb);font-weight:600;font-size:.95rem}

/* 5 logos — teal SCROLLING LOGO WALL (continuous marquee, no label) */
.logos{background:var(--dz-brand);border-block:2px solid var(--dz-line);text-align:center}
.logos--wall{padding-block:clamp(1.5rem,3vw,2.4rem);--mo-marq:34s}
.logos__marquee .logos__item{flex:none;font-family:var(--fd);font-weight:900;font-size:clamp(1.3rem,2.4vw,1.9rem);
  color:#FBFBF7;opacity:.95;display:inline-flex;align-items:center;white-space:nowrap}
.logos__marquee .logos__item::after{content:"✦";margin-left:2rem;color:var(--support-1);font-size:.8em;opacity:.9}
.logos__label{font-family:'Caveat',cursive;font-weight:700;font-size:1.5rem;color:#FBFBF7;
  text-transform:none;letter-spacing:0;display:block;width:100%;text-align:center;opacity:1}
.logos__row{justify-content:center;gap:clamp(1.2rem,3vw,2.6rem);margin-top:var(--space-3)}
.logos__row .logos__item{font-family:var(--fd);font-weight:900;font-size:1.25rem;color:#FBFBF7;opacity:.92}

/* 3 feature-split — framed sticker media; titles serif */
.fs__row{gap:clamp(2rem,5vw,5rem);align-items:center}
.fs--media-wide .fs__row,.fs--text-wide .fs__row{grid-template-columns:1fr 1fr}
.fs__icon{color:var(--accent);border:2px solid var(--dz-line);border-radius:999px;box-shadow:2px 2px 0 var(--dz-line)}
.fs__text h2,.fs__text h3{font-family:var(--fd)}
.fs .media{border:2px solid var(--dz-line);border-radius:var(--radius);box-shadow:var(--dz-sticker);overflow:hidden}

/* THE ESSENCE — sticky-scroll: pinned cross-fading panels + scrolling sticker gallery + coral caption */
.ss{background:var(--surface-2)}
.ss__heading{font-family:var(--fd);font-weight:900}
.ss__eyebrow{display:inline-flex;align-items:center;justify-content:center;min-width:46px;height:46px;
  padding:0 .5rem;background:var(--support-1);color:var(--dz-bubble-ink);border:2px solid var(--dz-line);
  border-radius:999px;box-shadow:2px 2px 0 var(--dz-line);font-family:var(--fd);font-weight:900;font-size:1.3rem;margin-bottom:var(--space-3)}
.ss__title{font-family:var(--fd);font-weight:900}
.ss__media{border:2px solid var(--dz-line);border-radius:var(--radius);box-shadow:var(--dz-sticker)}
.ss__cap{font-family:'Caveat',cursive;font-weight:700;font-size:1.4rem;text-transform:none;letter-spacing:0;color:var(--dz-script)}

/* 4 feature-grid — sticker cards, honey icon badge */
.fg__icon{display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;border-radius:999px;
  background:var(--support-1);color:var(--dz-bubble-ink);border:2px solid var(--dz-line);box-shadow:2px 2px 0 var(--dz-line)}
.fg__card{padding:clamp(1.4rem,2.6vw,2rem)}
.fg__card h3{font-family:var(--fd);font-weight:900}

/* 6 stats — each metric inside a CREAM STICKER CARD (pops on the dark band) */
.stats__grid{grid-template-columns:repeat(auto-fit,minmax(min(160px,100%),1fr));gap:clamp(1.2rem,3vw,1.8rem)}
.stats__cell{background:#FFFFFF;border:2px solid #1E2620;border-radius:var(--radius);box-shadow:4px 4px 0 #1E2620;
  padding:clamp(1.4rem,3vw,2rem) clamp(1rem,2vw,1.4rem)}
.stats__num{font-family:var(--fd);font-weight:900;font-size:clamp(2.6rem,6vw,4.4rem);line-height:.9;color:var(--dz-brand);overflow-wrap:anywhere}
.stats .stats__cell .small{font-family:'Caveat',cursive;font-size:1.3rem;text-transform:none;letter-spacing:0;color:#57605A}
[data-ground="dark"] .stats__num{color:var(--dz-brand)}    /* keep deep teal on the cream card (AA on both themes) */

/* 7 steps — round honey sticker numerals */
.steps__item h3{font-family:var(--fd)}
.steps__num{font-family:var(--fd);font-weight:900;font-size:1.4rem;color:var(--dz-bubble-ink);
  background:var(--support-1);width:52px;height:52px;border-radius:999px;border:2px solid var(--dz-line);
  box-shadow:var(--dz-sticker);display:flex;align-items:center;justify-content:center;flex:none}

/* 8 testimonial — sticker speech-bubbles (honey) on a teal ground, gentle scatter (no overlap),
   big outlined heading on TOP, ✦ sparkle doodles. Avatars = circular cut-outs. ------------- */
.tm{background:var(--dz-brand);position:relative;overflow:hidden}
.tm::before,.tm::after{content:"✦";position:absolute;color:var(--support-1);opacity:.9;pointer-events:none}
.tm::before{top:8%;left:5%;font-size:clamp(1.4rem,3vw,2.4rem);transform:rotate(-8deg)}
.tm::after{bottom:9%;right:6%;font-size:clamp(2rem,4vw,3.2rem);transform:rotate(12deg)}
.tm .sec-head{margin-bottom:var(--space-7)}
.tm .sec-head h2{font-family:var(--fd);font-weight:900;text-align:center;
  font-size:clamp(2.6rem,7vw,5.2rem);line-height:1;color:#FBFBF7;
  -webkit-text-stroke:2px var(--dz-line);paint-order:stroke fill;text-shadow:4px 4px 0 rgba(0,0,0,.22)}
.tm__grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(290px,100%),1fr));
  gap:clamp(1.6rem,3vw,2.4rem) clamp(1.4rem,3vw,2.2rem);align-items:start}
.tm__card{background:var(--dz-bubble);color:var(--dz-bubble-ink);border:2px solid var(--dz-line);
  border-radius:var(--radius);box-shadow:var(--dz-sticker);padding:clamp(1.4rem,2.4vw,1.9rem);position:relative}
.tm__card::after{content:"";position:absolute;left:34px;bottom:-15px;width:22px;height:22px;
  background:var(--dz-bubble);border-right:2px solid var(--dz-line);border-bottom:2px solid var(--dz-line);transform:rotate(45deg)}
.tm__card:nth-child(2n){margin-top:clamp(1rem,2.5vw,2rem)}      /* gentle stagger, never overlapping */
@media(min-width:760px){
  .tm__card:nth-child(3n+1){transform:rotate(-1deg)}
  .tm__card:nth-child(3n+3){transform:rotate(1deg)}
}
.tm__quote{font-family:var(--fb);font-weight:500;font-size:clamp(1rem,1.4vw,1.15rem);line-height:1.45;color:var(--dz-bubble-ink)}
.tm__by{margin-top:var(--space-4)}
.tm__avatar{width:52px;height:52px;border-radius:999px;border:2px solid var(--dz-line);object-fit:cover}
.tm__name{font-family:var(--fd);font-weight:900;color:var(--dz-bubble-ink)}
.tm__by .small.muted{color:var(--dz-bubble-ink);opacity:.78}
/* marquee variant → honey ticker, surface cards */
.tm--marquee{background:var(--support-1)}
.tm--marquee .sec-head h2{color:var(--dz-bubble-ink);-webkit-text-stroke:0;text-shadow:none;font-size:clamp(2rem,5vw,3.2rem)}
.tm--marquee .tm__card{background:var(--surface);color:var(--ink)}
.tm--marquee .tm__card::after{background:var(--surface)}
.tm--marquee .tm__quote{color:var(--ink)}
.tm--marquee .tm__name{color:var(--ink)}
.tm--marquee .tm__by .small.muted{color:var(--ink-soft);opacity:1}
.tm--marquee .tm__marquee{padding-block:1.8rem 2.4rem}
.tm--marquee .tm__card{transform:none!important;margin-top:0!important}
.tm--marquee .tm__card::after{display:none}
.tm--marquee .tm__card{justify-content:flex-start}
.tm--marquee .tm__quote{flex:0 0 auto}
.tm--marquee .tm__by{margin-top:auto}

/* 9 pricing — sticker "menu" cards; popular = honey pop + script badge */
.pr__card{padding:clamp(1.6rem,3vw,2.2rem)}
.pr__card--pop{background:var(--support-1);color:var(--dz-bubble-ink);transform:translateY(-6px)}
.pr__card--pop .pr__amt,.pr__card--pop h3,.pr__card--pop .small,.pr__card--pop .muted,.pr__card--pop li,.pr__card--pop .pr__feats *{color:var(--dz-bubble-ink)}
.pr__amt{font-family:var(--fd);font-weight:900;font-size:clamp(2.4rem,4vw,3.2rem)}
.pr__badge{font-family:'Caveat',cursive;font-weight:700;font-size:1.2rem;text-transform:none;letter-spacing:0;
  background:var(--support-2);color:#FBFBF7;border:2px solid var(--dz-line);border-radius:999px;
  padding:.2rem .9rem;display:inline-flex;align-items:center;line-height:1.1;white-space:nowrap}

/* 10 faq — 2-COLUMN: heading pinned left, accordion fills right (no dead blank half) --------- */
.faq__wrap{max-width:var(--w-wide)}
.faq__h{font-family:var(--fd);font-weight:900;text-align:left}
@media(min-width:880px){
  .faq__wrap{display:grid;grid-template-columns:.8fr 1.2fr;gap:clamp(2.5rem,6vw,5rem);align-items:start}
  .faq__h{margin-bottom:0;position:sticky;top:96px}
}
.faq__item{border-bottom:2px solid var(--border)}
.faq__q{font-family:var(--fd);font-weight:600;font-size:clamp(1.15rem,2vw,1.5rem)}
.faq__icon{color:var(--accent)}
.faq__a .body{font-family:var(--fb);color:var(--ink-soft)}

/* 11 contact-form — a cream sticker card on a teal ground (form text on cream = AA) */
.cf{background:var(--dz-brand);position:relative;overflow:hidden}
.cf__bg{position:absolute;inset:0;z-index:0;opacity:.18;border:0;border-radius:0;box-shadow:none}
.cf__wrap{position:relative;z-index:1;background:var(--surface);border:2px solid var(--dz-line);border-radius:var(--radius);
  box-shadow:6px 6px 0 var(--dz-line);padding:clamp(1.8rem,4vw,3rem);max-width:56rem;margin-inline:auto}
.cf h2{font-family:var(--fd);font-weight:900}
.cf__field span{font-family:var(--fb);font-weight:600;font-size:.85rem;color:var(--ink-soft)}
.cf__field input,.cf__field textarea{font-family:var(--fb);width:100%;background:var(--bg);
  border:2px solid var(--dz-line);border-radius:var(--radius);color:var(--ink)}
.cf__field input{height:52px}.cf__field textarea{height:140px;resize:none}

/* 12 card-grid — the RECIPE RAIL: horizontal sticker cards, each with a CIRCLE photo ALWAYS
   sitting above the card's top edge (never hover-revealed) ------------------------------------ */
.cg .container{max-width:none}
.cg__tabs{justify-content:center;border:0;gap:.6rem;flex-wrap:wrap}
.cg__tab{font-family:var(--fb);font-weight:600;border:2px solid var(--dz-line);border-radius:999px;
  background:var(--surface);box-shadow:2px 2px 0 var(--dz-line);padding:.35rem 1rem}
.cg__tab[aria-pressed="true"]{background:var(--accent);color:var(--accent-ink)}
.cg__grid{display:flex;grid-template-columns:none;gap:clamp(1.4rem,3vw,2.6rem);overflow-x:auto;overflow-y:visible;
  margin-inline:calc(-1 * var(--gutter));padding:78px var(--gutter) 2.4rem;
  scroll-snap-type:x mandatory;scroll-padding-inline:var(--gutter);scrollbar-width:none}
.cg__grid::-webkit-scrollbar{display:none}
.cg__card{position:relative;flex:0 0 clamp(248px,72vw,294px);scroll-snap-align:center;overflow:visible;
  padding:clamp(1.3rem,2.4vw,1.7rem);padding-top:78px;text-align:center;margin-top:60px}
/* circle photo pinned to ITS OWN card (position:relative above), ALWAYS visible, popping above the top edge */
.cg__media{width:132px;height:132px;border-radius:999px;border:3px solid var(--dz-line);
  box-shadow:var(--dz-sticker);overflow:hidden;position:absolute;top:-60px;left:50%;transform:translateX(-50%);
  aspect-ratio:1/1;margin:0;background:var(--surface-2);display:block!important}    /* ALWAYS visible */
.cg__media>img{width:100%;height:100%;object-fit:cover}
.cg__nav{display:flex;align-items:center;justify-content:center;position:absolute;top:56%;transform:translateY(-50%);z-index:3;width:52px;height:52px;border-radius:999px;background:var(--surface);color:var(--ink);border:2px solid var(--dz-line);box-shadow:var(--dz-sticker);font-family:var(--fd);font-size:1.7rem;line-height:1;cursor:pointer;transition:box-shadow .12s}
.cg__nav:hover{box-shadow:2px 2px 0 var(--dz-line)}
.cg__nav--prev{left:6px}.cg__nav--next{right:6px}
@media(max-width:600px){.cg__nav{display:none}}
.cg__top{justify-content:center;gap:.6rem;margin-top:.2rem}
.cg__tag{font-family:'Caveat',cursive;font-weight:700;font-size:1.15rem;text-transform:none;letter-spacing:0;color:var(--dz-script);border:0;padding:0}
.cg__meta{font-family:var(--fb);font-weight:600;font-size:.8rem;color:var(--ink-soft)}
.cg__title{font-family:var(--fd);font-weight:900;font-size:1.3rem}
.cg__role{color:var(--ink-soft)}
.cg__link{font-family:var(--fb);font-weight:700;color:var(--accent);justify-content:center}
.cg__morewrap{display:none}

/* 13 index-tiles — sticker photo plates, coral script caption, big serif numeral */
.it__grid{gap:clamp(1.4rem,3vw,2.4rem)}
.it__tile{border:2px solid var(--dz-line);border-radius:var(--radius);box-shadow:var(--dz-sticker)}
.it__num{font-family:var(--fd);font-weight:900;font-size:1.4rem}
.it__title{font-family:var(--fd);font-weight:900}
.it__cap{font-family:'Caveat',cursive;font-weight:700;font-size:1.2rem;text-transform:none;letter-spacing:0}

/* 14 cta — bold teal band, giant OUTLINED headline, sticker button + ✦ sparkles */
.cta{position:relative;overflow:hidden;padding-inline:var(--gutter)}
.cta .container{padding-inline:clamp(1.25rem,5vw,3.5rem)}
.cta__panel{background:var(--dz-brand);border:2px solid var(--dz-line);border-radius:18px;box-shadow:6px 6px 0 var(--dz-line);
  position:relative;overflow:hidden}
.cta__panel::before,.cta__panel::after{content:"✦";position:absolute;color:var(--support-1);opacity:.9}
.cta__panel::before{top:14%;left:7%;font-size:2rem;transform:rotate(-10deg)}
.cta__panel::after{bottom:16%;right:9%;font-size:2.8rem;transform:rotate(14deg)}
.cta h2{font-family:var(--fd);font-weight:900;font-size:clamp(2.2rem,5vw,4rem);color:#FBFBF7;
  -webkit-text-stroke:2px var(--dz-line);paint-order:stroke fill;text-shadow:4px 4px 0 rgba(0,0,0,.22)}
.cta__sub{font-family:var(--fb);color:#FBFBF7;font-weight:500;opacity:.96}
.cta__btn,.cta .btn{background:var(--support-1);color:var(--dz-bubble-ink)}

/* 15 footer */
.ft__name{font-family:var(--fd);font-weight:900;font-size:1.8rem}
.ft__brand .small{font-family:'Caveat',cursive;font-size:1.2rem;text-transform:none;letter-spacing:0;color:var(--ink-soft)}
.ft__h{font-family:var(--fb);font-weight:700;letter-spacing:.02em;color:var(--ink)}
.ft__col a{font-family:var(--fb);font-size:.9rem}
`,
  heroHTML({wordmark='YUM', title='Good On Everything', lead='', dots=[], ctas=[]}){
    const btns = (ctas.length?ctas:[{label:'Shop now',href:'#cta'}])
      .map((c,i)=>`<a class="btn ${i===0?'btn-primary':'btn-ghost'}" href="${c.href}">${c.label}</a>`).join('');
    return `<section class="section dz-hero" data-section="hero" data-variant="split-pop" data-width="full" data-signature="drizzle-split-hero">
      <div class="dz-hero__half dz-hero__brand">
        <div class="dz-hero__ghostwrap" aria-hidden="true"><div class="dz-hero__ghost">${(wordmark+' ').repeat(8)}</div></div>
        <div class="dz-hero__brandinner" data-motion="reveal-up">
          <p class="eyebrow">${dots.join(' · ')||'The original'}</p>
          <p class="dz-hero__lead">${lead||'From the first drizzle to the last drop.'}</p>
          <div class="dz-hero__cta">${btns}</div>
        </div>
      </div>
      <div class="dz-hero__half dz-hero__photo">
        <div class="dz-hero__imgwrap" aria-hidden="true"><div class="dz-hero__img media" data-photo="messy delicious overstacked sandwich close up"></div></div>
        <h1 class="dz-hero__head dz-outline" data-motion="reveal-up">${title}</h1>
      </div>
    </section>
    <style>
      /* REBUILT hero (visual unchanged, big headline restored). Clipping is now STRUCTURALLY
         impossible: neither the hero nor either half uses overflow:hidden, so nothing that holds
         text (buttons, headline) can ever be cut. The ONLY two clipping boxes are the decorative
         LAYERS — the ghost wordmark and the bg image — each clipping ITSELF inside its own wrap.
         All text lives in normal padded flow, never pinned against a clipping edge. */
      /* padding:0 overrides the base .section{padding-block} so the hero is FULL-BLEED top-to-bottom
         (no cream bands above/below); the coloured halves fill the whole section */
      .dz-hero{display:grid;grid-template-columns:1fr 1fr;gap:0;padding:0;min-height:clamp(560px,86vh,840px);border-bottom:3px solid var(--dz-line)}
      .dz-hero__half{position:relative;display:flex;flex-direction:column;min-width:0}
      .dz-hero__brand{background:var(--dz-brand);color:var(--accent-ink);justify-content:center;padding:clamp(2.4rem,5vw,4.5rem)}
      .dz-hero__ghostwrap{position:absolute;inset:0;overflow:hidden;pointer-events:none;user-select:none}
      .dz-hero__ghost{font-family:var(--fd);font-weight:900;font-size:clamp(3rem,8.5vw,6.5rem);line-height:.86;color:rgba(0,0,0,.12);word-break:break-word;overflow-wrap:anywhere;padding:.3em;text-transform:uppercase}
      .dz-hero__brandinner{position:relative;z-index:1;max-width:32rem}
      .dz-hero__brandinner .eyebrow{color:#FBFBF7}
      .dz-hero__lead{font-family:var(--fd);font-weight:600;font-size:clamp(1.4rem,2.4vw,2.1rem);line-height:1.15;margin:var(--space-3) 0 var(--space-5);color:#FBFBF7}
      .dz-hero__cta{display:flex;gap:.8rem;flex-wrap:wrap}
      /* RIGHT photo half: intentional 3px ink divider; image clips itself; the BIG headline sits at
         the bottom in padded flow — its own padding keeps text + stroke + sticker-shadow off every edge */
      .dz-hero__photo{background:#0C1614;border-left:3px solid var(--dz-line);justify-content:flex-end}
      .dz-hero__imgwrap{position:absolute;inset:0;z-index:0;overflow:hidden}
      .dz-hero__img{position:absolute;inset:0;width:100%;height:100%;border:0;border-radius:0;box-shadow:none;padding:0}
      .dz-hero__img>img{width:100%;height:100%;object-fit:cover}
      .dz-hero__imgwrap::after{content:"";position:absolute;inset:0;background:linear-gradient(0deg,rgba(0,0,0,.62),rgba(0,0,0,.12) 70%)}
      .dz-hero__head{position:relative;z-index:2;margin:0;padding:clamp(2rem,5vw,3.6rem);color:#FBFBF7;font-size:clamp(2.8rem,6vw,5.4rem);line-height:1.07;-webkit-text-stroke:3px var(--dz-line);overflow-wrap:anywhere}
      @media (max-width:860px){.dz-hero{grid-template-columns:1fr}.dz-hero__photo{min-height:52vh;border-left:0;border-top:3px solid var(--dz-line)}}
    </style>`;
  }
};
