# Skin: `sticker-pop` — playful pantry-pop (learned from a food-brand site)

**Essence.** A bold small-batch food/CPG voice. The identity is **structural + material**, not just
colour: pinned-narrative storytelling, sticker-material cards, circle-on-card recipes, big outlined
display type, handwritten-script accents. Motion = **playful**.

> **** Three things changed from the first cut:
> 1. **Structure over paint.** The source's signature interaction — *left content pinned and
>    cross-fading in place while a right gallery scrolls up* — is now a **real section**
>    (`stickyScroll`, promoted into `sections.mjs`), used normally **and** mirrored (`reverse`).
>    This is the essence; a skin must change structure, not only restyle.
> 2. **Palette de-cloned.** We learn the *language*, not the brand's exact colours. The red+amber
>    was too close to the source, so the skin is re-mapped to a **distinct** same-character set:
>    **pine-teal brand + honey + coral** on warm cream.
> 3. **Bug fixes.** Hero halves both sharp + an intentional 3px ink divider (no bug-seam) + roomy
>    outlined title; circle-on-card photos **always present** (not hover); FAQ is **2-column**
>    (no dead blank half); testimonial bubbles use a clean non-overlapping stagger; **real photos**
>    applied (no empty placeholders) via `apply-photos`.

**Palette (dual-mode, re-mapped — NOT the source's red/amber).**
- Light: bg cream `#F7EFDC` · ink `#211C14` · **accent pine-teal `#0E7C6B`** · support-1 honey
  `#EFA12E` · support-2 coral `#E2533B` · fixed brand-flood `--dz-brand #0E7C6B`.
- Dark: bg `#0E1A18` · accent bright-teal `#2FC4AC` · honey `#FFC24D` · coral `#FF7E63` ·
  brand-flood `#0C6B5C`.

**Type.** Display **Fraunces** 900 (`--fd`, outlined via `.dz-outline` on hero/cta) · body
**Figtree** (`--fb`) · accents **Caveat** script in coral (`--dz-script`).

**Signature moments.**
- **Hero** (`heroHTML`): sharp full-bleed split — teal panel + ghost wordmark + sticker CTAs **|**
  food photo + roomy outlined serif headline, with an intentional 3px ink divider.
- **sticky-scroll** (`.ss`, the promoted section): pinned cross-fading story panels (honey number
  badge + serif title + sticker CTA) beside a scrolling sticker gallery with coral script captions.
  Driven by `STICKY_JS` (IO activates the panel whose gallery image crosses centre). `reverse` swaps sides.
- **card-grid** (`.cg`): recipe rail — horizontal sticker cards, each with a **circle photo always
  above the top edge**, coral script tag.
- **testimonial** (`.tm`): honey sticker speech-bubbles (with tails) on the teal brand ground, big
  outlined heading, ✦ sparkles, circular avatar cut-outs — clean staggered grid (no overlap).
- Sticker material (hard ink border + offset shadow, pop-on-press) + script accents throughout.

**System change (promotion).** Added `stickyScroll` section to `sections.mjs` (+ base CSS +
`STICKY_JS`), wired into `gen-engine.mjs` and `build-skinsheet.mjs`. Rationale: a genuinely novel
signature interaction the 15 didn't cover (web-motion §3). Treat as `web-design-system` **minor**
bump; it is now available to the generator for any skin.

**Gate status.** Skinsheet (all sections incl. sticky-scroll) **and** the end-to-end demo
(`gen-demo-sticker-pop.mjs` → real food-brand content + real photos) both **PASS** full matrix + `--site`
(0 violations). Sticky-scroll cross-fade + reverse verified live in a browser.

**Gate gotchas codified (for the next skin).**
- Outlined text: the CONTRAST gate reads the **fill `color`**, not the stroke — pin the fill to a
  fixed light colour over a solid/photo-scrim backing; never `var(--bg)` (flips with theme).
- **No single accent clears AA on both light & dark grounds** → pin flooded brand grounds to a
  FIXED deep teal (`--dz-brand`); let the `--accent` role flip for small accents/buttons only.
- Script/coral is decorative — never use it for sentence-length text (fails AA); use ink/ink-soft.
- Big serif numerals overflow `minmax(0,1fr)` at 375 → `minmax(min(150px,100%),1fr)`.
- **Hero clipping is a STRUCTURE bug, not a font-size bug** (Tong, 2026-06-29). A split hero put
  text (buttons / outlined headline) inside containers that had `overflow:hidden` (to clip the
  ghost wordmark / the parallax bg image) and pinned the text hard to an edge (`align-items:
  flex-end`, `max-width:14ch`) → the text + its stroke/sticker-shadow got cut, and shrinking the
  font did NOT fix it. **Fix = restructure, never shrink:** the hero and both halves carry NO
  `overflow:hidden`; only the two decorative LAYERS clip themselves (`.dz-hero__ghostwrap` and
  `.dz-hero__imgwrap`, each `position:absolute;inset:0;overflow:hidden`); all text sits in normal
  padded flow (its own padding keeps it off every edge). Keep the big headline size.

**Live demo (Copper Spoon — original brand, real photos):** https://ws-sticker-pop-715f6d07-356b448b.sites.vm0.io
