# Section library — sticker-pop

Cut from the reference page by `tools/split-sections.mjs`. Pick the sections the brief supports,
in the order `NARRATIVE.md` gives, and assemble with `tools/compose.mjs`. A section you do not
pick is not in the page, so it cannot be left half-edited.

`_foundation.css` and `_shell.part` are always included. `css −` means the section reuses a skin
block an earlier section already brought. `geometry` is measured off the reference page at 1440 and
390 — column counts, the first media box's aspect ratio and its share of the section width, and the
section's own height. Read it here rather than opening the stylesheet.

| section | kind | html | skin | words | imgs | geometry |
|---|---|---|---|---|---|---|
| `01-nav` | nav | 1.7KB | — | 9 | 0 | 66px |
| `02-hero` | hero | 1.5KB | — | 41 | 1 | media 0.93 · 50%w · 774px |
| `03-logos` | logos | 1.7KB | — | 36 | 0 | 129px |
| `04-feature-grid` | feature-grid | 3.8KB | — | 63 | 0 | 3col · →1col · 823px |
| `05-feature-grid` | feature-grid | 3.7KB | — | 63 | 0 | 4col · →1col · 1100px |
| `06-feature` | feature | 2.4KB | — | 32 | 2 | 2col · →1col · media 1.33 · 43%w · 1341px |
| `07-feature` | feature | 2.4KB | — | 32 | 2 | 2col · media 1.33 · 43%w · 1341px |
| `08-stats` | stats | 0.6KB | — | 10 | 0 | 7col · →2col · 397px |
| `09-steps` | steps | 0.8KB | — | 38 | 0 | 5col · →1col · 421px |
| `10-sticky-scroll` | sticky-scroll | 2.9KB | — | 78 | 3 | 2col · →1col · media 0.8 · 46%w · 3114px |
| `11-sticky-scroll` | sticky-scroll | 2.0KB | — | 42 | 2 | 2col · →1col · media 0.8 · 46%w · 2162px |
| `12-card-grid` | card-grid | 5.4KB | — | 70 | 6 | media 1 · 9%w · 839px |
| `13-index-tiles` | index-tiles | 2.9KB | — | 28 | 4 | 4col · →1col · media 0.75 · 21%w · 775px |
| `14-testimonial` | testimonial | 2.4KB | — | 55 | 3 | 3col · →1col · media 1 · 4%w · 589px |
| `15-testimonial` | testimonial | 9.1KB | — | 211 | 12 | media 1 · 4%w · 603px |
| `16-statement` | statement | 1.9KB | — | 240 | 0 | 870px |
| `17-pricing` | pricing | 1.3KB | — | 48 | 0 | 3col · →1col · 800px |
| `18-faq` | faq | 2.1KB | — | 66 | 0 | 2col · →1col · 514px |
| `19-contact` | contact | 1.3KB | — | 24 | 1 | 2col · →1col · media 1.33 · 803px |
| `20-cta` | cta | 0.4KB | — | 14 | 0 | 445px |
| `21-footer` | footer | 1.7KB | — | 26 | 0 | 4col · →1col · 305px |

```json
{}
```

Whole reference page: 54.1KB · foundation 55.3KB.

## What each section is made of

Derived by `tools/describe-sections.mjs` — selectors matched in a browser, knobs read out of
`template.js`, hexes counted in the skin block. Read this instead of opening `template.js` or the
stylesheet: the four things below are what eleven runs went hunting for after composing, and they
are the ones the markup you composed does not tell you.

A **knob** changes what ships. `[data-cardgrid]` hides every card past `data-batch`, so a grid you
filled with six cards renders three until you raise it or drop the control. **Hardcoded** tints are
fixed hexes in the skin; the palette does not reach them, so a colour system you picked will not
recolour those parts.

Every section is also touched by `[data-motion="text-split"]` — the shared
motion/reveal runner, which reads data-to, data-suffix, data-motion, data-speed, data-pscale.
Listed once here; the lines below name only what is specific to one section.

### `01-nav`
- driven by: `.nav__burger` — reads data-open; · `.nav__menu a` — queries .nav__burger · `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label

### `02-hero`
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `03-logos`
- repeats: .logos__item ×36
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `04-feature-grid`
- repeats: .fg__card ×6, .fg__icon ×6, .h3 ×6
- one repeat holds: svg×1, h3×1, p×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `05-feature-grid`
- repeats: .fg__card ×6, .fg__icon ×6, .h3 ×6
- one repeat holds: svg×1, h3×1, p×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `06-feature`
- repeats: .h2 ×3
- driven by: nothing of its own

### `07-feature`
- repeats: .h2 ×3
- driven by: nothing of its own

### `08-stats`
- repeats: .stats__cell ×4, .stats__num ×4, .small ×4
- one repeat holds: p×1
- driven by: nothing of its own

### `09-steps`
- repeats: .steps__item ×3, .steps__num ×3, .h3 ×3
- one repeat holds: h3×1, p×1
- driven by: nothing of its own

### `10-sticky-scroll`
- repeats: .h2 ×4, .ss__panel ×3, .eyebrow ×3
- driven by: `[data-sticky-scroll]` — reads data-i; queries .ss__panel, .ss__item
- behaviour attributes present: data-i

### `11-sticky-scroll`
- repeats: .h2 ×3
- driven by: `[data-sticky-scroll]` — reads data-i; queries .ss__panel, .ss__item
- behaviour attributes present: data-i

### `12-card-grid`
- repeats: .mono ×18, .cg__card ×6, .cg__media ×6
- driven by: `[data-cardgrid]` — reads data-batch, data-cat; queries .cg__tab, .cg__card, .cg__morewrap, .cg__more, .cg__grid
- behaviour attributes present: data-cat

### `13-index-tiles`
- repeats: .it__tile ×4, .it__media ×4, .media ×4
- one repeat holds: img×1, h3×1, p×1
- driven by: nothing of its own

### `14-testimonial`
- repeats: .tm__card ×3, .tm__quote ×3, .tm__by ×3
- one repeat holds: img×1
- driven by: nothing of its own

### `15-testimonial`
- repeats: .tm__card ×12, .tm__quote ×12, .tm__by ×12
- one repeat holds: img×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `16-statement`
- driven by: nothing of its own

### `17-pricing`
- repeats: .pr__card ×3, .h3 ×3, .pr__tier ×3
- one repeat holds: h3×1, li×3, a×1
- driven by: nothing of its own

### `18-faq`
- repeats: .faq__item ×4, .faq__q ×4, .faq__icon ×4
- one repeat holds: svg×1, p×1
- driven by: `.faq__item` — queries summary, .faq__a

### `19-contact`
- repeats: .cf__field ×3
- driven by: `.cf__form` — queries .cf__ok

### `20-cta`
- driven by: nothing of its own

### `21-footer`
- repeats: .ft__col ×3, .ft__h ×3
- one repeat holds: h3×1, li×2, a×2
- driven by: `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label
