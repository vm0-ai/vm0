/* skin-object-archive.mjs — learned from objectandarchive.com (fine-art print store, curated by a
 * historian). Register: GALLERY ARCHIVE EDITORIAL — warm cream + near-black, painterly grain
 * grounds, a high-contrast flared DISPLAY SERIF, MONOSPACE body + tiny letterspaced accession
 * labels, italic-script accents, and the signature DECORATIVE PICTURE-FRAME on every artwork/card.
 * Motion = quiet/premium: scroll reveals + stagger, underline-on-hover links, gentle card lift
 * (the site's Lenis+GSAP calm, done native-first). Full 15-section restyle. (skin-contract.md) */
export const skin = {
  id:'gallery-wall',
  fontsAttr:'archive', motionAttr:'subtle',
  fontLink:'<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,800;1,400;1,600&family=Courier+Prime:ital,wght@0,400;0,700;1,400&family=Tangerine:wght@700&display=swap" rel="stylesheet">',
  signature:'cream + painterly grain · flared display serif · monospace accession labels · italic-script accents · decorative picture-frame artwork',
  contactBg:'vintage oil painting dark moody texture',   // gen-engine injects this as the contact-form full-bleed bg
  parallax:{speed:0.08, scale:1.45},                     // gentle, clamped image-parallax for content media
  css:`
/* ① COLOURS — warm cream / near-black; colour lives in the (painterly) imagery -------------- */
:root{--bg:#F9F8F2;--ink:#121212;--ink-soft:#4A463E;--accent:#2F4A38;--accent-ink:#F9F8F2;
  --support-1:#9C3B2E;--support-2:#2E4257;--surface:#F2EFE6;--surface-2:#EAE5D7;
  --border:#D9D3C4;--ring:#2F4A38;--radius:2px;--container:var(--w-wide);
  --fd:'Playfair Display';--fb:'Courier Prime';
  --fx-grain-opacity:.10;--fx-aurora-opacity:.5;--fx-aurora-blur:80px;--fx-aurora-1:17s;--fx-aurora-2:21s;--fx-aurora-3:25s;
  --oa-frame:#7A5A3C;--oa-matte:#F9F8F2}
html[data-theme="dark"]{--bg:#14160F;--ink:#F1ECE0;--ink-soft:#B7B0A0;--accent:#C9A86A;
  --accent-ink:#14160F;--support-1:#D08566;--support-2:#8FA9B8;--surface:#1C1E15;
  --surface-2:#24271B;--border:#34372A;--ring:#C9A86A;--oa-frame:#C9A86A;--oa-matte:#14160F}

/* ② TYPE — flared serif display · monospace body + labels · italic-script accents ----------- */
body{letter-spacing:.02em}
.display,h1,.h1,h2,.h2,h3,.h3{font-family:var(--fd);font-weight:400;letter-spacing:-.01em}
.display{font-weight:800}
h2,.h2{font-size:clamp(2rem,4.4vw,3.4rem);line-height:1.04}
.lead{font-family:var(--fb);font-size:clamp(1rem,1.3vw,1.18rem);line-height:1.7;color:var(--ink-soft);letter-spacing:.01em}
.eyebrow,.mono,.logos__label{font-family:var(--fb);text-transform:uppercase;letter-spacing:.18em;font-size:.72rem;color:var(--ink-soft)}
.small{font-family:var(--fb);letter-spacing:.04em}
.eyebrow{font-weight:700}
.oa-script{font-family:'Tangerine',cursive;font-weight:700;text-transform:none;letter-spacing:0}
/* quiet gallery interaction: underline-on-hover links + gentle motion */
a:not(.btn){text-decoration:none;background-image:linear-gradient(var(--ink),var(--ink));background-size:0 1px;background-repeat:no-repeat;background-position:0 100%;transition:background-size .35s ease}
a:not(.btn):hover{background-size:100% 1px}

/* buttons → quiet bordered "tickets", italic-serif label */
.btn{font-family:var(--fd);font-style:italic;font-weight:600;border-radius:2px;letter-spacing:.01em}
.btn-primary{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
.btn-ghost{background:transparent;color:var(--ink);border:1px solid var(--ink)}
.btn-ghost:hover{background:var(--ink);color:var(--bg)}

/* signature DECORATIVE PICTURE-FRAME — applied to artwork media + product cards ------------- */
.media,.it__media{border:0;border-radius:0;background:var(--surface-2);
  padding:10px;box-shadow:inset 0 0 0 10px var(--oa-frame),inset 0 0 0 13px var(--oa-matte),inset 0 0 0 14px var(--border),0 14px 30px rgb(18 18 18/.14)}
.fg__card,.cg__card,.tm__card{background:var(--surface);border:1px solid var(--border);border-radius:2px;
  box-shadow:inset 0 0 0 6px var(--bg),0 10px 26px rgb(18 18 18/.08);padding:clamp(1.3rem,2.6vw,2rem);transition:transform .4s ease,box-shadow .4s ease}
.fg__card:hover,.cg__card:hover{transform:translateY(-4px);box-shadow:inset 0 0 0 6px var(--bg),0 18px 40px rgb(18 18 18/.16)}

/* dark painterly contrast band (plan ground:'dark') — deep forest-ink, remap roles ---------- */
[data-ground="dark"]{--bg:#14160F;--ink:#F1ECE0;--ink-soft:#C7C0AE;--accent:#C9A86A;--accent-ink:#14160F;
  --surface:#1C1E15;--surface-2:#24271B;--border:#3A3E2E;--oa-frame:#C9A86A;--oa-matte:#14160F;
  background:#14160F;color:#F1ECE0;position:relative;overflow:hidden}
[data-ground="dark"] .eyebrow,[data-ground="dark"] .small{color:#C7C0AE}
[data-ground="dark"] .stats__num{color:var(--accent)}

/* ③ per-section restyle ------------------------------------------------------------------- */
/* 1 nav — hairline rule, tiny letterspaced caps links, script brand */
.nav{border-bottom:1px solid var(--border);background:color-mix(in srgb,var(--bg) 90%,transparent);backdrop-filter:blur(6px)}
.nav__brand{font-family:'Tangerine',cursive;font-weight:700;font-size:2.1rem;letter-spacing:0}
.nav__links a{font-family:var(--fb);text-transform:uppercase;letter-spacing:.16em;font-size:.72rem}
.nav__cta{font-family:var(--fd);font-style:italic}

/* 5 logos — CENTERED editorial "collected by" row (label forced centered, full-width) */
.logos{background:var(--surface);border-block:1px solid var(--border);text-align:center}
.logos .container,.logos .sec-head{text-align:center}
.logos__label{text-align:center;display:block;width:100%;margin-inline:auto}
.logos__row{justify-content:center;gap:clamp(1.4rem,3.5vw,2.6rem) clamp(2rem,5vw,4rem);margin-top:var(--space-4)}
.logos__item{font-family:var(--fd);font-size:1.15rem;letter-spacing:.02em;color:var(--ink-soft);opacity:.85}

/* 3 feature-split — editorial: serif title + mono body, framed media; EQUAL columns + roomy gap */
.fs__icon{color:var(--support-1)}
.fs__text h2,.fs__text h3{font-family:var(--fd)}
.fs--media-wide .fs__row,.fs--text-wide .fs__row{grid-template-columns:1fr 1fr}
.fs__row{gap:clamp(2.5rem,6vw,6rem)}

/* 4 feature-grid — framed "cards", serif titles */
.fg__icon{color:var(--support-1)}
.fg__card h3{font-family:var(--fd);font-weight:600;font-size:1.4rem}

/* 6 stats — big serif numerals + mono accession labels */
.stats__num{font-family:var(--fd);font-weight:800;font-size:clamp(2.6rem,6vw,4.4rem);line-height:.95}
.stats__cell .small{letter-spacing:.16em}

/* 7 steps — numbered like a catalogue: serif numerals, hairline divider */
.steps__item{border-top:1px solid var(--border);padding-top:var(--space-4)}
.steps__num{font-family:var(--fd);font-weight:600;font-size:1.35rem;color:var(--accent-ink);background:var(--accent);width:48px;height:48px;border-radius:2px;display:flex;align-items:center;justify-content:center;flex:none}
.steps__item h3{font-family:var(--fd)}

/* 8 testimonial — pull-quote in serif, attribution in mono caps */
.tm__quote{font-family:var(--fd);font-style:italic;font-size:clamp(1.3rem,2.4vw,1.9rem);line-height:1.35}
.tm__name{font-family:var(--fb);text-transform:uppercase;letter-spacing:.14em;font-size:.74rem}
.tm__marquee,.tm__grid{padding-block:1.6rem 2.6rem}   /* room so framed-card shadows aren't clipped */

/* 9 pricing — "editions": framed plan cards, serif price */
.pr__card{background:var(--surface);border:1px solid var(--border);border-radius:2px;box-shadow:inset 0 0 0 6px var(--bg),0 10px 26px rgb(18 18 18/.08)}
.pr__card--pop{border-color:var(--accent)}
.pr__amt{font-family:var(--fd);font-weight:800}
.pr__badge{font-family:var(--fb);text-transform:uppercase;letter-spacing:.12em;background:var(--accent);color:var(--accent-ink);display:inline-flex;align-items:center;justify-content:center;text-align:center;line-height:1;border-radius:2px;padding:.4rem .8rem;white-space:nowrap}

/* 10 faq — large serif questions as an editorial index, hairline rows */
.faq__item{border-bottom:1px solid var(--border)}
.faq__q{font-family:var(--fd);font-weight:600;font-size:clamp(1.15rem,2vw,1.6rem)}
.faq__a .body{font-family:var(--fb);color:var(--ink-soft)}

/* 11 contact-form — a light enquiry CARD floating over a FULL-BLEED painterly image (parallax),
   exactly like the source's subscribe. Form text sits on the solid cream card → AA (gate-safe);
   the painting is a decorative layer behind. (.cf__bg media injected at build → real photo.) */
.cf{position:relative;overflow:hidden;background:#171911;padding-block:clamp(4rem,11vw,8.5rem)}
.cf__bg{position:absolute;inset:0;z-index:0;width:100%;height:100%;border:0;border-radius:0;padding:0;box-shadow:none;background:#171911}
.cf__bg>img{width:100%;height:118%!important;object-fit:cover}
.cf__bg::after{content:"";position:absolute;inset:0;background:rgba(18,18,16,.22)}
.cf>.container{position:relative;z-index:1;max-width:56rem;background:var(--bg);
  padding:clamp(2rem,5vw,3.6rem);box-shadow:0 40px 90px rgba(0,0,0,.5);border:1px solid var(--border)}
.cf .h2,.cf h2{color:var(--ink);font-style:italic}
.cf .lead{color:var(--ink-soft)}
.cf__field span{font-family:var(--fb);text-transform:uppercase;letter-spacing:.14em;font-size:.7rem;color:var(--ink-soft)}
.cf__field input,.cf__field textarea{font-family:var(--fb);width:100%;background:var(--surface);border:1px solid var(--border);border-radius:2px;color:var(--ink)}
.cf__field input{height:52px}
.cf__field textarea{height:150px;resize:none}   /* fixed size — no manual drag-resize */

/* 12 card-grid — the COLLECTION: filter tabs as mono caps, framed cards, mono accession meta */
.cg__tabs{border-bottom:1px solid var(--border)}
.cg__tab{font-family:var(--fb);text-transform:uppercase;letter-spacing:.14em;font-size:.72rem;border-radius:0;background:transparent;border:0;border-bottom:2px solid transparent}
.cg__tab[aria-pressed="true"]{background:transparent;color:var(--ink);border-bottom-color:var(--accent)}
.cg__title{font-family:var(--fd);font-weight:600;font-size:1.3rem}
.cg__tag,.cg__meta,.cg__link{font-family:var(--fb);text-transform:uppercase;letter-spacing:.13em;font-size:.68rem;color:var(--ink-soft)}
.cg__role{font-style:italic;font-family:var(--fd);font-size:1.05rem}
/* HORIZONTAL full-width rail of FRAMED ARTWORK (Current obsessions): edge-to-edge, scrollbar hidden,
   generous vertical padding so the framed-card shadows are never clipped by the scroll overflow. */
.cg .container{max-width:none}
/* bleed the rail to the real viewport edges (no hard cut inside the page); first card aligns to the
   heading via padding; the trailing card runs off the screen edge like the source. */
.cg__grid{display:flex;grid-template-columns:none;gap:clamp(1.2rem,2.6vw,2.2rem);overflow-x:auto;overflow-y:hidden;
  margin-inline:calc(-1 * var(--gutter));padding:1.8rem var(--gutter) 2.8rem;
  scroll-snap-type:x mandatory;scroll-padding-inline:var(--gutter);-webkit-overflow-scrolling:touch;
  scrollbar-width:none}
.cg__grid::-webkit-scrollbar{display:none}
.cg__card{flex:0 0 clamp(258px,74vw,328px);scroll-snap-align:start}
.cg__media{aspect-ratio:4/5;width:100%;margin-bottom:var(--space-3);padding:7px;
  box-shadow:inset 0 0 0 7px var(--oa-frame),inset 0 0 0 9px var(--oa-matte),inset 0 0 0 10px var(--border),0 10px 22px rgb(18 18 18/.16)}
.cg__media>img{height:100%!important;object-fit:cover}
.cg__title{font-size:1.15rem}
.cg__morewrap{display:none}   /* a horizontal rail scrolls — no "load more" */

/* 13 index-tiles — moody photo plates (dark scrim); SHARP corners (whole site is sharp); pronounced parallax */
.it__tile{border-radius:0}
.it__num{font-family:var(--fd);font-style:italic;font-weight:600;color:#D8C39A}
.it__title,.it__body h3{font-family:var(--fd);font-weight:600}
.it__cap{font-style:italic;text-transform:none;letter-spacing:.01em;font-family:var(--fd);font-size:1.02rem}

/* 14 cta — painterly band + a serif manifesto + italic-script flourish */
.cta__panel{border-radius:3px}
.cta h2{font-family:var(--fd);font-weight:400;font-style:italic;font-size:clamp(2rem,4.6vw,3.6rem)}
.cta__sub{font-family:var(--fb)}

/* 15 footer — quiet archive colophon */
.ft__name{font-family:'Tangerine',cursive;font-weight:700;font-size:2.4rem}
.ft__h{font-family:var(--fb);text-transform:uppercase;letter-spacing:.16em;font-size:.7rem;color:var(--ink-soft)}
.ft__col a{font-family:var(--fb);font-size:.82rem}

/* IMAGE PARALLAX — driven by the JS image-parallax primitive (rAF). CSS scroll-driven
   (animation-timeline:view) is applied but DOES NOT tick in the gate chromium, so media get
   data-motion=image-parallax (+ data-speed/data-pscale to make it OBVIOUS) injected at build. */
.media>img,.it__media>img,.cf__bg>img{will-change:transform}
.it__media>img{height:100%;object-fit:cover}

/* hero — TRUE FULL-SCREEN painterly image: a full-viewport cover image (image-parallax) on a SOLID
   dark backing, with cream text + the giant flared wordmark overlaid. Text is measured against the
   solid .oa-hero backing (the image is a lower sibling layer) → AA, like index-tiles. */
.oa-hero{position:relative;overflow:hidden;padding:0;min-height:clamp(620px,94vh,1000px);
  display:flex;align-items:center;background:#14160F;color:#F4EFE3}
.oa-hero__img{position:absolute;inset:0;z-index:0;width:100%;height:100%;border:0;border-radius:0;padding:0;
  background:#14160F;opacity:.84;box-shadow:inset 0 0 0 14px rgba(249,248,242,.14)}
.oa-hero__img>img{height:114%!important;width:100%;object-fit:cover}
.oa-hero__inner{position:relative;z-index:2;width:100%}
.oa-hero__panel{max-width:60rem}
.oa-hero__eyebrow{font-family:var(--fb);text-transform:uppercase;letter-spacing:.22em;font-size:.74rem;color:#E7D2A0}
.oa-hero__head{font-family:var(--fd);font-weight:400;font-size:clamp(2.4rem,6vw,5rem);line-height:1.03;margin:var(--space-4) 0;max-width:18ch;color:#F8F4EA}
.oa-hero__lead{font-family:var(--fb);color:#EAE4D5;max-width:46ch;line-height:1.7}
.oa-hero__cta{margin-top:var(--space-5)}
.oa-hero__shop{font-family:var(--fd);font-style:italic;font-size:1.4rem;color:#F8F4EA;border-bottom:1px solid currentColor;padding-bottom:2px}
.oa-hero__shop:hover{background-size:0 1px}
.oa-word{font-family:var(--fd);font-weight:400;text-transform:uppercase;letter-spacing:.01em;line-height:.92;
  font-size:clamp(2.6rem,12vw,9rem);margin:var(--space-6) 0 0;color:#F8F4EA;overflow-wrap:anywhere}
`,
  heroHTML({wordmark='OBJECT & ARCHIVE', title='Curated work with a past and a point of view.', lead='', dots=[], ctas=[], photo=''}){
    const links = (ctas.length ? ctas : [{label:'shop the collection', href:'#cta'}])
      .map(c=>`<a class="oa-hero__shop" href="${c.href}">${c.label}</a>`).join('');
    return `<section class="section oa-hero" data-section="hero" data-width="full" data-signature="archive-fullscreen-parallax-hero">
      <div class="media oa-hero__img" data-motion="image-parallax" data-speed="0.08" data-pscale="1.26" data-photo="${photo || 'vintage abstract oil painting framed'}"></div>
      <div class="fx-grain" aria-hidden="true"></div>
      <div class="container oa-hero__inner" data-motion="parallax" data-speed="0.04">
        <div class="oa-hero__panel" data-motion="reveal-up">
          <p class="eyebrow oa-hero__eyebrow">${(dots.join(' · ')||'Fine art prints · Curated by a historian')}</p>
          <h1 class="oa-hero__head">${title}</h1>
          <p class="oa-hero__lead">${lead}</p>
          <p class="oa-hero__cta">${links}</p>
        </div>
        <div class="oa-word" data-motion="reveal-up">${wordmark}</div>
      </div>
    </section>`;
  }
};
