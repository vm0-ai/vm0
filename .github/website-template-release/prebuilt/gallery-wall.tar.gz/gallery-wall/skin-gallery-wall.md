---
name: gallery-wall
kind: skin
extends: skin-contract.md
source: objectandarchive.com (fine-art print store, "curated by a historian"), learned 2026-06-29
---

# gallery-wall — gallery-archive editorial skin

A warm, painterly, museum-archive register: cream ground, near-black ink,
a high-contrast flared **display serif**, **monospace body + accession labels**, italic-script
accents, and the signature **decorative picture-frame** on every artwork/card. Motion is quiet
and premium (scroll reveals, underline-on-hover links, gentle card lift) — the source's
Lenis+GSAP calm, done native-first. **All 15 sections restyled.**

## Lever re-map (source → skin)
| Lever | Source (objectandarchive.com) | Re-mapped to |
|-------|-------------------------------|--------------|
| Ground | warm cream `#F9F8F2` / ink `#121212`; colour carried by painterly oil/watercolour imagery | same cream/ink; `--accent` deep gallery green `#2F4A38`, support terracotta `#9C3B2E` + archival blue `#2E4257`; painterly feel via shared `grain` |
| Display | high-contrast flared serif (≈ Abril/Didone) | **Playfair Display** (`--fd`) — display 800 / headings 400 / italic accents |
| Body | **monospace** (Courier, letterspaced) — archival/curatorial | **Courier Prime** (`--fb`), letterspaced labels |
| Accents | italic-script logo + "shop the collection" | **Tangerine** script (brand marks) + Playfair italic links/CTAs |
| Labels | tiny uppercase letterspaced caption ("2/18 UNTITLED VI") | mono uppercase `.18em` accession labels (eyebrow/tag/meta) |
| Signature motif | scalloped/ornate **picture frames** on product cards | CSS frame + cream matte + drop shadow on `.media/.it__media/.fg__card/.cg__card/.pr__card`; gilt frame on dark |
| Motion | Lenis smooth scroll + GSAP reveals; 1s hero crossfade; underline/lift hovers | `subtle`: reveal-up/fade + stagger; underline-grow links; card lift (native) |
| **Image parallax** | GSAP scroll parallax on images | **JS `image-parallax` rAF primitive** on hero/feature/index/contact media (CSS `animation-timeline` doesn't tick in this chromium); per-element `data-speed`/`data-pscale`; offset **clamped to the scale headroom** so the image never gaps; scroll-DOWN → image-UP |
| **Full-screen image** | full-screen painterly image hero | **true full-viewport (94vh) cover-image hero** on a solid dark backing, cream text + giant wordmark overlaid (`data-width="full"`); text measured vs the solid backing → AA |
| **Selected works** | horizontal-scroll rail of **framed artwork** (Current Obsessions) | **`card-grid` → horizontal scroll-snap rail of framed artwork** — cardGrid gained an optional `photo` (framed `.cg__media`); serif title + italic artist + mono tag/year |
| Dark band | painterly green manifesto bands breaking the cream | `[data-ground="dark"]` = deep forest-ink `#14160F` + gilt accent |
| **Contact** | elegant full-screen image-bg subscribe | **`contact-form` = a light cream CARD floating over a full-bleed painterly image** (`.cf__bg` media + apply-photos + parallax); form text on the solid card → AA |
| Voice | witty, human microcopy | (content-layer; skin carries the type voice) |

## Signature (passes `--site`)
True full-screen parallax painterly hero (`archive-fullscreen-parallax-hero` = full-viewport
cover image with `image-parallax`, cream text + giant flared wordmark overlaid) · horizontal
framed-artwork rail (Current obsessions) · decorative picture-frame artwork · monospace accession
labels · italic-script brand marks · full-screen painterly contact · cream + grain grounds + scroll
parallax on imagery.

## Dual-mode + gate
Dual-mode: cream/ink ↔ deep forest-ink `#14160F` / warm off-white, gilt accent in dark.
`build-skinsheet.mjs skin-gallery-wall.mjs` → **`qa-site` PASS** full (4 bp × 2 themes ·
landmarks · links · tap-target · contrast · type-floor · DUAL-MODE) **and `--site`**
(SIGNATURE-PRESENT · MOTION-NON-UNIFORM · LAYOUT-VARIETY), with real photos applied.
Live skinsheet: https://ws2-gallery-wall-715f6d07-ea840bd9.sites.vm0.io

## Gotchas codified
- `index-tiles` ships a **fixed-dark photo ground + light overlay text** — restyle its type but
  keep `.it__cap/.it__title` light (don't set dark `--ink-soft`, or it fails contrast on the scrim).
- Don't crush global `.small` to a sub-12px size — type-floor flags it; size labels via
  `.eyebrow/.mono` (exempt) instead, and tag any bespoke label element with `eyebrow`.
