# Gallery Wall — design system

Measured from the local `template.css` and `index.html`. These are facts about
the shipped stylesheet, not intentions. Where a value here disagrees with prose anywhere else, this
file is right.

## Character

> cream + painterly grain · flared display serif · monospace accession labels · italic-script accents · decorative picture-frame artwork



## Type

| | |
|---|---|
| Families loaded | `Playfair Display` · `Courier Prime` · `Tangerine` |
| Display face | `'Playfair Display'` |
| Body face | `'Courier Prime'` |
| Font personality flag | `data-fonts="archive"` |

Both faces are declared as tokens, so a brand type change is a two-line edit in
`style[data-brand-theme]` — not a find-and-replace through the stylesheet.

## Colour roles

The stylesheet reads colour only through these roles. Rebinding them in `style[data-brand-theme]`
restyles the whole page; writing a literal colour anywhere else forks it.

| role | light | dark |
|---|---|---|
| `--bg` | #F9F8F2 | #14160F |
| `--ink` | #121212 | #F1ECE0 |
| `--ink-soft` | #4A463E | #B7B0A0 |
| `--accent` | #2F4A38 | #C9A86A |
| `--accent-ink` | #F9F8F2 | #14160F |
| `--support-1` | #9C3B2E | #D08566 |
| `--support-2` | #2E4257 | #8FA9B8 |
| `--surface` | #F2EFE6 | #1C1E15 |
| `--surface-2` | #EAE5D7 | #24271B |
| `--border` | #D9D3C4 | #34372A |
| `--ring` | #2F4A38 | #C9A86A |

Generate a replacement set with `node tools/palette.mjs --pick <system>`; use `--list` to choose and `--check` to audit bespoke values.
The values above are the reference page's own palette; they are a demonstration, not a requirement.

## Structural tokens

| token | value |
|---|---|
| `--container` | var(--w-wide) |
| `--fb` | 'Courier Prime' |
| `--fd` | 'Playfair Display' |
| `--fx-aurora-1` | 17s |
| `--fx-aurora-2` | 21s |
| `--fx-aurora-3` | 25s |
| `--fx-aurora-blur` | 80px |
| `--fx-aurora-opacity` | .5 |
| `--fx-grain-opacity` | .10 |
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |
| `--oa-frame` | #7A5A3C |
| `--oa-matte` | #F9F8F2 |
| `--radius` | 2px |

**Spacing scale** — `--space-2`=.5rem · `--space-3`=.75rem · `--space-4`=1rem · `--space-5`=1.5rem · `--space-6`=2rem · `--space-7`=3rem · `--space-8`=4rem · `--space-9`=6rem · `--space-10`=8rem



## Motion

| token | value |
|---|---|
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |

Motion personality: `subtle`. `template.js` binds the reveals, the marquee, the
disclosure widgets, the theme toggle and the mobile nav. Reveals must degrade to visible content —
never hide a whole section behind an IntersectionObserver.

## Device vocabulary

Class prefixes that carry layout in the reference page, by frequency. Compose from these; a class
that is not here has no stylesheet behind it, and inventing one produces an unstyled bare tag.

`.muted`×47 · `.small`×35 · `.h3`×28 · `.h2`×25 · `.mono`×22 · `.container`×21 · `.media`×21 · `.section`×19 · `.body`×19 · `.lead`×16 · `.eyebrow`×11 · `.sec-head`×10 · `.btn`×8 · `.btn-primary`×4 · `.btn-ghost`×3 · `.theme-toggle`×2 · `.fg`×2 · `.fs`×2 · `.fs--rev`×2 · `.ss`×2 · `.tm`×2 · `.skip`×1 · `.nav`×1 · `.theme-toggle--nav`×1 · `.oa-hero`×1 · `.oa-word`×1 · `.logos`×1 · `.logos--wall`×1 · `.fg--cards`×1 · `.fg--bento`×1 · `.fs--even`×1 · `.fs--media-wide`×1 · `.stats`×1 · `.steps`×1

## Reference density

The reference page carries **1233 visible words** across its sections. That is a description
of this example, not a target. Say what the brief supports and stop — a page padded to reach a
word count reads like one, and the reader can tell.
