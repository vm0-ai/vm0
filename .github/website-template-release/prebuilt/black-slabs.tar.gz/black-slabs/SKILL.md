# Black Slabs — direct-HTML website template

Select the sections, run `tools/compose.mjs` exactly once, then edit the composed `index.html`.

## Outcome

Create one evidence-led landing page with one primary conversion action. It should feel unmistakably
Black Slabs: oversized monolithic type, sharp graphic blocks, high-contrast grounds, a restrained
accent and several distinct motion families placed at meaningful narrative beats.

Use only facts the brief supports. Drop unsupported beats instead of inventing logos, quotes, metrics
or cases.

## Read only what the decision needs

Before composing:

1. `NARRATIVE.md` — choose the supported beats and their order.
2. `sections/_index.md` — choose the actual sections; it includes media cost, geometry and behaviour.
3. `checks/GATES.md` — know the shipping requirements before authoring.

Read these only when needed:

- `layout-map.md` when a beat-to-device choice is unclear.
- `design-system.md` when changing type, spacing or composition CSS.
- `COLOR-SYSTEM.md` when selecting, seeding or auditing a palette.
- Run `node tools/palette.mjs --list` when the brief pins a colour, official brand evidence exists,
  or you need a bespoke palette.
- The selected section files when their manifest entry is not enough to author them.
- `index.html` only to inspect a selected device in its original context.
- `template.css` or `template.js` only to repair a named failure that the manifest and gate output do
  not explain.

Keep the existing `template.css` and `template.js` links.

## Black Slabs visual DNA

- One family throughout: Schibsted Grotesk. Display is 800 weight, very tight
  (`letter-spacing:-0.045em`, `line-height:0.92`); body is 17px.
- Use giant type as structure, not decoration. Headlines form solid slabs rather than airy editorial
  columns.
- Corners stay sharp: the modal radius is 5px. Do not turn the page into rounded SaaS cards.
- Preserve pure light/dark contrast, the deep full-bleed slab and sparse accent allocation. A palette
  may change the hues, not where emphasis lands.
- Keep the graphic devices that define this skin: full-bleed showcase panels, metric cards,
  asymmetric spotlight, giant wordmark band and corner-square details.
- The spotlight is fixed at 560px so switching entries never changes the section height.
- Add composition CSS only in `<style data-brand-theme>`. Use semantic colour roles there; do not
  hard-code colours through the page or edit `template.css` during authoring.

## Default color tokens

These are this template's shipped reference values, not a palette requirement. When the brief or
brand evidence calls for another palette, replace the semantic roles as one set with
`node tools/palette.mjs`; do not scatter literal colours through the page.

| role           | light   | dark    |
| -------------- | ------- | ------- |
| `--bg`         | #FBFBF9 | #0C0D0D |
| `--ink`        | #17181C | #F2F3EF |
| `--ink-soft`   | #6A6A66 | #9A9B95 |
| `--accent`     | #0C7C6C | #2FDCC4 |
| `--accent-ink` | #FFFFFF | #062019 |
| `--support-1`  | —       | #2DD4BF |
| `--support-2`  | #13A18C | #5FE8D4 |
| `--surface`    | #F1F1ED | #15171A |
| `--surface-2`  | #E7E7E1 | #1E2024 |
| `--border`     | #DCDCD6 | #2A2C2E |
| `--ring`       | #0C7C6C | #2FDCC4 |
| `--slab`       | #070707 | #040404 |

## Motion composition

Basic `reveal-up` / `reveal-fade` is connective tissue, not a featured motion family. Use the
ready-made families below when their content is honest:

| family                           | ready-made section   | best narrative use |
| -------------------------------- | -------------------- | ------------------ |
| word reveal + image parallax     | `04-showcase-panels` | capability         |
| continuous marquee               | `05-logos`           | proof-scale        |
| staggered cards + image parallax | `06-stat-cards`      | proof-data         |
| interactive cross-fade spotlight | `08-spotlight-show`  | proof-people       |
| filter / load-more card grid     | `13-card-grid`       | proof-cases        |
| animated disclosure              | `11-faq`             | objections         |

When the brief supports at least three eligible sections, compose at least three distinct families
from this table. Include one scroll/media family and one user-controlled interaction. When fewer than
three are honest, use every eligible family rather than fabricating evidence. Put the strongest
motion at capability and proof beats; keep the rest quieter.

Preserve the existing motion attributes and reduced-motion fallbacks. Do not invent a motion family
that is absent from the selected markup and documented vocabulary.

## Workflow

1. Resolve the single conversion action and list the brief's usable evidence.
2. Map that evidence to `NARRATIVE.md`, then choose sections and motion families from
   `sections/_index.md`. Nav and footer are wayfinding, not beats.
3. Choose the palette:

   `node tools/palette.mjs --list`, then `node tools/palette.mjs --pick <id>`. Paste the printed
   blocks into `<style data-brand-theme>` and set `data-palette-source`,
   `data-palette-system` and `data-palette-reason` on `<html>`. Use `--check` for a bespoke set.

4. Compose the selected sections exactly once before authoring:

   ```bash
   cat sections/_index.md
   node tools/compose.mjs <section-ids...>
   ```

   `compose.mjs` rewrites `index.html` and `template.css`. This is the only assembly pass.
   Do not run `compose.mjs` again after authoring begins. It writes `.compose-once.json` and refuses
   a second assembly. If the selection was wrong, restart from a fresh template copy instead of
   bypassing the marker or overwriting authored work.

5. Directly author the composed `index.html` while any VM0-managed image jobs run.

   Replace every demo fact, link, asset, title, description and brand reference in the kept sections.
   Preserve `data-section`, `data-node-id`, behaviour attributes and working anchors. Read the
   selected markup first, then write the page in one go; do not patch it section by section.

   After compose succeeds, begin substantive `index.html` authoring immediately. Do not query image
   progress, reopen the section menu, or inspect `template.css`, `template.js` or gate implementation
   while authoring remains. If the VM0 run prompt started image work, wait for it exactly once after
   the HTML is authored; generation commands and scheduling remain owned by that prompt.

   The VM0 run prompt owns image generation and scheduling. When assets are ready, place them in the
   selected slots and copy each reported `dataGenerationSize` into the corresponding
   `data-generation-size`. Keep `data-image-role`, `data-image-presentation`, `data-image-fit` and
   `data-image-crop-safety` on real images. Text-bearing media must not use `cover`. If a slot has no
   honest image, remove its wrapper and recompose the reserved space.

   Run `node tools/brand-assets.mjs` after the final brand, title and palette are in place.

6. Run `bash checks/verify.sh index.html qa` as-is. Repair every blocking failure against its printed
   `actual` / `required` values and rerun until clean. The script creates `qa/` and its own log; do
   not redirect or pipe it. When it prints `QA_READY`, every blocking gate and the motion contract
   passed; proceed directly to staging and publishing. `QA_NOTE` advisories do not block delivery.

   The gate has already used `tools/screenshot.mjs` to write `qa/review-atlas.png`. If a concrete
   concern still requires visual confirmation, inspect that one image once. Do not take more
   screenshots, crop or pixel-search it, or start a recognition loop. It is overview evidence, not
   motion evidence. On `QA_MOTION_FAIL`, repair from `qa/motion-states.json` and its focused
   ordinary-viewport failure image.

7. Stage and publish once:

   `node tools/stage.mjs publish && okou host publish --site <slug>`

8. Run `bash checks/verify-published.sh <url>` against the deployed page. A local pass is not evidence
   about a different directory or deployment.

## Authoring constraints

- Follow the brief and narrative; never pad the page merely to imitate the reference word count.
- Use selected section markup and documented classes. An invented class has no styling contract.
- Preserve one primary action, layered proof, both themes, focus states and reduced-motion legibility.
- Never leave a blank media column or hide an entire section behind entrance motion.
- `checks/GATES.md` is the acceptance contract; do not duplicate its thresholds here.

<!-- MEASURED:BEGIN -->

### Measured identity constants

Measured off this package's `index.html` by `tools/stamp-identity.mjs` at 1440×900 and 390×844.
Stated as floors with slack, so a different composition can still satisfy them.

- **Type.** Headings are set in `Schibsted Grotesk` on at least 90% of visible
  `h1`/`h2`; body is `Schibsted Grotesk` at 17px. Display sits at least
  **5.34×** body for the hero and **2.59×** for `h2` on desktop;
  **2.18×** and **1.62×** on mobile. At a 105.6px
  headline that is tracking `-0.045em`, leading `0.92`, weight
  `800`.
  Collapsing to one generic sans, or flattening the display/body ratio, removes the template.
- **Corner.** The modal radius across visible boxes is **`5px`**
  (profile: `5px`×23 · `999px`×16 · `4px`×7 · `6px`×5). Do not round or
  square boxes against this — the corner is identity, not taste.
- **Colour.** The reference accent is `#0C7C6C`, on a `#070707` deep band.
  Replace the palette with `node tools/palette.mjs`; keep the _allocation_ — how much of the page the
  accent touches, and whether the template uses a deep band at all.
- **Density.** 701 visible words in `main` across 14 marked sections,
  1 `.prose` block(s) and 4 multi-paragraph
  block(s); widest paragraph box 790px. These describe the reference, not a
  target — say what the brief supports and stop. A page padded to hit a word count reads like one.
- **Frame.** No horizontal overflow at 390px (reference: clean).

<!-- MEASURED:END -->
