# Section library — black-slabs

Cut from the reference page by `tools/split-sections.mjs`. Pick the sections the brief supports,
in the order `NARRATIVE.md` gives, and assemble with `tools/compose.mjs`. A section you do not
pick is not in the page, so it cannot be left half-edited.

`_foundation.css`, `_baselayer.css` and `_shell.part` are always included. `css −` means the section reuses a skin
block an earlier section already brought. `geometry` is measured off the reference page at 1440 and
390 — column counts, the first media box's aspect ratio and its share of the section width, and the
section's own height. Read it here rather than opening the stylesheet.

| section | kind | html | skin | words | imgs | geometry |
|---|---|---|---|---|---|---|
| `01-nav` | nav | 1.7KB | skin-01-nav.css | 10 | 0 | 71px |
| `02-hero` | hero | 1.1KB | skin-02-hero.css | 44 | 0 | 661px |
| `03-feature` | feature | 1.8KB | skin-03-feature-split.css | 58 | 2 | 2col · →1col · media 1.33 · 44%w · 1654px |
| `04-showcase-panels` | showcase-panels | 3.0KB | — | 31 | 3 | 3col · →1col · media 1.45 · 24%w · 934px |
| `05-logos` | logos | 1.7KB | skin-05-logos.css | 36 | 0 | 179px |
| `06-stat-cards` | stat-cards | 3.1KB | — | 21 | 4 | 4col · →2col · media 1.6 · 16%w · 436px |
| `07-steps` | steps | 0.9KB | skin-07-steps.css | 47 | 0 | 5col · →1col · 493px |
| `08-spotlight-show` | spotlight-show | 4.5KB | — | 113 | 2 | 2col · →1col · media 1.6 · 18%w · 971px |
| `09-statement` | statement | 1.9KB | — | 240 | 0 | 895px |
| `10-pricing` | pricing | 1.4KB | skin-09-pricing.css | 47 | 0 | 3col · →1col · 783px |
| `11-faq` | faq | 2.3KB | skin-10-faq.css | 78 | 0 | 640px |
| `12-contact` | contact | 0.9KB | skin-11-contact.css | 24 | 0 | 2col · →1col · 672px |
| `13-card-grid` | card-grid | 5.9KB | skin-12-card-grid.css | 65 | 6 | 3col · →1col · media 1 · 27%w · 1544px |
| `14-index-tiles` | index-tiles | 3.3KB | skin-13-index-tiles.css | 29 | 4 | 4col · →1col · media 0.75 · 22%w · 777px |
| `15-cta` | cta | 0.4KB | skin-14-cta.css | 15 | 0 | 468px |
| `16-footer` | footer | 1.7KB | skin-15-footer.css | 30 | 0 | 4col · →1col · 328px |

```json
{"01-nav":"skin-01-nav.css","02-hero":"skin-02-hero.css","03-feature":"skin-03-feature-split.css","05-logos":"skin-05-logos.css","07-steps":"skin-07-steps.css","10-pricing":"skin-09-pricing.css","11-faq":"skin-10-faq.css","12-contact":"skin-11-contact.css","13-card-grid":"skin-12-card-grid.css","14-index-tiles":"skin-13-index-tiles.css","15-cta":"skin-14-cta.css","16-footer":"skin-15-footer.css"}
```

Whole reference page: 37.7KB · foundation 46.5KB.

## What each section is made of

Derived by `tools/describe-sections.mjs` — selectors matched in a browser, knobs read out of
`template.js`, hexes counted in the skin block. Read this instead of opening `template.js` or the
stylesheet: the four things below are what eleven runs went hunting for after composing, and they
are the ones the markup you composed does not tell you.

A **knob** changes what ships. `[data-cardgrid]` hides every card past `data-batch`, so a grid you
filled with six cards renders three until you raise it or drop the control. **Hardcoded** tints are
fixed hexes in the skin; the palette does not reach them, so a colour system you picked will not
recolour those parts.

Every section is also touched by `[data-motion="text-split"]` — the shared
motion/reveal runner, which reads data-to, data-suffix, data-motion, data-speed, data-pscale.
Listed once here; the lines below name only what is specific to one section.

### `01-nav`
- driven by: `.nav__burger` — reads data-open; · `.nav__menu a` — queries .nav__burger · `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label

### `02-hero`
- repeats: .mo-in ×5, .hero__metaItem ×3
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `03-feature`
- repeats: .h2 ×3
- driven by: nothing of its own
- behaviour attributes present: data-motion, data-speed, data-pscale

### `04-showcase-panels`
- repeats: .xhead__seg ×3, .spnl__panel ×3, .spnl__top ×3
- driven by: `[data-motion="word-reveal"]` —
- behaviour attributes present: data-motion, data-speed, data-pscale

### `05-logos`
- repeats: .logos__item ×36
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `06-stat-cards`
- repeats: .stc__card ×4, .stc__num ×4, .stc__graphic ×4
- one repeat holds: img×1, p×1
- driven by: nothing of its own
- behaviour attributes present: data-motion, data-speed, data-pscale

### `07-steps`
- repeats: .steps__item ×3, .steps__num ×3, .h3 ×3
- one repeat holds: h3×1, p×1
- driven by: nothing of its own

### `08-spotlight-show`
- repeats: .sx__tab ×3
- driven by: `[data-spotlight-show]` — reads data-i, data-d; queries .sx__data, .sx__quote, .sx__name, .sx__role, .sx__avatar
- behaviour attributes present: data-d, data-i

### `09-statement`
- driven by: nothing of its own

### `10-pricing`
- repeats: .pr__card ×3, .h3 ×3, .pr__tier ×3
- one repeat holds: h3×1, li×3, a×1
- driven by: nothing of its own

### `11-faq`
- repeats: .faq__item ×4, .faq__q ×4, .faq__icon ×4
- one repeat holds: svg×1, p×1
- driven by: `.faq__item` — queries summary, .faq__a

### `12-contact`
- repeats: .cf__field ×3
- driven by: `.cf__form` — queries .cf__ok

### `13-card-grid`
- repeats: .mono ×18, .cg__card ×6, .cg__media ×6
- driven by: `[data-cardgrid]` — reads data-batch, data-cat; queries .cg__tab, .cg__card, .cg__morewrap, .cg__more, .cg__grid
- behaviour attributes present: data-cat, data-motion, data-speed, data-pscale

### `14-index-tiles`
- repeats: .it__tile ×4, .it__media ×4, .media ×4
- one repeat holds: img×1, h3×1, p×1
- driven by: nothing of its own
- behaviour attributes present: data-motion, data-speed, data-pscale

### `15-cta`
- driven by: nothing of its own

### `16-footer`
- repeats: .ft__col ×3, .ft__h ×3
- one repeat holds: h3×1, li×2, a×2
- driven by: `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label
