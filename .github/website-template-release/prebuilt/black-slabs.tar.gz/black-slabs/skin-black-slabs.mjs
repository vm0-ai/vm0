/* skin-monolith.mjs — a Website Studio skin learned from an enterprise process-automation
 * marketing site (poetic.com), re-expressed (source branding/copy/assets stripped).
 *
 * this skin: per Tong's feedback, a learned site's identity is its
 * LAYOUT/STRUCTURE, not just paint. So this skin now brings STRUCTURAL sections (graphic
 * stat-cards · large full-bleed showcase panels with a floating light mock · an ASYMMETRIC
 * spotlight with scattered text + a giant wordmark band · mixed-tone scroll-recolour headings),
 * plus hover/scroll interactions — not only a recolour of the fixed 15.
 *
 * ESSENCE — "monolith": ONE neutral grotesque, one weight, set EXTREMELY tight (a wall of type);
 * pure black/white with a single surgical electric-indigo accent; airy white fields interleaved
 * with full-bleed BLACK "moment" slabs; numbering motif; recurring tiny indigo corner-square.
 */
export const skin = {
  id:'black-slabs',
  fontsAttr:'monolith', motionAttr:'kinetic',
  parallax:{speed:0.05, scale:1.14},
  fontLink:'<link href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@400;500;600;700;800&display=swap" rel="stylesheet">',
  signature:'monolithic tight grotesque · graphic metric cards · full-bleed showcase panels with floating light mock · asymmetric scattered-text spotlight + giant wordmark band · mixed-tone scroll-recolour headings · surgical electric-indigo + corner-square motif on pure B/W',
  css:`
/* ① COLOURS — dual-mode, all 11 roles --------------------------------------------------- */
/* PALETTE — re-mapped to our OWN scheme (NOT the source's brand colours, for copyright safety):
 * the LANGUAGE we keep is "monochrome + ONE surgical electric accent + black moment-slabs";
 * the accent is now a deep electric TEAL of our own (was the source's ultramarine indigo). B/W
 * neutrals are generic (not copyrightable). Swap --accent/--ix to retarget the whole skin. */
:root{
  --bg:#FBFBF9; --ink:#17181C; --ink-soft:#6A6A66;
  --accent:#0C7C6C; --accent-ink:#FFFFFF;             /* deep electric teal (ours) */
  --support-1:#0A0A0A; --support-2:#13A18C;
  --surface:#F1F1ED; --surface-2:#E7E7E1;
  --border:#DCDCD6; --ring:#0C7C6C;
  --fd:'Schibsted Grotesk'; --fb:'Schibsted Grotesk';
  --radius:5px; --container:var(--w-wide); --gutter:clamp(1.1rem,4.5vw,4.5rem);
  --slab:#070707; --ix:#2FDCC4;                       /* black moment ground + on-slab bright teal */
}
html[data-theme="dark"]{
  --bg:#0C0D0D; --ink:#F2F3EF; --ink-soft:#9A9B95;
  --accent:#2FDCC4; --accent-ink:#062019;            /* bright teal clears AA on near-black */
  --support-1:#FFFFFF; --support-2:#5FE8D4;
  --surface:#15171A; --surface-2:#1E2024;
  --border:#2A2C2E; --ring:#2FDCC4;
  --slab:#040404;
}

/* shared chrome — the MONOLITHIC voice: one grotesque, tight tracking, tight leading */
.display{font-weight:800;letter-spacing:-.045em;line-height:.92}
h1,.h1{font-weight:700;letter-spacing:-.04em;line-height:.96}
h2,.h2{font-weight:700;letter-spacing:-.035em;line-height:1.0}
h3,.h3{font-weight:600;letter-spacing:-.02em;line-height:1.08}
.lead{color:var(--ink-soft);letter-spacing:-.01em}
.eyebrow{display:inline-flex;align-items:center;gap:.55em;font-weight:700;font-size:.74rem;
  letter-spacing:.16em;text-transform:uppercase;color:var(--ink)}
.eyebrow::before{content:"";width:.5em;height:.5em;border-radius:50%;background:var(--accent);flex:none}
.mono{font-family:var(--fd);font-weight:600;letter-spacing:.04em}
strong{font-weight:700}

/* buttons — pill pair: black-fill primary + outline ghost */
.btn{border-radius:var(--r-pill);font-weight:600;letter-spacing:-.01em;padding:.78rem 1.5rem}
.btn-primary{background:var(--ink);color:var(--bg);border-color:var(--ink)}
.btn-ghost{background:transparent;color:var(--ink);border:1px solid var(--ink)}
.btn-primary:hover{background:var(--accent);border-color:var(--accent);color:#fff}
.btn-ghost:hover{border-color:var(--accent);color:var(--accent)}

/* the BLACK MOMENT SLAB — flooded ground; fixed dark in BOTH themes, accent→light indigo */
[data-ground="dark"]{--bg:var(--slab);--ink:#FFFFFF;--ink-soft:#A6A6A0;--surface:transparent;
  --surface-2:transparent;--border:#1E1E1E;--accent:var(--ix);--accent-ink:#0A0A0A;
  background:var(--slab);color:#fff}
[data-ground="dark"] .eyebrow{color:#fff}
html[data-theme="dark"] .fg__card,html[data-theme="dark"] .stc__card,
html[data-theme="dark"] .spnl__panel,html[data-theme="dark"] .cta__panel,html[data-theme="dark"] .pr__card--pop{border:1px solid #26262B}

/* mixed-tone heading (the colour-shifts-mid-sentence treatment) */
.xhead{font-size:clamp(1.9rem,4.6vw,3.4rem);letter-spacing:-.035em;line-height:1.04;max-width:26ch}
.xhead--ink{color:var(--ink)} .xhead--accent{color:var(--accent)} .xhead--muted{color:var(--ink-soft)}

/* tiny indigo corner-square motif */
.stc__corner,.spnl__corner{background:var(--accent)}

/* ===== STRUCTURAL sections this skin brings (the LAYOUT, not just paint) ================= */

/* STAT-CARDS — black squares: big white number TL, graphic centre, caption BL, indigo corner */
.stc{padding-block:clamp(1.5rem,3vw,2.5rem) clamp(3rem,7vw,5rem)}
.stc__card{background:var(--slab);color:#fff;border-radius:var(--radius)}
.stc__num{color:#fff;font-weight:800;letter-spacing:-.045em}
.stc__graphic{background:#101012;border-radius:6px;width:84%;transition:transform .5s cubic-bezier(.2,.7,.2,1)}
.stc__cap{color:#A6A6A0;letter-spacing:-.005em}
.stc__card:hover .stc__graphic{transform:scale(1.045)}

/* SHOWCASE-PANELS — LARGE full-bleed black panels; title TL, index TR, floating LIGHT mock */
.spnl{padding-block:clamp(2.5rem,5vw,4rem)}
.spnl .container{max-width:none}                       /* go wide / near full-bleed */
.spnl .xhead{margin:0 auto clamp(2rem,4vw,3.5rem);text-align:center}
.spnl__grid{gap:clamp(.6rem,1.2vw,1rem)}
.spnl__panel{background:var(--slab);color:#fff;border-radius:var(--radius);
  min-height:clamp(420px,46vw,580px);padding:clamp(1.6rem,2.6vw,2.4rem)}
.spnl__title{color:#fff;font-size:clamp(1.4rem,2.2vw,2rem);letter-spacing:-.03em;max-width:14ch}
.spnl__ix{color:var(--ix);font-size:1.15rem;font-weight:700}
.spnl__mock{background:#fff;border-radius:14px;box-shadow:0 24px 60px rgba(0,0,0,.5);
  aspect-ratio:16/11;transition:transform .5s cubic-bezier(.2,.7,.2,1)}
.spnl__panel:hover .spnl__mock{transform:translateY(-8px)}

/* SPOTLIGHT-SHOW — asymmetric scattered text on black + giant wordmark band */
.sx__ix{font-family:var(--fd);font-weight:800;font-size:clamp(2.6rem,5vw,4rem);line-height:.9;color:#fff;display:block}
.sx__label{color:#fff;font-weight:700;letter-spacing:-.005em;margin-top:.5rem;max-width:14ch}
.sx__graphic{background:linear-gradient(135deg,#0C7C6C,#04201c);border-radius:6px}
.sx__quote{font-weight:700;letter-spacing:-.03em;line-height:1.14;color:#fff;font-size:clamp(1.5rem,3.2vw,2.5rem)}
.sx__avatar{border-radius:4px}                          /* SQUARE avatar */
.sx__name{font-weight:700;color:#fff;letter-spacing:-.01em}
.sx__role{color:#A6A6A0}
.sx__arrow{color:#fff;border-color:#3A3A3A}
.sx__arrow:hover{border-color:var(--ix);color:var(--ix)}
.sx__tab{color:#fff}
.sx__tab.is-active{color:var(--ix);opacity:1}
.sx__wordmark{color:#fff;opacity:.97}

/* ===== the fixed 15, in the monolith character ========================================== */

/* 1 · NAV */
.nav{background:color-mix(in srgb,var(--bg) 88%,transparent);backdrop-filter:blur(10px);border-bottom:1px solid var(--border)}
.nav__bar{min-height:70px}
.nav__brand{font-weight:800;letter-spacing:-.05em;font-size:1.32rem}
.nav__links a{font-size:.92rem;font-weight:500;letter-spacing:-.01em}
.nav__cta{padding:.6rem 1.2rem}

/* 2 · HERO — statement wall + a thin editorial meta rule + corner-square motif */
.hero{padding-block:clamp(3.5rem,8vw,7rem) clamp(2rem,5vw,3.5rem);position:relative;overflow:hidden}
.hero .display{font-size:clamp(2.7rem,8.2vw,6.6rem);max-width:15ch}
.hero__lead{font-size:var(--t-lead);max-width:48ch;margin-top:var(--space-5)}
.hero__cta{margin-top:var(--space-6)}
.hero__meta{display:flex;flex-wrap:wrap;gap:clamp(1.2rem,3vw,3rem);margin-top:clamp(2.5rem,5vw,3.5rem);padding-top:var(--space-5);border-top:1px solid var(--border)}
.hero__metaItem{display:flex;align-items:center;gap:.5rem;color:var(--ink-soft);font-size:.86rem;letter-spacing:-.005em}
.hero__metaItem::before{content:"";width:8px;height:8px;background:var(--accent)}
.hero__corner{position:absolute;top:clamp(1.5rem,5vw,4rem);right:clamp(1.1rem,4.5vw,4.5rem);width:14px;height:14px;background:var(--accent)}

/* 3 · FEATURE-SPLIT — accent index per row, hairline rules, square media */
.fs__heading{font-size:clamp(2rem,4.5vw,3.2rem);max-width:16ch;letter-spacing:-.035em}
.fs__rows{gap:0}.fs{counter-reset:fsx}
.fs__row{padding-block:clamp(2.5rem,5vw,4.2rem);border-top:1px solid var(--border);position:relative}
.fs__row:first-child{border-top:0}
.fs__text .h2{font-size:clamp(1.6rem,3vw,2.3rem)}
.fs__text .lead{max-width:46ch}
.fs__icon{display:none}
.fs__text::before{counter-increment:fsx;content:"/" counter(fsx,decimal-leading-zero);display:block;font-family:var(--fd);font-weight:700;color:var(--accent);font-size:1rem;margin-bottom:var(--space-4)}
.fs .media{border-radius:var(--radius);aspect-ratio:4/3;border:1px solid var(--border)}

/* 4 · FEATURE-GRID — black panels (index TL, icon chip TR, caption bottom) */
.fg__grid{gap:clamp(.6rem,1.2vw,1rem);counter-reset:fgx}
.fg__card{position:relative;background:var(--slab);color:#fff;border:0;border-radius:var(--radius);padding:clamp(1.4rem,2.4vw,2rem);min-height:clamp(260px,30vw,360px);display:flex;flex-direction:column;justify-content:flex-end;overflow:hidden}
.fg__card::before{counter-increment:fgx;content:"/" counter(fgx);position:absolute;top:clamp(1.2rem,2vw,1.8rem);left:clamp(1.4rem,2.4vw,2rem);font-family:var(--fd);font-weight:700;color:var(--ix);font-size:.95rem}
.fg__icon{position:absolute;top:clamp(1rem,2vw,1.6rem);right:clamp(1.4rem,2.4vw,2rem);width:42px;height:42px;border:1px solid #242424;border-radius:var(--radius);color:var(--ix);background:#0E0E0E}
.fg__card .h3{color:#fff;font-size:clamp(1.25rem,2vw,1.6rem);margin-bottom:var(--space-2)}
.fg__card .muted{color:#A6A6A0}
.fg--bento .fg__card:nth-child(6n+1){min-height:clamp(280px,34vw,440px)}

/* 5 · LOGOS — brand names rendered LARGE */
.logos{padding-block:clamp(2.2rem,5vw,3.5rem)}
.logos__label{letter-spacing:.16em;text-transform:uppercase;font-weight:700;color:var(--ink-soft);font-size:.74rem}
.logos__marquee,.logos__row{gap:clamp(2rem,5vw,4.5rem)}
.logos__item{font-weight:800;letter-spacing:-.045em;font-size:clamp(1.6rem,3.4vw,2.6rem);color:var(--ink);opacity:1}

/* 6 · STATS — black slab band, huge tabular numerals, hairline column rules */
.stats{padding-block:clamp(3rem,7vw,5.5rem)}
.stats__grid{gap:0;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));text-align:left}
.stats__cell{padding:clamp(1rem,2.4vw,2rem);border-left:1px solid var(--border)}
.stats__cell:first-child{border-left:0;padding-left:0}
.stats__num{color:var(--ink);font-weight:800;letter-spacing:-.045em;line-height:.88;font-size:clamp(2.6rem,6vw,4.4rem);font-variant-numeric:tabular-nums}
.stats__cell .small{color:var(--ink-soft);margin-top:var(--space-3);font-size:.86rem;max-width:18ch}

/* 7 · STEPS — oversized accent indices (no rows: a clean 3-up in this layout, so no hairline) */
.steps__list{gap:0}
.steps__item{padding-block:clamp(1.6rem,3.2vw,2.4rem);align-items:baseline;gap:clamp(1rem,3vw,2.4rem)}
.steps__num{background:transparent;color:var(--accent);width:auto;height:auto;border-radius:0;font-weight:800;font-size:clamp(1.6rem,3vw,2.4rem);letter-spacing:-.03em;flex:none;min-width:2.6ch}
.steps__item .h3{font-size:clamp(1.3rem,2.2vw,1.7rem)}

/* 8 · TESTIMONIAL — big tight quote, square avatar, accent quote-mark */
.tm__grid{gap:clamp(1rem,2vw,1.4rem)}
.tm__card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:clamp(1.6rem,3vw,2.4rem);position:relative}
.tm__card::before{content:"\\201C";position:absolute;top:.2rem;right:1.2rem;font-family:var(--fd);font-weight:800;font-size:4rem;line-height:1;color:var(--accent);opacity:.9}
.tm__quote{font-weight:600;letter-spacing:-.02em;font-size:clamp(1.05rem,1.5vw,1.22rem);line-height:1.4}
.tm__avatar{width:52px;height:52px;border-radius:4px;object-fit:cover}
.tm__name{font-weight:700;letter-spacing:-.01em}
.tm--spotlight .tm__quote{font-weight:700;letter-spacing:-.03em;font-size:clamp(1.7rem,4vw,2.8rem);line-height:1.12}
.tm--spotlight .tm__card::before{display:none}

/* 9 · PRICING — stark hairline columns; popular plan inverts to a slab */
.pr__grid{gap:clamp(.6rem,1.2vw,1rem)}
.pr__card{background:var(--bg);border:1px solid var(--ink);border-radius:var(--radius);padding:clamp(1.8rem,3vw,2.6rem)}
.pr__tier{font-size:1.15rem;text-transform:uppercase;font-weight:700}
.pr__amt{font-weight:800;letter-spacing:-.05em;font-size:clamp(2.4rem,4.5vw,3.4rem)}
.pr__feats li{color:var(--ink-soft)}
.pr__feats li::before{border-radius:0;width:7px;height:7px;background:var(--accent)}
.pr__card--pop{background:var(--slab);border-color:var(--slab);color:#fff;box-shadow:none}
.pr__card--pop .pr__tier,.pr__card--pop .pr__amt{color:#fff}
.pr__card--pop .pr__feats li,.pr__card--pop .small,.pr__card--pop .muted{color:#C9C9C2}
.pr__card--pop .pr__feats li::before{background:var(--ix)}
.pr__card--pop .pr__badge{background:var(--ix);color:#0A0A0A}
.pr__card--pop .pr__cta{background:#fff;color:#0A0A0A;border-color:#fff}

/* 10 · FAQ — big tight questions, hairline list, accent icon */
.faq__h{font-size:clamp(1.8rem,3.5vw,2.8rem);letter-spacing:-.035em}
.faq__item{border-bottom:1px solid var(--border)}
.faq__q{font-weight:700;letter-spacing:-.02em;font-size:clamp(1.1rem,1.8vw,1.4rem);padding-block:clamp(1.1rem,2vw,1.5rem)}
.faq__icon{color:var(--accent)}
.faq__a .muted{color:var(--ink-soft);font-size:1.02rem}

/* 11 · CONTACT — underline-only fields */
.cf__field span{text-transform:uppercase;letter-spacing:.1em;font-size:.74rem;color:var(--ink-soft)}
.cf__field input,.cf__field textarea{background:transparent;border:0;border-bottom:1px solid var(--ink);border-radius:0;padding:.6rem 0;font-weight:500}
.cf__field input:focus,.cf__field textarea:focus{box-shadow:none;border-bottom-color:var(--accent)}
.cf__form .btn{align-self:flex-start;margin-top:var(--space-3)}

/* 12 · CARD-GRID — framed cards, square media, mono meta, accent hover */
.cg__tab{border-radius:var(--r-pill);font-weight:600}
.cg__card{background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);padding:var(--space-4)}
.cg__card:hover{border-color:var(--accent);transform:translateY(-2px)}
.cg__media{border-radius:4px;aspect-ratio:1/1}
.cg__tag{border-radius:0;color:var(--accent);border-color:var(--accent);text-transform:uppercase}
.cg__meta{font-family:var(--fd)}
.cg__title{font-size:clamp(1.15rem,1.8vw,1.45rem)}
.cg__link{color:var(--accent)}

/* 13 · INDEX-TILES — sharp tiles, oversized index */
.it__grid{gap:clamp(.5rem,1vw,.85rem)}
.it__tile{border-radius:var(--radius)}
.it__tile::after{background:linear-gradient(to top,rgba(0,0,0,.82),rgba(0,0,0,.05) 60%,rgba(0,0,0,.32))}
.it__num{font-weight:800;letter-spacing:-.04em;font-size:2.4rem;opacity:.95}
.it__title{font-size:clamp(1.2rem,2vw,1.55rem);letter-spacing:-.02em}

/* 14 · CTA — black slab with an oversized faint wordmark behind */
.cta{padding-block:clamp(3rem,7vw,5rem);padding-inline:var(--gutter)}
.cta__panel{background:var(--slab);color:#fff;border-radius:var(--radius);position:relative;overflow:hidden;padding:clamp(2.6rem,6vw,5rem)}
.cta__panel::before{content:"GO";position:absolute;right:-2%;bottom:-26%;font-family:var(--fd);font-weight:800;font-size:clamp(9rem,26vw,20rem);letter-spacing:-.06em;line-height:1;color:#fff;opacity:.05;pointer-events:none}
.cta__title{color:#fff;font-weight:800;letter-spacing:-.04em;font-size:clamp(2rem,4.5vw,3.4rem);max-width:18ch}
.cta__sub{color:#A6A6A0}
.cta__btn{background:#fff;color:#0A0A0A}
.cta__btn:hover{background:var(--ix);color:#0A0A0A}

/* 15 · FOOTER — hairline grid, oversized tight brand mark */
footer{background:var(--bg);border-top:1px solid var(--ink)}
.ft__name{font-weight:800;letter-spacing:-.05em;font-size:clamp(1.6rem,3vw,2.4rem)}
.ft__h{text-transform:uppercase;letter-spacing:.12em;font-size:.72rem;color:var(--ink-soft);font-weight:700}
.ft__col a{font-size:.92rem}
.ft__bottom{border-top:1px solid var(--border);padding-top:var(--space-5)}
`,

  /* HERO — statement wall + editorial meta rule + corner-square. The graphic metric cards live
   * in the statCards section placed right after (poetic's hero+stats unit). */
  heroHTML({wordmark, title, lead, dots=[], ctas=[], meta}){
    const btns = ctas.map((c,i)=>`<a class="btn ${i===0?'btn-primary':'btn-ghost'}" href="${c.href}">${c.label}</a>`).join('');
    const tags = (meta||['SOC 2 Type II','Zero data retention','Self-healing']).map(m=>`<span class="hero__metaItem">${m}</span>`).join('');
    return `<section class="section hero" data-section="hero" data-variant="statement" data-signature="monolith-hero">
      <span class="hero__corner" data-signature="corner-square" aria-hidden="true"></span>
      <div class="container">
        ${dots.length?`<p class="eyebrow" data-motion="reveal-fade">${dots[0]}</p>`:''}
        <h1 class="display" data-motion="reveal-up" style="overflow-wrap:anywhere">${title||wordmark}</h1>
        ${lead?`<p class="lead hero__lead" data-motion="reveal-up">${lead}</p>`:''}
        ${btns?`<div class="hero__cta" data-motion="reveal-up">${btns}</div>`:''}
        <div class="hero__meta" data-motion="reveal-fade">${tags}</div>
      </div></section>`;
  }
};
