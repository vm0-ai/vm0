# Black Slabs — design system

Measured from the local `template.css` and `index.html`. These are facts about
the shipped stylesheet, not intentions. Where a value here disagrees with prose anywhere else, this
file is right.

## Character

> monolithic tight grotesque · graphic metric cards · full-bleed showcase panels with floating light mock · asymmetric scattered-text spotlight + giant wordmark band · mixed-tone scroll-recolour headings · surgical electric-indigo + corner-square motif on pure B/W

A **monolithic wall of type** — ONE neutral grotesque, one weight, set EXTREMELY tight — on a pure

Schibsted Grotesk for BOTH display & body (monolithic). Display 800 / `-0.045em` / `line-height .92`.

- spotlight block has a **fixed height (560px)** so switching brand tabs never resizes it: top row

## Type

| | |
|---|---|
| Families loaded | `Schibsted Grotesk` |
| Display face | `'Schibsted Grotesk'` |
| Body face | `'Schibsted Grotesk'` |
| Font personality flag | `data-fonts="monolith"` |

Both faces are declared as tokens, so a brand type change is a two-line edit in
`style[data-brand-theme]` — not a find-and-replace through the stylesheet.

## Colour roles

The stylesheet reads colour only through these roles. Rebinding them in `style[data-brand-theme]`
restyles the whole page; writing a literal colour anywhere else forks it.

| role | light | dark |
|---|---|---|
| `--bg` | #FBFBF9 | #0C0D0D |
| `--ink` | #17181C | #F2F3EF |
| `--ink-soft` | #6A6A66 | #9A9B95 |
| `--accent` | #0C7C6C | #2FDCC4 |
| `--accent-ink` | #FFFFFF | #062019 |
| `--support-1` | — | #2DD4BF |
| `--support-2` | #13A18C | #5FE8D4 |
| `--surface` | #F1F1ED | #15171A |
| `--surface-2` | #E7E7E1 | #1E2024 |
| `--border` | #DCDCD6 | #2A2C2E |
| `--ring` | #0C7C6C | #2FDCC4 |
| `--slab` | #070707 | #040404 |

Generate a replacement set with `node tools/palette.mjs --pick <system>`; use `--list` to choose and `--check` to audit bespoke values.
The values above are the reference page's own palette; they are a demonstration, not a requirement.

## Structural tokens

| token | value |
|---|---|
| `--container` | var(--w-wide) |
| `--fb` | 'Schibsted Grotesk' |
| `--fd` | 'Schibsted Grotesk' |
| `--fx-aurora-1` | 12s |
| `--fx-aurora-2` | 14s |
| `--fx-aurora-3` | 16s |
| `--fx-aurora-blur` | 90px |
| `--fx-aurora-opacity` | .5 |
| `--fx-grain-opacity` | .085 |
| `--gutter` | clamp(1.1rem,4.5vw,4.5rem) |
| `--ix` | #2FDCC4 |
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |
| `--radius` | 5px |

**Spacing scale** — `--space-2`=.5rem · `--space-3`=.75rem · `--space-4`=1rem · `--space-5`=1.5rem · `--space-6`=2rem · `--space-7`=3rem · `--space-8`=4rem · `--space-9`=6rem · `--space-10`=8rem



## Motion

| token | value |
|---|---|
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |

Motion personality: `kinetic`. `template.js` binds the reveals, the marquee, the
disclosure widgets, the theme toggle and the mobile nav. Reveals must degrade to visible content —
never hide a whole section behind an IntersectionObserver.

## Device vocabulary

Class prefixes that carry layout in the reference page, by frequency. Compose from these; a class
that is not here has no stylesheet behind it, and inventing one produces an unstyled bare tag.

`.mono`×25 · `.small`×22 · `.media`×20 · `.muted`×17 · `.container`×16 · `.h3`×16 · `.section`×14 · `.h2`×12 · `.btn`×9 · `.lead`×8 · `.body`×7 · `.sec-head`×6 · `.btn-primary`×4 · `.eyebrow`×4 · `.btn-ghost`×4 · `.theme-toggle`×2 · `.skip`×1 · `.nav`×1 · `.theme-toggle--nav`×1 · `.hero`×1 · `.display`×1 · `.fs`×1 · `.fs--even`×1 · `.fs--rev`×1 · `.spnl`×1 · `.xhead`×1 · `.xhead--ink`×1 · `.xhead--accent`×1 · `.xhead--muted`×1 · `.logos`×1 · `.logos--wall`×1 · `.stc`×1 · `.steps`×1 · `.sx`×1

## Reference density

The reference page carries **812 visible words** across its sections. That is a description
of this example, not a target. Say what the brief supports and stop — a page padded to reach a
word count reads like one, and the reader can tell.
