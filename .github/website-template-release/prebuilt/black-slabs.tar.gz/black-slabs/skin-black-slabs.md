# Skin — `black-slabs`

Learned from an enterprise process-automation marketing site (poetic.com), re-expressed (source
branding / copy / assets **and colours** stripped per the ingestion copyright guardrails).

## Essence
A **monolithic wall of type** — ONE neutral grotesque, one weight, set EXTREMELY tight — on a pure
black/white canvas with a **single surgical electric accent** + a recurring **tiny corner-square**.
Airy white fields breathe against **full-bleed black "moment" slabs** (light↔dark rhythm).
**Numbering is a motif** (`/01`, big indices). Sharp small radius + pill buttons.

## The model: system DEFINES the 15 sections; the skin FILLS each in this style
The distinctive STRUCTURES are folded into the matching contract section (not shipped as extras):
- **feature-grid → showcase panels** — LARGE full-bleed black panels: title top-left, big `/n`
  index top-right, corner-square, a **floating light product MOCK** that **lifts on hover**.
- **stats → graphic metric cards** — square black cards: big number top-left, a real centred
  graphic, caption bottom-left, corner-square; graphic **scales on hover** / parallax on scroll.
- **testimonial → asymmetric spotlight** — index + label top-left, graphic top-right, an OFFSET
  large quote, **square** avatar bottom-left, prev/next + **brand-tab switcher** bottom-right
  (cross-fades the slide, keyboard-operable), and a **GIANT wordmark band** beneath.
The other 12 are the standard contract sections dressed by the skin (nav glass hairline · statement
hero + editorial meta-rule + corner-square · feature-split big `/0n` indices + hairline rules ·
logos rendered LARGE · steps oversized accent indices · pricing popular plan inverts to a slab · faq
big tight Qs + accent `+`→`×` · contact underline-only fields · card-grid square media + accent
hover · index-tiles oversized index · cta black slab + oversized faint wordmark · footer hairline).

## Palette (RE-MAPPED — not the source's brand colours, for copyright safety)
Kept the LANGUAGE (monochrome + ONE electric accent + black slabs); changed the accent from the
source's ultramarine indigo to **our own deep electric TEAL**: light `#0C7C6C`, on-slab / dark-theme
`#2FDCC4`. B/W neutrals are generic. Dual-mode. All accent refs are centralized in `:root`/dark +
`--ix` + one gradient, so retargeting is a token swap. (If the team has a brand palette, map to it —
or pick any of the 16 catalogue palettes; see `System MD/palettes-and-fonts.md`.)

## Fonts
Schibsted Grotesk for BOTH display & body (monolithic). Display 800 / `-0.045em` / `line-height .92`.

## Interactions / fixes baked in
- spotlight block has a **fixed height (560px)** so switching brand tabs never resizes it: top row
  (index/label + graphic) top-aligned, quote+attribution+controls bottom-aligned.
- prev/next arrows use **inline SVG chevrons** (perfectly centred; not text glyphs).
- custom **dot cursor** hides the native pointer (`html.mo-cursor-on{cursor:none}`; reduced-motion
  users keep the native cursor).
- logo marquee **repeats to fill** the row (no empty gap on short lists).
- integrated **theme toggle** in nav + footer (needs `THEME_JS` injected).

## Gate status
All 15 sections **PASS** full matrix (4 bp × 2 themes · contrast · type-floor · DUAL-MODE) **and**
`--site` (SIGNATURE · MOTION-NON-UNIFORM · LAYOUT-VARIETY).

## Live
- **All 15 sections filled in the black-slabs style** (this folder's `skinsheet-black-slabs.html`):
  https://black-slabs-15-715f6d07-856bfe34.sites.vm0.io
- Build it: `node build-black-slabs-15.mjs` (in Sites/black-slabs).
