
(function(){try{var t=localStorage.getItem('theme');if(t)document.documentElement.setAttribute('data-theme',t)}catch(e){}})();

document.querySelectorAll('.nav__burger').forEach(function(b){
  b.addEventListener('click',function(){
    var nav=b.closest('.nav'); var open=nav.getAttribute('data-open')==='true';
    nav.setAttribute('data-open',String(!open)); b.setAttribute('aria-expanded',String(!open));
  });
});
document.querySelectorAll('.nav__menu a').forEach(function(a){
  a.addEventListener('click',function(){var nav=a.closest('.nav');if(nav){nav.setAttribute('data-open','false');
    var b=nav.querySelector('.nav__burger');if(b)b.setAttribute('aria-expanded','false');}});
});


document.querySelectorAll('.cf__form').forEach(function(f){ f.addEventListener('submit',function(e){
  e.preventDefault(); if(!f.checkValidity()){f.reportValidity();return;}
  var ok=f.querySelector('.cf__ok'); if(ok)ok.hidden=false; f.reset(); });});


document.querySelectorAll('[data-cardgrid]').forEach(function(grid){
  var tabs=[].slice.call(grid.querySelectorAll('.cg__tab'));
  var cards=[].slice.call(grid.querySelectorAll('.cg__card'));
  var morewrap=grid.querySelector('.cg__morewrap'), more=grid.querySelector('.cg__more');
  var rail=grid.querySelector('.cg__grid');var prevB=grid.querySelector('.cg__nav--prev'),nextB=grid.querySelector('.cg__nav--next');
  function railStep(d){if(!rail)return;var c=rail.querySelector('.cg__card');var w=c?c.getBoundingClientRect().width+28:300;rail.scrollBy({left:d*w,behavior:'smooth'});}
  if(prevB)prevB.addEventListener('click',function(){railStep(-1);});if(nextB)nextB.addEventListener('click',function(){railStep(1);});
  var batch=parseInt(grid.getAttribute('data-batch'),10)||6, cur='all', shown=batch;
  function render(){
    var matched=cards.filter(function(c){return cur==='all'||c.getAttribute('data-cat')===cur;});
    cards.forEach(function(c){c.hidden=true;});
    matched.slice(0,shown).forEach(function(c){c.hidden=false;});
    if(morewrap) morewrap.hidden = matched.length<=shown;
  }
  tabs.forEach(function(t){ t.addEventListener('click',function(){
    tabs.forEach(function(x){x.setAttribute('aria-pressed','false');});
    t.setAttribute('aria-pressed','true'); cur=t.getAttribute('data-cat')||'all'; shown=batch; render();
  });});
  if(more) more.addEventListener('click',function(){ shown+=batch; render(); });
  render();
});


(function(){
  var RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
  document.querySelectorAll('.faq__item').forEach(function(d){
    var sum=d.querySelector('summary'), body=d.querySelector('.faq__a'), anim=null;
    if(!sum||!body) return;
    sum.addEventListener('click',function(e){
      if(RM) return;                                  // let native toggle handle it
      e.preventDefault();
      if(anim){ anim.cancel(); anim=null; }
      var pb=getComputedStyle(body).paddingBottom||'0px';   // animate padding too → true 0 collapse
      if(!d.open){                                    // OPEN: render, then grow 0→auto
        d.open=true; var h=body.offsetHeight;
        anim=body.animate([{height:'0px',opacity:0,paddingBottom:'0px'},{height:h+'px',opacity:1,paddingBottom:pb}],{duration:280,easing:'cubic-bezier(.2,.8,.2,1)'});
        anim.onfinish=function(){if(anim){anim.cancel();anim=null;}body.style.height='';};
      } else {                                        // CLOSE: shrink auto→0 (incl padding), hold 0, THEN unset open
        var start=body.offsetHeight; d.setAttribute('data-closing','');
        anim=body.animate([{height:start+'px',opacity:1,paddingBottom:pb},{height:'0px',opacity:0,paddingBottom:'0px'}],{duration:240,easing:'cubic-bezier(.4,0,.2,1)',fill:'forwards'});
        // fill:forwards holds height:0 so there's NO 1-frame pop back to full height (the close stutter);
        // padding animates to 0 too so it doesn't plateau at the padding height. Close details FIRST
        // (→display:none), then release the held animation.
        anim.onfinish=function(){d.open=false;d.removeAttribute('data-closing');if(anim){anim.cancel();anim=null;}body.style.height='';};
      }
    });
  });
})();


(function(){
  if(matchMedia('(prefers-reduced-motion:reduce)').matches) return;
  if(!('IntersectionObserver' in window)) return;
  document.querySelectorAll('[data-sticky-scroll]').forEach(function(sec){
    var panels=[].slice.call(sec.querySelectorAll('.ss__panel'));
    var items=[].slice.call(sec.querySelectorAll('.ss__item'));
    if(panels.length<2||!items.length) return;
    function activate(i){ panels.forEach(function(p){ p.classList.toggle('is-active', +p.getAttribute('data-i')===i); }); }
    var io=new IntersectionObserver(function(es){
      es.forEach(function(e){ if(e.isIntersecting) activate(+e.target.getAttribute('data-i')); });
    },{rootMargin:'-48% 0px -48% 0px',threshold:0});
    items.forEach(function(it){io.observe(it);});
  });
})();


(function(){
  var root=document.documentElement;
  function apply(){var d=root.getAttribute('data-theme')||'light';
    document.querySelectorAll('[data-theme-toggle]').forEach(function(b){
      b.setAttribute('aria-checked',String(d==='dark'));
      b.setAttribute('aria-label',d==='dark'?'Switch to light theme':'Switch to dark theme');
      var l=b.querySelector('.theme-toggle__label'); if(l)l.textContent=d==='dark'?'Light mode':'Dark mode';
    });}
  document.querySelectorAll('[data-theme-toggle]').forEach(function(b){b.addEventListener('click',function(){
    var d=(root.getAttribute('data-theme')||'light')==='dark'?'light':'dark';
    root.setAttribute('data-theme',d);try{localStorage.setItem('theme',d)}catch(e){}apply();});});
  apply();
})();


(function(){
  var root=document.documentElement;
  var RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
  var HOVER=matchMedia('(hover:hover)').matches;
  var num=function(v,d){v=parseFloat(v);return isNaN(v)?d:v;};

  // text-split: wrap each word in <span class=mo-line><span class=mo-w --i></span></span>
  document.querySelectorAll('[data-motion="text-split"]').forEach(function(el){
    var words=el.textContent.trim().split(/\s+/); el.textContent='';
    words.forEach(function(w,i){ var line=document.createElement('span'); line.className='mo-line';
      var s=document.createElement('span'); s.className='mo-w'; s.style.setProperty('--i',i); s.textContent=w;
      line.appendChild(s); el.appendChild(line); if(i<words.length-1) el.appendChild(document.createTextNode(' ')); });
  });
  // stagger: index children
  document.querySelectorAll('[data-motion="stagger"]').forEach(function(el){
    [].forEach.call(el.children,function(c,i){c.style.setProperty('--i',i);}); });

  if(RM){ document.querySelectorAll('[data-motion^="reveal"],[data-motion="stagger"],[data-motion="text-split"],[data-motion="count-up"]').forEach(function(e){e.classList.add('mo-in');}); return; }

  // marquee: clone the track once for a seamless -50% loop. Idempotent — skip if already wrapped
  // (a page whose DOM was serialized AFTER this ran, e.g. apply-photos output, won't double-wrap).
  document.querySelectorAll('[data-motion="marquee"]').forEach(function(el){
    if(el.querySelector('.mo-track')) return;
    var t=document.createElement('div'); t.className='mo-track'; while(el.firstChild)t.appendChild(el.firstChild);
    el.appendChild(t);
    // A SHORT list makes the track narrower than the viewport → the -50% loop leaves an empty gap
    // on the right (uneven distribution). Repeat the base items until one track comfortably exceeds
    // a wide viewport, THEN clone it for the seamless loop. So a few logos still fill the row.
    var base=t.innerHTML, guard=0;
    while(t.scrollWidth < 2200 && guard++ < 24){ t.insertAdjacentHTML('beforeend', base); }
    var c=t.cloneNode(true); el.appendChild(c); });

  // count-up tween
  function countUp(el){ var to=num(el.getAttribute('data-to'),num(el.textContent,0)); var suf=el.getAttribute('data-suffix')||'';
    var dur=1400, t0=null; function step(t){ if(!t0)t0=t; var k=Math.min(1,(t-t0)/dur); var e=1-Math.pow(1-k,3);
      el.textContent=Math.round(to*e)+suf; if(k<1)requestAnimationFrame(step); } requestAnimationFrame(step); }

  // IntersectionObserver: reveal family + count-up
  if('IntersectionObserver' in window){
    var io=new IntersectionObserver(function(es){es.forEach(function(e){ if(!e.isIntersecting)return;
      var el=e.target; el.classList.add('mo-in');
      if(el.getAttribute('data-motion')==='count-up') countUp(el);
      io.unobserve(el); });},{threshold:.16,rootMargin:'0px 0px -8% 0px'});
    document.querySelectorAll('[data-motion^="reveal"],[data-motion="stagger"],[data-motion="text-split"],[data-motion="count-up"]').forEach(function(e){io.observe(e);});
  } else { document.querySelectorAll('[data-motion]').forEach(function(e){e.classList.add('mo-in');}); }

  // rAF: parallax + image-parallax + scroll-progress
  var paras=[].slice.call(document.querySelectorAll('[data-motion="parallax"]'));
  var imgs=[].slice.call(document.querySelectorAll('[data-motion="image-parallax"] > *'));
  var bars=[].slice.call(document.querySelectorAll('[data-motion="scroll-progress"]'));
  var ticking=false;
  function frame(){ var vh=innerHeight, mid=vh/2;
    paras.forEach(function(el){ var sp=num(el.getAttribute('data-speed'),.18); var r=el.getBoundingClientRect();
      var off=((r.top+r.height/2)-mid)*-sp; el.style.transform='translate3d(0,'+off.toFixed(1)+'px,0)'; });
    imgs.forEach(function(el){ var p=el.parentElement; var sp=num(p.getAttribute('data-speed'),.06); var sc=num(p.getAttribute('data-pscale'),1.18);
      var r=p.getBoundingClientRect(); var off=((r.top+r.height/2)-mid)*sp;   /* +sp: scroll DOWN → image drifts UP (conventional parallax) */
      var hw=(sc-1)/2*r.height*.92; if(off>hw)off=hw; else if(off<-hw)off=-hw;   /* CLAMP to the scale headroom so the image always covers — never a gap at the frame edge */
      el.style.transform='scale('+sc+') translate3d(0,'+off.toFixed(1)+'px,0)'; });
    if(bars.length){ var h=document.documentElement.scrollHeight-innerHeight; var k=h>0?Math.min(1,scrollY/h):0;
      bars.forEach(function(b){b.style.transform='scaleX('+k.toFixed(4)+')';}); }
    ticking=false; }
  function onScroll(){ if(!ticking){ticking=true; requestAnimationFrame(frame);} }
  if(paras.length||imgs.length||bars.length){ addEventListener('scroll',onScroll,{passive:true}); addEventListener('resize',onScroll); frame(); }

  if(!HOVER) return;
  // custom cursor — the understated dot (grows on interactive, difference blend). The ONE cursor.
  var cur=document.createElement('div'); cur.className='mo-cursor'; cur.style.opacity='0'; document.body.appendChild(cur);
  document.documentElement.classList.add('mo-cursor-on');   // → hide the native pointer (CSS, pointer devices only)
  addEventListener('pointermove',function(e){ cur.style.opacity='1'; cur.style.left=e.clientX+'px'; cur.style.top=e.clientY+'px'; });
  document.querySelectorAll('a,button,[data-magnetic],[data-motion="hover-tilt"],[data-motion="magnetic"]').forEach(function(el){
    el.addEventListener('pointerenter',function(){cur.classList.add('mo-big');});
    el.addEventListener('pointerleave',function(){cur.classList.remove('mo-big');}); });

  // hover-tilt (rotateX/Y toward cursor)
  document.querySelectorAll('[data-motion="hover-tilt"]').forEach(function(el){
    el.addEventListener('pointermove',function(e){ var t=num(getComputedStyle(root).getPropertyValue('--mo-tilt'),6);
      var r=el.getBoundingClientRect(); var px=(e.clientX-r.left)/r.width-.5, py=(e.clientY-r.top)/r.height-.5;
      el.style.transform='perspective(800px) rotateY('+(px*t).toFixed(2)+'deg) rotateX('+(-py*t).toFixed(2)+'deg)'; });
    el.addEventListener('pointerleave',function(){el.style.transform='';}); });

  // magnetic (translate toward cursor)
  document.querySelectorAll('[data-motion="magnetic"]').forEach(function(el){
    el.addEventListener('pointermove',function(e){ var m=num(getComputedStyle(root).getPropertyValue('--mo-mag'),.3);
      var r=el.getBoundingClientRect(); var dx=(e.clientX-(r.left+r.width/2))*m, dy=(e.clientY-(r.top+r.height/2))*m;
      el.style.transform='translate('+dx.toFixed(1)+'px,'+dy.toFixed(1)+'px)'; });
    el.addEventListener('pointerleave',function(){el.style.transform='';}); });

  // spotlight (move the radial light)
  document.querySelectorAll('[data-motion="spotlight"]').forEach(function(el){
    el.addEventListener('pointermove',function(e){ var r=el.getBoundingClientRect();
      el.style.setProperty('--mx',(e.clientX-r.left)+'px'); el.style.setProperty('--my',(e.clientY-r.top)+'px'); }); });
})();



document.querySelectorAll('[data-fixed-showcase]').forEach(function(sec){
  var cards=[].slice.call(sec.querySelectorAll('.fx__card'));
  var dots=[].slice.call(sec.querySelectorAll('.fx__dot'));
  var spacers=[].slice.call(sec.querySelectorAll('.fx__spacer'));
  if(cards.length<2){ return; }
  var RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
  var MOB=matchMedia('(max-width:767px)').matches;
  if(RM || MOB || !('IntersectionObserver' in window)){ sec.classList.add('is-static'); return; }
  var cur=0;
  function show(i){ i=(i+cards.length)%cards.length; cur=i;
    cards.forEach(function(c,j){ c.classList.toggle('is-active',j===i); });
    dots.forEach(function(d,j){ d.classList.toggle('is-active',j===i); d.setAttribute('aria-pressed',String(j===i)); });
  }
  sec.querySelectorAll('.fx__arrow').forEach(function(a){ a.addEventListener('click',function(){ show(cur + (+a.getAttribute('data-d'))); }); });
  dots.forEach(function(d){ d.addEventListener('click',function(){ show(+d.getAttribute('data-i')); }); });
  if(spacers.length===cards.length){
    var io=new IntersectionObserver(function(es){ es.forEach(function(e){ if(e.isIntersecting) show(+e.target.getAttribute('data-i')); }); },
      {rootMargin:'-50% 0px -50% 0px',threshold:0});
    spacers.forEach(function(s){ io.observe(s); });
  }
  show(0);
});
