# Section library — blueprint-grid

Cut from the reference page by `tools/split-sections.mjs`. Pick the sections the brief supports,
in the order `NARRATIVE.md` gives, and assemble with `tools/compose.mjs`. A section you do not
pick is not in the page, so it cannot be left half-edited.

`_foundation.css`, `_baselayer.css` and `_shell.part` are always included. `css −` means the section reuses a skin
block an earlier section already brought. `geometry` is measured off the reference page at 1440 and
390 — column counts, the first media box's aspect ratio and its share of the section width, and the
section's own height. Read it here rather than opening the stylesheet.

| section | kind | html | skin | words | imgs | geometry |
|---|---|---|---|---|---|---|
| `01-nav` | nav | 1.8KB | skin-01-nav.css | 11 | 0 | 69px |
| `02-hero` | hero | 1.2KB | skin-02-hero.css | 46 | 1 | 2col · →1col · media 0.98 · 52%w · 772px |
| `03-grid-editorial` | grid-editorial | 1.3KB | — | 92 | 1 | 4col · →1col · media 0.8 · 46%w · 1252px |
| `04-logos` | logos | 1.4KB | skin-03-logos.css | 36 | 0 | 170px |
| `05-feature` | feature | 1.5KB | skin-04-feature-grid.css | 51 | 2 | 2col · →1col · media 1.33 · 54%w · 1359px |
| `06-feature-grid` | feature-grid | 3.9KB | skin-04-feature-grid.css (shared) | 83 | 0 | 3col · →1col · 1013px |
| `07-fixed-showcase` | fixed-showcase | 3.0KB | — | 62 | 3 | media 1.6 · 2700px |
| `08-stats` | stats | 0.6KB | skin-05-stats.css | 15 | 0 | 8col · →2col · 362px |
| `09-steps` | steps | 0.8KB | skin-06-steps.css | 49 | 0 | 784px |
| `10-index-tiles` | index-tiles | 2.6KB | skin-13-index-tiles.css | 31 | 4 | 4col · →1col · media 0.75 · 23%w · 809px |
| `11-card-grid` | card-grid | 5.1KB | skin-12-card-grid.css | 72 | 6 | 3col · →1col · media 1.33 · 28%w · 1375px |
| `12-testimonial` | testimonial | 2.5KB | skin-08-testimonial.css | 69 | 3 | 3col · →1col · media 1 · 3%w · 575px |
| `13-statement` | statement | 1.9KB | — | 240 | 0 | 940px |
| `14-pricing` | pricing | 1.4KB | skin-09-pricing.css | 57 | 0 | 3col · →1col · 812px |
| `15-faq` | faq | 2.2KB | skin-10-faq.css | 86 | 0 | 677px |
| `16-contact` | contact | 0.9KB | skin-11-contact.css | 31 | 0 | 2col · →1col · 735px |
| `17-cta` | cta | 0.4KB | skin-14-cta.css | 20 | 0 | 503px |
| `18-footer` | footer | 1.7KB | skin-15-footer.css | 38 | 0 | 3col · →1col · 601px |

```json
{"01-nav":"skin-01-nav.css","02-hero":"skin-02-hero.css","04-logos":"skin-03-logos.css","05-feature":"skin-04-feature-grid.css","06-feature-grid":"skin-04-feature-grid.css","08-stats":"skin-05-stats.css","09-steps":"skin-06-steps.css","10-index-tiles":"skin-13-index-tiles.css","11-card-grid":"skin-12-card-grid.css","12-testimonial":"skin-08-testimonial.css","14-pricing":"skin-09-pricing.css","15-faq":"skin-10-faq.css","16-contact":"skin-11-contact.css","17-cta":"skin-14-cta.css","18-footer":"skin-15-footer.css"}
```

Whole reference page: 36.4KB · foundation 41.8KB.

## What each section is made of

Derived by `tools/describe-sections.mjs` — selectors matched in a browser, knobs read out of
`template.js`, hexes counted in the skin block. Read this instead of opening `template.js` or the
stylesheet: the four things below are what eleven runs went hunting for after composing, and they
are the ones the markup you composed does not tell you.

A **knob** changes what ships. `[data-cardgrid]` hides every card past `data-batch`, so a grid you
filled with six cards renders three until you raise it or drop the control. **Hardcoded** tints are
fixed hexes in the skin; the palette does not reach them, so a colour system you picked will not
recolour those parts.

Every section is also touched by `[data-motion="text-split"]` — the shared
motion/reveal runner, which reads data-to, data-suffix, data-motion, data-speed, data-pscale.
Listed once here; the lines below name only what is specific to one section.

### `01-nav`
- driven by: `.nav__burger` — reads data-open; · `.nav__menu a` — queries .nav__burger · `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label

### `02-hero`
- repeats: .mo-in ×5
- one repeat holds: img×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `03-grid-editorial`
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `04-logos`
- repeats: .logos__item ×28
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `05-feature`
- repeats: .h2 ×3
- driven by: nothing of its own
- behaviour attributes present: data-motion, data-speed, data-pscale

### `06-feature-grid`
- repeats: .fg__card ×6, .fg__icon ×6, .h3 ×6
- one repeat holds: svg×1, h3×1, p×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `07-fixed-showcase`
- repeats: .media ×3
- one repeat holds: img×1
- driven by: `[data-fixed-showcase]` — reads data-d, data-i; queries .fx__card, .fx__dot, .fx__spacer, .fx__arrow
- behaviour attributes present: data-i, data-d

### `08-stats`
- repeats: .stats__cell ×4, .stats__num ×4, .small ×4
- one repeat holds: p×1
- driven by: nothing of its own

### `09-steps`
- repeats: .steps__item ×3, .steps__num ×3, .h3 ×3
- one repeat holds: h3×1, p×1
- driven by: nothing of its own

### `10-index-tiles`
- repeats: .it__tile ×4, .it__media ×4, .media ×4
- one repeat holds: img×1, h3×1, p×1
- driven by: nothing of its own
- behaviour attributes present: data-motion, data-speed, data-pscale

### `11-card-grid`
- repeats: .mono ×18, .cg__card ×6, .cg__media ×6
- driven by: `[data-cardgrid]` — reads data-batch, data-cat; queries .cg__tab, .cg__card, .cg__morewrap, .cg__more, .cg__grid
- behaviour attributes present: data-cat, data-motion, data-speed, data-pscale

### `12-testimonial`
- repeats: .tm__card ×3, .tm__quote ×3, .tm__by ×3
- one repeat holds: img×1
- driven by: nothing of its own

### `13-statement`
- driven by: nothing of its own

### `14-pricing`
- repeats: .pr__card ×3, .h3 ×3, .pr__tier ×3
- one repeat holds: h3×1, li×3, a×1
- driven by: nothing of its own

### `15-faq`
- repeats: .faq__item ×4, .faq__q ×4, .faq__icon ×4
- one repeat holds: svg×1, p×1
- driven by: `.faq__item` — queries summary, .faq__a

### `16-contact`
- repeats: .cf__field ×3
- driven by: `.cf__form` — queries .cf__ok

### `17-cta`
- driven by: nothing of its own

### `18-footer`
- driven by: `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label
- skin hardcodes: --ink:#EBEBEB, --ink-soft:#9AA0B4 (the palette will not reach these)
