# Blueprint Grid — design system

Measured from the local `template.css` and `index.html`. These are facts about
the shipped stylesheet, not intentions. Where a value here disagrees with prose anywhere else, this
file is right.

## Character

> thin oversized UPPERCASE grotesque × Space-Mono body · faint 4-column vertical-rule grid overlay · bracketed mono micro-labels + 01-02 indices · editorial ↗ arrow link-rows with hairline dividers · sharp full-bleed navy/court-azure grounds · deep royal-cobalt accent

An editorial **construction-drawing** system. THIN oversized **UPPERCASE grotesque** display set

- display: **Hanken Grotesk** (light neutral grotesque — free stand-in for the source's thin NeueHelvetica);

## Type

| | |
|---|---|
| Families loaded | `Hanken Grotesk` · `Space Mono` |
| Display face | `'Hanken Grotesk'` |
| Body face | `'Space Mono'` |
| Font personality flag | `data-fonts="blueprint-grid"` |

Both faces are declared as tokens, so a brand type change is a two-line edit in
`style[data-brand-theme]` — not a find-and-replace through the stylesheet.

## Colour roles

The stylesheet reads colour only through these roles. Rebinding them in `style[data-brand-theme]`
restyles the whole page; writing a literal colour anywhere else forks it.

| role | light | dark |
|---|---|---|
| `--bg` | #EBEBEB | #0B0F1E |
| `--ink` | #0F1320 | #EBEBEB |
| `--ink-soft` | #50566A | #9AA0B4 |
| `--accent` | #192B88 | #6E8CFF |
| `--accent-ink` | #FFFFFF | #0A0E1E |
| `--support-1` | — | #2DD4BF |
| `--support-2` | #3E6E9E | #7FB0DC |
| `--surface` | — | #121729 |
| `--surface-2` | #D7D7D4 | #1A2038 |
| `--border` | #C6C6C2 | #2A3252 |
| `--ring` | #192B88 | #6E8CFF |

Generate a replacement set with `node tools/palette.mjs --pick <system>`; use `--list` to choose and `--check` to audit bespoke values.
The values above are the reference page's own palette; they are a demonstration, not a requirement.

## Structural tokens

| token | value |
|---|---|
| `--container` | var(--w-wide) |
| `--court` | #2F5E86 |
| `--fb` | 'Space Mono' |
| `--fd` | 'Hanken Grotesk' |
| `--fx-aurora-1` | 12s |
| `--fx-aurora-2` | 14s |
| `--fx-aurora-3` | 16s |
| `--fx-aurora-blur` | 90px |
| `--fx-aurora-opacity` | .5 |
| `--fx-grain-opacity` | .085 |
| `--fx-ground` | var(--court) |
| `--gutter` | clamp(1.1rem,4vw,3.5rem) |
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |
| `--navy` | #0F1320 |
| `--radius` | 0 |

**Spacing scale** — `--space-2`=.5rem · `--space-3`=.75rem · `--space-4`=1rem · `--space-5`=1.5rem · `--space-6`=2rem · `--space-7`=3rem · `--space-8`=4rem · `--space-9`=6rem · `--space-10`=8rem



## Motion

| token | value |
|---|---|
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |

Motion personality: `kinetic`. `template.js` binds the reveals, the marquee, the
disclosure widgets, the theme toggle and the mobile nav. Reveals must degrade to visible content —
never hide a whole section behind an IntersectionObserver.

## Device vocabulary

Class prefixes that carry layout in the reference page, by frequency. Compose from these; a class
that is not here has no stylesheet behind it, and inventing one produces an unstyled bare tag.

`.muted`×29 · `.mono`×24 · `.small`×23 · `.h3`×22 · `.media`×17 · `.container`×16 · `.section`×16 · `.h2`×16 · `.body`×13 · `.btn`×9 · `.lead`×9 · `.sec-head`×8 · `.eyebrow`×5 · `.btn-primary`×4 · `.btn-ghost`×4 · `.theme-toggle`×2 · `.xn-arrow`×2 · `.skip`×1 · `.nav`×1 · `.theme-toggle--nav`×1 · `.hero`×1 · `.xnhero`×1 · `.display`×1 · `.ge`×1 · `.logos`×1 · `.logos--wall`×1 · `.fs`×1 · `.fs--media-wide`×1 · `.fs--rev`×1 · `.fg`×1 · `.fg--cards`×1 · `.fx`×1 · `.stats`×1 · `.steps`×1

## Reference density

The reference page carries **1083 visible words** across its sections. That is a description
of this example, not a target. Say what the brief supports and stop — a page padded to reach a
word count reads like one, and the reader can tell.
