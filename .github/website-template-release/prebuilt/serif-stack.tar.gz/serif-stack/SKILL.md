# Serif Stack — direct-HTML website template

Select the sections, run `tools/compose.mjs` exactly once, then edit the composed `index.html`.

> minimalist serif hero + a GRAVITY tag-cloud (library-icon pills drop in, settle at the bottom, scatter from the cursor) · page-by-page cover-stack work scroll · scattered photos with straighten-on-hover · blinking-eyes footer

## Read in this order

| file                 | what it decides                                                                                                                                                                                                                      |
| -------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `sections/_index.md` | **read this instead of `index.html`** — every section: size, words, image slots, measured geometry, and what it is made of (repeats, the script that drives it and the attributes that script reads, tints the palette cannot reach) |
| `checks/GATES.md`    | what every gate requires, one line each. Read it before authoring, not after failing. Do not open `checks/gates.mjs` — it is a thousand lines of measurement code and this is its answer                                             |
| `index.html`         | only if you need to see a device in its original context; 86KB, and you do not have to read it                                                                                                                                       |
| `NARRATIVE.md`       | the page structure — the beats, their order, and how proof is layered                                                                                                                                                                |
| `COLOR-SYSTEM.md`    | how to select, seed or audit a palette with this package's local tools                                                                                                                                                               |
| `layout-map.md`      | which device _this_ template uses for each beat                                                                                                                                                                                      |
| `design-system.md`   | the measured type, colour, spacing, motion and device vocabulary                                                                                                                                                                     |

`template.css` and `template.js` are reusable primitives already linked from `index.html`. Keep the
links. Do not open them on the normal path — the device map below is enough unless a named QA failure
cannot be repaired from its reported actual/required values.

## Default color tokens

These are this template's shipped reference values, not a palette requirement. When the brief or
brand evidence calls for another palette, replace the semantic roles as one set with
`node tools/palette.mjs`; do not scatter literal colours through the page.

| role           | light   | dark    |
| -------------- | ------- | ------- |
| `--bg`         | #FFFFFF | #0A0A0A |
| `--ink`        | #0A0A0A | #F2F2F2 |
| `--ink-soft`   | #565656 | #9A9A9A |
| `--accent`     | #111111 | #FFFFFF |
| `--accent-ink` | #FFFFFF | #0A0A0A |
| `--support-1`  | #0f0f0f | #fbfbfb |
| `--support-2`  | #626262 | #acacac |
| `--surface`    | #f4f4f4 | #181818 |
| `--surface-2`  | #eaeaea | #242424 |
| `--border`     | #dadada | #383838 |
| `--ring`       | #111111 | #FFFFFF |
| `--slab`       | #050505 | #040404 |

## Sequence

1. Read the brief. Resolve the **single conversion action**.
2. Compose the beat list from `NARRATIVE.md` against the brief — not from this example's section
   order. Drop beats the brief cannot support honestly; never invent evidence to fill one.
3. Choose the palette: `node tools/palette.mjs --list`, then `node tools/palette.mjs --pick <id>`.
   A palette is six values per mode; surface, ink-soft and border derive from them. Paste the printed
   blocks into `<style data-brand-theme>` and declare `data-palette-source` /
   `data-palette-system` / `data-palette-reason` on `<html>`. If none of the fourteen fits the brief,
   write your own six values and audit them with `--check` — a bespoke palette held to the same rules
   is fine; an unaudited one is not.
4. Pick the sections the brief supports. Before any page authoring, assemble them exactly once.

   During generation, actively combine multiple distinct motion families provided by the template—especially sticky or pinned storytelling, cover stacks, draggable rails, parallax, and ambient motion—and place the strongest effects at key narrative beats so the page feels visually rich, dynamic, and engaging without compromising readability or performance.

   ```bash
   cat sections/_index.md                                  # what exists, and what each costs
   node tools/compose.mjs <section-ids-in-narrative-order...>
   ```

   `compose.mjs` writes `index.html` and `template.css` from what you named, in the order you named
   it. `NARRATIVE.md` decides that order, not the numbering — the numbers are only where each
   section sat in the reference page. This is the one allowed assembly pass: do not edit the
   original `index.html` before this command, and do not run `compose.mjs` again after authoring
   begins, because it rewrites both files. The command writes `.compose-once.json` and refuses a
   second assembly; if the selection was wrong, restart from a fresh template copy instead of
   bypassing the marker.

5. Directly author the composed `index.html` while any VM0-managed image jobs run.

   Replace every demo fact, link, asset, title and brand reference **in the sections you kept**.
   A section you did not pick is not in the page and cannot be left half-edited; that is the reason
   this path exists. You still own grouping, column structure, responsive behaviour, type hierarchy,
   image placement, fit, crop and interactions inside what you picked.

   Read the selected markup first, then write the page in one go; do not patch it section by section.

   After compose succeeds, begin substantive `index.html` authoring immediately. Do not query image
   progress, reopen the section menu, or inspect `template.css`, `template.js` or gate implementation
   while authoring remains. If the VM0 run prompt started image work, wait for it exactly once after
   the HTML is authored; generation commands and scheduling remain owned by that prompt.

   The VM0 run prompt owns image generation and scheduling. When assets are ready, place them in the
   selected slots and copy each reported `dataGenerationSize` into the corresponding
   `data-generation-size`. Then run `node tools/brand-assets.mjs` for the favicon and social card.

6. Run `bash checks/verify.sh index.html qa` as-is. Repair every blocking failure against its printed
   `actual` / `required` values and rerun until clean. The script creates `qa/` and its own log; do
   not redirect or pipe it. When it prints `QA_READY`, every blocking gate and the motion contract
   passed; proceed directly to staging and publishing. `QA_NOTE` advisories do not block delivery.

   The gate has already used `tools/screenshot.mjs` to write `qa/review-atlas.png`. If a concrete
   concern still requires visual confirmation, inspect that one image once. Do not take more
   screenshots, crop or pixel-search it, or start a recognition loop. It is overview evidence, not
   motion evidence. On `QA_MOTION_FAIL`, repair from `qa/motion-states.json` and its focused
   ordinary-viewport failure image.

7. Stage and publish once: `node tools/stage.mjs publish && okou host publish --site <slug>`.
8. Run `bash checks/verify-published.sh <url>` against the deployed page. A local pass is not evidence
   about a different directory or deployment.

## Device map

Compose freely from these; they are not a section plan.

`.mono` · `.media` · `.small` · `.muted` · `.h3` · `.container` · `.h2` · `.section` · `.btn` · `.lead` · `.body` · `.tagpill` · `.btn-ghost` · `.sec-head` · `.eyebrow` · `.btn-primary` · `.theme-toggle` · `.c1` · `.c3` · `.c2` · `.c6` · `.c4`

Anything not in `design-system.md`'s vocabulary has no stylesheet behind it. Inventing a class name
produces a bare unstyled tag — the reset strips margins page-wide, so two `<p>` dropped into a
`.container` touch each other and left-hug their measure under a centred head. Running copy goes in
`.prose`; new composition CSS goes in `<style data-brand-theme>`, never in `template.css`.

```html
<section class="section" data-section="statement" data-node-id="why-now">
  <div class="container">
    <div class="sec-head">
      <p class="eyebrow">Why now</p>
      <h2 class="h2">One real claim</h2>
    </div>
    <div class="prose" data-prose="wide">
      <p class="lead">The opening paragraph carries the argument.</p>
      <p>Following paragraphs get their own break automatically.</p>
    </div>
  </div>
</section>
```

## Style DNA — keep these

- See `design-system.md`.

Keep `data-section`, `data-node-id`, palette metadata and image decision attributes. If a composition
removes a demo anchor, replace it with an equivalent one.

## Images

Image sourcing, generation and scheduling are run-level decisions owned by the VM0 prompt. This
template owns only selection and presentation:

- Use only the selected sections' real slots; there is no image quota. Describe the subject, setting,
  light, mood and required display size for every slot the page keeps.
- Declare `data-image-role`, `data-image-presentation`, `data-image-fit="cover|contain|natural"` and
  `data-image-crop-safety` on every real image. Text-bearing media (screenshots, diagrams, documents,
  product UI) must never use `cover`, and must render at >= 0.5 of natural width.
- When an asset is supplied, copy its reported `dataGenerationSize` into `data-generation-size`.
- No gradient, coloured rectangle or decorative SVG counts as an image. If a slot has no real image,
  remove the wrapper and its width reservation and recompose at full width — never leave a blank half
  column beside missing media.

<!-- MEASURED:BEGIN -->

### Measured identity constants

Measured off this package's `index.html` by `tools/stamp-identity.mjs` at 1440×900 and 390×844.
Stated as floors with slack, so a different composition can still satisfy them.

- **Type.** Headings are set in `Cormorant Garamond` on at least 90% of visible
  `h1`/`h2`; body is `Inter` at 17px. Display sits at least
  **4.05×** body for the hero and **1.82×** for `h2` on desktop;
  **2.11×** and **1.21×** on mobile. At a 80px
  headline that is tracking `-0.025em`, leading `1.02`, weight
  `300`.
  Collapsing to one generic sans, or flattening the display/body ratio, removes the template.
- **Corner.** The modal radius across visible boxes is **`20px`**
  (profile: `20px`×54 · `999px`×50 · `16px`×32 · `14px`×28). Do not round or
  square boxes against this — the corner is identity, not taste.
- **Colour.** The reference accent is `#111111`, on a `#050505` deep band.
  Replace the palette with `node tools/palette.mjs`; keep the _allocation_ — how much of the page the
  accent touches, and whether the template uses a deep band at all.
- **Density.** 1521 visible words in `main` across 20 marked sections,
  1 `.prose` block(s) and 6 multi-paragraph
  block(s); widest paragraph box 815px.
  These describe the reference, not a target — say what the brief supports and stop. A page
  padded to hit a word count reads like one.
- **Frame.** No horizontal overflow at 390px (reference: clean).

<!-- MEASURED:END -->

## Authoring constraints

- Follow the brief and narrative; never pad the page merely to imitate the reference word count.
- ≥ 1 multi-paragraph `.prose` block carries the argument the cards summarise.
- ≥ 3 of the five trust kinds (credentials · scale · data · people · cases), at ≥ 3 separated points.
  This reference demonstrates: `proof-scale` · `proof-data` · `proof-cases` · `proof-people`.
- One primary action, repeated in hero, mid-page and close. No competing second primary.
- `og:title`, `og:description`, a loading `og:image`, a favicon.
- Desktop action width < 90% of any container ≥ 600px.
- Widest paragraph box ≥ 480px on desktop.
- Text-bearing images render at ≥ 0.5 of natural width; never `object-fit: cover` on a screenshot.
- Every text/ground pair ≥ 4.5:1 in **both** themes.
- Never hide a whole section behind an entrance animation.
- One `h1`, ordered headings, working anchors, visible focus, unique ids, alt text, no page overflow.
