/* skin-serif-stack.mjs — a Website-Studio skin (skin-contract.md).
 *
 * COPYRIGHT-SAFE RESKIN: colours come ONLY from the catalogue (`palettes.mjs` → palette `stone`) and
 * fonts ONLY from the catalogue (`fonts.mjs` → style `elegant` = Cormorant Garamond + Inter), plus the
 * library's Space Mono for the micro-label motif. NOTHING is hand-authored or lifted from the source —
 * the identity lives in the STRUCTURE/motion re-express, not the palette/typeface. (See memory
 * web-reskin-use-catalogue.) Learned language: airy TEXT-FIRST editorial minimalism.
 *
 * SIGNATURE moves: (1) minimalist serif hero with a floating TAG-CLOUD that SHRINKS upward; (2)
 * page-by-page COVER-STACK work scroll (promoted `coverStack`); (3) SCATTERED photos around centred
 * text with a straighten-on-hover lift (promoted `photoScatter`); (4) black footer with BLINKING eyes
 * + a giant serif nameplate.
 *
 * Prove: `node build-skinsheet.mjs skin-serif-stack.mjs` → qa-site full + --site must pass. */
import { paletteCSS } from './engine/palettes.mjs';
import { fontCSS } from './engine/fonts.mjs';
import { ic, iconFor } from './engine/icons.mjs';       // shared ICON LIBRARY (Lucide) — hero tags use these, not bespoke SVG

/* hero tag-cloud PHYSICS — inline in heroHTML so it ships with the skin (build-skinsheet/gen-engine
 * don't inject custom JS). Icon pills DROP in with gravity, settle & scatter at the bottom, and are
 * PUSHED AWAY from the cursor. Honours prefers-reduced-motion (keeps the calm flex-wrap layout). */
const CLOUD_JS = `
(function(){
  var s=document.currentScript, cloud=s&&s.parentElement; if(!cloud) return;
  var pills=[].slice.call(cloud.querySelectorAll('.tagpill')); if(!pills.length) return;
  if(matchMedia('(prefers-reduced-motion:reduce)').matches) return;   // leave the centred flex-wrap
  cloud.classList.add('is-physics');
  var W=0,H=0,G=0.48,REST=0.16,FR=0.92,MR=95,MF=2.4,mx=-1e5,my=-1e5,mon=false;   // calmer gravity/bounce + gentler cursor push
  var bodies=pills.map(function(p){return {el:p,x:0,y:0,vx:0,vy:0,a:0,va:0,w:0,h:0};});
  function measure(){ W=cloud.clientWidth; H=cloud.clientHeight; bodies.forEach(function(b){ b.w=b.el.offsetWidth; b.h=b.el.offsetHeight; }); }
  function drop(){ bodies.forEach(function(b,i){ b.x=Math.random()*Math.max(1,W-b.w); b.y=-b.h-Math.random()*120-i*16;   // start just above the TOP edge
    b.vx=(Math.random()-.5)*0.6; b.vy=0; b.a=(Math.random()-.5)*12; b.va=(Math.random()-.5)*1; }); }
  function draw(b){ b.el.style.transform='translate('+b.x.toFixed(1)+'px,'+b.y.toFixed(1)+'px) rotate('+b.a.toFixed(1)+'deg)'; }
  function frame(){ var i,j,b;
    for(i=0;i<bodies.length;i++){ b=bodies[i];
      b.vy+=G; b.x+=b.vx; b.y+=b.vy; b.a+=b.va; b.va*=0.99;
      if(b.x<0){b.x=0;b.vx=-b.vx*REST;} if(b.x+b.w>W){b.x=W-b.w;b.vx=-b.vx*REST;}
      if(b.y+b.h>H){ b.y=H-b.h; if(b.vy>0)b.vy=-b.vy*REST; b.vx*=FR; if(Math.abs(b.vy)<1.3)b.vy=0; b.va*=0.7; b.a*=0.92; }
      if(b.y<-620)b.y=-620;
      if(mon){ var cx=b.x+b.w/2, cy=b.y+b.h/2, dx=cx-mx, dy=cy-my, d2=dx*dx+dy*dy;
        if(d2<MR*MR){ var d=Math.sqrt(d2)||1, f=(MR-d)/MR*MF; b.vx+=dx/d*f; b.vy+=dy/d*f*0.5; } } }
    var ZONE=H-260;   // de-overlap ONLY in the bottom pile zone → airborne pills fall freely (no mid-air jams / stuck-high pills)
    for(i=0;i<bodies.length;i++)for(j=i+1;j<bodies.length;j++){ var A=bodies[i],C=bodies[j];
      if(A.y+A.h<ZONE||C.y+C.h<ZONE) continue;
      var ox=Math.min(A.x+A.w,C.x+C.w)-Math.max(A.x,C.x), oy=Math.min(A.y+A.h,C.y+C.h)-Math.max(A.y,C.y);
      if(ox>0&&oy>0){ if(ox<oy){ var sx=ox*0.3*(A.x<C.x?-1:1); A.x+=sx; C.x-=sx; A.vx*=.8;C.vx*=.8; }
        else{ var sy=oy*0.3*(A.y<C.y?-1:1); A.y+=sy; C.y-=sy; A.vy*=.6;C.vy*=.6; } } }
    for(i=0;i<bodies.length;i++) draw(bodies[i]);
    requestAnimationFrame(frame); }
  var hero=cloud.closest('.hero')||cloud;   // cloud is pointer-events:none (front overlay) → track the cursor on the hero
  hero.addEventListener('pointermove',function(e){ var r=cloud.getBoundingClientRect(); mx=e.clientX-r.left; my=e.clientY-r.top; mon=true; },{passive:true});
  hero.addEventListener('pointerleave',function(){ mon=false; mx=my=-1e5; });
  function boot(){ measure(); drop(); }
  boot(); requestAnimationFrame(frame);
  var rt; addEventListener('resize',function(){ clearTimeout(rt); rt=setTimeout(boot,220); });
})();
`;

const PALETTE = 'ink';        // catalogue palette (pure white/black, stark editorial — no warm cast) — palettes.mjs
const FONTS   = 'elegant';    // catalogue font style (Cormorant Garamond + Inter) — fonts.mjs

export const skin = {
  id:'serif-stack',
  fontsAttr:'serif-stack', motionAttr:'playful',
  cardLayout:'rail',
  indexLayout:'coverflow',   // index-tiles → Apple-style 3D cover-flow carousel (Tong, 2026-07-13)
  // library families only: Cormorant Garamond (elegant display) + Inter (body) + Space Mono (mono style)
  fontLink:'<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500&family=Inter:wght@400;500;600&family=Space+Mono:wght@400;500&display=swap" rel="stylesheet">',
  signature:'minimalist serif hero + a GRAVITY tag-cloud (library-icon pills drop in, settle at the bottom, scatter from the cursor) · page-by-page cover-stack work scroll · scattered photos with straighten-on-hover · blinking-eyes footer',
  css: paletteCSS(PALETTE) + '\n' + fontCSS(FONTS) + '\n' + `
/* fonts/personality levers layered on top of the catalogue palette + font style */
:root{--fm:'Space Mono';--radius:20px;--container:var(--w-standard);--navh:96px}

/* dark flood ground (plans may set ground:'dark') — reuse the palette's slab */
[data-ground="dark"]{background:var(--slab);color:#F3F2EE;--bg:var(--slab);--ink:#F3F2EE;--ink-soft:#B7B7BE;--border:rgb(255 255 255/.14)}

/* ---- shared chrome the skin owns (thin editorial serif) ---- */
.display,h1,.h1,h2,.h2,h3,.h3{font-family:var(--fd);letter-spacing:-.01em;font-weight:500}
.display{font-weight:300;line-height:1.02;letter-spacing:-.02em}
.display em,h1 em,h2 em,.display i,h1 i{font-style:italic;font-weight:400}
h2,.h2{font-weight:400;line-height:1.08}
h3,.h3{font-weight:500;line-height:1.2;letter-spacing:-.004em}
.mono{font-family:var(--fm)}
.eyebrow{font-family:var(--fm);font-weight:500;font-size:.72rem;letter-spacing:.12em;text-transform:uppercase;color:var(--ink-soft)}
.lead{color:var(--ink-soft);font-weight:400}
.muted{color:var(--ink-soft)}
.sec-head{text-align:left;margin-inline:0;max-width:38ch}
.sec-head .lead{margin-top:var(--space-3)}
.media{border-radius:var(--radius);border-color:var(--border)}

/* buttons — pills; primary = an ink pill (like the source's "View case study"), accent used as a ground */
.btn{border-radius:var(--r-pill);font-family:var(--fm);font-weight:500;font-size:.86rem;letter-spacing:.01em;text-transform:none;padding:.72rem 1.25rem}
.btn-primary{background:var(--ink);color:var(--bg);border-color:var(--ink)}
.btn-ghost{background:transparent;color:var(--ink);border-color:var(--border)}
.btn-ghost:hover{border-color:var(--ink)}
.btn:hover{transform:translateY(-1px)}

/* ③ FULL RESTYLE of every section ------------------------------------------------------- */

/* 1 · NAV — a floating pill: round ink brand badge + a rounded surface menu-pill. Give the header
   real breathing room from the top edge (Tong: was too close to the top). */
body>header{padding-top:clamp(1.1rem,2.8vw,2.2rem)}
.nav{background:transparent;border-bottom:0;top:clamp(.8rem,1.6vw,1.3rem)}
.nav__bar{min-height:60px;gap:var(--space-4)}
.nav__brand{width:52px;height:52px;flex:none;display:inline-flex;align-items:center;justify-content:center;
  border-radius:var(--r-pill);background:var(--ink);color:var(--bg);font-family:var(--fm);font-weight:500;
  font-size:.86rem;letter-spacing:.02em}
.nav__menu{gap:var(--space-4);background:var(--surface);border:1px solid var(--border);border-radius:var(--r-pill);
  padding:.4rem .5rem .4rem 1.2rem;box-shadow:0 8px 30px rgb(20 20 20/.07)}
.nav__links{gap:var(--space-5)}
.nav__links a{font-family:var(--fm);font-size:.8rem;letter-spacing:.01em;color:var(--ink-soft)}
.nav__cta{min-height:40px;padding:.5rem 1.1rem}
@media(max-width:767px){
  .nav__menu{border-radius:var(--r-lg);padding:var(--space-5);box-shadow:var(--shadow-lifted)}
  .nav__brand{width:46px;height:46px}
}

/* 2 · HERO — heroHTML() below. The tag-cloud + serif statement. */
.hero{position:relative;overflow:hidden;min-height:100svh;display:flex;flex-direction:column;text-align:center;
  margin-top:calc(-1*var(--navh));padding-top:calc(var(--navh) + clamp(1rem,3vh,2.5rem));padding-bottom:0}
.hero__wrap{position:relative;z-index:2;flex:none}   /* stays container-width (grid-consistency); inner text is centred + narrow */
.hero__hello{display:inline-flex;align-items:center;gap:.5rem;color:var(--ink-soft);font-size:.95rem;margin-bottom:var(--space-5)}
.hero__hello .ava{width:26px;height:26px;border-radius:50%;object-fit:cover;display:inline-block;
  background:linear-gradient(135deg,var(--support-1),var(--support-2))}
.hero__title{font-size:clamp(2.6rem,6.6vw,5rem);letter-spacing:-.025em;margin-inline:auto;max-width:15ch}
.hero__lead{margin:var(--space-5) auto 0;max-width:40ch;font-size:var(--t-lead)}
.hero__lead b,.hero__lead strong{color:var(--ink);font-weight:600}
.hero__cta{justify-content:center;margin-top:var(--space-6)}
/* the tag-cloud — a GRAVITY FIELD: icon pills (all SAME size) drop from the top, settle & scatter
   at the bottom, and get pushed away from the cursor (CLOUD_JS). Default (no-JS / reduced-motion) is
   a calm centred flex-wrap so the area is never blank. */
.hero__cloud{position:relative;z-index:1;width:100%;flex:1 1 auto;margin-top:clamp(1rem,2vh,1.6rem);
  display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:.55rem;padding-bottom:var(--space-4)}
.hero__cloud.is-physics{position:absolute;inset:0;z-index:3;height:auto;padding-bottom:0;overflow:hidden;pointer-events:none}   /* overlay the WHOLE hero, IN FRONT; pills fall from the top edge → settle at the bottom */
.tagpill{display:inline-flex;align-items:center;gap:.45rem;font-family:var(--fm);font-weight:500;
  font-size:.8rem;letter-spacing:.04em;text-transform:uppercase;color:var(--ink);
  background:var(--surface-2);border:1px solid var(--border);
  padding:.55rem 1rem;border-radius:var(--r-pill);white-space:nowrap;box-shadow:0 6px 18px rgb(20 20 20/.07)}
.hero__cloud.is-physics .tagpill{position:absolute;top:0;left:0;will-change:transform;pointer-events:none}
.tagpill svg{width:15px;height:15px;flex:none}
.tagpill.c1{background:color-mix(in srgb,var(--accent) 15%,var(--surface))}
.tagpill.c2{background:var(--surface-2)}
.tagpill.c3{background:color-mix(in srgb,var(--support-1) 22%,var(--surface))}
.tagpill.c4{background:color-mix(in srgb,var(--accent) 9%,var(--surface))}
.tagpill.c5{background:var(--surface)}
.tagpill.c6{background:color-mix(in srgb,var(--support-2) 26%,var(--surface))}
.tagpill.c7{background:var(--surface-2)}

/* 3 · FEATURE-SPLIT — editorial rows: mono eyebrow, thin serif title, generous rhythm */
.fs__heading{font-size:clamp(1.8rem,3.6vw,2.6rem);max-width:22ch}
.fs__rows{gap:clamp(3rem,7vw,6rem)}
.fs__text .h2{font-size:clamp(1.6rem,3vw,2.2rem)}
.fs__icon{border:0;background:var(--surface-2);border-radius:14px;color:var(--ink);width:52px;height:52px}
.fs .media{aspect-ratio:5/4}

/* 4 · FEATURE-GRID — soft rounded cards, serif titles, rounded icon chip */
.fg__grid{gap:var(--space-5)}
.fg__card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:clamp(1.5rem,2.4vw,2rem);
  transition:transform .18s ease,box-shadow .18s ease}
.fg__card:hover{transform:translateY(-4px);box-shadow:0 16px 40px rgb(20 20 20/.08)}
.fg__icon{border:0;background:var(--surface-2);border-radius:14px;color:var(--ink)}
.fg__card .h3{font-size:1.25rem;margin-bottom:var(--space-3)}

/* 5 · LOGOS — mono uppercase, quiet */
.logos__item{font-family:var(--fm);font-weight:500;font-size:1rem;letter-spacing:.02em;text-transform:uppercase;color:var(--ink-soft);opacity:.8}
.logos__label{font-family:var(--fm);text-transform:uppercase;letter-spacing:.14em}

/* 6 · STATS — big THIN serif numbers (ink), mono captions */
.stats__num{font-family:var(--fd);font-weight:300;color:var(--ink);font-size:clamp(2.6rem,6vw,4rem);letter-spacing:-.03em}
.stats__cell .small{font-family:var(--fm);text-transform:uppercase;letter-spacing:.08em;font-size:.74rem}
.stats__grid{gap:var(--space-7)}

/* 7 · STEPS — big serif index, hairline rule, no coloured bubble */
.steps__list{gap:var(--space-6) var(--space-7)}
.steps__item{gap:var(--space-4);border-top:1px solid var(--border);padding-top:var(--space-4);align-items:flex-start}
.steps__num{background:transparent;color:var(--ink);width:auto;height:auto;border-radius:0;font-family:var(--fd);
  font-weight:300;font-size:2.4rem;line-height:.9;letter-spacing:-.02em}
.steps__item .h3{font-size:1.2rem;margin-bottom:var(--space-2)}

/* 8 · TESTIMONIAL — a bordered 2-col grid (hairline dividers, NO card fill): a result STAT on top,
   a serif quote with quote-marks, avatar + name/role at the bottom. Compact — the template's own look. */
.tm--cards .tm__grid{grid-template-columns:1fr 1fr;gap:0;border:1px solid var(--border);border-radius:var(--radius);overflow:hidden}
.tm--cards .tm__card{background:transparent;border:0;border-radius:0;padding:clamp(1.4rem,2.4vw,2.2rem);gap:var(--space-4);
  border-top:1px solid var(--border);border-inline-start:1px solid var(--border)}
.tm--cards .tm__card:nth-child(-n+2){border-top:0}
.tm--cards .tm__card:nth-child(odd){border-inline-start:0}
/* an ODD count leaves the last card alone in its row → HUG the full grid width (span both columns)
   instead of sitting half-wide with dead space beside it. */
.tm--cards .tm__card:last-child:nth-child(odd){grid-column:1/-1}
.tm__stat{display:flex;flex-direction:column;gap:.15rem;margin-bottom:var(--space-2)}
.tm__stat-label{font-family:var(--fm);text-transform:uppercase;letter-spacing:.06em;font-size:.7rem;color:var(--ink-soft)}
.tm__stat-value{font-family:var(--fd);font-weight:400;font-size:clamp(1.3rem,2.4vw,1.75rem);letter-spacing:-.01em;color:var(--ink)}
.tm__quote{font-family:var(--fd);font-weight:400;font-size:clamp(1.15rem,1.9vw,1.4rem);line-height:1.42;letter-spacing:-.005em}
.tm--cards .tm__quote::before{content:'\\201C'} .tm--cards .tm__quote::after{content:'\\201D'}
.tm__name{font-family:var(--fb);font-weight:600}
.tm--cards .tm__avatar{border-radius:50%;width:38px;height:38px}
.tm--spotlight .tm__quote{font-size:clamp(1.6rem,3.6vw,2.4rem);font-weight:400;line-height:1.25}
@media(max-width:680px){
  .tm--cards .tm__grid{grid-template-columns:1fr}
  .tm--cards .tm__card{border-inline-start:0}
  .tm--cards .tm__card:nth-child(-n+2){border-top:1px solid var(--border)}
  .tm--cards .tm__card:first-child{border-top:0}
}

/* 9 · PRICING — rounded cards; popular = ink outline; badge on the accent ground */
.pr__card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:clamp(1.6rem,2.6vw,2.2rem)}
.pr__card--pop{border-color:var(--ink);box-shadow:0 18px 48px rgb(20 20 20/.10)}
.pr__badge{background:var(--accent);color:var(--accent-ink);font-family:var(--fm);letter-spacing:.06em}
.pr__amt{font-family:var(--fd);font-weight:400;letter-spacing:-.02em}
.pr__feats li::before{background:var(--ink)}
.pr__tier{font-size:1.2rem}

/* 10 · FAQ — big serif questions, hairline rows. Widen the .container (grid-consistency),
   constrain the inner list instead. */
.faq .container.faq__wrap{max-width:var(--container)}
.faq__list{max-width:780px;margin-inline:auto}
.faq__h{text-align:left;max-width:20ch;font-size:clamp(1.8rem,3.6vw,2.6rem)}
.faq--list .faq__h{margin-inline:auto;max-width:780px}
.faq__q{font-family:var(--fd);font-weight:500;font-size:1.3rem}
.faq__item[open] .faq__icon,.faq__item[data-closing] .faq__icon{color:var(--ink)}

/* 11 · CONTACT-FORM — rounded fields; widen the container, constrain the form */
.cf .container.cf__wrap{max-width:var(--container)}
.cf__wrap .sec-head{text-align:center;margin-inline:auto}
.cf__form{max-width:640px;margin-inline:auto}
.cf__field input,.cf__field textarea{border-radius:14px;background:var(--surface);border-color:var(--border)}
.cf__field span{font-family:var(--fm);text-transform:uppercase;letter-spacing:.06em;font-size:.72rem}

/* 12 · CARD-GRID — a horizontal RAIL of framed cards (the source's screenshot galleries) */
.cg__head{text-align:left;margin-inline:0}
.cg__tabs{justify-content:flex-start}
.cg__tab{font-family:var(--fm);text-transform:uppercase;letter-spacing:.04em;font-size:.72rem;border-radius:var(--r-pill)}
.cg__tab[aria-pressed="true"]{background:var(--ink);color:var(--bg);border-color:var(--ink)}
.cg__card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:var(--space-4)}
.cg__card:hover{border-color:var(--ink);transform:translateY(-4px)}
.cg__media{aspect-ratio:4/3;margin-bottom:var(--space-2)}
.cg__tag{color:var(--ink);border-color:var(--border);font-family:var(--fm)}
.cg__meta{font-family:var(--fm)}
.cg__title{font-size:1.15rem}
.cg__link{color:var(--ink);font-family:var(--fm)}
.cg__nav{background:var(--surface);border:1px solid var(--border);color:var(--ink);width:44px;height:44px;border-radius:var(--r-pill)}

/* 13 · INDEX-TILES — Apple-style COVER-FLOW carousel, serif index */
.it__num{font-family:var(--fd);font-weight:300;font-size:2.6rem}
.it__title{font-family:var(--fd);font-weight:500}
.it__cap{color:rgb(255 255 255/.88)}   /* re-assert white on the dark tile (global .muted would dim it) */
.it--flow .itf{--cw:clamp(190px,21vw,310px)}   /* moderate card size — full-bleed fan, no overlap (Tong, 2026-07-13) */
.it--flow .itf__card{border-radius:var(--radius)}
.it--flow .itf__cap .it__title{font-size:clamp(1.3rem,1.8vw,1.6rem)}

/* 14 · CTA — a rounded accent PANEL, inset from the screen edges by the responsive gutter at EVERY bp
   (never full-bleed). The section carries the side gutter (.cta padding-inline); the base .cta__panel
   supplies max-width + centring + the flex layout — we just dress it (serif title · pill · big radius). */
.cta{padding-inline:var(--gutter)}
.cta__panel{background:var(--accent);color:var(--accent-ink);border-radius:clamp(24px,3vw,34px);padding:clamp(2.2rem,5vw,3.8rem)}
.cta__title{color:var(--accent-ink);font-family:var(--fd);font-weight:400;font-size:clamp(1.9rem,4vw,3rem);max-width:20ch}
.cta__sub{color:var(--accent-ink);opacity:.9}
.cta__btn{background:var(--accent-ink);color:var(--accent);border-radius:var(--r-pill)}
/* narrow screens: the base panel is a space-between flex row → on small widths the title sits left and
   the button gets shoved to the far edge with an awkward gap. STACK it: title/sub over the button,
   all left-aligned, button at its natural width (not glued to the edge). */
@media(max-width:760px){
  .cta .cta__panel{flex-direction:column;align-items:flex-start;gap:clamp(1.5rem,5vw,2rem)}
  .cta__btn{align-self:flex-start}
}

/* 15 · FOOTER — the palette's SLAB ground (both themes) with two BLINKING eyes + a large serif
   nameplate. Footer text is pinned to light neutrals (the slab is dark, independent of theme). */
footer{position:relative;background:var(--slab);color:#F3F2EE;border-top:0;margin-top:0;padding-block:clamp(6.5rem,10vw,8rem) var(--space-6)}
footer::before{content:"";position:absolute;left:var(--gutter);top:clamp(2rem,5vw,3rem);width:104px;height:56px;transform-origin:50% 46%;
  background:
    radial-gradient(circle at 26px 32px,#0b0b0d 0 6px,transparent 6.5px),
    radial-gradient(circle at 74px 32px,#0b0b0d 0 6px,transparent 6.5px),
    radial-gradient(27px 33px at 26px 28px,#F5F4F0 0 98%,transparent),
    radial-gradient(27px 33px at 74px 28px,#F5F4F0 0 98%,transparent);
  background-repeat:no-repeat;animation:eyeblink 5.5s infinite}
@keyframes eyeblink{0%,90%,100%{transform:scaleY(1)}94%{transform:scaleY(.1)}}
@media(prefers-reduced-motion:reduce){footer::before{animation:none}}
footer .ft__grid,footer .ft__bottom{position:relative}
.ft__name{font-family:var(--fd);font-weight:400;font-size:clamp(2.2rem,4.6vw,3.4rem);color:#F6F5F1;letter-spacing:-.01em}
.ft__brand .small{color:#B7B7BE}
.ft__h{font-family:var(--fm);text-transform:uppercase;letter-spacing:.1em;font-size:.72rem;color:#F6F5F1}
.ft__col a{color:#B7B7BE} .ft__col a:hover{color:#fff}
.ft__bottom{border-top:1px solid rgb(255 255 255/.12);padding-top:var(--space-5);color:#9C9CA4}
.ft__bottom .small{color:#9C9CA4}
.theme-toggle--footer{background:rgb(255 255 255/.06);border-color:rgb(255 255 255/.22);color:#F3F2EE}
.theme-toggle--footer:hover{border-color:rgb(255 255 255/.5)}

/* MOSAIC-SCROLL — two staggered auto-scrolling photo rows */
.mos .sec-head{text-align:left;margin-inline:0}
.mos__media{aspect-ratio:4/3;border-radius:16px}
.mos__tag{font-family:var(--fm);text-transform:uppercase;letter-spacing:.06em;color:var(--ink-soft)}
.mos__title{font-family:var(--fb);font-weight:600}

/* STICKY-SCROLL — pinned serif heading + a rail of image cards sliding sideways as you scroll */
.ss__heading,.ssh__heading{font-family:var(--fd);font-weight:400;font-size:clamp(1.8rem,3.6vw,2.6rem);max-width:18ch}
.ss__title{font-family:var(--fd);font-weight:400;font-size:clamp(1.6rem,3vw,2.2rem)}
.ssh__title{font-family:var(--fb);font-weight:600;font-size:1.25rem}
.ssh__media,.ss__media{border-radius:18px}
.ssh__tabs{gap:var(--space-2)}
.ssh__tab{min-height:44px;min-width:44px;padding:.45rem .95rem;font-family:var(--fm);font-size:.74rem;
  letter-spacing:.04em;text-transform:uppercase;color:var(--ink-soft);background:var(--surface);
  border:1px solid var(--border);border-radius:var(--r-pill)}
.ssh__tab.is-active{background:var(--ink);color:var(--bg);border-color:var(--ink)}
.ssh__count{font-family:var(--fm);color:var(--ink-soft)}
.ssh__arrow,.ss__cta{border-color:var(--border);color:var(--ink)}
.ssh__arrow{background:var(--surface)}
.ssh__arrow:hover{border-color:var(--ink)}

/* ===== promoted sections this skin brings (base geometry in the demo build) ===== */
/* COVER-STACK — full-viewport case-study panels that stack & cover as you scroll */
.cst__panel{background:var(--surface);border:1px solid var(--border)}
.cst__badge{background:var(--surface-2);color:var(--ink)}
.cst__label{font-family:var(--fm);text-transform:uppercase;letter-spacing:.08em;color:var(--ink-soft);font-size:.74rem}
.cst__title{font-family:var(--fb);font-weight:600;letter-spacing:-.02em;font-size:clamp(1.5rem,3.4vw,2.4rem);line-height:1.08;max-width:24ch}
.cst__metas{font-family:var(--fm);font-size:.8rem;color:var(--ink-soft)}
.cst__cta{background:var(--ink);color:var(--bg)}
.cst__soon{background:var(--surface-2);color:var(--ink-soft)}
.cst__shot{background:var(--surface-2);border:1px solid var(--border);border-radius:18px}
.cst__bar>span{background:var(--accent)}
/* PHOTO-SCATTER — scattered rotated photos around centred serif text; straighten-lift on hover */
.psc__title{font-family:var(--fd);font-weight:300;font-size:clamp(2.6rem,6vw,4.6rem);letter-spacing:-.02em}
.psc__sub{color:var(--ink-soft);max-width:26ch;margin-inline:auto}
.psc__item{border-radius:16px;border:1px solid var(--border);background:var(--surface-2);box-shadow:0 10px 30px rgb(20 20 20/.10)}
.psc__label{background:color-mix(in srgb,var(--accent) 16%,var(--surface));color:var(--ink);font-family:var(--fm);font-size:.72rem}
`,

  /* 2 · HERO — the SIGNATURE. Minimalist serif statement + a GRAVITY tag-cloud (icons from the
     shared library; all pills the same size; they drop in, settle at the bottom, and scatter from
     the cursor — CLOUD_JS). */
  heroHTML({wordmark='XH', title='', lead='', dots=[], ctas=[], tags:planTags=null, hello=''}={}){
    // tags use the shared ICON LIBRARY (icons.mjs · Lucide), NOT bespoke SVG
    const tags = [
      {t:'Prototyping', i:'layers', c:1}, {t:'Systems thinking', i:'cpu', c:3},
      {t:'Moving rectangles', i:'settings', c:2}, {t:'Improving UX', i:'heart', c:6},
      {t:'Making it pop', i:'sparkles', c:4}, {t:'Reframing problems', i:'target', c:2},
      {t:'Rounding corners', i:'palette', c:5}, {t:'Testing', i:'check', c:7},
      {t:'Sketching', i:'lightbulb', c:1}, {t:'Shipping', i:'rocket', c:6},
      {t:'Research', i:'search', c:3}, {t:'Accessibility', i:'eye', c:4}
    ];
    const pills = (Array.isArray(planTags) && planTags.length
      ? planTags.map((x,n)=>{ const o = typeof x==='string' ? {t:x} : (x||{});
          return {t:o.t||'', svg:o.i?ic(o.i,15):iconFor(o.t||'',15), c:o.c??((n%7)+1)}; })
      : tags.map(x=>({t:x.t, svg:ic(x.i,15), c:x.c}))
    ).map(x=>`<span class="tagpill c${x.c}">${x.svg}${x.t}</span>`).join('');
    const btns = ctas.map((c,i)=>`<a class="btn ${i===0?'btn-primary':'btn-ghost'}" href="${c.href}">${c.label}</a>`).join('');
    return `<section class="section hero" data-section="hero" data-variant="stage" data-signature="serif-hero">
      <div class="container hero__wrap">
        <p class="hero__hello mono" data-motion="reveal-fade"><span class="ava"></span> ${hello || `Hello — I'm ${wordmark}`}</p>
        <h1 class="display hero__title" data-motion="reveal-up">${title||wordmark}</h1>
        ${lead?`<p class="lead hero__lead" data-motion="reveal-up">${lead}</p>`:''}
        ${btns?`<div class="hero__cta" data-motion="reveal-up">${btns}</div>`:''}
      </div>
      <div class="hero__cloud" data-signature="tag-cloud" aria-hidden="true">
        ${pills}
        <script>${CLOUD_JS}</script>
      </div>
    </section>`;
  }
};
