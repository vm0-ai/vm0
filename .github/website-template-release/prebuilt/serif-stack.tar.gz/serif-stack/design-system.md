# Serif Stack — design system

Measured from the local `template.css` and `index.html`. These are facts about
the shipped stylesheet, not intentions. Where a value here disagrees with prose anywhere else, this
file is right.

## Character

> minimalist serif hero + a GRAVITY tag-cloud (library-icon pills drop in, settle at the bottom, scatter from the cursor) · page-by-page cover-stack work scroll · scattered photos with straighten-on-hover · blinking-eyes footer



## Type

| | |
|---|---|
| Families loaded | `Cormorant Garamond` · `Inter` · `Space Mono` |
| Display face | `'Cormorant Garamond'` |
| Body face | `'Inter'` |
| Font personality flag | `data-fonts="serif-stack"` |

Both faces are declared as tokens, so a brand type change is a two-line edit in
`style[data-brand-theme]` — not a find-and-replace through the stylesheet.

## Colour roles

The stylesheet reads colour only through these roles. Rebinding them in `style[data-brand-theme]`
restyles the whole page; writing a literal colour anywhere else forks it.

| role | light | dark |
|---|---|---|
| `--bg` | #FFFFFF | #0A0A0A |
| `--ink` | #0A0A0A | #F2F2F2 |
| `--ink-soft` | #565656 | #9A9A9A |
| `--accent` | #111111 | #FFFFFF |
| `--accent-ink` | #FFFFFF | #0A0A0A |
| `--support-1` | #0f0f0f | #fbfbfb |
| `--support-2` | #626262 | #acacac |
| `--surface` | #f4f4f4 | #181818 |
| `--surface-2` | #eaeaea | #242424 |
| `--border` | #dadada | #383838 |
| `--ring` | #111111 | #FFFFFF |
| `--slab` | #050505 | #040404 |

Generate a replacement set with `node tools/palette.mjs --pick <system>`; use `--list` to choose and `--check` to audit bespoke values.
The values above are the reference page's own palette; they are a demonstration, not a requirement.

## Structural tokens

| token | value |
|---|---|
| `--container` | var(--w-standard) |
| `--fb` | 'Inter' |
| `--fd` | 'Cormorant Garamond' |
| `--fm` | 'Space Mono' |
| `--fx-aurora-1` | 12s |
| `--fx-aurora-2` | 14s |
| `--fx-aurora-3` | 16s |
| `--fx-aurora-blur` | 90px |
| `--fx-aurora-opacity` | .5 |
| `--fx-grain-opacity` | .085 |
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |
| `--navh` | 96px |
| `--radius` | 20px |

**Spacing scale** — `--space-2`=.5rem · `--space-3`=.75rem · `--space-4`=1rem · `--space-5`=1.5rem · `--space-6`=2rem · `--space-7`=3rem · `--space-8`=4rem · `--space-9`=6rem · `--space-10`=8rem



## Motion

| token | value |
|---|---|
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |

Motion personality: `playful`. `template.js` binds the reveals, the marquee, the
disclosure widgets, the theme toggle and the mobile nav. Reveals must degrade to visible content —
never hide a whole section behind an IntersectionObserver.

## Device vocabulary

Class prefixes that carry layout in the reference page, by frequency. Compose from these; a class
that is not here has no stylesheet behind it, and inventing one produces an unstyled bare tag.

`.mono`×66 · `.media`×62 · `.small`×45 · `.muted`×41 · `.h3`×32 · `.container`×21 · `.h2`×21 · `.section`×20 · `.btn`×16 · `.lead`×14 · `.body`×13 · `.tagpill`×12 · `.btn-ghost`×11 · `.sec-head`×10 · `.eyebrow`×6 · `.btn-primary`×4 · `.theme-toggle`×2 · `.c1`×2 · `.c3`×2 · `.c2`×2 · `.c6`×2 · `.c4`×2 · `.fs`×2 · `.fs--rev`×2 · `.ss`×2 · `.ssh`×2 · `.tm`×2 · `.skip`×1 · `.nav`×1 · `.theme-toggle--nav`×1 · `.hero`×1 · `.ava`×1 · `.display`×1 · `.c5`×1

## Reference density

The reference page carries **1609 visible words** across its sections. That is a description
of this example, not a target. Say what the brief supports and stop — a page padded to reach a
word count reads like one, and the reader can tell.
