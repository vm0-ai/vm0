# skin-serif-stack — spec

**Essence.** Airy, TEXT-FIRST editorial minimalism. Copyright-safe reskin — colours & fonts ONLY from
the catalogue: palette **`ink`** (`paletteCSS('ink')`, pure white/near-black, no warm cast — Tong
rejected warm `stone` as "太 AI"), fonts **`elegant`** (`fontCSS('elegant')` = Cormorant Garamond +
Inter) + library **Space Mono** for mono micro-labels. Hero tag icons from the shared `icons.mjs`.

## Signature moves (all generatable via `renderPage`)

1. **Gravity tag-cloud hero** — same-size library-icon pills DROP from the hero's TOP EDGE, fall IN
   FRONT (`is-physics` = absolute overlay, `z-index:3`, `pointer-events:none`), settle & scatter at the
   viewport bottom (separation gated to the bottom pile zone so none jam mid-air), and are gently pushed
   from the cursor. Calm physics (G .48 / bounce .16 / cursor MR 95·MF 2.4). Part of the skin → every
   serif-stack page gets it. Honours reduced-motion (calm flex-wrap).
2. **`coverStack`** — page-by-page case-study panels that STACK & cover on scroll (section-covers-section).
3. **`photoScatter`** — rotated photos scattered around centred serif text, straighten-lift on hover.
4. **Blinking-eyes footer** on the palette slab + giant serif nameplate.
   Plus the skin dresses `stickyScroll` (sideways cards), `mosaicScroll` (staggered rows), and all 15 base sections.

## Relies on these BASE geometries in `sections.mjs` (shared, all skins)

- `coverStack` + `photoScatter` promoted (builders + `SECTION_CSS`).
- `cg__navwrap` — card-rail prev/next are a grouped top-right pair, icons centred.
- `cg__railfull` — card RAIL lives outside `.container` (full-width) so cards bleed to the SCREEN edge,
  first card aligned to the heading via `padding-inline:max(gutter,(100%-container)/2+gutter)`.
- `ssh` (sticky-scroll horizontal) — pinned TEXT keeps a gutter; the card viewport BLEEDS to the screen edge.

## Gate status

- Skinsheet (15 sections): **PASS** full + `--site`.
- Showcase (`build-showcase.mjs` → `renderPage` with coverStack + photoScatter + sticky + mosaic + …,
  photos applied): **PASS** `--site --learn`.

## Live

- Showcase (the page to show users — all signature interactions + photos): https://serif-stack-showcase-715f6d07-18c59031.sites.vm0.io
- Skinsheet (15-section catalog proof + photos): https://serif-stack-sheet-715f6d07-e68c60ef.sites.vm0.io
