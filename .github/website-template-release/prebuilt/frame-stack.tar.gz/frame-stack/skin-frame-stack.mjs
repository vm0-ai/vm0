/* skin-frame-stack.mjs — a Website Studio skin (skin-contract.md).
 *
 * A RESKIN (not a copy) of an industrialized-construction site's STRUCTURE, dressed in OUR own
 * design-system palette + font (catalogue, not lifted from the source):
 *   • palette  = `teal`  (palettes.mjs)   — cool technical green, dual-mode, contrast-calibrated
 *   • font     = `neo`   (fonts.mjs)      — Schibsted Grotesk, one tight monolithic grotesque
 *
 * The LEARNED STRUCTURE (this is the identity, kept):
 *   1. FULL-BLEED, ZERO page padding — everything spans the whole browser width.
 *   2. The whole page is a modular grid of BORDERED FRAMES / CELLS that connect (shared 1px
 *      hairlines, no gaps). The lines are STRUCTURAL (cell edges), never decorative. Text is
 *      inset by each cell's OWN internal padding — the page has none.
 *   3. SECTIONS STACK on scroll — each is a solid panel pinned to the top; the next slides up and
 *      covers it (position:sticky). Degrades to a plain flow under reduced-motion / on mobile.
 *   4. Motifs: ■ corner markers · bordered arrow button-frames · coordinate read-outs · coded
 *      plates · a giant wordmark footer.
 *
 * Prove:  node build-skinsheet.mjs skin-frame-stack.mjs
 *         node qa-site.mjs skinsheet-frame-stack.html            # full matrix + DUAL-MODE
 *         node qa-site.mjs skinsheet-frame-stack.html --site      # signature · motion · layout
 */
import { paletteCSS } from './engine/palettes.mjs';
import { fontCSS, fontLink } from './engine/fonts.mjs';

const PALETTE = 'teal', FONT = 'neo';

export const skin = {
  id:'frame-stack',
  fontsAttr:'neo', motionAttr:'kinetic',
  fontLink: fontLink(FONT),
  signature:'full-bleed modular grid of connected bordered frames (zero page padding) · sections STACK & cover on scroll · axon-wireframe title-block hero · coordinate read-outs · giant wordmark footer',
  cardLayout:'rail',
  css:`
/* ═══════════ ① COLOUR — from OUR catalogue (teal), dual-mode ═══════════ */
${paletteCSS(PALETTE)}
/* ② FONT — from OUR catalogue (neo · Schibsted Grotesk) */
${fontCSS(FONT)}

/* personality levers + frame system tokens */
:root{
  --radius:0; --container:var(--w-full); --gutter:0;      /* FULL-BLEED · ZERO page padding */
  --frame:var(--border);                                   /* the structural hairline */
  --cell:clamp(1.25rem,3vw,3rem);                          /* every cell's INTERNAL inset */
  --coord:color-mix(in srgb,var(--ink) 52%,transparent);
}

/* ═══════════ shared chrome ═══════════ */
body{letter-spacing:-.006em}
.display,h1,.h1,h2,.h2,h3,.h3{font-weight:800;letter-spacing:-.035em;text-wrap:balance;line-height:.98}
.display{line-height:.9;letter-spacing:-.045em}
.lead{color:var(--ink-soft)}
/* EVERY card/surface is SQUARE (right-angle) — one radius site-wide */
.card,.media,.fg__card,.pr__card,.tm__card,.it__tile,.stats__cell,.steps__item,.cg__card,.ssh__card,.mos__media,.cg__media,.tm__avatar{border-radius:0}
.media{border:1px solid var(--frame);background:var(--surface-2)}
/* REMOVE the scroll-reveal ("content appears as you scroll") animation — content is shown at once.
   (Keeps marquee + hover; only the reveal/stagger/text-split entrances are disabled.) */
[data-motion^="reveal"],[data-motion="stagger"]>*,[data-motion="text-split"] .mo-w{
  opacity:1!important;transform:none!important;filter:none!important;clip-path:none!important;transition:none!important}
p{max-width:64ch}

/* EYEBROW / mono technical label — ink, uppercase, tracked, coral→accent ■ marker */
.eyebrow{font-weight:700;color:var(--ink);letter-spacing:.16em;font-size:.72rem;
  display:inline-flex;align-items:center;gap:.6em;text-transform:uppercase}
.eyebrow::before{content:"";width:.5em;height:.5em;background:var(--accent);flex:none}
.mono,.cg__tag,.cg__meta,.cg__link,.it__num{font-weight:700;letter-spacing:.08em;
  text-transform:uppercase;font-variant-numeric:tabular-nums}

/* BUTTONS — bordered "frame" buttons with an arrow (like the source's boxed Learn-more) */
.btn{border-radius:0;font-weight:700;letter-spacing:.01em;text-transform:uppercase;
  font-size:.78rem;padding:.9rem 1.25rem;min-height:48px;border:1px solid var(--ink)}
.btn-primary{background:var(--ink);color:var(--bg);border-color:var(--ink)}
.btn-primary::after{content:"→";margin-left:.7em}
.btn-ghost{background:transparent;color:var(--ink);border-color:var(--ink)}
.btn-ghost::after{content:"→";margin-left:.7em;color:var(--accent)}
.btn:hover{transform:none;background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
.btn:hover::after{color:var(--accent-ink)}

/* ═══════════ ③ full-bleed sections, separated by WHITESPACE (no divider line) ═══════════
   Removing the section-level border-top kills the doubled hairline (grid-bottom + section-top read
   as one thick line). Instead each section BREATHES with generous vertical padding, and each content
   group carries its OWN single frame. Grounded bands fill their padding with their own bg. */
/* NO section-level dividers anywhere — the whole site was reading as too many lines; sections now
   separate by WHITESPACE only. ONLY the two horizontal sticky-scroll sections get bracketing
   top+bottom rules (below), to set that scroll-narrative pair apart. */
main>section{background:var(--bg)}
main>section[data-ground="dark"]{background:var(--slab)}
/* GUARD — the connected cell-grids (stats/feature/pricing/index/steps) are built for the LIGHT
   canvas: their cells are hardcoded --bg and their labels are dark ink. If a plan marks such a
   section data-ground:dark, the light cells float as a strip inside a black band (the dark section
   padding shows above/below). Those grids have no dark styling, so keep their section on the light
   ground regardless. (spotlight-show/.sx is a bespoke dark section and carries no framed grid.) */
main>section[data-ground="dark"]:has(.stats__grid,.fg__grid,.pr__grid,.it__grid,.steps__list,.tm--cards .tm__grid){background:var(--bg)}
.section{padding-block:clamp(3.5rem,6.5vw,7rem)}
.hero{padding-block:0}
/* the two "The story / And it works mirrored" sections — top + bottom lines bracket the pair
   (top on each; bottom on the last one → single shared line between them, no double). */
.ssh{border-top:1px solid var(--frame)}
.ss--rev.ssh{border-bottom:1px solid var(--frame)}

/* ═══════════ the CONNECTED-CELL grid helpers ═══════════
   A grid whose gap IS the hairline (gap:1px on a border-coloured track), cells solid → cells
   connect with shared 1px lines and no gutter. An outer border closes the frame at the edges. */
/* CARDS keep their COMPLETE frame (top+bottom+sides) — only the SECTION-level dividers are gone */
.fg__grid,.pr__grid,.tm--cards .tm__grid,.it__grid,.stats__grid,.steps__list{
  gap:1px;background:var(--frame);border:1px solid var(--frame)}
.fg__card,.pr__card,.tm--cards .tm__card,.stats__cell,.it__tile,.steps__item{
  background:var(--bg);border:0;border-radius:0;box-shadow:none}

/* ═══════════ COORDINATE read-outs (structural motif) on the big editorial images ═══════════ */
.fs .media,.ss__media{position:relative}
.fs .media::before,.ss__media::before{content:"X: 631";position:absolute;left:0;bottom:0;
  padding:.4rem .55rem;font:700 .66rem/1 var(--fb);letter-spacing:.1em;color:var(--coord)}
.fs .media::after,.ss__media::after{content:"Y: 779";position:absolute;right:0;bottom:0;
  padding:.4rem .55rem;font:700 .66rem/1 var(--fb);letter-spacing:.1em;color:var(--coord)}
.fs__rows .fs__row:nth-child(2n) .media::before{content:"X: 202"}
.fs__rows .fs__row:nth-child(2n) .media::after{content:"Y: 263"}

/* ═══════════ 1 · NAV — GREEN (accent) header, matching hero/footer ═══════════ */
.nav{background:var(--accent);color:var(--accent-ink);z-index:100;
  border-bottom:1px solid var(--accent-ink)}   /* white line in light · black line in dark (accent-ink) */
.nav__bar{min-height:70px;padding-inline:var(--cell)}
.nav__brand{font-weight:800;letter-spacing:-.03em;font-size:1.3rem;color:var(--accent-ink)}
.nav__links a{font-weight:700;text-transform:uppercase;letter-spacing:.09em;font-size:.74rem;color:var(--accent-ink);opacity:.82}
.nav__links a:hover{color:var(--accent-ink);opacity:1}
.nav__cta.btn-primary{background:var(--accent-ink);color:var(--accent);border-color:var(--accent-ink)}
.nav__cta.btn-primary::after{color:var(--accent)}
.nav__cta.btn-primary:hover{background:var(--bg);color:var(--ink);border-color:var(--bg)}
.nav__cta.btn-primary:hover::after{color:var(--ink)}
.nav__burger{color:var(--accent-ink);border-color:var(--accent-ink);background:transparent}
.nav .theme-toggle{background:transparent;border-color:var(--accent-ink);color:var(--accent-ink)}
@media(max-width:767px){.nav__menu{background:var(--accent);border-bottom-color:color-mix(in srgb,#000 14%,var(--accent))}}

/* ═══════════ 2 · HERO — accent-ground panel, framed figure cell (see heroHTML) ═══════════ */
.hero{background:var(--accent);color:var(--accent-ink);border-top:0;overflow:hidden}
.hero__grid{max-width:var(--w-full);padding:0;display:grid;gap:0;align-items:stretch;min-height:calc(100vh - 71px)}
@media(min-width:900px){.hero__grid{grid-template-columns:1.02fr .98fr}}
.hero__text{padding:var(--cell);display:flex;flex-direction:column}
.hero__labelrow{display:flex;gap:clamp(2rem,6vw,5rem);padding-bottom:1rem;
  border-bottom:1px solid color-mix(in srgb,var(--accent-ink) 34%,transparent);margin-bottom:auto}
.hero__labelrow span{font-weight:700;text-transform:uppercase;letter-spacing:.16em;font-size:.72rem;color:var(--accent-ink)}
.hero .display{color:var(--accent-ink);font-size:clamp(3rem,9vw,7.4rem);margin-top:clamp(1.4rem,4vw,2.6rem)}
.hero__lead{color:var(--accent-ink);opacity:.9;max-width:34ch;margin-top:auto;font-size:clamp(1.05rem,1.4vw,1.3rem)}
.hero__cta{display:flex;flex-wrap:wrap;gap:.8rem;margin-top:clamp(1.4rem,3vw,2rem)}
.hero .btn-primary{background:var(--accent-ink);color:var(--accent);border-color:var(--accent-ink)}
.hero .btn-ghost{color:var(--accent-ink);border-color:color-mix(in srgb,var(--accent-ink) 55%,transparent)}
.hero .btn-ghost::after{color:var(--accent-ink)}
.hero .btn:hover{background:var(--bg);color:var(--ink);border-color:var(--bg)}
.hero .btn:hover::after{color:var(--ink)}
.hero__figure{border-left:1px solid var(--accent-ink);display:flex;flex-direction:column}
.hero__stage{position:relative;flex:1;display:grid;place-items:center;padding:clamp(1.5rem,4vw,3rem);overflow:hidden}
.hero__axon{width:min(74%,440px);height:auto;display:block}
.hero__axon path,.hero__axon line{stroke:var(--accent-ink);stroke-width:2;fill:none;
  vector-effect:non-scaling-stroke;stroke-linejoin:round;stroke-linecap:round}
.hero__reg{position:absolute;right:clamp(1rem,3vw,2.2rem);bottom:clamp(1rem,3vw,2.2rem);
  font-weight:800;font-size:clamp(2rem,5vw,3.2rem);line-height:1;color:var(--accent-ink);opacity:.9}
.hero__coordL,.hero__coordR{position:absolute;top:clamp(.8rem,2vw,1.4rem);
  font:700 .68rem/1 var(--fb);letter-spacing:.12em;color:color-mix(in srgb,var(--accent-ink) 60%,transparent)}
.hero__coordL{left:clamp(.8rem,2vw,1.4rem)} .hero__coordR{right:clamp(.8rem,2vw,1.4rem)}
.titleblock{border-top:1px solid var(--accent-ink);display:grid;grid-template-columns:auto 1fr}
.titleblock__mark{display:grid;place-items:center;width:clamp(64px,9vw,92px);border-right:1px solid var(--accent-ink);padding:.6rem}
.titleblock__mark svg{width:100%;height:auto}
.titleblock__rows{display:flex;flex-direction:column}
.titleblock__row{display:flex;justify-content:space-between;gap:1rem;padding:.5rem clamp(.8rem,2vw,1.2rem);
  font-weight:700;text-transform:uppercase;letter-spacing:.09em;font-size:.68rem;color:var(--accent-ink)}
.titleblock__row+.titleblock__row{border-top:1px solid color-mix(in srgb,var(--accent-ink) 32%,transparent)}
@media(max-width:899px){.hero__figure{border-left:0;border-top:1px solid var(--accent-ink)}}

main>section>.container{width:100%}
/* section headers get their own internal inset (page has none) + a clear GAP before the grid
   below them (title/subtitle must breathe away from the cards). */
.sec-head,.cg__head{padding:0 var(--cell) clamp(2rem,4vw,3.2rem)}
.fs__heading,.faq__h,.ss__heading{padding:0 var(--cell) clamp(2rem,4vw,3.2rem)}
.sec-head{text-align:left;margin:0;max-width:none}
.sec-head .h2,.fs__heading,.faq__h,.cg__head .h2,.ss__heading{font-size:clamp(1.9rem,3.6vw,3rem)}
.sec-head .lead{max-width:56ch;margin-top:.85rem}

/* ═══════════ 3 · FEATURE-SPLIT — full-bleed alternating cells, framed ═══════════ */
.fs__rows{gap:0;border:1px solid var(--frame)}   /* complete card frame (top+bottom+sides) */
.fs__row{gap:0;align-items:stretch;border-bottom:1px solid var(--frame);grid-template-columns:1fr}
.fs__rows .fs__row:last-child{border-bottom:0}
@media(min-width:880px){.fs__row{grid-template-columns:1fr 1fr}.fs--rev .fs__text{order:2}}
.fs__text{padding:var(--cell);display:flex;flex-direction:column;justify-content:flex-start;  /* TOP-left, not centered */
  border-right:1px solid var(--frame)}
.fs--rev .fs__text{border-right:0;border-left:1px solid var(--frame)}
.fs__icon{display:none}                                 /* icon removed per feedback */
.fs__text .eyebrow{margin-bottom:.9rem}
.fs__text .h2{font-size:clamp(1.5rem,2.6vw,2.3rem);margin-block:.2rem .3rem}
.fs__text .lead{margin-top:.6rem}
.fs .media{aspect-ratio:auto;border:0;min-height:clamp(260px,40vw,480px)}

/* ═══════════ 4 · FEATURE-GRID — connected cells, ■ corner ═══════════ */
/* page-colour cells (no gray fill) + only side edges/internal dividers, text TOP-LEFT, NO icon */
.fg__card{position:relative;padding:var(--cell);display:block;text-align:left}
.fg__card::after{content:"";position:absolute;top:var(--cell);right:var(--cell);width:9px;height:9px;background:var(--accent)}
.fg__icon{display:none}   /* icon removed per feedback */
.fg__card .h3{font-size:1.35rem;letter-spacing:-.02em;padding-right:1.6rem;margin-bottom:.7rem}
.fg__card .body{max-width:44ch;line-height:1.55}

/* ═══════════ 5 · LOGOS — a horizontal SCROLLING ROW of small BORDERED CELLS ═══════════ */
.logos{border:0}
.logos__marquee{margin-top:0;border-block:1px solid var(--frame)}   /* band top+bottom framing the logo cells */
.logos__marquee .mo-track{gap:0}                    /* cells connect via shared 1px borders (no gap) */
.logos__item{display:inline-flex;align-items:center;justify-content:center;text-align:center;
  width:clamp(150px,17vw,220px);height:clamp(84px,9vw,110px);padding:1rem 1.2rem;flex:none;
  border-left:1px solid var(--frame);
  font-weight:800;font-size:1.02rem;color:var(--ink);opacity:1;letter-spacing:-.01em;text-transform:uppercase}

/* ═══════════ 6 · STATS — connected cells on the dark slab, accent numerals ═══════════ */
.stats__grid{gap:1px}
.stats__cell{padding:var(--cell);text-align:left}
.stats__num{font-weight:800;color:var(--accent);font-size:clamp(2.4rem,5vw,3.6rem);letter-spacing:-.03em}
.stats__cell .small{color:var(--ink-soft);text-transform:uppercase;letter-spacing:.11em;font-weight:700;font-size:.72rem;margin-top:.5rem}

/* ═══════════ 7 · STEPS — the numbered index cells (connected, full frame) ═══════════ */
.steps__list{gap:1px}
.steps__item{grid-template-columns:auto 1fr;gap:clamp(1rem,4vw,3rem);align-items:baseline;
  padding:var(--cell);background:var(--bg)}
.steps__num{background:transparent;color:var(--ink);border-radius:0;width:auto;height:auto;
  font-weight:800;font-size:clamp(1.8rem,4vw,3rem);letter-spacing:-.02em}
.steps__num::after{content:" /";color:var(--accent)}
.steps__item .h3{font-size:clamp(1.3rem,2.2vw,1.8rem);margin-bottom:.5rem}

/* ═══════════ 8 · TESTIMONIAL — connected quote cells, ■ corner ═══════════ */
.tm__card{position:relative;padding:var(--cell);gap:1.3rem}
.tm--cards .tm__card::after{content:"";position:absolute;top:var(--cell);right:var(--cell);width:9px;height:9px;background:var(--accent)}
.tm__quote{font-weight:600;font-size:1.1rem;line-height:1.42;letter-spacing:-.01em}
.tm__avatar{border-radius:0}
.tm__name{font-weight:700}
.tm--marquee .tm__grid{border:0;background:transparent}
.tm--marquee .tm__card{border:1px solid var(--frame);background:var(--bg)}
.tm--marquee{padding-block:var(--cell)}

/* ═══════════ 9 · PRICING — connected plates, accent pop cell ═══════════ */
.pr__card{padding:var(--cell);gap:1.1rem}
.pr__card--pop{background:var(--accent);color:var(--accent-ink)}
.pr__card--pop .pr__tier,.pr__card--pop .pr__amt,.pr__card--pop .pr__feats li,
.pr__card--pop .small,.pr__card--pop .pr__price .small{color:var(--accent-ink)}
.pr__card--pop .pr__feats li::before{background:var(--accent-ink)}
.pr__badge{background:var(--ink);color:var(--bg);border-radius:0;text-transform:uppercase;letter-spacing:.1em}
.pr__amt{font-weight:800;letter-spacing:-.03em}
.pr__feats li::before{border-radius:0;width:7px;height:7px;top:.62em}
.pr__card--pop .pr__cta{background:var(--accent-ink);color:var(--accent);border-color:var(--accent-ink)}
.pr__card--pop .pr__cta::after{color:var(--accent)}
.pr__card--pop .pr__cta:hover{background:var(--bg);color:var(--ink);border-color:var(--bg)}

/* ═══════════ 10 · FAQ — ONE big centred CARD (not full-bleed; that read as odd) ═══════════ */
.faq{padding-inline:clamp(1.1rem,4vw,3rem)}          /* the card floats inset, not edge-to-edge */
.faq__wrap{max-width:var(--w-standard);margin-inline:auto;border:1px solid var(--frame);
  padding:clamp(1.9rem,3.5vw,3.4rem) clamp(1.6rem,3vw,3.2rem)}
.faq__h{text-align:left;padding:0 0 clamp(1.4rem,3vw,2.2rem)}   /* card supplies the inset */
.faq__list{border:0}                                  /* the CARD is the frame; list = row dividers only */
.faq__item{border-bottom:1px solid var(--frame);padding-inline:0}
.faq__item:first-of-type{border-top:1px solid var(--frame)}
.faq__item:last-child{border-bottom:0}
.faq__q{font-weight:700;font-size:1.15rem;letter-spacing:-.015em;padding-block:1.15rem}
.faq__icon{color:var(--accent)}
.faq__a{padding-inline:0}

/* ═══════════ 11 · CONTACT — dark slab panel, mono field labels ═══════════ */
.cf{position:relative;background:var(--slab);color:#fff;border-top:0;overflow:hidden;padding-block:0;
  --ink:#fff;--ink-soft:color-mix(in srgb,#fff 66%,transparent);--border:color-mix(in srgb,#fff 26%,transparent);--surface:color-mix(in srgb,#fff 8%,transparent)}
.cf .container{position:relative;z-index:1;padding:clamp(3rem,7vw,6rem) var(--cell)}
/* SPLIT — left: title + paragraph · right: the form */
.cf__wrap{max-width:var(--w-full);margin:0}
@media(min-width:880px){.cf__wrap{display:grid;grid-template-columns:1fr 1fr;gap:clamp(2.5rem,6vw,6rem);align-items:start}}
.cf .sec-head{padding:0;margin:0;text-align:left}
.cf .sec-head .h2{color:#fff;font-size:clamp(2rem,3.6vw,3rem)}
.cf .sec-head .lead{color:color-mix(in srgb,#fff 74%,transparent);max-width:44ch;margin-top:1rem}
.cf__field span{text-transform:uppercase;letter-spacing:.13em;font-size:.68rem;color:color-mix(in srgb,#fff 70%,transparent)}
.cf__field input,.cf__field textarea{border-radius:0;background:color-mix(in srgb,#fff 8%,transparent);color:#fff;border:1px solid color-mix(in srgb,#fff 26%,transparent)}
.cf__field textarea{resize:none;min-height:150px}          /* fixed size — not resizable */
.cf__form .btn-primary{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
.cf__form .btn-primary::after{color:var(--accent-ink)}

/* ═══════════ 12 · CARD-GRID (rail) — full-bleed coded project plates ═══════════ */
.cg .container{padding-inline:0}
.cg__head{padding:var(--cell)}
.cg__tabs{justify-content:flex-start;padding-inline:var(--cell)}
.cg__tab{border-radius:0;text-transform:uppercase;letter-spacing:.09em;font-size:.72rem;
  background:transparent;border:1px solid var(--ink);color:var(--ink-soft)}
.cg__tab[aria-pressed="true"]{background:var(--ink);color:var(--bg);border-color:var(--ink)}
.cg__railwrap{position:relative;border-block:1px solid var(--frame)}   /* frame top+bottom around the rail cards */
.cg__grid.cg--rail{gap:0;margin-inline:0;padding-inline:0;scroll-padding-inline:0}
.cg--rail>.cg__card{flex-basis:clamp(280px,33.33vw,33.33vw);border-right:1px solid var(--frame)}
.cg__card{position:relative;aspect-ratio:4/5;background:var(--slab);border:0;border-radius:0;
  padding:var(--cell);gap:0;justify-content:space-between;overflow:hidden;color:#fff}
.cg__card:hover{transform:none}
.cg__media{position:absolute;inset:0;width:100%;height:100%;border:0;border-radius:0;aspect-ratio:auto;opacity:.92}
.cg__card::after{content:"";position:absolute;inset:0;z-index:0;
  background:linear-gradient(to top,rgba(0,0,0,.82),rgba(0,0,0,.05) 55%,rgba(0,0,0,.35))}
.cg__top,.cg__title,.cg__role,.cg__link{position:relative;z-index:1}
.cg__top{align-items:flex-start}
.cg__tag{color:var(--accent-ink);background:var(--accent);border:0;border-radius:0;padding:.28rem .5rem;letter-spacing:.07em;font-weight:700}
.cg__meta{color:rgba(255,255,255,.75)}
.cg__title{color:#fff;font-size:1.4rem;letter-spacing:-.02em;margin-top:auto}
.cg__role{color:rgba(255,255,255,.8)}
.cg__link{color:#fff;letter-spacing:.05em;margin-top:.6rem}
/* prev/next BOUND together as a pair at the top-right (above the rail), glyphs centred */
.cg__nav{border-radius:0;border:1px solid var(--ink);background:var(--bg);color:var(--ink);
  width:48px;height:48px;min-width:48px;padding:0;font-size:1.5rem;line-height:1;
  display:inline-flex;align-items:center;justify-content:center;
  position:absolute;top:auto;bottom:calc(100% + var(--space-4))}
.cg[data-variant="rail"] .cg__nav{display:inline-flex}
.cg__nav--next{right:var(--cell)}
.cg__nav--prev{right:calc(var(--cell) + 47px)}    /* immediately left of next, shared 1px edge */
.cg__morewrap{padding-block:var(--cell)}

/* ═══════════ 13 · INDEX-TILES — connected dark photo tiles, accent index ═══════════ */
.it__grid{gap:1px}
.it__tile{border-radius:0;background:var(--slab)}
.it__body{padding:var(--cell)}
.it__num{font-weight:800;color:var(--accent);letter-spacing:-.02em}
.it__title{letter-spacing:-.02em}

/* ═══════════ 14 · CTA — accent slab, framed ═══════════ */
.cta{padding:0}
.cta__panel{background:var(--accent);color:var(--accent-ink);border-radius:0;
  padding:clamp(3rem,6vw,5rem) var(--cell);align-items:center;min-height:0}   /* equal top/bottom padding */
.cta__title{color:var(--accent-ink);font-size:clamp(2rem,4.4vw,3.4rem);max-width:20ch}
.cta__sub{color:var(--accent-ink);opacity:.86}
.cta__btn{background:var(--accent-ink);color:var(--accent);border:1px solid var(--accent-ink);border-radius:0}
.cta__btn::after{content:"→";margin-left:.6em}

/* ═══════════ 15 · FOOTER — accent block-sheet, connected columns, giant wordmark ═══════════ */
/* UNIFORM green — one solid accent everywhere, NO translucent (whitish-green) dividers/gaps */
footer{background:var(--accent);color:var(--accent-ink);border-top:0;
  --ink:var(--accent-ink);--ink-soft:var(--accent-ink);padding:0;margin-top:0}
.ft__grid{grid-template-columns:repeat(2,1fr);gap:0;background:var(--accent)}
@media(min-width:680px){.ft__grid{grid-template-columns:repeat(4,1fr)}}
.ft__brand{grid-column:1/-1;order:2;background:var(--accent);padding:var(--cell);overflow:hidden}
.ft__col{position:relative;background:var(--accent);padding:var(--cell)}
.ft__h{text-transform:uppercase;letter-spacing:.12em;font-size:.72rem;color:var(--accent-ink);margin-bottom:clamp(1.4rem,3vw,2.4rem)}
.ft__h::after{content:"■";float:right;color:var(--accent-ink);font-size:.6rem}
.ft__col a{color:var(--accent-ink);font-weight:600}
.ft__col a:hover{color:var(--accent-ink);text-decoration:underline}
.ft__name{font-weight:800;color:var(--accent-ink);font-size:clamp(3.2rem,17vw,13rem);line-height:.82;letter-spacing:-.05em}
.ft__name::after{content:"®";font-size:.24em;vertical-align:super;font-weight:800;margin-left:.05em}
.ft__brand .small{color:var(--accent-ink);max-width:44ch}
.ft__bottom{padding:var(--cell);margin-top:0;color:var(--accent-ink);border-top:0}
.ft__bottom .small{color:var(--accent-ink)}
footer .theme-toggle{border-radius:0;background:transparent;border-color:var(--accent-ink);color:var(--accent-ink)}

/* ═══════════ sticky-scroll VERTICAL (fallback) — framed edges ═══════════ */
.ss__grid{padding:var(--cell)}

/* ═══════════ sticky-scroll HORIZONTAL — pinned text (left) + horizontal image-card track ═══════════ */
.ssh{padding-block:0}                 /* keep the sticky geometry clean; whitespace comes from neighbours */
.ssh__grid{gap:0}
/* the pinned text sits on a bg→transparent gradient MASK that already separates it from the sliding
   cards; a vertical border here just draws a stray rule down the middle AND makes the first card
   (half-hidden under the mask) read as an oversized cell — so NO side border on the pin (Tong, 2026-07-13). */
.ssh__pin{padding:var(--cell);align-self:stretch;display:flex;flex-direction:column;justify-content:center}
.ss--rev.ssh .ssh__pin{border-right:0;border-left:0}
.ssh__tabs{gap:0}
.ssh__tab{border:1px solid var(--ink);border-radius:var(--r-pill);background:transparent;color:var(--ink-soft);
  font-weight:700;text-transform:uppercase;letter-spacing:.08em;font-size:.72rem;padding:.5rem 1rem;min-height:40px;cursor:pointer;margin-right:.5rem}
.ssh__tab.is-active{background:var(--ink);color:var(--bg)}
.ssh__heading{font-size:clamp(2rem,3.6vw,3rem);margin:clamp(1rem,2vw,1.6rem) 0 clamp(1rem,2vw,1.4rem)}
.ssh__intro{max-width:42ch}
.ssh__nav{gap:var(--space-4)}
.ssh__arrow{border:1px solid var(--ink);color:var(--ink)}
.ssh__arrow:hover{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
.ssh__count{color:var(--ink);letter-spacing:.1em}
.ssh__viewport{padding:var(--cell) 0}
.ssh__track{gap:0;padding-inline:var(--cell);align-items:stretch;counter-reset:sshcard}   /* EQUAL-HEIGHT cards: stretch every cell to the tallest so varying body length never changes card size; counter numbers the cards */
.ssh__card{flex-basis:clamp(280px,32vw,420px);border:1px solid var(--frame);margin-right:-1px;position:relative;counter-increment:sshcard}   /* connected card frames + a per-card index that mirrors the pin's counter */
/* NUMBER PLATE — a coded corner plate on each card, its sequence (01·02·03…) matching the pin's
   "NN / total" counter + tabs, so a card's number always corresponds to the number in the text. */
.ssh__card::before{content:counter(sshcard,decimal-leading-zero);position:absolute;top:0;left:0;z-index:2;
  font-family:var(--fb);font-weight:600;font-size:.82rem;letter-spacing:.14em;
  color:var(--ink);background:var(--bg);border-right:1px solid var(--frame);border-bottom:1px solid var(--frame);
  padding:.4rem .7rem;line-height:1}
.ssh__media{aspect-ratio:4/3;border:0;border-bottom:1px solid var(--frame)}
.ssh__cbody{padding:var(--cell);flex:1;display:flex;flex-direction:column}   /* fills the stretched card so the cta can sit at the bottom */
.ssh__title{font-size:1.35rem;letter-spacing:-.02em}
.ssh__text{color:var(--ink-soft);line-height:1.55}
.ssh__cta{align-self:flex-start;margin-top:auto}   /* pin READ MORE to the card bottom → all ctas align across cards */
@media(max-width:879px){.ssh__pin{border-right:0;border-bottom:1px solid var(--frame)}.ss--rev.ssh .ssh__pin{border-left:0;border-bottom:1px solid var(--frame)}}

/* ═══════════ mosaic-scroll — two offset auto-scrolling rows of bordered image cards ═══════════ */
.mos .sec-head{padding:0 var(--cell) clamp(2rem,4vw,3.2rem)}
.mos__card{width:clamp(220px,25vw,360px)}
.mos__media{aspect-ratio:4/3;border:1px solid var(--frame)}
.mos__meta{margin-top:.7rem}
.mos__tag{color:var(--accent)}
.mos__title{font-weight:700;color:var(--ink);letter-spacing:-.01em}
`,

  /* 2 · HERO — accent-ground panel, framed figure cell with the axon wireframe + title-block. */
  heroHTML({wordmark='STUDIO', title='', lead='', dots=[], ctas=[], titleblock=null, coords=null}={}){
    const tbRows = (Array.isArray(titleblock) && titleblock.length ? titleblock
      : [{k:'Drawing no.',v:'001.02.00'},{k:'Axonometric',v:'Standard'},{k:'Scale',v:'1 / 100'}])
      .map(r=>`<div class="titleblock__row"><span>${r.k||''}</span><b>${r.v||''}</b></div>`).join('\n              ');
    const co = coords || {};
    const btns = ctas.map((c,i)=>`<a class="btn ${i===0?'btn-primary':'btn-ghost'}" href="${c.href}">${c.label}</a>`).join('');
    const est = dots[0]||'System'; const est2 = dots[1]||'Est. 2025';
    const axon = `<svg class="hero__axon" viewBox="0 0 520 560" role="img" aria-label="Axonometric building diagram">
      <path d="M260 150 L380 218 L260 286 L140 218 Z"/>
      <path d="M260 150 L380 218 L380 426 L260 358 Z"/>
      <path d="M140 218 L260 150 L260 358 L140 426 Z"/>
      <line x1="260" y1="202" x2="380" y2="270"/><line x1="260" y1="254" x2="380" y2="322"/><line x1="260" y1="306" x2="380" y2="374"/>
      <line x1="140" y1="270" x2="260" y2="202"/><line x1="140" y1="322" x2="260" y2="254"/><line x1="140" y1="374" x2="260" y2="306"/>
      <line x1="320" y1="184" x2="200" y2="252"/><line x1="200" y1="184" x2="320" y2="252"/>
      <line x1="260" y1="150" x2="260" y2="358"/>
    </svg>`;
    const markMini = `<svg viewBox="0 0 40 40" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 6 30 12 20 18 10 12Z"/><path d="M20 22 30 28 20 34 10 28Z"/></g></svg>`;
    return `<section class="section hero" data-section="hero" data-variant="split" data-signature="frame-hero">
      <div class="container hero__grid">
        <div class="hero__text">
          <div class="hero__labelrow" data-motion="reveal-fade"><span>${est}</span><span>${est2}</span></div>
          <h1 class="display" data-motion="reveal-up">${title||wordmark}</h1>
          ${lead?`<p class="lead hero__lead" data-motion="reveal-up">${lead}</p>`:''}
          ${btns?`<div class="hero__cta" data-motion="reveal-up">${btns}</div>`:''}
        </div>
        <figure class="hero__figure" data-signature="axon-figure" data-motion="reveal-fade">
          <div class="hero__stage">
            <span class="hero__coordL">${co.x || 'X: 158.01'}</span><span class="hero__coordR">${co.y || 'Y: 100.00'}</span>
            ${axon}
            <span class="hero__reg" aria-hidden="true">®</span>
          </div>
          <figcaption class="titleblock">
            <div class="titleblock__mark">${markMini}</div>
            <div class="titleblock__rows">
              ${tbRows}
            </div>
          </figcaption>
        </figure>
      </div>
    </section>`;
  }
};
