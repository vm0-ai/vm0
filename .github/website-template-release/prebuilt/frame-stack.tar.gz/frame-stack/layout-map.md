# Frame Stack — layout map

The order below is what `index.html` actually ships, read off the DOM. It is the layout reference:
it shows which device this template uses for each narrative beat, at what ground and what width.

**It is not a section plan.** Compose the page from the brief using `NARRATIVE.md`, then reach into
this table for the device this template uses to carry each beat you decided to keep.

| # | section | narrative beat | classes | ground | width |
|---|---|---|---|---|---|
| 01 | `hero` | promise | `.hero` | — | default |
| 02 | `logos` | proof-scale | `.logos.logos--wall` | — | default |
| 03 | `feature-grid` | capability | `.fg` | — | default |
| 04 | `mosaic-scroll` | capability | `.mos` | — | default |
| 05 | `feature` | mechanism | `.fs` | — | default |
| 06 | `feature` | mechanism | `.fs` | — | default |
| 07 | `stats` | proof-data | `.stats` | — | default |
| 08 | `steps` | mechanism | `.steps` | — | default |
| 09 | `sticky-scroll` | mechanism | `.ss.ssh` | — | default |
| 10 | `sticky-scroll` | mechanism | `.ss.ssh.ss--rev` | — | default |
| 11 | `card-grid` | proof-cases | `.cg` | — | default |
| 12 | `index-tiles` | fit | `.it` | — | default |
| 13 | `testimonial` | proof-people | `.tm.tm--cards` | — | default |
| 14 | `testimonial` | proof-people | `.tm.tm--marquee` | — | default |
| 15 | `statement` | tension | `.section` only | — | default |
| 16 | `pricing` | offer | `.pr` | — | default |
| 17 | `faq` | objections | `.faq.faq--list` | — | default |
| 18 | `contact` | conversion | `.cf` | — | default |
| 19 | `cta` | close | `.cta` | — | default |

## Beats this reference demonstrates

`promise` · `proof-scale` · `capability` · `mechanism` · `proof-data` · `proof-cases` · `fit` · `proof-people` · `tension` · `offer` · `objections` · `conversion` · `close`

## Coverage

Every narrative beat has a device in this reference.

## Credentials live inside the hero

The one beat with no section of its own. `credentials` — compliance marks, guarantees, certifications
— belongs in the hero's own trust line, immediately under the opening claim, because the first claim
is the first thing doubted. Every hero in this set has a meta/badge slot for exactly this; use it
rather than adding a separate trust section below the fold.

## Trust is layered, not stacked

The one ordering rule this template inherits from the narrative contract: proof arrives in more than
one form, and each form lands immediately after a moment that asks the reader to invest attention —
credentials in the hero's own trust line, scale right under the opening claim, numbers after the
capability argument, a named person before the price, cases before the close. Collapsing all proof
into one testimonial block leaves the rest of the page unsupported.
