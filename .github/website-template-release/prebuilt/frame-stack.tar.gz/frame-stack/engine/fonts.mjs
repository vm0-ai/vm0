/* fonts.mjs — the FONT-STYLE CATALOGUE: 16 curated display+body pairings the generator matches
 * pages from. Each style
 * sets --fd (display) / --fb (body) + the personality levers a skin reads (display weight/tracking),
 * and ships a single Google Fonts <link>. All families are open-licensed (OFL/Apache).
 *
 * Variety across the 16: neo-grotesque · geometric · humanist · grotesque-display · editorial serif
 * · classic serif · slab · modern-tech · condensed-poster · mono-accent · rounded · elegant-serif
 * · expressive-display · refined-sans · brutalist · friendly. fontCSS(id) → ready vars + link. */

export const FONTSTYLES = [
  {id:'grotesk',     name:'Grotesk',        mood:'clean startup default',      fd:'Space Grotesk', fb:'Inter',
    link:'family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600', dWeight:700, dTrack:'-0.02em'},
  {id:'neo',         name:'Neo-Grotesque',  mood:'monolithic, tight, editorial', fd:'Schibsted Grotesk', fb:'Schibsted Grotesk',
    link:'family=Schibsted+Grotesk:wght@400;500;600;700;800', dWeight:800, dTrack:'-0.04em'},
  {id:'geometric',   name:'Geometric',      mood:'friendly, modern consumer',  fd:'Poppins', fb:'Inter',
    link:'family=Poppins:wght@500;600;700&family=Inter:wght@400;500;600', dWeight:600, dTrack:'-0.01em'},
  {id:'humanist',    name:'Humanist',       mood:'approachable, legible',      fd:'Figtree', fb:'Figtree',
    link:'family=Figtree:wght@400;500;600;700;800', dWeight:700, dTrack:'-0.02em'},
  {id:'editorial',   name:'Editorial',      mood:'serif display + sans body',  fd:'Fraunces', fb:'Inter',
    link:'family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600', dWeight:600, dTrack:'-0.01em'},
  {id:'classic',     name:'Classic',        mood:'elegant high-contrast serif', fd:'Playfair Display', fb:'Source Serif 4',
    link:'family=Playfair+Display:wght@600;700;800&family=Source+Serif+4:wght@400;500;600', dWeight:700, dTrack:'-0.005em'},
  {id:'slab',        name:'Slab',           mood:'sturdy, mechanical',         fd:'Roboto Slab', fb:'Roboto',
    link:'family=Roboto+Slab:wght@500;600;700;800&family=Roboto:wght@400;500;700', dWeight:700, dTrack:'-0.01em'},
  {id:'tech',        name:'Modern Tech',    mood:'dev-tool, precise',          fd:'Sora', fb:'Inter',
    link:'family=Sora:wght@500;600;700;800&family=Inter:wght@400;500;600', dWeight:700, dTrack:'-0.02em'},
  {id:'condensed',   name:'Condensed',      mood:'poster, high-impact',        fd:'Archivo Expanded', fb:'Archivo',
    link:'family=Archivo:wght@400;500;600;700&family=Archivo+Expanded:wght@600;700;800', dWeight:800, dTrack:'-0.02em'},
  {id:'mono',        name:'Mono-Accent',    mood:'technical, code-flavoured',  fd:'Space Mono', fb:'Inter',
    link:'family=Space+Mono:wght@400;700&family=Inter:wght@400;500;600', dWeight:700, dTrack:'-0.03em'},
  {id:'rounded',     name:'Rounded',        mood:'soft, playful consumer',     fd:'Fredoka', fb:'Nunito',
    link:'family=Fredoka:wght@500;600;700&family=Nunito:wght@400;600;700', dWeight:600, dTrack:'0em'},
  {id:'elegant',     name:'Elegant',        mood:'luxury, fine serif',         fd:'Cormorant Garamond', fb:'Inter',
    link:'family=Cormorant+Garamond:wght@500;600;700&family=Inter:wght@400;500;600', dWeight:600, dTrack:'0em'},
  {id:'expressive',  name:'Expressive',     mood:'arty, distinctive display',  fd:'Syne', fb:'Inter',
    link:'family=Syne:wght@600;700;800&family=Inter:wght@400;500;600', dWeight:800, dTrack:'-0.01em'},
  {id:'refined',     name:'Refined',        mood:'corporate grotesque',        fd:'Libre Franklin', fb:'Libre Franklin',
    link:'family=Libre+Franklin:wght@400;500;600;700;800', dWeight:700, dTrack:'-0.02em'},
  {id:'brutalist',   name:'Brutalist',      mood:'heavy, raw poster',          fd:'Anton', fb:'Inter',
    link:'family=Anton&family=Inter:wght@400;500;600', dWeight:400, dTrack:'-0.01em'},
  {id:'friendly',    name:'Friendly',       mood:'warm, rounded-sans',         fd:'Plus Jakarta Sans', fb:'Plus Jakarta Sans',
    link:'family=Plus+Jakarta+Sans:wght@400;500;600;700;800', dWeight:700, dTrack:'-0.02em'},
];

export const fontStyle = id => FONTSTYLES.find(f=>f.id===id);

export function fontLink(id){
  const f=fontStyle(id); if(!f) throw new Error('unknown font style '+id);
  return `<link href="https://fonts.googleapis.com/css2?${f.link}&display=swap" rel="stylesheet">`;
}

/* fontCSS(id) → the --fd/--fb vars + display weight/tracking the skin reads. */
export function fontCSS(id){
  const f=fontStyle(id); if(!f) throw new Error('unknown font style '+id);
  return `:root{--fd:'${f.fd}';--fb:'${f.fb}'}\n.display,h1,h2,h3,.h1,.h2,.h3{font-weight:${f.dWeight};letter-spacing:${f.dTrack}}`;
}
