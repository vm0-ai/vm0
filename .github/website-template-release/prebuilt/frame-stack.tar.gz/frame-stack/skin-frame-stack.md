# skin-frame-stack

**Essence.** A RESKIN (not a copy) of an industrialized-construction site's **structure**, dressed
in OUR own design-system catalogue — the source's colour/font are NOT lifted:
- **palette = `teal`** (`palettes.mjs`) — cool technical green, dual-mode, contrast-calibrated.
- **font = `neo` · Schibsted Grotesk** (`fonts.mjs`) — one tight monolithic grotesque for all.

The identity is the **LAYOUT + INTERACTION**, not the paint:

1. **Full-bleed, ZERO page padding** — `--container:var(--w-full)` + `--gutter:0`; everything spans
   the whole browser width.
2. **A modular grid of BORDERED FRAMES / CELLS that connect** — `gap:1px` on a border-coloured
   track + solid cells + a closing `border:1px` = shared hairlines, no gutter, no gaps. The lines
   are **structural cell edges**, never decoration. Text is inset only by each cell's **own**
   internal padding (`--cell`); the page has none.
3. Sections are **normal-flow full-bleed frames** separated by a top hairline. (An earlier
   sticky "cover-on-scroll" stack was REMOVED per Tong 2026-07-04 — short sections like the logo
   wall shouldn't pin; forcing it on every section read wrong.)
4. Motifs: ■ corner markers · bordered **arrow button-frames** · X:/Y: coordinate read-outs ·
   coded project plates · axon-wireframe **title-block** hero · **giant wordmark** footer.
   Section title/subtitle keep a clear gap before the cards below (`.sec-head` bottom padding).

**Live (gate-verified skinsheet, all 16 sections):**
https://frame-stack-715f6d07-0718efc3.sites.vm0.io

## Lever re-map
| Lever | Value |
|---|---|
| Palette | `teal` from the catalogue (`paletteCSS('teal')`) — NOT the source colour. |
| Fonts | `neo` / Schibsted Grotesk (`fontCSS('neo')` + `fontLink('neo')`) — NOT the source font. |
| Radius | 0 (sharp). |
| Width / padding | `--container:var(--w-full)`, `--gutter:0` — full-bleed, zero page padding; cells carry `--cell` internal inset. |
| Motion | `kinetic` scroll-reveals (the sticky-stack cover-on-scroll was removed per feedback). |
| Grounds | `dark` → the palette `--slab`; the accent (teal) carries hero / cta / pop-pricing / footer. |

## Full restyle (all 16)
nav (frame header) · hero (accent panel + axon title-block) · feature-split (full-bleed alternating
cells, flow) · feature-grid (connected cells + ■) · logos (ruled band) · stats (connected cells on
the slab) · steps (numbered index rows) · testimonial (connected quote cells) · pricing (connected
plates + accent pop) · faq (full-bleed frame rows) · contact (slab panel, mono labels) · card-grid
(full-bleed coded rail plates) · index-tiles (connected dark tiles) · cta (accent slab) · footer
(accent block-sheet + giant wordmark) · sticky-scroll (flow narrative + coordinate gallery).

## Promoted sections (2026-07-04, from this skin's feedback)
- **`mosaicScroll`** — TWO offset auto-scrolling rows of image cards (2nd row reversed → staggered);
  replaces the bento here. (SECTION_CSS + the marquee primitive; `data-marquee-dir="reverse"`.)
- **`stickyScroll` `layout:'horizontal'`** — LEFT pinned text (tabs · heading · intro · prev/next ·
  counter) + RIGHT a row of image cards (photo · title · body · cta) that translate HORIZONTALLY as
  the page scrolls vertically (STICKY_JS `data-sticky-h`); `reverse` mirrors the sides. Degrades to a
  manual horizontal rail on mobile / reduced-motion. The vertical cross-fade mode is unchanged.
  The pinned column carries **NO side border** — it rides the base bg→transparent gradient mask, so a
  `.ssh__pin` `border-right`/`border-left` is dropped on desktop (it kept the mobile `border-bottom`).
  Cards are **EQUAL-HEIGHT** — the track is `align-items:stretch`, `.ssh__cbody` is `flex:1` column
  and `.ssh__cta` gets `margin-top:auto`, so varying body length never changes card size and every READ
  MORE aligns at the card bottom (the bordered frames stay a clean connected row).
  Each card also carries a **coded number plate** (top-left corner) via a CSS counter
  (`.ssh__track{counter-reset}` + `.ssh__card{counter-increment}` + `::before{content:counter(…,decimal-leading-zero)}`),
  so a card's `01·02·03…` matches the pin's `NN / total` counter — no markup change needed.
- Feature-grid cards: NO icon, top-left text, **transparent (no fill)** cells framed by 4 borders +
  negative margins (single shared hairlines), longer body copy. Logos = a scrolling row of bordered
  cells.

## Gate status
`build-skinsheet.mjs skin-frame-stack.mjs` → `qa-site.mjs skinsheet-frame-stack.html`
**PASS (full · 4 bp × 2 themes · DUAL-MODE)** and `--site` **PASS (SIGNATURE · MOTION · LAYOUT-VARIETY)**.
Verified by eye in both themes + the sticky-stack scroll.

## Gotchas codified (this build)
- **Reskin = pull palette/font from OUR catalogue** (`paletteCSS`/`fontCSS`/`fontLink`), never lift the
  source's colour or typeface. (Tong, 2026-07-04.)
- **Sticky-stack traps content in sections taller than the viewport** (pinned top hides the overflow) —
  measure section heights and EXEMPT the long-form ones (`feature`/`sticky-scroll`/`card-grid`) so they
  scroll in normal flow; only ~1-viewport panels get `position:sticky;top:0`.
- **`position:sticky` nav lives in a short `<header>`** → it un-sticks after ~70px (its containing block
  scrolls away). For a stacking site let it scroll; a persistent bar needs `position:fixed`.
- **Full-bleed connected cells + CONTENT-INSET**: a `gap:1px` grid with `border-block` only leaves the
  edge `<li>` touching the list box → add a **4-side `border:1px`** so cells are 1px inset (gate threshold
  is `<1px`).
- Don't set `z-index` on the stacked sections — let DOM paint order do the cover; the nav keeps its own
  `z-index` to float above.
- **No vertical border on the sticky-scroll pin** (Tong, 2026-07-13): the connected-cells motif tempts a
  `.ssh__pin{border-right}` / `.ss--rev .ssh__pin{border-left}`, but in the full-bleed sliding-rail layout
  the pin overlays the cards on a gradient mask — that border draws a stray vertical rule straight down
  the middle of BOTH sticky sections AND makes the first card (half-hidden under the mask) read as an
  oversized cell. Keep only the mobile `border-bottom` (the stacked-layout divider).
