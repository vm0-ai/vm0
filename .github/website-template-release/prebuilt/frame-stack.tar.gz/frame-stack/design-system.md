# Frame Stack — design system

Measured from the local `template.css` and `index.html`. These are facts about
the shipped stylesheet, not intentions. Where a value here disagrees with prose anywhere else, this
file is right.

## Character

> full-bleed modular grid of connected bordered frames (zero page padding) · sections STACK & cover on scroll · axon-wireframe title-block hero · coordinate read-outs · giant wordmark footer



## Type

| | |
|---|---|
| Families loaded | `Schibsted Grotesk` |
| Display face | `'Schibsted Grotesk'` |
| Body face | `'Schibsted Grotesk'` |
| Font personality flag | `data-fonts="neo"` |

Both faces are declared as tokens, so a brand type change is a two-line edit in
`style[data-brand-theme]` — not a find-and-replace through the stylesheet.

## Colour roles

The stylesheet reads colour only through these roles. Rebinding them in `style[data-brand-theme]`
restyles the whole page; writing a literal colour anywhere else forks it.

| role | light | dark |
|---|---|---|
| `--bg` | #FBFBF9 | #0C0D0D |
| `--ink` | #17181C | #F2F3EF |
| `--ink-soft` | #5C635F | #9A9B95 |
| `--accent` | #0C7C6C | #2FDCC4 |
| `--accent-ink` | #FFFFFF | #062019 |
| `--support-1` | #0f5e54 | #6ae3d1 |
| `--support-2` | #5da79c | #239686 |
| `--surface` | #f1f1ef | #1a1b1b |
| `--surface-2` | #e8e8e6 | #252626 |
| `--border` | #d9d9d8 | #3a3b3a |
| `--ring` | #0C7C6C | #2FDCC4 |
| `--slab` | #0a0b0d | #040404 |

Generate a replacement set with `node tools/palette.mjs --pick <system>`; use `--list` to choose and `--check` to audit bespoke values.
The values above are the reference page's own palette; they are a demonstration, not a requirement.

## Structural tokens

| token | value |
|---|---|
| `--container` | var(--w-full) |
| `--fb` | 'Schibsted Grotesk' |
| `--fd` | 'Schibsted Grotesk' |
| `--fx-aurora-1` | 12s |
| `--fx-aurora-2` | 14s |
| `--fx-aurora-3` | 16s |
| `--fx-aurora-blur` | 90px |
| `--fx-aurora-opacity` | .5 |
| `--fx-grain-opacity` | .085 |
| `--gutter` | 0 |
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |
| `--radius` | 0 |

**Spacing scale** — `--space-2`=.5rem · `--space-3`=.75rem · `--space-4`=1rem · `--space-5`=1.5rem · `--space-6`=2rem · `--space-7`=3rem · `--space-8`=4rem · `--space-9`=6rem · `--space-10`=8rem



## Motion

| token | value |
|---|---|
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |

Motion personality: `kinetic`. `template.js` binds the reveals, the marquee, the
disclosure widgets, the theme toggle and the mobile nav. Reveals must degrade to visible content —
never hide a whole section behind an IntersectionObserver.

## Device vocabulary

Class prefixes that carry layout in the reference page, by frequency. Compose from these; a class
that is not here has no stylesheet behind it, and inventing one produces an unstyled bare tag.

`.mono`×56 · `.media`×53 · `.small`×42 · `.muted`×41 · `.h3`×29 · `.h2`×20 · `.container`×19 · `.section`×19 · `.btn`×16 · `.lead`×14 · `.body`×13 · `.btn-ghost`×11 · `.sec-head`×10 · `.eyebrow`×5 · `.btn-primary`×4 · `.theme-toggle`×2 · `.fs`×2 · `.fs--rev`×2 · `.ss`×2 · `.ssh`×2 · `.tm`×2 · `.skip`×1 · `.nav`×1 · `.theme-toggle--nav`×1 · `.hero`×1 · `.display`×1 · `.titleblock`×1 · `.logos`×1 · `.logos--wall`×1 · `.fg`×1 · `.fg--cards`×1 · `.mos`×1 · `.fs--even`×1 · `.fs--media-wide`×1

## Reference density

The reference page carries **1514 visible words** across its sections. That is a description
of this example, not a target. Say what the brief supports and stop — a page padded to reach a
word count reads like one, and the reader can tell.
