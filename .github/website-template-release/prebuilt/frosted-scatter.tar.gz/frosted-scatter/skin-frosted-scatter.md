# frosted-scatter — skin spec

A very-modern **luminous glass** skin, learned clean-room from a frosted voice-product site (withnovu.com)
plus two captured moments from a frosted dev-studio (a one-at-a-time big-number band + a differentiated
footer). Deliberately **not** derived from `glass-bloom` — a fresh reading that brings the signature
*interactions* that skin lacked.

## Essence
Frosted glass on near-black / cool near-white grounds, big radii, Sora display, one lilac pop. The
identity lives in **motion + structure**, not paint.

## Signature moments
- **Scattered parallax photo hero** — small frosted photo chips strewn irregularly; each drifts toward the
  cursor at its own `data-depth`, so they deliberately **mis-align** (layered depth). `pointer-parallax`.
- **Flashlight grid** — a page-wide faint two-level grid on EVERY section (`.section::before,.ftp::before`),
  revealed **only around the pointer** (a torch over graph paper) and phase-aligned to ONE document origin
  (`--goy`) so the lines run **unbroken** across every light↔dark boundary. `spotlight-cursor`.
- **Line-by-line copy** — body paragraphs split into visual lines and **wipe in left→right** on enter.
  `line-reveal`.
- **One-at-a-time big numbers** — a pinned left header beside a tall column of huge numerals; the one
  nearest viewport-centre is bright, its neighbours fall away. `stat-focus` + `statsBand({layout:'reveal'})`.
- **Pinned-split signature** — a CENTER image slides up & leaves over a short scroll while the left heading +
  right description cross-fade in place. `pinnedSplit({layout:'slide'})` + `PIN_SLIDE_JS`.
- **Draggable mosaic wall** — two offset FULL-BLEED rows of image cards (text inside each image over a
  gradient), dragged sideways; cards **fade in/out at the browser edges** (horizontal mask, no hard cut).
  `mosaicScroll` + `MOS_JS`.
- **Team cards** — big cards, 3–4 across; DEFAULT a small SQUARE sharp image floats in the upper-middle over
  a plain card with the info beneath; on HOVER the image **enlarges to fill the whole card** and the
  name/role read white over a scrim. Socials in both states. `team`.
- **Case-study carousel** — a horizontal DRAG row of compact split cards (~1.5 show at once), fading at the
  browser edges; arrows/dots scroll. `testimonial({layout:'case'})` + `TM_JS`.
- **Card tilt** — every card tilts toward the cursor on hover (pointer devices only). `skin.cardTilt` →
  `tiltCards()` tags cards with `data-tilt`; the motion runtime drives the 3D transform.
- **Differentiated footer** — oversized wordmark + 3 link columns beneath it, a frosted CTA card over a
  rounded image card, dark ground flush to the CTA (no seam / no white strip), legal on the baseline.
  `footer({layout:'panel'})`.

## Lever re-map
- **Font (system):** catalogue `tech` — Sora (display) + Inter (body). Honours the fonts.mjs rule.
- **Colour (bespoke, Tong-permitted for glass):** dual-mode frosted set. `--accent` is a mid/deep purple
  that clears AA as text on its ground; the lilac pop is a fill used with dark ink. Dark "slab" grounds
  (stats-reveal · footer) remap roles locally to light-on-near-black.
- **Radius:** 20px (finite, soft); team cards/images are square + sharp. **Width:** `--w-wide`.
  **Motion personality:** `kinetic`. **Nav:** glass-bloom-structure fixed centred Apple-glass pill.
- **Opt-ins:** `parallax`, `cardLayout:'rail'`, `statsLayout:'reveal'`, `footerLayout:'panel'`,
  `lineReveal:true`, `pinnedLayout:'slide'`, `cardTilt:true`.

## Promotions shipped with this skin (System Code — opt-in, defaults unchanged; other skins unaffected)
- `motion.mjs`/`motion.css`: **`pointer-parallax`, `spotlight-cursor`, `line-reveal`, `stat-focus`**
  (all `prefers-reduced-motion`-safe); hover-tilt selector extended to `[data-motion="hover-tilt"],[data-tilt]`.
- `sections.mjs`: **`statsBand({layout:'reveal'})`**, **`footer({layout:'panel'})`**, **`pinnedSplit
  ({layout:'slide'})`** (+`PIN_SLIDE_JS`), reworked **`mosaicScroll`** (drag wall, +`MOS_JS`), new **`team`**
  section, **`testimonial({layout:'case'})`** rebuilt as a drag carousel (+scroll-based `TM_JS`), and the
  **`tiltCards(html)`** post-process — all with base CSS in `SECTION_CSS_X`.
- `build-skinsheet.mjs`/`gen-engine.mjs`: read the opt-in flags; stats-reveal + pinned-slide render raw (a
  reveal transform would break their sticky pins); `tiltCards` runs after BODY compose when `skin.cardTilt`.

## Gate status
`node build-skinsheet.mjs skin-frosted-scatter.mjs` → passes **full + --site** at 0 violations.
Demo page passes **full + --site + --learn** at 0 violations. glass-bloom + blueprint-grid regression clean.

## Live
- Skinsheet (all 15, gate-verified): https://frosted-scatter-sheet-715f6d07-197a46f0.sites.vm0.io
- Demo "Cadence" (original brand): https://frosted-scatter-cadence-715f6d07-58b20128.sites.vm0.io
- Host: `zero host <dir> --site frosted-scatter-sheet --slug-suffix 197a46f0` (demo suffix `58b20128`); the
  platform auto-inserts the `715f6d07` user hash — do NOT pass it as the slug-suffix or the URL changes.
  Bundle images locally first (`bundle-host.mjs`, clamps CDN width to 1400) — external hotlinks break preview.

## Gotchas relearned
- `position:sticky` breaks if an ancestor has `overflow:hidden` (it becomes the scroll container) — kept
  stats-reveal clip-free (there's a `DO NOT add overflow:hidden` comment on it).
- Text over a photo fails the contrast gate (it can't see the photo, only the card ground) — give the card
  a solid ground so the DEFAULT state reads correctly (team keeps a `--surface` card; default text is
  `--ink`/`--ink-soft`, so no dark-card hack needed).
- **`transition:color` is a gate trap** — qa-site flips `data-theme` then reads colour synchronously; a colour
  transition means it samples a mid-animation (wrong-theme) value → false CONTRAST fail. Don't transition
  colour on theme-driven text.
- Card tilt / custom cursor live behind `if(!HOVER) return` — only pointer devices get them; headless
  screenshots won't show the tilt (real desktop does).
- Gradient-clipped numerals compute `color:transparent` (the gradient is the visible fill) — expected.
- Base `SECTION_CSS_X` = STRUCTURE only (radius/padding/layout); never paint (background/color) a hook the
  skin owns, or specificity flips can produce dark-on-dark. Footer-panel rules are scoped under `.ftp`.
