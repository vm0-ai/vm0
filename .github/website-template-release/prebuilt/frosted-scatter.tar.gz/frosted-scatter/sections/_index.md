# Section library — frosted-scatter

Cut from the reference page by `tools/split-sections.mjs`. Pick the sections the brief supports,
in the order `NARRATIVE.md` gives, and assemble with `tools/compose.mjs`. A section you do not
pick is not in the page, so it cannot be left half-edited.

`_foundation.css` and `_shell.part` are always included. `css −` means the section reuses a skin
block an earlier section already brought. `geometry` is measured off the reference page at 1440 and
390 — column counts, the first media box's aspect ratio and its share of the section width, and the
section's own height. Read it here rather than opening the stylesheet.

| section | kind | html | skin | words | imgs | geometry |
|---|---|---|---|---|---|---|
| `01-nav` | nav | 1.9KB | — | 9 | 0 | 75px |
| `02-hero` | hero | 4.4KB | — | 27 | 6 | media 1.25 · 19%w · 900px |
| `03-logos` | logos | 1.7KB | — | 36 | 0 | 128px |
| `04-feature-grid` | feature-grid | 4.6KB | — | 188 | 0 | 3col · →1col · 960px |
| `05-pinned-split` | pinned-split | 3.2KB | — | 108 | 3 | 3col · →1col · media 0.75 · 25%w · 3478px |
| `06-mosaic-scroll` | mosaic-scroll | 5.9KB | — | 38 | 8 | media 1.33 · 32%w · 1093px |
| `07-feature` | feature | 2.5KB | — | 32 | 2 | 2col · →1col · media 1.33 · 43%w · 1330px |
| `08-feature` | feature | 2.5KB | — | 32 | 2 | 2col · →1col · media 1.33 · 52%w · 1330px |
| `09-stats` | stats | 1.3KB | — | 67 | 0 | 2col · →1col · 1265px |
| `10-steps` | steps | 1.8KB | — | 38 | 0 | 3col · →1col · 465px |
| `11-sticky-scroll` | sticky-scroll | 4.8KB | — | 123 | 4 | media 1.33 · 31%w · 1800px |
| `12-sticky-scroll` | sticky-scroll | 3.9KB | — | 88 | 3 | media 1.33 · 31%w · 1800px |
| `13-card-grid` | card-grid | 5.5KB | — | 68 | 6 | media 1.33 · 23%w · 903px |
| `14-index-tiles` | index-tiles | 2.6KB | — | 28 | 4 | 4col · →1col · media 0.75 · 22%w · 781px |
| `15-team` | team | 5.4KB | — | 28 | 4 | 4col · →1col · media 1.35 · 21%w · 742px |
| `16-testimonial` | testimonial | 11.2KB | — | 132 | 10 | 2col · →1col · media 0.7 · 18%w · 776px |
| `17-testimonial` | testimonial | 9.3KB | — | 211 | 12 | media 1 · 3%w · 531px |
| `18-statement` | statement | 1.9KB | — | 240 | 0 | 708px |
| `19-pricing` | pricing | 1.4KB | — | 48 | 0 | 3col · →1col · 828px |
| `20-faq` | faq | 2.2KB | — | 66 | 0 | 643px |
| `21-contact` | contact | 1.1KB | — | 61 | 0 | 2col · →1col · 905px |
| `22-cta` | cta | 0.4KB | — | 14 | 0 | 374px |
| `23-footer` | footer | 2.6KB | — | 44 | 1 | 3col · →2col · media 1.6 · 39%w · 782px |

```json
{}
```

Whole reference page: 84.0KB · foundation 99.4KB.

## What each section is made of

Derived by `tools/describe-sections.mjs` — selectors matched in a browser, knobs read out of
`template.js`, hexes counted in the skin block. Read this instead of opening `template.js` or the
stylesheet: the four things below are what eleven runs went hunting for after composing, and they
are the ones the markup you composed does not tell you.

A **knob** changes what ships. `[data-cardgrid]` hides every card past `data-batch`, so a grid you
filled with six cards renders three until you raise it or drop the control. **Hardcoded** tints are
fixed hexes in the skin; the palette does not reach them, so a colour system you picked will not
recolour those parts.

Every section is also touched by `[data-motion="text-split"]` — the shared
motion/reveal runner, which reads data-to, data-suffix, data-motion, data-speed, data-pscale, data-depth.
Listed once here; the lines below name only what is specific to one section.

### `01-nav`
- driven by: `.nav__burger` — reads data-open; · `.nav__menu a` — queries .nav__burger · `.nav` — queries .hero, .hero,[data-ground="dark"],.ftx,[data-nav-dark] · `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label

### `02-hero`
- repeats: .hs__chip ×6, .media ×6, .mo-in ×4
- one repeat holds: img×1
- driven by: `.nav` — queries .hero, .hero,[data-ground="dark"],.ftx,[data-nav-dark]
- behaviour attributes present: data-depth, data-motion

### `03-logos`
- repeats: .logos__item ×36
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `04-feature-grid`
- repeats: .fg__card ×6, .fg__icon ×6, .h3 ×6
- one repeat holds: svg×1, h3×1, p×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `05-pinned-split`
- repeats: .eyebrow ×4, .h2 ×4, .lead ×4
- driven by: `[data-pin-slide]` — queries .pins__track, .pins__shot, .pins__text, .pins__desc
- behaviour attributes present: data-i

### `06-mosaic-scroll`
- repeats: .mos__card ×8, .mos__media ×8, .media ×8
- one repeat holds: img×1
- driven by: `[data-mos-drag]` —

### `07-feature`
- repeats: .h2 ×3
- driven by: nothing of its own
- behaviour attributes present: data-motion, data-speed, data-pscale

### `08-feature`
- repeats: .h2 ×3
- driven by: nothing of its own
- behaviour attributes present: data-motion, data-speed, data-pscale

### `09-stats`
- repeats: .st__row ×4, .st__num ×4, .small ×4
- one repeat holds: p×1
- driven by: `.nav` — queries .hero, .hero,[data-ground="dark"],.ftx,[data-nav-dark]
- behaviour attributes present: data-motion

### `10-steps`
- repeats: .steps__item ×3, .steps__num ×3, .h3 ×3
- one repeat holds: h3×1, p×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `11-sticky-scroll`
- repeats: .ssh__card ×4, .ssh__media ×4, .media ×4
- one repeat holds: img×1, h3×1, p×1, a×1
- driven by: `[data-sticky-h]` — reads data-d; queries .ssh__track, .ssh__viewport, .ssh__cur, .ssh__card, .ssh__tab
- behaviour attributes present: data-i, data-d

### `12-sticky-scroll`
- repeats: .ssh__card ×3, .ssh__media ×3, .media ×3
- one repeat holds: img×1, h3×1, p×1, a×1
- driven by: `[data-sticky-h]` — reads data-d; queries .ssh__track, .ssh__viewport, .ssh__cur, .ssh__card, .ssh__tab
- behaviour attributes present: data-i, data-d

### `13-card-grid`
- repeats: .mono ×18, .cg__card ×6, .cg__media ×6
- driven by: `[data-cardgrid]` — reads data-batch, data-cat; queries .cg__tab, .cg__card, .cg__morewrap, .cg__more, .cg__grid
- behaviour attributes present: data-cat

### `14-index-tiles`
- repeats: .it__tile ×4, .it__media ×4, .media ×4
- one repeat holds: img×1, h3×1, p×1
- driven by: nothing of its own
- behaviour attributes present: data-motion, data-speed, data-pscale

### `15-team`
- repeats: .team__soc ×8, .team__card ×4, .team__media ×4
- one repeat holds: svg×1
- driven by: nothing of its own

### `16-testimonial`
- repeats: .small ×10, .tm__case ×5, .tm__caseMedia ×5
- driven by: `[data-mos-drag]` — · `[data-tm-carousel]` — reads data-d; queries .tm__stage, .tm__case, .tm__dot, .tm__arrow
- behaviour attributes present: data-i, data-d

### `17-testimonial`
- repeats: .tm__card ×12, .tm__quote ×12, .tm__by ×12
- one repeat holds: img×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `18-statement`
- driven by: nothing of its own

### `19-pricing`
- repeats: .pr__card ×3, .h3 ×3, .pr__tier ×3
- one repeat holds: h3×1, li×3, a×1
- driven by: nothing of its own

### `20-faq`
- repeats: .faq__item ×4, .faq__q ×4, .faq__icon ×4
- one repeat holds: svg×1, p×1
- driven by: `.faq__item` — queries summary, .faq__a

### `21-contact`
- repeats: .cf__field ×3
- driven by: `.cf__form` — queries .cf__ok

### `22-cta`
- driven by: nothing of its own

### `23-footer`
- repeats: .ft__col ×3, .ft__h ×3
- one repeat holds: h3×1, li×4, a×4
- driven by: `.nav` — queries .hero, .hero,[data-ground="dark"],.ftx,[data-nav-dark] · `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label
