# Frosted Scatter — design system

Measured from the local `template.css` and `index.html`. These are facts about
the shipped stylesheet, not intentions. Where a value here disagrees with prose anywhere else, this
file is right.

## Character

> scattered parallax photo hero · flashlight grid cursor · line-by-line copy · one-at-a-time big numbers · frosted glass

Frosted glass on near-black / cool near-white grounds, big radii, Sora display, one lilac pop. The

## Type

| | |
|---|---|
| Families loaded | `Sora` · `Inter` |
| Display face | `'Sora'` |
| Body face | `'Inter'` |
| Font personality flag | `data-fonts="frosted-scatter"` |

Both faces are declared as tokens, so a brand type change is a two-line edit in
`style[data-brand-theme]` — not a find-and-replace through the stylesheet.

## Colour roles

The stylesheet reads colour only through these roles. Rebinding them in `style[data-brand-theme]`
restyles the whole page; writing a literal colour anywhere else forks it.

| role | light | dark |
|---|---|---|
| `--bg` | #EDEEF3 | #0A0B12 |
| `--ink` | #131522 | #EEF0FA |
| `--ink-soft` | #585F76 | #A7ADC4 |
| `--accent` | #6338E6 | #B7A6FF |
| `--accent-ink` | #FFFFFF | #0A0B12 |
| `--support-1` | #8A6BFF | #C7BAFF |
| `--support-2` | #12B6C9 | #5EEAD4 |
| `--surface` | #FFFFFF | #13141F |
| `--surface-2` | #E6E8F0 | #1B1D2B |
| `--border` | #E1E3EC | #242739 |
| `--ring` | #6338E6 | #B7A6FF |

Generate a replacement set with `node tools/palette.mjs --pick <system>`; use `--list` to choose and `--check` to audit bespoke values.
The values above are the reference page's own palette; they are a demonstration, not a requirement.

## Structural tokens

| token | value |
|---|---|
| `--container` | var(--w-wide) |
| `--fb` | 'Inter' |
| `--fd` | 'Sora' |
| `--frost` | saturate(160%) blur(16px) |
| `--fx-aurora-1` | 12s |
| `--fx-aurora-2` | 14s |
| `--fx-aurora-3` | 16s |
| `--fx-aurora-blur` | 90px |
| `--fx-aurora-opacity` | .5 |
| `--fx-grain-opacity` | .085 |
| `--glass-brd` | rgba(20,20,55,.10) |
| `--grid-cell` | 80px |
| `--grid-min` | rgba(108,114,158,.045) |
| `--grid-sub` | 20px |
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |
| `--nav-brd` | rgba(20,20,55,.12) |
| `--radius` | 20px |

**Spacing scale** — `--space-2`=.5rem · `--space-3`=.75rem · `--space-4`=1rem · `--space-5`=1.5rem · `--space-6`=2rem · `--space-7`=3rem · `--space-8`=4rem · `--space-9`=6rem · `--space-10`=8rem



## Motion

| token | value |
|---|---|
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |

Motion personality: `kinetic`. `template.js` binds the reveals, the marquee, the
disclosure widgets, the theme toggle and the mobile nav. Reveals must degrade to visible content —
never hide a whole section behind an IntersectionObserver.

## Device vocabulary

Class prefixes that carry layout in the reference page, by frequency. Compose from these; a class
that is not here has no stylesheet behind it, and inventing one produces an unstyled bare tag.

`.small`×53 · `.media`×48 · `.muted`×43 · `.mono`×32 · `.h3`×29 · `.h2`×26 · `.container`×23 · `.section`×21 · `.lead`×20 · `.btn`×17 · `.body`×13 · `.eyebrow`×12 · `.btn-ghost`×11 · `.sec-head`×11 · `.btn-primary`×4 · `.theme-toggle`×2 · `.fs`×2 · `.fs--rev`×2 · `.ss`×2 · `.ssh`×2 · `.tm`×2 · `.skip`×1 · `.nav`×1 · `.theme-toggle--nav`×1 · `.hero`×1 · `.hero--scatter`×1 · `.display`×1 · `.logos`×1 · `.logos--wall`×1 · `.fg`×1 · `.fg--cards`×1 · `.pin`×1 · `.pin--slide`×1 · `.mos`×1

## Reference density

The reference page carries **1733 visible words** across its sections. That is a description
of this example, not a target. Say what the brief supports and stop — a page padded to reach a
word count reads like one, and the reader can tell.
