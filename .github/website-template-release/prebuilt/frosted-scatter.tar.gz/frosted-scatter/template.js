
(function(){try{var t=localStorage.getItem('theme');if(t)document.documentElement.setAttribute('data-theme',t)}catch(e){}})();

document.querySelectorAll('.nav__burger').forEach(function(b){
  b.addEventListener('click',function(){
    var nav=b.closest('.nav'); var open=nav.getAttribute('data-open')==='true';
    nav.setAttribute('data-open',String(!open)); b.setAttribute('aria-expanded',String(!open));
  });
});
document.querySelectorAll('.nav__menu a').forEach(function(a){
  a.addEventListener('click',function(){var nav=a.closest('.nav');if(nav){nav.setAttribute('data-open','false');
    var b=nav.querySelector('.nav__burger');if(b)b.setAttribute('aria-expanded','false');}});
});
/* nav SCROLL STATE — data-scrolled (past hero), data-hide (scroll direction), and data-tone
   (light|dark of whatever section sits BEHIND the fixed nav). A section counts as DARK if it's the
   hero, a data-ground="dark" slab, a .ftx cover footer, or is explicitly marked [data-nav-dark].
   Skins style .nav[data-tone="dark"] to flip the header into dark-mode chrome, and back to light over
   white sections — a fixed nav is its own stacking context so this can't be done with blend modes. */
(function(){
  var nav=document.querySelector('.nav'); if(!nav) return;
  var hero=document.querySelector('.hero'); var lastY=window.pageYOffset||0;
  function darkZones(){ return [].slice.call(document.querySelectorAll('.hero,[data-ground="dark"],.ftx,[data-nav-dark]')); }
  var dz=darkZones();
  function onScroll(){
    var y=window.pageYOffset||0;
    var past = hero ? (hero.getBoundingClientRect().bottom<=72) : (y>80);
    nav.setAttribute('data-scrolled', String(!!past));
    if(y>160 && y>lastY+4) nav.setAttribute('data-hide','true');        // scrolling DOWN → hide up
    else if(y<lastY-4 || y<80) nav.setAttribute('data-hide','false');   // scrolling UP / near top → show
    lastY=y;
    var nr=nav.getBoundingClientRect(), probe=nr.top+nr.height/2, over='light';   // probe = nav's centre
    for(var i=0;i<dz.length;i++){ var r=dz[i].getBoundingClientRect(); if(r.top<=probe && r.bottom>=probe){ over='dark'; break; } }
    nav.setAttribute('data-tone', over);
  }
  window.addEventListener('scroll', onScroll, {passive:true});
  window.addEventListener('resize', function(){ dz=darkZones(); onScroll(); });
  onScroll();
})();


document.querySelectorAll('.cf__form').forEach(function(f){ f.addEventListener('submit',function(e){
  e.preventDefault(); if(!f.checkValidity()){f.reportValidity();return;}
  var ok=f.querySelector('.cf__ok'); if(ok)ok.hidden=false; f.reset(); });});


document.querySelectorAll('[data-cardgrid]').forEach(function(grid){
  var tabs=[].slice.call(grid.querySelectorAll('.cg__tab'));
  var cards=[].slice.call(grid.querySelectorAll('.cg__card'));
  var morewrap=grid.querySelector('.cg__morewrap'), more=grid.querySelector('.cg__more');
  var rail=grid.querySelector('.cg__grid');var prevB=grid.querySelector('.cg__nav--prev'),nextB=grid.querySelector('.cg__nav--next');
  function railStep(d){if(!rail)return;var c=rail.querySelector('.cg__card');var w=c?c.getBoundingClientRect().width+28:300;rail.scrollBy({left:d*w,behavior:'smooth'});}
  if(prevB)prevB.addEventListener('click',function(){railStep(-1);});if(nextB)nextB.addEventListener('click',function(){railStep(1);});
  var batch=parseInt(grid.getAttribute('data-batch'),10)||6, cur='all', shown=batch;
  function render(){
    var matched=cards.filter(function(c){return cur==='all'||c.getAttribute('data-cat')===cur;});
    cards.forEach(function(c){c.hidden=true;});
    matched.slice(0,shown).forEach(function(c){c.hidden=false;});
    if(morewrap) morewrap.hidden = matched.length<=shown;
  }
  tabs.forEach(function(t){ t.addEventListener('click',function(){
    tabs.forEach(function(x){x.setAttribute('aria-pressed','false');});
    t.setAttribute('aria-pressed','true'); cur=t.getAttribute('data-cat')||'all'; shown=batch; render();
  });});
  if(more) more.addEventListener('click',function(){ shown+=batch; render(); });
  render();
});


(function(){
  var RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
  document.querySelectorAll('.faq__item').forEach(function(d){
    var sum=d.querySelector('summary'), body=d.querySelector('.faq__a'), anim=null;
    if(!sum||!body) return;
    sum.addEventListener('click',function(e){
      if(RM) return;                                  // let native toggle handle it
      e.preventDefault();
      if(anim){ anim.cancel(); anim=null; }
      var pb=getComputedStyle(body).paddingBottom||'0px';   // animate padding too → true 0 collapse
      if(!d.open){                                    // OPEN: render, then grow 0→auto
        d.open=true; var h=body.offsetHeight;
        anim=body.animate([{height:'0px',opacity:0,paddingBottom:'0px'},{height:h+'px',opacity:1,paddingBottom:pb}],{duration:280,easing:'cubic-bezier(.2,.8,.2,1)'});
        anim.onfinish=function(){if(anim){anim.cancel();anim=null;}body.style.height='';};
      } else {                                        // CLOSE: shrink auto→0 (incl padding), hold 0, THEN unset open
        var start=body.offsetHeight; d.setAttribute('data-closing','');
        anim=body.animate([{height:start+'px',opacity:1,paddingBottom:pb},{height:'0px',opacity:0,paddingBottom:'0px'}],{duration:240,easing:'cubic-bezier(.4,0,.2,1)',fill:'forwards'});
        // fill:forwards holds height:0 so there's NO 1-frame pop back to full height (the close stutter);
        // padding animates to 0 too so it doesn't plateau at the padding height. Close details FIRST
        // (→display:none), then release the held animation.
        anim.onfinish=function(){d.open=false;d.removeAttribute('data-closing');if(anim){anim.cancel();anim=null;}body.style.height='';};
      }
    });
  });
})();


(function(){
  if(matchMedia('(prefers-reduced-motion:reduce)').matches) return;
  if(!('IntersectionObserver' in window)) return;
  document.querySelectorAll('[data-sticky-scroll]').forEach(function(sec){
    var panels=[].slice.call(sec.querySelectorAll('.ss__panel'));
    var items=[].slice.call(sec.querySelectorAll('.ss__item'));
    if(panels.length<2||!items.length) return;
    function activate(i){ panels.forEach(function(p){ p.classList.toggle('is-active', +p.getAttribute('data-i')===i); }); }
    var io=new IntersectionObserver(function(es){
      es.forEach(function(e){ if(e.isIntersecting) activate(+e.target.getAttribute('data-i')); });
    },{rootMargin:'-48% 0px -48% 0px',threshold:0});
    items.forEach(function(it){io.observe(it);});
  });
})();
/* sticky-scroll HORIZONTAL: map the section's vertical scroll progress → the card track's X.
   Skips the pin under reduced-motion / mobile (the CSS fallback = a manual horizontal rail). */
(function(){
  document.querySelectorAll('[data-sticky-h]').forEach(function(sec){
    var track=sec.querySelector('.ssh__track'), vp=sec.querySelector('.ssh__viewport');
    var curEl=sec.querySelector('.ssh__cur'), cards=[].slice.call(sec.querySelectorAll('.ssh__card'));
    var tabs=[].slice.call(sec.querySelectorAll('.ssh__tab'));
    tabs.forEach(function(t){ t.addEventListener('click',function(){ tabs.forEach(function(x){x.classList.remove('is-active');x.setAttribute('aria-pressed','false');}); t.classList.add('is-active'); t.setAttribute('aria-pressed','true'); }); });
    if(!track||!vp) return;
    var RM=matchMedia('(prefers-reduced-motion:reduce)').matches, MOB=matchMedia('(max-width:879px)').matches;
    if(RM||MOB){ vp.style.overflow=''; track.style.transform=''; return; } // CSS fallback = manual horizontal scroll rail
    vp.style.overflow='hidden';
    function maxX(){ return Math.max(0, track.scrollWidth - vp.clientWidth); }
    function prog(){ var total=sec.offsetHeight-window.innerHeight; if(total<=0)return 0;
      return Math.min(1,Math.max(0,-sec.getBoundingClientRect().top/total)); }
    function apply(){ var p=prog(); track.style.transform='translateX('+(-p*maxX())+'px)';
      if(curEl&&cards.length){ curEl.textContent=String(Math.min(cards.length,Math.round(p*(cards.length-1))+1)).padStart(2,'0'); } }
    sec.querySelectorAll('.ssh__arrow').forEach(function(a){ a.addEventListener('click',function(){
      var total=sec.offsetHeight-window.innerHeight; if(total<=0)return; var step=total/Math.max(1,cards.length-1);
      var base=window.pageYOffset+sec.getBoundingClientRect().top; var cur=Math.min(total,Math.max(0,prog()*total));
      window.scrollTo({top:base+Math.min(total,Math.max(0,cur+(+a.getAttribute('data-d'))*step)),behavior:'smooth'}); }); });
    window.addEventListener('scroll',apply,{passive:true}); window.addEventListener('resize',apply); apply();
  });
})();


document.querySelectorAll('[data-pinned-split]').forEach(function(sec){
  var frames=[].slice.call(sec.querySelectorAll('.pin__frame'));
  var panels=[].slice.call(sec.querySelectorAll('.pin__panel'));
  if(frames.length<2||!panels.length) return;
  if(matchMedia('(prefers-reduced-motion:reduce)').matches||!('IntersectionObserver' in window)) return;
  function activate(i){ frames.forEach(function(f){f.classList.toggle('is-active',+f.getAttribute('data-i')===i);});
    panels.forEach(function(p){p.classList.toggle('is-active',+p.getAttribute('data-i')===i);}); }
  var io=new IntersectionObserver(function(es){ es.forEach(function(e){ if(e.isIntersecting) activate(+e.target.getAttribute('data-i')); }); },
    {rootMargin:'-45% 0px -45% 0px',threshold:0});
  panels.forEach(function(p){io.observe(p);});
});


document.querySelectorAll('[data-pin-slide]').forEach(function(sec){
  var track=sec.querySelector('.pins__track'); if(!track) return;
  var shots=[].slice.call(sec.querySelectorAll('.pins__shot'));
  var lefts=[].slice.call(sec.querySelectorAll('.pins__text'));
  var rights=[].slice.call(sec.querySelectorAll('.pins__desc'));
  var n=shots.length; if(!n) return;
  if(matchMedia('(prefers-reduced-motion:reduce)').matches||matchMedia('(max-width:860px)').matches){
    shots.forEach(function(s){s.style.removeProperty('transform');s.style.removeProperty('opacity');s.style.removeProperty('z-index');});
    lefts.forEach(function(e){e.classList.add('is-on');}); rights.forEach(function(e){e.classList.add('is-on');}); return; }
  var ticking=false;
  function frame(){ ticking=false;
    var vh=window.innerHeight; var top=track.getBoundingClientRect().top;   // scrub over the pinned TRACK
    var total=track.offsetHeight-vh; var p= total>0 ? (-top)/total : 0; if(p<0)p=0; else if(p>1)p=1;
    var pos=p*n;
    for(var i=0;i<n;i++){ var t=pos-i;
      var ty=-t*100; if(ty>100)ty=100; else if(ty<-100)ty=-100;
      var op=1-Math.abs(t); if(op<0)op=0; else if(op>1)op=1;
      var s=shots[i]; s.style.transform='translateY('+ty.toFixed(1)+'%) scale('+(0.93+0.07*op).toFixed(3)+')';
      s.style.opacity=op.toFixed(3); s.style.zIndex=String(100-Math.round(Math.abs(t)*20));
    }
    var active=Math.round(pos); if(active<0)active=0; else if(active>n-1)active=n-1;
    for(var j=0;j<lefts.length;j++){ lefts[j].classList.toggle('is-on',j===active); }
    for(var k=0;k<rights.length;k++){ rights[k].classList.toggle('is-on',k===active); }
  }
  function onScroll(){ if(!ticking){ticking=true;requestAnimationFrame(frame);} }
  window.addEventListener('scroll',onScroll,{passive:true}); window.addEventListener('resize',onScroll); frame();
});


document.querySelectorAll('[data-mos-drag]').forEach(function(row){
  var down=false,startX=0,startL=0,moved=false;
  row.addEventListener('pointerdown',function(e){ if(e.button!==undefined&&e.button!==0)return;
    down=true; moved=false; startX=e.clientX; startL=row.scrollLeft; try{row.setPointerCapture(e.pointerId);}catch(x){} row.classList.add('is-drag'); });
  row.addEventListener('pointermove',function(e){ if(!down)return; var dx=e.clientX-startX; if(Math.abs(dx)>4)moved=true; row.scrollLeft=startL-dx; e.preventDefault(); });
  function up(){ down=false; row.classList.remove('is-drag'); }
  row.addEventListener('pointerup',up); row.addEventListener('pointercancel',up);
  row.addEventListener('click',function(e){ if(moved){ e.preventDefault(); e.stopPropagation(); } },true);
  row.addEventListener('keydown',function(e){ if(e.key==='ArrowRight')row.scrollLeft+=240; else if(e.key==='ArrowLeft')row.scrollLeft-=240; });
});


document.querySelectorAll('[data-tm-carousel]').forEach(function(sec){
  var stage=sec.querySelector('.tm__stage');
  var cards=[].slice.call(sec.querySelectorAll('.tm__case'));
  var dots=[].slice.call(sec.querySelectorAll('.tm__dot'));
  if(!stage||cards.length<2) return;
  function step(){ return cards[0].getBoundingClientRect().width + 20; }
  sec.querySelectorAll('.tm__arrow').forEach(function(a){a.addEventListener('click',function(){
    stage.scrollBy({left:(+a.getAttribute('data-d'))*step(),behavior:'smooth'}); });});
  dots.forEach(function(d,j){d.addEventListener('click',function(){
    cards[j].scrollIntoView({behavior:'smooth',inline:'center',block:'nearest'}); });});
  function sync(){ var r=stage.getBoundingClientRect(); var c=r.left+r.width/2; var best=0,bd=1e9;
    cards.forEach(function(card,j){ var cr=card.getBoundingClientRect(); var cc=cr.left+cr.width/2; var dd=Math.abs(cc-c); if(dd<bd){bd=dd;best=j;} });
    dots.forEach(function(d,j){d.classList.toggle('is-active',j===best);d.setAttribute('aria-pressed',String(j===best));}); }
  var raf=0; stage.addEventListener('scroll',function(){ if(raf)return; raf=requestAnimationFrame(function(){raf=0;sync();}); },{passive:true});
  sync();
});


(function(){
  var root=document.documentElement;
  function apply(){var d=root.getAttribute('data-theme')||'light';
    document.querySelectorAll('[data-theme-toggle]').forEach(function(b){
      b.setAttribute('aria-checked',String(d==='dark'));
      b.setAttribute('aria-label',d==='dark'?'Switch to light theme':'Switch to dark theme');
      var l=b.querySelector('.theme-toggle__label'); if(l)l.textContent=d==='dark'?'Light mode':'Dark mode';
    });}
  document.querySelectorAll('[data-theme-toggle]').forEach(function(b){b.addEventListener('click',function(){
    var d=(root.getAttribute('data-theme')||'light')==='dark'?'light':'dark';
    root.setAttribute('data-theme',d);try{localStorage.setItem('theme',d)}catch(e){}apply();});});
  apply();
})();


(function(){
  var root=document.documentElement;
  var RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
  var HOVER=matchMedia('(hover:hover)').matches;
  var num=function(v,d){v=parseFloat(v);return isNaN(v)?d:v;};

  // text-split: wrap each word in <span class=mo-line><span class=mo-w --i></span></span>
  document.querySelectorAll('[data-motion="text-split"]').forEach(function(el){
    var words=el.textContent.trim().split(/\s+/); el.textContent='';
    words.forEach(function(w,i){ var line=document.createElement('span'); line.className='mo-line';
      var s=document.createElement('span'); s.className='mo-w'; s.style.setProperty('--i',i); s.textContent=w;
      line.appendChild(s); el.appendChild(line); if(i<words.length-1) el.appendChild(document.createTextNode(' ')); });
  });
  // stagger: index children
  document.querySelectorAll('[data-motion="stagger"]').forEach(function(el){
    [].forEach.call(el.children,function(c,i){c.style.setProperty('--i',i);}); });

  if(RM){ document.querySelectorAll('[data-motion^="reveal"],[data-motion="stagger"],[data-motion="text-split"],[data-motion="count-up"]').forEach(function(e){e.classList.add('mo-in');}); return; }

  // marquee: clone the track once for a seamless -50% loop. Idempotent — skip if already wrapped
  // (a page whose DOM was serialized AFTER this ran, e.g. apply-photos output, won't double-wrap).
  document.querySelectorAll('[data-motion="marquee"]').forEach(function(el){
    if(el.querySelector('.mo-track')) return;
    var t=document.createElement('div'); t.className='mo-track'; while(el.firstChild)t.appendChild(el.firstChild);
    el.appendChild(t);
    // A SHORT list makes the track narrower than the viewport → the -50% loop leaves an empty gap
    // on the right (uneven distribution). Repeat the base items until one track comfortably exceeds
    // a wide viewport, THEN clone it for the seamless loop. So a few logos still fill the row.
    var base=t.innerHTML, guard=0;
    while(t.scrollWidth < 2200 && guard++ < 24){ t.insertAdjacentHTML('beforeend', base); }
    var c=t.cloneNode(true); el.appendChild(c); });

  // line-reveal: split a paragraph into visual LINES and wipe each in left→right as it enters view.
  // (learned from a frosted product site — body copy that "types" one line at a time, per line L→R.)
  [].slice.call(document.querySelectorAll('[data-motion="line-reveal"]')).forEach(function(el){
    var txt=(el.textContent||'').replace(/\s+/g,' ').trim(); if(!txt) return;
    el.textContent=''; var words=txt.split(' '), probe=[];
    words.forEach(function(w,i){ var s=document.createElement('span'); s.style.display='inline-block';
      s.textContent=w+(i<words.length-1?'\u00a0':''); el.appendChild(s); probe.push(s); });
    var lines=[],cur=[],top=null;
    probe.forEach(function(s){ var t=s.offsetTop; if(top===null||Math.abs(t-top)>2){ if(cur.length)lines.push(cur); cur=[]; top=t; } cur.push(s); });
    if(cur.length)lines.push(cur);
    el.textContent='';
    lines.forEach(function(ln,li){ var outer=document.createElement('span'); outer.className='mo-lr';
      var inner=document.createElement('span'); inner.className='mo-lr-i'; inner.style.setProperty('--i',li);
      ln.forEach(function(s){ s.style.display=''; inner.appendChild(s); }); outer.appendChild(inner); el.appendChild(outer); });
    el.classList.add('is-split');
  });

  // count-up tween
  function countUp(el){ var to=num(el.getAttribute('data-to'),num(el.textContent,0)); var suf=el.getAttribute('data-suffix')||'';
    var dur=1400, t0=null; function step(t){ if(!t0)t0=t; var k=Math.min(1,(t-t0)/dur); var e=1-Math.pow(1-k,3);
      el.textContent=Math.round(to*e)+suf; if(k<1)requestAnimationFrame(step); } requestAnimationFrame(step); }

  // IntersectionObserver: reveal family + count-up
  if('IntersectionObserver' in window){
    var io=new IntersectionObserver(function(es){es.forEach(function(e){ if(!e.isIntersecting)return;
      var el=e.target; el.classList.add('mo-in');
      if(el.getAttribute('data-motion')==='count-up') countUp(el);
      io.unobserve(el); });},{threshold:.16,rootMargin:'0px 0px -8% 0px'});
    document.querySelectorAll('[data-motion^="reveal"],[data-motion="stagger"],[data-motion="text-split"],[data-motion="count-up"],[data-motion="line-reveal"]').forEach(function(e){io.observe(e);});
  } else { document.querySelectorAll('[data-motion]').forEach(function(e){e.classList.add('mo-in');}); }

  // rAF: parallax + image-parallax + scroll-progress
  var paras=[].slice.call(document.querySelectorAll('[data-motion="parallax"]'));
  var imgs=[].slice.call(document.querySelectorAll('[data-motion="image-parallax"] > *'));
  var bars=[].slice.call(document.querySelectorAll('[data-motion="scroll-progress"]'));
  var ills=[].slice.call(document.querySelectorAll('[data-motion="text-illuminate"]'));   // scroll-linked line brighten
  var focs=[].slice.call(document.querySelectorAll('[data-motion="stat-focus"]'));        // one big number in focus at a time
  var ticking=false;
  function frame(){ var vh=innerHeight, mid=vh/2;
    paras.forEach(function(el){ var sp=num(el.getAttribute('data-speed'),.18); var r=el.getBoundingClientRect();
      var off=((r.top+r.height/2)-mid)*-sp; el.style.transform='translate3d(0,'+off.toFixed(1)+'px,0)'; });
    imgs.forEach(function(el){ var p=el.parentElement; var sp=num(p.getAttribute('data-speed'),.06); var sc=num(p.getAttribute('data-pscale'),1.18);
      var r=p.getBoundingClientRect(); var off=((r.top+r.height/2)-mid)*sp;   /* +sp: scroll DOWN → image drifts UP (conventional parallax) */
      var hw=(sc-1)/2*r.height*.92; if(off>hw)off=hw; else if(off<-hw)off=-hw;   /* CLAMP to the scale headroom so the image always covers — never a gap at the frame edge */
      el.style.transform='scale('+sc+') translate3d(0,'+off.toFixed(1)+'px,0)'; });
    if(bars.length){ var h=document.documentElement.scrollHeight-innerHeight; var k=h>0?Math.min(1,scrollY/h):0;
      bars.forEach(function(b){b.style.transform='scaleX('+k.toFixed(4)+')';}); }
    // text-illuminate: light the statement LINE BY LINE as the block scrolls up through the viewport
    ills.forEach(function(el){ var lines=el.querySelectorAll('.mo-ill'); var m=lines.length; if(!m)return;
      var r=el.getBoundingClientRect(); var p=(vh-r.top)/(vh+r.height); if(p<0)p=0; else if(p>1)p=1;
      var lit=p*(m+1);
      for(var i=0;i<m;i++){ var t=lit-i; if(t<0)t=0; else if(t>1)t=1; lines[i].style.opacity=(0.28+0.72*t).toFixed(3); } });
    // stat-focus: the row nearest viewport-centre is bright; neighbours fall away (screenshot-1 big numbers)
    focs.forEach(function(scene){ var rows=scene.querySelectorAll('.st__row'); var n=rows.length; if(!n)return;
      var best=1e9,bi=0;
      for(var i=0;i<n;i++){ var rr=rows[i].getBoundingClientRect(); var dc=Math.abs((rr.top+rr.height/2)-mid); if(dc<best){best=dc;bi=i;} }
      for(var j=0;j<n;j++){ var dd=Math.abs(j-bi); var o=dd===0?1:(dd===1?0.42:0.12);
        rows[j].style.setProperty('--foc',o.toFixed(2)); rows[j].classList.toggle('is-foc',j===bi); } });
    ticking=false; }
  function onScroll(){ if(!ticking){ticking=true; requestAnimationFrame(frame);} }
  if(paras.length||imgs.length||bars.length||ills.length||focs.length){ addEventListener('scroll',onScroll,{passive:true}); addEventListener('resize',onScroll); frame(); }

  if(!HOVER) return;
  // custom cursor — the understated dot (grows on interactive, difference blend). The ONE cursor.
  var cur=document.createElement('div'); cur.className='mo-cursor'; cur.style.opacity='0'; document.body.appendChild(cur);
  document.documentElement.classList.add('mo-cursor-on');   // → hide the native pointer (CSS, pointer devices only)
  addEventListener('pointermove',function(e){ cur.style.opacity='1'; cur.style.left=e.clientX+'px'; cur.style.top=e.clientY+'px'; });
  document.querySelectorAll('a,button,[data-magnetic],[data-motion="hover-tilt"],[data-motion="magnetic"]').forEach(function(el){
    el.addEventListener('pointerenter',function(){cur.classList.add('mo-big');});
    el.addEventListener('pointerleave',function(){cur.classList.remove('mo-big');}); });

  // hover-tilt (rotateX/Y toward cursor) — [data-tilt] is the opt-in "all cards tilt" hook (skin.cardTilt)
  document.querySelectorAll('[data-motion="hover-tilt"],[data-tilt]').forEach(function(el){
    el.addEventListener('pointermove',function(e){ var t=num(getComputedStyle(root).getPropertyValue('--mo-tilt'),6);
      var r=el.getBoundingClientRect(); var px=(e.clientX-r.left)/r.width-.5, py=(e.clientY-r.top)/r.height-.5;
      el.style.transform='perspective(800px) rotateY('+(px*t).toFixed(2)+'deg) rotateX('+(-py*t).toFixed(2)+'deg)'; });
    el.addEventListener('pointerleave',function(){el.style.transform='';}); });

  // magnetic (translate toward cursor)
  document.querySelectorAll('[data-motion="magnetic"]').forEach(function(el){
    el.addEventListener('pointermove',function(e){ var m=num(getComputedStyle(root).getPropertyValue('--mo-mag'),.3);
      var r=el.getBoundingClientRect(); var dx=(e.clientX-(r.left+r.width/2))*m, dy=(e.clientY-(r.top+r.height/2))*m;
      el.style.transform='translate('+dx.toFixed(1)+'px,'+dy.toFixed(1)+'px)'; });
    el.addEventListener('pointerleave',function(){el.style.transform='';}); });

  // spotlight (move the radial light)
  document.querySelectorAll('[data-motion="spotlight"]').forEach(function(el){
    el.addEventListener('pointermove',function(e){ var r=el.getBoundingClientRect();
      el.style.setProperty('--mx',(e.clientX-r.left)+'px'); el.style.setProperty('--my',(e.clientY-r.top)+'px'); }); });

  // pointer-parallax — scattered children drift toward the cursor at per-depth rates (hero mis-align).
  // Each [data-depth] child lags the pointer by an eased amount → layered depth + deliberate offset.
  [].slice.call(document.querySelectorAll('[data-motion="pointer-parallax"]')).forEach(function(scene){
    var items=[].slice.call(scene.querySelectorAll('[data-depth]')); if(!items.length) return;
    var tx=0,ty=0,cx=0,cy=0,raf=0;
    function loop(){ cx+=(tx-cx)*.09; cy+=(ty-cy)*.09;
      items.forEach(function(el){ var d=num(el.getAttribute('data-depth'),.2);
        el.style.transform='translate3d('+(cx*d).toFixed(1)+'px,'+(cy*d).toFixed(1)+'px,0)'; });
      if(Math.abs(tx-cx)>.15||Math.abs(ty-cy)>.15){ raf=requestAnimationFrame(loop); } else { raf=0; } }
    scene.addEventListener('pointermove',function(e){ var r=scene.getBoundingClientRect();
      tx=((e.clientX-r.left)/r.width-.5)*r.width*.12; ty=((e.clientY-r.top)/r.height-.5)*r.height*.12;
      if(!raf) raf=requestAnimationFrame(loop); });
    scene.addEventListener('pointerleave',function(){ tx=0; ty=0; if(!raf) raf=requestAnimationFrame(loop); });
  });

  // spotlight-cursor — a continuous background grid that scrolls with the page and lights around the
  // pointer. The page grid (.pagegrid) is DOCUMENT-aligned → publish DOCUMENT coords to :root (--gx/--gy,
  // updated on move AND scroll so the highlight stays under the cursor). Each [data-sgrid] island gets
  // element-LOCAL cursor coords (--lx/--ly) + a document-top offset (--goy) so its grid phase-aligns to
  // the page grid (lines run unbroken across the boundary — no truncation).
  // Every section (+ footer) carries the same cursor-lit grid. Publish each host's cursor-LOCAL coords
  // (--lx/--ly) so the light follows the pointer, and its DOCUMENT-top (--goy) so all the grids share
  // ONE origin → the lines run continuously from section to section (no truncation at a boundary).
  var gridHosts=[].slice.call(document.querySelectorAll('main .section, body>footer .ftp'));
  if(gridHosts.length){
    function setGoy(){ var sy=window.pageYOffset||0;
      for(var i=0;i<gridHosts.length;i++){ var el=gridHosts[i]; el.style.setProperty('--goy',Math.round(el.getBoundingClientRect().top+sy)+'px'); } }
    addEventListener('pointermove',function(e){
      for(var i=0;i<gridHosts.length;i++){ var el=gridHosts[i], r=el.getBoundingClientRect();
        if(r.bottom<-400||r.top>innerHeight+400) continue;   // skip far-off-screen sections
        el.style.setProperty('--lx',Math.round(e.clientX-r.left)+'px'); el.style.setProperty('--ly',Math.round(e.clientY-r.top)+'px'); }
    },{passive:true});
    addEventListener('resize',setGoy); setGoy();
  }
})();
