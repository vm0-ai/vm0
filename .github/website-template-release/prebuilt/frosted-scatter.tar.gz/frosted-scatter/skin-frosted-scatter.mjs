/* skin-frosted-scatter.mjs — a skin learned (clean-room) from a frosted voice-product site.
 * Identity: a very-modern LUMINOUS GLASS language — a scattered parallax photo hero that mis-aligns
 * under the cursor, a page-wide faint grid that lights only around the pointer (a flashlight), body
 * copy that wipes in one line at a time, and a tall column of huge numbers that come into focus one at
 * a time as you scroll. Frosted cards, big radii, one lilac pop on near-black / near-white grounds.
 *
 * COLOUR — bespoke frosted set (dual-mode, AA-calibrated). Permitted here because it's a glass/gradient
 * design that the 16-palette catalogue can't express; the SYSTEM FONT is honoured (fonts.mjs `tech` =
 * Sora + Inter). --accent is a mid/deep purple that clears AA as text on its ground; the lilac pop is a
 * FILL used with dark ink. Dark "slab" grounds (hero optional · stats-reveal · footer) remap roles locally.
 */
export const skin = {
  id:'frosted-scatter',
  fontsAttr:'frosted-scatter', motionAttr:'kinetic',
  fontLink:'<link href="https://fonts.googleapis.com/css2?family=Sora:wght@500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">',
  signature:'scattered parallax photo hero · flashlight grid cursor · line-by-line copy · one-at-a-time big numbers · frosted glass',
  // OPT-INS the engine/skinsheet read:
  parallax:{speed:0.06, scale:1.3},   // gentle image-parallax on content media
  cardLayout:'rail',                  // horizontal card rail (bleeds off the edges)
  statsLayout:'reveal',               // pinned header + one-at-a-time big numbers
  footerLayout:'panel',               // differentiated footer (wordmark + cols + frosted CTA card)
  lineReveal:true,                    // step bodies wipe in line by line
  pinnedLayout:'slide',               // daily-loop: center image slides up & leaves, side text swaps in place
  cardTilt:true,                      // every card gets a subtle 3D parallax tilt toward the cursor on hover
  css:`
/* ① COLOURS — frosted, dual-mode ------------------------------------------------------------ */
:root{
  --bg:#EDEEF3; --surface:#FFFFFF; --surface-2:#E6E8F0; --ink:#131522; --ink-soft:#585F76;
  --accent:#6338E6; --accent-ink:#FFFFFF; --support-1:#8A6BFF; --support-2:#12B6C9;
  --border:#E1E3EC; --ring:#6338E6;
  --fd:'Sora'; --fb:'Inter'; --radius:20px; --container:var(--w-wide);
  --glass-brd:rgba(20,20,55,.10); --frost:saturate(160%) blur(16px);
  /* glass-pill nav (glass-bloom structure) */
  --nav-glass:rgba(255,255,255,.72); --nav-brd:rgba(20,20,55,.12);
  /* mouse-lit page grid — TWO levels: BIG major cells + a finer MINOR sub-grid (4 per big cell) whose
     lines are much lighter. Both brighten around the cursor (--gx/--gy = viewport coords). */
  --goy:0px; --grid-cell:80px; --grid-sub:20px;
  /* faint, smaller. Cool-grey on the light canvas (so it's visible); the dark islands override to WHITE */
  --grid-maj:rgba(108,114,158,.13); --grid-min:rgba(108,114,158,.045);
}
html[data-theme="dark"]{
  --bg:#0A0B12; --surface:#13141F; --surface-2:#1B1D2B; --ink:#EEF0FA; --ink-soft:#A7ADC4;
  --accent:#B7A6FF; --accent-ink:#0A0B12; --support-1:#C7BAFF; --support-2:#5EEAD4;
  --border:#242739; --ring:#B7A6FF;
  --glass-brd:rgba(255,255,255,.12);
  --nav-glass:rgba(18,20,30,.6); --nav-brd:rgba(255,255,255,.14);
  --grid-maj:rgba(255,255,255,.11); --grid-min:rgba(255,255,255,.038);
}
.display,h1,h2,h3,.h1,.h2,.h3{font-weight:700;letter-spacing:-.03em}
.display{font-weight:800;letter-spacing:-.04em}
.eyebrow{letter-spacing:.18em;font-weight:600}
.lead{color:var(--ink-soft)}
/* ALL first-level section titles LEFT-aligned (hero + footer keep their own alignment). Only the TEXT
   is left-aligned — the .container geometry stays on the shared grid (don't zero a .container margin). */
.sec-head{text-align:left;margin-inline:0;max-width:72ch}
.fs__heading,.faq__h{text-align:left}
.pin__intro{text-align:left;max-width:none}

/* frosted glass helper + one shared stacking rule (all content above the fixed page grid).
   NOTE: the header must NOT get a stacking context here or it would trap the fixed nav (z:100)
   below the sections — the nav stays in the ROOT context, above everything. */
.frost{background:color-mix(in srgb,var(--surface) 80%,transparent);backdrop-filter:var(--frost);-webkit-backdrop-filter:var(--frost);border:1px solid var(--glass-brd)}
.section{position:relative;z-index:1}
@media(prefers-reduced-transparency:reduce){.frost{background:var(--surface);backdrop-filter:none;-webkit-backdrop-filter:none}}

/* dark ISLANDS — the big-number band + footer stay dark (per the references); remap roles LIGHT.
   (The hero is NOT dark — it sits on the light-grey canvas with the global grid.) */
.stats--reveal, .ftp{
  --ink:#EEF0FA; --ink-soft:#AEB4C8; --accent:#BCA9FF; --accent-ink:#0A0B12;
  --border:rgba(255,255,255,.14); --surface:#14161F; --surface-2:#1B1E2A; --glass-brd:rgba(255,255,255,.12);
  --grid-maj:rgba(255,255,255,.15); --grid-min:rgba(255,255,255,.05);   /* white grid on the dark ground */
  background-color:#08090F; color:var(--ink)}

/* ── MOUSE-LIT GRID — THE QUIET PROOF's grid, on EVERY section. A two-level WHITE grid that appears
   around the cursor (radial mask), behind the content (::before, z-index:-1). Every section AND the
   footer carries the SAME grid, all phase-aligned to ONE document origin via --goy → the lines run
   UNBROKEN from one section straight into the next (no truncation at any boundary). The runtime
   publishes per-section cursor coords (--lx/--ly) + the section's document-top (--goy). */
main{position:relative}
.section, .ftp{--lx:50%; --ly:40%; --goy:0px}
.ftp{position:relative;isolation:isolate}
.section::before, .ftp::before{content:"";position:absolute;inset:0;z-index:-1;pointer-events:none;
  background-image:
    linear-gradient(to right,var(--grid-maj) 1px,transparent 1px),linear-gradient(to bottom,var(--grid-maj) 1px,transparent 1px),
    linear-gradient(to right,var(--grid-min) 1px,transparent 1px),linear-gradient(to bottom,var(--grid-min) 1px,transparent 1px);
  background-size:var(--grid-cell) var(--grid-cell),var(--grid-cell) var(--grid-cell),var(--grid-sub) var(--grid-sub),var(--grid-sub) var(--grid-sub);
  background-position:0 calc(-1 * var(--goy));   /* one document origin → continuous across sections */
  -webkit-mask:radial-gradient(circle 360px at var(--lx) var(--ly),#000 0,rgba(0,0,0,.12) 46%,transparent 80%);
          mask:radial-gradient(circle 360px at var(--lx) var(--ly),#000 0,rgba(0,0,0,.12) 46%,transparent 80%)}
@media(prefers-reduced-motion:reduce){.section::before,.ftp::before{-webkit-mask:radial-gradient(circle 340px at 50% 42%,#000,transparent 82%);mask:radial-gradient(circle 340px at 50% 42%,#000,transparent 82%)}}
.ftp__grid{display:none}   /* old static footer grid unused */

/* buttons — pill CTAs, frosted ghost */
.btn{border-radius:var(--r-pill);font-weight:600}
.btn-primary{box-shadow:0 8px 24px -10px color-mix(in srgb,var(--accent) 70%,transparent)}
.btn-ghost{background:color-mix(in srgb,var(--surface) 60%,transparent);backdrop-filter:var(--frost);-webkit-backdrop-filter:var(--frost);border-color:var(--glass-brd);color:var(--ink)}

/* ────────────────────────────────────────────────────────────────────────────────────────
   1 · NAV — SAME STRUCTURE as glass-bloom: a fixed, content-hugging CENTRED Apple-glass pill
   (circular initial logo INSIDE on the left · links · CTA · toggle); hides on scroll-down. The pill
   carries its own frosted backing (theme-based), so chrome is always readable over any ground.
   ──────────────────────────────────────────────────────────────────────────────────────── */
.nav{position:fixed;top:0;left:0;right:0;z-index:100;background:transparent;border:0;transition:transform .35s ease}
.nav[data-hide="true"]{transform:translateY(-150%)}
.nav__bar{margin-top:16px}
/* logo = a purple circle with the brand initial (wordmark hidden), visible on the pill in both themes */
.nav__brand{flex:none;width:42px;height:42px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;
  text-decoration:none;background:var(--accent);color:#fff}
.nav__wordmark{display:none}
.nav__brand::before{content:attr(data-initial);font-family:var(--fd);font-weight:700;font-size:1.12rem;line-height:1}
.nav__links a{font-family:var(--fb);font-weight:500;font-size:.9rem;color:var(--ink)}
.nav__links a:hover{color:var(--accent)}
.nav__cta{font-size:.85rem;padding:.5rem 1.1rem;border-radius:var(--r-pill)}
.theme-toggle{border-radius:var(--r-pill);background:transparent;border-color:transparent;min-width:40px;min-height:40px;padding:.4rem .6rem;color:var(--ink)}
.nav__burger{display:none}
@media(min-width:768px){
  /* the whole bar IS the Apple-style glass pill — hugging its content, centred; logo is its first item */
  .nav__bar{width:max-content;min-height:0;margin-inline:auto;gap:1.05rem;padding:.4rem .6rem .4rem .5rem;border-radius:var(--r-pill);
    background:var(--nav-glass);border:1px solid var(--nav-brd);
    box-shadow:inset 0 1px 0 rgba(255,255,255,.6), 0 12px 32px -14px rgba(20,28,60,.32);
    backdrop-filter:blur(26px) saturate(1.9);-webkit-backdrop-filter:blur(26px) saturate(1.9)}
  .nav__menu{display:flex;align-items:center;gap:1.05rem}
  .nav__links{display:flex;gap:1.4rem}
}
@media(max-width:767px){
  .nav__bar{width:max-content;margin-inline:auto;gap:.9rem;padding:.4rem .5rem;border-radius:var(--r-pill);
    background:var(--nav-glass);border:1px solid var(--nav-brd);backdrop-filter:blur(22px) saturate(1.8);-webkit-backdrop-filter:blur(22px) saturate(1.8)}
  .nav__burger{display:inline-flex;background:transparent;border:0;color:var(--ink)}
  .nav__menu{position:absolute;inset:auto var(--gutter) auto auto;top:calc(100% + .5rem);flex-direction:column;align-items:stretch;gap:var(--space-4);
    padding:1.2rem;border-radius:var(--r-lg);background:var(--surface);border:1px solid var(--border);box-shadow:var(--shadow-lifted);display:none}
  .nav__menu[data-open]{display:flex}
  .nav__links{flex-direction:column;gap:var(--space-4)}
}

/* ────────────────────────────────────────────────────────────────────────────────────────
   2 · HERO — scattered parallax photo chips + centred display + flashlight grid behind
   ──────────────────────────────────────────────────────────────────────────────────────── */
.hero--scatter{position:relative;min-height:100svh;display:flex;align-items:center;overflow:hidden;padding-block:clamp(6rem,15vh,11rem)}
.hs__scene{position:absolute;inset:0;z-index:1}
.hs__chip{position:absolute;border-radius:var(--r-lg);width:auto;aspect-ratio:auto;
  background:color-mix(in srgb,var(--surface) 70%,transparent);backdrop-filter:var(--frost);-webkit-backdrop-filter:var(--frost);
  border:1px solid var(--glass-brd);box-shadow:0 40px 80px -34px rgba(0,0,0,.6)}
/* BIGGER scattered images (per reference) */
.hs__c1{width:clamp(150px,19vw,320px);aspect-ratio:3/4;top:9%;left:4%}
.hs__c2{width:clamp(130px,16vw,260px);aspect-ratio:1/1;top:14%;right:6%}
.hs__c3{width:clamp(120px,14vw,230px);aspect-ratio:4/5;bottom:12%;left:11%}
.hs__c4{width:clamp(170px,21vw,360px);aspect-ratio:16/11;bottom:9%;right:5%}
.hs__c5{width:clamp(104px,12vw,190px);aspect-ratio:1/1;top:56%;left:1%}
.hs__c6{width:clamp(128px,15vw,236px);aspect-ratio:3/4;top:6%;right:30%}
/* SMALLER title / paragraph / text */
.hero__inner{position:relative;z-index:2;text-align:center;max-width:44rem;margin-inline:auto}
.hero__title{font-size:clamp(1.7rem,3.6vw,2.9rem);line-height:1.06;margin-block:var(--space-3) var(--space-4)}
.hero__lead{max-width:42ch;margin-inline:auto;font-size:clamp(1rem,1.25vw,1.15rem);color:var(--ink-soft)}
.hero__cta{display:flex;gap:var(--space-3);justify-content:center;margin-top:var(--space-5);flex-wrap:wrap}
@media(max-width:760px){.hs__c3,.hs__c5,.hs__c6{display:none}}

/* ────────────────────────────────────────────────────────────────────────────────────────
   3 · FEATURE-SPLIT — airy alternating rows, big rounded media
   ──────────────────────────────────────────────────────────────────────────────────────── */
.fs__heading{max-width:20ch;margin-bottom:clamp(1.6rem,4vw,3rem);font-size:clamp(1.7rem,3.4vw,2.6rem)}
.fs__row{gap:clamp(1.6rem,5vw,4.5rem);align-items:center}
.fs__text .eyebrow{color:var(--accent)}
.fs__icon{display:inline-flex;width:52px;height:52px;align-items:center;justify-content:center;border-radius:var(--r-lg);
  background:color-mix(in srgb,var(--accent) 14%,transparent);color:var(--accent);margin-bottom:var(--space-4)}
.fs .media{border-radius:var(--r-xl);border:1px solid var(--glass-brd);box-shadow:0 40px 80px -46px rgba(20,20,60,.5)}
.fs__text h3{font-size:clamp(1.4rem,2.6vw,2.1rem)}

/* ────────────────────────────────────────────────────────────────────────────────────────
   4 · FEATURE-GRID — frosted glass cards, soft lilac icon tiles
   ──────────────────────────────────────────────────────────────────────────────────────── */
.fg__grid{gap:clamp(1rem,2vw,1.4rem)}
.fg__card{border-radius:var(--r-xl);padding:clamp(1.5rem,2.6vw,2.1rem);
  background:color-mix(in srgb,var(--surface) 80%,transparent);backdrop-filter:var(--frost);-webkit-backdrop-filter:var(--frost);
  border:1px solid var(--glass-brd);transition:transform .3s var(--mo-ease),box-shadow .3s var(--mo-ease)}
.fg__card:hover{transform:translateY(-6px);box-shadow:0 30px 60px -34px rgba(20,20,60,.5)}
.fg__icon{display:inline-flex;width:48px;height:48px;align-items:center;justify-content:center;border-radius:14px;
  background:color-mix(in srgb,var(--accent) 16%,transparent);color:var(--accent);margin-bottom:var(--space-4)}
.fg__card h3{font-size:1.28rem;margin-bottom:var(--space-3)}

/* ────────────────────────────────────────────────────────────────────────────────────────
   5 · LOGOS — quiet frosted chips on the marquee wall
   ──────────────────────────────────────────────────────────────────────────────────────── */
.logos{padding-block:clamp(1.4rem,3vw,2.4rem)}
.logos__marquee{--gap:1rem}
.logos__item{font-family:var(--fd);font-weight:600;color:var(--ink-soft);opacity:.8;
  padding:.5rem 1.1rem;border-radius:var(--r-pill);border:1px solid var(--glass-brd);
  background:color-mix(in srgb,var(--surface) 60%,transparent);backdrop-filter:var(--frost);-webkit-backdrop-filter:var(--frost)}

/* ────────────────────────────────────────────────────────────────────────────────────────
   6 · STATS — default band frosted · REVEAL variant = dark slab, one big number at a time
   ──────────────────────────────────────────────────────────────────────────────────────── */
.stats__cell{padding:clamp(1.3rem,2.4vw,1.9rem);border-radius:var(--r-xl);
  background:color-mix(in srgb,var(--surface) 78%,transparent);backdrop-filter:var(--frost);-webkit-backdrop-filter:var(--frost);border:1px solid var(--glass-brd)}
.stats__num{font-family:var(--fd);font-weight:800;letter-spacing:-.04em;font-size:clamp(2rem,4vw,3rem)}
/* DO NOT add overflow:hidden here — it makes the section its own scroll container and BREAKS the
   viewport-sticky on the left title (it would scroll away with the section). The grid ::before is
   inset:0 + masked, so it never needs clipping. */
.stats--reveal{position:relative;--stk-top:clamp(4.5rem,15vh,8rem)}
.stats--reveal .container{position:relative;z-index:1}
.stats--reveal .eyebrow{color:var(--accent)}
.stats__leadH{font-size:clamp(1.8rem,3.6vw,2.8rem);margin-top:var(--space-3)}
/* align the FIRST number's top with the pinned title (same offset on both columns) */
.stats--reveal .stats__lead{top:var(--stk-top)}
/* +eyebrow height so the FIRST number aligns with the TITLE; small bottom padding so the LAST number
   sits near the section end → it and the pinned title scroll away TOGETHER as the section exits. */
/* push the data block toward the RIGHT edge of the section (was too much empty space on the right) */
.stats--reveal .stats__stack{padding-top:calc(var(--stk-top) + 2.1rem);padding-bottom:clamp(1rem,4vh,3rem);max-width:34rem;margin-left:auto}
@media(min-width:900px){.stats--reveal .stats__revwrap{grid-template-columns:.9fr 1.1fr}}
.stats__leadSub{color:var(--ink-soft);margin-top:var(--space-4);max-width:34ch;font-size:clamp(1rem,1.3vw,1.15rem)}
/* SMALLER + LIGHTER numbers. Brightness comes from stat-focus opacity (very light grey when far →
   bright when focused); the FOCUSED one also RISES in (a subtle appear animation). */
.st__num{background:none;color:#F2F4FC;
  font-family:var(--fd);font-weight:600;letter-spacing:-.03em;font-size:clamp(2.1rem,4.6vw,4.4rem);line-height:1;
  transform:translateY(14px);transition:transform .55s var(--mo-ease)}
.st__row.is-foc .st__num{transform:none}
.st__cap{color:var(--ink-soft)}

/* ────────────────────────────────────────────────────────────────────────────────────────
   7 · STEPS — numbered, big lilac numerals, line-revealed bodies
   ──────────────────────────────────────────────────────────────────────────────────────── */
.steps__list{display:grid;gap:clamp(1.4rem,3vw,2.4rem);grid-template-columns:1fr}
@media(min-width:760px){.steps__list{grid-template-columns:repeat(3,1fr)}}
/* override the base flex row (which made the huge numeral overlap the title/body) → clean vertical stack */
.steps__item{display:block;padding-top:var(--space-5);border-top:2px solid var(--glass-brd)}
.steps__num{font-family:var(--fd);font-weight:800;font-size:clamp(2.2rem,4vw,3rem);letter-spacing:-.02em;line-height:1;
  color:var(--accent);width:auto;height:auto;background:none;border-radius:0;display:block;margin-bottom:var(--space-4);font-variant-numeric:tabular-nums}
.steps__item h3{margin-bottom:var(--space-2)}

/* ────────────────────────────────────────────────────────────────────────────────────────
   8 · TESTIMONIAL — frosted cards / case carousel with lilac stat pill
   ──────────────────────────────────────────────────────────────────────────────────────── */
.tm__card{border-radius:var(--r-xl);padding:clamp(1.5rem,2.6vw,2.1rem);
  background:color-mix(in srgb,var(--surface) 80%,transparent);backdrop-filter:var(--frost);-webkit-backdrop-filter:var(--frost);border:1px solid var(--glass-brd)}
.tm__quote{font-size:1.15rem;line-height:1.5}
.tm--case .tm__case{border-radius:var(--r-xl);background:color-mix(in srgb,var(--surface) 82%,transparent);backdrop-filter:var(--frost);-webkit-backdrop-filter:var(--frost);border:1px solid var(--glass-brd)}
.tm__statPill,.tm__play{background:var(--accent);color:var(--accent-ink)}
.tm__caseQuote{font-family:var(--fd);font-weight:600;letter-spacing:-.02em}
.tm__avatar{border-radius:50%}

/* ────────────────────────────────────────────────────────────────────────────────────────
   9 · PRICING — frosted plan cards, the popular one lifted on a lilac wash
   ──────────────────────────────────────────────────────────────────────────────────────── */
.pr__grid{gap:clamp(1rem,2vw,1.4rem)}
.pr__card{border-radius:var(--r-xl);padding:clamp(1.6rem,2.8vw,2.2rem);
  background:color-mix(in srgb,var(--surface) 80%,transparent);backdrop-filter:var(--frost);-webkit-backdrop-filter:var(--frost);border:1px solid var(--glass-brd)}
.pr__card--pop{background:color-mix(in srgb,var(--accent) 12%,var(--surface));border-color:color-mix(in srgb,var(--accent) 40%,transparent);transform:translateY(-8px)}
.pr__badge{background:var(--accent);color:var(--accent-ink);border-radius:var(--r-pill);padding:.24rem .7rem;font-weight:600}
.pr__amt{font-family:var(--fd);font-weight:800;font-size:clamp(2.2rem,4vw,3rem);letter-spacing:-.03em}
.pr__feats{display:grid;gap:.6rem;margin-block:var(--space-5)}
.pr__feats li{padding-left:1.6rem;position:relative;color:var(--ink-soft)}
.pr__feats li::before{content:"";position:absolute;left:0;top:.5em;width:9px;height:9px;border-radius:50%;background:var(--accent)}

/* ────────────────────────────────────────────────────────────────────────────────────────
   10 · FAQ — frosted accordion rows, lilac plus toggles
   ──────────────────────────────────────────────────────────────────────────────────────── */
.faq__h{margin-bottom:clamp(1.4rem,3vw,2.4rem)}
.faq__item{border-radius:var(--r-lg);margin-bottom:.7rem;padding:.3rem clamp(1rem,2vw,1.5rem);
  background:color-mix(in srgb,var(--surface) 70%,transparent);backdrop-filter:var(--frost);-webkit-backdrop-filter:var(--frost);border:1px solid var(--glass-brd)}
.faq__q{font-family:var(--fd);font-weight:600;padding-block:1.1rem;display:flex;justify-content:space-between;gap:1rem;align-items:center}
.faq__icon{color:var(--accent)}
.faq__a{overflow:hidden}
.faq__a p{padding-bottom:1.1rem}

/* ────────────────────────────────────────────────────────────────────────────────────────
   11 · CONTACT-FORM — a single frosted panel
   ──────────────────────────────────────────────────────────────────────────────────────── */
.cf__wrap{max-width:52rem;margin-inline:auto;padding:clamp(1.6rem,3.4vw,3rem);border-radius:var(--r-xl);
  background:color-mix(in srgb,var(--surface) 80%,transparent);backdrop-filter:var(--frost);-webkit-backdrop-filter:var(--frost);border:1px solid var(--glass-brd)}
.cf__field span{font-weight:500;font-size:.9rem;color:var(--ink-soft)}
.cf__field input,.cf__field textarea{width:100%;margin-top:.4rem;padding:.85rem 1rem;border-radius:var(--r-md);
  background:var(--bg);border:1px solid var(--border);color:var(--ink);font:inherit;resize:none}
.cf__row{display:grid;gap:var(--space-4)}
@media(min-width:640px){.cf__row{grid-template-columns:1fr 1fr}}
.cf__form{display:grid;gap:var(--space-4)}

/* ────────────────────────────────────────────────────────────────────────────────────────
   12 · CARD-GRID — horizontal frosted rail (bleeds off the edges via base .cg--rail)
   ──────────────────────────────────────────────────────────────────────────────────────── */
.cg__tabs{display:flex;gap:.5rem;flex-wrap:wrap;justify-content:flex-start;margin-bottom:var(--space-5)}
.cg__tab{border-radius:var(--r-pill);padding:.5rem 1rem;border:1px solid var(--glass-brd);background:transparent;color:var(--ink-soft);font-weight:500}
.cg__tab[aria-pressed="true"]{background:var(--accent);color:var(--accent-ink);border-color:transparent}
.cg__card{border-radius:var(--r-xl);overflow:hidden;padding:0 0 clamp(1rem,2vw,1.4rem);
  background:color-mix(in srgb,var(--surface) 82%,transparent);backdrop-filter:var(--frost);-webkit-backdrop-filter:var(--frost);border:1px solid var(--glass-brd)}
.cg__media{border-radius:0;margin:0 0 var(--space-4);aspect-ratio:4/3}
.cg__top,.cg__title,.cg__role,.cg__link{padding-inline:clamp(1rem,2vw,1.4rem)}
.cg__tag{color:var(--accent)}
.cg__link{color:var(--accent);font-weight:600}

/* ────────────────────────────────────────────────────────────────────────────────────────
   13 · INDEX-TILES — numbered rounded photo tiles
   ──────────────────────────────────────────────────────────────────────────────────────── */
.it__tile{border-radius:var(--r-xl);overflow:hidden;position:relative}
.it__media{aspect-ratio:4/5;border-radius:var(--r-xl)}
.it__num{font-family:var(--fd);font-weight:800;color:var(--accent)}
.it__body{padding-top:var(--space-4)}

/* ────────────────────────────────────────────────────────────────────────────────────────
   14 · CTA — a big frosted lilac panel
   ──────────────────────────────────────────────────────────────────────────────────────── */
.cta__panel{border-radius:var(--r-xl);padding:clamp(2rem,5vw,4rem);align-items:center;color:var(--ink);
  background:linear-gradient(135deg,color-mix(in srgb,var(--accent) 20%,var(--surface)),var(--surface));
  background-color:var(--surface);border:1px solid var(--glass-brd);box-shadow:0 40px 90px -50px color-mix(in srgb,var(--accent) 60%,transparent)}
.cta__title{font-size:clamp(1.8rem,3.6vw,2.8rem);color:var(--ink)}
.cta__sub{color:var(--ink-soft);opacity:1}
.cta__btn{background:var(--accent);color:var(--accent-ink)}
/* CTA sits just above the footer — a small breathing gap, then the dark footer starts flush (no big seam) */
main>.cta:last-child{padding-bottom:clamp(1.6rem,4vw,2.6rem)}
/* the footer element itself is DARK + zero padding/border → the dark panel reaches the very bottom
   (no light strip below it), and connects flush to the CTA above. */
body>footer{padding:0;margin:0;border:0;background-color:#08090F}
/* card-rail prev/next arrows → round */
.cg__nav{border-radius:var(--r-pill);border:1px solid var(--glass-brd);background:color-mix(in srgb,var(--surface) 60%,transparent);color:var(--ink);backdrop-filter:var(--frost);-webkit-backdrop-filter:var(--frost)}
.cg__nav:hover{border-color:var(--accent);color:var(--accent)}
.cta__panel{box-shadow:0 24px 60px -44px color-mix(in srgb,var(--accent) 55%,transparent)}

/* ────────────────────────────────────────────────────────────────────────────────────────
   15 · FOOTER — panel variant styling handled in SECTION_CSS_X; skin sets the dark tone + card
   ──────────────────────────────────────────────────────────────────────────────────────── */
.ft__h{color:var(--ink-soft);text-transform:uppercase;letter-spacing:.14em;font-size:.8rem;font-weight:600}
.ft__cols a{color:var(--ink);font-family:var(--fd);font-weight:500;font-size:1.05rem}
.ft__cols a:hover{color:var(--accent)}
.ft__promo{--ink:#14151C; --ink-soft:#585E70; --accent:#6D4AFF; --accent-ink:#FFFFFF; --border:rgba(20,20,55,.10); --glass-brd:rgba(20,20,55,.10);
  background:#F4F5FA;color:var(--ink)}
.ft__promoEy{color:var(--accent)}
.ft__promoCta{background:#101018;color:#fff}
.ft__bottom .small,.ft__legal a{color:var(--ink-soft)}
.ft__legal a:hover{color:var(--ink)}

/* ────────────────────────────────────────────────────────────────────────────────────────
   Promoted sections that appear in the skinsheet proof — frost them so nothing reads generic
   ──────────────────────────────────────────────────────────────────────────────────────── */
.pin__shot{border-radius:var(--r-xl);border:1px solid var(--glass-brd);box-shadow:0 50px 90px -50px rgba(20,20,60,.55)}
.pin__intro .lead{color:var(--ink-soft)}
/* pinned-split SLIDE (daily loop) — frosted image card + big side heading / muted description */
.pins__shot{border:1px solid var(--glass-brd);box-shadow:0 50px 100px -50px rgba(20,20,60,.55)}
.pins__title{font-size:clamp(1.45rem,2.4vw,2.1rem);letter-spacing:-.02em;line-height:1.12}
.pins__left .eyebrow{color:var(--accent);margin-bottom:var(--space-3)}
.pins__desc .lead{color:var(--ink-soft);font-size:clamp(1rem,1.2vw,1.15rem);line-height:1.5}
/* mosaic wall — BIGGER images, SMALLER gaps (a tight full-bleed gallery wall) */
/* mosaic wall — bigger images, equal small gaps (--mos-gap), rounded media, drag hint styled */
.mos{--mos-gap:clamp(.45rem,.9vw,.75rem)}
.mos__card{width:clamp(300px,34vw,460px)}
.mos__media{border-radius:var(--r-lg)}
.mos__hint{color:var(--ink-soft)}
.mos__title{font-size:1.05rem}
/* team — big cards; SQUARE sharp image (no radius) by default, fills the card on hover (lifts with a soft shadow) */
.team__card{border-radius:0}
.team__card:hover,.team__card:focus-within{box-shadow:var(--shadow-lifted,0 30px 60px -24px rgba(8,9,20,.4))}
.team__name{font-family:var(--fd)}
.ss__card,.sticky__card{border-radius:var(--r-xl);border:1px solid var(--glass-brd)}
/* every card tilts toward the cursor on hover (motion runtime drives the transform on [data-tilt]) */
[data-tilt]{transition:transform .3s var(--mo-ease,cubic-bezier(.2,.8,.2,1));transform-style:preserve-3d;will-change:transform}
`,
  /* 2 · HERO markup — the signature block */
  heroHTML({title='', lead='', dots=[], ctas=[]}={}){
    const btns = ctas.map((c,i)=>`<a class="btn ${i===0?'btn-primary':'btn-ghost'}" href="${c.href}">${c.label}</a>`).join('');
    const photos=['calm minimal workspace desk plant soft morning light','phone app screen minimal ui','smiling person portrait natural window light','open notebook coffee flatlay warm','soft abstract gradient blur lilac','city window daylight interior'];
    const depths=[0.55,0.30,0.72,0.44,0.24,0.60];
    const chips=photos.map((p,i)=>`<div class="hs__chip hs__c${i+1} media" data-depth="${depths[i]}" data-photo="${p}" aria-hidden="true"></div>`).join('');
    // The grid now lives on every .section::before (see MOUSE-LIT GRID) — no separate layer needed.
    // pointer-parallax on the SECTION so moving over the TEXT also drifts the images.
    return `<section class="section hero hero--scatter" data-section="hero" data-variant="scatter" data-signature="frosted-scatter-hero" data-motion="pointer-parallax">
      <div class="hs__scene" aria-hidden="true">${chips}</div>
      <div class="container hero__inner">
        ${dots.length?`<p class="eyebrow" data-motion="reveal-fade">${dots.join('&nbsp;&nbsp;·&nbsp;&nbsp;')}</p>`:''}
        <h1 class="display hero__title" data-motion="reveal-up">${title}</h1>
        ${lead?`<p class="lead hero__lead" data-motion="line-reveal">${lead}</p>`:''}
        ${btns?`<div class="hero__cta" data-motion="reveal-up">${btns}</div>`:''}
      </div>
    </section>`;
  }
};
