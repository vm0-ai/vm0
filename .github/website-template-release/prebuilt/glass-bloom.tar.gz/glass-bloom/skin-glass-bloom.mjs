/* skin-glass-bloom.mjs — a Website Studio skin (skin-contract.md).
 * LEARNED FROM: a voice-first day-planner consumer site (withnovu.com). Re-expressed, not copied.
 * ESSENCE: frosted-glass panels floating over soft blooming gradient light · SUPER-large radii ·
 * an elegant Fraunces serif whose accent words go true-italic, interleaved with a tight Inter sans ·
 * a single lime "pop" threaded sparingly through highlights · big shadowed cards on horizontal rails ·
 * a full-bleed hero + a full-bleed dark-gradient footer for depth. SIGNATURE: the CENTER-pinned
 * device that cross-fades while text panels alternate left↔right and scroll past it (pinnedSplit).
 *
 * COLOUR NOTE (Tong-approved, 2026-07-08): this is a glass/gradient-driven design, so the palette is
 * a HAND-TUNED, dual-mode, contrast-calibrated bespoke set (neutral white / near-black chrome + cool
 * lavender-mint gradient blooms + a lime pop) rather than a catalogue palette — the lime pop + glass
 * washes aren't in the 16. FONTS stay on the system catalogue (`editorial`: Fraunces + Inter), with
 * the italic axis added to carry the serif-italic accent signature.
 */
export const skin = {
  id:'glass-bloom',
  fontsAttr:'glass-bloom', motionAttr:'subtle',
  cardLayout:'rail',
  fontLink:'<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;0,9..144,700;1,9..144,400;1,9..144,500;1,9..144,600&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">',
  signature:'frosted-glass panels over blooming gradient light · super-large radii · Fraunces serif with true-italic accent words interleaved with tight Inter sans · lime pop · center-pinned device that cross-fades while copy alternates left↔right',
  css:`
/* ①②  COLOUR ROLES + fonts + personality levers — dual-mode, contrast-calibrated ---------------- */
:root{
  --bg:#FFFFFF; --ink:#0E1015; --ink-soft:#5C6472;
  --accent:#14161D; --accent-ink:#FFFFFF;            /* near-black chrome (reads as text AND as fill) */
  --support-1:#6D7DF7; --support-2:#B8C1F6;
  --surface:#F4F5FA; --surface-2:#ECEEF7; --border:#E6E8F2; --ring:#6D7DF7;
  /* materials */
  --pop:#C9F24C; --pop-ink:#161A00;                  /* the ONE lime pop (decorative fill only) */
  --glass:rgba(255,255,255,.58); --glass-2:rgba(255,255,255,.74); --glass-brd:rgba(255,255,255,.75);
  --nav-glass:rgba(255,255,255,.62); --nav-brd:rgba(120,132,164,.28);   /* light-tone Apple frost (over white) */
  --nav-glass-dark:rgba(14,18,30,.42); --nav-brd-dark:rgba(255,255,255,.18);   /* dark-tone frost (over dark sections) */
  --bloom-a:rgba(109,125,247,.16); --bloom-b:rgba(96,206,176,.14); --bloom-c:rgba(201,242,76,.14);
  --shadow-soft:0 8px 30px -16px rgba(20,28,60,.28); --shadow-lifted:0 34px 74px -34px rgba(24,32,68,.42);
  /* fonts (system catalogue: editorial) + levers */
  --fd:'Fraunces'; --fb:'Inter';
  /* smaller paragraph type (Tong, 2026-07-08): lead + body a notch down; both stay ≥16px (TYPE-FLOOR) */
  --t-lead:clamp(1rem,1.25vw,1.15rem); --t-body:1rem;
  --radius:15px; --r-card:30px; --r-hero:clamp(30px,4.6vw,58px); --container:1180px;
}
html[data-theme="dark"]{
  --bg:#0A0C12; --ink:#EEF0F8; --ink-soft:#99A1B5;
  --accent:#EEF0F8; --accent-ink:#0A0C12;
  --support-1:#8A9BFF; --support-2:#33405F;
  --surface:#12151E; --surface-2:#1A1E2A; --border:#262B3A; --ring:#8A9BFF;
  --pop:#C9F24C; --pop-ink:#161A00;
  --glass:rgba(20,24,36,.55); --glass-2:rgba(26,30,44,.72); --glass-brd:rgba(255,255,255,.09);
  --nav-glass:rgba(18,22,34,.5); --nav-brd:rgba(255,255,255,.14);
  --bloom-a:rgba(120,138,255,.18); --bloom-b:rgba(78,196,168,.13); --bloom-c:rgba(201,242,76,.10);
  --shadow-soft:0 8px 30px -16px rgba(0,0,0,.6); --shadow-lifted:0 34px 74px -34px rgba(0,0,0,.75);
}
html{scroll-padding-top:96px}
body{background:var(--bg)}   /* plain ground — the gradient blooms were removed (Tong, 2026-07-08) */

/* shared type — serif display + tight Inter sans, interleaved. Accent word = <em> → true italic. */
.display,h1,.h1,h2,.h2{font-family:var(--fd);font-weight:520;letter-spacing:-.018em}
.display{font-weight:440}
h3,.h3{font-family:var(--fb);font-weight:700;letter-spacing:-.02em}
.display em,h1 em,h2 em,.h2 em,.h3 em,.hero__title em{font-style:italic;font-weight:400;font-family:var(--fd)}
.lead{color:var(--ink-soft)}
.eyebrow{font-family:var(--fb);font-weight:600;font-size:.74rem;letter-spacing:.18em;color:var(--ink-soft)}
.sec-head{max-width:56ch}
.sec-head .h2{font-size:clamp(1.9rem,3.6vw,2.9rem)}

/* buttons — pill chrome + a glass variant + the lime pop */
.btn{border-radius:var(--r-pill);font-family:var(--fb);font-weight:600;padding:.8rem 1.4rem}
.btn-primary{background:var(--accent);color:var(--accent-ink);box-shadow:var(--shadow-soft)}
.btn-ghost{background:transparent;color:var(--ink);border-color:var(--border)}
.btn-glass{background:var(--glass-2);color:var(--ink);border:1px solid var(--glass-brd);
  backdrop-filter:blur(16px) saturate(1.4);-webkit-backdrop-filter:blur(16px) saturate(1.4)}
.btn-pop{background:var(--pop);color:var(--pop-ink);border:0}
.btn:hover{transform:translateY(-2px)}

/* a reusable frosted panel */
.glass{background:var(--glass);border:1px solid var(--glass-brd);border-radius:var(--r-card);
  backdrop-filter:blur(20px) saturate(1.5);-webkit-backdrop-filter:blur(20px) saturate(1.5);box-shadow:var(--shadow-soft)}

/* dark-ground moment (privacy-card depth): black → olive-lime gradient, its own rounded slab */
[data-ground="dark"]{--bg:#0B0D0A;--ink:#F3F5EC;--ink-soft:#AAB29A;--surface:#141712;--border:#2A2E22;
  --accent:#F3F5EC;--accent-ink:#0B0D0A;
  background:radial-gradient(80% 120% at 88% 30%, rgba(201,242,76,.16), transparent 60%),
    linear-gradient(155deg,#0B0D0A 30%, #14170E 100%);
  background-color:#0B0D0A;
  color:#F3F5EC;border-radius:var(--r-hero);margin-inline:var(--gutter);
  box-shadow:var(--shadow-lifted);overflow:hidden}
[data-ground="dark"] .lead,[data-ground="dark"] .muted{color:#AAB29A}

/* ③  FULL RESTYLE — every section in the glass-bloom character ------------------------------------ */

/* 1 · NAV — a circular logo placeholder + links + CTA + toggle, ALL inside ONE content-hugging,
   CENTRED Apple-style glass pill (the logo sits INSIDE the pill, on the left). Hides on scroll-down,
   returns on scroll-up (NAV_JS data-hide). */
.nav{position:fixed;top:0;left:0;right:0;z-index:100;background:transparent;border:0;transition:transform .35s ease}
.nav[data-hide="true"]{transform:translateY(-150%)}
.nav__bar{margin-top:16px}
/* the logo = a lime circle w/ the brand initial — visible over the hero AND white content */
.nav__brand{flex:none;width:42px;height:42px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;
  text-decoration:none;background:var(--pop);color:var(--pop-ink)}
.nav__wordmark{display:none}
.nav__brand::before{content:attr(data-initial);font-family:var(--fd);font-weight:700;font-size:1.12rem;line-height:1}
.nav__links a{font-family:var(--fb);font-weight:500;font-size:.86rem;color:var(--ink)}
.nav__links a:hover{color:var(--accent)}
.nav__cta{font-size:.82rem;padding:.5rem 1rem;border-radius:var(--r-pill)}
.theme-toggle{border-radius:var(--r-pill);background:transparent;border-color:transparent;min-width:40px;min-height:40px;padding:.4rem .6rem}
@media(min-width:768px){
  /* the whole bar IS the Apple-style glass pill — hugging its content, centred; logo is its first item.
     Apple glass = opaque-ish frost + strong blur/saturation + a top inner highlight + a soft drop shadow. */
  .nav__bar{width:max-content;min-height:0;margin-inline:auto;gap:1.05rem;padding:.4rem .55rem;border-radius:var(--r-pill);
    background:var(--nav-glass);border:1px solid var(--nav-brd);
    box-shadow:inset 0 1px 0 rgba(255,255,255,.65), 0 10px 30px -12px rgba(20,28,60,.3);
    backdrop-filter:blur(26px) saturate(1.9);-webkit-backdrop-filter:blur(26px) saturate(1.9)}
  .nav__menu{display:flex;align-items:center;gap:1.05rem}
  .nav__links{gap:1.4rem}
}
/* AUTO light/dark header — NAV_JS sets data-tone from the section behind the nav. Over a DARK section
   the pill flips to a dark frost + light text; over white it stays light. Smooth cross-fade. */
.nav__bar,.nav__links a,.theme-toggle,.nav__cta{transition:background-color .3s ease,border-color .3s ease,color .3s ease,box-shadow .3s ease}
@media(min-width:768px){
  .nav[data-tone="dark"] .nav__bar{background:var(--nav-glass-dark);border-color:var(--nav-brd-dark);
    box-shadow:inset 0 1px 0 rgba(255,255,255,.16), 0 12px 34px -14px rgba(0,0,0,.55)}
}
.nav[data-tone="dark"] .nav__links a{color:rgba(255,255,255,.92)}
.nav[data-tone="dark"] .nav__links a:hover{color:var(--pop)}
.nav[data-tone="dark"] .theme-toggle{color:#fff;border-color:transparent}
.nav[data-tone="dark"] .nav__cta{background:#fff;color:#0E1015}

/* 2 · HERO — taller full-bleed image + dark scrim + BOTTOM-aligned serif title + a big rounded lip */
.hero{position:relative;min-height:100svh;display:grid;align-items:end;justify-items:center;overflow:hidden;
  background:#0B1020;color:#fff;padding:clamp(7rem,17vh,12rem) var(--gutter) clamp(8rem,17vh,12rem);isolation:isolate}
.hero__media{position:absolute;inset:0;width:100%;height:100%;border:0;border-radius:0;aspect-ratio:auto;z-index:0}
.hero__media>img{width:100%;height:100%;object-fit:cover}
.hero__scrim{position:absolute;inset:0;z-index:1;
  background:linear-gradient(180deg,rgba(8,12,28,.42) 0%,rgba(8,12,28,.28) 42%,rgba(8,12,28,.6) 100%)}
.hero__inner{position:relative;z-index:2;max-width:60rem;text-align:center;margin-inline:auto}
.hero__kicker{font-family:var(--fb);font-weight:600;font-size:.8rem;letter-spacing:.2em;text-transform:uppercase;
  color:rgba(255,255,255,.86);margin-bottom:var(--space-5);display:inline-flex;gap:.6rem;align-items:center}
.hero__kicker::before{content:"";width:9px;height:9px;border-radius:50%;background:var(--pop)}
.hero__title{font-family:var(--fd);font-weight:430;font-size:clamp(2.7rem,7.4vw,5.4rem);line-height:1.02;
  letter-spacing:-.022em;color:#fff}
.hero__lead{margin:var(--space-5) auto 0;max-width:56ch;font-size:var(--t-lead);color:rgba(255,255,255,.92)}
.hero__cta{display:flex;gap:var(--space-3);justify-content:center;margin-top:var(--space-7);flex-wrap:wrap}
.hero__lip{position:absolute;left:0;right:0;bottom:-1px;height:clamp(38px,6vw,72px);background:var(--bg);
  border-radius:var(--r-hero) var(--r-hero) 0 0;z-index:3}

/* 3 · FEATURE-SPLIT — glass panel rows, oversized media radius, alternating */
.fs__heading{font-family:var(--fd)}
.fs__row{gap:clamp(2rem,5vw,4rem)}
.fs__text .h2{font-family:var(--fb);font-weight:700;letter-spacing:-.02em}
.fs__icon{border:0;background:var(--pop);color:var(--pop-ink);border-radius:16px}
.fs .media{border:1px solid var(--glass-brd);border-radius:var(--r-card);box-shadow:var(--shadow-lifted);aspect-ratio:4/3}

/* 4 · FEATURE-GRID — frosted cards, big radius, soft lift */
.fg__card{background:var(--glass);border:1px solid var(--glass-brd);border-radius:var(--r-card);
  padding:clamp(1.5rem,2.4vw,2.1rem);box-shadow:var(--shadow-soft);
  backdrop-filter:blur(18px) saturate(1.4);-webkit-backdrop-filter:blur(18px) saturate(1.4);
  transition:transform .3s var(--mo-ease),box-shadow .3s var(--mo-ease)}
.fg__card:hover{transform:translateY(-6px);box-shadow:var(--shadow-lifted)}
.fg__icon{border:0;background:var(--surface-2);color:var(--ink);border-radius:14px}
.fg--bento .fg__card:nth-child(6n+1){background:var(--glass-2)}

/* 5 · LOGOS — TALL soft-gray rectangles (same logo text size, more padding → taller frame), tight
   gaps, full-bleed off the screen edges; sits cleanly BELOW the hero lip (not pressed on its corner). */
.logos--wall{padding-block:clamp(1rem,2.4vw,1.8rem) clamp(2.6rem,5vw,4rem);margin-top:0}
.logos__item{font-family:var(--fd);font-weight:600;color:var(--ink-soft);opacity:1;
  background:var(--surface-2);border:1px solid var(--border);border-radius:16px;
  padding:1.75rem 3rem;font-size:1.18rem;display:inline-flex;align-items:center;line-height:1}
.logos--wall .logos__marquee{padding-block:0}
.logos__marquee .mo-track{gap:.75rem}   /* tighter spacing between logos */

/* 6 · STATS — big serif numerals with a lime tick, no accent-as-text risk */
.stats__grid{gap:var(--space-7)}
.stats__cell{position:relative;padding-top:var(--space-4)}
.stats__cell::before{content:"";position:absolute;top:0;left:50%;transform:translateX(-50%);width:34px;height:4px;border-radius:2px;background:var(--pop)}
.stats__num{font-family:var(--fd);font-weight:560;color:var(--ink);font-size:clamp(2.4rem,5.4vw,3.8rem);letter-spacing:-.02em}

/* 7 · STEPS — lime numbered chips */
.steps__num{background:var(--pop);color:var(--pop-ink)}
.steps__item .h3{font-family:var(--fb)}

/* 8 · TESTIMONIAL — big frosted quote cards with a light hairline stroke + shadow */
.tm__card{background:var(--glass);border:1px solid var(--border);border-radius:var(--r-card);
  padding:clamp(1.6rem,2.6vw,2.2rem);box-shadow:var(--shadow-soft);
  backdrop-filter:blur(18px) saturate(1.4);-webkit-backdrop-filter:blur(18px) saturate(1.4)}
.tm__quote{font-family:var(--fd);font-weight:440;font-size:1.18rem;line-height:1.5}
.tm__quote::before{content:"";display:block;width:26px;height:4px;border-radius:2px;background:var(--pop);margin-bottom:var(--space-4)}
.tm__name{font-family:var(--fb)}
/* marquee overflow:hidden clips shadows → contained shadow + padding that fits it (offset) */
.tm--marquee .tm__card{width:min(420px,84vw);box-shadow:0 14px 30px -14px rgba(24,32,68,.32)}
.tm--marquee .tm__marquee{padding-block:36px;margin-block:-22px}
/* CASE carousel — glass split card with a light hairline stroke */
.tm--case .tm__case{background:var(--glass);border:1px solid var(--border);box-shadow:0 20px 46px -22px rgba(24,32,68,.4)}
.tm__caseQuote{font-family:var(--fd);font-weight:440}
.tm__company{font-family:var(--fd)}
.tm__caseCta{color:var(--ink)}
.tm__caseCta:hover{color:var(--accent)}
.tm--spotlight .tm__quote{font-family:var(--fd);font-weight:440}
.tm--spotlight .tm__quote::before{margin-inline:auto}

/* 9 · PRICING — frosted plan cards; the popular one lifts + a lime badge */
.pr__card{background:var(--glass);border:1px solid var(--glass-brd);border-radius:var(--r-card);
  padding:clamp(1.8rem,3vw,2.4rem);box-shadow:var(--shadow-soft);
  backdrop-filter:blur(18px) saturate(1.4);-webkit-backdrop-filter:blur(18px) saturate(1.4)}
.pr__card--pop{background:var(--glass-2);border-color:var(--pop);box-shadow:var(--shadow-lifted)}
.pr__badge{background:var(--pop);color:var(--pop-ink)}
.pr__amt{font-family:var(--fd);font-weight:560}
.pr__feats li::before{background:var(--pop)}

/* 10 · FAQ — airy list; hairline rows, no boxes */
.faq__h{font-family:var(--fd)}
.faq__item{border-bottom:1px solid var(--border)}
.faq__q{font-family:var(--fb);font-weight:600;font-size:1.08rem;padding-block:var(--space-5)}
.faq__item[open] .faq__icon,.faq__item[data-closing] .faq__icon{color:var(--ink)}

/* 11 · CONTACT — a single frosted card holding the form */
.cf__wrap{background:var(--glass);border:1px solid var(--glass-brd);border-radius:var(--r-hero);
  padding:clamp(1.8rem,4vw,3rem);box-shadow:var(--shadow-soft);
  backdrop-filter:blur(20px) saturate(1.5);-webkit-backdrop-filter:blur(20px) saturate(1.5)}
.cf__field input,.cf__field textarea{background:var(--bg);border-radius:14px;border-color:var(--border)}
.cf__field textarea{resize:none}   /* no manual resize handle */
.cf__form .btn{align-self:flex-start;border-radius:var(--r-pill)}

/* 12 · CARD-GRID — BIG SQUARE cards on a rail; cards ALTERNATE white-bg+text and full-image-bg+text
   (white text sits on a dark scrim + a dark bg-color so it clears AA even before the image loads). */
.cg__tab{border-radius:var(--r-pill)}
.cg__tab[aria-pressed="true"]{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
/* rail overflow clips a big shadow → contained shadow + generous padding (offset). */
.cg__grid.cg--rail{padding-block:56px;margin-block:-40px}
.cg--rail>.cg__card{flex-basis:clamp(320px,88vw,470px)}      /* bigger square cards */
.cg__card{position:relative;aspect-ratio:1/1;overflow:hidden;border-radius:var(--r-card);padding:0;
  display:flex;flex-direction:column;border:1px solid var(--glass-brd);
  box-shadow:0 16px 34px -16px rgba(24,32,68,.34);transition:transform .3s var(--mo-ease),box-shadow .3s var(--mo-ease)}
.cg--rail>.cg__card:hover{transform:translateY(-6px);box-shadow:0 24px 44px -18px rgba(24,32,68,.44)}
.cg__tag{border-radius:var(--r-pill)}
/* SHARED layout so BOTH card types match: text block TOP-aligned + tight; the CTA pinned to the BOTTOM */
.cg__card .cg__top{padding-inline:clamp(1.3rem,2.6vw,1.8rem)}
.cg__card .cg__title{padding-inline:clamp(1.3rem,2.6vw,1.8rem);margin:.14rem 0 0;line-height:1.15}
.cg__card .cg__role{padding-inline:clamp(1.3rem,2.6vw,1.8rem);margin:.14rem 0 0}
.cg__card .cg__link{margin-top:auto;padding:.7rem clamp(1.3rem,2.6vw,1.8rem) clamp(1.3rem,2.6vw,1.8rem)}
/* WHITE card (odd) — image on top, text top-aligned below, Read at the bottom */
.cg__card:nth-child(odd){background:var(--surface)}
.cg__card:nth-child(odd) .cg__media{position:relative;height:56%;width:100%;aspect-ratio:auto;border-radius:0;margin:0 0 clamp(.9rem,1.8vw,1.2rem);border:0;flex:none}
.cg__card:nth-child(odd) .cg__tag{border-color:var(--border);color:var(--ink-soft)}
.cg__card:nth-child(odd) .cg__link{color:var(--accent)}
/* IMAGE card (even) — media fills; text TOP-aligned over a top scrim, Read at the bottom over a base scrim */
.cg__card:nth-child(even){background-color:#171923;color:#fff}
.cg__card:nth-child(even) .cg__media{position:absolute;inset:0;height:100%;width:100%;aspect-ratio:auto;border-radius:0;margin:0;border:0}
.cg__card:nth-child(even)::after{content:"";position:absolute;inset:0;z-index:0;background:linear-gradient(to bottom,rgba(6,8,16,.82) 0%,rgba(6,8,16,.1) 44%,rgba(6,8,16,.62) 100%)}
.cg__card:nth-child(even) .cg__top{position:relative;z-index:1;padding-top:clamp(1.3rem,2.6vw,1.8rem)}
.cg__card:nth-child(even) .cg__title{position:relative;z-index:1;color:#fff}
.cg__card:nth-child(even) .cg__role{position:relative;z-index:1;color:rgba(255,255,255,.85)}
.cg__card:nth-child(even) .cg__tag{color:#fff;border-color:rgba(255,255,255,.55)}
.cg__card:nth-child(even) .cg__link{position:relative;z-index:1;color:#fff}
/* circular prev/next buttons on the rail */
.cg__nav{border-radius:50%;border:1px solid var(--nav-brd);background:var(--glass-2);color:var(--ink);
  box-shadow:var(--shadow-soft);backdrop-filter:blur(14px) saturate(1.4);-webkit-backdrop-filter:blur(14px) saturate(1.4);transition:border-color .18s,color .18s}
.cg__nav:hover{border-color:var(--accent);color:var(--accent)}

/* 13 · INDEX-TILES — extra-round photo tiles */
.it__tile{border-radius:var(--r-card);box-shadow:var(--shadow-soft)}
.it__num{font-family:var(--fd);font-weight:520}

/* 14 · CTA — dark-gradient band (inset by the system gutter — never full-bleed) with a lime button */
.cta__panel{background:radial-gradient(80% 130% at 84% 20%, rgba(201,242,76,.16), transparent 58%),
    linear-gradient(150deg,#0B1020 20%, #141A2C 100%);
  background-color:#0B1020;
  color:#fff;border-radius:var(--r-hero);padding:clamp(2.4rem,5vw,4rem);box-shadow:var(--shadow-lifted)}
.cta__title{font-family:var(--fd);font-weight:460;color:#fff}
.cta__sub{color:rgba(255,255,255,.85)}
.cta__btn{background:var(--pop);color:var(--pop-ink);border-radius:var(--r-pill);border:0}

/* 15 · FOOTER — default frosted band, OR (bgPhoto) a FULL-VIEWPORT closing image: statement centred,
   link columns sitting low, copyright pinned to the bottom edge, dark gradient grounding the base. */
footer{background:var(--surface);border-top:1px solid var(--border);border-radius:var(--r-hero) var(--r-hero) 0 0;margin-top:var(--space-8)}
.ft__name{font-family:var(--fd);font-weight:600;font-size:1.35rem}
/* cover footer */
footer:has(.ftx){background:transparent;border:0;border-radius:0;margin:0;padding:0}
.ftx{position:relative;min-height:100svh;background-color:#0B1020;color:#fff;overflow:hidden;isolation:isolate}
.ft__bg{position:absolute;inset:0;z-index:0;width:100%;height:100%;border:0;border-radius:0;aspect-ratio:auto;margin:0}
.ft__bg>img{width:100%;height:100%;object-fit:cover}
.ft__scrim{position:absolute;inset:0;z-index:1;background:linear-gradient(180deg,rgba(8,12,26,.30) 0%,rgba(8,12,26,.08) 32%,rgba(8,12,26,.52) 70%,rgba(8,12,26,.9) 100%)}
.ft__cover{position:relative;z-index:2;min-height:100svh;display:grid;grid-template-rows:1fr auto;
  padding-block:clamp(6rem,12vh,9rem) clamp(1.4rem,3vh,2.2rem)}
.ft__statement{align-self:center;text-align:center;max-width:60rem;margin-inline:auto}
.ft__eyebrow{color:#fff;opacity:.85;margin-bottom:var(--space-4)}
.ft__stTitle{font-family:var(--fd);font-weight:440;color:#fff;font-size:clamp(2.6rem,6.4vw,4.8rem);line-height:1.02;letter-spacing:-.022em}
.ft__stTitle em{font-style:italic}
.ft__stSub{color:rgba(255,255,255,.92);margin:var(--space-5) auto 0;max-width:42ch}
.ft__stCta.btn{margin-top:clamp(2.2rem,4.5vh,3.4rem);background:var(--pop);color:var(--pop-ink);border:0;border-radius:var(--r-pill);padding:.95rem 1.8rem;font-size:1.02rem}
.ft__lower{align-self:end}
footer:has(.ftx) .ft__grid{margin-inline:auto;margin-block:0 clamp(1.8rem,4vh,2.6rem)}
footer:has(.ftx) .ft__h,footer:has(.ftx) .ft__name{color:#fff;font-family:var(--fd)}
footer:has(.ftx) .ft__brand .small,footer:has(.ftx) .ft__col a{color:rgba(255,255,255,.84)}
footer:has(.ftx) .ft__col a:hover{color:#fff}
footer:has(.ftx) .ft__bottom{margin-inline:auto;margin-block:0;border-top:1px solid rgba(255,255,255,.18);padding-top:var(--space-4);color:rgba(255,255,255,.72)}
footer:has(.ftx) .ft__bottom .small{color:rgba(255,255,255,.72)}
footer:has(.ftx) .theme-toggle{color:#fff;border-color:rgba(255,255,255,.42)}

/* promoted signatures the skinsheet exercises ---------------------------------------------------- */
/* pinnedSplit — the crown signature */
.pin__intro .h2{font-family:var(--fd)}
.pin__device{width:min(300px,74vw);filter:drop-shadow(0 40px 70px rgba(20,28,60,.35))}
.pin__shot{border-radius:38px;border:1px solid var(--glass-brd);aspect-ratio:1/2;
  box-shadow:0 0 0 8px rgba(255,255,255,.06), var(--shadow-lifted)}
.pin__eyebrow{color:var(--ink-soft)}
.pin__title{font-family:var(--fb);font-weight:700;font-size:clamp(1.8rem,3.4vw,2.7rem);letter-spacing:-.022em}
.pin__title em{font-family:var(--fd);font-style:italic;font-weight:440}
.pin__text{max-width:34ch}
/* stickyScroll (horizontal) — frosted cards, big radius */
.ssh__title{font-family:var(--fb)}
.ssh__heading{font-family:var(--fd)}
.ssh__media{border-radius:var(--r-card);box-shadow:var(--shadow-soft);border:1px solid var(--glass-brd)}
.ssh__tab.is-active{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
.ssh__arrow{border-color:var(--border)}
/* mosaicScroll — rounded image cards, a lime tag */
.mos__media{border-radius:var(--r-card);box-shadow:var(--shadow-soft)}
.mos__title{font-family:var(--fb)}
.mos__tag{color:var(--ink-soft)}

/* scroll-statement — the full-bleed image + dark-gradient "footer moment" (withnovu closing band) */
.sst__eyebrow{color:#fff}
.sst__quote{font-family:var(--fd);font-weight:440}
.sst__quote em{font-style:italic}
.sst::before{background:linear-gradient(180deg,rgba(8,12,26,.35) 0%,rgba(8,12,26,.28) 40%,rgba(8,12,26,.72) 100%)}
.sst__cta.btn{background:var(--pop);color:var(--pop-ink);border:0;border-radius:var(--r-pill)}

/* material a11y — degrade glass to a solid surface when the user reduces transparency */
@media (prefers-reduced-transparency:reduce){
  .nav__bar,.glass,.btn-glass,.fg__card,.tm__card,.pr__card,.cg__card,.cf__wrap{
    backdrop-filter:none;-webkit-backdrop-filter:none;background:var(--surface)}
}
`,
  /* 2 · HERO — the signature glass hero. Full-bleed image + scrim + BOTTOM-aligned serif title +
     rounded lip. No buttons (per the source; conversion lives in pricing + the closing footer band). */
  heroHTML({wordmark='', title='', lead='', dots=[], photo=''}={}){
    return `<section class="hero" data-section="hero" data-variant="cover" data-signature="glass-hero">
      <div class="hero__media media" data-media="hero"${photo?` data-photo="${photo}"`:''} role="img" aria-label="Product moment"></div>
      <div class="hero__scrim"></div>
      <div class="hero__inner">
        ${dots.length?`<p class="eyebrow hero__kicker">${dots.join(' · ')}</p>`:''}
        <h1 class="display hero__title">${title||wordmark}</h1>
        ${lead?`<p class="lead hero__lead">${lead}</p>`:''}
      </div>
      <div class="hero__lip"></div>
    </section>`;
  }
};
