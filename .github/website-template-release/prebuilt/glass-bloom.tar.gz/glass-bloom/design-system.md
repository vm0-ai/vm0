# Glass Bloom — design system

Measured from the local `template.css` and `index.html`. These are facts about
the shipped stylesheet, not intentions. Where a value here disagrees with prose anywhere else, this
file is right.

## Character

> frosted-glass panels over blooming gradient light · super-large radii · Fraunces serif with true-italic accent words interleaved with tight Inter sans · lime pop · center-pinned device that cross-fades while copy alternates left↔right



## Type

| | |
|---|---|
| Families loaded | `Fraunces` · `Inter` |
| Display face | `—` |
| Body face | `'Inter'` |
| Font personality flag | `data-fonts="glass-bloom"` |

Both faces are declared as tokens, so a brand type change is a two-line edit in
`style[data-brand-theme]` — not a find-and-replace through the stylesheet.

## Colour roles

The stylesheet reads colour only through these roles. Rebinding them in `style[data-brand-theme]`
restyles the whole page; writing a literal colour anywhere else forks it.

| role | light | dark |
|---|---|---|
| `--bg` | #FFFFFF | #0A0C12 |
| `--ink` | #0E1015 | #EEF0F8 |
| `--ink-soft` | #5C6472 | #99A1B5 |
| `--accent` | #14161D | #EEF0F8 |
| `--accent-ink` | #FFFFFF | #0A0C12 |
| `--support-1` | — | #8A9BFF |
| `--support-2` | #B8C1F6 | #33405F |
| `--surface` | #F4F5FA | #12151E |
| `--surface-2` | #ECEEF7 | #1A1E2A |
| `--border` | #E6E8F2 | #262B3A |
| `--ring` | #6D7DF7 | #8A9BFF |

Generate a replacement set with `node tools/palette.mjs --pick <system>`; use `--list` to choose and `--check` to audit bespoke values.
The values above are the reference page's own palette; they are a demonstration, not a requirement.

## Structural tokens

| token | value |
|---|---|
| `--bloom-b` | rgba(96,206,176,.14) |
| `--bloom-c` | rgba(201,242,76,.14) |
| `--container` | 1180px |
| `--fb` | 'Inter' |
| `--fx-aurora-1` | 12s |
| `--fx-aurora-2` | 14s |
| `--fx-aurora-3` | 16s |
| `--fx-aurora-blur` | 90px |
| `--fx-aurora-opacity` | .5 |
| `--fx-grain-opacity` | .085 |
| `--glass-2` | rgba(255,255,255,.74) |
| `--glass-brd` | rgba(255,255,255,.75) |
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |
| `--nav-brd` | rgba(120,132,164,.28) |
| `--nav-brd-dark` | rgba(255,255,255,.18) |
| `--nav-glass` | rgba(255,255,255,.62) |
| `--pop-ink` | #161A00 |
| `--r-card` | 30px |
| `--r-hero` | clamp(30px,4.6vw,58px) |
| `--radius` | 15px |
| `--shadow-lifted` | 0 34px 74px -34px rgba(24,32,68,.42) |
| `--shadow-soft` | 0 8px 30px -16px rgba(20,28,60,.28) |
| `--t-body` | 1rem |

**Spacing scale** — `--space-2`=.5rem · `--space-3`=.75rem · `--space-4`=1rem · `--space-5`=1.5rem · `--space-6`=2rem · `--space-7`=3rem · `--space-8`=4rem · `--space-9`=6rem · `--space-10`=8rem



## Motion

| token | value |
|---|---|
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |

Motion personality: `subtle`. `template.js` binds the reveals, the marquee, the
disclosure widgets, the theme toggle and the mobile nav. Reveals must degrade to visible content —
never hide a whole section behind an IntersectionObserver.

## Device vocabulary

Class prefixes that carry layout in the reference page, by frequency. Compose from these; a class
that is not here has no stylesheet behind it, and inventing one produces an unstyled bare tag.

`.media`×61 · `.mono`×56 · `.small`×45 · `.muted`×41 · `.h3`×29 · `.h2`×25 · `.container`×20 · `.lead`×19 · `.section`×19 · `.btn`×15 · `.body`×13 · `.eyebrow`×10 · `.sec-head`×10 · `.btn-ghost`×10 · `.btn-primary`×3 · `.theme-toggle`×2 · `.fs`×2 · `.fs--rev`×2 · `.ss`×2 · `.ssh`×2 · `.tm`×2 · `.skip`×1 · `.nav`×1 · `.theme-toggle--nav`×1 · `.hero`×1 · `.display`×1 · `.logos`×1 · `.logos--wall`×1 · `.fg`×1 · `.fg--cards`×1 · `.pin`×1 · `.pin--phone`×1 · `.mos`×1 · `.fs--even`×1

## Reference density

The reference page carries **1663 visible words** across its sections. That is a description
of this example, not a target. Say what the brief supports and stop — a page padded to reach a
word count reads like one, and the reader can tell.
