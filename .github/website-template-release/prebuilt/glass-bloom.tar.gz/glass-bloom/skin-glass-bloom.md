# glass-bloom — skin spec

**Essence.** Frosted-glass panels floating over soft blooming gradient light, with **super-large
radii**, an **elegant Fraunces serif whose accent words go true-italic** interleaved with a tight
Inter sans, a single **lime "pop"** threaded sparingly through highlights, **big shadowed cards on
horizontal rails**, and a **full-bleed hero + full-bleed dark-gradient closing band** for depth.

**Learned from** a voice-first day-planner consumer site (withnovu.com) — re-expressed, not copied
(original brand/copy/imagery; the language only).

## Signature
The **`pinnedSplit`** section (promoted to the core library): a **CENTER device stays pinned** in the
viewport and **cross-fades between frames** while text panels **alternate left ↔ right** and scroll
up past it. Plus: the frosted floating nav pill, the rounded white hero "lip", and the serif-italic
accent-word type move.

## Lever re-map
| Lever | Choice |
|-------|--------|
| Palette | **bespoke, dual-mode, contrast-calibrated** (Tong-approved for this glass/gradient design): pure white / near-black chrome + cool lavender-mint gradient blooms + a lime pop. Not a catalogue palette — the lime pop + glass washes aren't in the 16. |
| Accent discipline | `--accent` is a **near-black** (reads as text AND as fill → all accent-text passes AA automatically); the lime `--pop` is a **decorative fill only** (steps chips, badges, ticks, buttons — always with dark ink), never small text on light. |
| Fonts | **system catalogue `editorial`** (Fraunces + Inter), with the **italic axis added** to carry the serif-italic accent signature. Serif for elegant/section titles; Inter (tight, bold) for card/feature/scroll titles; `<em>` → Fraunces italic accent word. |
| Radius | super-large (`--r-card:30px`, `--r-hero:clamp(30–58px)`, pill buttons/nav). |
| Material | frosted glass (`backdrop-filter`) on nav/cards/panels + soft radial gradient "bloom" washes on the page; degrades to solid under `prefers-reduced-transparency`. |
| Motion | `subtle` personality + the bespoke pinned cross-fade + marquee rails. |
| Cards | `cardLayout:'rail'` — big shadowed cards on a horizontal scroll rail. |
| Depth | dark-gradient slab (`[data-ground="dark"]`, black→olive-lime) + a full-bleed image closing band (`scrollStatement`). |

## Gate status
`node build-skinsheet.mjs skin-glass-bloom.mjs` → **PASS** full matrix + `--site` (0 violations).
Real demo page (`build-sona.mjs`) → **PASS** full + `--site` + `--learn` (0 violations).

## Live
- Skinsheet (all 15 sections, gate-verified): https://glass-bloom-sheet-715f6d07-f0e5f351.sites.vm0.io
- Real demo page ("Sona", an original brand): https://glass-bloom-sona-715f6d07-056eacd2.sites.vm0.io

## Tuning pass (Tong, 2026-07-08) — folded into the skin + `sections.mjs`
- **Header:** wordmark pulled OUT of the bar into a standalone frosted **chip on the left**; the links
  + CTA + toggle live in a **content-hugging, centred glass pill**; frost is **lighter + blurrier**
  (`--nav-glass`, blur 30) and nav type is smaller (.86rem). (The wordmark uses a chip, not
  `mix-blend-mode`, because the contrast parser reads a blended colour as white-on-white.)
- **Hero:** taller (`100svh`), content **bottom-aligned**, **buttons removed**, longer lead.
- **Logos:** each mark on its own soft-gray **chip**, marquee preserved.
- **Card rail + testimonial marquee:** the scroll/`overflow:hidden` containers were **clipping the
  card shadows** → added `padding-block` (offset with negative `margin-block`) for shadow room; the
  rail's prev/next buttons are now **circular**.
- **Footer:** new **COVER variant** (`footer({bgPhoto,statement,anchor})`) — a **full-viewport image**
  with the statement centred, link columns sitting low, copyright pinned to the base, and a dark
  gradient grounding it (the withnovu closing band). Folded the closing CTA into it (dropped the
  separate `scrollStatement` from the demo).
- **apply-photos:** **dedupe** the footer photo-credit line (was one entry per slot → a huge repeated
  block) and drop it onto its own small row.
- Gate gotcha: overriding `.container` with `margin:0`/`margin:0 0 …` also zeroes its `margin-inline:auto`
  → the block jumps to left:0 and trips GRID-CONSISTENCY. Use `margin-inline:auto` + `margin-block:…`.

## Tuning pass 2 (Tong, 2026-07-08)
- **Logo:** white, no chip; adaptive via a **nav scroll-state toggle** (`NAV_JS` sets `data-scrolled`
  once the hero passes → wordmark flips white→`--ink`). `mix-blend-mode:difference` is kept as a
  no-op-in-fixed-nav marker so the static contrast gate exempts it (it's white over the hero image the
  parser can't see). — needs `NAV_JS` scroll toggle (system).
- **Logo wall:** RECTANGULAR chips (radius 12px, not pills) + tight top padding (no empty band).
- **Card rail + testimonial marquee:** a scroll/overflow container ALWAYS clips a big shadow → use a
  **CONTAINED shadow** (reach ≤ ~50px: `0 16px 34px -16px`, hover `0 24px 44px -18px`) + rail
  `padding-block:52px;margin-block:-36px`. This is the real fix (padding alone can't hold a 100px hover
  shadow).
- **Contact:** `textarea{resize:none}`.
- **ctaBand padding — FIXED IN SYSTEM (`SECTION_CSS`):** `.cta{padding-inline:var(--gutter)}` +
  `.cta__panel{max-width:var(--container);margin-inline:auto}` so the panel is ALWAYS inset (64px @1280,
  20px @390), never full-bleed. Skins must NOT set `.cta{padding-inline:0}` (that was the recurring bug).
- **Hero:** a warm lifestyle PORTRAIT (footer-style), via a new `heroHTML({photo})` field; trimmed copy.
- **Testimonial → CASE carousel** (promoted): `testimonial({layout:'case'})` — a single-spotlight
  case-study card (media left · company + lime stat pill + big quote + attribution + "Read case study"
  right) with dots + arrows (`TM_JS`). quotes gain `{company,stat:{value,label},photo,cta}`.
- Gate: added a **CONTRAST exemption for `mix-blend-mode` text** in `qa-site.mjs` (blended text
  composites against live pixels → static ratio is meaningless).

## Tuning pass 3 (Tong, 2026-07-08)
- **Nav:** left wordmark → a **circular logo placeholder** (lime mark w/ the brand initial; `nav()` now
  emits `data-initial` + a hidden `.nav__wordmark` + `aria-label`). Pill glass made **Apple-style**:
  more opaque frost (`--nav-glass` .62) + strong blur/saturation + an inset top highlight + soft drop
  shadow, so it reads as glass over white too.
- **Background:** removed the gradient bloom washes → plain `var(--bg)`.
- **Logo wall:** BIGGER rectangles, TIGHTER gaps (`.logos__marquee .mo-track{gap:.75rem}`), and pulled
  UP (`margin-top` negative) so it CONNECTS to the hero (no white band).
- **Card rail → BIG SQUARE cards** that ALTERNATE: odd = white-bg (image top, dark text); even =
  full-image-bg with white text on a dark scrim + a `background-color:#171923` fallback so it clears AA.
- **ROOT-CAUSE FIX (recurring): sliding media rails must BLEED to the BROWSER EDGES, not hard-cut at a
  container/column.** Fixed `stickyScroll` horizontal in `SECTION_CSS`: the viewport spans the FULL
  viewport width; the pinned text is OVERLAID over a `linear-gradient(var(--bg)→transparent)` MASK so
  cards **fade softly** under the text and bleed off both screen edges (no hard vertical cut). This is
  the pattern any full-bleed rail should reuse (the `.cg--rail` bleed formula is the horizontal-scroll
  analog).

## Tuning pass 4 (Tong, 2026-07-08)
- **Nav:** the circular logo now sits INSIDE the pill — the whole `.nav__bar` became the content-hugging,
  centred Apple-glass pill (logo = its first item), instead of a standalone left logo + a separate pill.
- **Header hides on scroll-down, returns on scroll-up** (`NAV_JS` sets `data-hide` by scroll direction;
  skin: `.nav[data-hide="true"]{transform:translateY(-150%)}`).
- **Testimonial cards** (`.tm__card` + `.tm--case .tm__case`) get a light hairline **stroke**
  (`1px solid var(--border)`), not the near-invisible `--glass-brd`.
- **Logo wall:** TALLER chips (more padding, same text size), sits cleanly BELOW the hero lip (removed
  the negative overlap so it's not pressed on the rounded corner), still full-bleed.
- **stickyScroll readability:** the pinned-text gradient MASK now stays SOLID to ~82% (was 68%) over a
  WIDER pin, and the heading is smaller so it wraps inside the solid zone → text no longer sits over a
  see-through image. (`SECTION_CSS`, so every skin inherits it.)

## Tuning pass 5 (Tong, 2026-07-08)
- Header logo: **shadow removed**.
- **Card rail edge-bleed — ROOT-CAUSE fix in `SECTION_CSS`:** `.cg--rail` used `margin-inline:-gutter`
  (reaches only the CONTAINER edge → cards hard-cut at the container margin on screens WIDER than the
  container). Now `width:100vw; margin-inline:calc(50% - 50vw)` (true viewport full-bleed) +
  `padding-inline:max(gutter, (100vw - container)/2)` to keep the first card aligned to the container.
  Verified: at 1600px the rail spans 0→1600, first card at 210. (Same class of bug as the stickyScroll.)
- **Card layout unified:** BOTH card types now = text block TOP-aligned + CTA pinned to the BOTTOM
  (`.cg__link{margin-top:auto}`), tighter inter-line spacing. Previously the image card clustered text at
  the bottom while the white card had a gap → CTAs at different heights. Image-card scrim is now
  dark at TOP (for the top text) AND at the base (for the CTA). Squares scaled up (`clamp(320px,88vw,470px)`).
- **Footer:** dropped the statement eyebrow (small title) + more space above the CTA (less crowded).

## Tuning pass 6 (Tong, 2026-07-08) — two RECURRING bugs root-caused in the SYSTEM
- **"Small title not centred" (recurs across templates):** `foundation.css` had a global
  `p{max-width:68ch}` prose measure. A centred eyebrow is a `<p class="eyebrow">`, and at the tiny
  eyebrow font `68ch` ≈ 530px < the section width, so the label box shrank + left-anchored and
  `text-align:center` centred the text inside that NARROW box (off to the left). Fixed at the source:
  `.eyebrow{max-width:none}` + `p:where(:not(.eyebrow):not(.small):not(.mono)){max-width:68ch}` — label
  paragraphs are exempt from the prose measure. Every template inherits it.
- **"Cards don't appear from the browser edge" (recurs):** the rail/media bleed used
  `margin-inline:-gutter` (CONTAINER-relative → hard-cut at the container margin on wide screens).
  Canonical fix = viewport-relative `width:100vw; margin-inline:calc(50% - 50vw)` (done for `.cg--rail`
  + stickyScroll). Audited: no container-relative bleeds remain in the used sections.

## Tuning pass 7 (Tong, 2026-07-08)
- **Smaller paragraph type:** `--t-lead` (≤~18px) + `--t-body` (16px) overridden in the skin `:root`
  (both stay ≥16px for TYPE-FLOOR).
- **Hero:** bottom padding bumped (`clamp(8rem,17vh,12rem)`) → more space below the bottom-aligned text.
- **AUTO light/dark header (promoted to `NAV_JS`, system):** the fixed nav reads which section sits
  BEHIND it and sets `data-tone="light|dark"`. A section counts as DARK if it is `.hero`, a
  `[data-ground="dark"]` slab, a `.ftx` cover footer, or is explicitly marked `[data-nav-dark]`
  (probe = the nav's vertical centre). The skin styles `.nav[data-tone="dark"]` → dark frost pill
  (`--nav-glass-dark`) + white links + white-filled CTA + white toggle; over white sections it stays the
  light Apple-glass pill with dark text. 300ms cross-fade. Any template inherits the JS; a skin opts in
  by styling `[data-tone="dark"]`. (Verified: dark over hero/privacy/footer, light over white sections.)
- **PENDING:** swap the pill glass for the user's tuned Figma glass (node 34:3) once the Figma connector
  is connected or the Dev-Mode CSS is provided — headless Figma is CDN-blocked (403) and the connector
  is not connected, so the exact values couldn't be read.

## Engine promotion
`pinnedSplit` was promoted into `System Code/sections.mjs` (builder + base CSS in `SECTION_CSS_X` +
`PINNED_JS`), and `build-skinsheet.mjs` / `gen-engine.mjs` were updated to inject `SECTION_CSS_X` +
`PINNED_JS` and to skip the reveal wrapper on pinned/sticky sections. `web-design-system` minor bump.
