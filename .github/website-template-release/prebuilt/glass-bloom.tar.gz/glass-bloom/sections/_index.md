# Section library — glass-bloom

Cut from the reference page by `tools/split-sections.mjs`. Pick the sections the brief supports,
in the order `NARRATIVE.md` gives, and assemble with `tools/compose.mjs`. A section you do not
pick is not in the page, so it cannot be left half-edited.

`_foundation.css`, `_baselayer.css` and `_shell.part` are always included. `css −` means the section reuses a skin
block an earlier section already brought. `geometry` is measured off the reference page at 1440 and
390 — column counts, the first media box's aspect ratio and its share of the section width, and the
section's own height. Read it here rather than opening the stylesheet.

| section | kind | html | skin | words | imgs | geometry |
|---|---|---|---|---|---|---|
| `01-nav` | nav | 1.9KB | skin-01-nav.css | 9 | 0 | 75px |
| `02-hero` | hero | 0.8KB | skin-02-hero.css | 29 | 1 | media 1.6 · 900px |
| `03-logos` | logos | 1.7KB | skin-05-logos.css | 36 | 0 | 170px |
| `04-feature-grid` | feature-grid | 4.5KB | skin-04-feature-grid.css | 188 | 0 | 3col · →1col · 1035px |
| `05-pinned-split` | pinned-split | 3.1KB | — | 108 | 3 | media 0.5 · 21%w · 2924px |
| `06-mosaic-scroll` | mosaic-scroll | 20.2KB | — | 107 | 32 | media 1.33 · 25%w · 996px |
| `07-feature` | feature | 2.1KB | skin-03-feature-split.css | 32 | 2 | 2col · →1col · media 1.33 · 34%w · 1134px |
| `08-feature` | feature | 2.1KB | skin-03-feature-split.css (shared) | 32 | 2 | 2col · →1col · media 1.33 · 41%w · 1134px |
| `09-stats` | stats | 0.6KB | skin-06-stats.css | 10 | 0 | 5col · →2col · 331px |
| `10-steps` | steps | 0.8KB | skin-07-steps.css | 38 | 0 | 4col · →1col · 411px |
| `11-sticky-scroll` | sticky-scroll | 4.8KB | — | 123 | 4 | media 1.33 · 31%w · 1800px |
| `12-sticky-scroll` | sticky-scroll | 3.9KB | — | 88 | 3 | media 1.33 · 31%w · 1800px |
| `13-card-grid` | card-grid | 5.4KB | skin-12-card-grid.css | 68 | 6 | media 1.79 · 33%w · 963px |
| `14-index-tiles` | index-tiles | 2.3KB | skin-13-index-tiles.css | 28 | 4 | 4col · →1col · media 0.75 · 17%w · 700px |
| `15-testimonial` | testimonial | 7.0KB | skin-08-testimonial.css | 78 | 6 | 2col · →1col · media 1.1 · 34%w · 843px |
| `16-testimonial` | testimonial | 9.1KB | skin-08-testimonial.css (shared) | 211 | 12 | media 1 · 3%w · 595px |
| `17-statement` | statement | 1.9KB | — | 240 | 0 | 821px |
| `18-pricing` | pricing | 1.3KB | skin-09-pricing.css | 48 | 0 | 3col · →1col · 776px |
| `19-faq` | faq | 2.1KB | skin-10-faq.css | 66 | 0 | 604px |
| `20-contact` | contact | 1.1KB | skin-11-contact.css | 61 | 0 | 2col · →1col · 862px |
| `21-cta` | cta | 0.4KB | skin-14-cta.css | 14 | 0 | 431px |
| `22-footer` | footer | 2.4KB | skin-15-footer.css | 47 | 1 | 4col · →1col · media 1.6 · 900px |

```json
{"01-nav":"skin-01-nav.css","02-hero":"skin-02-hero.css","03-logos":"skin-05-logos.css","04-feature-grid":"skin-04-feature-grid.css","07-feature":"skin-03-feature-split.css","08-feature":"skin-03-feature-split.css","09-stats":"skin-06-stats.css","10-steps":"skin-07-steps.css","13-card-grid":"skin-12-card-grid.css","14-index-tiles":"skin-13-index-tiles.css","15-testimonial":"skin-08-testimonial.css","16-testimonial":"skin-08-testimonial.css","18-pricing":"skin-09-pricing.css","19-faq":"skin-10-faq.css","20-contact":"skin-11-contact.css","21-cta":"skin-14-cta.css","22-footer":"skin-15-footer.css"}
```

Whole reference page: 81.7KB · foundation 62.0KB.

## What each section is made of

Derived by `tools/describe-sections.mjs` — selectors matched in a browser, knobs read out of
`template.js`, hexes counted in the skin block. Read this instead of opening `template.js` or the
stylesheet: the four things below are what eleven runs went hunting for after composing, and they
are the ones the markup you composed does not tell you.

A **knob** changes what ships. `[data-cardgrid]` hides every card past `data-batch`, so a grid you
filled with six cards renders three until you raise it or drop the control. **Hardcoded** tints are
fixed hexes in the skin; the palette does not reach them, so a colour system you picked will not
recolour those parts.

Every section is also touched by `[data-motion="text-split"]` — the shared
motion/reveal runner, which reads data-to, data-suffix, data-motion, data-speed, data-pscale.
Listed once here; the lines below name only what is specific to one section.

### `01-nav`
- driven by: `.nav__burger` — reads data-open; · `.nav__menu a` — queries .nav__burger · `.nav` — queries .hero, .hero,[data-ground="dark"],.ftx,[data-nav-dark] · `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label

### `02-hero`
- driven by: `.nav` — queries .hero, .hero,[data-ground="dark"],.ftx,[data-nav-dark]

### `03-logos`
- repeats: .logos__item ×36
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `04-feature-grid`
- repeats: .fg__card ×6, .fg__icon ×6, .h3 ×6
- one repeat holds: svg×1, h3×1, p×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `05-pinned-split`
- repeats: .eyebrow ×4, .h2 ×4, .lead ×4
- driven by: `[data-pinned-split]` — reads data-i; queries .pin__frame, .pin__panel
- behaviour attributes present: data-i

### `06-mosaic-scroll`
- repeats: .mos__card ×32, .mos__media ×32, .media ×32
- one repeat holds: img×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `07-feature`
- repeats: .h2 ×3
- driven by: nothing of its own

### `08-feature`
- repeats: .h2 ×3
- driven by: nothing of its own

### `09-stats`
- repeats: .stats__cell ×4, .stats__num ×4, .small ×4
- one repeat holds: p×1
- driven by: nothing of its own

### `10-steps`
- repeats: .steps__item ×3, .steps__num ×3, .h3 ×3
- one repeat holds: h3×1, p×1
- driven by: nothing of its own

### `11-sticky-scroll`
- repeats: .ssh__card ×4, .ssh__media ×4, .media ×4
- one repeat holds: img×1, h3×1, p×1, a×1
- driven by: `[data-sticky-h]` — reads data-d; queries .ssh__track, .ssh__viewport, .ssh__cur, .ssh__card, .ssh__tab
- behaviour attributes present: data-i, data-d

### `12-sticky-scroll`
- repeats: .ssh__card ×3, .ssh__media ×3, .media ×3
- one repeat holds: img×1, h3×1, p×1, a×1
- driven by: `[data-sticky-h]` — reads data-d; queries .ssh__track, .ssh__viewport, .ssh__cur, .ssh__card, .ssh__tab
- behaviour attributes present: data-i, data-d

### `13-card-grid`
- repeats: .mono ×18, .cg__card ×6, .cg__media ×6
- driven by: `[data-cardgrid]` — reads data-batch, data-cat; queries .cg__tab, .cg__card, .cg__morewrap, .cg__more, .cg__grid
- behaviour attributes present: data-cat

### `14-index-tiles`
- repeats: .it__tile ×4, .it__media ×4, .media ×4
- one repeat holds: img×1, h3×1, p×1
- driven by: nothing of its own

### `15-testimonial`
- repeats: .small ×6, .tm__case ×3, .tm__caseMedia ×3
- driven by: `[data-tm-carousel]` — reads data-d, data-i; queries .tm__case, .tm__dot, .tm__arrow
- behaviour attributes present: data-i, data-d

### `16-testimonial`
- repeats: .tm__card ×12, .tm__quote ×12, .tm__by ×12
- one repeat holds: img×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `17-statement`
- driven by: nothing of its own

### `18-pricing`
- repeats: .pr__card ×3, .h3 ×3, .pr__tier ×3
- one repeat holds: h3×1, li×3, a×1
- driven by: nothing of its own

### `19-faq`
- repeats: .faq__item ×4, .faq__q ×4, .faq__icon ×4
- one repeat holds: svg×1, p×1
- driven by: `.faq__item` — queries summary, .faq__a

### `20-contact`
- repeats: .cf__field ×3
- driven by: `.cf__form` — queries .cf__ok

### `21-cta`
- driven by: nothing of its own

### `22-footer`
- repeats: .container ×3, .ft__col ×3, .ft__h ×3
- one repeat holds: h2×1, p×1, a×1
- driven by: `.nav` — queries .hero, .hero,[data-ground="dark"],.ftx,[data-nav-dark] · `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label
