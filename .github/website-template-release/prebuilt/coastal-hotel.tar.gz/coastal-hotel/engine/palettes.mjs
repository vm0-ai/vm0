/* palettes.mjs — the COLOUR CATALOGUE: 16 curated, dual-mode palettes the generator matches
 * pages from. Each fills the 11 colour-ROLE contract (foundation.css) in BOTH themes, plus a
 * --slab moment ground. Re-introduces a shared catalogue so generation can
 * "pick a palette" instead of every skin inventing colours.
 *
 * RULES (Tong, 2026-06-30):
 *  - exactly ONE warm-yellow / ochre "AI-background" palette (`sand`). Do NOT let a yellow creep
 *    into the others — the rest span cool/neutral/dark/vivid families.
 *  - every palette is contrast-calibrated (see check-catalog.mjs): ink, ink-soft and accent each
 *    clear AA on their ground, in light AND dark.
 *
 * Each seed declares the 5 anchor roles per mode; derive() computes surface/surface-2/border/
 * ring/support-1/support-2/slab. paletteCSS(id) → ready `:root`+dark CSS. */

const hx = h => { h=h.replace('#',''); return [0,2,4].map(i=>parseInt(h.slice(i,i+2),16)); };
const hex = a => '#'+a.map(x=>Math.max(0,Math.min(255,Math.round(x))).toString(16).padStart(2,'0')).join('');
const mix = (a,b,t) => { const A=hx(a),B=hx(b); return hex(A.map((x,i)=>x+(B[i]-x)*t)); };

// derive the full 11-role set (+ slab) from the 5 anchors of one mode
function derive(a, mode){
  const dark = mode==='dark';
  return {
    bg:a.bg, ink:a.ink, 'ink-soft':a.inkSoft, accent:a.accent, 'accent-ink':a.accentInk,
    surface:   mix(a.bg, a.ink, dark?0.06:0.045),
    'surface-2':mix(a.bg, a.ink, dark?0.11:0.085),
    border:    mix(a.bg, a.ink, dark?0.20:0.15),
    ring:      a.accent,
    'support-1':mix(a.accent, a.ink, 0.30),
    'support-2':mix(a.accent, a.bg, 0.34),
    slab: dark ? '#040404' : mix(a.ink, '#000000', 0.55)
  };
}

/* 16 seeds — anchors only (bg · ink · inkSoft · accent · accentInk), per mode. Families:
 * cool-blue ×4 (slate·nordic·ocean·stone) · green/teal ×4 (teal·forest·mint·graphite) ·
 * purple ×2 (plum·violet) · warm-red/pink ×3 (berry·coral·crimson) · mono (ink) ·
 * dark-first (midnight) · and the ONE yellow (sand). */
const SEEDS = [
  {id:'slate', name:'Slate', mood:'cool corporate, trustworthy',
    light:{bg:'#FFFFFF',ink:'#0F1521',inkSoft:'#51607A',accent:'#2952C8',accentInk:'#FFFFFF'},
    dark:{bg:'#0C0F16',ink:'#EAEEF6',inkSoft:'#9AA6B7',accent:'#8AA0FF',accentInk:'#0B0E14'}},
  {id:'ink', name:'Ink', mood:'mono editorial, stark',
    light:{bg:'#FFFFFF',ink:'#0A0A0A',inkSoft:'#565656',accent:'#111111',accentInk:'#FFFFFF'},
    dark:{bg:'#0A0A0A',ink:'#F2F2F2',inkSoft:'#9A9A9A',accent:'#FFFFFF',accentInk:'#0A0A0A'}},
  {id:'nordic', name:'Nordic', mood:'cool grey-blue, calm',
    light:{bg:'#F7F9FB',ink:'#1B2430',inkSoft:'#54616E',accent:'#356C8C',accentInk:'#FFFFFF'},
    dark:{bg:'#0E1419',ink:'#E7EDF2',inkSoft:'#93A1AD',accent:'#7FB7D2',accentInk:'#08121A'}},
  {id:'teal', name:'Teal', mood:'fresh fintech, confident',
    light:{bg:'#FBFBF9',ink:'#17181C',inkSoft:'#5C635F',accent:'#0C7C6C',accentInk:'#FFFFFF'},
    dark:{bg:'#0C0D0D',ink:'#F2F3EF',inkSoft:'#9A9B95',accent:'#2FDCC4',accentInk:'#062019'}},
  {id:'forest', name:'Forest', mood:'deep green, grounded',
    light:{bg:'#FAFBF8',ink:'#16201A',inkSoft:'#525E54',accent:'#1C7345',accentInk:'#FFFFFF'},
    dark:{bg:'#0B110D',ink:'#EAF1EA',inkSoft:'#93A096',accent:'#4FD08A',accentInk:'#04140B'}},
  {id:'berry', name:'Berry', mood:'vivid magenta, expressive',
    light:{bg:'#FFFCFE',ink:'#21121C',inkSoft:'#6A5563',accent:'#B11A78',accentInk:'#FFFFFF'},
    dark:{bg:'#140910',ink:'#F6EAF1',inkSoft:'#B098A6',accent:'#FF6FC2',accentInk:'#1A0512'}},
  {id:'coral', name:'Coral', mood:'warm red-coral, energetic',
    light:{bg:'#FFFBFA',ink:'#241410',inkSoft:'#6B564F',accent:'#C0341F',accentInk:'#FFFFFF'},
    dark:{bg:'#150B09',ink:'#F6EAE6',inkSoft:'#B59C95',accent:'#FF7A66',accentInk:'#1A0703'}},
  {id:'plum', name:'Plum', mood:'rich purple, premium',
    light:{bg:'#FCFBFE',ink:'#1B1426',inkSoft:'#5E5670',accent:'#6B2BC9',accentInk:'#FFFFFF'},
    dark:{bg:'#100A18',ink:'#EFEAF6',inkSoft:'#A79EB5',accent:'#A98BFF',accentInk:'#0C0518'}},
  {id:'ocean', name:'Ocean', mood:'azure / cyan, open',
    light:{bg:'#F8FCFE',ink:'#0E1E27',inkSoft:'#4E626D',accent:'#0A6FA8',accentInk:'#FFFFFF'},
    dark:{bg:'#08131A',ink:'#E6F1F7',inkSoft:'#90A3AD',accent:'#52C4F0',accentInk:'#03131C'}},
  {id:'sand', name:'Sand', mood:'warm ochre / cream — the ONE yellow palette (use sparingly)',
    light:{bg:'#F7EFD9',ink:'#2B2415',inkSoft:'#6A5E42',accent:'#8A5A12',accentInk:'#FFFFFF'},
    dark:{bg:'#16130C',ink:'#F1E9D6',inkSoft:'#A99E84',accent:'#E3B65C',accentInk:'#1A1304'}},
  {id:'clay', name:'Clay', mood:'terracotta, earthy (NOT yellow)',
    light:{bg:'#FBF7F5',ink:'#241814',inkSoft:'#6B5951',accent:'#B14E2E',accentInk:'#FFFFFF'},
    dark:{bg:'#140C0A',ink:'#F4E9E4',inkSoft:'#B39E96',accent:'#E07A52',accentInk:'#1A0803'}},
  {id:'midnight', name:'Midnight', mood:'dark-first, vivid indigo',
    light:{bg:'#FFFFFF',ink:'#0B1020',inkSoft:'#566075',accent:'#3B3BE0',accentInk:'#FFFFFF'},
    dark:{bg:'#070A14',ink:'#E8EBF5',inkSoft:'#969FB5',accent:'#8C8CFF',accentInk:'#06060F'}},
  {id:'crimson', name:'Crimson', mood:'deep red, bold',
    light:{bg:'#FFFAFB',ink:'#220F13',inkSoft:'#6A5258',accent:'#B11231',accentInk:'#FFFFFF'},
    dark:{bg:'#14080B',ink:'#F6E9EC',inkSoft:'#B6989E',accent:'#FF6B85',accentInk:'#1A0509'}},
  {id:'graphite', name:'Graphite', mood:'desaturated grey-green, quiet',
    light:{bg:'#F6F7F8',ink:'#15181C',inkSoft:'#586069',accent:'#3A6E5E',accentInk:'#FFFFFF'},
    dark:{bg:'#101214',ink:'#ECEFF2',inkSoft:'#99A1A9',accent:'#7FB8A6',accentInk:'#06120D'}},
  {id:'mint', name:'Mint', mood:'fresh green-mint, light',
    light:{bg:'#F6FCF8',ink:'#0F1F17',inkSoft:'#506658',accent:'#097A4E',accentInk:'#FFFFFF'},
    dark:{bg:'#091310',ink:'#E6F2EC',inkSoft:'#90A39A',accent:'#48D69E',accentInk:'#04140C'}},
  {id:'stone', name:'Stone', mood:'warm neutral grey, blue accent',
    light:{bg:'#F8F7F4',ink:'#1C1B18',inkSoft:'#5E5B54',accent:'#3A5C8C',accentInk:'#FFFFFF'},
    dark:{bg:'#121110',ink:'#EEEDEA',inkSoft:'#9C988F',accent:'#86A6D8',accentInk:'#070C16'}},
];

export const PALETTES = SEEDS.map(s => ({
  id:s.id, name:s.name, mood:s.mood,
  light: derive(s.light,'light'),
  dark:  derive(s.dark,'dark')
}));

export const palette = id => PALETTES.find(p=>p.id===id);

const roleLine = roles => Object.entries(roles).map(([k,v])=>`--${k}:${v}`).join(';');

/* paletteCSS(id) → the `:root` (light) + `html[data-theme=dark]` blocks for a page/skin. */
export function paletteCSS(id){
  const p = palette(id); if(!p) throw new Error('unknown palette '+id);
  return `:root{${roleLine(p.light)}}\nhtml[data-theme="dark"]{${roleLine(p.dark)}}`;
}
