# Coastal Hotel — design system

Measured from the local `template.css` and `index.html`. These are facts about
the shipped stylesheet, not intentions. Where a value here disagrees with prose anywhere else, this
file is right.

## Character

> crest-emblem hero + rotating seal · tilted postcard cards · hairline-ruled lists · watercolour-coast contour · fanned arc showcase · scroll-illuminate statement



## Type

| | |
|---|---|
| Families loaded | `Cormorant` · `Jost` |
| Display face | `'Cormorant'` |
| Body face | `'Jost'` |
| Font personality flag | `data-fonts="coastal-hotel"` |

Both faces are declared as tokens, so a brand type change is a two-line edit in
`style[data-brand-theme]` — not a find-and-replace through the stylesheet.

## Colour roles

The stylesheet reads colour only through these roles. Rebinding them in `style[data-brand-theme]`
restyles the whole page; writing a literal colour anywhere else forks it.

| role | light | dark |
|---|---|---|
| `--bg` | #FBF7F5 | #140C0A |
| `--ink` | #241814 | #F4E9E4 |
| `--ink-soft` | #6B5951 | #B39E96 |
| `--accent` | #B14E2E | #E07A52 |
| `--accent-ink` | #FFFFFF | #1A0803 |
| `--support-1` | #873e26 | #e69b7e |
| `--support-2` | #ca8772 | #9b553a |
| `--surface` | #f1edeb | #211917 |
| `--surface-2` | #e9e4e2 | #2d2422 |
| `--border` | #dbd6d3 | #413836 |
| `--ring` | #B14E2E | #E07A52 |
| `--slab` | #100b09 | #040404 |

Generate a replacement set with `node tools/palette.mjs --pick <system>`; use `--list` to choose and `--check` to audit bespoke values.
The values above are the reference page's own palette; they are a demonstration, not a requirement.

## Structural tokens

| token | value |
|---|---|
| `--container` | var(--w-standard) |
| `--fb` | 'Jost' |
| `--fd` | 'Cormorant' |
| `--fx-aurora-1` | 12s |
| `--fx-aurora-2` | 14s |
| `--fx-aurora-3` | 16s |
| `--fx-aurora-blur` | 90px |
| `--fx-aurora-opacity` | .5 |
| `--fx-grain-opacity` | .085 |
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |
| `--radius` | 5px |
| `--rule` | color-mix(in srgb,var(--ink) 14%,transparent) |

**Spacing scale** — `--space-2`=.5rem · `--space-3`=.75rem · `--space-4`=1rem · `--space-5`=1.5rem · `--space-6`=2rem · `--space-7`=3rem · `--space-8`=4rem · `--space-9`=6rem · `--space-10`=8rem



## Motion

| token | value |
|---|---|
| `--mo-dist` | 28px |
| `--mo-dur` | .7s |
| `--mo-ease` | cubic-bezier(.2,.8,.2,1) |
| `--mo-mag` | .3 |
| `--mo-marq` | 30s |
| `--mo-stagger` | 80ms |
| `--mo-tilt` | 6deg |

Motion personality: `kinetic`. `template.js` binds the reveals, the marquee, the
disclosure widgets, the theme toggle and the mobile nav. Reveals must degrade to visible content —
never hide a whole section behind an IntersectionObserver.

## Device vocabulary

Class prefixes that carry layout in the reference page, by frequency. Compose from these; a class
that is not here has no stylesheet behind it, and inventing one produces an unstyled bare tag.

`.media`×57 · `.mono`×56 · `.small`×42 · `.muted`×41 · `.h3`×29 · `.h2`×21 · `.container`×20 · `.section`×20 · `.btn`×16 · `.lead`×14 · `.body`×13 · `.btn-ghost`×11 · `.sec-head`×11 · `.eyebrow`×6 · `.btn-primary`×4 · `.theme-toggle`×2 · `.fs`×2 · `.fs--rev`×2 · `.ss`×2 · `.ssh`×2 · `.tm`×2 · `.skip`×1 · `.nav`×1 · `.theme-toggle--nav`×1 · `.hero`×1 · `.logos`×1 · `.logos--wall`×1 · `.fg`×1 · `.fg--cards`×1 · `.mos`×1 · `.fs--even`×1 · `.fs--media-wide`×1 · `.stats`×1 · `.steps`×1

## Reference density

The reference page carries **1549 visible words** across its sections. That is a description
of this example, not a target. Say what the brief supports and stop — a page padded to reach a
word count reads like one, and the reader can tell.
