/* skin-litoral.mjs — a Website Studio skin. LEARNED FRESH from a Basque coastal luxury hotel
 * (San Sebastián / La Concha). Its language: restrained "quiet luxury" — an elegant LIGHT
 * high-contrast serif (Cormorant) paired with a geometric sans (Jost), hand-drawn line motifs and
 * tactile paper. COLOUR is NOT lifted from the source: it is driven by the system catalogue
 * (`palettes.mjs` → `clay`, warm terracotta) so the look is clearly its own, not a copy.
 * Signatures: centred CREST-EMBLEM hero + rotating seal · tilted "postcard" cards · hairline-ruled
 * lists · watercolour-coast contour · a FANNED ARC showcase · a full-bleed scroll-illuminate
 * statement · a split (image + form) contact. All sections re-dressed in this character.
 */
import { palette } from './engine/palettes.mjs';

const P = palette('clay');                 // system palette (terracotta / espresso), NOT the source green
const L = P.light, D = P.dark;
const roles = o => Object.entries(o).map(([k,v])=>`--${k}:${v}`).join(';');
// a deep espresso chrome (nav / footer / statement) derived from the palette's DARK roles — AA-safe
const darkChrome = sel => `${sel}{${roles(D)};background:${D.bg};color:${D.ink};` +
  `--rule:color-mix(in srgb,${D.ink} 20%,transparent)}`;

export const skin = {
  id:'coastal-hotel',                 // canonical two-word kebab name (team naming convention)
  brand:'Litoral',                    // original demo brand shown in the proof (decoupled from id)
  fontsAttr:'coastal-hotel', motionAttr:'kinetic',
  fontLink:'<link href="https://fonts.googleapis.com/css2?family=Cormorant:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400;1,500&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet">',
  signature:'crest-emblem hero + rotating seal · tilted postcard cards · hairline-ruled lists · watercolour-coast contour · fanned arc showcase · scroll-illuminate statement',
  css:`
/* ① COLOURS — from the system catalogue (clay), dual-mode; NOT the source palette --------- */
:root{${roles(L)};
  --fd:'Cormorant'; --fb:'Jost'; --radius:5px; --container:var(--w-standard);
  --rule:color-mix(in srgb,var(--ink) 14%,transparent)}
html[data-theme="dark"]{${roles(D)};
  --rule:color-mix(in srgb,var(--ink) 18%,transparent)}
/* deep espresso flooded ground (hero, stats, any plan ground:'dark') */
[data-ground="dark"]{${roles(D)};background:${D.bg};color:${D.ink};
  --rule:color-mix(in srgb,${D.ink} 20%,transparent)}

/* ── shared type — elegant light serif display, geometric-sans utility ── */
.display{font-family:var(--fd);font-weight:400;letter-spacing:-.012em;line-height:1.02}
h1,.h1{font-family:var(--fd);font-weight:400;letter-spacing:-.01em;line-height:1.06}
h2,.h2{font-family:var(--fd);font-weight:400;letter-spacing:-.005em;line-height:1.12}
h3,.h3{font-family:var(--fd);font-weight:500;letter-spacing:0;line-height:1.2}
.lead{font-family:var(--fd);font-weight:400;color:var(--ink-soft);
  font-size:clamp(1.15rem,1.7vw,1.45rem);line-height:1.5}
.eyebrow{font-family:var(--fb);font-weight:500;text-transform:uppercase;letter-spacing:.24em;
  font-size:.72rem;color:var(--accent);max-width:none}   /* not a body <p>: don't inherit the 68ch cap (which left-aligned + de-centred it) */
.muted{color:var(--ink-soft)}
.sec-head{max-width:56ch;margin:0 auto clamp(2rem,4vw,3.2rem);text-align:center}
.sec-head .lead{margin-top:var(--space-3)}
.media{background:var(--surface-2);border:1px solid var(--border);border-radius:var(--r-md);
  box-shadow:0 1px 0 rgba(0,0,0,.02)}

/* ── buttons — uppercase geometric-sans pills; ghost carries the → arrow motif ── */
.btn{font-family:var(--fb);font-weight:500;text-transform:uppercase;letter-spacing:.14em;
  font-size:.78rem;min-height:46px;padding:.85rem 1.5rem;border-radius:var(--r-pill);border:1px solid transparent}
.btn-primary{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
.btn-primary:hover{filter:brightness(1.06)}
.btn-ghost{background:transparent;color:var(--accent);
  border:1px solid color-mix(in srgb,var(--accent) 50%,transparent)}
.btn-ghost::after{content:"→";font-family:var(--fb);margin-left:.15em;transition:transform .2s ease}
.btn-ghost:hover{border-color:var(--accent)}
.btn-ghost:hover::after{transform:translateX(3px)}

/* ═══════════ 1 · NAV — persistent espresso chrome, tracked-sans wordmark ═══════════ */
${darkChrome('.nav')}
.nav{border-bottom:1px solid color-mix(in srgb,${D.ink} 12%,transparent)}
.nav__bar{min-height:74px}
.nav__brand{font-family:var(--fb);font-weight:500;text-transform:uppercase;letter-spacing:.34em;
  font-size:.92rem;color:var(--ink)}
.nav__links a{font-family:var(--fb);text-transform:uppercase;letter-spacing:.14em;font-size:.72rem;
  font-weight:400;color:var(--ink-soft)}
.nav__links a:hover{color:var(--ink)}
.nav__cta{background:transparent;color:var(--ink);border:1px solid color-mix(in srgb,var(--ink) 40%,transparent)}
.nav__cta:hover{border-color:var(--ink)}
.theme-toggle{background:transparent;color:var(--ink);border-color:color-mix(in srgb,var(--ink) 28%,transparent)}
.nav__burger{color:var(--ink);border-color:color-mix(in srgb,var(--ink) 30%,transparent)}
@media(max-width:767px){.nav__menu{background:${D.bg};border-bottom-color:color-mix(in srgb,${D.ink} 12%,transparent)}}

/* ═══════════ 2 · HERO — centred crest emblem on espresso + rotating seal ═══════════ */
.hero{position:relative;overflow:hidden;text-align:center;padding-block:clamp(4rem,11vw,9rem)}
.hero__inner{max-width:60rem;margin-inline:auto;display:flex;flex-direction:column;align-items:center;gap:var(--space-4)}
.hero .eyebrow{color:var(--accent);letter-spacing:.32em}
.hero__place{display:block;font-family:var(--fb);text-transform:uppercase;letter-spacing:.42em;
  font-size:.7rem;color:var(--accent);margin:.2rem 0 .1rem}
.hero__crest{width:clamp(64px,9vw,92px);height:auto;color:var(--ink);opacity:.92;margin:.4rem 0}
.hero__word{font-family:var(--fd);font-weight:300;line-height:.92;letter-spacing:-.02em;
  font-size:clamp(3.4rem,13vw,8.5rem);color:var(--ink);overflow-wrap:anywhere}
.hero__tag{font-family:var(--fd);font-style:italic;font-weight:400;color:var(--ink);opacity:.92;
  font-size:clamp(1.3rem,2.6vw,2rem);line-height:1.25;max-width:24ch;margin:.2rem 0}
.hero .hero__lead{color:var(--ink);opacity:.82;max-width:52ch;margin-inline:auto}
.hero__cta{display:flex;flex-wrap:wrap;gap:var(--space-3);justify-content:center;margin-top:var(--space-5)}
.hero__seal{position:absolute;right:clamp(.8rem,4vw,3.5rem);bottom:clamp(1rem,5vw,3.5rem);
  width:clamp(84px,11vw,124px);height:clamp(84px,11vw,124px);display:grid;place-items:center;
  color:color-mix(in srgb,var(--ink) 82%,var(--accent))}
.hero__seal .seal__spin{width:100%;height:100%;animation:litoral-spin 26s linear infinite}
.seal__txt{font-family:var(--fb);font-weight:500;text-transform:uppercase;letter-spacing:.24em;
  font-size:9px;fill:currentColor}
.hero__seal .seal__mark{position:absolute;font-family:var(--fd);font-size:1.1rem;color:var(--accent)}
@keyframes litoral-spin{to{transform:rotate(360deg)}}
@media(prefers-reduced-motion:reduce){.hero__seal .seal__spin{animation:none}}
@media(max-width:520px){.hero__seal{position:static;margin:1.4rem auto 0}}

/* ═══════════ 3 · FEATURE-SPLIT — airy 50/50, hairline-bracketed text, framed media ═══════════ */
.fs{padding-block:clamp(3.5rem,8vw,7rem)}
.fs__heading{text-align:center;max-width:24ch;margin:0 auto clamp(2rem,5vw,4rem);
  font-size:clamp(1.8rem,3.4vw,2.8rem)}
.fs__rows{gap:clamp(3rem,7vw,6rem)}
.fs__row{align-items:center;gap:clamp(1.6rem,4vw,3.5rem)}
.fs__text{padding-block:var(--space-4);border-top:1px solid var(--rule);border-bottom:1px solid var(--rule)}
.fs__text .lead{margin-top:var(--space-4)}
.fs__icon{width:52px;height:52px;border:1px solid var(--accent);border-radius:var(--r-pill);
  color:var(--accent);margin-bottom:var(--space-4)}
.fs__text h3{font-size:clamp(1.7rem,3vw,2.5rem);font-weight:400}
.fs .media{aspect-ratio:4/5;border-radius:var(--r-md);position:relative}
.fs .media::after{content:"";position:absolute;inset:10px;border:1px solid var(--rule);border-radius:2px;pointer-events:none}

/* ═══════════ 4 · FEATURE-GRID — tilted "postcard" cards, sage circle icons ═══════════ */
.fg__grid{gap:clamp(1.2rem,2.5vw,2rem)}
.fg__card{background:var(--surface);border:1px solid var(--border);border-radius:var(--r-md);
  padding:clamp(1.6rem,2.4vw,2.1rem);box-shadow:0 12px 30px -22px rgba(20,12,10,.4);
  transition:transform .3s ease,box-shadow .3s ease}
.fg--cards .fg__card:nth-child(3n+1){transform:rotate(-1.1deg)}
.fg--cards .fg__card:nth-child(3n){transform:rotate(1.1deg)}
.fg__card:hover{transform:rotate(0) translateY(-4px);box-shadow:0 22px 44px -26px rgba(20,12,10,.5)}
.fg__icon{width:48px;height:48px;border:1px solid var(--accent);border-radius:var(--r-pill);
  color:var(--accent);margin-bottom:var(--space-4)}
.fg__card .h3{font-weight:500;font-size:1.5rem;margin-bottom:var(--space-2)}
.fg--bento .fg__card{transform:none;box-shadow:none;background:var(--surface-2);border-color:var(--border)}
.fg--bento .fg__card:hover{transform:translateY(-3px)}

/* ═══════════ 5 · LOGOS — serif band, FLUSH (no top/bottom padding), uniform gaps ═══════════ */
.logos{background:var(--surface-2);padding-block:0}
.logos .container{padding-block:var(--space-4)}
.logos__label{font-family:var(--fb);text-transform:uppercase;letter-spacing:.28em;font-size:.7rem;
  color:var(--ink-soft);text-align:center;max-width:none;margin-inline:auto}   /* it's a <p>; p{max-width:68ch} shrinks the block + left-aligns it, so text-align:center wouldn't centre it in the band — force full width */
.logos__row{gap:clamp(2.5rem,5vw,4rem);justify-content:center}
.logos__marquee{margin:0;padding-block:var(--space-5);border:0}
.logos .mo-track{gap:clamp(2.5rem,5vw,4rem);padding-right:clamp(2.5rem,5vw,4rem);align-items:center}
.logos__item{font-family:var(--fd);font-style:italic;font-weight:400;font-size:clamp(1.5rem,2.6vw,2.1rem);
  letter-spacing:0;color:var(--ink-soft);opacity:.9;white-space:nowrap}

/* ═══════════ 6 · STATS — flooded espresso, big light serif figures, hairline dividers ═══════════ */
.stats{padding-block:clamp(3rem,7vw,6rem)}
.stats__grid{gap:0}
.stats__cell{text-align:center;padding:var(--space-5) var(--space-4);border-left:1px solid var(--rule)}
.stats__cell:first-child{border-left:0}
.stats__num{font-family:var(--fd);font-weight:300;font-size:clamp(1.9rem,4vw,3.4rem);
  color:var(--ink);letter-spacing:-.02em;line-height:1;white-space:nowrap}   /* figures ALWAYS on one line; smaller clamp so long values (e.g. "1.6M km²", "8,611 m") shrink to fit instead of wrapping */
.stats__cell .small{font-family:var(--fb);text-transform:uppercase;letter-spacing:.2em;font-size:.68rem;
  color:var(--ink-soft);margin-top:var(--space-3)}
@media(max-width:639px){.stats__grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:var(--space-4)}
  .stats__cell{border-left:0;border-top:1px solid var(--rule)}}

/* ═══════════ 7 · STEPS — big serif index numerals, hairline-separated ═══════════ */
.steps__list{gap:0}
.steps__item{align-items:flex-start;gap:var(--space-5);padding-block:clamp(1.4rem,3vw,2.2rem);
  border-top:1px solid var(--rule)}
.steps__num{font-family:var(--fd);font-weight:300;font-size:2.6rem;line-height:1;color:var(--accent);
  background:transparent;width:auto;height:auto;border-radius:0;justify-content:flex-start;flex:none;min-width:2.4ch}
.steps__item .h3{font-weight:500;font-size:1.5rem;margin-bottom:var(--space-1)}
@media(min-width:880px){.steps__list{grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:0}
  .steps__item{border-top:0;border-left:1px solid var(--rule);padding:0 var(--space-5);flex-direction:column}
  .steps__item:first-child{border-left:0;padding-left:0}}

/* ═══════════ 8 · TESTIMONIAL — tilted quote postcards w/ pin + big serif quote-mark ═══════════ */
.tm__grid{gap:clamp(1.2rem,2.5vw,2rem)}
.tm__card{background:var(--surface);border:1px solid var(--border);border-radius:var(--r-md);
  padding:clamp(1.6rem,2.6vw,2.2rem);position:relative;box-shadow:0 14px 34px -24px rgba(20,12,10,.45);
  transition:transform .3s ease,box-shadow .3s ease}
.tm__card::before{content:"";position:absolute;top:14px;left:50%;transform:translateX(-50%);
  width:9px;height:9px;border-radius:50%;background:var(--accent);box-shadow:0 1px 3px rgba(0,0,0,.3)}
.tm--cards .tm__card:nth-child(3n+1){transform:rotate(-1.2deg)}
.tm--cards .tm__card:nth-child(3n){transform:rotate(1.2deg)}
.tm__card:hover{transform:rotate(0) translateY(-4px);box-shadow:0 24px 48px -28px rgba(20,12,10,.55)}
.tm__quote{font-family:var(--fd);font-weight:400;font-size:1.35rem;line-height:1.4;margin-top:var(--space-3)}
.tm__quote::before{content:"“";font-family:var(--fd);color:var(--accent);font-size:2.4rem;
  line-height:0;vertical-align:-.35em;margin-right:.1em}
.tm__name{font-family:var(--fb);font-weight:500;text-transform:uppercase;letter-spacing:.1em;font-size:.78rem}
.tm__avatar{border-radius:50%}
.tm--spotlight .tm__card{background:transparent;border:0;box-shadow:none}
.tm--spotlight .tm__card::before{display:none}
.tm--spotlight .tm__quote{font-style:italic;font-size:clamp(1.5rem,3.4vw,2.3rem);line-height:1.32}
.tm--marquee .tm__card{transform:none}
/* the marquee clips overflow for the loop — pad it so the card DROP-SHADOWS aren't cut off */
.tm--marquee .tm__marquee{padding-block:12px 48px;margin-top:var(--space-4)}

/* ═══════════ 9 · PRICING — refined rate cards, hairline feature rules, serif prices ═══════════ */
.pr__grid{gap:clamp(1.2rem,2.5vw,2rem)}
.pr__card{background:var(--surface);border:1px solid var(--border);border-radius:var(--r-md);
  padding:clamp(1.8rem,3vw,2.6rem);box-shadow:none}
.pr__card--pop{border-color:var(--accent);box-shadow:0 24px 50px -30px rgba(20,12,10,.5)}
.pr__tier{font-family:var(--fb);font-weight:500;text-transform:uppercase;letter-spacing:.18em;
  font-size:.8rem;color:var(--ink-soft)}
.pr__badge{background:var(--support-1);color:#fff;font-family:var(--fb);letter-spacing:.14em;
  text-transform:uppercase;border-radius:var(--r-pill)}
.pr__amt{font-family:var(--fd);font-weight:300;font-size:clamp(2.6rem,5vw,3.6rem);letter-spacing:-.02em}
.pr__feats li{padding:var(--space-3) 0;border-top:1px solid var(--rule);color:var(--ink-soft)}
.pr__feats li::before{display:none}
.pr__feats li:first-child{border-top:0}

/* ═══════════ 10 · FAQ — hairline accordion, light serif questions ═══════════ */
.faq__h{font-size:clamp(1.9rem,3.6vw,2.8rem)}
.faq__item{border-bottom:1px solid var(--rule)}
.faq__q{font-family:var(--fd);font-weight:400;font-size:clamp(1.25rem,2.2vw,1.6rem);
  padding:clamp(1rem,2vw,1.4rem) 0}
.faq__icon{color:var(--accent)}
.faq__a .body{font-family:var(--fb)}

/* ═══════════ 11 · CONTACT — split: framed photo LEFT, form RIGHT ═══════════ */
.cf--split .cf__media{aspect-ratio:4/5;border-radius:var(--r-md);position:relative;overflow:hidden}
.cf--split .cf__media::after{content:"";position:absolute;inset:10px;border:1px solid rgba(255,255,255,.35);border-radius:2px;pointer-events:none}
.cf__head .h2{font-size:clamp(1.9rem,3.6vw,2.8rem);font-weight:400}
.cf__field span{font-family:var(--fb);text-transform:uppercase;letter-spacing:.16em;font-size:.68rem;color:var(--ink-soft)}
.cf__field input,.cf__field textarea{background:var(--surface);border:1px solid var(--border);
  color:var(--ink);border-radius:var(--radius)}

/* ═══════════ 12 · CARD-GRID — tilted photo postcards, "view" arrow ═══════════ */
.cg__head .h2{font-size:clamp(1.9rem,3.6vw,2.8rem);font-weight:400}
.cg__tabs{gap:var(--space-2)}
.cg__tab{font-family:var(--fb);text-transform:uppercase;letter-spacing:.12em;font-size:.68rem;
  border-radius:var(--r-pill);background:transparent;border-color:var(--border);color:var(--ink-soft)}
.cg__tab[aria-pressed="true"]{background:var(--accent);border-color:var(--accent);color:var(--accent-ink)}
.cg__grid{gap:clamp(1.2rem,2.5vw,2rem)}
.cg__card{background:var(--surface);border:1px solid var(--border);border-radius:var(--r-md);
  padding:var(--space-4);box-shadow:0 14px 34px -24px rgba(20,12,10,.45);
  transition:transform .3s ease,box-shadow .3s ease}
.cg__card:nth-child(3n+1){transform:rotate(-1deg)}
.cg__card:nth-child(3n){transform:rotate(1deg)}
.cg__card:hover{transform:rotate(0) translateY(-5px);border-color:var(--accent);
  box-shadow:0 24px 48px -26px rgba(20,12,10,.55)}
.cg__media{aspect-ratio:3/4;border-radius:2px}
.cg__tag{font-family:var(--fb);letter-spacing:.12em;color:var(--accent);border:1px solid var(--accent);border-radius:var(--r-pill)}
.cg__meta{font-family:var(--fb);letter-spacing:.08em;color:var(--ink-soft)}
.cg__title{font-family:var(--fd);font-weight:500;font-size:1.5rem}
.cg__role{font-family:var(--fb)}
.cg__link{font-family:var(--fb);text-transform:uppercase;letter-spacing:.12em;font-size:.68rem;color:var(--accent)}

/* ═══════════ 13 · INDEX-TILES — numbered photo tiles, big serif index, espresso scrim ═══════════ */
.it__grid{gap:clamp(1rem,2vw,1.5rem)}
.it__tile{border-radius:var(--r-md);background:${D.bg}}
.it__tile::after{background:linear-gradient(to top,rgba(15,8,6,.86),rgba(15,8,6,.08) 55%,rgba(15,8,6,.32))}
.it__media{transition:transform .5s ease}
.it__tile:hover .it__media{transform:scale(1.05)}
.it__num{font-family:var(--fd);font-weight:300;font-size:2.6rem;opacity:.9}
.it__title{font-family:var(--fd);font-weight:500;font-size:1.4rem}
.it__cap{font-family:var(--fb)}

/* ═══════════ 14 · ARC-SHOWCASE — fanned arc of tilted photo cards ═══════════ */
.arc__head .eyebrow{margin-bottom:var(--space-3)}
.arc__head .h2{font-size:clamp(1.9rem,3.6vw,2.8rem);font-weight:400}
.arc__media{border-radius:var(--r-md)}
/* no card plate / shadow — just the rotated photo + caption (Tong) */
.arc.is-live .arc__card,.arc.is-live .arc__card .arc__media{box-shadow:none;background:transparent}
.arc__cap{font-family:var(--fd);font-size:1.35rem}
.arc__cardcta{font-family:var(--fb);text-transform:uppercase;letter-spacing:.12em;font-size:.68rem;color:var(--accent)}
.arc__btn{background:var(--surface)}
.arc__btn:hover{border-color:var(--accent);color:var(--accent)}

/* ═══════════ 15 · SCROLL-STATEMENT — full-bleed image, line-by-line serif illuminate ═══════════ */
.sst{background:${D.bg}}
.sst__bg{border-radius:0}                 /* square corners — a true full-bleed band (override .media) */
.sst::before{background:linear-gradient(color-mix(in srgb,${D.bg} 62%,transparent),color-mix(in srgb,${D.bg} 58%,transparent))}
.sst__eyebrow{color:${D.accent};letter-spacing:.3em}
.sst__quote{font-family:var(--fd);font-weight:400}
.sst__quote .mo-ill{color:#FBF7F5}

/* ═══════════ CTA — booking panel, watercolour-coast contour, serif invitation ═══════════ */
/* the panel IS the .container, so it must stay INSET from the viewport at every width — cap its
   width to leave a real cream gap on both sides (generous in the ~1200–1280 band where a plain
   1200 container would touch the edges; smaller floor on mobile). Internal text padding stays on
   .cta__panel below. */
.cta .container{max-width:min(var(--container),calc(100% - clamp(2.5rem,8vw,5rem)))}
.cta__panel{position:relative;overflow:hidden;border-radius:var(--r-lg);
  background:var(--accent);color:var(--accent-ink);padding:clamp(2.4rem,6vw,4.5rem)}
.cta__panel::before{content:"";position:absolute;inset:0;z-index:0;opacity:.9;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='260' height='170'%3E%3Cg fill='none' stroke='%23ffffff' stroke-opacity='0.16' stroke-width='1'%3E%3Cpath d='M0 34 Q65 12 130 34 T260 34'/%3E%3Cpath d='M0 68 Q65 46 130 68 T260 68'/%3E%3Cpath d='M0 102 Q65 80 130 102 T260 102'/%3E%3Cpath d='M0 136 Q65 114 130 136 T260 136'/%3E%3C/g%3E%3C/svg%3E");
  background-size:340px auto}
.cta__panel>*{position:relative;z-index:1}
.cta__title{font-family:var(--fd);font-weight:400;font-size:clamp(2rem,4vw,3.2rem);color:var(--accent-ink)}
.cta__sub{font-family:var(--fd);font-style:italic}
.cta__btn{background:var(--accent-ink);color:var(--accent);border-color:var(--accent-ink)}

/* ═══════════ FOOTER — espresso, serif wordmark, coast contour ═══════════ */
${darkChrome('footer')}
footer{position:relative;overflow:hidden;padding-block:clamp(3.5rem,7vw,5.5rem) var(--space-6)}
footer::before{content:"";position:absolute;top:0;left:0;right:0;height:150px;z-index:0;opacity:.5;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='260' height='150'%3E%3Cg fill='none' stroke='%23ffffff' stroke-opacity='0.12' stroke-width='1'%3E%3Cpath d='M0 30 Q65 10 130 30 T260 30'/%3E%3Cpath d='M0 62 Q65 42 130 62 T260 62'/%3E%3Cpath d='M0 94 Q65 74 130 94 T260 94'/%3E%3C/g%3E%3C/svg%3E");background-size:360px auto}
footer .container{position:relative;z-index:1}
.ft__name{font-family:var(--fd);font-weight:400;font-size:2rem;letter-spacing:.01em}
.ft__brand .small{color:var(--ink-soft)}
.ft__h{font-family:var(--fb);text-transform:uppercase;letter-spacing:.18em;font-size:.7rem;color:var(--support-2)}
.ft__col a{font-family:var(--fb);font-size:.9rem;color:var(--ink-soft)}
.ft__col a:hover{color:var(--ink)}
`,

  /* 2 · HERO — the SIGNATURE block: centred crest emblem on an espresso ground + rotating seal */
  heroHTML({wordmark, title, lead, dots=[], ctas=[], seal}){
    const btns = ctas.map((c,i)=>`<a class="btn ${i===0?'btn-primary':'btn-ghost'}" href="${c.href}">${c.label}</a>`).join('');
    const crest = `<svg class="hero__crest" viewBox="0 0 84 66" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" aria-hidden="true">
      <path d="M13 42 a29 29 0 0 1 58 0"/><circle cx="42" cy="31" r="6.5"/>
      <path d="M9 51 q8.25 -5 16.5 0 t16.5 0 t16.5 0 t16.5 0"/>
      <path d="M9 59 q8.25 -5 16.5 0 t16.5 0 t16.5 0 t16.5 0"/></svg>`;
    const sealHTML = `<div class="hero__seal" data-signature="rotating-seal" aria-hidden="true">
      <svg class="seal__spin" viewBox="0 0 120 120">
        <defs><path id="litoral-seal" d="M60 60 m-44 0 a44 44 0 1 1 88 0 a44 44 0 1 1 -88 0"/></defs>
        <text class="seal__txt"><textPath href="#litoral-seal" startOffset="0">· ${seal || (wordmark+' HOTEL · BY THE BAY · A QUIET LUXURY')} ·</textPath></text>
      </svg><span class="seal__mark">✳</span></div>`;
    return `<section class="section hero" data-section="hero" data-variant="emblem" data-ground="dark" data-signature="crest-emblem-hero">
      <div class="container hero__inner">
        ${dots.length?`<span class="hero__place">${dots.slice(0,2).join(' · ')}</span>`:''}
        <span data-motion="reveal-fade">${crest}</span>
        <h1 class="hero__word" data-motion="reveal-up">${wordmark}</h1>
        ${title?`<p class="hero__tag" data-motion="reveal-fade">${title}</p>`:''}
        ${lead?`<p class="lead hero__lead" data-motion="reveal-up">${lead}</p>`:''}
        ${btns?`<div class="hero__cta" data-motion="reveal-up">${btns}</div>`:''}
      </div>
      ${sealHTML}
    </section>`;
  }
};
