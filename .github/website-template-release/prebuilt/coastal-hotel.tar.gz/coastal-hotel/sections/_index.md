# Section library — coastal-hotel

Cut from the reference page by `tools/split-sections.mjs`. Pick the sections the brief supports,
in the order `NARRATIVE.md` gives, and assemble with `tools/compose.mjs`. A section you do not
pick is not in the page, so it cannot be left half-edited.

`_foundation.css` and `_shell.part` are always included. `css −` means the section reuses a skin
block an earlier section already brought. `geometry` is measured off the reference page at 1440 and
390 — column counts, the first media box's aspect ratio and its share of the section width, and the
section's own height. Read it here rather than opening the stylesheet.

| section | kind | html | skin | words | imgs | geometry |
|---|---|---|---|---|---|---|
| `01-nav` | nav | 1.7KB | — | 9 | 0 | 75px |
| `02-hero` | hero | 1.6KB | — | 43 | 0 | 928px |
| `03-logos` | logos | 1.7KB | — | 36 | 0 | 102px |
| `04-feature-grid` | feature-grid | 4.5KB | — | 188 | 0 | 3col · →1col · 1006px |
| `05-mosaic-scroll` | mosaic-scroll | 20.1KB | — | 107 | 32 | media 1.33 · 25%w · 997px |
| `06-feature` | feature | 2.1KB | — | 32 | 2 | 2col · →1col · media 0.8 · 35%w · 1704px |
| `07-feature` | feature | 2.1KB | — | 32 | 2 | 2col · →1col · media 0.8 · 42%w · 1704px |
| `08-stats` | stats | 0.6KB | — | 10 | 0 | 7col · →2col · 324px |
| `09-steps` | steps | 0.8KB | — | 38 | 0 | 4col · →1col · 468px |
| `10-sticky-scroll` | sticky-scroll | 4.1KB | — | 123 | 4 | media 1.33 · 31%w · 1800px |
| `11-sticky-scroll` | sticky-scroll | 3.4KB | — | 88 | 3 | media 1.33 · 31%w · 1800px |
| `12-arc-showcase` | arc-showcase | 3.5KB | — | 24 | 4 | media 0.96 · 32%w · 1066px |
| `13-card-grid` | card-grid | 5.1KB | — | 68 | 6 | 3col · →1col · media 0.76 · 21%w · 1625px |
| `14-index-tiles` | index-tiles | 2.3KB | — | 28 | 4 | 4col · →1col · media 0.75 · 17%w · 696px |
| `15-testimonial` | testimonial | 2.5KB | — | 55 | 3 | 3col · →1col · media 1 · 3%w · 551px |
| `16-testimonial` | testimonial | 9.1KB | — | 211 | 12 | media 1 · 3%w · 611px |
| `17-statement` | statement | 1.9KB | — | 240 | 0 | 853px |
| `18-pricing` | pricing | 1.3KB | — | 48 | 0 | 3col · →1col · 893px |
| `19-faq` | faq | 2.1KB | — | 66 | 0 | 653px |
| `20-contact` | contact | 1.1KB | — | 61 | 0 | 2col · →1col · 780px |
| `21-cta` | cta | 0.4KB | — | 14 | 0 | 465px |
| `22-footer` | footer | 1.7KB | — | 26 | 0 | 4col · →1col · 317px |

```json
{}
```

Whole reference page: 75.7KB · foundation 73.1KB.

## What each section is made of

Derived by `tools/describe-sections.mjs` — selectors matched in a browser, knobs read out of
`template.js`, hexes counted in the skin block. Read this instead of opening `template.js` or the
stylesheet: the four things below are what eleven runs went hunting for after composing, and they
are the ones the markup you composed does not tell you.

A **knob** changes what ships. `[data-cardgrid]` hides every card past `data-batch`, so a grid you
filled with six cards renders three until you raise it or drop the control. **Hardcoded** tints are
fixed hexes in the skin; the palette does not reach them, so a colour system you picked will not
recolour those parts.

Every section is also touched by `[data-motion="text-split"]` — the shared
motion/reveal runner, which reads data-to, data-suffix, data-motion, data-speed, data-pscale.
Listed once here; the lines below name only what is specific to one section.

### `01-nav`
- driven by: `.nav__burger` — reads data-open; · `.nav__menu a` — queries .nav__burger · `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label

### `02-hero`
- repeats: .mo-in ×4
- one repeat holds: svg×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `03-logos`
- repeats: .logos__item ×36
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `04-feature-grid`
- repeats: .fg__card ×6, .fg__icon ×6, .h3 ×6
- one repeat holds: svg×1, h3×1, p×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `05-mosaic-scroll`
- repeats: .mos__card ×32, .mos__media ×32, .media ×32
- one repeat holds: img×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `06-feature`
- repeats: .h2 ×3
- driven by: nothing of its own

### `07-feature`
- repeats: .h2 ×3
- driven by: nothing of its own

### `08-stats`
- repeats: .stats__cell ×4, .stats__num ×4, .small ×4
- one repeat holds: p×1
- driven by: nothing of its own

### `09-steps`
- repeats: .steps__item ×3, .steps__num ×3, .h3 ×3
- one repeat holds: h3×1, p×1
- driven by: nothing of its own

### `10-sticky-scroll`
- repeats: .ssh__card ×4, .ssh__media ×4, .media ×4
- one repeat holds: img×1, h3×1, p×1, a×1
- driven by: `[data-sticky-h]` — reads data-d; queries .ssh__track, .ssh__viewport, .ssh__cur, .ssh__card, .ssh__tab
- behaviour attributes present: data-i, data-d

### `11-sticky-scroll`
- repeats: .ssh__card ×3, .ssh__media ×3, .media ×3
- one repeat holds: img×1, h3×1, p×1, a×1
- driven by: `[data-sticky-h]` — reads data-d; queries .ssh__track, .ssh__viewport, .ssh__cur, .ssh__card, .ssh__tab
- behaviour attributes present: data-i, data-d

### `12-arc-showcase`
- repeats: .arc__card ×8, .arc__media ×8, .media ×8
- one repeat holds: img×1, a×1
- driven by: `[data-arc]` — queries .arc__stage, .arc__card, .arc__prev, .arc__next, .arc__media
- behaviour attributes present: data-i

### `13-card-grid`
- repeats: .mono ×18, .cg__card ×6, .cg__media ×6
- driven by: `[data-cardgrid]` — reads data-batch, data-cat; queries .cg__tab, .cg__card, .cg__morewrap, .cg__more, .cg__grid
- behaviour attributes present: data-cat

### `14-index-tiles`
- repeats: .it__tile ×4, .it__media ×4, .media ×4
- one repeat holds: img×1, h3×1, p×1
- driven by: nothing of its own

### `15-testimonial`
- repeats: .tm__card ×3, .tm__quote ×3, .tm__by ×3
- one repeat holds: img×1
- driven by: nothing of its own

### `16-testimonial`
- repeats: .tm__card ×12, .tm__quote ×12, .tm__by ×12
- one repeat holds: img×1
- driven by: nothing of its own
- behaviour attributes present: data-motion

### `17-statement`
- driven by: nothing of its own

### `18-pricing`
- repeats: .pr__card ×3, .h3 ×3, .pr__tier ×3
- one repeat holds: h3×1, li×3, a×1
- driven by: nothing of its own

### `19-faq`
- repeats: .faq__item ×4, .faq__q ×4, .faq__icon ×4
- one repeat holds: svg×1, p×1
- driven by: `.faq__item` — queries summary, .faq__a

### `20-contact`
- repeats: .cf__field ×3
- driven by: `.cf__form` — queries .cf__ok

### `21-cta`
- driven by: nothing of its own

### `22-footer`
- repeats: .ft__col ×3, .ft__h ×3
- one repeat holds: h3×1, li×2, a×2
- driven by: `[data-theme-toggle]` — reads data-theme; queries .theme-toggle__label
