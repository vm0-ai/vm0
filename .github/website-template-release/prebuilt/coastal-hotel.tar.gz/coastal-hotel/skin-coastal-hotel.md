# skin-coastal-hotel — spec  (demo brand: “Litoral”)

**Essence.** Restrained Basque-coastal "quiet luxury" — a boutique seaside hotel by the bay.
An elegant LIGHT high-contrast serif over a geometric sans; hand-drawn line motifs and tactile
paper. Learned fresh (no prior skin referenced) from a 4★ San Sebastián hotel facing La Concha.

**Colour is NOT lifted from the source.** It is driven by the system catalogue
(`palettes.mjs` → **`clay`**, warm terracotta / espresso) so the look is unmistakably its own —
the source's sage-green is deliberately avoided. `import { palette } from '../../palettes.mjs'`
supplies all 11 roles (both themes) + a derived espresso flooded ground.

**Type.** display **Cormorant** (light 300–400, elegant high contrast) ← *Berlingske Serif Lt*;
body/label **Jost** (geometric, tracked uppercase) ← *Hurme Geometric Sans*.

**Signatures (structure carried over, painted in clay).**
- centred **crest-emblem hero** on an espresso ground + a slowly **rotating seal**;
- **tilted "postcard" cards** (feature / rooms / pinned quotes) that straighten & lift on hover;
- **hairline-ruled** lists (feature brackets, pricing rows, faq, stats dividers);
- **watercolour-coast contour** SVG motif behind the booking CTA + footer;
- a **fanned ARC showcase** (`arcShowcase`) — centre card upright & largest, sides drop & rotate
  out; prev/next buttons + autoplay (pausable, reduced-motion safe);
- a full-bleed **scroll-illuminate statement** (`scrollStatement` + the `text-illuminate` motion)
  whose lines brighten one by one as you scroll;
- a **split contact** (`contactForm layout:'split'`) — framed photo left, form right;
- **flush logo band** (no vertical padding, uniform gaps) hugging the hero + next section.

**System promotions shipped with this skin (reusable by any future skin / generated page):**
- `arcShowcase()` + `ARC_JS` + base CSS (sections.mjs) — the fanned-arc carousel.
- `scrollStatement()` (sections.mjs) + `text-illuminate` motion primitive (motion.css/mjs).
- `contactForm({layout:'split', photo})` variant (sections.mjs).
- build-skinsheet + gen-engine now inject `SECTION_CSS_X` (base CSS for all structural
  promotions) and `ARC_JS`.

**Tuning (2026-07-07, Tong).** Three template tweaks folded into the skin CSS:
- **Logos band label** centred — it's a `<p>`, so `p{max-width:68ch}` shrank + left-aligned the
  block; added `max-width:none;margin-inline:auto` so `text-align:center` actually centres it.
- **Stats figures stay on ONE line** — `.stats__num` now `white-space:nowrap` with a smaller
  clamp `clamp(1.9rem,4vw,3.4rem)`, so long values (e.g. `1.6M km²`, `8,611 m`) shrink to fit
  instead of wrapping.
- **CTA band floats with a real side gap at every width** — the panel *is* the `.container`, so
  a plain 1200 cap made it touch the viewport edges in the ~1200–1280 band. Capped its width to
  `min(var(--container),calc(100% - clamp(2.5rem,8vw,5rem)))` so cream always shows on both sides
  (40px each side at ~1207–1280, 120px at 1440, 20–31px on mobile/tablet); internal text padding
  stays on `.cta__panel`. The `5rem` cap is deliberate — at the gate's 1280px checkpoint the
  container lands back on exactly 1200px, so this adds NO grid-consistency violation.

**Gate status.** `qa-site` **PASS** full (4bp × 2 themes · landmarks · tap-target · links ·
contrast · type-floor · DUAL-MODE) **and** `--site` **PASS** (SIGNATURE · MOTION-NON-UNIFORM ·
LAYOUT-VARIETY). Verified by eye across every section + both themes; photos via `apply-photos`.

**Live URL (catalog / skinsheet).** https://ws-coastal-hotel-715f6d07-94dc125e.sites.vm0.io
(the earlier https://ws-litoral-715f6d07-a2299168.sites.vm0.io serves the same build)
